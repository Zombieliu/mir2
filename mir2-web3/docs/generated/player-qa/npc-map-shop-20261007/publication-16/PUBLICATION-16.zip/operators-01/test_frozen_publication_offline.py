"""Verify genuine generated R20/s16 bytes without executing any operator.

Root supplied the proof/plan hashes below after its strict CMS reconstruction.
This suite checks that admission and source bindings are copied unchanged; it
does not perform CMS verification itself. Remote reads/writes are memory-only.
"""
import ast
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
import unittest

from test_operator_offline import gen, MemoryGuard

HERE = Path(__file__).resolve().parent
PLAN_SHA = '905bc48ea9a210d5cb8ef5d82f748b341d9654cf287f1c3803ce74a1a7ae556d'
PROOF_SHA = '6a59813e8e3451820a064e1ff1c9f7525f77e0aab6ed85ffa791c8679c3192e8'


def data(name):
    return (HERE / name).read_bytes()


def body(name):
    lines = data(name).decode('utf-8').splitlines()
    if lines[0] not in ("sudo -n python3 -B - <<'PY'", "python3 -B - <<'PY'") or lines[-1] != 'PY':
        raise RuntimeError('frozen-command-envelope')
    source = '\n'.join(lines[1:-1]) + '\n'
    return source, ast.parse(source)


def assignment(tree, name):
    return next(node.value for node in tree.body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == name for target in node.targets))


def literal_assignment(tree, name):
    return ast.literal_eval(assignment(tree, name))


def actual_writer():
    module = SimpleNamespace(__name__='frozen_r20_writer_offline', __file__=str(HERE / 'origin_r20_s16.py'))
    exec(compile(data('origin_r20_s16.py'), '<ACTUAL-FROZEN-WRITER-NO-MAIN>', 'exec'), module.__dict__)
    # These are local-byte witnesses keyed by the fixed remote private filenames.
    guard = MemoryGuard({str(module.STAGE / name): data(name) for name in (
        'ROOT-VERIFICATION.json', 'PUBLICATION-PLAN.json', 'APPEND-INPUTS.prepared.json',
        'PREVIOUS-ROOT-VERIFICATION.json', 'PREVIOUS-PUBLICATION-PLAN.json')})
    plan = json.loads(data('PUBLICATION-PLAN.json'))
    needed = [0, 1] + [row['index'] for row in module.PINS['new']
                      if row['path'].endswith('/RELEASE-STATEMENT.json') or row['path'].endswith('/ENGINE.json')]
    for index in needed:
        guard.files[str(module.STAGE / module.PINS['sourceNames'][index])] = Path(plan['objects'][index]['source']).read_bytes()
    return module, guard


class ActualFrozenPublicationTests(unittest.TestCase):
    def test_all_generated_output_hashes_and_sizes_match_receipt(self):
        receipt = json.loads(data('OFFLINE-PREPARATION-01.json'))
        expected_names = set(gen.OUTPUT_NAMES) - {'OFFLINE-PREPARATION-01.json'}
        self.assertEqual({Path(row['path']).name for row in receipt['outputs']}, expected_names)
        for row in receipt['outputs']:
            path = Path(row['path'])
            self.assertEqual(path.parent, HERE)
            raw = path.read_bytes()
            self.assertEqual(len(raw), row['size'])
            self.assertEqual(gen.sha(raw), row['sha256'])
        self.assertFalse(receipt['cmsReverifiedByThisGenerator'])
        self.assertEqual(receipt['networkCalls'], 0)
        self.assertFalse(receipt['publicMutations'])

    def test_actual_root_proof_and_plan_are_exact_parent_issued_bytes(self):
        self.assertEqual(gen.sha(data('PUBLICATION-PLAN.json')), PLAN_SHA)
        self.assertEqual(gen.sha(data('ROOT-VERIFICATION.json')), PROOF_SHA)
        origin = HERE.parent / 'publication-01'
        self.assertEqual(data('PUBLICATION-PLAN.json'), (origin / 'PUBLICATION-PLAN.json').read_bytes())
        self.assertEqual(data('ROOT-VERIFICATION.json'), (origin / 'ROOT-VERIFICATION.json').read_bytes())
        plan, proof = json.loads(data('PUBLICATION-PLAN.json')), json.loads(data('ROOT-VERIFICATION.json'))
        self.assertEqual(len(gen.validate_admission(plan, proof, PLAN_SHA, PROOF_SHA, 16)), 41)

    def test_actual_rendered_writer_matches_generator_and_accepts_frozen_metadata(self):
        module, guard = actual_writer()
        self.assertEqual(module.GAME, gen.GAME)
        self.assertEqual(module.ENGINE, gen.ENGINE)
        self.assertEqual(module.PINS['proof'], PROOF_SHA)
        self.assertEqual(module.PINS['publication'], PLAN_SHA)
        rendered = gen.render_writer(module.PINS,
            (gen.OLD / 'operators-01/origin_r19_s15.py').read_text(), (HERE / 'origin_r20_tail.py.in').read_text())
        self.assertEqual(rendered.encode('utf-8'), data('origin_r20_s16.py'))
        self.assertEqual(len(module.fixed_envelope(guard)), 41)

    def test_actual_frozen_writer_rejects_modified_proof_and_membership(self):
        module, guard = actual_writer()
        guard.files[str(module.STAGE / 'ROOT-VERIFICATION.json')] += b'\n'
        with self.assertRaisesRegex(RuntimeError, 'envelope-hash'):
            module.fixed_envelope(guard)
        module, guard = actual_writer()
        module.PINS['new'][-1]['size'] += 1
        with self.assertRaisesRegex(RuntimeError, 'fixed-object-proof-mismatch'):
            module.fixed_envelope(guard)

    def test_actual_seal_literal_closure_and_reuse_are_root_bound(self):
        source, tree = body('SEAL-STAGE-01.command')
        rows = literal_assignment(tree, 'ROWS')
        self.assertEqual(rows, json.loads(data('SEAL-INPUTS-01.json')))
        self.assertEqual(len(rows), 48)
        self.assertEqual(len({row['name'] for row in rows}), 48)
        public_rows = [row for row in rows if row['kind'] == 'public']
        self.assertEqual(len(public_rows), 19)
        self.assertEqual(sum(row['size'] for row in public_rows), 357550434)
        previous = json.loads(data('PREVIOUS-PUBLICATION-PLAN.json'))
        old = {row['path']: row for row in previous['objects']}
        for row in public_rows:
            relative = PurePosixPath(row['source']).relative_to(PurePosixPath(gen.PUBLIC)).as_posix()
            self.assertEqual((row['size'], row['sha256']), (old[relative]['size'], old[relative]['sha256']))
        for name, value in [('USER', gen.USER), ('ROOT', gen.ROOT), ('PUBLIC', gen.PUBLIC)]:
            self.assertEqual(ast.literal_eval(assignment(tree, name).args[0]), value)
        self.assertIn('dir_fd=userfd', source)
        self.assertIn('immutable-public-reuse-source-required', source)
        self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)))

    def test_actual_upload_batch_is_exact_user_inputs_without_reuse_uploads(self):
        _, tree = body('SEAL-STAGE-01.command')
        rows = literal_assignment(tree, 'ROWS')
        users = {row['name']: row for row in rows if row['kind'] == 'user'}
        batch = json.loads(data('UPLOAD-BATCH-01.json'))
        self.assertEqual(len(batch), 29)
        self.assertEqual({PurePosixPath(destination).name for _, destination in batch}, set(users))
        self.assertEqual(len({destination for _, destination in batch}), 29)
        for path, destination in batch:
            name = PurePosixPath(destination).name
            self.assertEqual(destination, users[name]['source'])
            self.assertEqual(PurePosixPath(destination).parent, PurePosixPath(gen.USER))
            self.assertTrue(Path(path).is_file())
            self.assertEqual(Path(path).stat().st_size, users[name]['size'])
        receipt = json.loads(data('OFFLINE-PREPARATION-01.json'))
        self.assertEqual(receipt['uploadedObjectBytes'], 719854986)

    def test_actual_promote_literal_pins_writer_and_retains_exchange_cas_tls(self):
        source, tree = body('FEED-PROMOTE-01.command')
        self.assertEqual(literal_assignment(tree, 'WRITER_SHA256'), gen.sha(data('origin_r20_s16.py')))
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call) and ast.unparse(node.func) == 'rename']
        self.assertEqual(len(calls), 1)
        self.assertEqual(ast.literal_eval(calls[0].args[-1]), 2)
        self.assertLess(source.index('w.stable_feed(g) == old_identity'), source.index('need(rename('))
        self.assertIn('feed16-ready', source)
        self.assertIn('old_identity[name]', source)
        self.assertIn('ssl.create_default_context()', source)
        self.assertIn('w.same_pids(before, w.snapshot_services())', source)
        self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)))

    def test_actual_primitive_commands_remain_static_and_fresh_generator_refuses_rerun(self):
        self.assertEqual(data('PREFLIGHT-01.command'), f'sudo -n python3 -B {gen.ROOT}/origin_r20_s16.py preflight\n'.encode())
        self.assertEqual(data('APPEND-01.command'), f'sudo -n python3 -B {gen.ROOT}/origin_r20_s16.py append\n'.encode())
        for name in ['CREATE-STAGE-01.command', 'PRIVATE-MODES-01.command']:
            _, tree = body(name)
            self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)))
        with self.assertRaisesRegex(RuntimeError, 'fresh-output-required'):
            gen.require_fresh_outputs()


if __name__ == '__main__':
    unittest.main(verbosity=2)
