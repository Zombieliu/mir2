python3 -B - <<'PY'
import json, os, pathlib, stat
def need(condition, label):
    if not condition:
        raise RuntimeError(label)
path = pathlib.Path('/tmp/mir2-origin-r20-s16-20261007-01')
need(os.geteuid() == 1000 and not path.exists() and not path.is_symlink(), 'fresh-user-stage-required')
i = path.parent.lstat()
need(stat.S_ISDIR(i.st_mode) and i.st_uid == 0, 'unsafe-tmp-parent')
path.mkdir(mode=0o700)
i = path.lstat()
need(stat.S_ISDIR(i.st_mode) and i.st_uid == 1000 and stat.S_IMODE(i.st_mode) == 0o700, 'private-created-stage')
print(json.dumps({'schema': 'mir2.private-upload-stage.v1', 'created': True, 'path': str(path)}))
PY
