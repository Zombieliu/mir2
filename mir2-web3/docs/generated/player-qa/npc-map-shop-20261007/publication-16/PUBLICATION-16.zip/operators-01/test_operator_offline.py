"""Offline unit checks. In-memory fixture proofs do NOT claim CMS admission.

Never invokes the generator main, a Linux command, SSH, a network API, or UI.
No fixture artifact is saved. Exact reviewed R19 guards and rendered R20 writer
functions are exercised with in-memory byte/metadata/descriptor test doubles.
"""
import ast
from contextlib import contextmanager
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import stat
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent


def load_module(name, path, expected_sha=None):
    raw = path.read_bytes()
    if expected_sha is not None and hashlib.sha256(raw).hexdigest() != expected_sha:
        raise RuntimeError('test-reviewed-module-pin')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw, str(path), 'exec'), module.__dict__)
    return module


gen = load_module('r20_offline_generator_under_test', HERE / 'prepare_origin_r20_s16.py')
guards = load_module('r19_pinned_guards_under_test', gen.OLD / 'operators-01/guards.py', gen.GUARDS_SHA)
OLD_WRITER = (gen.OLD / 'operators-01/origin_r19_s15.py').read_text()
TAIL = (HERE / 'origin_r20_tail.py.in').read_text()


def meta(size=1, **changes):
    values = dict(st_dev=7, st_ino=23, st_mode=stat.S_IFREG | 0o444, st_uid=0, st_nlink=1,
                  st_size=size, st_mtime_ns=11, st_ctime_ns=12, st_file_attributes=0)
    values.update(changes)
    return SimpleNamespace(**values)


class MemoryGuard:
    def __init__(self, files=None):
        self.files = dict(files or {})
        self.match_calls = []
        self.parents_calls = []
        self.reader_info_override = None
        self.reader_bytes_override = None

    def read(self, path, maximum, expected=None):
        raw = self.files[str(path)]
        if len(raw) > maximum:
            raise RuntimeError('memory-read-bound')
        if expected is not None and (len(raw) != expected['size'] or gen.sha(raw) != expected['sha256']):
            raise RuntimeError('memory-file-pin')
        return raw

    def file_info(self, path):
        return meta(len(self.files[str(path)]))

    def identity(self, info):
        return guards.fingerprint(info)

    def match(self, path, expected):
        self.match_calls.append(str(path))
        self.read(path, expected['size'], expected)
        return guards.fingerprint(self.file_info(path))

    def parents(self, path):
        self.parents_calls.append(str(path))

    @contextmanager
    def opened(self, path):
        raw = self.files[str(path)] if self.reader_bytes_override is None else self.reader_bytes_override
        before = self.file_info(path) if self.reader_info_override is None else self.reader_info_override
        with io.BytesIO(raw) as reader:
            yield reader, before


class MemoryWriter(io.BytesIO):
    def __init__(self, files, path):
        super().__init__()
        self.files, self.path = files, str(path)

    def fileno(self):
        return 9

    def close(self):
        if not self.closed:
            self.files[self.path] = self.getvalue()
        super().close()


class MemoryOS:
    O_WRONLY, O_CREAT, O_EXCL, O_NOFOLLOW, O_CLOEXEC = 1, 64, 128, 131072, 524288

    def __init__(self, guard):
        self.guard = guard
        self.opens, self.modes, self.syncs = [], [], []
        self.target = None

    def open(self, target, flags, mode):
        self.opens.append((str(target), flags, mode))
        if flags & self.O_EXCL and str(target) in self.guard.files:
            raise FileExistsError('memory-exclusive-create')
        self.target = target
        return 9

    def fdopen(self, descriptor, mode):
        return MemoryWriter(self.guard.files, self.target)

    def fsync(self, descriptor):
        self.syncs.append(descriptor)

    def fchmod(self, descriptor, mode):
        self.modes.append(mode)


class MemoryOps:
    def __init__(self):
        self.synced = []

    def sync_dir(self, guard, path):
        self.synced.append(str(path))


def render_fixture_writer():
    # These fixtures exist only in memory and have no signatures/CMS verifier.
    game_dir = 'releases/game-' + gen.CANDIDATE
    engine_dir = 'releases/unit-engine'
    new_feed = gen.encoded({'sequence': 16, 'expiresUnix': 99999999999,
                           'game': {'directory': game_dir, 'identity': gen.CANDIDATE},
                           'engine': {'directory': engine_dir}})
    old_feed = gen.encoded({'sequence': 15, 'expiresUnix': 99999999999,
                           'game': {'directory': 'releases/game-WN-CANDIDATE-20261007-invited-19'}})
    payloads = [new_feed, b'UNIT-ONLY-NO-CMS',
                gen.encoded({'gitRevision': gen.GAME, 'candidate': gen.CANDIDATE, 'worktreeDirty': False}),
                gen.encoded({'sourceRevision': gen.ENGINE, 'exeSha256': gen.ENGINE_EXE_SHA})]
    paths = ['feeds/unit/latest.json', 'feeds/unit/latest.p7s', game_dir + '/RELEASE-STATEMENT.json', engine_dir + '/ENGINE.json']
    new = [dict(index=i, path=p, size=len(raw), sha256=gen.sha(raw)) for i, (p, raw) in enumerate(zip(paths, payloads))]
    previous = [dict(index=i, path=p, size=len(raw), sha256=gen.sha(raw))
                for i, (p, raw) in enumerate(zip(['feeds/previous/latest.json', 'feeds/previous/latest.p7s'], [old_feed, b'OLD-UNIT-NO-CMS']))]

    def admission(objects, sequence):
        closure = sorted([{k: row[k] for k in ('path', 'size', 'sha256')} for row in objects], key=lambda row: row['path'])
        closed_raw = (json.dumps(closure, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()
        return gen.encoded({'passed': True, 'cmsVerified': True, 'candidateVerified': True,
                            'sequence': sequence, 'sourceRevision': gen.ENGINE, 'objectsSha256': gen.sha(closed_raw)})

    proof, old_proof = admission(new, 16), admission(previous, 15)
    plan = gen.encoded({'verificationReceipt': {'sha256': gen.sha(proof)},
                        'objects': [{k: v for k, v in row.items() if k != 'index'} for row in new]})
    old_plan = gen.encoded({'verificationReceipt': {'sha256': gen.sha(old_proof)},
                            'objects': [{k: v for k, v in row.items() if k != 'index'} for row in previous]})
    prepared = gen.encoded({'gameSource': gen.GAME, 'engineSource': gen.ENGINE, 'sequence': 16})
    pins = dict(guards=gen.GUARDS_SHA, proof=gen.sha(proof), publication=gen.sha(plan), prepared=gen.sha(prepared),
                previousProof=gen.sha(old_proof), previousPublication=gen.sha(old_plan), config=gen.CADDY_SHA,
                previousFeed={'latest.json': {k: previous[0][k] for k in ('size', 'sha256')},
                              'latest.p7s': {k: previous[1][k] for k in ('size', 'sha256')}},
                previousGameDirectory='releases/game-WN-CANDIDATE-20261007-invited-19',
                gameDirectory=game_dir, candidate=gen.CANDIDATE, engineExeSha256=gen.ENGINE_EXE_SHA,
                new=new, previousObjects=previous, sourceNames={i: f'UNIT-{i}' for i in range(len(new))})
    writer = gen.render_writer(pins, OLD_WRITER, TAIL)
    module = SimpleNamespace(__name__='offline_generated_writer_unit', __file__=str(HERE / 'UNIT-NOT-A-RELEASE.py'))
    exec(compile(writer, '<IN-MEMORY-UNIT-WRITER>', 'exec'), module.__dict__)
    files = {str(module.STAGE / name): raw for name, raw in {
        'ROOT-VERIFICATION.json': proof, 'PUBLICATION-PLAN.json': plan, 'APPEND-INPUTS.prepared.json': prepared,
        'PREVIOUS-ROOT-VERIFICATION.json': old_proof, 'PREVIOUS-PUBLICATION-PLAN.json': old_plan}.items()}
    for i, raw in enumerate(payloads):
        files[str(module.STAGE / pins['sourceNames'][i])] = raw
    files[str(module.PUBLIC / 'feed-current/latest.json')] = old_feed
    files[str(module.PUBLIC / 'feed-current/latest.p7s')] = b'OLD-UNIT-NO-CMS'
    return module, MemoryGuard(files), writer


class OfflineOperatorTests(unittest.TestCase):
    def setUp(self):
        self.writer, self.guard, self.rendered = render_fixture_writer()

    def object_plan(self, count=2, size=1, suffix='.bin'):
        return {'schema': 'mir2.windows.r2-publication.v1',
                'objects': [dict(path=f'releases/unit/{i}{suffix}', source='C:/UNIT-NOT-A-RELEASE',
                                 size=size, sha256='a' * 64) for i in range(count)]}

    def repin_json(self, name, key, mutate):
        path = str(self.writer.STAGE / name)
        value = json.loads(self.guard.files[path])
        mutate(value)
        self.guard.files[path] = gen.encoded(value)
        self.writer.PINS[key] = gen.sha(self.guard.files[path])

    def test_publication_accepts_exact_100_object_bound(self):
        self.assertEqual(len(gen.object_rows(self.object_plan(100))), 100)

    def test_publication_rejects_101_objects(self):
        with self.assertRaisesRegex(RuntimeError, 'object-count-bound'):
            gen.object_rows(self.object_plan(101))

    def test_publication_metadata_and_artifact_bounds(self):
        for suffix, maximum in [('.json', gen.MAX_METADATA), ('.p7s', gen.MAX_METADATA), ('.exe', gen.MAX_ARTIFACT), ('.m2b', gen.MAX_ARTIFACT)]:
            with self.subTest(suffix=suffix):
                gen.object_rows(self.object_plan(size=maximum, suffix=suffix))
                with self.assertRaisesRegex(RuntimeError, 'object-size-bound'):
                    gen.object_rows(self.object_plan(size=maximum + 1, suffix=suffix))

    def test_publication_rejects_bool_negative_zero_sizes(self):
        for size in [True, False, -1, 0]:
            with self.subTest(size=size), self.assertRaisesRegex(RuntimeError, 'object-size-bound'):
                gen.object_rows(self.object_plan(size=size))

    def test_publication_rejects_path_escape_duplicate_and_upper_sha(self):
        for bad_path in ['../escape', '/releases/escape', 'releases/unit/../escape', 'feed-current/latest.json', 'releases/unit//item.bin']:
            plan = self.object_plan()
            plan['objects'][0]['path'] = bad_path
            with self.subTest(path=bad_path), self.assertRaisesRegex(RuntimeError, 'public-object-boundary'):
                gen.object_rows(plan)
        plan = self.object_plan()
        plan['objects'][1]['path'] = plan['objects'][0]['path']
        with self.assertRaisesRegex(RuntimeError, 'duplicate-public-path'):
            gen.object_rows(plan)
        plan = self.object_plan()
        plan['objects'][0]['sha256'] = 'A' * 64
        with self.assertRaisesRegex(RuntimeError, 'object-sha-source'):
            gen.object_rows(plan)

    def test_duplicate_json_keys_rejected(self):
        with self.assertRaisesRegex(RuntimeError, 'duplicate-json-key'):
            gen.decode(b'{"sequence":16,"sequence":15}')

    def test_fresh_output_rejects_existing_or_dangling_symlink(self):
        class FakePath:
            def __init__(self, name): self.name = name
            def exists(self): return self.name == 'ROOT-VERIFICATION.json'
            def is_symlink(self): return False
        class FakeDirectory:
            def __truediv__(self, name): return FakePath(name)
        with patch.object(gen, 'OUT', FakeDirectory()), self.assertRaisesRegex(RuntimeError, 'fresh-output-required:ROOT-VERIFICATION'):
            gen.require_fresh_outputs()
        with patch.object(FakePath, 'exists', lambda self: False), patch.object(FakePath, 'is_symlink', lambda self: self.name == 'APPEND-01.command'):
            with patch.object(gen, 'OUT', FakeDirectory()), self.assertRaisesRegex(RuntimeError, 'fresh-output-required:APPEND-01'):
                gen.require_fresh_outputs()

    def test_generator_rejects_changed_reviewed_r19_template(self):
        with self.assertRaisesRegex(RuntimeError, 'reviewed-writer-template-pin'):
            gen.render_writer(self.writer.PINS, OLD_WRITER + '\n', TAIL)

    def test_pinned_guard_rejects_nonroot_links_writable_or_nonplain_files(self):
        validator = guards.Guard()
        validator.check_info(meta(), False, False)
        for changes in [dict(st_uid=1000), dict(st_nlink=2), dict(st_mode=stat.S_IFREG | 0o664),
                        dict(st_mode=stat.S_IFLNK | 0o777), dict(st_mode=stat.S_IFDIR | 0o755), dict(st_file_attributes=0x400)]:
            with self.subTest(changes=changes), self.assertRaises(guards.Refusal):
                validator.check_info(meta(**changes), False, False)
        with self.assertRaises(guards.Refusal):
            validator.check_info(meta(st_mode=stat.S_IFREG | 0o644), False, True)

    def test_generated_envelope_accepts_in_memory_fixture_only(self):
        self.assertEqual(len(self.writer.fixed_envelope(self.guard)), 4)

    def test_generated_envelope_rejects_unrepinned_raw_proof(self):
        key = str(self.writer.STAGE / 'ROOT-VERIFICATION.json')
        self.guard.files[key] += b'\n'
        with self.assertRaisesRegex(RuntimeError, 'envelope-hash'):
            self.writer.fixed_envelope(self.guard)

    def test_generated_envelope_rejects_false_proof_claims_or_wrong_sequence(self):
        for field, value in [('passed', False), ('cmsVerified', False), ('candidateVerified', False), ('sequence', 15), ('sourceRevision', '0' * 40)]:
            module, guard, _ = render_fixture_writer()
            path = str(module.STAGE / 'ROOT-VERIFICATION.json')
            data = json.loads(guard.files[path]); data[field] = value
            guard.files[path] = gen.encoded(data); module.PINS['proof'] = gen.sha(guard.files[path])
            with self.subTest(field=field), self.assertRaisesRegex(RuntimeError, 'genuine-root-proof-binding'):
                module.fixed_envelope(guard)

    def test_generated_envelope_rejects_rehashed_changed_object_closure(self):
        self.repin_json('PUBLICATION-PLAN.json', 'publication', lambda value: value['objects'][2].update(size=999))
        with self.assertRaisesRegex(RuntimeError, 'closed-object-proof-digest'):
            self.writer.fixed_envelope(self.guard)

    def test_generated_envelope_rejects_same_digest_membership_pin_change(self):
        self.writer.PINS['new'][2]['sha256'] = '0' * 64
        with self.assertRaisesRegex(RuntimeError, 'fixed-object-proof-mismatch'):
            self.writer.fixed_envelope(self.guard)

    def test_generated_envelope_rejects_wrong_game_source_or_dirty_statement(self):
        for field, value in [('gitRevision', '0' * 40), ('candidate', 'OTHER'), ('worktreeDirty', True)]:
            module, guard, _ = render_fixture_writer()
            row = module.PINS['new'][2]
            path = str(module.STAGE / module.PINS['sourceNames'][2])
            body = json.loads(guard.files[path]); body[field] = value
            guard.files[path] = gen.encoded(body)
            # To reach the source-specific guard, change all mock closure bindings consistently.
            row.update(size=len(guard.files[path]), sha256=gen.sha(guard.files[path]))
            pub_path = str(module.STAGE / 'PUBLICATION-PLAN.json')
            pub = json.loads(guard.files[pub_path]); pub['objects'][2].update(size=row['size'], sha256=row['sha256'])
            closure = sorted([{k: o[k] for k in ('path', 'size', 'sha256')} for o in pub['objects']], key=lambda o: o['path'])
            proof_path = str(module.STAGE / 'ROOT-VERIFICATION.json')
            proof = json.loads(guard.files[proof_path]); proof['objectsSha256'] = gen.sha((json.dumps(closure, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode())
            guard.files[proof_path] = gen.encoded(proof); module.PINS['proof'] = gen.sha(guard.files[proof_path])
            pub['verificationReceipt']['sha256'] = module.PINS['proof']
            guard.files[pub_path] = gen.encoded(pub); module.PINS['publication'] = gen.sha(guard.files[pub_path])
            with self.subTest(field=field), self.assertRaisesRegex(RuntimeError, 'game-statement-source-binding'):
                module.fixed_envelope(guard)

    def test_generated_previous_feed_cas_refuses_changed_bytes(self):
        self.writer.stable_feed(self.guard)
        path = str(self.writer.PUBLIC / 'feed-current/latest.json')
        self.guard.files[path] = self.guard.files[path].replace(b'15', b'16', 1)
        with self.assertRaisesRegex(RuntimeError, 'memory-file-pin'):
            self.writer.stable_feed(self.guard)

    def test_generated_same_pids_refuses_restart_or_state_change_allows_new_players(self):
        before = {'game': {'MainPID': '7', 'ActiveState': 'active', 'incoming': 1}}
        self.writer.same_pids(before, {'game': {'MainPID': '7', 'ActiveState': 'active', 'incoming': 9}})
        for after in [{'game': {'MainPID': '8', 'ActiveState': 'active'}}, {'game': {'MainPID': '7', 'ActiveState': 'inactive'}}]:
            with self.assertRaisesRegex(RuntimeError, 'service-pid-or-state-changed'):
                self.writer.same_pids(before, after)

    def test_generated_boot_refuses_nonroot_before_any_stage_access(self):
        with patch.object(self.writer, 'sys', SimpleNamespace(platform='linux')), patch.object(self.writer, 'os', SimpleNamespace(geteuid=lambda: 1000)):
            with self.assertRaisesRegex(RuntimeError, 'linux-root-required'):
                self.writer.boot()

    def test_generated_copy_uses_exclusive_nofollow_stream_and_private_then_immutable(self):
        source, target = PurePosixPath('/UNIT/source'), PurePosixPath('/UNIT/staged')
        raw = b'unit-original-bytes'
        guard = MemoryGuard({str(source): raw}); filesystem = MemoryOS(guard); ops = MemoryOps()
        pin = dict(size=len(raw), sha256=gen.sha(raw))
        with patch.object(self.writer, 'os', filesystem):
            self.writer.copy_frozen(guard, ops, source, target, pin, 0o444)
        flags = filesystem.opens[0][1]
        self.assertTrue(flags & filesystem.O_EXCL and flags & filesystem.O_NOFOLLOW and flags & filesystem.O_CLOEXEC)
        self.assertEqual(filesystem.opens[0][2], 0o600)
        self.assertEqual(filesystem.modes, [0o444])
        self.assertEqual(guard.files[str(target)], raw)
        self.assertEqual(guard.files[str(source)], raw)

    def test_generated_copy_refuses_overwrite_without_touching_existing_bytes(self):
        source, target = PurePosixPath('/UNIT/source'), PurePosixPath('/UNIT/staged')
        guard = MemoryGuard({str(source): b'new', str(target): b'existing'})
        filesystem = MemoryOS(guard)
        with patch.object(self.writer, 'os', filesystem), self.assertRaises(FileExistsError):
            self.writer.copy_frozen(guard, MemoryOps(), source, target, dict(size=3, sha256=gen.sha(b'new')), 0o444)
        self.assertEqual(guard.files[str(target)], b'existing')
        self.assertEqual(filesystem.modes, [])

    def test_generated_copy_bad_hash_overrun_or_wrong_size_never_becomes_immutable(self):
        for kind in ['hash', 'overrun', 'size']:
            source, target = PurePosixPath('/UNIT/source'), PurePosixPath('/UNIT/staged')
            guard = MemoryGuard({str(source): b'ab'}); filesystem = MemoryOS(guard)
            pin = dict(size=2, sha256=gen.sha(b'ab'))
            if kind == 'hash': pin['sha256'] = '0' * 64
            if kind == 'overrun': guard.reader_info_override = meta(size=2); guard.reader_bytes_override = b'abc'
            if kind == 'size': pin['size'] = 1
            with self.subTest(kind=kind), patch.object(self.writer, 'os', filesystem), self.assertRaises(RuntimeError):
                self.writer.copy_frozen(guard, MemoryOps(), source, target, pin, 0o444)
            self.assertEqual(filesystem.modes, [])
            self.assertEqual(guard.files[str(source)], b'ab')

    def test_generated_target_escape_rejected_before_file_checks(self):
        self.writer.PUBLIC = Path('C:/UNIT-NOT-A-REAL-PUBLIC')
        for value in ['../outside.bin', 'releases/unit/../../../../outside.bin', 'D:/outside.bin']:
            with self.subTest(path=value), self.assertRaisesRegex(RuntimeError, 'target-escape'):
                self.writer.check_target(self.guard, dict(path=value, size=1, sha256='0' * 64))
        self.assertEqual(self.guard.match_calls, [])

    def test_actual_reviewed_lock_and_atomic_rename_contracts_are_retained(self):
        lock = ast.parse((gen.OLD / 'operators-01/guards.py').read_text())
        operation_class = next(node for node in lock.body if isinstance(node, ast.ClassDef) and node.name == 'Operations')
        lock_fn = next(node for node in operation_class.body if isinstance(node, ast.FunctionDef) and node.name == 'lock')
        opens = [node for node in ast.walk(lock_fn) if isinstance(node, ast.Call) and ast.unparse(node.func) == 'os.open']
        self.assertEqual(len(opens), 1)
        flags = ast.unparse(opens[0].args[1])
        self.assertIn('O_NOFOLLOW', flags); self.assertIn('O_CLOEXEC', flags)
        self.assertNotIn('O_CREAT', flags); self.assertNotIn('O_TRUNC', flags)
        rename_fn = next(node for node in operation_class.body if isinstance(node, ast.FunctionDef) and node.name == 'rename_new')
        rename = next(node for node in ast.walk(rename_fn) if isinstance(node, ast.Call) and ast.unparse(node.func) == 'rename')
        self.assertEqual(ast.literal_eval(rename.args[-1]), 1)  # RENAME_NOREPLACE
        promote = ast.parse((HERE / 'feed_promote_r20.py.in').read_text())
        exchange = next(node for node in ast.walk(promote) if isinstance(node, ast.Call) and ast.unparse(node.func) == 'rename')
        self.assertEqual(ast.literal_eval(exchange.args[-1]), 2)  # RENAME_EXCHANGE
        text = (HERE / 'feed_promote_r20.py.in').read_text()
        self.assertLess(text.index('w.stable_feed(g) == old_identity'), text.index('need(rename('))
        self.assertIn('old_identity[name]', text)
        self.assertIn('w.same_pids(before, w.snapshot_services())', text)

    def test_critical_templates_do_not_use_optimization_removable_asserts(self):
        for name in ['origin_r20_tail.py.in', 'seal_r20.py.in', 'private_modes_r20.py.in', 'feed_promote_r20.py.in']:
            with self.subTest(template=name):
                tree = ast.parse((HERE / name).read_text())
                self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(tree)))
        # The real creator is a string literal in the generator, inspected without executing it.
        tree = ast.parse((HERE / 'prepare_origin_r20_s16.py').read_text())
        creator = next(node.value.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'create' for target in node.targets))
        self.assertFalse(any(isinstance(node, ast.Assert) for node in ast.walk(ast.parse(creator))))

    def test_seal_public_reuse_metadata_and_boundaries(self):
        class MetaPath(PurePosixPath):
            infos = {}
            def lstat(self):
                return self.infos.get(str(self), meta(st_mode=stat.S_IFDIR | 0o755))
        public = MetaPath('/srv/mir2-client-updates')
        user = MetaPath('/tmp/mir2-origin-r20-s16-20261007-01')
        MetaPath.infos[str(user)] = meta(st_mode=stat.S_IFDIR | 0o700, st_uid=1000)
        source = public / 'releases/unit/item.m2b'
        MetaPath.infos[str(source)] = meta(size=9)
        scope = dict(pathlib=SimpleNamespace(Path=MetaPath), stat=stat, PUBLIC=public, USER=user)
        tree = ast.parse((HERE / 'seal_r20.py.in').read_text())
        functions = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)], type_ignores=[])
        exec(compile(functions, '<UNIT-SEAL-FUNCTIONS>', 'exec'), scope)
        scope['user_identity'] = scope['ident'](MetaPath.infos[str(user)])
        row = dict(kind='public', source=str(source), name='UNIT-item.m2b', size=9, sha256='0' * 64)
        scope['source_info'](row)
        for changes in [dict(st_uid=1000), dict(st_nlink=2), dict(st_mode=stat.S_IFREG | 0o644),
                        dict(st_mode=stat.S_IFREG | 0o664), dict(st_mode=stat.S_IFLNK | 0o777), dict(st_size=10)]:
            MetaPath.infos[str(source)] = meta(size=9, **({k: v for k, v in changes.items() if k != 'st_size'}))
            if 'st_size' in changes:
                MetaPath.infos[str(source)].st_size = changes['st_size']
            with self.subTest(changes=changes), self.assertRaises(RuntimeError):
                scope['source_info'](row)
        with self.assertRaisesRegex(RuntimeError, 'reuse-source-boundary'):
            scope['source_info']({**row, 'source': '/etc/Caddyfile'})
        with self.assertRaisesRegex(RuntimeError, 'fixed-source-kind'):
            scope['source_info']({**row, 'kind': 'arbitrary'})

    def test_seal_user_source_stat_and_open_are_relative_to_held_directory_fd(self):
        class MetaPath(PurePosixPath):
            def lstat(self):
                if str(self) == '/tmp/mir2-origin-r20-s16-20261007-01':
                    return meta(st_mode=stat.S_IFDIR | 0o700, st_uid=1000)
                raise AssertionError('Unexpected absolute-path lookup of a user source')
        class Reader(io.BytesIO):
            def fileno(self): return 19
        class DescriptorOS:
            O_RDONLY, O_NOFOLLOW, O_CLOEXEC, O_NONBLOCK = 0, 131072, 524288, 2048
            def __init__(self): self.stats, self.opens = [], []
            def stat(self, name, *, dir_fd, follow_symlinks):
                self.stats.append((name, dir_fd, follow_symlinks))
                return meta(size=3, st_uid=1000, st_mode=stat.S_IFREG | 0o600)
            def open(self, name, flags, *, dir_fd):
                self.opens.append((name, flags, dir_fd))
                return 19
            def fdopen(self, fd, mode): return Reader(b'abc')
            def fstat(self, fd): return meta(size=3, st_uid=1000, st_mode=stat.S_IFREG | 0o600)
        filesystem = DescriptorOS()
        user = MetaPath('/tmp/mir2-origin-r20-s16-20261007-01')
        scope = dict(pathlib=SimpleNamespace(Path=MetaPath), stat=stat, os=filesystem, hashlib=hashlib,
                     PUBLIC=MetaPath('/srv/mir2-client-updates'), USER=user, userfd=17)
        tree = ast.parse((HERE / 'seal_r20.py.in').read_text())
        functions = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)], type_ignores=[])
        exec(compile(functions, '<UNIT-SEAL-DESCRIPTORS>', 'exec'), scope)
        scope['user_identity'] = scope['ident'](user.lstat())
        row = dict(kind='user', source=str(user / 'UNIT-input'), name='UNIT-input', size=3, sha256=gen.sha(b'abc'))
        scope['transfer'](row)
        self.assertEqual(filesystem.stats, [('UNIT-input', 17, False), ('UNIT-input', 17, False)])
        self.assertEqual(filesystem.opens[0][0], 'UNIT-input')
        self.assertEqual(filesystem.opens[0][2], 17)
        self.assertTrue(filesystem.opens[0][1] & filesystem.O_NOFOLLOW)
        filesystem.fstat = lambda fd: meta(size=3, st_uid=1000, st_mode=stat.S_IFREG | 0o600, st_ino=999)
        with self.assertRaisesRegex(RuntimeError, 'source-open-race'):
            scope['transfer'](row)


if __name__ == '__main__':
    unittest.main(verbosity=2)
