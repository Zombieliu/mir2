sudo -n python3 - <<'PY'
import hashlib,json,subprocess,os,stat
from pathlib import Path
p=Path('/srv/mir2-client-updates/feed-current')
result={'schema':'mir2.r20.origin-readonly-probe.v1','uid':os.geteuid(),'feeds':{},'services':{},'changedFiles':False}
for name in ('latest.json','latest.p7s'):
 path=p/name
 for ancestor in [*reversed(path.parents),path]:
  s=ancestor.lstat()
  assert not stat.S_ISLNK(s.st_mode)
 raw=path.read_bytes();result['feeds'][name]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if name=='latest.json':
  f=json.loads(raw);result['sequence']=f['sequence'];result['game']=f['game']['identity']
result['caddySha256']=hashlib.sha256(Path('/etc/caddy/Caddyfile').read_bytes()).hexdigest()
for name in ('caddy.service','mir2-gateway.service','mir2-playtest.service','mir2-periodic-qa.service','mir2-commonware-gateway.service','mir2-admin-api.service','mir2-zone-ucloud.service'):
 r=subprocess.run(['systemctl','show',name,'--property=MainPID,ActiveState'],capture_output=True,text=True,check=True)
 result['services'][name]=dict(x.split('=',1) for x in r.stdout.splitlines() if '=' in x)
print(json.dumps(result,sort_keys=True))
PY
