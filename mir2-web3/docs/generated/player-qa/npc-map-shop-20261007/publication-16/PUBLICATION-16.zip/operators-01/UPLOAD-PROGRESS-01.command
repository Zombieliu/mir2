python3 -B - <<'PY'
import json,pathlib,stat
p=pathlib.Path('/tmp/mir2-origin-r20-s16-20261007-01')
s=p.lstat()
if not stat.S_ISDIR(s.st_mode) or s.st_uid!=1000 or stat.S_IMODE(s.st_mode)!=0o700:
    raise RuntimeError('fixed private upload directory required')
items=[x.lstat() for x in p.iterdir()]
if not all(stat.S_ISREG(x.st_mode) and x.st_uid==1000 and x.st_nlink==1 for x in items):
    raise RuntimeError('ordinary upload files required')
print(json.dumps({'filesPresent':len(items),'bytesPresent':sum(x.st_size for x in items),'expectedFiles':29,'expectedBytes':719991774,'readOnly':True}))
PY
