sudo -n python3 -B - <<'PY'
import pathlib
USER = pathlib.Path('/tmp/mir2-origin-r20-s16-20261007-01')
ROOT = pathlib.Path('/srv/.mir2-origin-r20-s16-20261007-01')
PUBLIC = pathlib.Path('/srv/mir2-client-updates')
ROWS = [{'kind': 'user',
  'name': 'APPEND-INPUTS.prepared.json',
  'sha256': 'de03044efe062b8081502a3976147f40c2e67eef49b8c27ff7a1b48eecbf3c18',
  'size': 16098,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/APPEND-INPUTS.prepared.json'},
 {'kind': 'user',
  'name': 'ROOT-VERIFICATION.json',
  'sha256': '6a59813e8e3451820a064e1ff1c9f7525f77e0aab6ed85ffa791c8679c3192e8',
  'size': 424,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/ROOT-VERIFICATION.json'},
 {'kind': 'user',
  'name': 'PUBLICATION-PLAN.json',
  'sha256': '905bc48ea9a210d5cb8ef5d82f748b341d9654cf287f1c3803ce74a1a7ae556d',
  'size': 16251,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/PUBLICATION-PLAN.json'},
 {'kind': 'user',
  'name': 'PREVIOUS-ROOT-VERIFICATION.json',
  'sha256': '099702223680a43d63fb500740763e8b8f67442c6fcd414b6d5f178293d7d7a3',
  'size': 424,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/PREVIOUS-ROOT-VERIFICATION.json'},
 {'kind': 'user',
  'name': 'PREVIOUS-PUBLICATION-PLAN.json',
  'sha256': '852b474af0f9c7a5512b1ea1b3d9d2c957cc512dec95e366b8907052641c2356',
  'size': 15343,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/PREVIOUS-PUBLICATION-PLAN.json'},
 {'kind': 'user',
  'name': 'guards.py',
  'sha256': '10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811',
  'size': 47951,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/guards.py'},
 {'kind': 'user',
  'name': 'origin_r20_s16.py',
  'sha256': '11378641e6497feaa2c9687f1ce1da14e45408f9a5137d1af40f4d865c3b8fb3',
  'size': 40297,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/origin_r20_s16.py'},
 {'kind': 'user',
  'name': '00-latest.json',
  'sha256': 'fd8109231f6077405c410047fab94ea1a5797e9963e81fd9a80a0cb86cf95dca',
  'size': 1159,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/00-latest.json'},
 {'kind': 'user',
  'name': '01-latest.p7s',
  'sha256': '1f881c23724b892ab9814eb2eb9002a365df159a7220bb5316538a0ea181a5c7',
  'size': 1614,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/01-latest.p7s'},
 {'kind': 'public',
  'name': '02-Mir2Setup.exe',
  'sha256': 'ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03',
  'size': 29245069,
  'source': '/srv/mir2-client-updates/installers/ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03/Mir2Setup.exe'},
 {'kind': 'user',
  'name': '03-BUILD-ATTESTATION.json',
  'sha256': '4d3593f85c529640b8aa7a3935a1999c24410a1c671ee250eaeb9b71d14a8182',
  'size': 1493,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/03-BUILD-ATTESTATION.json'},
 {'kind': 'public',
  'name': '04-CONTROLS.txt',
  'sha256': 'b9ad2a5a01b3ecbe673a3d38b1974b38492d3a62a0e28932eb8367ce19ebf7c6',
  'size': 10612,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/CONTROLS.txt'},
 {'kind': 'user',
  'name': '05-DELIVERY.json',
  'sha256': '679889dcce106251c5530546f714352dc6d8b03543a3da748d9311b176b0fce2',
  'size': 10560559,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/05-DELIVERY.json'},
 {'kind': 'user',
  'name': '06-DELIVERY.p7s',
  'sha256': 'cf4184d9a41537f484441f9316efbd68708cdf57f860c1d937aea4e4e34c6a00',
  'size': 1614,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/06-DELIVERY.p7s'},
 {'kind': 'public',
  'name': '07-KNOWN-ISSUES.md',
  'sha256': 'd2a2ffca1d2170ee0a0f2e3d3fdf0eff644f2fe4472c5ba7e6120ce12c4eadc9',
  'size': 2152,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/KNOWN-ISSUES.md'},
 {'kind': 'public',
  'name': '08-MULTILINGUAL-SOURCES.json',
  'sha256': '1528b614dedb07860e22ac2e1cf62528b0ed126230657dc008fb88d2f01f6d11',
  'size': 8618,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/MULTILINGUAL-SOURCES.json'},
 {'kind': 'public',
  'name': '09-NotoSansTC-OFL.txt',
  'sha256': 'e35ffdebb2225b49814c31889cbb3ce69cb3509e6a9f431edaba5e1a6de8cd15',
  'size': 4481,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/NotoSansTC-OFL.txt'},
 {'kind': 'public',
  'name': '10-OFL-NotoSans.txt',
  'sha256': 'cee9892f9f0cc8fe882c9e9537ee6a89621d86ee7ceaf70b02e2b2b1c25c061a',
  'size': 4396,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSans.txt'},
 {'kind': 'public',
  'name': '11-OFL-NotoSansArabic.txt',
  'sha256': 'a7a5a25eb188bf1cd96982030d53e23c33485c69b1044a562254226857ee13af',
  'size': 4382,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansArabic.txt'},
 {'kind': 'public',
  'name': '12-OFL-NotoSansDevanagari.txt',
  'sha256': 'a216f6f8d85c7228093e0ee5e258d9d377e6671f68acb4db1930b29583d0f331',
  'size': 4386,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansDevanagari.txt'},
 {'kind': 'public',
  'name': '13-OFL-NotoSansThai.txt',
  'sha256': 'dad6e6abc2bf3fc37cc698af7607c3f4d4235039695713b222e5a034fb5b9b1c',
  'size': 4380,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansThai.txt'},
 {'kind': 'user',
  'name': '14-PACKAGE-MANIFEST.json',
  'sha256': 'df3fbe3bb4cc44429b8bdeaae4549313878092f8896311c7d84c00d30795b155',
  'size': 31537753,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/14-PACKAGE-MANIFEST.json'},
 {'kind': 'user',
  'name': '15-README-START.txt',
  'sha256': 'e50595fbc3b973df130d7824d7fb7f91b3b0a46abcf9d2d1888831c065b8902b',
  'size': 49328,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/15-README-START.txt'},
 {'kind': 'user',
  'name': '16-RELEASE-STATEMENT.json',
  'sha256': '305543a68c651560b484ece5bdc44bed67e4985fe9930e75acf478507baecc84',
  'size': 707,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/16-RELEASE-STATEMENT.json'},
 {'kind': 'user',
  'name': '17-RELEASE-STATEMENT.p7s',
  'sha256': '5ad7aced2fdaba635579b1082b8d42ed81d66f80b15c0d371550d04601f94528',
  'size': 1614,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/17-RELEASE-STATEMENT.p7s'},
 {'kind': 'user',
  'name': '18-VERSION.json',
  'sha256': 'f36dfd9df5b1206f173cfd78aea8262bf88c39e8e346e33367982f62ea40b0e6',
  'size': 1221,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/18-VERSION.json'},
 {'kind': 'user',
  'name': '19-04cd5f15be5159deced5c78129ec8b3c22de13a0fe48492221b0503fd3f3f02a.m2b.gz',
  'sha256': '04cd5f15be5159deced5c78129ec8b3c22de13a0fe48492221b0503fd3f3f02a',
  'size': 63808945,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/19-04cd5f15be5159deced5c78129ec8b3c22de13a0fe48492221b0503fd3f3f02a.m2b.gz'},
 {'kind': 'user',
  'name': '20-07cf86715d833385727589d019dc675860788121749fae2286fe396931109df4.m2d.gz',
  'sha256': '07cf86715d833385727589d019dc675860788121749fae2286fe396931109df4',
  'size': 25562191,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/20-07cf86715d833385727589d019dc675860788121749fae2286fe396931109df4.m2d.gz'},
 {'kind': 'user',
  'name': '21-0c05437ef097c20d60afa63860ecebb023ffb8edbb64ec7015ed90ed2ed59823.m2b.gz',
  'sha256': '0c05437ef097c20d60afa63860ecebb023ffb8edbb64ec7015ed90ed2ed59823',
  'size': 65614809,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/21-0c05437ef097c20d60afa63860ecebb023ffb8edbb64ec7015ed90ed2ed59823.m2b.gz'},
 {'kind': 'user',
  'name': '22-13deda5f6adde99888d88173e70aabfec6497e02ff88f8872d61c1a17bfb3b7d.m2b.gz',
  'sha256': '13deda5f6adde99888d88173e70aabfec6497e02ff88f8872d61c1a17bfb3b7d',
  'size': 55866222,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/22-13deda5f6adde99888d88173e70aabfec6497e02ff88f8872d61c1a17bfb3b7d.m2b.gz'},
 {'kind': 'user',
  'name': '23-3503b719be52717502245782a015acbb7c4aac242e621de21d23b5a3952868ea.m2b.gz',
  'sha256': '3503b719be52717502245782a015acbb7c4aac242e621de21d23b5a3952868ea',
  'size': 60714132,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/23-3503b719be52717502245782a015acbb7c4aac242e621de21d23b5a3952868ea.m2b.gz'},
 {'kind': 'user',
  'name': '24-35b07f1c78b26f75b14d8bf73b5bddd1fbf88d372e7c65a011a1a0c27c97e9ea.m2b.gz',
  'sha256': '35b07f1c78b26f75b14d8bf73b5bddd1fbf88d372e7c65a011a1a0c27c97e9ea',
  'size': 65602834,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/24-35b07f1c78b26f75b14d8bf73b5bddd1fbf88d372e7c65a011a1a0c27c97e9ea.m2b.gz'},
 {'kind': 'user',
  'name': '25-405448ce67bf1f723b57027d3f2348a53d76657090de5c631739b35c18eb1483.m2b.gz',
  'sha256': '405448ce67bf1f723b57027d3f2348a53d76657090de5c631739b35c18eb1483',
  'size': 55151705,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/25-405448ce67bf1f723b57027d3f2348a53d76657090de5c631739b35c18eb1483.m2b.gz'},
 {'kind': 'public',
  'name': '26-565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2.m2b.gz',
  'sha256': '565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2',
  'size': 66861961,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2.m2b.gz'},
 {'kind': 'user',
  'name': '27-5bb7e634a19b633d8aca5a7949340a9fc326d1b5afed2a16810b4938e832734c.m2b.gz',
  'sha256': '5bb7e634a19b633d8aca5a7949340a9fc326d1b5afed2a16810b4938e832734c',
  'size': 65547038,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/27-5bb7e634a19b633d8aca5a7949340a9fc326d1b5afed2a16810b4938e832734c.m2b.gz'},
 {'kind': 'public',
  'name': '28-5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd.m2b.gz',
  'sha256': '5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd',
  'size': 12699131,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd.m2b.gz'},
 {'kind': 'public',
  'name': '29-6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4.m2b.gz',
  'sha256': '6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4',
  'size': 60049219,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4.m2b.gz'},
 {'kind': 'public',
  'name': '30-84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7.m2b.gz',
  'sha256': '84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7',
  'size': 66910012,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7.m2b.gz'},
 {'kind': 'user',
  'name': '31-a58dca90e66a5f9b94aa8930dd444712e760dd4ed3e53acd5c9dbcbf527e7bc7.m2b.gz',
  'sha256': 'a58dca90e66a5f9b94aa8930dd444712e760dd4ed3e53acd5c9dbcbf527e7bc7',
  'size': 46858151,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/31-a58dca90e66a5f9b94aa8930dd444712e760dd4ed3e53acd5c9dbcbf527e7bc7.m2b.gz'},
 {'kind': 'user',
  'name': '32-b405e78cb5ff43098bb3edb1670c367689d96cecc45c0a49c34bafc5b1bd1130.m2d.gz',
  'sha256': 'b405e78cb5ff43098bb3edb1670c367689d96cecc45c0a49c34bafc5b1bd1130',
  'size': 25493950,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/32-b405e78cb5ff43098bb3edb1670c367689d96cecc45c0a49c34bafc5b1bd1130.m2d.gz'},
 {'kind': 'user',
  'name': '33-b5f92dd2703b567d7a8dc76124301fb1b39214fc143a8e1431da07d77d553f06.m2b.gz',
  'sha256': 'b5f92dd2703b567d7a8dc76124301fb1b39214fc143a8e1431da07d77d553f06',
  'size': 36317627,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/33-b5f92dd2703b567d7a8dc76124301fb1b39214fc143a8e1431da07d77d553f06.m2b.gz'},
 {'kind': 'public',
  'name': '34-ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe.m2b.gz',
  'sha256': 'ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe',
  'size': 59737743,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe.m2b.gz'},
 {'kind': 'public',
  'name': '35-e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9.m2b.gz',
  'sha256': 'e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9',
  'size': 60049370,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9.m2b.gz'},
 {'kind': 'public',
  'name': '36-mir2-client.toml',
  'sha256': '58a5a7cf2ed6e880a7a7f259243dd9ab96150fc43e1a346e6fc79b8de6ee3641',
  'size': 231,
  'source': '/srv/mir2-client-updates/releases/game-WN-CANDIDATE-20261007-invited-19/mir2-client.toml'},
 {'kind': 'user',
  'name': '37-mir2-platform-windows.exe',
  'sha256': 'e227a68c10042e6f7d7264b2f91a8f252a1b73d5aad4fb6fa92fad3e11d04fcb',
  'size': 111160320,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/37-mir2-platform-windows.exe'},
 {'kind': 'public',
  'name': '38-ENGINE.json',
  'sha256': '82fed6853aed2ed3d8c8c7520b9d4b84aacd4ac2723c2e47506eb4d001cb99b0',
  'size': 421,
  'source': '/srv/mir2-client-updates/releases/updater-9213EC3FE1A992F7-s15/ENGINE.json'},
 {'kind': 'public',
  'name': '39-ENGINE.p7s',
  'sha256': 'c19efee65316762e459ae48afc6123184e4c66defcb33f274fec046c66908a2b',
  'size': 1614,
  'source': '/srv/mir2-client-updates/releases/updater-9213EC3FE1A992F7-s15/ENGINE.p7s'},
 {'kind': 'public',
  'name': '40-Mir2Updater.exe',
  'sha256': '9213ec3fe1a992f757ea48c53981afa661765b42e637c1ad811e326060b170b8',
  'size': 1952256,
  'source': '/srv/mir2-client-updates/releases/updater-9213EC3FE1A992F7-s15/Mir2Updater.exe'}]
# Literal frozen inputs below are emitted only after actual proof/plan validation.
import hashlib, json, os, pathlib, stat, sys


def need(condition, label):
    if not condition:
        raise RuntimeError(label)


def ident(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def root_parents(path):
    for parent in [*reversed(path.parent.parents), path.parent]:
        i = parent.lstat()
        need(stat.S_ISDIR(i.st_mode) and i.st_uid == 0 and not i.st_mode & 0o022, 'unsafe-root-parent')


def source_info(row):
    need(row['kind'] in ('public', 'user'), 'fixed-source-kind')
    path = pathlib.Path(row['source'])
    if row['kind'] == 'public':
        need(path.is_relative_to(PUBLIC) and '..' not in path.parts, 'reuse-source-boundary')
        root_parents(path)
    else:
        need(path.parent == USER and path.name == row['name'], 'upload-source-boundary')
        need(ident(USER.lstat()) == user_identity, 'user-directory-changed')
    info = (os.stat(row['name'], dir_fd=userfd, follow_symlinks=False)
            if row['kind'] == 'user' else path.lstat())
    need(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_uid == (0 if row['kind'] == 'public' else 1000)
         and not info.st_mode & 0o022 and info.st_size == row['size'], 'unsafe-source-file')
    if row['kind'] == 'user':
        need(stat.S_IMODE(info.st_mode) == 0o600, 'private-upload-mode-required')
    else:
        need(stat.S_IMODE(info.st_mode) == 0o444, 'immutable-public-reuse-source-required')
    return path, info


def transfer(row, rootfd=None):
    path, info = source_info(row)
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
    fd = (os.open(row['name'], flags, dir_fd=userfd)
          if row['kind'] == 'user' else os.open(path, flags))
    with os.fdopen(fd, 'rb') as reader:
        need(ident(os.fstat(reader.fileno())) == ident(info), 'source-open-race')
        writer = None
        if rootfd is not None:
            dest = os.open(row['name'], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                           0o600, dir_fd=rootfd)
            writer = os.fdopen(dest, 'wb')
        try:
            count, h = 0, hashlib.sha256()
            while chunk := reader.read(1024 * 1024):
                count += len(chunk)
                need(count <= row['size'], 'source-overrun')
                h.update(chunk)
                if writer is not None:
                    writer.write(chunk)
            need(count == row['size'] and h.hexdigest() == row['sha256'], 'source-pin:' + row['name'])
            current_info = (os.stat(row['name'], dir_fd=userfd, follow_symlinks=False)
                            if row['kind'] == 'user' else path.lstat())
            need(ident(os.fstat(reader.fileno())) == ident(info) and ident(current_info) == ident(info), 'source-read-race')
            if writer is not None:
                writer.flush()
                os.fsync(writer.fileno())
                sealed = os.fstat(writer.fileno())
                need(stat.S_ISREG(sealed.st_mode) and sealed.st_uid == 0 and sealed.st_nlink == 1 and
                     stat.S_IMODE(sealed.st_mode) == 0o600 and sealed.st_size == row['size'], 'sealed-file-metadata')
                need(ident(os.stat(row['name'], dir_fd=rootfd, follow_symlinks=False)) == ident(sealed), 'sealed-file-race')
        finally:
            if writer is not None:
                writer.close()


need(sys.platform.startswith('linux') and os.geteuid() == 0, 'linux-root-required')
need(str(USER) == '/tmp/mir2-origin-r20-s16-20261007-01' and str(ROOT) == '/srv/.mir2-origin-r20-s16-20261007-01'
     and str(PUBLIC) == '/srv/mir2-client-updates', 'fixed-boundaries')
tmp = USER.parent.lstat()
need(stat.S_ISDIR(tmp.st_mode) and tmp.st_uid == 0, 'unsafe-tmp-parent')
root_parents(PUBLIC)
public_before = PUBLIC.lstat()
need(stat.S_ISDIR(public_before.st_mode) and public_before.st_uid == 0 and not public_before.st_mode & 0o022,
     'unsafe-public-root')
user_before = USER.lstat()
need(stat.S_ISDIR(user_before.st_mode) and user_before.st_uid == 1000 and stat.S_IMODE(user_before.st_mode) == 0o700,
     'private-user-directory-required')
user_identity = ident(user_before)
userfd = os.open(USER, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
try:
    need(ident(os.fstat(userfd)) == user_identity, 'user-directory-open-race')
    need(set(os.listdir(userfd)) == {r['name'] for r in ROWS if r['kind'] == 'user'}, 'closed-upload-input-set')
    need(len(ROWS) == len({r['name'] for r in ROWS}), 'duplicate-seal-name')
    for row in ROWS:
        need(pathlib.Path(row['name']).name == row['name'] and row['name'] not in ('.', '..'), 'unsafe-seal-name')
        transfer(row)  # All inputs are verified before creating the root stage.
    root_parents(ROOT)
    need(not ROOT.exists() and not ROOT.is_symlink(), 'fresh-root-stage-required')
    ROOT.mkdir(mode=0o700)
    root_before = ROOT.lstat()
    need(stat.S_ISDIR(root_before.st_mode) and root_before.st_uid == 0 and stat.S_IMODE(root_before.st_mode) == 0o700,
         'private-root-directory-required')
    rootfd = os.open(ROOT, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        need(ident(os.fstat(rootfd)) == ident(root_before), 'root-directory-open-race')
        current_public = PUBLIC.lstat()
        need(stat.S_ISDIR(current_public.st_mode) and current_public.st_uid == 0 and not current_public.st_mode & 0o022
             and current_public.st_dev == public_before.st_dev and current_public.st_ino == public_before.st_ino,
             'public-root-changed')
        need(root_before.st_dev == current_public.st_dev, 'stage-filesystem-mismatch')
        for row in ROWS:
            transfer(row, rootfd)  # Copies bytes; never links or renames public sources.
        need(set(os.listdir(rootfd)) == {r['name'] for r in ROWS}, 'closed-root-input-set')
        need(set(os.listdir(userfd)) == {r['name'] for r in ROWS if r['kind'] == 'user'}, 'closed-upload-input-set-changed')
        need(ident(USER.lstat()) == user_identity and ident(os.fstat(userfd)) == user_identity, 'user-stage-changed')
        os.fsync(rootfd)
        parentfd = os.open(ROOT.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            os.fsync(parentfd)
        finally:
            os.close(parentfd)
    finally:
        os.close(rootfd)
finally:
    os.close(userfd)
print(json.dumps({'schema': 'mir2.origin.r20.fixed-inputs-sealed.v1', 'passed': True, 'files': len(ROWS),
                  'reusedPublicFiles': sum(r['kind'] == 'public' for r in ROWS),
                  'reusedPublicBytes': sum(r['size'] for r in ROWS if r['kind'] == 'public'),
                  'hardlinksCreated': False, 'publicMutations': False, 'gatewayRestarted': False}))

PY
