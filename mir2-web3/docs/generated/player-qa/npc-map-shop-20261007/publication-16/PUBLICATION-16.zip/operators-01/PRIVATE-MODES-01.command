python3 -B - <<'PY'
ROWS = [{'kind': 'user',
  'name': 'APPEND-INPUTS.prepared.json',
  'sha256': 'de03044efe062b8081502a3976147f40c2e67eef49b8c27ff7a1b48eecbf3c18',
  'size': 16098,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/APPEND-INPUTS.prepared.json'},
 {'kind': 'user',
  'name': 'ROOT-VERIFICATION.json',
  'sha256': '6a59813e8e3451820a064e1ff1c9f7525f77e0aab6ed85ffa791c8679c3192e8',
  'size': 424,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/ROOT-VERIFICATION.json'},
 {'kind': 'user',
  'name': 'PUBLICATION-PLAN.json',
  'sha256': '905bc48ea9a210d5cb8ef5d82f748b341d9654cf287f1c3803ce74a1a7ae556d',
  'size': 16251,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/PUBLICATION-PLAN.json'},
 {'kind': 'user',
  'name': 'PREVIOUS-ROOT-VERIFICATION.json',
  'sha256': '099702223680a43d63fb500740763e8b8f67442c6fcd414b6d5f178293d7d7a3',
  'size': 424,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/PREVIOUS-ROOT-VERIFICATION.json'},
 {'kind': 'user',
  'name': 'PREVIOUS-PUBLICATION-PLAN.json',
  'sha256': '852b474af0f9c7a5512b1ea1b3d9d2c957cc512dec95e366b8907052641c2356',
  'size': 15343,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/PREVIOUS-PUBLICATION-PLAN.json'},
 {'kind': 'user',
  'name': 'guards.py',
  'sha256': '10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811',
  'size': 47951,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/guards.py'},
 {'kind': 'user',
  'name': 'origin_r20_s16.py',
  'sha256': '11378641e6497feaa2c9687f1ce1da14e45408f9a5137d1af40f4d865c3b8fb3',
  'size': 40297,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/origin_r20_s16.py'},
 {'kind': 'user',
  'name': '00-latest.json',
  'sha256': 'fd8109231f6077405c410047fab94ea1a5797e9963e81fd9a80a0cb86cf95dca',
  'size': 1159,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/00-latest.json'},
 {'kind': 'user',
  'name': '01-latest.p7s',
  'sha256': '1f881c23724b892ab9814eb2eb9002a365df159a7220bb5316538a0ea181a5c7',
  'size': 1614,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/01-latest.p7s'},
 {'kind': 'user',
  'name': '03-BUILD-ATTESTATION.json',
  'sha256': '4d3593f85c529640b8aa7a3935a1999c24410a1c671ee250eaeb9b71d14a8182',
  'size': 1493,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/03-BUILD-ATTESTATION.json'},
 {'kind': 'user',
  'name': '05-DELIVERY.json',
  'sha256': '679889dcce106251c5530546f714352dc6d8b03543a3da748d9311b176b0fce2',
  'size': 10560559,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/05-DELIVERY.json'},
 {'kind': 'user',
  'name': '06-DELIVERY.p7s',
  'sha256': 'cf4184d9a41537f484441f9316efbd68708cdf57f860c1d937aea4e4e34c6a00',
  'size': 1614,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/06-DELIVERY.p7s'},
 {'kind': 'user',
  'name': '14-PACKAGE-MANIFEST.json',
  'sha256': 'df3fbe3bb4cc44429b8bdeaae4549313878092f8896311c7d84c00d30795b155',
  'size': 31537753,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/14-PACKAGE-MANIFEST.json'},
 {'kind': 'user',
  'name': '15-README-START.txt',
  'sha256': 'e50595fbc3b973df130d7824d7fb7f91b3b0a46abcf9d2d1888831c065b8902b',
  'size': 49328,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/15-README-START.txt'},
 {'kind': 'user',
  'name': '16-RELEASE-STATEMENT.json',
  'sha256': '305543a68c651560b484ece5bdc44bed67e4985fe9930e75acf478507baecc84',
  'size': 707,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/16-RELEASE-STATEMENT.json'},
 {'kind': 'user',
  'name': '17-RELEASE-STATEMENT.p7s',
  'sha256': '5ad7aced2fdaba635579b1082b8d42ed81d66f80b15c0d371550d04601f94528',
  'size': 1614,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/17-RELEASE-STATEMENT.p7s'},
 {'kind': 'user',
  'name': '18-VERSION.json',
  'sha256': 'f36dfd9df5b1206f173cfd78aea8262bf88c39e8e346e33367982f62ea40b0e6',
  'size': 1221,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/18-VERSION.json'},
 {'kind': 'user',
  'name': '19-04cd5f15be5159deced5c78129ec8b3c22de13a0fe48492221b0503fd3f3f02a.m2b.gz',
  'sha256': '04cd5f15be5159deced5c78129ec8b3c22de13a0fe48492221b0503fd3f3f02a',
  'size': 63808945,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/19-04cd5f15be5159deced5c78129ec8b3c22de13a0fe48492221b0503fd3f3f02a.m2b.gz'},
 {'kind': 'user',
  'name': '20-07cf86715d833385727589d019dc675860788121749fae2286fe396931109df4.m2d.gz',
  'sha256': '07cf86715d833385727589d019dc675860788121749fae2286fe396931109df4',
  'size': 25562191,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/20-07cf86715d833385727589d019dc675860788121749fae2286fe396931109df4.m2d.gz'},
 {'kind': 'user',
  'name': '21-0c05437ef097c20d60afa63860ecebb023ffb8edbb64ec7015ed90ed2ed59823.m2b.gz',
  'sha256': '0c05437ef097c20d60afa63860ecebb023ffb8edbb64ec7015ed90ed2ed59823',
  'size': 65614809,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/21-0c05437ef097c20d60afa63860ecebb023ffb8edbb64ec7015ed90ed2ed59823.m2b.gz'},
 {'kind': 'user',
  'name': '22-13deda5f6adde99888d88173e70aabfec6497e02ff88f8872d61c1a17bfb3b7d.m2b.gz',
  'sha256': '13deda5f6adde99888d88173e70aabfec6497e02ff88f8872d61c1a17bfb3b7d',
  'size': 55866222,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/22-13deda5f6adde99888d88173e70aabfec6497e02ff88f8872d61c1a17bfb3b7d.m2b.gz'},
 {'kind': 'user',
  'name': '23-3503b719be52717502245782a015acbb7c4aac242e621de21d23b5a3952868ea.m2b.gz',
  'sha256': '3503b719be52717502245782a015acbb7c4aac242e621de21d23b5a3952868ea',
  'size': 60714132,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/23-3503b719be52717502245782a015acbb7c4aac242e621de21d23b5a3952868ea.m2b.gz'},
 {'kind': 'user',
  'name': '24-35b07f1c78b26f75b14d8bf73b5bddd1fbf88d372e7c65a011a1a0c27c97e9ea.m2b.gz',
  'sha256': '35b07f1c78b26f75b14d8bf73b5bddd1fbf88d372e7c65a011a1a0c27c97e9ea',
  'size': 65602834,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/24-35b07f1c78b26f75b14d8bf73b5bddd1fbf88d372e7c65a011a1a0c27c97e9ea.m2b.gz'},
 {'kind': 'user',
  'name': '25-405448ce67bf1f723b57027d3f2348a53d76657090de5c631739b35c18eb1483.m2b.gz',
  'sha256': '405448ce67bf1f723b57027d3f2348a53d76657090de5c631739b35c18eb1483',
  'size': 55151705,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/25-405448ce67bf1f723b57027d3f2348a53d76657090de5c631739b35c18eb1483.m2b.gz'},
 {'kind': 'user',
  'name': '27-5bb7e634a19b633d8aca5a7949340a9fc326d1b5afed2a16810b4938e832734c.m2b.gz',
  'sha256': '5bb7e634a19b633d8aca5a7949340a9fc326d1b5afed2a16810b4938e832734c',
  'size': 65547038,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/27-5bb7e634a19b633d8aca5a7949340a9fc326d1b5afed2a16810b4938e832734c.m2b.gz'},
 {'kind': 'user',
  'name': '31-a58dca90e66a5f9b94aa8930dd444712e760dd4ed3e53acd5c9dbcbf527e7bc7.m2b.gz',
  'sha256': 'a58dca90e66a5f9b94aa8930dd444712e760dd4ed3e53acd5c9dbcbf527e7bc7',
  'size': 46858151,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/31-a58dca90e66a5f9b94aa8930dd444712e760dd4ed3e53acd5c9dbcbf527e7bc7.m2b.gz'},
 {'kind': 'user',
  'name': '32-b405e78cb5ff43098bb3edb1670c367689d96cecc45c0a49c34bafc5b1bd1130.m2d.gz',
  'sha256': 'b405e78cb5ff43098bb3edb1670c367689d96cecc45c0a49c34bafc5b1bd1130',
  'size': 25493950,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/32-b405e78cb5ff43098bb3edb1670c367689d96cecc45c0a49c34bafc5b1bd1130.m2d.gz'},
 {'kind': 'user',
  'name': '33-b5f92dd2703b567d7a8dc76124301fb1b39214fc143a8e1431da07d77d553f06.m2b.gz',
  'sha256': 'b5f92dd2703b567d7a8dc76124301fb1b39214fc143a8e1431da07d77d553f06',
  'size': 36317627,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/33-b5f92dd2703b567d7a8dc76124301fb1b39214fc143a8e1431da07d77d553f06.m2b.gz'},
 {'kind': 'user',
  'name': '37-mir2-platform-windows.exe',
  'sha256': 'e227a68c10042e6f7d7264b2f91a8f252a1b73d5aad4fb6fa92fad3e11d04fcb',
  'size': 111160320,
  'source': '/tmp/mir2-origin-r20-s16-20261007-01/37-mir2-platform-windows.exe'}]
import hashlib, json, os, pathlib, stat


def need(condition, label):
    if not condition:
        raise RuntimeError(label)


def ident(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


user = pathlib.Path('/tmp/mir2-origin-r20-s16-20261007-01')
need(os.geteuid() == 1000, 'fixed-upload-owner-required')
info = user.lstat()
need(stat.S_ISDIR(info.st_mode) and info.st_uid == 1000 and stat.S_IMODE(info.st_mode) == 0o700, 'private-user-stage-required')
fd = os.open(user, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
try:
    need(ident(os.fstat(fd)) == ident(info), 'user-stage-open-race')
    need(set(os.listdir(fd)) == {r['name'] for r in ROWS}, 'closed-user-input-set')
    for row in ROWS:
        name = row['name']
        need(pathlib.Path(name).name == name and name not in ('.', '..'), 'unsafe-input-name')
        before = os.stat(name, dir_fd=fd, follow_symlinks=False)
        need(stat.S_ISREG(before.st_mode) and before.st_uid == 1000 and before.st_nlink == 1 and
             stat.S_IMODE(before.st_mode) in (0o664, 0o644, 0o600) and before.st_size == row['size'], 'unsafe-upload-input')
        f = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK, dir_fd=fd)
        with os.fdopen(f, 'rb') as stream:
            need(ident(os.fstat(stream.fileno())) == ident(before), 'upload-open-race')
            count, h = 0, hashlib.sha256()
            while chunk := stream.read(1024 * 1024):
                count += len(chunk)
                need(count <= row['size'], 'upload-overrun')
                h.update(chunk)
            need(count == row['size'] and h.hexdigest() == row['sha256'], 'upload-content-pin')
            need(ident(os.fstat(stream.fileno())) == ident(before) and
                 ident(os.stat(name, dir_fd=fd, follow_symlinks=False)) == ident(before), 'upload-read-race')
            os.fchmod(stream.fileno(), 0o600)
            after = os.fstat(stream.fileno())
            need(stat.S_IMODE(after.st_mode) == 0o600 and after.st_uid == 1000 and after.st_size == before.st_size
                 and after.st_ino == before.st_ino and after.st_dev == before.st_dev and after.st_nlink == 1
                 and after.st_mtime_ns == before.st_mtime_ns, 'private-mode-result')
            need(ident(os.stat(name, dir_fd=fd, follow_symlinks=False)) == ident(after), 'private-mode-path-race')
    need(ident(os.fstat(fd)) == ident(info) and ident(user.lstat()) == ident(info), 'user-stage-changed')
    need(set(os.listdir(fd)) == {r['name'] for r in ROWS}, 'user-stage-inputs-changed')
finally:
    os.close(fd)
print(json.dumps({'schema': 'mir2.origin.r20.private-input-modes.v1', 'passed': True, 'files': len(ROWS),
                  'mode': '0600', 'contentPinsVerified': True, 'publicMutations': False}))

PY
