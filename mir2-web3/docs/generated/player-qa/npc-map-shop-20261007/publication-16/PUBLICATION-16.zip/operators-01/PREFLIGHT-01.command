sudo -n python3 -B /srv/.mir2-origin-r20-s16-20261007-01/origin_r20_s16.py preflight
