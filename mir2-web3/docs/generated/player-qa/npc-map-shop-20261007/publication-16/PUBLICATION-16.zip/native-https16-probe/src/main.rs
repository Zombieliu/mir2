use anyhow::{ensure, Context, Result};
use mir2_windows_updater::{model::hash, platform, update::{HttpsSource, Source}, CDN_FEED_URL, SIGNING_KEY};
use serde_json::json;
use std::{fs, io::Read, path::PathBuf, time::Duration};

fn get(agent: &ureq::Agent, path: &str, size: usize, pin: &str, dir: &PathBuf) -> Result<Vec<u8>> {
    let url = format!("https://assets.mir2.obelisk.build/client-updates/{path}");
    let r = agent.get(&url).set("Accept-Encoding", "identity").call()?;
    ensure!(r.status() == 200, "status");
    ensure!(r.header("Content-Encoding").is_none(), "encoding");
    if path.starts_with("latest.") { ensure!(r.header("X-Mir2-Sequence") == Some("16"), "actual CDN sequence"); }
    let headers = json!({"status":r.status(),"sequence":r.header("X-Mir2-Sequence"),"cache":r.header("X-Mir2-Native-Cache"),"cfRay":r.header("CF-Ray"),"etag":r.header("ETag"),"contentLength":r.header("Content-Length"),"cacheControl":r.header("Cache-Control")});
    let mut bytes = Vec::new();
    r.into_reader().take(size as u64 + 1).read_to_end(&mut bytes)?;
    ensure!(bytes.len() == size && hash(&bytes).eq_ignore_ascii_case(pin), "size/SHA");
    let name = path.rsplit('/').next().context("filename")?;
    fs::write(dir.join(name), &bytes)?;
    fs::write(dir.join(format!("{name}.headers.json")), serde_json::to_vec_pretty(&headers)?)?;
    Ok(bytes)
}
fn main() -> Result<()> {
    let dir = PathBuf::from(std::env::args_os().nth(1).context("owned output path")?);
    ensure!(!dir.exists(), "output already exists");
    fs::create_dir(&dir)?;
    let agent = ureq::AgentBuilder::new().redirects(0).timeout_connect(Duration::from_secs(8)).timeout_read(Duration::from_secs(30)).timeout_write(Duration::from_secs(30)).build();
    let feed = get(&agent, "latest.json", 1159, "fd8109231f6077405c410047fab94ea1a5797e9963e81fd9a80a0cb86cf95dca", &dir)?;
    let signature = get(&agent, "latest.p7s", 1614, "1f881c23724b892ab9814eb2eb9002a365df159a7220bb5316538a0ea181a5c7", &dir)?;
    platform::verify_cms(&feed, &signature, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let source = HttpsSource::new()?;
    let mut received = 0;
    let pair = source.discovery_pair(&mut |n| { received += n; Ok(()) })?;
    ensure!(pair.0 == feed && pair.1 == signature, "production HTTPS discovery pair");
    platform::verify_cms(&pair.0, &pair.1, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let engine = get(&agent, "releases/updater-9213EC3FE1A992F7-s15/ENGINE.json", 421, "82fed6853aed2ed3d8c8c7520b9d4b84aacd4ac2723c2e47506eb4d001cb99b0", &dir)?;
    let engine_sig = get(&agent, "releases/updater-9213EC3FE1A992F7-s15/ENGINE.p7s", 1614, "c19efee65316762e459ae48afc6123184e4c66defcb33f274fec046c66908a2b", &dir)?;
    platform::verify_cms(&engine, &engine_sig, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let _binary = get(&agent, "releases/updater-9213EC3FE1A992F7-s15/Mir2Updater.exe", 1952256, "9213ec3fe1a992f757ea48c53981afa661765b42e637c1ad811e326060b170b8", &dir)?;
    let statement = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-20/RELEASE-STATEMENT.json", 707, "305543a68c651560b484ece5bdc44bed67e4985fe9930e75acf478507baecc84", &dir)?;
    let statement_sig = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-20/RELEASE-STATEMENT.p7s", 1614, "5ad7aced2fdaba635579b1082b8d42ed81d66f80b15c0d371550d04601f94528", &dir)?;
    platform::verify_cms(&statement, &statement_sig, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let value: serde_json::Value = serde_json::from_slice(&statement)?;
    ensure!(value["gitRevision"] == "8faedd89fbcdda7d4f814c05f7d2f56979ab5bf5" && value["worktreeDirty"] == false && value["exeSha256"] == "E227A68C10042E6F7D7264B2F91A8F252A1B73D5AAD4FB6FA92FAD3E11D04FCB", "actual game source and executable binding");
    let delivery = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-20/DELIVERY.json", 10560559, "679889dcce106251c5530546f714352dc6d8b03543a3da748d9311b176b0fce2", &dir)?;
    let delivery_sig = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-20/DELIVERY.p7s", 1614, "cf4184d9a41537f484441f9316efbd68708cdf57f860c1d937aea4e4e34c6a00", &dir)?;
    platform::verify_cms(&delivery, &delivery_sig, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let r = agent.get("https://assets.mir2.obelisk.build/client-updates/installers/ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03/Mir2Setup.exe").set("Accept-Encoding", "identity").set("Range", "bytes=0-1023").call()?;
    ensure!(r.status() == 206 && r.header("Content-Range") == Some("bytes 0-1023/29245069"), "actual TLS range");
    let mut prefix = Vec::new();
    r.into_reader().take(1025).read_to_end(&mut prefix)?;
    let mut original = Vec::new();
    fs::File::open("C:/mir2-playtest-releases/20261007-mining-r19/bootstrap-03/artifacts/Numeron-Legend-of-Rebirth-20261007-r19-Bootstrap.exe")?.take(1024).read_to_end(&mut original)?;
    ensure!(prefix == original && prefix.len() == 1024, "range original bytes");
    fs::write(dir.join("bootstrap-prefix.bin"), &prefix)?;
    let receipt = json!({"schema":"mir2.actual-native-ureq-https-cms-readonly.v1","passed":true,"ureq":"2.12.1","defaultUserAgent":"ureq/2.12.1","tlsVerified":true,"directCdnSequence":16,"compiledCdnUrl":CDN_FEED_URL,"actualProductionDiscoveryPair":true,"discoveryReportedBytes":received,"feedCmsVerified":true,"engineCmsVerified":true,"engineFullShaVerified":true,"actualRange206OriginalBytes":true,"requestBytesStored":true,"gameSource":"8faedd89fbcdda7d4f814c05f7d2f56979ab5bf5","engineSource":"b4390ee4c987bbf000ba1d95761151e39fc0d54f","gameStatementCmsVerified":true,"deliveryCmsVerified":true,"gameLaunched":false,"gameInstallationTouched":false,"fullInstallerExecuted":false,"affectedLaptopTested":false});
    fs::write(dir.join("RESULT.json"), serde_json::to_vec_pretty(&receipt)?)?;
    println!("{receipt}");
    Ok(())
}
