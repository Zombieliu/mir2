Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$pin='6C70C777B27D50949370D494B4B25798200FBDD5C171BAEEAA94D7E289900F3E'
function NoLinks([string]$Path) {
    $cursor=[IO.Path]::GetFullPath($Path)
    if($cursor.StartsWith('\\')){throw 'UNC publication inputs unsupported'}
    while($cursor){
        if((Test-Path -LiteralPath $cursor)-and((Get-Item -LiteralPath $cursor -Force).Attributes-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'Linked publication path rejected'}
        $parent=Split-Path -Parent $cursor
        if(!$parent -or $parent-eq$cursor){break};$cursor=$parent
    }
}
function Bytes([string]$Path) {
    NoLinks $Path
    $item=Get-Item -LiteralPath $Path -Force
    if($item.PSIsContainer -or $item.Length-gt33554432 -or $item.LinkType-eq'HardLink'){throw 'Bounded plain metadata required'}
    foreach($stream in @(Get-Item -LiteralPath $Path -Stream *)){if($stream.Stream-cne':$DATA'){throw 'Metadata alternate stream rejected'}}
    return ,[IO.File]::ReadAllBytes($Path)
}
function Sha([byte[]]$Value){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Value))}
function Save([string]$Path,$Value){
    NoLinks $Path
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 16 -Compress))
    $stream=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$stream.Write($bytes);$stream.Flush($true)}finally{$stream.Dispose()}
}
function CheckCms([byte[]]$Value,[byte[]]$Signature,[long]$At){
    $envelope=[Security.Cryptography.Pkcs.SignedCms]::new();$envelope.Decode($Signature)
    if($envelope.ContentInfo.Content.Length-ne0){throw 'Detached CMS required'}
    $cms=[Security.Cryptography.Pkcs.SignedCms]::new([Security.Cryptography.Pkcs.ContentInfo]::new($Value),$true)
    $cms.Decode($Signature)
    if($cms.SignerInfos.Count-ne1 -or $cms.SignerInfos[0].DigestAlgorithm.Value-cne'2.16.840.1.101.3.4.2.1'){throw 'One SHA256 CMS signer required'}
    $cms.CheckSignature($true)
    $certificate=$cms.SignerInfos[0].Certificate
    $when=[DateTimeOffset]::FromUnixTimeSeconds($At).UtcDateTime
    if(!$certificate -or $certificate.NotBefore.ToUniversalTime()-gt$when -or $certificate.NotAfter.ToUniversalTime()-lt$when){throw 'CMS certificate time mismatch'}
    $eku=$certificate.Extensions|Where-Object {$_.Oid.Value-eq'2.5.29.37'}|Select-Object -First 1
    $usage=$certificate.Extensions|Where-Object {$_.Oid.Value-eq'2.5.29.15'}|Select-Object -First 1
    if(!$eku -or @($eku.EnhancedKeyUsages|ForEach-Object {$_.Value})-notcontains'1.3.6.1.5.5.7.3.3' -or
       ($usage-and($usage.KeyUsages-band[Security.Cryptography.X509Certificates.X509KeyUsageFlags]::DigitalSignature)-eq0)){throw 'CMS code signing usage required'}
    $rsa=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($certificate)
    if(!$rsa-or(Sha $rsa.ExportRSAPublicKey())-cne$pin){throw 'CMS publisher key pin mismatch'}
}

Add-Type -AssemblyName System.Security.Cryptography.Pkcs
$now=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$oldFeed='C:/mir2-playtest-releases/20261007-mining-r19/updater-01/feed'
$raw=Bytes (Join-Path $oldFeed 'latest.json');$feed=[Text.Encoding]::UTF8.GetString($raw)|ConvertFrom-Json
CheckCms $raw (Bytes (Join-Path $oldFeed 'latest.p7s')) $feed.createdUnix
if($feed.sequence-ne15){throw 'Exact s15 required'}
$roots=@('C:/mir2-playtest-releases/20261007-npc-map-r20/base-auth-01','C:/Users/Administrator/.codex/worktrees/r17/mir2-player-journey/mir2-web3/dist/r17')
$exes=@('C:/mir2-playtest-releases/20261007-mining-r19/native-run-03-public/mir2-platform-windows.exe',(Join-Path $roots[1] 'mir2-platform-windows.exe'))
$result=@()
for($i=0;$i-lt2;$i++){
 $v=Bytes (Join-Path $roots[$i] 'VERSION.json')
 $s=Bytes (Join-Path $roots[$i] 'RELEASE-STATEMENT.json')
 $sig=Bytes (Join-Path $roots[$i] 'RELEASE-STATEMENT.p7s')
 CheckCms $s $sig $now
 $version=[Text.Encoding]::UTF8.GetString($v)|ConvertFrom-Json
 $statement=[Text.Encoding]::UTF8.GetString($s)|ConvertFrom-Json
 if($statement.versionSha256-cne(Sha $v)-or$version.worktreeDirty-ne$false){throw 'Base version signed binding rejected'}
 if($i-eq0){
  foreach($e in $feed.game.metadata){if($e.path-cne'PACKAGE-MANIFEST.json'){
   $b=Bytes (Join-Path $roots[$i] $e.path)
   if($b.Length-ne$e.size-or(Sha $b)-cne$e.sha256){throw 'Signed predecessor metadata mismatch'}
  }}
  if($version.candidate-cne$feed.game.identity){throw 'Wrong public base candidate'}
 }
 NoLinks $exes[$i]
 $item=Get-Item -LiteralPath $exes[$i]
 $hash=(Get-FileHash -LiteralPath $exes[$i] -Algorithm SHA256).Hash
 if($hash-cne$version.exeSha256-or$item.Length-ne$version.exeSizeBytes){throw 'Base EXE does not match signed candidate'}
 $result+=[ordered]@{candidate=$version.candidate;path=$exes[$i];size=$item.Length;sha256=$hash;cmsVerified=$true;signedVersionBound=$true}
}
Save 'C:/mir2-playtest-releases/20261007-npc-map-r20/base-auth-01/BASE-VERIFICATION.json' ([ordered]@{schema='mir2.r20.delta-base-verification.v1';passed=$true;bases=$result;previousFeedSha256=Sha $raw})
$result|ConvertTo-Json
