"""Root-reviewed read-only native HTTPS probe; preserve all existing CMS gates."""
import hashlib,json,pathlib,subprocess
old=pathlib.Path('C:/mir2-playtest-releases/20261007-mining-r19/native-https15-probe')
out=pathlib.Path('C:/mir2-playtest-releases/20261007-npc-map-r20/native-https16-probe')
raw=(old/'src/main.rs').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='8a2fb0dcf4aed1fcb57b5392bb235f62145b83c801fa72ac70c9b02be7e5bcbb'
assert not out.exists()
source=raw.decode()
replacements={
 'Some("15")':('Some("16")',1),
 '"directCdnSequence":15':('"directCdnSequence":16',1),
 '11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c':('fd8109231f6077405c410047fab94ea1a5797e9963e81fd9a80a0cb86cf95dca',1),
 '742d8403f6179697d58e5aa5b66c2b45ce4f485bdb573edbe0bf4b9212236ef5':('1f881c23724b892ab9814eb2eb9002a365df159a7220bb5316538a0ea181a5c7',1),
 'game-WN-CANDIDATE-20261007-invited-19':('game-WN-CANDIDATE-20261007-invited-20',4),
 'e614b21b5ffa3ce82dfaf8c39270f317a3defed0bf0c1c378b52637b03ac0b24':('305543a68c651560b484ece5bdc44bed67e4985fe9930e75acf478507baecc84',1),
 'd8a9d7162e4c851fa66b7d86cc206621f514e7348da28e933b80139932bfd3b1':('5ad7aced2fdaba635579b1082b8d42ed81d66f80b15c0d371550d04601f94528',1),
 '2b04e82c4f42b22f895f5f95b5bd79a8147eacdf':('8faedd89fbcdda7d4f814c05f7d2f56979ab5bf5',2),
 '3ABC0C7B74AF234D797705AC9CE32A68ABEFAC70BF43095093A353C81145F297':('E227A68C10042E6F7D7264B2F91A8F252A1B73D5AAD4FB6FA92FAD3E11D04FCB',1),
 '10560229':('10560559',1),
 'b7ba15b5478bff38a04b2678ccb52377e572ac0f7996b7af69403f1d137cf45a':('679889dcce106251c5530546f714352dc6d8b03543a3da748d9311b176b0fce2',1),
 '5d53e88d692f490a27a85404e68f3db1785673037565787cc96276897040e732':('cf4184d9a41537f484441f9316efbd68708cdf57f860c1d937aea4e4e34c6a00',1),
}
for before,(after,count) in replacements.items():
    assert source.count(before)==count,(before,source.count(before))
    source=source.replace(before,after)
engine=pathlib.Path('C:/Users/Administrator/.codex/worktrees/r20-engine-source/mir2-player-journey')
assert subprocess.check_output(['git','-C',str(engine),'rev-parse','HEAD']).decode().strip()=='b4390ee4c987bbf000ba1d95761151e39fc0d54f'
assert not subprocess.check_output(['git','-C',str(engine),'status','--porcelain'])
cargo=(old/'Cargo.toml').read_text().replace('mir2-native-cdn15-readonly-proof','mir2-native-cdn16-readonly-proof')
before='C:/Users/Administrator/.codex/worktrees/m19u/mir2-player-journey/mir2-web3/apps/game-client/windows-updater'
assert cargo.count(before)==1
cargo=cargo.replace(before,str(engine).replace('\\','/')+'/mir2-web3/apps/game-client/windows-updater')
(out/'src').mkdir(parents=True)
(out/'src/main.rs').write_bytes(source.encode())
(out/'Cargo.toml').write_bytes(cargo.encode())
receipt={'schema':'mir2.native.r20.https16-probe-recipe.v1','engineSource':'b4390ee4c987bbf000ba1d95761151e39fc0d54f','gameSource':'8faedd89fbcdda7d4f814c05f7d2f56979ab5bf5','priorSourceSha256':hashlib.sha256(raw).hexdigest(),'candidateSourceSha256':hashlib.sha256(source.encode()).hexdigest(),'onlyFixedExpectedIdentitiesChanged':True,'originalReadOnlySourceRetained':True,'networkExecuted':False}
(out/'RECIPE.json').write_bytes(json.dumps(receipt,indent=2).encode())
print(json.dumps(receipt))
