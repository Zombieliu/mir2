# Isolated public-WSS acceptance; normal password login via supported env API.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$candidate='C:/Users/Administrator/.codex/worktrees/npc-map-go/mir2-player-journey/mir2-web3/dist/r20'
$qaRoot='C:/mir2-playtest-releases/20261007-npc-map-r20/native-run-01'
if(Test-Path -LiteralPath $qaRoot){throw 'fresh QA directory required'}
$version=Get-Content -LiteralPath (Join-Path $candidate 'VERSION.json') -Raw | ConvertFrom-Json
if($version.gitRevision-cne'8faedd89fbcdda7d4f814c05f7d2f56979ab5bf5'-or$version.worktreeDirty-ne$false){throw 'wrong candidate source'}
$exe=Join-Path $candidate 'mir2-platform-windows.exe'
if((Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash-cne$version.exeSha256){throw 'candidate EXE changed'}
[IO.Directory]::CreateDirectory($qaRoot)|Out-Null
Copy-Item -LiteralPath $exe -Destination (Join-Path $qaRoot 'mir2-platform-windows.exe')
Copy-Item -LiteralPath (Join-Path $candidate 'mir2-client.toml') -Destination (Join-Path $qaRoot 'mir2-client.toml')
$appData=Join-Path $qaRoot 'appdata'
$localData=Join-Path $qaRoot 'localappdata'
[IO.Directory]::CreateDirectory((Join-Path $appData 'mir2-web3'))|Out-Null
[IO.Directory]::CreateDirectory($localData)|Out-Null
[IO.File]::WriteAllText((Join-Path $appData 'mir2-web3/locale.json'),' {"schema":1,"locale":"zh-TW"}',[Text.UTF8Encoding]::new($false))
$accounts=Get-Content -LiteralPath 'C:/mir2-playtest-releases/20261007-mining-r19/public-wss-03/private/accounts.json' -Raw|ConvertFrom-Json
$qaAccount=@($accounts | Where-Object {$_.accountId -ceq 'PubR19B07'})
if($qaAccount.Count-ne1-or$qaAccount[0].characterIndex-ne24){throw 'exact dedicated QA cohort required'}
$taskEnvNames=@('MIR2_NATIVE_ACCOUNT','MIR2_NATIVE_PASSWORD','MIR2_NATIVE_CHARACTER_INDEX','MIR2_GATEWAY_WS_URL','MIR2_NATIVE_ASSET_ROOT','APPDATA','LOCALAPPDATA')
$taskSavedEnv=@{}
foreach($name in $taskEnvNames){$taskSavedEnv[$name]=[Environment]::GetEnvironmentVariable($name)}
try {
 $env:MIR2_NATIVE_ACCOUNT=$qaAccount[0].accountId
 $env:MIR2_NATIVE_PASSWORD=$qaAccount[0].password
 $env:MIR2_NATIVE_CHARACTER_INDEX='24'
 $env:MIR2_GATEWAY_WS_URL='wss://165.154.65.136.sslip.io/playtest/ws'
 $env:MIR2_NATIVE_ASSET_ROOT=Join-Path $candidate 'mir2-assets'
 $env:APPDATA=$appData
 $env:LOCALAPPDATA=$localData
 $process=Start-Process -FilePath (Join-Path $qaRoot 'mir2-platform-windows.exe') -WorkingDirectory $qaRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $qaRoot 'stdout.log') -RedirectStandardError (Join-Path $qaRoot 'stderr.log')
 [IO.File]::WriteAllText((Join-Path $qaRoot 'LAUNCH.json'),([ordered]@{schema='mir2.r20.native-npc-shop-qa.v1';pid=$process.Id;gameSource=$version.gitRevision;exeSha256=$version.exeSha256;endpoint=$env:MIR2_GATEWAY_WS_URL;accountId='PubR19B07';characterIndex=24;class='Wizard';settingsIsolated=$true;assetRoot=$env:MIR2_NATIVE_ASSET_ROOT;passwordLogged=$false;installationTouched=$false}|ConvertTo-Json -Depth 5),[Text.UTF8Encoding]::new($false))
 [ordered]@{pid=$process.Id;source=$version.gitRevision;root=$qaRoot;settingsIsolated=$true}|ConvertTo-Json
} finally {foreach($name in $taskEnvNames){[Environment]::SetEnvironmentVariable($name,$taskSavedEnv[$name])};$qaAccount=$null;$accounts=$null}
