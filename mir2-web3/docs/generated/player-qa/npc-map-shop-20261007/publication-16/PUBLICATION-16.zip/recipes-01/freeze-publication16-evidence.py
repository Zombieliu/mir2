"""Freeze validated actual publication evidence; never sign or publish."""
import hashlib,json,pathlib,zipfile,re
R=pathlib.Path('C:/mir2-playtest-releases/20261007-npc-map-r20')
P=pathlib.Path('C:/Users/Administrator/.codex/worktrees/npc-map-publish/mir2-player-journey/mir2-web3')
OUT=P/'docs/generated/player-qa/npc-map-shop-20261007/publication-16'
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(b): return hashlib.sha256(b).hexdigest()
stage=load(R/'r2-stage-01/receipt.json'); promote=load(R/'r2-promote-01/receipt.json')
sc=load(R/'operators-01/stage-ci-37603327260.json'); pc=load(R/'operators-01/promote-ci-37605195682.json')
native=load(R/'native-https16-01/RESULT.json')
origin=load(pathlib.Path('C:/mir2-build/npc-map-shop-origin-feed-promote-01.log'))
for c in (sc,pc):
    assert c['workflow_id']==284517107 and c['event']=='workflow_dispatch' and c['conclusion']=='success'
    assert c['head_sha']=='aba54763f797c90596fd8aeea7f24c622fe71bed'
assert stage['passed'] and stage['publicVerified'] and stage['verifiedObjectCount']==41 and stage['publicVerifiedBytes']==1077405420
assert sha((R/'r2-stage-01/receipt.json').read_bytes())=='95a807c965582bfbaba42bca7679c79f2a83f85945900e58418b87a523e2ff4b'
assert promote['passed'] and promote['privatePointerVerified'] and promote['aliasesVerified'] and promote['pointerChanged']
assert not promote['pointerOutcomeUnknown'] and promote['stageReceiptSha256']=='95a807c965582bfbaba42bca7679c79f2a83f85945900e58418b87a523e2ff4b'
assert promote['candidate']==stage['candidate'] and promote['candidate']['sequence']==16
assert native['passed'] and native['directCdnSequence']==16 and native['actualProductionDiscoveryPair']
assert all(native[k] for k in ('feedCmsVerified','engineCmsVerified','engineFullShaVerified','gameStatementCmsVerified','deliveryCmsVerified','actualRange206OriginalBytes'))
assert origin['passed'] and origin['sequence']==16 and origin['allServicePidsPreserved'] and origin['oldFeed15BytesAndFingerprintsPreserved']
assert not origin['gatewayRestarted'] and not origin['caddyReloaded']
assert OUT.is_dir() and {x.name for x in OUT.iterdir()}=={'PUBLICATION-16.zip','ARCHIVE.json','FINAL-RELEASE-01.json'}
assert sha((OUT/'PUBLICATION-16.zip').read_bytes())=='016a0486441bffc5c84edd4e1940879c8d3e095d342c3cc5953ccc9325873885'
assert sha((R/'archive-original-01/PUBLICATION-16.zip').read_bytes())=='016a0486441bffc5c84edd4e1940879c8d3e095d342c3cc5953ccc9325873885'
files=[]
def add(path,name):
    raw=path.read_bytes(); original_sha=sha(raw)
    if name.startswith('raw-logs/'):
        raw=re.sub(rb'https://results-receiver\.actions\.githubusercontent\.com/[^\s\"<>]+',b'[temporary private CI log URL redacted; original retained locally]',raw)
    files.append((name,raw))
    result={'path':name,'bytes':len(raw),'sha256':sha(raw)}
    if sha(raw)!=original_sha:
        result.update(sourceSha256=original_sha,privateCiLogAuthorizationUrlRedacted=True,originalRetainedLocally=True)
    return result
inventory=[]
for d in ('publication-01','base-auth-01','feed-01'):
    for f in sorted((R/d).iterdir()):
        if f.is_file() and f.suffix in ('.json','.p7s','.log'): inventory.append(add(f,d+'/'+f.name))
for name in ('DELIVERY-VERIFICATION.json','SIGN-DELIVERY.json','byte-verification.log'):
    inventory.append(add(R/'delivery-01'/name,'delivery-01/'+name))
for d in ('r2-stage-01','r2-promote-01'):
    for f in sorted((R/d).rglob('*')):
        if f.is_file(): inventory.append(add(f,d+'/'+str(f.relative_to(R/d)).replace('\\','/')))
for f in sorted((R/'native-https16-01').iterdir()):
    if f.suffix in ('.json','.p7s'): inventory.append(add(f,'native-https16-01/'+f.name))
for f in sorted((R/'operators-01').iterdir()):
    if f.is_file() and f.name!='TREE-REQUEST-01.json' and f.suffix in ('.json','.command','.py','.in','.log'):
        inventory.append(add(f,'operators-01/'+f.name))
for f in sorted((R/'native-https16-probe').rglob('*')):
    if f.is_file(): inventory.append(add(f,'native-https16-probe/'+str(f.relative_to(R/'native-https16-probe')).replace('\\','/')))
for f in sorted((R/'recipes-01').iterdir()):
    if f.is_file(): inventory.append(add(f,'recipes-01/'+f.name))
for f in sorted(pathlib.Path('C:/mir2-build').glob('npc-map-shop-*.log')):
    inventory.append(add(f,'raw-logs/'+f.name))
archive=OUT/'PUBLICATION-16.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in files: z.writestr(name,raw)
(OUT/'ARCHIVE.json').write_text(json.dumps({'schema':'mir2.npc-map-shop.publication16-archive.v1','files':inventory,'archiveSha256':sha(archive.read_bytes()),'credentialsIncluded':False,'playerStoresIncluded':False,'executablesIncluded':False},indent=2)+'\n',encoding='utf-8')
result={'schema':'mir2.npc-map-shop.actual-publication16.v1','passed':True,'candidate':'WN-CANDIDATE-20261007-invited-20','candidatePublished':True,'accepted':False,'clientOnly':True,'gameSource':'8faedd89fbcdda7d4f814c05f7d2f56979ab5bf5','engineSource':'b4390ee4c987bbf000ba1d95761151e39fc0d54f','publisherSource':'aba54763f797c90596fd8aeea7f24c622fe71bed','signedSequence':16,'stageRun':37603327260,'promoteRun':37605195682,'stageReceiptSha256':sha((R/'r2-stage-01/receipt.json').read_bytes()),'promoteReceiptSha256':sha((R/'r2-promote-01/receipt.json').read_bytes()),'objectsVerified':41,'publicBytesVerified':1077405420,'windowsExeSha256':'e227a68c10042e6f7d7264b2f91a8f252a1b73d5aad4fb6fa92fad3e11d04fcb','nativeHttpsCmsRangePassed':True,'oldFeed15BytesAndFingerprintsPreserved':True,'allServicePidsPreserved':True,'gatewayRestarted':False,'installedDOrFFilesTouched':False,'playerSavesChanged':False,'bootstrapReused':True,'bootstrapUrl':'https://assets.mir2.obelisk.build/client-updates/installers/ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03/Mir2Setup.exe','bootstrapBytes':29245069,'bootstrapSha256':'ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03','liveCandidateNpcShopAcceptance':False,'fullInstallerExecuted':False,'affectedLaptopTested':False,'broaderGoalComplete':False,'archiveSha256':sha(archive.read_bytes())}
(OUT/'FINAL-RELEASE-01.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':True,'filesArchived':len(files),'archiveBytes':archive.stat().st_size,'archiveSha256':result['archiveSha256']}))
