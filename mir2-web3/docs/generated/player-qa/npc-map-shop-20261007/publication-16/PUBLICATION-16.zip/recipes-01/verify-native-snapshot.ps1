Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$pin='6C70C777B27D50949370D494B4B25798200FBDD5C171BAEEAA94D7E289900F3E'
function NoLinks([string]$Path) {
    $cursor=[IO.Path]::GetFullPath($Path)
    if($cursor.StartsWith('\\')){throw 'UNC publication inputs unsupported'}
    while($cursor){
        if((Test-Path -LiteralPath $cursor)-and((Get-Item -LiteralPath $cursor -Force).Attributes-band[IO.FileAttributes]::ReparsePoint)-ne0){throw 'Linked publication path rejected'}
        $parent=Split-Path -Parent $cursor
        if(!$parent -or $parent-eq$cursor){break};$cursor=$parent
    }
}
function Bytes([string]$Path) {
    NoLinks $Path
    $item=Get-Item -LiteralPath $Path -Force
    if($item.PSIsContainer -or $item.Length-gt33554432 -or $item.LinkType-eq'HardLink'){throw 'Bounded plain metadata required'}
    foreach($stream in @(Get-Item -LiteralPath $Path -Stream *)){if($stream.Stream-cne':$DATA'){throw 'Metadata alternate stream rejected'}}
    return ,[IO.File]::ReadAllBytes($Path)
}
function Sha([byte[]]$Value){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($Value))}
function Save([string]$Path,$Value){
    NoLinks $Path
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($Value|ConvertTo-Json -Depth 16 -Compress))
    $stream=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try{$stream.Write($bytes);$stream.Flush($true)}finally{$stream.Dispose()}
}
function CheckCms([byte[]]$Value,[byte[]]$Signature,[long]$At){
    $envelope=[Security.Cryptography.Pkcs.SignedCms]::new();$envelope.Decode($Signature)
    if($envelope.ContentInfo.Content.Length-ne0){throw 'Detached CMS required'}
    $cms=[Security.Cryptography.Pkcs.SignedCms]::new([Security.Cryptography.Pkcs.ContentInfo]::new($Value),$true)
    $cms.Decode($Signature)
    if($cms.SignerInfos.Count-ne1 -or $cms.SignerInfos[0].DigestAlgorithm.Value-cne'2.16.840.1.101.3.4.2.1'){throw 'One SHA256 CMS signer required'}
    $cms.CheckSignature($true)
    $certificate=$cms.SignerInfos[0].Certificate
    $when=[DateTimeOffset]::FromUnixTimeSeconds($At).UtcDateTime
    if(!$certificate -or $certificate.NotBefore.ToUniversalTime()-gt$when -or $certificate.NotAfter.ToUniversalTime()-lt$when){throw 'CMS certificate time mismatch'}
    $eku=$certificate.Extensions|Where-Object {$_.Oid.Value-eq'2.5.29.37'}|Select-Object -First 1
    $usage=$certificate.Extensions|Where-Object {$_.Oid.Value-eq'2.5.29.15'}|Select-Object -First 1
    if(!$eku -or @($eku.EnhancedKeyUsages|ForEach-Object {$_.Value})-notcontains'1.3.6.1.5.5.7.3.3' -or
       ($usage-and($usage.KeyUsages-band[Security.Cryptography.X509Certificates.X509KeyUsageFlags]::DigitalSignature)-eq0)){throw 'CMS code signing usage required'}
    $rsa=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($certificate)
    if(!$rsa-or(Sha $rsa.ExportRSAPublicKey())-cne$pin){throw 'CMS publisher key pin mismatch'}
}

Add-Type -AssemblyName System.Security.Cryptography.Pkcs
$now=[DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$candidate='C:/mir2-playtest-releases/20261007-npc-map-r20/native-candidate-qa-input-01'
$statementBytes=Bytes (Join-Path $candidate 'RELEASE-STATEMENT.json')
CheckCms $statementBytes (Bytes (Join-Path $candidate 'RELEASE-STATEMENT.p7s')) $now
$statement=[Text.Encoding]::UTF8.GetString($statementBytes)|ConvertFrom-Json
if($statement.versionSha256-cne(Sha (Bytes (Join-Path $candidate 'VERSION.json')))-or
 $statement.packageManifestSha256-cne(Sha (Bytes (Join-Path $candidate 'PACKAGE-MANIFEST.json')))){throw 'Snapshot signature binding failed'}
'CMS-bound R20 snapshot; full package verifier remains in progress'
