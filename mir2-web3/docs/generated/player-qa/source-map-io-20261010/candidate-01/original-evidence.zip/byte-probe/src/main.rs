#[path = "E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3/apps/simulation/src/runtime/source_map_loading.rs"]
mod source_map_loading;
#[path = "E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3/apps/simulation/src/runtime/source_map_io.rs"]
mod source_map_io;
use sha2::{Digest,Sha256};
use std::{fs,io::Write,path::Path};
fn digest(bytes: &[u8])->String {
    Sha256::digest(bytes).iter().map(|v|format!("{v:02x}")).collect()
}
fn main() {
    let args:Vec<_>=std::env::args().collect();
    let mut output=fs::OpenOptions::new().write(true).create_new(true).open(&args[5]).unwrap();
    let mut raw_count=0; let mut gzip_count=0;
    for line in fs::read_to_string(&args[1]).unwrap().lines() {
        let original:serde_json::Value=serde_json::from_str(line).unwrap();
        let name=original["input"]["fileName"].as_str().unwrap();
        if name.is_empty() {continue;}
        let path=Path::new(&args[2]).join(format!("{name}.map"));
        let bytes=source_map_io::read_raw_map_file(&path).expect("actual Source raw map became unavailable");
        assert_eq!(bytes.len() as u64,original["rawByteLength"].as_u64().unwrap());
        let actual=digest(&bytes);
        assert_eq!(actual,original["rawSha256"].as_str().unwrap(),"Source raw bytes changed");
        raw_count+=1;
        writeln!(output,"{}",serde_json::json!({"sourceInput":original["input"],"scope":"raw-file-bytes-only","sha256":actual,"matched":true})).unwrap();
    }
    let pack:serde_json::Value=serde_json::from_slice(&fs::read(&args[3]).unwrap()).unwrap();
    assert_eq!(pack["count"].as_u64(),Some(1620));
    for row in pack["inputs"].as_array().unwrap() {
        let name=row["file"].as_str().unwrap();
        let path=Path::new(&args[4]).join(name);
        let compressed=fs::read(&path).unwrap();
        assert_eq!(compressed.len() as u64,row["compressedBytes"].as_u64().unwrap());
        assert_eq!(digest(&compressed),row["compressedSha256"].as_str().unwrap(),"Bundle input changed");
        drop(compressed);
        let bytes=source_map_io::read_gzip_map_file(&path).expect("actual packaged gzip map became unavailable");
        assert_eq!(bytes.len() as u64,row["rawBytes"].as_u64().unwrap());
        let actual=digest(&bytes);
        assert_eq!(actual,row["rawSha256"].as_str().unwrap(),"Bundle decompressed bytes changed");
        gzip_count+=1;
        writeln!(output,"{}",serde_json::json!({"packFile":name,"scope":"gzip-file-bytes-only","sha256":actual,"matched":true})).unwrap();
    }
    assert_eq!(raw_count,463); assert_eq!(gzip_count,1620);
    println!("{}",serde_json::json!({"rawFilesMatched":raw_count,"packGzipFilesMatched":gzip_count,
        "mismatches":0,"scope":"actual bounded I/O bytes only; overlapping corpora, no Map.Load/authority/render proof"}));
}
