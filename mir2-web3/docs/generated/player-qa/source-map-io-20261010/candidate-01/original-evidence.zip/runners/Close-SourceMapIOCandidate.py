"""Close the bounded I/O slice using actual final logs and immutable originals."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile
from datetime import datetime, timezone

helpers = Path(__file__).resolve().parent
repo = helpers / 'gateway-lifecycle-20261008-01'
root = repo / 'mir2-web3'
ev = Path('C:/mir2-build/p7-source-map-io-20261010-evidence')
base = '64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
out = root / 'docs/generated/player-qa/source-map-io-20261010/candidate-01'
assert not out.exists()
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-c', 'gc.auto=0',
       '-c', 'maintenance.auto=false', '-C', str(repo)]
assert subprocess.check_output(git + ['rev-parse', 'HEAD']).decode().strip() == base

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def new_json(path, record):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(record, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

names, final = set(), {}
for stem, expected, ignored in [('01-final-bounded-io-and-collision', 59, 1),
                                ('02-original-optimized-gateway-map-flow', 4, 0)]:
    before, after = read(ev / (stem + '-before.json')), read(ev / (stem + '-after.json'))
    assert before['declaredBaseSource'] == after['declaredBaseSource'] == base
    assert before['source'] == after['source'] and len(after['source']) == 14
    for row in after['source']:
        assert sha(Path(row['Path']).read_bytes()).upper() == row['Hash']
    result = read(ev / (stem + '-result.json'))
    log = (ev / (stem + '.log')).read_text(encoding='utf-8-sig')
    totals = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    passed = re.findall(r'^test (\S+) \.\.\. ok$', log, re.M)
    assert result['exitCode'] == 0 and len(totals) == 1
    assert tuple(map(int, totals[0])) == (expected, 0, ignored)
    assert len(passed) == len(set(passed)) == expected and not names.intersection(passed)
    names.update(passed)
    final[stem] = {'passed': expected, 'failed': 0, 'ignored': ignored, 'exitCode': 0,
                   'selectedPaths': 14, 'beforeAfterStableAndCurrent': True,
                   'logSha256': sha((ev / (stem + '.log')).read_bytes())}
assert len(names) == 63 and sum('source_map_io::tests::' in name for name in names) == 27
probe_stem = '03-actual-raw-and-gzip-byte-comparison'
probe = read(ev / (probe_stem + '-result.json'))
assert probe['exitCode'] == 0 and probe['beforeAfterStable'] is True
assert probe['rawFilesMatched'] == 463 and probe['packGzipFilesMatched'] == 1620 and probe['mismatches'] == 0
probe_before, probe_after = read(ev / (probe_stem + '-before.json')), read(ev / (probe_stem + '-after.json'))
assert len(probe_after['inputs']) == 19 and probe_before['inputs'] == probe_after['inputs']
for row in probe_after['inputs']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
comparison = Path(probe['output'])
assert sha(comparison.read_bytes()) == probe['outputSha256']
rows = [json.loads(line) for line in comparison.read_text().splitlines()]
assert len(rows) == 2083 and all(row['matched'] is True for row in rows)
assert sum(row['scope'] == 'raw-file-bytes-only' for row in rows) == 463
assert sum(row['scope'] == 'gzip-file-bytes-only' for row in rows) == 1620

review_hashes = {
    'mir2-web3/apps/simulation/src/runtime/source_map_io.rs': '94269231ddd973c8feb3351119cff6b903e0d942dcad4a690eed32c5307d5ab4',
    'mir2-web3/apps/simulation/src/runtime/map.rs': '58f96f41cbd3ad4ff8632c4c8313fa84c4c4d1cbb639711b8bbba4d564482542',
    'mir2-web3/apps/simulation/src/runtime/source_map_loading.rs': 'dd95951c0e90f5d1fc53dc07493549e7b6c200a3a9909feaae01750375a3a2ec',
    'mir2-web3/apps/simulation/src/runtime/mod.rs': '0d0658326320ce7c96de05a83babc4c57af0d451086330ea075c4ecf3d32b54d',
    '.github/workflows/gateway-release.yml': 'b60de53f497759f805ad4e39f3b2aa2a15faa9089c350a51988da080518100d6',
}
assert all(sha((repo / name).read_bytes()) == expected for name, expected in review_hashes.items())
review = {'recordedUtc': datetime.now(timezone.utc).isoformat(),
          'source': 'final read-only mentor_integration_audit response received by Root',
          'ranTests': False, 'editedFiles': False, 'reportedBlockingFindings': False,
          'reviewedHashesStable': review_hashes,
          'scope': 'raw fallback origins; cap and EOF/footer; first gzip member; module/cap/workflow wiring',
          'limits': ['No entire process RSS or allocator footprint guarantee',
                     'Third-party finite infallible header/workspace allocations remain',
                     'No real OOM fault injection, Map.Load/world population authority or human acceptance']}
new_json(ev / 'FINAL-READ-ONLY-REVIEW.json', review)
provenance = {'utc': datetime.now(timezone.utc).isoformat(), 'baseSource': base,
              'finalSelectedInputs': read(ev / '01-final-bounded-io-and-collision-after.json')['source'],
              'scope': '14 selected paths, not whole-workspace/toolchain input closure',
              'finalTests': final, 'byteProbeInputs': probe_after['inputs'],
              'byteProbe': probe, 'review': review}
new_json(ev / 'FINAL-PROVENANCE.json', provenance)

entries = {}

def add(name, path):
    assert name not in entries
    data = Path(path).read_bytes()
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)', data), name
    entries[name] = data

for path in sorted(ev.iterdir()):
    if path.is_file():
        add('local/' + path.name, path)
for name in ['Cargo.toml', 'Cargo.lock', 'src/main.rs', 'lock-original.log', 'actual-comparison-01.jsonl']:
    add('byte-probe/' + name, ev / 'byte-probe' / name)
for name in ['Run-SourceMapIORoot.ps1', 'Prepare-SourceMapIOVerification.py',
             'Run-SourceMapIOByteProbe.py', 'Close-SourceMapIOCandidate.py']:
    add('runners/' + name, helpers / name)
for name in review_hashes:
    add('final-source/' + name, repo / name)
add('final-source/shared_purification_map_transfer.rs', root / 'apps/gateway/tests/shared_purification_map_transfer.rs')
terrain = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence')
for name in ['oracle-01/original-oracle.jsonl', 'pack-oracle-01/PACK-INPUTS.json']:
    add('prior-oracle/' + name, terrain / name)
git_receipt = Path('C:/mir2-build/p7-source-map-terrain-20261010-git-publication-01/exact-api/PUBLISHED-VERIFIED.json')
published = read(git_receipt)
assert published['head'] == base and published['force'] is False and published['candidateSourcePublishedToGit'] is True
add('predecessor-git/PUBLISHED-VERIFIED.json', git_receipt)
ci = Path('C:/mir2-build/p7-source-map-terrain-20261010-ci/server-ci-01')
snapshots = sorted(ci.glob('snapshot-[0-9][0-9].json'))
assert snapshots
latest = read(snapshots[-1])
assert latest['source'] == base and latest['runId'] == 38001876065
assert latest['status'] == 'in_progress', 'Update scope from an actual completed result before archiving'
for path in sorted(ci.glob('snapshot-*')):
    if path.is_file():
        add('predecessor-ci/' + path.name, path)
out.mkdir(parents=True)
archive = out / 'original-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, data in entries.items():
        zipped.writestr(name, data)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None and set(zipped.namelist()) == set(entries)
    assert all(zipped.read(name) == data for name, data in entries.items())
assert archive.stat().st_size <= 3 * 1024**2
record = {'schema': 'mir2.source-map-io.candidate.v1', 'createdUtc': datetime.now(timezone.utc).isoformat(),
          'baseSource': base, 'uniqueTestsPassed': 63, 'ioUnitTestsPassed': 27,
          'originalBenchmarkIgnored': 1, 'localTestsPassed': True, 'finalTests': final,
          'byteProbe': probe, 'readOnlyReview': review,
          'rawAndDecodedLimitBytes': 128 * 1024**2, 'compressedReadLimitBytes': 129 * 1024**2,
          'oneRejectionProbeByte': True, 'singleGzipMemberWithIgnoredTailPreserved': True,
          'processMemoryBoundProven': False, 'realOomFaultInjected': False,
          'predecessorActuallyPushed': True, 'predecessorLinux': latest,
          'newSourceActuallyPushed': False, 'newSourceLinuxPassed': False, 'serverSwitched': False,
          'successfulMapLoadProducerImplemented': False, 'fullClassicCompleted': False,
          'archive': {'file': archive.name, 'entries': len(entries), 'bytes': archive.stat().st_size,
                      'sha256': sha(archive.read_bytes()), 'everyEntryByteVerified': True},
          'entries': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in entries.items()}}
new_json(out / 'EVIDENCE.json', record)

header = '''> Current bounded map I/O round, 2026-10-10 local: raw/gzip map byte reads now
> stop at preparation limits, validate the complete first gzip footer and retain
> typed ordinary fallback behavior. Final 59 library + 4 original optimized
> Gateway tests pass (63 distinct; one original benchmark ignored). Actual463
> raw files and1,620 gzip maps keep identical bytes/hashes; corpora overlap.
> [Scope and original evidence](CLASSIC-SOURCE-MAP-IO-20261010.md).
> Root owns all files; bounded worker returned ownership and review is read-only.
> Source64b6 is pushed, but its Linux38001876065 remains incomplete. New I/O
> Candidate needs its own Git/Linux qualification. Last observed publicc704/
> R23/feed18 had1 undrained WS; no staging/switch/kick or real-save changes.
> Source Map.Load/population, Source-CAS world outbox and fullP1–P7/Mentor/native/
> human remain open. Expired heartbeat stays paused; no Goal completion claim.

'''
for name in ['AGENT-ORCHESTRATION', 'AGENT-TASK-QUEUE', 'CRYSTAL-1TO1-ROADMAP',
             'BACKEND-1TO1-PROGRESS', 'CRYSTAL-SERVER-PARITY', 'CLASSIC-12H-DELIVERY-20261007']:
    path = root / 'docs' / (name + '.md')
    text = path.read_text(encoding='utf-8-sig')
    if name == 'AGENT-ORCHESTRATION':
        old = '''> Active bounded I/O round: Root solely owns map.rs, source_map_loading.rs,
> mod.rs, workflow, tests integration, Git, rollout and common docs. The
> classic_p2_p6_p7_audit worker is reassigned only one new source_map_io.rs
> leaf module; it cannot edit common files or run Cargo/Git/deployment.
> Terrain source 64b6b10c05 is pushed and frozen in t64; exact-source Linux
> run 38001876065 is pending. Do not edit t64 or infer its success from the
> predecessor 01e3 run 37993166469, whose two jobs now actually passed.

'''
        assert text.count(old) == 1
        text = text.replace(old, '', 1)
    first, body = text.split('\n', 1)
    assert 'Current bounded map I/O round' not in text
    path.write_text(first + '\n\n' + header + body.lstrip('\n'), encoding='utf-8')
with (root / 'docs/CLASSIC-SOURCE-MAP-TERRAIN-20261010.md').open('a', encoding='utf-8') as stream:
    stream.write('''
## Separate bounded I/O Candidate

The following [I/O slice](CLASSIC-SOURCE-MAP-IO-20261010.md) bounds the actual
raw/gzip providers while retaining Source ordinary-read semantics. It passes
63 distinct final local checks and byte comparison across463 raw/1,620 gzip
records. It does not change the frozen64b6 source or retroactively qualify its
Linux run. Strict trailing-byte preparation gaps and Source-load/population,
world-outbox and native/human gates above remain open.
''')
subprocess.run(git + ['diff', '--check'], check=True)
print(json.dumps({key: value for key, value in record.items() if key != 'entries'}, indent=2))
