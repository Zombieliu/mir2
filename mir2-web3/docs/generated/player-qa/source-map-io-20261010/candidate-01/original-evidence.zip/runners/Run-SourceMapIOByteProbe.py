"""Compare actual bounded raw/gzip bytes without modifying original oracles."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
from datetime import datetime, timezone

helpers = Path(__file__).resolve().parent
repo = helpers / 'gateway-lifecycle-20261008-01'
evidence = Path('C:/mir2-build/p7-source-map-io-20261010-evidence')
probe = evidence / 'byte-probe'
stem = '03-actual-raw-and-gzip-byte-comparison'
oracle = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/oracle-01/original-oracle.jsonl')
pack_inputs = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/pack-oracle-01/PACK-INPUTS.json')
output = probe / 'actual-comparison-01.jsonl'
assert not output.exists()
assert not any((evidence / (stem + suffix)).exists()
               for suffix in ('.log', '.stderr.log', '-before.json', '-after.json', '-result.json'))
selected = json.loads((evidence / '01-final-bounded-io-and-collision-after.json').read_text(encoding='utf-8-sig'))
assert len(selected['source']) == 14
paths = [Path(row['Path']) for row in selected['source']]
paths += [probe / 'Cargo.toml', probe / 'Cargo.lock', probe / 'src/main.rs', oracle, pack_inputs]
assert len(paths) == 19
command = ['cargo', '+1.95.0', 'run', '--release', '--locked', '--manifest-path', str(probe / 'Cargo.toml'),
           '--', str(oracle), 'E:/mir2/Crystal/Build/Server/Debug/Maps', str(pack_inputs),
           str(repo / 'mir2-web3/apps/web/lib/generated/crystal-map-pack'), str(output)]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def record_inputs(phase):
    record = {'utc': datetime.now(timezone.utc).isoformat(), 'phase': phase,
              'baseSource': '64b6b10c05732048da9c6bf5ccb0a491d2d053d3', 'command': command,
              'scope': '14 selected production paths and 5 probe/oracle inputs; not whole Cargo/toolchain closure',
              'inputs': [{'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size} for path in paths]}
    with (evidence / (stem + '-' + phase + '.json')).open('x', encoding='utf-8') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    return record

before = record_inputs('before')
for item in selected['source']:
    assert sha(Path(item['Path'])).upper() == item['Hash']
environment = os.environ.copy()
environment['CARGO_TARGET_DIR'] = 'C:/mir2-build/p4-purification-map-20261009-target'
started = datetime.now(timezone.utc).isoformat()
with (evidence / (stem + '.log')).open('xb') as log, (evidence / (stem + '.stderr.log')).open('xb') as error:
    result = subprocess.run(command, cwd=repo / 'mir2-web3', env=environment, stdout=log, stderr=error)
after = record_inputs('after')
record = {'utcStarted': started, 'utcFinished': datetime.now(timezone.utc).isoformat(),
          'exitCode': result.returncode, 'beforeAfterStable': before['inputs'] == after['inputs'],
          'output': str(output), 'outputSha256': sha(output) if output.exists() else None,
          'rawFilesMatched': None, 'packGzipFilesMatched': None,
          'scope': 'actual bytes only; overlapping corpora; no Map.Load/world authority/render/performance proof'}
if result.returncode == 0:
    summary = json.loads((evidence / (stem + '.log')).read_text().splitlines()[-1])
    assert summary['rawFilesMatched'] == 463 and summary['packGzipFilesMatched'] == 1620
    assert summary['mismatches'] == 0
    rows = [json.loads(line) for line in output.read_text().splitlines()]
    assert len(rows) == 2083 and all(row['matched'] is True for row in rows)
    record.update({'rawFilesMatched': 463, 'packGzipFilesMatched': 1620, 'mismatches': 0})
with (evidence / (stem + '-result.json')).open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record), flush=True)
assert record['beforeAfterStable'], 'Production/probe/oracle input changed while running'
raise SystemExit(result.returncode)
