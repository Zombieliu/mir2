import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

out = Path('C:/mir2-build/p7-npc-world-20261009-ci/server-ci-01/failure-01')
out.mkdir(exist_ok=False)
run = 37941832277
job = 113857901032
def capture(name, command):
    result = subprocess.run(command, capture_output=True, timeout=55)
    (out / (name + '.raw')).write_bytes(result.stdout)
    (out / (name + '.stderr.log')).write_bytes(result.stderr)
    assert result.returncode == 0, (name, result.returncode)
    return result.stdout
status = json.loads(capture('run', ['gh', 'api', f'repos/Zombieliu/mir2/actions/runs/{run}']))
assert status['head_sha'] == '4baa66e99374cb6752906f94c6a264e2f0f1416b'
assert status['status'] == 'completed' and status['conclusion'] == 'failure'
jobs = json.loads(capture('jobs', ['gh', 'api', f'repos/Zombieliu/mir2/actions/runs/{run}/jobs']))
assert any(item['id'] == job and item['conclusion'] == 'failure' for item in jobs['jobs'])
log = capture('linux-job', ['gh', 'run', 'view', str(run), '--repo', 'Zombieliu/mir2',
                                '--job', str(job), '--log'])
receipt = {'utc': datetime.now(timezone.utc).isoformat(), 'source': status['head_sha'],
           'runId': run, 'failedJob': job, 'conclusion': status['conclusion'],
           'originalLogBytes': len(log), 'originalLogSha256': hashlib.sha256(log).hexdigest(),
           'gatewayPublished': False, 'publicGatewayStill': 'c70436f34eabb432d769e0082c0afa23303294b0'}
(out / 'FAILED-VERIFIED.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
lines = log.decode('utf-8', errors='replace').splitlines()
for index, line in enumerate(lines):
    if 'panicked at' in line or 'test result: FAILED' in line:
        print('\n'.join(lines[max(0, index-2):index+9]))
