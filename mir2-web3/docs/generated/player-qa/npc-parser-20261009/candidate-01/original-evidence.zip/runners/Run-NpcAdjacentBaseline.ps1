param([Parameter(Mandatory=$true)][string]$LogStem)
$ErrorActionPreference='Stop'
$taskRepo='C:/Users/Administrator/.codex/worktrees/npc-source-release-4baa66e993/mir2-player-journey'
$taskRoot="$taskRepo/mir2-web3"
$taskEvidence='C:/mir2-build/p7-npc-parser-20261009-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
$taskGit=@('-c',"safe.directory=$taskRepo",'-c','gc.auto=0','-c','maintenance.auto=false','-C',$taskRepo)
$taskHead=& git @taskGit rev-parse HEAD
if ($LASTEXITCODE -ne 0 -or $taskHead -ne '4baa66e99374cb6752906f94c6a264e2f0f1416b') { throw 'Unexpected frozen baseline head' }
$taskStatus=& git @taskGit status --porcelain
if ($LASTEXITCODE -ne 0 -or $taskStatus) { throw 'Frozen baseline not clean' }
Set-Location -LiteralPath $taskRoot
$taskArgs=@('+1.95.0','test','--offline','--locked','-p','mir2-simulation','--features','test-support','--lib','--','--test-threads=1','crystal_npc_buy_item_dead_player_is_silent_and_preserves_state','crystal_npc_stage5_message_buff_appearance_name_list_and_hero_commands_execute')
$taskPaths=@('Cargo.lock','apps/simulation/src/runtime/mod.rs','apps/simulation/src/runtime/npc_script.rs','apps/simulation/src/runtime/default_npc_events.rs','apps/simulation/src/runtime/default_npc_events_tests.rs','apps/simulation/src/runtime/npc_source_guard_tests.rs','apps/simulation/src/runtime/shared_guild_experience.rs','apps/simulation/src/runtime/prepared_kill_experience.rs','apps/simulation/src/runtime/save.rs','apps/simulation/src/runtime/packets.rs','apps/simulation/src/world_runtime.rs','packages/game-data/src/lib.rs','packages/game-data/data/generated/crystal_npc_manifest.json','packages/game-data/data/generated/crystal_default_npc_scripts.json','tools/generate-crystal-default-npc-scripts.mjs','tools/generate-crystal-default-npc-scripts.test.mjs')
if (Test-Path -LiteralPath "$taskEvidence/$LogStem.log") { throw 'Evidence stem already exists' }
function Write-SourceHashes([string]$phase) {
 $taskHashes=@($taskPaths | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
 [ordered]@{declaredBaseSource=$taskHead;utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=@('cargo')+$taskArgs;scope='16 declared baseline paths; only the two unresolved cases';source=$taskHashes} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding UTF8
}
Write-SourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& cargo @taskArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Write-SourceHashes 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;log="$taskEvidence/$LogStem.log"} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 35
exit $taskExit
