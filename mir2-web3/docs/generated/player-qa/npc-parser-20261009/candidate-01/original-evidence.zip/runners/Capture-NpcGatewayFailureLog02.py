import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

out = Path('C:/mir2-build/p7-npc-world-20261009-ci/server-ci-01/failure-01')
status = json.loads((out / 'run.raw').read_bytes())
assert status['head_sha'] == '4baa66e99374cb6752906f94c6a264e2f0f1416b'
assert status['conclusion'] == 'failure'
result = subprocess.run(['gh', 'api', '-H', 'Cache-Control: no-cache',
                         'repos/Zombieliu/mir2/actions/jobs/113857901032/logs'],
                        capture_output=True, timeout=55)
with (out / 'linux-job-attempt02.raw').open('xb') as stream:
    stream.write(result.stdout)
with (out / 'linux-job-attempt02.stderr.log').open('xb') as stream:
    stream.write(result.stderr)
record = {'utc': datetime.now(timezone.utc).isoformat(), 'source': status['head_sha'],
          'runId': status['id'], 'jobId': 113857901032, 'exitCode': result.returncode,
          'rawBytes': len(result.stdout), 'sha256': hashlib.sha256(result.stdout).hexdigest()}
with (out / 'LOG-ATTEMPT02.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
if result.returncode:
    raise RuntimeError('Second original log fetch failed; raw attempts preserved')
lines = result.stdout.decode('utf-8', errors='replace').splitlines()
for index, line in enumerate(lines):
    if 'panicked at' in line or 'test result: FAILED' in line:
        print('\n'.join(lines[max(0,index-2):index+9]))
