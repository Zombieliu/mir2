param([Parameter(Mandatory=$true)][string]$LogStem,[Parameter(Mandatory=$true)][ValidateSet('cargo','node')][string]$Tool,[Parameter(Mandatory=$true)][string[]]$ToolArgs)
$ErrorActionPreference='Stop'
$taskRoot='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p7-npc-parser-20261009-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
New-Item -ItemType Directory -Path $taskEvidence -Force | Out-Null
Set-Location -LiteralPath $taskRoot
$taskPaths=@('Cargo.lock','apps/simulation/src/runtime/mod.rs','apps/simulation/src/runtime/npc_script.rs','apps/simulation/src/runtime/npc_parser_omission_tests.rs','apps/simulation/src/runtime/default_npc_events.rs','apps/simulation/src/runtime/default_npc_events_tests.rs','apps/simulation/src/runtime/npc_source_guard_tests.rs','apps/simulation/src/runtime/shared_guild_experience.rs','apps/simulation/src/runtime/prepared_kill_experience.rs','apps/simulation/src/runtime/save.rs','apps/simulation/src/runtime/packets.rs','apps/simulation/src/world_runtime.rs','packages/game-data/src/lib.rs','packages/game-data/data/generated/crystal_npc_manifest.json','packages/game-data/data/generated/crystal_default_npc_scripts.json','tools/generate-crystal-default-npc-scripts.mjs','tools/generate-crystal-default-npc-scripts.test.mjs')
if (Test-Path -LiteralPath "$taskEvidence/$LogStem.log") { throw 'Evidence stem already exists' }
$taskCommand=@($Tool)+$ToolArgs
function Write-SourceHashes([string]$phase) {
 $taskHashes=@($taskPaths | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
 [ordered]@{declaredBaseSource='4baa66e99374cb6752906f94c6a264e2f0f1416b';utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=$taskCommand;scope='17 declared paths, not whole-workspace input closure';source=$taskHashes} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding UTF8
}
Write-SourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& $Tool @ToolArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Write-SourceHashes 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;log="$taskEvidence/$LogStem.log"} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 45
exit $taskExit
