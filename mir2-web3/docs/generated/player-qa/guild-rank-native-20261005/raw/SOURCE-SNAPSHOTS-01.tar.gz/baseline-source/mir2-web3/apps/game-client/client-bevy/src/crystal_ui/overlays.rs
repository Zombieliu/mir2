//! Operable native player windows: bag, equipment, inspect, death, menu, chat, mail, bigmap, shop, storage.

#[path = "character_stats.rs"]
pub mod character_stats;
#[path = "game_shop_dialog.rs"]
pub mod game_shop_dialog;
#[path = "hero_dialog.rs"]
pub mod hero_dialog;
#[path = "local_keyboard_ui.rs"]
pub mod local_keyboard_ui;
#[path = "skill_bars.rs"]
pub mod skill_bars;
#[path = "skill_page.rs"]
mod skill_page;
#[path = "npc_item_service.rs"]
mod npc_item_service;
#[path = "big_map_coordinates.rs"]
mod big_map_coordinates;
#[path = "localized_help.rs"]
mod localized_help;

use std::collections::VecDeque;

use bevy::app::AppExit;
use bevy::asset::{load_internal_asset, uuid_handle};
use bevy::ecs::system::SystemParam;
use bevy::input::keyboard::KeyboardInput;
use bevy::input::mouse::{MouseScrollUnit, MouseWheel};
use bevy::input::ButtonState;
use bevy::prelude::*;
use bevy::render::render_resource::{
    AsBindGroup, BlendComponent, BlendFactor, BlendOperation, BlendState, RenderPipelineDescriptor,
};
use bevy::shader::{Shader, ShaderRef};
use bevy::text::{Justify, LineBreak, TextLayout};
use bevy::ui::{
    AlignItems, BackgroundColor, Display, FlexDirection, FocusPolicy, Interaction, JustifyContent,
    Node, PositionType, UiRect, Val,
};
use bevy::window::{CursorMoved, PrimaryWindow};

use crate::big_map::{
    BigMapGatewayIntentQueue, BigMapModel, BigMapPoint, BigMapView, BIG_MAP_NPC_ROW_COUNT,
};
use crate::game_shop::{
    GameShopModel, GameShopPaymentType, GameShopRequest, GAME_SHOP_QUANTITY_MAX,
    GAME_SHOP_QUANTITY_MIN,
};
use crate::inventory::{concrete_item_image_index, item_icon_path, InventoryModel, ItemModel};
use crate::mail::{
    mail_claim_enabled, mail_date_label, mail_delete_enabled, MailAttachment, MailMessage,
    MailModel, MailOperationKind, MailPageCursor, MAX_MAIL_ATTACHMENTS,
};
use crate::mail_service::{MailServiceEvent, MailServiceInbox};
use crate::map::MapModel;
use crate::native_shell::{
    NativeShellModel, NativeShellScreen, NativeUiIntent, NativeUiIntentQueue,
};
use crate::pending_operations::{
    AuthoritativeModelRevisions, InventoryOperationFeedback, NativeSessionBoundaryTracker,
    OverlayResetTracker, PendingLifecycleSet, PendingOperationKey, PendingOperations,
    SessionResetGameShopPreservation, SessionResetRevision, StorageRequestIdGenerator,
};
use crate::quest_model::NpcDialogModel;
use crate::read_model::{UiReadModel, UiSurfaceSignals};
use crate::shop::{
    shop_buy_enabled, shop_buy_enabled_with_pearls, shop_quantity_clamped, shop_quantity_dec,
    shop_quantity_inc, shop_sell_enabled, NpcShopServiceMode, NpcShopServiceSignal, ShopGood,
    ShopModel,
};
use crate::skill_binding_persistence::{
    persist_skill_bindings_if_changed, SkillBindingPersistenceRuntime,
};
use crate::skill_binding_ui::SkillBindingUi;
use crate::skill_model::SkillModel;
use crate::storage::{
    inventory_selection_for_slot, storage_deposit_enabled_for_selection,
    storage_remove_password_enabled, storage_set_password_enabled, storage_unlock_enabled,
    storage_withdraw_enabled_for_selection, StorageItemSelection, StorageModel, StoragePageCursor,
};
#[cfg(test)]
use crate::storage::{
    storage_deposit_enabled, storage_expand_enabled, storage_withdraw_enabled,
};

use super::amount_input::{AmountKeyAction, CrystalAmountInput};
#[path = "mail_reader_drag.rs"]
mod mail_reader_drag;
#[path = "mail_compose_drag.rs"]
mod mail_compose_drag;
#[path = "mail_editor.rs"]
pub mod mail_editor;
#[path = "mail_text_adapter.rs"]
pub mod mail_text_adapter;
#[path = "mail_parcel.rs"]
mod mail_parcel;
#[path = "options_volume.rs"]
mod options_volume;
#[path = "mail_list.rs"]
mod mail_list;
use super::assets::CrystalButtonAssetSet;
use super::guild_storage::{self, GuildGoldAction, GuildGoldPrompt, GuildStorageUi};
use super::hud::{free_inventory_slots, CrystalHudAction};
#[cfg(test)]
use super::item_image::OriginalItemImage;
use super::item_image::{
    layout_original_item_images, original_item_image_bundle, spawn_original_item_image,
};
use super::item_tooltip::{
    crystal_item_tooltip_document, crystal_item_tooltip_document_from_source,
    crystal_item_tooltip_document_from_source_with_options, CrystalItemTooltipOptions,
};
use super::panel_layouts::{
    GAME_SHOP_CELL_SIZE, GAME_SHOP_COLUMN_STEP, GAME_SHOP_GRID_ORIGIN, GAME_SHOP_PAGE_COLUMNS,
    GAME_SHOP_PAGE_SIZE as CRYSTAL_GAME_SHOP_PAGE_SIZE, GAME_SHOP_PANEL_SIZE, GAME_SHOP_ROW_STEP,
    INVENTORY_CELL_SIZE, INVENTORY_DELETE_BUTTON_ORIGIN, INVENTORY_DELETE_BUTTON_SIZE,
    INVENTORY_FREE_SLOT_LABEL_ORIGIN, INVENTORY_FREE_SLOT_LABEL_SIZE, INVENTORY_GOLD_LABEL_ORIGIN,
    INVENTORY_GOLD_LABEL_SIZE, INVENTORY_GRID_ORIGIN, INVENTORY_GRID_STEP, INVENTORY_PAGE_COLUMNS,
    INVENTORY_PAGE_SIZE, INVENTORY_PANEL_ORIGIN, INVENTORY_PANEL_SIZE, INVENTORY_WEIGHT_BAR_ORIGIN,
    INVENTORY_WEIGHT_BAR_SIZE, NPC_DIALOG_PANEL_SIZE, NPC_DROP_PANEL_ORIGIN, NPC_DROP_PANEL_SIZE,
    NPC_GOODS_PANEL_ORIGIN, NPC_GOODS_PANEL_SIZE, NPC_SERVICE_INVENTORY_ORIGIN,
    SKILL_PAGE_SIZE, SKILL_PANEL_SIZE, SKILL_ROW_ORIGIN, SKILL_ROW_SIZE,
    SKILL_ROW_STEP_Y,
};
use super::storage_password::{Command as StoragePasswordCommand, Prompt as StoragePasswordPrompt, Stage as StoragePasswordStage};
use super::spec::{CrystalButtonSpec, CrystalFrameSpec, CrystalRect};
use super::widget::{spawn_crystal_image_button, CrystalImageButton, CrystalItemHint};

#[cfg(test)]
#[path = "guild_storage_tests.rs"]
mod guild_storage_tests;

#[cfg(test)]
#[path = "primary_item_image_tests.rs"]
mod primary_item_image_tests;

#[cfg(test)]
#[path = "options_volume_tests.rs"]
mod options_volume_tests;

#[path = "combat_mode_keys.rs"]
pub mod combat_mode_keys;
#[path = "creature_dialog.rs"]
pub mod creature_dialog;
#[path = "equipment_creature_host.rs"]
pub mod equipment_creature_host;
#[path = "friend_dialog.rs"]
pub mod friend_dialog;
#[path = "group_dialog.rs"]
pub mod group_dialog;
#[path = "guild_buff_dialog.rs"]
pub mod guild_buff_dialog;
#[path = "guild_panel.rs"]
pub mod guild_panel;
#[path = "hero_buff_hud.rs"]
pub mod hero_buff_hud;
#[path = "keyboard_dialog.rs"]
pub mod keyboard_dialog;
#[path = "leave_game_dialog.rs"]
pub mod leave_game_dialog;
#[cfg(test)]
#[path = "leave_game_input_tests.rs"]
mod leave_game_input_tests;
#[path = "mount_fishing_dialog.rs"]
pub mod mount_fishing_dialog;
#[path = "ranking_dialog.rs"]
pub mod ranking_dialog;
#[path = "skill_assign_dialog.rs"]
pub mod skill_assign_dialog;
#[path = "social_bond_dialog.rs"]
pub mod social_bond_dialog;
#[path = "status_hud.rs"]
pub mod status_hud;
#[path = "text_input.rs"]
pub mod text_input;
#[path = "trade_dialog.rs"]
mod trade_dialog;
pub use trade_dialog::TradeDialogUi;

const BIG_MAP_SEARCH_COOLDOWN_MS: u64 = 1_000;
const NPC_GOODS_CELL_WIDTH: f32 = 205.0;
const NPC_GOODS_CELL_HEIGHT: f32 = 32.0;
const NPC_GOODS_ICON_AREA_WIDTH: i32 = 40;
const NPC_GOODS_NEW_ICON_ASSET: &str = "original-ui/Prguse/550.png";

const CRYSTAL_ADDITIVE_UI_SHADER_HANDLE: Handle<Shader> =
    uuid_handle!("7842d484-2b55-4b54-989d-cda47cd4c40a");

/// Crystal `DXManager.SetBlend(true)` uses SourceAlpha + One for RGB. This
/// material keeps CharacterDialog's `Prguse2.DrawBlend` wing layer distinct
/// from the ordinary alpha-blended armour, weapon and hair images.
#[derive(AsBindGroup, Asset, TypePath, Debug, Clone)]
pub(crate) struct CrystalAdditiveUiMaterial {
    #[texture(0)]
    #[sampler(1)]
    pub(crate) image: Handle<Image>,
}

/// Hold the four immutable material handles across per-frame overlay rebuilds
/// so the render asset is not recreated before the GPU can prepare it.
#[derive(Resource)]
struct CrystalCharacterWingMaterials([Handle<CrystalAdditiveUiMaterial>; 4]);

impl CrystalCharacterWingMaterials {
    fn get(&self, index: u16) -> Option<&Handle<CrystalAdditiveUiMaterial>> {
        self.0.get(usize::from(index.checked_sub(1202)?))
    }
}

fn load_character_wing_materials(
    mut commands: Commands,
    asset_server: Res<AssetServer>,
    mut materials: ResMut<Assets<CrystalAdditiveUiMaterial>>,
) {
    commands.insert_resource(CrystalCharacterWingMaterials(std::array::from_fn(
        |offset| {
            materials.add(CrystalAdditiveUiMaterial {
                image: asset_server.load(format!("original-ui/Prguse2/{}.png", 1202 + offset)),
            })
        },
    )));
}

const CRYSTAL_DRAW_BLEND_STATE: BlendState = BlendState {
    color: BlendComponent {
        src_factor: BlendFactor::SrcAlpha,
        dst_factor: BlendFactor::One,
        operation: BlendOperation::Add,
    },
    alpha: BlendComponent::OVER,
};

impl UiMaterial for CrystalAdditiveUiMaterial {
    fn fragment_shader() -> ShaderRef {
        CRYSTAL_ADDITIVE_UI_SHADER_HANDLE.into()
    }

    fn specialize(descriptor: &mut RenderPipelineDescriptor, _key: UiMaterialKey<Self>) {
        if let Some(target) = descriptor
            .fragment
            .as_mut()
            .and_then(|fragment| fragment.targets.first_mut())
            .and_then(Option::as_mut)
        {
            target.blend = Some(CRYSTAL_DRAW_BLEND_STATE);
        }
    }
}

/// Both the login shell and in-game overlays use Crystal's DrawBlend path.
/// Register it once even when a renderer uses only the character preview UI.
pub(crate) fn register_crystal_additive_ui(app: &mut App) {
    if app.world().contains_resource::<AssetServer>()
        && app.world().contains_resource::<Assets<Shader>>()
        && !app.is_plugin_added::<UiMaterialPlugin<CrystalAdditiveUiMaterial>>()
    {
        load_internal_asset!(
            app,
            CRYSTAL_ADDITIVE_UI_SHADER_HANDLE,
            "crystal_additive_ui.wgsl",
            Shader::from_wgsl
        );
        app.add_plugins(UiMaterialPlugin::<CrystalAdditiveUiMaterial>::default());
    }
}

/// Overlay mutation must run before any `Res<NativePlayerUiState>` readers in
/// the same Update. Unordered Res + ResMut on this resource panics Bevy B0001.
#[derive(SystemSet, Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum NativePlayerUiSet {
    Mutate,
    Read,
}

const PANEL_BG: Color = Color::srgba(0.07, 0.05, 0.03, 0.94);
const TEXT: Color = Color::srgb(0.95, 0.92, 0.82);
const GOLD: Color = Color::srgb(0.94, 0.78, 0.28);
const BUTTON_BG: Color = Color::srgba(0.28, 0.18, 0.08, 0.95);
const BUTTON_DISABLED: Color = Color::srgba(0.30, 0.24, 0.16, 0.45);
const MAX_QUEUED: usize = 24;
const BAG_SLOTS: u32 = 46;
pub const HELP_PAGE_COUNT: u8 = 45;

/// Pages exposed by Crystal's CharacterDialog.  The page is local UI state;
/// values shown on each page still come from the authoritative read models.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum CharacterPage {
    #[default]
    Character,
    Stats1,
    Stats2,
    Spells,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum GuildLeftPage {
    #[default]
    Notice,
    Members,
    Storage,
    Ranks,
}

/// Renderer-owned Crystal HelpDialog state. It is intentionally independent
/// from `UiPanel`: the source client allows Help to coexist with other
/// windows, and hiding/reopening the dialog preserves the current page.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct HelpDialogUi {
    pub open: bool,
    pub page: u8,
    pub left: f32,
    pub top: f32,
    z_index: i32,
    dragging: bool,
    drag_offset_x: f32,
    drag_offset_y: f32,
}

/// Renderer-owned position for Crystal's movable InventoryDialog. The source
/// window starts at `(0,0)`, preserves its position across Hide/Show, and is
/// reconstructed at the origin only with a new game session.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct InventoryDialogUi {
    pub left: f32,
    pub top: f32,
    dragging: bool,
    drag_offset_x: f32,
    drag_offset_y: f32,
    last_cursor: Option<Vec2>,
}

impl Default for InventoryDialogUi {
    fn default() -> Self {
        Self {
            left: INVENTORY_PANEL_ORIGIN.x as f32,
            top: INVENTORY_PANEL_ORIGIN.y as f32,
            dragging: false,
            drag_offset_x: 0.0,
            drag_offset_y: 0.0,
            last_cursor: None,
        }
    }
}

impl InventoryDialogUi {
    pub fn dragging(&self) -> bool {
        self.dragging
    }

    fn begin_drag(&mut self, cursor_x: f32, cursor_y: f32) -> bool {
        if !inventory_drag_surface_contains(self, cursor_x, cursor_y) {
            return false;
        }
        self.dragging = true;
        self.drag_offset_x = cursor_x - self.left;
        self.drag_offset_y = cursor_y - self.top;
        true
    }

    fn drag_to(&mut self, cursor_x: f32, cursor_y: f32) {
        if !self.dragging {
            return;
        }
        self.left = (cursor_x - self.drag_offset_x).clamp(0.0, INVENTORY_MAX_LEFT);
        self.top = (cursor_y - self.drag_offset_y).clamp(0.0, INVENTORY_MAX_TOP);
    }

    fn end_drag(&mut self) {
        self.dragging = false;
        self.drag_offset_x = 0.0;
        self.drag_offset_y = 0.0;
    }

    fn remember_cursor(&mut self, cursor: Option<Vec2>) {
        if let Some(cursor) = cursor {
            self.last_cursor = Some(cursor);
        }
    }

    fn clear_cursor(&mut self) {
        self.last_cursor = None;
    }
}

impl Default for HelpDialogUi {
    fn default() -> Self {
        Self {
            open: false,
            page: 0,
            left: CRYSTAL_HELP_PANEL_RECT.left,
            top: CRYSTAL_HELP_PANEL_RECT.top,
            z_index: OVERLAY_NPC_DIALOG_Z,
            dragging: false,
            drag_offset_x: 0.0,
            drag_offset_y: 0.0,
        }
    }
}

impl HelpDialogUi {
    pub fn toggle(&mut self) {
        if self.open {
            self.hide();
        } else {
            self.show();
        }
    }

    fn show(&mut self) {
        self.open = true;
        self.sort_to_front();
    }

    pub fn hide(&mut self) {
        self.open = false;
        self.end_drag();
    }

    pub fn previous_page(&mut self) {
        self.page = if self.page == 0 {
            HELP_PAGE_COUNT - 1
        } else {
            self.page - 1
        };
    }

    pub fn next_page(&mut self) {
        self.page = (self.page + 1) % HELP_PAGE_COUNT;
    }

    pub fn display_page(&mut self, page: usize) {
        self.page = page.min(usize::from(HELP_PAGE_COUNT - 1)) as u8;
        self.show();
    }

    pub fn dragging(&self) -> bool {
        self.dragging
    }

    fn begin_drag(&mut self, cursor_x: f32, cursor_y: f32) -> bool {
        if !self.open || !help_drag_surface_contains(self, cursor_x, cursor_y) {
            return false;
        }
        self.dragging = true;
        self.drag_offset_x = cursor_x - self.left;
        self.drag_offset_y = cursor_y - self.top;
        self.sort_to_front();
        true
    }

    fn drag_to(&mut self, cursor_x: f32, cursor_y: f32) {
        if !self.dragging {
            return;
        }
        self.left = (cursor_x - self.drag_offset_x).clamp(0.0, HELP_MAX_LEFT);
        self.top = (cursor_y - self.drag_offset_y).clamp(0.0, HELP_MAX_TOP);
    }

    fn end_drag(&mut self) {
        self.dragging = false;
        self.drag_offset_x = 0.0;
        self.drag_offset_y = 0.0;
    }

    fn sort_to_front(&mut self) {
        self.z_index = OVERLAY_HELP_SORTED_Z;
    }

    fn z_index(&self) -> i32 {
        self.z_index
    }
}

pub const BIGMAP_ZOOM_MIN: f32 = 0.5;
pub const BIGMAP_ZOOM_MAX: f32 = 3.0;
pub const BIGMAP_ZOOM_STEP: f32 = 0.25;
pub const BIGMAP_WIDTH: f32 = 568.0;
pub const BIGMAP_HEIGHT: f32 = 380.0;
pub const CRYSTAL_MENU_PANEL_RECT: CrystalRect = CrystalRect::new(988.0, 349.0, 36.0, 282.0);
pub const CRYSTAL_OPTIONS_PANEL_RECT: CrystalRect = CrystalRect::new(382.0, 207.0, 259.0, 354.0);
pub const CRYSTAL_BIGMAP_PANEL_RECT: CrystalRect = CrystalRect::new(132.0, 134.0, 760.0, 500.0);
pub const CRYSTAL_GROUP_PANEL_RECT: CrystalRect = CrystalRect::new(396.0, 259.0, 232.0, 249.0);
pub const CRYSTAL_GUILD_PANEL_RECT: CrystalRect = CrystalRect::new(217.0, 168.0, 590.0, 432.0);
pub const CRYSTAL_HELP_PANEL_RECT: CrystalRect = CrystalRect::new(244.0, 129.0, 536.0, 509.0);
/// `CharacterDialog.Location = (ScreenWidth - 264, 0)` at Crystal's fixed
/// 1024x768 stage.
pub const CRYSTAL_CHARACTER_PANEL_RECT: CrystalRect = CrystalRect::new(760.0, 0.0, 264.0, 380.0);
const CRYSTAL_CHARACTER_PAGE_RECT: CrystalRect = CrystalRect::new(8.0, 90.0, 248.0, 284.0);
// CharacterDialog.cs:229-348 uses MirItemCell's default 36x32 hit size.
const CRYSTAL_CHARACTER_EQUIPMENT_SLOTS: [(u32, CrystalRect); 14] = [
    (0, CrystalRect::new(131.0, 97.0, 36.0, 32.0)),
    (1, CrystalRect::new(171.0, 97.0, 36.0, 32.0)),
    (2, CrystalRect::new(211.0, 97.0, 36.0, 32.0)),
    (13, CrystalRect::new(211.0, 152.0, 36.0, 32.0)),
    (4, CrystalRect::new(211.0, 188.0, 36.0, 32.0)),
    (3, CrystalRect::new(211.0, 224.0, 36.0, 32.0)),
    (5, CrystalRect::new(16.0, 260.0, 36.0, 32.0)),
    (6, CrystalRect::new(211.0, 260.0, 36.0, 32.0)),
    (7, CrystalRect::new(16.0, 296.0, 36.0, 32.0)),
    (8, CrystalRect::new(211.0, 296.0, 36.0, 32.0)),
    (9, CrystalRect::new(16.0, 332.0, 36.0, 32.0)),
    (11, CrystalRect::new(56.0, 332.0, 36.0, 32.0)),
    (10, CrystalRect::new(96.0, 332.0, 36.0, 32.0)),
    (12, CrystalRect::new(136.0, 332.0, 36.0, 32.0)),
];
const CRYSTAL_MALE_HAIR_RECTS: [CrystalRect; 9] = [
    CrystalRect::new(131.0, 173.0, 16.0, 14.0),
    CrystalRect::new(127.0, 170.0, 20.0, 33.0),
    CrystalRect::new(127.0, 174.0, 24.0, 16.0),
    CrystalRect::new(118.0, 157.0, 36.0, 37.0),
    CrystalRect::new(118.0, 157.0, 36.0, 37.0),
    CrystalRect::new(118.0, 157.0, 36.0, 37.0),
    CrystalRect::new(128.0, 173.0, 20.0, 23.0),
    CrystalRect::new(128.0, 173.0, 20.0, 23.0),
    CrystalRect::new(128.0, 173.0, 20.0, 22.0),
];
const CRYSTAL_ASSASSIN_MALE_HAIR_RECTS: [CrystalRect; 9] = [
    CrystalRect::new(125.0, 147.0, 16.0, 21.0),
    CrystalRect::new(120.0, 146.0, 28.0, 31.0),
    CrystalRect::new(118.0, 150.0, 28.0, 26.0),
    CrystalRect::new(104.0, 126.0, 44.0, 46.0),
    CrystalRect::new(104.0, 126.0, 44.0, 46.0),
    CrystalRect::new(104.0, 126.0, 44.0, 46.0),
    CrystalRect::new(123.0, 149.0, 20.0, 26.0),
    CrystalRect::new(123.0, 149.0, 20.0, 26.0),
    CrystalRect::new(123.0, 149.0, 20.0, 26.0),
];
const CRYSTAL_FEMALE_HAIR_RECTS: [CrystalRect; 9] = [
    CrystalRect::new(126.0, 171.0, 24.0, 25.0),
    CrystalRect::new(128.0, 171.0, 20.0, 24.0),
    CrystalRect::new(116.0, 160.0, 40.0, 38.0),
    CrystalRect::new(126.0, 161.0, 28.0, 29.0),
    CrystalRect::new(126.0, 161.0, 28.0, 29.0),
    CrystalRect::new(126.0, 161.0, 28.0, 29.0),
    CrystalRect::new(116.0, 167.0, 44.0, 31.0),
    CrystalRect::new(116.0, 167.0, 44.0, 31.0),
    CrystalRect::new(118.0, 168.0, 40.0, 30.0),
];
const CRYSTAL_ASSASSIN_FEMALE_HAIR_RECTS: [CrystalRect; 9] = [
    CrystalRect::new(122.0, 156.0, 24.0, 24.0),
    CrystalRect::new(125.0, 155.0, 20.0, 23.0),
    CrystalRect::new(122.0, 149.0, 24.0, 32.0),
    CrystalRect::new(122.0, 139.0, 32.0, 37.0),
    CrystalRect::new(122.0, 139.0, 32.0, 37.0),
    CrystalRect::new(122.0, 139.0, 32.0, 37.0),
    CrystalRect::new(114.0, 149.0, 40.0, 33.0),
    CrystalRect::new(114.0, 149.0, 40.0, 33.0),
    CrystalRect::new(114.0, 149.0, 40.0, 33.0),
];
const CRYSTAL_HELP_DRAG_HEADER_RECT: CrystalRect = CrystalRect::new(0.0, 0.0, 509.0, 35.0);
const CRYSTAL_HELP_TITLE_RECT: CrystalRect = CrystalRect::new(18.0, 9.0, 45.0, 14.0);
const HELP_MAX_LEFT: f32 = 1024.0 - CRYSTAL_HELP_PANEL_RECT.width - 1.0;
const HELP_MAX_TOP: f32 = 768.0 - CRYSTAL_HELP_PANEL_RECT.height - 1.0;
const INVENTORY_MAX_LEFT: f32 = 1024.0 - INVENTORY_PANEL_SIZE.width as f32 - 1.0;
const INVENTORY_MAX_TOP: f32 = 768.0 - INVENTORY_PANEL_SIZE.height as f32 - 1.0;
const CRYSTAL_INVENTORY_TAB_RECTS: [CrystalRect; 3] = [
    CrystalRect::new(6.0, 7.0, 72.0, 23.0),
    CrystalRect::new(76.0, 7.0, 72.0, 23.0),
    CrystalRect::new(146.0, 7.0, 72.0, 23.0),
];
const CRYSTAL_INVENTORY_ADD_RECT: CrystalRect = CrystalRect::new(235.0, 5.0, 72.0, 23.0);
const CRYSTAL_INVENTORY_CLOSE_RECT: CrystalRect = CrystalRect::new(289.0, 3.0, 24.0, 21.0);

fn help_drag_surface_contains(help: &HelpDialogUi, cursor_x: f32, cursor_y: f32) -> bool {
    let local_x = cursor_x - help.left;
    let local_y = cursor_y - help.top;
    CRYSTAL_HELP_DRAG_HEADER_RECT.contains(local_x, local_y)
        && !CRYSTAL_HELP_TITLE_RECT.contains(local_x, local_y)
}

/// MirControl sends a press to the deepest child under the cursor. Therefore
/// InventoryDialog moves only from exposed background pixels: tabs, cells and
/// footer controls consume their own presses while the one-pixel cell gutters
/// and other frame areas continue to drag the parent.
fn inventory_drag_surface_contains(
    inventory: &InventoryDialogUi,
    cursor_x: f32,
    cursor_y: f32,
) -> bool {
    let local_x = cursor_x - inventory.left;
    let local_y = cursor_y - inventory.top;
    let local = CrystalRect::new(
        0.0,
        0.0,
        INVENTORY_PANEL_SIZE.width as f32,
        INVENTORY_PANEL_SIZE.height as f32,
    );
    if !local.contains(local_x, local_y)
        || CRYSTAL_INVENTORY_TAB_RECTS
            .iter()
            .any(|rect| rect.contains(local_x, local_y))
        || CRYSTAL_INVENTORY_ADD_RECT.contains(local_x, local_y)
        || CRYSTAL_INVENTORY_CLOSE_RECT.contains(local_x, local_y)
        || CrystalRect::new(
            INVENTORY_GOLD_LABEL_ORIGIN.x as f32,
            INVENTORY_GOLD_LABEL_ORIGIN.y as f32,
            INVENTORY_GOLD_LABEL_SIZE.width as f32,
            INVENTORY_GOLD_LABEL_SIZE.height as f32,
        )
        .contains(local_x, local_y)
        || CrystalRect::new(
            INVENTORY_FREE_SLOT_LABEL_ORIGIN.x as f32,
            INVENTORY_FREE_SLOT_LABEL_ORIGIN.y as f32,
            INVENTORY_FREE_SLOT_LABEL_SIZE.width as f32,
            INVENTORY_FREE_SLOT_LABEL_SIZE.height as f32,
        )
        .contains(local_x, local_y)
        || CrystalRect::new(
            INVENTORY_DELETE_BUTTON_ORIGIN.x as f32,
            INVENTORY_DELETE_BUTTON_ORIGIN.y as f32,
            INVENTORY_DELETE_BUTTON_SIZE.width as f32,
            INVENTORY_DELETE_BUTTON_SIZE.height as f32,
        )
        .contains(local_x, local_y)
    {
        return false;
    }

    !(0..INVENTORY_PAGE_SIZE).any(|slot| {
        let x = INVENTORY_GRID_ORIGIN.x as f32
            + (slot % INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.x as f32;
        let y = INVENTORY_GRID_ORIGIN.y as f32
            + (slot / INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.y as f32;
        CrystalRect::new(
            x,
            y,
            INVENTORY_CELL_SIZE.width as f32,
            INVENTORY_CELL_SIZE.height as f32,
        )
        .contains(local_x, local_y)
    })
}

fn help_cursor_logical(window: &Window) -> Option<Vec2> {
    let cursor = window.cursor_position()?;
    Some(cursor_logical(window, cursor))
}

fn cursor_logical(window: &Window, cursor: Vec2) -> Vec2 {
    let transform = super::metrics::CrystalStageTransform::fit_native(
        window.resolution.width(),
        window.resolution.height(),
    );
    let (x, y) = transform.physical_to_logical(cursor.x, cursor.y);
    Vec2::new(x, y)
}

// Re-export shop/storage constants for external consumers that import via overlays.
pub use crate::shop::{SHOP_QUANTITY_MAX, SHOP_QUANTITY_MIN, SHOP_QUANTITY_STEP};
pub use crate::storage::{STORAGE_BASE_SIZE, STORAGE_EXPANDED_SIZE, STORAGE_EXPAND_COST};

// ---------------------------------------------------------------------------
// Item inspect
// ---------------------------------------------------------------------------
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ItemInspect {
    pub container: u8,
    pub slot: u32,
    pub key: String,
    pub name: String,
    pub quantity: u32,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InventoryOperationDraft {
    Move { source_slot: u32, unique_id: u64 },
    Merge { source_slot: u32, unique_id: u64 },
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) struct InventoryItemDrag {
    source_slot: u32,
    unique_id: u64,
    start: Vec2,
}

#[derive(Resource, Debug, Clone, Copy)]
struct InventoryBeltDiagnostics(bool);

#[derive(Default, Resource)]
struct StorageInventoryPlacement {
    was_open: bool,
}

impl FromWorld for InventoryBeltDiagnostics {
    fn from_world(_world: &mut World) -> Self {
        Self(std::env::var_os("MIR2_BELT_DIAGNOSTICS").is_some())
    }
}

fn belt_diagnostic(
    diagnostics: Option<&InventoryBeltDiagnostics>,
    message: impl FnOnce() -> String,
) {
    if diagnostics.is_some_and(|diagnostics| diagnostics.0) {
        eprintln!("[belt-diagnostics] {}", message());
    }
}

/// Exact bag-instance identity captured when Crystal opens its destructive
/// delete prompt.  The live inventory snapshot must still contain this same
/// stack before the native client is allowed to emit `DeleteItem`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InventoryDeleteTarget {
    unique_id: u64,
    slot: u32,
    key: String,
    name: String,
    max_count: u16,
}

/// Renderer-owned state for Crystal's two delete prompt shapes:
/// `MirAmountBox` for a stack and `MirMessageBox(YesNo)` for one item.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum InventoryDeletePrompt {
    Amount {
        target: InventoryDeleteTarget,
        draft: String,
        /// Crystal selects the initial maximum value, so the first typed digit
        /// replaces it instead of appending to it.
        select_all: bool,
    },
    Confirm {
        target: InventoryDeleteTarget,
    },
}

impl InventoryDeletePrompt {
    fn target(&self) -> &InventoryDeleteTarget {
        match self {
            Self::Amount { target, .. } | Self::Confirm { target } => target,
        }
    }
}

/// A destructive bag-drop must be confirmed against the latest authoritative
/// inventory snapshot.  Keeping the exact instance id, slot, and quantity
/// prevents a stale confirmation from dropping a replacement stack.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct InventoryDropConfirmation {
    key: String,
    unique_id: u64,
    slot: u32,
    count: u16,
}

pub fn bigmap_zoom_clamped(zoom: f32) -> f32 {
    zoom.clamp(BIGMAP_ZOOM_MIN, BIGMAP_ZOOM_MAX)
}

pub fn bigmap_zoom_in(zoom: f32) -> f32 {
    bigmap_zoom_clamped(zoom + BIGMAP_ZOOM_STEP)
}

pub fn bigmap_zoom_out(zoom: f32) -> f32 {
    bigmap_zoom_clamped(zoom - BIGMAP_ZOOM_STEP)
}

fn guild_notice_lines(draft: &str) -> Vec<String> {
    if draft.is_empty() {
        return Vec::new();
    }
    draft
        .split('\n')
        .map(|line| line.trim_end_matches('\r').to_owned())
        .collect()
}

fn valid_social_name(name: &str) -> bool {
    let trimmed = name.trim();
    !trimmed.is_empty()
        && trimmed == name
        && trimmed.chars().count() <= 32
        && trimmed.chars().all(|ch| !ch.is_control())
}

fn push_social_name_text(draft: &mut String, text: &str) {
    for ch in text.chars() {
        if !ch.is_control() && draft.chars().count() < 32 {
            draft.push(ch);
        }
    }
}

fn social_has_permission(guild: &crate::social::GuildModel, key: &str) -> bool {
    guild.permissions.iter().any(|permission| {
        let without_can = permission
            .get(..3)
            .filter(|prefix| prefix.eq_ignore_ascii_case("can"))
            .and_then(|_| permission.get(3..));
        permission.eq_ignore_ascii_case(key)
            || without_can.is_some_and(|permission| permission.eq_ignore_ascii_case(key))
            || (key.eq_ignore_ascii_case("notice")
                && (permission.eq_ignore_ascii_case("changeNotice")
                    || permission.eq_ignore_ascii_case("CanChangeNotice")))
            || (key.eq_ignore_ascii_case("changeRank")
                && (permission.eq_ignore_ascii_case("rank")
                    || permission.eq_ignore_ascii_case("CanChangeRank")))
    })
}

fn queue_group_invite_by_name(
    intents: &mut NativePlayerUiIntentQueue,
    social: &mut crate::social::SocialModel,
    name: String,
) -> bool {
    if !valid_social_name(&name) {
        return false;
    }
    let add = NativePlayerUiIntent::GroupAddMember { name: name.clone() };
    if intents.intents.iter().any(|queued| queued == &add) {
        return false;
    }
    let enable = NativePlayerUiIntent::GroupSwitch { allow_group: true };
    let needs_enable =
        !social.group.allow_invites && !intents.intents.iter().any(|queued| queued == &enable);
    let required = usize::from(needs_enable) + 1;
    if intents.intents.len().saturating_add(required) > MAX_QUEUED
        || !social
            .begin_pending(crate::social::SocialPendingOperation::GroupAdd { name: name.clone() })
    {
        return false;
    }
    if needs_enable {
        intents.intents.push_back(enable);
    }
    intents.intents.push_back(add);
    true
}

#[derive(Debug, Clone, Resource, PartialEq)]
pub struct NativePlayerUiState {
    /// The single authoritative core UI state used by the native adapter.
    /// `quest_ui` reads and writes this same field; it does not own another
    /// `UiState` resource.
    pub core: mir2_ui_core::state::UiState,
    pub bigmap_zoom: f32,
    pub chat_draft: String,
    pub inspect: Option<ItemInspect>,
    pub shop_quantity: u16,
    /// A dragged NPC sale mirrors Crystal TargetItem.Count. Direct picker
    /// selection continues to use the explicit quantity control.
    pub shop_service_drag_count: Option<u16>,
    /// The source instance retained by an NPC service drag until its Confirm
    /// reaches the outbound queue. A slot replacement must not be retargeted.
    pub shop_service_drag_unique_id: Option<u64>,
    /// Crystal's InventoryDialog stays independently closable while
    /// NPCDropDialog remains visible.
    pub npc_inventory_hidden: bool,
    /// `MailComposeParcelDialog.ComposeMail` explicitly shows the ordinary
    /// bag beside its own source frame without replacing the Mail panel.
    pub(crate) mail_inventory_visible: bool,
    /// Local presentation tab for an NPC service that advertises both Buy
    /// and Sell. Capabilities remain authoritative in `ShopModel`.
    pub npc_shop_buy_tab: bool,
    /// An accepted local @Exit closes the NPC service even when its text page
    /// was already hidden by a service-only server snapshot.
    pub(crate) npc_service_exit_requested: bool,
    /// Reject delayed service replies until a new NPC page/request begins.
    pub(crate) npc_service_exit_latched: bool,
    /// Crystal Hold auto-submits the next selection in this service only.
    pub npc_service_hold: Option<NpcShopServiceMode>,
    /// A locally rejected NPC service attempt waits for the System chat
    /// bridge. Rendering never consumes or repeats this feedback.
    pub npc_service_notice: Option<String>,
    /// The service that produced the pending feedback. A later service mode
    /// invalidates it before the player sees a stale rejection.
    pub npc_service_notice_mode: Option<NpcShopServiceMode>,
    pub shop_repair_mode: bool,
    /// Repair selection is a `(container, slot)` pair. The emitted command
    /// still carries the authoritative unique id, so bag slot 3 cannot be
    /// mistaken for equipment slot 3.
    pub shop_repair_container: u8,
    pub shop_repair_slot: Option<u32>,
    /// Bounded cash-shop page; keeps the native panel usable while every
    /// server catalog row remains reachable.
    pub game_shop_page: usize,
    pub game_shop_dialog: game_shop_dialog::GameShopDialogUi,
    pub split_count: u16,
    pub inventory_operation: Option<InventoryOperationDraft>,
    pub(crate) inventory_item_drag: Option<InventoryItemDrag>,
    /// StorageDialog can coexist with CharacterDialog. Keep this host-local
    /// visibility bit separate from the exclusive core panel so both source
    /// frames remain reachable without replacing the warehouse.
    pub(crate) storage_equipment_visible: bool,
    pub(crate) equipment_item_drag: Option<EquipmentItemDrag>,
    pub(crate) inventory_item_pointer_consumed: bool,
    pub selected_skill_id: Option<u32>,
    pub character_page: CharacterPage,
    pub inventory_page: u8,
    pub skill_page: usize,
    pub drop_confirmation: Option<InventoryDropConfirmation>,
    /// Crystal InventoryDialog's persistent footer-bin toggle.  This is
    /// presentation state only; deleting still requires an exact prompt and
    /// an authoritative server acknowledgement.
    pub inventory_delete_mode: bool,
    pub inventory_delete_prompt: Option<InventoryDeletePrompt>,
    /// MailDialog's source Yes/No warning for a parcel that still contains
    /// item rows or gold. Its identity is rechecked on the eventual Yes.
    pub(crate) mail_delete_prompt: Option<MailDeletePrompt>,
    /// A prompt closing on Enter/Escape/Yes/No consumes the remainder of that
    /// input frame so covered mail or world controls cannot receive it.
    pub(crate) mail_delete_input_consumed: bool,
    /// Result and validation feedback uses Crystal's modal message frame.
    /// Keeping this in the native state lets the shared input guards block
    /// movement and covered controls while it is visible.
    pub(crate) mail_feedback_prompt: Option<String>,
    pub(crate) mail_feedback_input_consumed: bool,
    /// The source MailDialog Write route asks for a recipient before opening
    /// MailComposeLetterDialog. These flags protect raw drag systems through
    /// the same close frame as the visible MirInputBox.
    pub(crate) mail_recipient_prompt_active: bool,
    pub(crate) mail_recipient_input_consumed: bool,
    /// External source controls (friend, inspect, and bond windows) queue a
    /// recipient here; the overlay owns the safe Letter/Parcel transition.
    pub(crate) queued_mail_letter_recipient: Option<String>,
    /// The source reader is keyed by the authoritative MailID, rather than a
    /// list row. Refreshes therefore cannot retarget a reader action.
    pub(crate) mail_reader: Option<MailReaderUi>,
    pub(crate) mail_reader_windows: mail_reader_drag::ReaderWindows,
    /// Close/Escape/read actions consume their input frame after dismissing a
    /// reader so covered MailDialog or world controls cannot receive it.
    pub(crate) mail_reader_input_consumed: bool,
    pub inventory_window: InventoryDialogUi,
    pub selected_group_member: Option<u8>,
    /// Crystal's group window accepts a player name independently of the
    /// current combat target.  This renderer-owned draft is bounded and is
    /// never copied into the authoritative social model.
    pub group_invite_draft: String,
    pub group_invite_focused: bool,
    pub selected_guild_member: Option<u8>,
    /// Same boundary for guild recruitment: local text until one typed
    /// EditGuildMember request is accepted by the outbound queue.
    pub guild_recruit_draft: String,
    pub guild_recruit_focused: bool,
    pub guild_gold_prompt: Option<GuildGoldPrompt>,
    /// MailComposeParcelDialog's GiftGoldButton opens the existing source
    /// MirAmountBox primitive. The amount remains a draft reservation only.
    pub(crate) parcel_gold_prompt: Option<CrystalAmountInput>,
    pub(crate) parcel_gold_input_consumed: bool,
    pub trade_dialog: TradeDialogUi,
    pub menu_pointer_consumed: bool,
    pub menu_hit_regions: Vec<CrystalRect>,
    pub equipment_dialogs: mount_fishing_dialog::MountFishingUi,
    pub creature: creature_dialog::CreatureUi,
    pub ranking: ranking_dialog::RankingDialogUi,
    pub friends: friend_dialog::FriendDialogUi,
    pub guild_panel: guild_panel::GuildPanelUi,
    pub group_dialog: group_dialog::GroupDialogUi,
    pub skill_assign: skill_assign_dialog::SkillAssignUi,
    pub local_keys: local_keyboard_ui::LocalKeyboardUi,
    pub ime_frame_consumed: bool,
    pub status_hud: status_hud::StatusHud,
    pub hero_buffs: hero_buff_hud::HeroBuffHud,
    pub skill_bars: skill_bars::SkillBarsUi,
    pub hero: hero_dialog::HeroDialogModel,
    pub combat_modes: combat_mode_keys::CombatModes,
    pub skill_authority: skill_assign_dialog::SkillAuthorityUi,
    pub leave_game: leave_game_dialog::LeaveGameDialog,
    pub social_bonds: social_bond_dialog::SocialBondDialogs,
    pub keyboard: keyboard_dialog::KeyboardDialogUi,
    pub guild_gold_ready_at_ms: u64,
    pub guild_storage: GuildStorageUi,
    pub selected_guild_rank: Option<u8>,
    pub guild_rank_name_draft: String,
    pub guild_rank_name_focused: bool,
    pub guild_left_page: GuildLeftPage,
    /// Renderer-owned Guild Notice editor. The authoritative notice remains
    /// in `SocialModel`; this draft is never copied there optimistically.
    pub guild_notice_editing: bool,
    pub guild_notice_draft: String,
    pub guild_notice_submission: Option<Vec<String>>,
    /// StorageDialog owns a sequential MirInputBox workflow. Credentials stay
    /// inside this renderer state until one server request is accepted.
    pub(crate) storage_password_prompt: Option<StoragePasswordPrompt>,
    /// A submit/cancel must consume the rest of its input frame even after it
    /// closes the prompt, so Enter/Escape cannot reach chat or world controls.
    pub(crate) storage_password_input_consumed: bool,
    /// StorageDialog's Rent control first opens the source OK/Cancel prompt.
    /// The eventual request stays pending-authoritative; this is not an
    /// optimistic rental state.
    pub(crate) storage_rental_confirmation: Option<StorageRentalConfirmation>,
    /// Consume the remainder of a confirmation frame after closing it so
    /// Enter/Escape and covered controls cannot leak into the world.
    pub(crate) storage_rental_input_consumed: bool,
    pub help: HelpDialogUi,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum MailComposeFocus {
    #[default]
    Recipient,
    Message,
    Gold,
}

/// Crystal has independent letter and parcel compose dialogs. Both retain
/// isolated drafts while the native parcel service owns postage and locks.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum MailComposeKind {
    #[default]
    Letter,
    Parcel,
}

#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub(crate) struct MailRecipientPrompt {
    recipient: String,
    target_kind: MailComposeKind,
    /// An NPC `MailSendRequest` has no MailDialog parent. Its cancelled
    /// recipient box must not leave the native list adapter newly visible.
    close_parent_on_cancel: bool,
    suspended_kind: MailComposeKind,
    suspended_draft: Option<mir2_ui_core::state::MailComposeDraft>,
}

#[derive(Debug, Clone, Default, Resource, PartialEq, Eq)]
pub struct MailComposeUi {
    pub focus: MailComposeFocus,
    pub kind: MailComposeKind,
    pub(crate) recipient_prompt: Option<MailRecipientPrompt>,
    letter_draft: Option<mir2_ui_core::state::MailComposeDraft>,
    parcel_draft: Option<mir2_ui_core::state::MailComposeDraft>,
    /// Changes whenever an active draft instance is restored or selected.
    /// Async text reads bind to this rather than treating equal body text as identity.
    draft_epoch: u64,
    pub last_notice: Option<String>,
}

fn show_mail_feedback(
    state: &mut NativePlayerUiState,
    compose: &mut MailComposeUi,
    message: impl Into<String>,
) {
    let message = message.into();
    compose.last_notice = Some(message.clone());
    state.mail_feedback_prompt = Some(message);
}

fn clear_mail_feedback(state: &mut NativePlayerUiState, compose: &mut MailComposeUi) {
    state.mail_feedback_prompt = None;
    state.mail_feedback_input_consumed = false;
    compose.last_notice = None;
}

fn clear_mail_recipient_prompt(state: &mut NativePlayerUiState, compose: &mut MailComposeUi) {
    compose.recipient_prompt = None;
    state.mail_recipient_prompt_active = false;
}

fn letter_draft(mut draft: mir2_ui_core::state::MailComposeDraft) -> mir2_ui_core::state::MailComposeDraft {
    // LetterDialog has no gold or item controls. Never retain an adapter-only
    // parcel payload where the Letter surface cannot show it.
    draft.gold = 0;
    draft.attachment_unique_ids.clear();
    draft
}

impl MailComposeUi {
    pub(crate) fn draft_epoch(&self) -> u64 {
        self.draft_epoch
    }

    fn advance_draft_epoch(&mut self) {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
        self.draft_epoch = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
    }
}

fn store_active_mail_draft(state: &mut NativePlayerUiState, compose: &mut MailComposeUi) {
    let Some(draft) = state.core.mail_compose.take() else {
        return;
    };
    match compose.kind {
        MailComposeKind::Letter => compose.letter_draft = Some(letter_draft(draft)),
        MailComposeKind::Parcel => compose.parcel_draft = Some(draft),
    }
}

fn activate_mail_compose(
    state: &mut NativePlayerUiState,
    compose: &mut MailComposeUi,
    effects: &mut UiEffectQueue,
    kind: MailComposeKind,
) {
    store_active_mail_draft(state, compose);
    compose.kind = kind;
    state.core.mail_compose = match kind {
        MailComposeKind::Letter => compose.letter_draft.take().map(letter_draft),
        MailComposeKind::Parcel => compose.parcel_draft.take(),
    };
    compose.advance_draft_epoch();
    dispatch_ui_action(
        &mut state.core,
        effects,
        mir2_ui_core::action::UiAction::OpenMailCompose,
    );
}

fn begin_mail_recipient_prompt_for(
    state: &mut NativePlayerUiState,
    compose: &mut MailComposeUi,
    target_kind: MailComposeKind,
) {
    begin_mail_recipient_prompt_with_parent(state, compose, target_kind, false);
}

fn begin_mail_recipient_prompt_with_parent(
    state: &mut NativePlayerUiState,
    compose: &mut MailComposeUi,
    target_kind: MailComposeKind,
    close_parent_on_cancel: bool,
) {
    let suspended_kind = compose.kind;
    let suspended_draft = state.core.mail_compose.take();
    compose.recipient_prompt = Some(MailRecipientPrompt {
        recipient: String::new(),
        target_kind,
        close_parent_on_cancel,
        suspended_kind,
        suspended_draft,
    });
    compose.last_notice = None;
    state.mail_recipient_prompt_active = true;
}

fn cancel_mail_recipient_prompt(state: &mut NativePlayerUiState, compose: &mut MailComposeUi) {
    if let Some(prompt) = compose.recipient_prompt.take() {
        compose.kind = prompt.suspended_kind;
        state.core.mail_compose = prompt.suspended_draft;
        compose.advance_draft_epoch();
        if prompt.close_parent_on_cancel {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
            state.mail_inventory_visible = false;
        }
    }
    state.mail_recipient_prompt_active = false;
    state.mail_recipient_input_consumed = true;
}

fn confirm_mail_recipient_prompt(
    state: &mut NativePlayerUiState,
    compose: &mut MailComposeUi,
    effects: &mut UiEffectQueue,
) -> bool {
    let Some(prompt) = compose.recipient_prompt.as_ref().cloned() else {
        return false;
    };
    let recipient = prompt.recipient.trim().to_owned();
    if recipient.is_empty() {
        compose.last_notice = Some("Recipient is required".to_owned());
        return false;
    }
    compose.recipient_prompt = None;
    state.mail_recipient_prompt_active = false;
    if let Some(draft) = prompt.suspended_draft {
        match prompt.suspended_kind {
            MailComposeKind::Letter => compose.letter_draft = Some(letter_draft(draft)),
            MailComposeKind::Parcel => compose.parcel_draft = Some(draft),
        }
    }
    activate_mail_compose(state, compose, effects, prompt.target_kind);
    dispatch_ui_action(
        &mut state.core,
        effects,
        mir2_ui_core::action::UiAction::SetMailRecipient { recipient },
    );
    compose.focus = MailComposeFocus::Message;
    if prompt.target_kind == MailComposeKind::Parcel {
        state.mail_inventory_visible = true;
    }
    compose.last_notice = None;
    state.mail_recipient_input_consumed = true;
    true
}

fn process_queued_mail_letter_request(
    mut state: ResMut<NativePlayerUiState>,
    mut compose: ResMut<MailComposeUi>,
    mut pending: ResMut<PendingOperations>,
    mut effects: Option<ResMut<UiEffectQueue>>,
) {
    let Some(recipient) = state.queued_mail_letter_recipient.take() else {
        return;
    };
    if pending.has_pending_mail_operation() {
        compose.last_notice = Some("Sending mail…".to_owned());
        return;
    }
    let mut fallback = UiEffectQueue::default();
    let effects = effects.as_deref_mut().unwrap_or(&mut fallback);
    activate_mail_compose(&mut state, &mut compose, effects, MailComposeKind::Letter);
    dispatch_ui_action(
        &mut state.core,
        effects,
        mir2_ui_core::action::UiAction::SetMailRecipient { recipient },
    );
    compose.focus = MailComposeFocus::Message;
    clear_mail_recipient_prompt(&mut state, &mut compose);
    clear_mail_feedback(&mut state, &mut compose);
}

/// Renderer-only state for the Crystal BigMap search field. Authoritative map,
/// NPC, search result and teleport eligibility remain in [`BigMapModel`].
#[derive(Debug, Clone, Default, Resource, PartialEq, Eq)]
pub struct BigMapUiState {
    pub search_focused: bool,
    bichon_safe_destination: bool,
    hunt_regions: Vec<crate::quest_hunt_regions::QuestHuntRegion>,
    last_reset_epoch: Option<u64>,
    requested_epoch_map: Option<(u64, i32)>,
}

#[derive(Debug, Clone, Default, Resource, PartialEq, Eq)]
pub struct MailUiState {
    pub cursor: MailPageCursor,
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct StorageItemDrag {
    source_slot: u32,
    unique_id: u64,
    start: Vec2,
}

/// Crystal's MailDialog warns before discarding a parcel with an attachment.
/// Capture the attachment snapshot so a late Yes cannot delete a refreshed
/// message whose contents changed while the source MirMessageBox was open.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct MailDeletePrompt {
    mail_id: u64,
    gold: u32,
    items: Vec<MailAttachment>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum MailReaderKind {
    Letter,
    Parcel,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct MailReaderUi {
    mail_id: u64,
    kind: MailReaderKind,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub(crate) struct EquipmentItemDrag {
    source_slot: u32,
    unique_id: u64,
    start: Vec2,
}

/// Crystal's Rent click distinguishes a first rental from a renewal only in
/// its confirmation message; both submit the same `@ADDSTORAGE` request.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct StorageRentalConfirmation {
    renew: bool,
}

impl StorageRentalConfirmation {
    fn from_storage(storage: &StorageModel) -> Self {
        Self { renew: storage.has_expanded }
    }

    fn message(self) -> &'static str {
        if self.renew {
            "Would you like to extend your rental period for 10 days at a cost of 1,000,000 gold?"
        } else {
            "Would you like to rent extra storage for 10 days at a cost of 1,000,000 gold?"
        }
    }
}

#[derive(Debug, Clone, Default, Resource, PartialEq)]
pub struct StorageUiState {
    pub cursor: StoragePageCursor,
    pub bag_selection: Option<StorageItemSelection>,
    pub storage_selection: Option<StorageItemSelection>,
    storage_item_drag: Option<StorageItemDrag>,
}

#[derive(Debug, Clone, Default, Resource, PartialEq, Eq)]
pub struct ShopUiState {
    pub start_index: usize,
}

#[derive(SystemParam)]
pub(crate) struct BigMapControls<'w> {
    model: Option<ResMut<'w, BigMapModel>>,
    intents: Option<ResMut<'w, BigMapGatewayIntentQueue>>,
    ui: Option<ResMut<'w, BigMapUiState>>,
    time: Option<Res<'w, Time>>,
    skill_binding: Option<ResMut<'w, SkillBindingUi>>,
    skills: Option<ResMut<'w, SkillModel>>,
    skill_persistence: Option<ResMut<'w, SkillBindingPersistenceRuntime>>,
}

impl Eq for NativePlayerUiState {}

impl Default for NativePlayerUiState {
    fn default() -> Self {
        Self {
            core: mir2_ui_core::state::UiState {
                screen: mir2_ui_core::state::UiScreen::InGame,
                panel: mir2_ui_core::state::UiPanel::None,
                minimap_visible: true,
                chat_focused: false,
                ..Default::default()
            },
            bigmap_zoom: 1.0,
            chat_draft: String::new(),
            inspect: None,
            shop_quantity: 1,
            shop_service_drag_count: None,
            shop_service_drag_unique_id: None,
            npc_inventory_hidden: false,
            mail_inventory_visible: false,
            npc_shop_buy_tab: true,
            npc_service_exit_requested: false,
            npc_service_exit_latched: false,
            npc_service_hold: None,
            npc_service_notice: None,
            npc_service_notice_mode: None,
            shop_repair_mode: false,
            shop_repair_container: 0,
            shop_repair_slot: None,
            game_shop_page: 0,
            game_shop_dialog: Default::default(),
            split_count: 1,
            inventory_operation: None,
            inventory_item_drag: None,
            storage_equipment_visible: false,
            equipment_item_drag: None,
            inventory_item_pointer_consumed: false,
            selected_skill_id: None,
            character_page: CharacterPage::Character,
            inventory_page: 0,
            skill_page: 0,
            drop_confirmation: None,
            inventory_delete_mode: false,
            inventory_delete_prompt: None,
            mail_delete_prompt: None,
            mail_delete_input_consumed: false,
            mail_feedback_prompt: None,
            mail_feedback_input_consumed: false,
            mail_recipient_prompt_active: false,
            mail_recipient_input_consumed: false,
            queued_mail_letter_recipient: None,
            mail_reader: None,
            mail_reader_windows: default(),
            mail_reader_input_consumed: false,
            inventory_window: InventoryDialogUi::default(),
            selected_group_member: None,
            group_invite_draft: String::new(),
            group_invite_focused: false,
            selected_guild_member: None,
            guild_recruit_draft: String::new(),
            guild_recruit_focused: false,
            guild_gold_prompt: None,
            parcel_gold_prompt: None,
            parcel_gold_input_consumed: false,
            trade_dialog: TradeDialogUi::default(),
            menu_pointer_consumed: false,
            menu_hit_regions: Vec::new(),
            equipment_dialogs: Default::default(),
            creature: Default::default(),
            ranking: ranking_dialog::RankingDialogUi::default(),
            friends: friend_dialog::FriendDialogUi::default(),
            guild_panel: Default::default(),
            group_dialog: Default::default(),
            skill_assign: Default::default(),
            local_keys: Default::default(),
            ime_frame_consumed: false,
            status_hud: Default::default(),
            hero_buffs: Default::default(),
            skill_bars: Default::default(),
            hero: Default::default(),
            combat_modes: Default::default(),
            skill_authority: Default::default(),
            leave_game: Default::default(),
            social_bonds: Default::default(),
            keyboard: Default::default(),
            guild_gold_ready_at_ms: 0,
            guild_storage: GuildStorageUi::default(),
            selected_guild_rank: None,
            guild_rank_name_draft: String::new(),
            guild_rank_name_focused: false,
            guild_left_page: GuildLeftPage::Notice,
            guild_notice_editing: false,
            guild_notice_draft: String::new(),
            guild_notice_submission: None,
            storage_password_prompt: None,
            storage_password_input_consumed: false,
            storage_rental_confirmation: None,
            storage_rental_input_consumed: false,
            help: HelpDialogUi::default(),
        }
    }
}

impl NativePlayerUiState {
    fn apply(&mut self, action: mir2_ui_core::action::UiAction) {
        let is_panel = matches!(
            action,
            mir2_ui_core::action::UiAction::OpenInventory
                | mir2_ui_core::action::UiAction::OpenCharacter
                | mir2_ui_core::action::UiAction::OpenSkill
                | mir2_ui_core::action::UiAction::OpenQuestLog
                | mir2_ui_core::action::UiAction::OpenOptions
                | mir2_ui_core::action::UiAction::OpenMenu
                | mir2_ui_core::action::UiAction::OpenGameShop
                | mir2_ui_core::action::UiAction::OpenNpcShop
                | mir2_ui_core::action::UiAction::OpenMail
                | mir2_ui_core::action::UiAction::OpenBigMap
                | mir2_ui_core::action::UiAction::OpenStorage
                | mir2_ui_core::action::UiAction::OpenGroup
                | mir2_ui_core::action::UiAction::OpenGuild
                | mir2_ui_core::action::UiAction::OpenTrade
                | mir2_ui_core::action::UiAction::ClosePanel
                | mir2_ui_core::action::UiAction::CloseAllPanels
                | mir2_ui_core::action::UiAction::ToggleMinimap
                | mir2_ui_core::action::UiAction::OpenChatSettings
        );
        if is_panel && self.core.screen != mir2_ui_core::state::UiScreen::InGame {
            self.core.screen = mir2_ui_core::state::UiScreen::InGame;
        }
        self.core = mir2_ui_core::reducer::reduce(&self.core, action).state;
    }

    pub fn inventory_open(&self) -> bool {
        // Crystal NPCDropDialog.Show and StorageDialog.Show both show the
        // ordinary InventoryDialog beside their own service frame.
        self.core.inventory_open()
            || (self.mail_open() && self.mail_inventory_visible)
            || (self.npc_shop_open() && !self.npc_inventory_hidden)
            || self.storage_open()
    }
    pub fn equipment_open(&self) -> bool {
        self.core.equipment_open() || (self.storage_open() && self.storage_equipment_visible)
    }
    pub fn menu_open(&self) -> bool {
        self.core.menu_open()
    }
    pub fn skill_open(&self) -> bool {
        self.core.skill_open()
            || (self.equipment_open() && self.character_page == CharacterPage::Spells)
    }
    pub fn quest_open(&self) -> bool {
        self.core.quest_open()
    }
    pub fn options_open(&self) -> bool {
        self.core.options_open()
    }
    pub fn mail_open(&self) -> bool {
        self.core.mail_open()
    }
    pub fn bigmap_open(&self) -> bool {
        self.core.bigmap_open()
    }
    pub fn shop_open(&self) -> bool {
        self.core.shop_open()
    }
    pub fn npc_shop_open(&self) -> bool {
        self.core.npc_shop_open()
    }
    pub fn begin_npc_service_request(&mut self) {
        self.npc_service_exit_latched = false;
        self.npc_service_exit_requested = false;
    }
    pub fn request_npc_service_exit(&mut self) {
        self.npc_service_exit_requested = true;
        self.npc_service_exit_latched = true;
    }
    pub fn accepts_npc_service_reply(&self) -> bool {
        !self.npc_service_exit_latched
    }
    pub fn storage_open(&self) -> bool {
        self.core.storage_open()
    }
    pub fn group_open(&self) -> bool {
        self.core.is_group_open()
    }
    pub fn guild_open(&self) -> bool {
        self.core.is_guild_open()
    }
    pub fn trade_open(&self) -> bool {
        self.trade_dialog.open || self.core.is_trade_open()
    }
    pub fn minimap_visible(&self) -> bool {
        self.core.minimap_visible()
    }
    pub fn chat_focused(&self) -> bool {
        self.core.chat_focused()
    }

    pub fn help_open(&self) -> bool {
        self.help.open
    }

    pub fn toggle_inventory(&mut self) {
        // The visible bag belongs to the open NPC service. Do not replace its
        // modal panel with Inventory; toggle the independently closable bag.
        if self.npc_shop_open() {
            self.npc_inventory_hidden = !self.npc_inventory_hidden;
            return;
        }
        if self.mail_open() && self.core.mail_compose_open() {
            self.mail_inventory_visible = !self.mail_inventory_visible;
            self.inventory_item_drag = None;
            return;
        }
        self.apply(mir2_ui_core::action::UiAction::OpenInventory);
        if !self.inventory_open() {
            self.inventory_window.end_drag();
            self.inventory_window.clear_cursor();
        }
    }
    pub fn toggle_equipment(&mut self) {
        if self.storage_open() {
            self.storage_equipment_visible = !self.storage_equipment_visible;
            if self.storage_equipment_visible {
                self.character_page = CharacterPage::Character;
            }
            self.equipment_item_drag = None;
            return;
        }
        self.apply(mir2_ui_core::action::UiAction::OpenCharacter);
    }
    fn activate_character_hud_button(&mut self) {
        // Crystal's main Character button closes only when the dialog is
        // already showing CharacterPage. From a stats/spells page it keeps
        // the dialog open and returns to CharacterPage instead.
        if self.storage_open() {
            if self.storage_equipment_visible && self.character_page == CharacterPage::Character {
                self.storage_equipment_visible = false;
            } else {
                self.storage_equipment_visible = true;
                self.character_page = CharacterPage::Character;
            }
            self.equipment_item_drag = None;
            return;
        }
        if self.equipment_open() && self.character_page == CharacterPage::Character {
            self.apply(mir2_ui_core::action::UiAction::OpenCharacter);
            return;
        }
        if !self.equipment_open() {
            self.apply(mir2_ui_core::action::UiAction::OpenCharacter);
        }
        self.character_page = CharacterPage::Character;
    }
    pub fn toggle_menu(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenMenu);
    }
    pub fn toggle_skill(&mut self) {
        // Crystal F11/Skills2 opens the CharacterDialog's SkillPage. It must
        // retain the real header and working CHAR/STATS/SPELLS controls.
        if self.storage_open() {
            if self.storage_equipment_visible && self.character_page == CharacterPage::Spells {
                self.storage_equipment_visible = false;
            } else {
                self.storage_equipment_visible = true;
                self.character_page = CharacterPage::Spells;
            }
            self.equipment_item_drag = None;
            return;
        }
        if self.equipment_open() && self.character_page == CharacterPage::Spells {
            self.apply(mir2_ui_core::action::UiAction::OpenCharacter);
            return;
        }
        if !self.equipment_open() {
            self.apply(mir2_ui_core::action::UiAction::OpenCharacter);
        }
        self.character_page = CharacterPage::Spells;
    }
    pub fn toggle_quest(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenQuestLog);
    }
    pub fn toggle_options(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenOptions);
    }
    pub fn toggle_mail(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenMail);
    }
    pub fn toggle_bigmap(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenBigMap);
    }
    pub fn toggle_shop(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenGameShop);
    }
    pub fn toggle_npc_shop(&mut self) {
        if !self.npc_shop_open() {
            self.npc_inventory_hidden = false;
            self.npc_service_notice = None;
            self.npc_service_notice_mode = None;
        }
        self.apply(mir2_ui_core::action::UiAction::OpenNpcShop);
    }
    pub fn toggle_storage(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenStorage);
    }
    pub fn toggle_group(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenGroup);
    }
    pub fn toggle_guild(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenGuild);
    }
    pub fn toggle_trade(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::OpenTrade);
    }
    pub fn toggle_minimap(&mut self) {
        self.apply(mir2_ui_core::action::UiAction::ToggleMinimap);
    }
    pub fn set_chat_focused(&mut self, focused: bool) {
        self.apply(if focused {
            mir2_ui_core::action::UiAction::FocusChat
        } else {
            mir2_ui_core::action::UiAction::BlurChat
        });
    }
    pub fn blocks_gameplay_keys(&self) -> bool {
        self.hero.modal() || self.hero.input_consumed || self.blocks_gameplay_keys_except_hero()
    }
    pub fn blocks_gameplay_keys_except_hero(&self) -> bool {
        self.mail_delete_prompt.is_some()
            || self.mail_delete_input_consumed
            || self.mail_feedback_prompt.is_some()
            || self.mail_feedback_input_consumed
            || self.mail_recipient_prompt_active
            || self.mail_recipient_input_consumed
            || self.mail_reader.is_some()
            || self.mail_reader_input_consumed
            || self.storage_password_prompt.is_some()
            || self.storage_password_input_consumed
            || self.storage_rental_confirmation.is_some()
            || self.storage_rental_input_consumed
            || self.game_shop_dialog.confirmation.is_some()
            || (self.shop_open() && self.game_shop_dialog.search_focused)
            || self.guild_panel.blocks()
            || self.guild_panel.consumed
            || self.skill_assign.open
            || self.group_dialog.modal()
            || self.group_dialog.consumed
            || self.leave_game.blocks()
            || self.social_bonds.prompt.is_some()
            || equipment_creature_host::modal(self)
            || self.core.blocks_gameplay_keys()
            || self.amount_modal_open_except_hero()
            || self.keyboard.open
            || self.keyboard.input_consumed
            || self.friends.modal.is_some()
    }
    pub fn blocks_world_click(&self) -> bool {
        self.blocks_world_click_with_panel(self.core.blocks_world_click())
    }

    /// Crystal's ordinary windows capture their visible rectangle, not the
    /// whole world (MirControl.IsMouseOver). Modals and item transactions keep
    /// their independent capture even when an ordinary panel is underneath.
    fn nonmodal_panel_rect(&self) -> Option<CrystalRect> {
        use mir2_ui_core::state::UiPanel;
        match self.core.panel {
            UiPanel::Inventory => Some(CrystalRect::new(
                self.inventory_window.left, self.inventory_window.top,
                INVENTORY_PANEL_SIZE.width as f32, INVENTORY_PANEL_SIZE.height as f32,
            )),
            UiPanel::Character | UiPanel::Skill => Some(CRYSTAL_CHARACTER_PANEL_RECT),
            UiPanel::Options => Some(CRYSTAL_OPTIONS_PANEL_RECT),
            UiPanel::Menu => Some(CRYSTAL_MENU_PANEL_RECT),
            UiPanel::QuestLog => Some(CrystalRect::new(
                crate::quest_ui::QUEST_DIARY_DESIGN_LEFT, crate::quest_ui::QUEST_DIARY_DESIGN_TOP,
                crate::quest_ui::QUEST_DIARY_DESIGN_WIDTH, crate::quest_ui::QUEST_DIARY_DESIGN_HEIGHT,
            )),
            _ => None,
        }
    }

    pub fn captures_nonmodal_pointer_at(&self, x: f32, y: f32) -> bool {
        x.is_finite() && y.is_finite() && (
            self.nonmodal_panel_rect().is_some_and(|rect| rect.contains(x, y))
            || (self.help.open && CrystalRect::new(
                self.help.left, self.help.top,
                CRYSTAL_HELP_PANEL_RECT.width, CRYSTAL_HELP_PANEL_RECT.height,
            ).contains(x, y))
        )
    }

    pub fn blocks_world_pointer_at(&self, x: f32, y: f32) -> bool {
        let rect = self.nonmodal_panel_rect();
        let panel_blocks = if rect.is_some() { self.core.chat_focused() }
            else { self.core.blocks_world_click() };
        !x.is_finite() || !y.is_finite()
            || self.blocks_world_click_with_panel(panel_blocks)
            || self.captures_nonmodal_pointer_at(x, y)
            || self.help.dragging
            || self.inventory_window.dragging()
            || self.inventory_item_drag.is_some()
            || self.inventory_operation.is_some()
            || self.equipment_item_drag.is_some()
    }

    fn blocks_world_click_with_panel(&self, panel_blocks: bool) -> bool {
        self.blocks_world_click_with_panel_and_hover(panel_blocks, true)
    }

    /// An established route owns its destination independently of pointer
    /// hover. Keep every modal/transaction guard and active drag; only the
    /// ordinary view windows may remain open without cancelling travel.
    /// Do not use inventory_open(): it also includes NPC/storage/mail service
    /// panels, which must retain their ordinary world-input protection.
    pub fn blocks_route_navigation(&self) -> bool {
        let panel_blocks = match self.core.panel {
            mir2_ui_core::state::UiPanel::Inventory
            | mir2_ui_core::state::UiPanel::Character
            | mir2_ui_core::state::UiPanel::Skill
            | mir2_ui_core::state::UiPanel::Options
            | mir2_ui_core::state::UiPanel::Menu
            | mir2_ui_core::state::UiPanel::QuestLog
            | mir2_ui_core::state::UiPanel::BigMap => {
                self.core.chat_focused()
            }
            _ => self.core.blocks_world_click(),
        };
        self.blocks_world_click_with_panel_and_hover(panel_blocks, false)
            || self.blocks_gameplay_keys()
            || self.help.dragging
            || self.skill_bars.dragging.is_some()
            || self.hero.dragging.is_some()
            || self.inventory_window.dragging()
            || self.inventory_item_drag.is_some()
            || self.inventory_operation.is_some()
            || self.equipment_item_drag.is_some()
    }

    fn blocks_world_click_with_panel_and_hover(&self, panel_blocks: bool, hover_blocks: bool) -> bool {
        self.game_shop_dialog.confirmation.is_some()
            || self.storage_password_prompt.is_some()
            || self.storage_password_input_consumed
            || self.storage_rental_confirmation.is_some()
            || self.storage_rental_input_consumed
            || self.guild_panel.blocks()
            || self.guild_panel.consumed
            || self.skill_assign.open
            || self.hero.modal()
            || self.hero.input_consumed
            || self.group_dialog.modal()
            || self.group_dialog.consumed
            || self.leave_game.blocks()
            || self.social_bonds.prompt.is_some()
            || equipment_creature_host::modal(self)
            || (hover_blocks && self.hero_buffs.rows.hovered)
            || (hover_blocks && self.status_hud.hovered)
            || self.menu_pointer_consumed
            || self.equipment_dialogs.fishing
            || panel_blocks
            || self.inspect.is_some()
            || self.inventory_delete_prompt.is_some()
            || self.mail_delete_prompt.is_some()
            || self.mail_delete_input_consumed
            || self.mail_feedback_prompt.is_some()
            || self.mail_feedback_input_consumed
            || self.mail_recipient_prompt_active
            || self.mail_recipient_input_consumed
            || self.mail_reader.is_some()
            || self.mail_reader_input_consumed
            || self.guild_gold_prompt.is_some()
            || self.parcel_gold_prompt.is_some()
            || self.parcel_gold_input_consumed
            || self.trade_dialog.open
            || self.trade_dialog.message.is_some()
            || self.trade_dialog.input_consumed
            || self.help.dragging
            || self.keyboard.open
            || self.friends.open
            || self.ranking.open
            || self.ranking.player_inspect.is_open()
    }
    pub fn blocks_world_action(&self, dialog_open: bool, dead: bool) -> bool {
        self.blocks_route_navigation() || dialog_open || dead
    }
    pub fn captures_pointer(
        &self,
        dragging_window: bool,
        dragging_scrollbar: bool,
        button_pressed: bool,
    ) -> bool {
        dragging_window || dragging_scrollbar || button_pressed || self.blocks_world_click()
    }
    pub fn trimmed_chat_to_send(&self) -> Option<String> {
        let value = self.chat_draft.trim();
        (!value.is_empty()).then(|| value.to_owned())
    }
    pub fn is_chat_focused(&self) -> bool {
        self.core.chat_focused()
    }
    pub fn close_windows(&mut self) {
        if self.npc_shop_open() {
            self.request_npc_service_exit();
        }
        self.skill_assign = Default::default();
        self.core.panel = mir2_ui_core::state::UiPanel::None;
        self.core.options_draft = None;
        self.core.chat_settings_draft = None;
        self.inspect = None;
        self.inventory_operation = None;
        self.inventory_item_drag = None;
        self.storage_equipment_visible = false;
        self.equipment_item_drag = None;
        self.selected_skill_id = None;
        self.character_page = CharacterPage::Character;
        self.inventory_page = 0;
        self.skill_page = 0;
        self.character_page = CharacterPage::Character;
        self.inventory_page = 0;
        self.skill_page = 0;
        self.drop_confirmation = None;
        self.inventory_delete_mode = false;
        self.inventory_delete_prompt = None;
        self.mail_delete_prompt = None;
        self.mail_delete_input_consumed = false;
        self.mail_feedback_prompt = None;
        self.mail_feedback_input_consumed = false;
        self.mail_recipient_prompt_active = false;
        self.mail_recipient_input_consumed = false;
        self.queued_mail_letter_recipient = None;
        self.mail_reader = None;
        self.mail_reader_windows = default();
        self.mail_reader_input_consumed = false;
        self.inventory_window.end_drag();
        self.inventory_window.clear_cursor();
        self.shop_repair_container = 0;
        self.shop_repair_slot = None;
        self.game_shop_page = 0;
        self.game_shop_dialog = Default::default();
        self.split_count = 1;
        self.selected_group_member = None;
        self.group_invite_draft.clear();
        self.group_invite_focused = false;
        self.selected_guild_member = None;
        self.guild_recruit_draft.clear();
        self.guild_recruit_focused = false;
        self.guild_gold_prompt = None;
        self.parcel_gold_prompt = None;
        self.parcel_gold_input_consumed = false;
        self.trade_dialog.hide();
        self.ranking.hide();
        self.friends.hide();
        self.social_bonds.hide(social_bond_dialog::BondPage::Mentor);
        self.social_bonds
            .hide(social_bond_dialog::BondPage::Relationship);
        self.ranking.player_inspect.close();
        self.guild_storage.end_drag();
        self.selected_guild_rank = None;
        self.guild_rank_name_draft.clear();
        self.guild_rank_name_focused = false;
        self.guild_left_page = GuildLeftPage::Notice;
    }

    pub fn inventory_delete_prompt_open(&self) -> bool {
        self.inventory_delete_prompt.is_some()
    }

    pub fn amount_modal_open(&self) -> bool {
        self.hero.modal() || self.amount_modal_open_except_hero()
    }
    fn amount_modal_open_except_hero(&self) -> bool {
        equipment_creature_host::modal(self)
            || self.non_friend_amount_modal_open_except_hero()
            || self.friends.modal.is_some()
            || self.friends.input_consumed
    }
    pub fn non_friend_amount_modal_open(&self) -> bool {
        self.hero.modal() || self.non_friend_amount_modal_open_except_hero()
    }
    fn non_friend_amount_modal_open_except_hero(&self) -> bool {
        self.guild_panel.blocks()
            || self.guild_panel.consumed
            || self.skill_assign.open
            || self.group_dialog.modal()
            || self.group_dialog.consumed
            || self.leave_game.blocks()
            || self.social_bonds.prompt.is_some()
            || self.social_bonds.input_consumed
            || self.inventory_delete_prompt.is_some()
            || self.mail_delete_prompt.is_some()
            || self.guild_gold_prompt.is_some()
            || self.parcel_gold_prompt.is_some()
            || self.parcel_gold_input_consumed
            || self.trade_dialog.gold_prompt.is_some()
            || self.trade_dialog.message.is_some()
            || self.trade_dialog.input_consumed
    }

    /// Open the source-shaped delete prompt for one current carried-item
    /// slot. Quest inventory, legacy rows without an instance id, zero-sized
    /// stacks and counts outside the wire's `u16` domain all fail closed.
    pub fn open_inventory_delete_for_slot(
        &mut self,
        inventory: &InventoryModel,
        slot: u32,
    ) -> bool {
        let Some(item) = inventory
            .items
            .iter()
            .find(|item| item.container == 0 && item.slot == slot)
        else {
            return false;
        };
        let Some(prompt) = inventory_delete_prompt_for_item(item) else {
            return false;
        };
        self.inventory_delete_prompt = Some(prompt);
        self.inspect = None;
        self.inventory_operation = None;
        self.drop_confirmation = None;
        true
    }

    fn cancel_inventory_delete(&mut self) {
        self.inventory_delete_mode = false;
        self.inventory_delete_prompt = None;
        self.inspect = None;
    }
    pub fn close_all_windows(&mut self) {
        self.keyboard.hide();
        self.close_windows();
        self.help.hide();
    }
    pub(crate) fn request_mail_letter(&mut self, recipient: String) {
        self.queued_mail_letter_recipient = Some(recipient);
    }

    pub fn reset_session(&mut self) {
        let options = self.core.options.clone();
        let chat_settings = self.core.chat_settings;
        let game_shop_had_pending = self.core.game_shop_pending.is_some();
        let mut keyboard = std::mem::take(&mut self.keyboard);
        keyboard.spell_target_lock = false;
        keyboard.hide();
        *self = Self::default();
        self.keyboard = keyboard;
        // Options are application-scoped rather than character/session-scoped.
        // Keep the loaded/applied values when the shell leaves InGame so a
        // logout/re-login does not silently revert the user's local settings.
        self.core.options = options;
        self.core.chat_settings = chat_settings;
        self.core.game_shop_unknown = game_shop_had_pending;
    }
    pub fn reset_session_preserving_exact_game_shop_receipt(
        &mut self,
        receipt: &crate::game_shop::GameShopReceipt,
    ) {
        let options = self.core.options.clone();
        let chat_settings = self.core.chat_settings;
        let mut keyboard = std::mem::take(&mut self.keyboard);
        keyboard.spell_target_lock = false;
        keyboard.hide();
        *self = Self::default();
        self.keyboard = keyboard;
        self.core.options = options;
        self.core.chat_settings = chat_settings;
        let _ = self.core.preserve_exact_game_shop_receipt_boundary(receipt);
    }
    pub fn zoom_in(&mut self) {
        self.bigmap_zoom = bigmap_zoom_in(self.bigmap_zoom);
    }
    pub fn zoom_out(&mut self) {
        self.bigmap_zoom = bigmap_zoom_out(self.bigmap_zoom);
    }
    pub fn shop_quantity_inc(&mut self) {
        self.shop_quantity = shop_quantity_inc(self.shop_quantity);
    }
    pub fn shop_quantity_dec(&mut self) {
        self.shop_quantity = shop_quantity_dec(self.shop_quantity);
    }
}

#[derive(Debug, Default, Resource)]
pub struct UiEffectQueue {
    effects: VecDeque<mir2_ui_core::effect::UiEffect>,
}

impl UiEffectQueue {
    pub fn push(&mut self, effect: mir2_ui_core::effect::UiEffect) {
        if self.effects.len() >= MAX_QUEUED {
            self.effects.pop_front();
        }
        self.effects.push_back(effect);
    }

    pub fn drain(&mut self) -> Vec<mir2_ui_core::effect::UiEffect> {
        self.effects.drain(..).collect()
    }

    pub fn drain_mail_commands(&mut self) -> Vec<mir2_ui_core::effect::GatewayCommand> {
        let mut commands = Vec::new();
        let mut retained = VecDeque::with_capacity(self.effects.len());
        while let Some(effect) = self.effects.pop_front() {
            match effect {
                mir2_ui_core::effect::UiEffect::GatewayCommand(
                    command @ mir2_ui_core::effect::GatewayCommand::SendMail { .. },
                ) => commands.push(command),
                other => retained.push_back(other),
            }
        }
        self.effects = retained;
        commands
    }

    pub(crate) fn drain_options_bounded(
        &mut self,
        max: usize,
    ) -> Vec<mir2_ui_core::effect::UiEffect> {
        self.drain_matching_bounded(max, |effect| {
            matches!(
                effect,
                mir2_ui_core::effect::UiEffect::ApplyAudioSettings { .. }
                    | mir2_ui_core::effect::UiEffect::ApplyWindowMode { .. }
                    | mir2_ui_core::effect::UiEffect::PersistOptions { .. }
            )
        })
    }

    pub(crate) fn drain_chat_settings_bounded(
        &mut self,
        max: usize,
    ) -> Vec<mir2_ui_core::effect::UiEffect> {
        self.drain_matching_bounded(max, |effect| {
            matches!(
                effect,
                mir2_ui_core::effect::UiEffect::ApplyChatSettings { .. }
                    | mir2_ui_core::effect::UiEffect::PersistChatSettings { .. }
            )
        })
    }

    fn drain_observe_bounded(&mut self, max: usize) -> usize {
        self.drain_matching_bounded(max, |effect| {
            matches!(
                effect,
                mir2_ui_core::effect::UiEffect::RequestObserve { .. }
            )
        })
        .len()
    }

    fn take_exit_application(&mut self) -> bool {
        !self
            .drain_matching_bounded(1, |effect| {
                matches!(effect, mir2_ui_core::effect::UiEffect::ExitApplication)
            })
            .is_empty()
    }

    #[cfg(test)]
    pub(crate) fn len(&self) -> usize {
        self.effects.len()
    }

    fn drain_matching_bounded<F>(
        &mut self,
        max: usize,
        mut matches: F,
    ) -> Vec<mir2_ui_core::effect::UiEffect>
    where
        F: FnMut(&mir2_ui_core::effect::UiEffect) -> bool,
    {
        if max == 0 || self.effects.is_empty() {
            return Vec::new();
        }

        let mut drained = Vec::with_capacity(max.min(self.effects.len()));
        let mut retained = VecDeque::with_capacity(self.effects.len());
        while let Some(effect) = self.effects.pop_front() {
            if drained.len() < max && matches(&effect) {
                drained.push(effect);
            } else {
                retained.push_back(effect);
            }
        }
        self.effects = retained;
        drained
    }
}

/// Apply a shared action and retain every typed adapter effect for the host.
pub fn dispatch_ui_action(
    core: &mut mir2_ui_core::state::UiState,
    effects: &mut UiEffectQueue,
    action: mir2_ui_core::action::UiAction,
) -> mir2_ui_core::reducer::Transition {
    let is_panel = matches!(
        &action,
        mir2_ui_core::action::UiAction::OpenInventory
            | mir2_ui_core::action::UiAction::OpenCharacter
            | mir2_ui_core::action::UiAction::OpenSkill
            | mir2_ui_core::action::UiAction::OpenQuestLog
            | mir2_ui_core::action::UiAction::OpenOptions
            | mir2_ui_core::action::UiAction::OpenMenu
            | mir2_ui_core::action::UiAction::OpenGameShop
            | mir2_ui_core::action::UiAction::OpenNpcShop
            | mir2_ui_core::action::UiAction::OpenMail
            | mir2_ui_core::action::UiAction::OpenBigMap
            | mir2_ui_core::action::UiAction::OpenStorage
            | mir2_ui_core::action::UiAction::ClosePanel
            | mir2_ui_core::action::UiAction::CloseAllPanels
            | mir2_ui_core::action::UiAction::ToggleMinimap
            | mir2_ui_core::action::UiAction::OpenChatSettings
    );
    if is_panel && core.screen != mir2_ui_core::state::UiScreen::InGame {
        core.screen = mir2_ui_core::state::UiScreen::InGame;
    }
    let transition = mir2_ui_core::reducer::reduce(core, action);
    *core = transition.state.clone();
    for effect in transition.effects.iter().cloned() {
        effects.push(effect);
    }
    transition
}

// ---------------------------------------------------------------------------
// Z-order and modal priority (Goal 4.8)
// ---------------------------------------------------------------------------

pub const OVERLAY_HUD_Z: i32 = 950;
// The map image occupies only the transparent 120x108 opening in the HUD
// frame.  Keep that content one layer above the frame so the retained night
// lighting composite cannot clear it while the frame/title/footer remain
// untouched.  Dialogs and chat still sort above both layers.
pub const OVERLAY_MINIMAP_Z: i32 = OVERLAY_HUD_Z + 1;
pub const OVERLAY_QUEST_Z: i32 = 900;
pub const OVERLAY_CHAT_Z: i32 = 975;
pub const OVERLAY_NPC_DIALOG_Z: i32 = 980;
/// Crystal HelpDialog has `Sort = true`: showing or pressing its drag surface
/// raises it above peer NPC dialogs while preserving the dedicated death/menu
/// modal layers.
pub const OVERLAY_HELP_SORTED_Z: i32 = OVERLAY_DEATH_Z - 1;
pub const OVERLAY_DEATH_Z: i32 = 985;
pub const OVERLAY_MENU_Z: i32 = 990;
const OVERLAY_INVENTORY_DELETE_MODAL_Z: i32 = 991;
const OVERLAY_INVENTORY_DELETE_CURSOR_Z: i32 = 992;
/// Mail result/error dialogs are above the reader and parcel-delete prompt.
const OVERLAY_MAIL_FEEDBACK_MODAL_Z: i32 = 993;
pub const OVERLAY_SHELL_Z: i32 = 1000;

/// `MirAmountBox` / `MirMessageBox` use integer centering at Crystal's fixed
/// 1024x768 stage. Their dimensions come from Prguse frames 238 and 360.
const CRYSTAL_DELETE_AMOUNT_RECT: CrystalRect = CrystalRect::new(410.0, 329.0, 204.0, 109.0);
const CRYSTAL_DELETE_CONFIRM_RECT: CrystalRect = CrystalRect::new(284.0, 289.0, 456.0, 190.0);
const CRYSTAL_DELETE_CURSOR_SIZE: (f32, f32) = (16.0, 15.0);
/// `StorageDialog` uses `Prguse[660]`, a 288x156 MirInputBox frame centered
/// on Crystal's fixed 1024x768 stage.
const CRYSTAL_STORAGE_PASSWORD_RECT: CrystalRect = CrystalRect::new(368.0, 306.0, 288.0, 156.0);
const CRYSTAL_MAIL_LETTER_RECT: CrystalRect = CrystalRect::new(100.0, 100.0, 236.0, 300.0);

/// Verify HUD < Chat < NPC < Death < Menu < Shell ordering.
pub fn is_overlay_z_order_correct() -> bool {
    // The quest tracker remains below HUD. The minimap content is clipped to
    // the frame opening and sits immediately above the HUD skin.
    OVERLAY_HUD_Z < OVERLAY_MINIMAP_Z
        && OVERLAY_MINIMAP_Z < OVERLAY_CHAT_Z
        && OVERLAY_CHAT_Z < OVERLAY_NPC_DIALOG_Z
        && OVERLAY_NPC_DIALOG_Z < OVERLAY_DEATH_Z
        && OVERLAY_DEATH_Z < OVERLAY_MENU_Z
        && OVERLAY_MENU_Z < OVERLAY_SHELL_Z
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum OverlayModalPriority {
    Hud = 0,
    NpcDialog = 1,
    Chat = 2,
    Death = 3,
    SystemMenu = 4,
}

pub fn modal_priority_for_state(
    state: &NativePlayerUiState,
    dialog_open: bool,
    dead: bool,
) -> Option<OverlayModalPriority> {
    if state.amount_modal_open() {
        return Some(OverlayModalPriority::SystemMenu);
    }
    if state.menu_open() {
        return Some(OverlayModalPriority::SystemMenu);
    }
    if dead {
        return Some(OverlayModalPriority::Death);
    }
    if state.chat_focused() {
        return Some(OverlayModalPriority::Chat);
    }
    if dialog_open || state.quest_open() || state.help_open() {
        return Some(OverlayModalPriority::NpcDialog);
    }
    if state.inventory_open()
        || state.equipment_open()
        || state.skill_open()
        || state.mail_open()
        || state.bigmap_open()
        || state.shop_open()
        || state.npc_shop_open()
        || state.storage_open()
        || state.group_open()
        || state.guild_open()
        || state.trade_open()
        || state.options_open()
    {
        // Generic window below NPC dialog but above HUD.
        return Some(OverlayModalPriority::NpcDialog);
    }
    None
}

/// Effective Z for a modal priority (used in rendering).
pub fn z_for_modal(priority: OverlayModalPriority) -> i32 {
    match priority {
        OverlayModalPriority::Hud => OVERLAY_HUD_Z,
        OverlayModalPriority::NpcDialog => OVERLAY_NPC_DIALOG_Z,
        OverlayModalPriority::Chat => OVERLAY_CHAT_Z,
        OverlayModalPriority::Death => OVERLAY_DEATH_Z,
        OverlayModalPriority::SystemMenu => OVERLAY_MENU_Z,
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum NativePlayerUiIntent {
    MagicKey {
        request_id: u64,
        spell: String,
        key: u8,
        old_key: u8,
    },
    EquipmentCreaturePacket(mir2_protocol::ClientPacket),
    HeroPacket(mir2_protocol::ClientPacket),
    GuildBuffUpdate(guild_buff_dialog::GuildBuffRequest),
    SocialBondPacket(mir2_protocol::ClientPacket),
    RefreshFriends,
    RemoveFriend {
        character_index: i32,
    },
    AddFriendMemo {
        character_index: i32,
        memo: String,
    },
    AddFriend {
        name: String,
        blocked: bool,
    },
    ObservePlayer {
        name: String,
    },
    GetRanking {
        rank_type: u8,
        rank_index: i32,
        online_only: bool,
    },
    InspectRanking {
        object_id: u32,
    },
    UseItem {
        key: Option<String>,
        unique_id: Option<u64>,
        slot: Option<u8>,
        grid: Option<String>,
    },
    EquipItem {
        unique_id: u64,
        grid: String,
        to: i32,
    },
    RemoveItem {
        unique_id: u64,
        grid: String,
        to: i32,
    },
    DropItem {
        key: String,
        unique_id: u64,
        count: u16,
        hero_inventory: bool,
    },
    DeleteItem {
        unique_id: u64,
        count: u16,
        hero_inventory: bool,
    },
    MoveItem {
        grid: String,
        unique_id: u64,
        from: i32,
        to: i32,
    },
    MergeItem {
        grid_from: String,
        grid_to: String,
        id_from: u64,
        id_to: u64,
    },
    SplitItem {
        unique_id: u64,
        grid: String,
        count: u16,
    },
    Chat {
        message: String,
    },
    ReadMail {
        mail_id: u64,
    },
    ClaimMail {
        mail_id: u64,
    },
    DeleteMail {
        mail_id: u64,
    },
    /// MailReadLetterDialog toggles the authoritative lock state by exact
    /// MailID. It is intentionally a status request, like Read/Delete.
    LockMail {
        mail_id: u64,
        lock: bool,
    },
    MailCost {
        gold: u32,
        attachment_unique_ids: Vec<u64>,
        stamped: bool,
    },
    MailLockItem {
        unique_id: u64,
        locked: bool,
    },
    SendMail {
        recipient: String,
        message: String,
        gold: u32,
        attachment_unique_ids: Vec<u64>,
        stamped: bool,
    },
    // Shop
    /// Cash GameShop purchase. The host maps this only to `gameShopBuy`.
    GameShopBuy {
        request_id: String,
        g_index: i32,
        quantity: u8,
        price_type: i32,
    },
    BuyItem {
        item_index: u64,
        count: u16,
    },
    SellItem {
        unique_id: u64,
        count: u16,
    },
    RepairItem {
        unique_id: u64,
    },
    SRepairItem {
        unique_id: u64,
    },
    // Storage
    StoreItem {
        request_id: String,
        unique_id: u64,
        from: i32,
        to: i32,
    },
    TakeBackItem {
        request_id: String,
        unique_id: u64,
        from: i32,
        to: i32,
    },
    UnlockStorage {
        password: String,
    },
    SetStoragePassword {
        current: String,
        new_password: String,
    },
    RemoveStoragePassword {
        current: String,
    },
    ExpandStorage,
    GroupSwitch {
        allow_group: bool,
    },
    GroupAddMember {
        name: String,
    },
    GroupRemoveMember {
        name: String,
    },
    GroupInvite {
        accept_invite: bool,
    },
    GuildRequestInfo {
        info_type: u8,
    },
    GuildEditMember {
        change_type: u8,
        rank_index: u8,
        name: String,
        rank_name: String,
    },
    GuildEditNotice {
        notice: Vec<String>,
    },
    GuildInvite {
        accept_invite: bool,
    },
    GuildStorageGoldChange {
        change_type: u8,
        amount: u32,
    },
    GuildStorageItemChange {
        change_type: u8,
        from: i32,
        to: i32,
    },
    TradeRequest,
    TradeReply {
        accept_invite: bool,
    },
    TradeGold {
        amount: u32,
    },
    TradeDepositItem {
        from: i32,
        to: i32,
    },
    TradeRetrieveItem {
        from: i32,
        to: i32,
    },
    TradeConfirm {
        locked: bool,
    },
    TradeCancel,
}

impl NativePlayerUiIntent {
    pub fn pending_key(&self) -> Option<PendingOperationKey> {
        match self {
            // Crystal has no negative acknowledgement for these status
            // commands. Queue-local deduplication prevents duplicate input;
            // a persistent receipt lock would make a rejected request unretryable.
            Self::ReadMail { .. }
            | Self::DeleteMail { .. }
            | Self::LockMail { .. }
            | Self::MailCost { .. }
            | Self::MailLockItem { .. } => None,
            Self::ClaimMail { mail_id } => Some(PendingOperationKey::ClaimMail(*mail_id)),
            Self::SendMail {
                recipient,
                message,
                gold,
                attachment_unique_ids,
                ..
            } => Some(PendingOperationKey::SendMail {
                recipient: recipient.clone(),
                message: message.clone(),
                gold: *gold,
                attachment_unique_ids: attachment_unique_ids.clone(),
            }),
            Self::BuyItem { item_index, count } => Some(PendingOperationKey::Buy {
                item_index: *item_index,
                count: *count,
            }),
            Self::GameShopBuy { request_id, .. } => {
                Some(PendingOperationKey::GameShop(request_id.clone()))
            }
            Self::SellItem { unique_id, count } => Some(PendingOperationKey::Sell {
                unique_id: *unique_id,
                count: *count,
            }),
            Self::RepairItem { unique_id } => Some(PendingOperationKey::Repair(*unique_id)),
            Self::SRepairItem { unique_id } => Some(PendingOperationKey::SpecialRepair(*unique_id)),
            Self::DropItem {
                unique_id,
                count,
                hero_inventory,
                ..
            } => Some(PendingOperationKey::Drop {
                unique_id: *unique_id,
                count: *count,
                hero_inventory: *hero_inventory,
            }),
            Self::DeleteItem {
                unique_id, count, ..
            } => Some(PendingOperationKey::DeleteItem {
                unique_id: *unique_id,
                count: *count,
            }),
            Self::MoveItem {
                grid,
                unique_id,
                from,
                to,
            } => Some(PendingOperationKey::Move {
                grid: grid.clone(),
                unique_id: *unique_id,
                from: *from,
                to: *to,
            }),
            Self::MergeItem {
                grid_from,
                grid_to,
                id_from,
                id_to,
            } => Some(PendingOperationKey::Merge {
                grid_from: grid_from.clone(),
                grid_to: grid_to.clone(),
                id_from: *id_from,
                id_to: *id_to,
            }),
            Self::SplitItem {
                unique_id,
                grid,
                count,
            } => Some(PendingOperationKey::Split {
                grid: grid.clone(),
                unique_id: *unique_id,
                count: *count,
            }),
            Self::EquipItem { unique_id, grid, to } => Some(PendingOperationKey::Equip {
                grid: grid.clone(),
                unique_id: *unique_id,
                to: *to,
            }),
            Self::RemoveItem { unique_id, grid, to } => Some(PendingOperationKey::Remove {
                grid: grid.clone(),
                unique_id: *unique_id,
                to: *to,
            }),
            Self::StoreItem {
                request_id,
                unique_id,
                from,
                to,
            } => Some(PendingOperationKey::StorageDepositV2 {
                request_id: request_id.clone(),
                unique_id: *unique_id,
                from: *from,
                to: *to,
            }),
            Self::TakeBackItem {
                request_id,
                unique_id,
                from,
                to,
            } => Some(PendingOperationKey::StorageWithdrawV2 {
                request_id: request_id.clone(),
                unique_id: *unique_id,
                from: *from,
                to: *to,
            }),
            Self::UnlockStorage { .. } => Some(PendingOperationKey::StorageUnlock),
            Self::SetStoragePassword { .. } => Some(PendingOperationKey::StorageSetPassword),
            Self::RemoveStoragePassword { .. } => Some(PendingOperationKey::StorageRemovePassword),
            Self::ExpandStorage => Some(PendingOperationKey::StorageExpand),
            Self::GroupSwitch { .. }
            | Self::GroupAddMember { .. }
            | Self::GroupRemoveMember { .. }
            | Self::GroupInvite { .. }
            | Self::GuildRequestInfo { .. }
            | Self::GuildEditMember { .. }
            | Self::GuildEditNotice { .. }
            | Self::GuildInvite { .. }
            | Self::GuildStorageGoldChange { .. }
            | Self::GuildStorageItemChange { .. }
            | Self::TradeRequest
            | Self::TradeReply { .. }
            | Self::TradeGold { .. }
            | Self::TradeDepositItem { .. }
            | Self::TradeRetrieveItem { .. }
            | Self::TradeConfirm { .. }
            | Self::TradeCancel => None,
            Self::GuildBuffUpdate(_)
            | Self::SocialBondPacket(_)
            | Self::HeroPacket(_)
            | Self::EquipmentCreaturePacket(_)
            | Self::UseItem { .. }
            | Self::Chat { .. }
            | Self::GetRanking { .. }
            | Self::InspectRanking { .. }
            | Self::RefreshFriends
            | Self::RemoveFriend { .. }
            | Self::AddFriendMemo { .. }
            | Self::AddFriend { .. }
            | Self::ObservePlayer { .. }
            | Self::MagicKey { .. } => None,
        }
    }
}

#[derive(Debug, Default, Resource)]
pub struct NativePlayerUiIntentQueue {
    intents: VecDeque<NativePlayerUiIntent>,
    storage_request_ids: StorageRequestIdGenerator,
    /// Crystal GameScene.UseItemTime is shared by player and Hero entry points.
    use_item_until_ms: u64,
}

impl NativePlayerUiIntentQueue {
    pub fn use_item_ready(&self, now: u64) -> bool {
        now >= self.use_item_until_ms
    }
    pub fn commit_item_use(&mut self, now: u64, delay: u64) {
        self.use_item_until_ms = now.saturating_add(delay);
    }
    pub fn push_intent(&mut self, intent: NativePlayerUiIntent) -> bool {
        self.push_intent_with_use_delay(intent, 300)
    }
    pub fn push_intent_with_use_delay(&mut self, intent: NativePlayerUiIntent, delay: u64) -> bool {
        self.push_intent_at(intent, crate::hero_model::hero_clock_ms(), delay)
    }
    fn push_intent_at(&mut self, intent: NativePlayerUiIntent, now: u64, delay: u64) -> bool {
        if matches!(
            &intent,
            NativePlayerUiIntent::ReadMail { .. }
                | NativePlayerUiIntent::DeleteMail { .. }
                | NativePlayerUiIntent::LockMail { .. }
        )
            && (self.intents.len() >= MAX_QUEUED || self.intents.iter().any(|queued| queued == &intent))
        {
            return false;
        }
        let uses_item = matches!(
            &intent,
            NativePlayerUiIntent::UseItem { .. }
                | NativePlayerUiIntent::HeroPacket(mir2_protocol::ClientPacket::UseItem { .. })
                | NativePlayerUiIntent::EquipmentCreaturePacket(
                    mir2_protocol::ClientPacket::UseItem { .. }
                )
        );
        if uses_item && !self.use_item_ready(now) {
            return false;
        }
        if self.intents.len() >= MAX_QUEUED {
            if matches!(
                intent,
                NativePlayerUiIntent::MagicKey { .. }
                    | NativePlayerUiIntent::GuildBuffUpdate(_)
                    | NativePlayerUiIntent::SocialBondPacket(_)
                    | NativePlayerUiIntent::HeroPacket(_)
                    | NativePlayerUiIntent::EquipmentCreaturePacket(_)
                    | NativePlayerUiIntent::GameShopBuy { .. }
                    | NativePlayerUiIntent::GetRanking { .. }
                    | NativePlayerUiIntent::InspectRanking { .. }
                    | NativePlayerUiIntent::AddFriend { .. }
                    | NativePlayerUiIntent::RemoveFriend { .. }
                    | NativePlayerUiIntent::AddFriendMemo { .. }
                    | NativePlayerUiIntent::RefreshFriends
            ) {
                return false;
            }
            let Some(index) = self.intents.iter().position(|queued| {
                !matches!(
                    queued,
                    NativePlayerUiIntent::MagicKey { .. }
                        | NativePlayerUiIntent::GuildBuffUpdate(_)
                        | NativePlayerUiIntent::SocialBondPacket(_)
                        | NativePlayerUiIntent::HeroPacket(_)
                        | NativePlayerUiIntent::EquipmentCreaturePacket(_)
                        | NativePlayerUiIntent::GameShopBuy { .. }
                        | NativePlayerUiIntent::GetRanking { .. }
                        | NativePlayerUiIntent::InspectRanking { .. }
                        | NativePlayerUiIntent::AddFriend { .. }
                        | NativePlayerUiIntent::RemoveFriend { .. }
                        | NativePlayerUiIntent::AddFriendMemo { .. }
                        | NativePlayerUiIntent::RefreshFriends
                )
            }) else {
                return false;
            };
            self.intents.remove(index);
        }
        self.intents.push_back(intent);
        if uses_item {
            self.commit_item_use(now, delay);
        }
        true
    }

    pub fn push_social_pending(
        &mut self,
        social: &mut crate::social::SocialModel,
        intent: NativePlayerUiIntent,
    ) -> bool {
        // Social operations are paired with a pending readback. A full queue
        // must reject the new operation before that pending state is created;
        // otherwise the generic queue's eviction policy could silently drop
        // an older intent while leaving a new social operation stuck forever.
        // The generic queue preserves transactional GameShop entries while
        // retaining bounded oldest-nontransaction eviction for normal work.
        if self.intents.len() >= MAX_QUEUED {
            return false;
        }
        if self.intents.iter().any(|queued| queued == &intent) {
            return false;
        }
        let operation = match &intent {
            NativePlayerUiIntent::GroupSwitch { allow_group } => {
                Some(crate::social::SocialPendingOperation::GroupSwitch {
                    allow_group: *allow_group,
                })
            }
            NativePlayerUiIntent::GroupAddMember { name } => {
                Some(crate::social::SocialPendingOperation::GroupAdd { name: name.clone() })
            }
            NativePlayerUiIntent::GroupRemoveMember { name } => {
                Some(crate::social::SocialPendingOperation::GroupRemove { name: name.clone() })
            }
            NativePlayerUiIntent::GroupInvite {
                accept_invite: true,
            } => {
                let Some(inviter) = social.group.pending_invite_from.clone() else {
                    return false;
                };
                Some(crate::social::SocialPendingOperation::GroupInviteAccept {
                    inviter,
                    invite_epoch: social.group.pending_invite_epoch,
                })
            }
            NativePlayerUiIntent::GuildRequestInfo { .. } => {
                Some(crate::social::SocialPendingOperation::GuildInfo)
            }
            NativePlayerUiIntent::GuildEditMember {
                change_type,
                rank_index,
                name,
                ..
            } => Some(crate::social::SocialPendingOperation::GuildMember {
                change_type: *change_type,
                rank_index: *rank_index,
                name: name.clone(),
            }),
            NativePlayerUiIntent::GuildEditNotice { notice } => {
                Some(crate::social::SocialPendingOperation::GuildNotice {
                    notice: notice.clone(),
                })
            }
            NativePlayerUiIntent::GuildInvite {
                accept_invite: true,
            } => {
                let Some(inviter) = social.guild.pending_invite_from.clone() else {
                    return false;
                };
                Some(crate::social::SocialPendingOperation::GuildInviteAccept {
                    inviter,
                    invite_epoch: social.guild.pending_invite_epoch,
                })
            }
            NativePlayerUiIntent::GuildStorageGoldChange {
                change_type,
                amount,
            } => Some(crate::social::SocialPendingOperation::GuildStorageGold {
                change_type: *change_type,
                amount: *amount,
            }),
            NativePlayerUiIntent::GuildStorageItemChange {
                change_type,
                from,
                to,
            } if *change_type <= 2 => {
                Some(crate::social::SocialPendingOperation::GuildStorageItem {
                    change_type: *change_type,
                    from: *from,
                    to: *to,
                })
            }
            NativePlayerUiIntent::GuildStorageItemChange { .. } => None,
            NativePlayerUiIntent::TradeRequest => {
                Some(crate::social::SocialPendingOperation::TradeRequest)
            }
            NativePlayerUiIntent::TradeReply { .. } => {
                Some(crate::social::SocialPendingOperation::TradeReply)
            }
            NativePlayerUiIntent::TradeGold { amount } => {
                Some(crate::social::SocialPendingOperation::TradeGold { amount: *amount })
            }
            NativePlayerUiIntent::TradeDepositItem { from, to } => {
                Some(crate::social::SocialPendingOperation::TradeDeposit {
                    from: *from,
                    to: *to,
                })
            }
            NativePlayerUiIntent::TradeRetrieveItem { from, to } => {
                Some(crate::social::SocialPendingOperation::TradeRetrieve {
                    from: *from,
                    to: *to,
                })
            }
            NativePlayerUiIntent::TradeConfirm { locked } => {
                Some(crate::social::SocialPendingOperation::TradeConfirm { locked: *locked })
            }
            NativePlayerUiIntent::TradeCancel => {
                Some(crate::social::SocialPendingOperation::TradeCancel)
            }
            _ => None,
        };
        if let Some(operation) = operation {
            if !social.begin_pending(operation) {
                return false;
            }
        }
        self.push_intent(intent)
    }

    /// Queue a client-only transient intent without adding a server pending
    /// key. This remains useful for non-authoritative local intents; server
    /// operations should use [`Self::push_pending_intent`].
    pub fn push_transient_unique(&mut self, intent: NativePlayerUiIntent) -> bool {
        if self.intents.iter().any(|queued| queued == &intent) {
            return false;
        }
        self.push_intent(intent)
    }

    pub fn drain_intents(&mut self) -> Vec<NativePlayerUiIntent> {
        self.intents.drain(..).collect()
    }

    /// Queue a server-authoritative operation only when the same logical key
    /// is not already awaiting readback.
    pub fn push_pending_intent(
        &mut self,
        pending: &mut PendingOperations,
        intent: NativePlayerUiIntent,
    ) -> bool {
        // Mail ACKs have no request id. Do not let a second claim/send with a
        // different id or draft pass through merely because its exact key is
        // different; the gateway can correlate only one of each class.
        if matches!(
            &intent,
            NativePlayerUiIntent::ClaimMail { .. } | NativePlayerUiIntent::SendMail { .. }
        ) && pending.has_pending_mail_operation()
        {
            return false;
        }
        if self.intents.len() >= MAX_QUEUED {
            return false;
        }
        let Some(key) = intent.pending_key() else {
            return self.push_intent(intent);
        };
        if !pending.try_begin(key.clone()) {
            return false;
        }
        if !self.push_intent(intent) {
            pending.release(&key);
            return false;
        }
        true
    }

    /// Allocate and enqueue a V2 storage transfer. Allocation happens before
    /// any capacity/pending check so a failed attempt still consumes its id;
    /// ids are never reused after a connection reset or queue rejection.
    pub fn push_storage_pending_intent(
        &mut self,
        pending: &mut PendingOperations,
        deposit: bool,
        unique_id: u64,
        from: i32,
        to: i32,
    ) -> bool {
        let Some(request_id) = self.storage_request_ids.next_request_id() else {
            return false;
        };
        let intent = if deposit {
            NativePlayerUiIntent::StoreItem {
                request_id,
                unique_id,
                from,
                to,
            }
        } else {
            NativePlayerUiIntent::TakeBackItem {
                request_id,
                unique_id,
                from,
                to,
            }
        };
        self.push_pending_intent(pending, intent)
    }

    /// Drag-only warehouse submission: reserve source identities/cells across
    /// Store, TakeBack, and Merge gestures before the generic V2 key enters
    /// the queue. Legacy adapter callers retain ordinary V2 semantics.
    pub fn push_storage_drag_pending_intent(
        &mut self,
        pending: &mut PendingOperations,
        deposit: bool,
        unique_id: u64,
        from: i32,
        to: i32,
    ) -> bool {
        let Some(request_id) = self.storage_request_ids.next_request_id() else {
            return false;
        };
        let intent = if deposit {
            NativePlayerUiIntent::StoreItem {
                request_id,
                unique_id,
                from,
                to,
            }
        } else {
            NativePlayerUiIntent::TakeBackItem {
                request_id,
                unique_id,
                from,
                to,
            }
        };
        let Some(key) = intent.pending_key() else {
            return false;
        };
        if pending.has_storage_drag_conflict(&key) {
            return false;
        }
        self.push_pending_intent(pending, intent)
    }

    /// Atomically reserve and enqueue the one in-flight native GameShop
    /// purchase. No correlation state is left behind when capacity or any
    /// reservation step fails.
    pub fn enqueue_game_shop_purchase(
        &mut self,
        core: &mut mir2_ui_core::state::UiState,
        game_shop: &mut GameShopModel,
        pending: &mut PendingOperations,
        g_index: i32,
        quantity: u8,
        price_type: i32,
    ) -> Option<GameShopRequest> {
        if self.intents.len() >= MAX_QUEUED
            || self
                .intents
                .iter()
                .any(|intent| matches!(intent, NativePlayerUiIntent::GameShopBuy { .. }))
        {
            return None;
        }

        let request = core.begin_game_shop_purchase(g_index, quantity, price_type)?;
        if !game_shop.reserve_purchase(request.clone()) {
            core.cancel_game_shop_purchase(&request.request_id);
            return None;
        }
        let key = PendingOperationKey::GameShop(request.request_id.clone());
        if !pending.try_begin(key.clone()) {
            game_shop.cancel_purchase_reservation(&request.request_id);
            core.cancel_game_shop_purchase(&request.request_id);
            return None;
        }
        if !self.push_intent(NativePlayerUiIntent::GameShopBuy {
            request_id: request.request_id.clone(),
            g_index: request.g_index,
            quantity: request.quantity,
            price_type: request.price_type,
        }) {
            pending.release(&key);
            game_shop.cancel_purchase_reservation(&request.request_id);
            core.cancel_game_shop_purchase(&request.request_id);
            return None;
        }
        Some(request)
    }

    pub fn clear(&mut self) {
        self.intents.clear();
    }
}

#[derive(Component)]
struct OverlayRoot;

#[derive(Component)]
struct OverlayInventory;

#[derive(Component)]
struct OverlayInventoryDeleteModal;

#[derive(Component)]
struct OverlayMailDeleteModal;

#[derive(Component)]
struct OverlayMailFeedbackModal;

#[derive(Component)]
struct OverlayStoragePasswordModal;

#[derive(Component)]
struct OverlayStorageRentalModal;

#[derive(Component)]
struct OverlayGuildGoldModal;

#[derive(Component)]
struct OverlayGuildGoldInput;

#[derive(Component)]
struct OverlayTrade;

#[derive(Component)]
struct OverlayTradeGoldModal;

#[derive(Component)]
struct OverlayTradeGoldInput;

#[derive(Component)]
pub struct OverlayGuildStorageCell {
    /// Original server slot, not the visible row/column's renumbered index.
    pub slot: usize,
}

#[derive(Component)]
struct OverlayGuildStorageThumb;

#[derive(Component)]
struct OverlayInventoryDeleteCursor;

#[derive(Component)]
struct OverlayInventoryDeleteDialog;

#[derive(Component)]
struct OverlayMailDeleteDialog;

#[derive(Component)]
struct OverlayMailFeedbackDialog;

#[derive(Component)]
struct OverlayMailReadLetter;

#[derive(Component)]
struct OverlayMailReadParcel;

#[derive(Component)]
struct OverlayMailComposeLetter;

#[derive(Component)]
struct OverlayMailComposeParcel;

#[derive(Component)]
struct OverlayInventoryDeleteAmountInput;

#[derive(Component)]
struct OverlayEquipment;

#[derive(Component)]
struct OverlayMenu;

#[derive(Component)]
struct OverlayHelp;

#[derive(Debug, Clone, Copy, Component, PartialEq, Eq)]
struct HelpPageImageEntity {
    image_index: u8,
}

#[derive(Component)]
struct OverlaySkill;

#[derive(Component)]
struct OverlayInspect;

#[derive(Component)]
struct OverlayDeath;

#[derive(Component)]
struct OverlayChatDraft;

#[derive(Component)]
struct OverlayMail;

#[derive(Component)]
struct OverlayBigMap;

#[derive(Component)]
struct BichonSafeDestinationArea;

/// Testable ECS provenance markers for the Big Map-only render tree. They
/// intentionally retain the authoritative renderer projection rather than
/// deriving values back from UI text or asset names.
#[derive(Debug, Clone, Component, PartialEq, Eq)]
struct BigMapImageEntity {
    url: String,
}

#[derive(Debug, Clone, Copy, Component, PartialEq, Eq)]
struct BigMapPlayerEntity {
    location: BigMapPoint,
}

/// Renderer-only marker for the authoritative map response wait state.  It
/// intentionally carries no map identity or fake image: once the server
/// supplies `map_image_url`, the normal panel rebuild removes this entity.
#[derive(Debug, Clone, Copy, Component, PartialEq, Eq)]
struct BigMapLoadingText;

#[derive(Debug, Clone, Component, PartialEq, Eq)]
struct BigMapNpcRowEntity {
    object_id: u32,
    name: String,
    location: BigMapPoint,
}

#[derive(Component)]
struct OverlayShop;

#[derive(Component)]
struct OverlayGameShop;

#[derive(Component)]
struct OverlayInventoryGridViewport;

#[derive(Component)]
struct OverlaySkillListViewport;

#[derive(Component)]
struct OverlayGameShopProduct;

#[derive(Component)]
struct OverlayNpcShopGoodCell;

#[derive(Component)]
struct OverlayNpcShopGoodIcon;

#[derive(Component)]
struct OverlayNpcShopGoodName;

#[derive(Component)]
struct OverlayNpcShopGoodPrice;

#[derive(Component)]
struct OverlayNpcShopGoodCount;

#[derive(Component)]
struct OverlayNpcShopGoodSelectionDivider;

#[derive(Component)]
struct OverlayNpcShopGoodNewIcon;

#[derive(Component)]
struct OverlayStorage;

#[derive(Component)]
struct OverlayOptions;

#[derive(Component)]
struct OverlaySocial;

#[derive(Component, Clone, Copy, Debug, PartialEq, Eq)]
enum OverlayButton {
    CastSkillBar(u8),
    RefreshSkillBar,
    ExitApplication,
    LeaveConfirm,
    LeaveCancel,
    CloseWindows,
    ToggleHelp,
    ToggleMount,
    ToggleFishing,
    ToggleCreature,
    ToggleRanking,
    ToggleFriends,
    ToggleMentor,
    ToggleRelationship,
    ToggleKeyboard,
    CloseHelp,
    HelpPrevious,
    HelpNext,
    CloseCharacter,
    CloseInspect,
    CloseMail,
    CloseBigMap,
    CloseShop,
    CloseGameShop,
    CloseStorage,
    CloseOptions,
    SetCrystalOption(mir2_ui_core::state::UiCrystalOption, bool),
    OptionsObserve(bool),
    OptionsMusicVolumeDown,
    OptionsMusicVolumeUp,
    OptionsSoundVolumeDown,
    OptionsSoundVolumeUp,
    ToggleInventory,
    ToggleEquipment,
    ToggleShop,
    ToggleNpcShop,
    ToggleStorage,
    ToggleGroup,
    ToggleGuild,
    ToggleTrade,
    CloseSocial,
    GroupInviteAccept,
    GroupInviteDecline,
    GroupSwitch,
    GroupLeave,
    SelectGuildRightBuff(bool),
    GuildBuffActivate(u8),
    GuildBuffScroll(i32),
    GuildBuffThumb,
    GuildNoticeScroll(i32),
    GuildRankDropdown,
    GuildCreateRank,
    GuildMemberRankMenu(u8),
    GuildMembersScroll(i32),
    GuildShowOffline,
    GuildMemberRankSelect(u8),
    GuildMemberRankConfirm,
    GuildCreateRankConfirm,
    GuildRankScroll(i32),
    GuildBuffErrorClose,
    GroupInputConfirm,
    GroupInputCancel,
    GroupAddSelected,
    GroupInviteNameFocus,
    GroupInviteNameSubmit,
    GroupRemoveSelected,
    SelectGroupMember(u8),
    GuildRequestInfo,
    SelectGuildLeftPage(GuildLeftPage),
    GuildInviteAccept,
    GuildInviteDecline,
    GuildRecruitNameFocus,
    GuildRecruitNameSubmit,
    GuildBeginNoticeEdit,
    GuildPublishNotice,
    GuildCancelNoticeEdit,
    SelectGuildMember(u8),
    GuildKickMember(u8),
    GuildKickSelected,
    GuildKickConfirm,
    GuildAssignPreviousRank,
    GuildAssignNextRank,
    GuildGoldDeposit,
    GuildGoldWithdraw,
    GuildGoldConfirm,
    GuildGoldCancel,
    GuildGoldClose,
    GuildStoragePreviousRow,
    GuildStorageNextRow,
    SelectGuildRank(u8),
    GuildRankNameFocus,
    GuildRankNameSave,
    GuildRankTogglePermission(u8),
    TradeRequest,
    TradeAccept(u64),
    TradeDecline(u64),
    TradeMessageClose(u64),
    TradeGoldOffer,
    TradeGoldConfirm,
    TradeGoldCancel,
    TradeGoldClose,
    TradeConfirm,
    TradeCancel,
    Logout,
    UseInspected,
    EquipInspected,
    UnequipInspected,
    InventoryDeleteToggle,
    InventoryDeleteConfirm,
    InventoryDeleteCancel,
    InventoryDeleteAmountClose,
    MailDeleteConfirm,
    MailDeleteCancel,
    MailFeedbackAcknowledge,
    DropInspected,
    ConfirmDropInspected,
    CancelDropInspected,
    SplitInspected,
    SplitCountDec,
    SplitCountInc,
    ArmMoveInspected,
    ArmMergeInspected,
    CancelInventoryOperation,
    InspectBag(u32),
    InspectQuest(u32),
    InspectEquip(u32),
    SelectCharacterPage(CharacterPage),
    SelectInventoryPage(u8),
    SelectSkill(u32),
    AssignSkillKey(u8),
    ClearSkillBinding,
    CloseSkillAssign,
    SkillPagePrev,
    SkillPageNext,
    SelectMail(u64),
    MailPagePrev,
    MailPageNext,
    ReadMail(u64),
    ClaimMail(u64),
    DeleteMail(u64),
    MailReply(u64),
    MailReaderClose,
    MailReaderDelete,
    MailReaderLock,
    MailReaderClaim,
    OpenMailCompose,
    OpenMailParcelCompose,
    MailRecipientSubmit,
    MailRecipientCancel,
    MailRecipientFocus,
    MailMessageFocus,
    MailGoldInc,
    MailGoldFocus,
    MailGoldDec,
    AddMailAttachment(u64),
    RemoveMailAttachment(u64),
    MailParcelStamp,
    MailParcelSlot(u8),
    MailParcelGoldConfirm,
    MailParcelGoldCancel,
    SubmitMail,
    CancelMailCompose,
    BigMapScrollUp,
    BigMapScrollDown,
    BigMapWorld,
    BigMapMyLocation,
    BigMapSearchFocus,
    BigMapSearchSubmit,
    BigMapTeleport,
    SelectBigMapNpc(u32),
    // NPC shop
    SelectShopGood(u64),
    ShopShowBuy,
    ShopShowSell,
    ShopBuy,
    ShopSell,
    ShopToggleHold,
    ShopRepair,
    ShopSRepair,
    ShopQuantityInc,
    ShopQuantityDec,
    ShopPageUp,
    ShopPageDown,
    ShopConfirm,
    ShopCancel,
    SelectBagForSell(u32),
    SelectBagForRepair(u32),
    // Cash shop
    SelectGameShopGood(i32),
    GameShopPaymentCredit,
    GameShopPaymentGold,
    GameShopBuy,
    GameShopQuantityInc,
    GameShopQuantityDec,
    GameShopPagePrev,
    GameShopPageNext,
    GameShopControl(game_shop_dialog::GameShopAction),
    // Storage
    SelectBagForStore(u32),
    SelectStorage(u32),
    StoragePage(usize),
    StorageDeposit,
    StorageWithdraw,
    StorageUnlock,
    StorageSetPassword,
    StorageRemovePassword,
    StoragePasswordSubmit,
    StoragePasswordCancel,
    StorageRentalConfirm,
    StorageRentalCancel,
    StorageExpand,
}

#[derive(SystemParam)]
struct OverlayButtonControls<'w, 's> {
    big_map: BigMapControls<'w>,
    mail_ui: ResMut<'w, MailUiState>,
    parcel_ui: Option<ResMut<'w, mail_parcel::MailParcelUi>>,
    storage_ui: ResMut<'w, StorageUiState>,
    shop_ui: ResMut<'w, ShopUiState>,
    ui_audio: ResMut<'w, crate::audio::NativeUiAudioQueue>,
    buttons: Query<'w, 's, (&'static Interaction, &'static OverlayButton), Changed<Interaction>>,
}

#[derive(SystemParam)]
pub(crate) struct OverlayKeyboardControls<'w> {
    surface_signals: Option<ResMut<'w, UiSurfaceSignals>>,
    ui_audio: ResMut<'w, crate::audio::NativeUiAudioQueue>,
    ui: Option<Res<'w, UiReadModel>>,
    mail: Option<ResMut<'w, MailModel>>,
    effects: Option<ResMut<'w, UiEffectQueue>>,
    belt: Option<ResMut<'w, super::hud::CrystalBeltPresentation>>,
    letter_editor: Option<ResMut<'w, mail_editor::MailLetterEditor>>,
    parcel: Option<Res<'w, mail_parcel::MailParcelUi>>,
}

fn release_mail_parcel_locks(
    parcel: &mut mail_parcel::MailParcelUi,
    intents: &mut NativePlayerUiIntentQueue,
) {
    for unique_id in parcel.release_all() {
        let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem {
            unique_id,
            locked: false,
        });
    }
}

fn complete_mail_parcel_send(
    parcel: &mut mail_parcel::MailParcelUi,
    intents: &mut NativePlayerUiIntentQueue,
) {
    for unique_id in parcel.complete_send() {
        let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem {
            unique_id,
            locked: false,
        });
    }
}

/// Native Mail service packets are deliberately independent from `MailModel`:
/// they control the parcel composer, not a durable mailbox row.  `MailCost`
/// has no request identity, so [`MailParcelUi`] accepts it only for its one
/// in-flight fingerprint and schedules a changed draft after that response.
fn process_mail_service_inbox(
    mut inbox: ResMut<MailServiceInbox>,
    mut state: ResMut<NativePlayerUiState>,
    mut compose: ResMut<MailComposeUi>,
    inventory: Res<InventoryModel>,
    mut parcel: ResMut<mail_parcel::MailParcelUi>,
    pending: Res<PendingOperations>,
) {
    for event in inbox.drain() {
        match event {
            MailServiceEvent::OpenParcel => {
                if pending.has_pending_mail_operation() {
                    compose.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                let active_parcel = state.core.mail_compose.is_some()
                    && compose.kind == MailComposeKind::Parcel;
                let saved_parcel = compose.parcel_draft.as_ref().is_some_and(|draft| {
                    !draft.recipient.is_empty()
                        || !draft.message.is_empty()
                        || draft.gold != 0
                        || !draft.attachment_unique_ids.is_empty()
                });
                if active_parcel || saved_parcel {
                    // A second NPC request must not retarget or overwrite an
                    // unsent parcel whose hidden payload could be mailed to a
                    // different recipient.
                    compose.last_notice = Some("Finish or cancel the current parcel first".to_owned());
                    continue;
                }
                let had_mail_parent = state.mail_open();
                state.apply(mir2_ui_core::action::UiAction::OpenMail);
                begin_mail_recipient_prompt_with_parent(
                    &mut state,
                    &mut compose,
                    MailComposeKind::Parcel,
                    !had_mail_parent,
                );
                parcel.window.position = mail_parcel::MAIL_PARCEL_DEFAULT_POSITION;
            }
            MailServiceEvent::Cost { cost } => {
                let draft = (state.mail_open() && compose.kind == MailComposeKind::Parcel)
                    .then(|| state.core.mail_compose.as_ref())
                    .flatten();
                parcel.apply_cost(cost, draft, &inventory);
            }
            MailServiceEvent::LockedItem { unique_id, locked } => {
                parcel.apply_lock_receipt(unique_id, locked);
                clear_mail_locked_inventory_interaction(&mut state, &inventory, &parcel);
            }
        }
    }
}

fn sync_mail_parcel_quote(
    shell: Res<NativeShellModel>,
    mut state: ResMut<NativePlayerUiState>,
    compose: Res<MailComposeUi>,
    inventory: Res<InventoryModel>,
    reset: Option<Res<SessionResetRevision>>,
    pending: Res<PendingOperations>,
    mut parcel: ResMut<mail_parcel::MailParcelUi>,
    mut intents: ResMut<NativePlayerUiIntentQueue>,
) {
    let revision = reset.as_deref().map_or(0, |revision| revision.0);
    if parcel.session_reset(revision).is_some() {
        // The native session boundary clears the outbound queue. Never emit a
        // stale-account unlock after it; local selected identities are gone.
        return;
    }
    let active = shell.screen == NativeShellScreen::InGame
        && state.mail_open()
        && compose.kind == MailComposeKind::Parcel
        && state.core.mail_compose.is_some();
    if !active {
        if parcel.selected_ids().next().is_some() {
            release_mail_parcel_locks(&mut parcel, &mut intents);
        }
        return;
    }
    let Some(draft) = state.core.mail_compose.as_mut() else {
        return;
    };
    let (unlock, lock) = parcel.reconcile_draft(draft, &inventory);
    for unique_id in unlock {
        let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem {
            unique_id,
            locked: false,
        });
    }
    for unique_id in lock {
        let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem {
            unique_id,
            locked: true,
        });
    }
    if pending.has_pending_mail_send() {
        return;
    }
    let now = crate::hero_model::hero_clock_ms();
    parcel.tick_quote_timeout(now);
    if let Some(fingerprint) = parcel.begin_quote(draft, &inventory, now) {
        let _ = intents.push_transient_unique(NativePlayerUiIntent::MailCost {
            gold: fingerprint.gold,
            attachment_unique_ids: fingerprint.attachment_unique_ids,
            stamped: fingerprint.stamped,
        });
    }
}

fn begin_mail_recipient_prompt(state: &mut NativePlayerUiState, compose: &mut MailComposeUi) {
    begin_mail_recipient_prompt_for(state, compose, MailComposeKind::Letter);
}

#[derive(SystemParam)]
struct OverlayRenderModels<'w> {
    asset_server: Option<Res<'w, AssetServer>>,
    wing_materials: Option<Res<'w, CrystalCharacterWingMaterials>>,
    game_shop_geometry: Option<Res<'w, game_shop_dialog::PreviewGeometry>>,
    shell: Option<Res<'w, NativeShellModel>>,
    state: Res<'w, NativePlayerUiState>,
    inventory: Res<'w, InventoryModel>,
    inventory_feedback: Res<'w, InventoryOperationFeedback>,
    mail: Res<'w, MailModel>,
    mail_ui: Res<'w, MailUiState>,
    compose_ui: Res<'w, MailComposeUi>,
    letter_window: Option<Res<'w, mail_compose_drag::MailLetterWindow>>,
    letter_editor: Option<Res<'w, mail_editor::MailLetterEditor>>,
    parcel_ui: Option<Res<'w, mail_parcel::MailParcelUi>>,
    big_map: Res<'w, BigMapModel>,
    big_map_ui: Res<'w, BigMapUiState>,
    ui: Res<'w, UiReadModel>,
    shop: Res<'w, ShopModel>,
    shop_ui: Res<'w, ShopUiState>,
    game_shop: Res<'w, GameShopModel>,
    storage: Res<'w, StorageModel>,
    storage_ui: Res<'w, StorageUiState>,
    skills: Res<'w, SkillModel>,
    skill_binding: Res<'w, SkillBindingUi>,
    skill_persistence: Res<'w, SkillBindingPersistenceRuntime>,
    social: Res<'w, crate::social::SocialModel>,
    combat_target: Option<Res<'w, crate::quest_model::CombatTargetModel>>,
}

pub struct Mir2CrystalOverlayPlugin;

impl Plugin for Mir2CrystalOverlayPlugin {
    fn build(&self, app: &mut App) {
        // Unit-only Apps intentionally omit AssetPlugin/RenderPlugin. Keep the
        // pure interaction systems usable there, while every real renderer
        // registers the exact Crystal DrawBlend material and embedded shader.
        if app.world().contains_resource::<AssetServer>()
            && app.world().contains_resource::<Assets<Shader>>()
        {
            register_crystal_additive_ui(app);
            app.add_systems(Startup, load_character_wing_materials);
        }
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<localized_help::HelpScrollState>()
            .add_systems(Update, (localized_help::scroll_help, localized_help::capture_help_scroll).chain().before(render_overlays))
            .add_systems(PostUpdate, localized_help::restore_help_scroll.before(bevy::ui::UiSystems::Layout))
            .init_resource::<keyboard_dialog::host::KeyboardHost>()
            .init_resource::<equipment_creature_host::MenuHost>()
            .init_resource::<social_bond_dialog::host::SocialHost>()
            .init_resource::<group_dialog::GroupHost>()
            .init_resource::<guild_panel::GuildHost>()
            .init_resource::<friend_dialog::host::FriendHost>()
            .init_resource::<UiEffectQueue>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<InventoryOperationFeedback>()
            .init_resource::<AuthoritativeModelRevisions>()
            .init_resource::<SessionResetRevision>()
            .init_resource::<SessionResetGameShopPreservation>()
            .init_resource::<NativeSessionBoundaryTracker>()
            .init_resource::<OverlayResetTracker>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MailComposeUi>()
            .init_resource::<mail_compose_drag::MailLetterWindow>()
            .init_resource::<mail_editor::MailLetterEditor>()
            .init_resource::<mail_parcel::MailParcelUi>()
            .init_resource::<MailServiceInbox>()
            .init_resource::<options_volume::OptionsVolumeDrag>()
            .init_resource::<BigMapModel>()
            .init_resource::<BigMapGatewayIntentQueue>()
            .init_resource::<BigMapUiState>()
            .init_resource::<crate::skill_model::SkillModelReceipts>()
            .init_resource::<SkillBindingUi>()
            .init_resource::<SkillBindingPersistenceRuntime>()
            .init_resource::<MailUiState>()
            .init_resource::<StorageUiState>()
            .init_resource::<StorageInventoryPlacement>()
            .init_resource::<ShopUiState>()
            .init_resource::<MapModel>()
            .init_resource::<UiReadModel>()
            .init_resource::<UiSurfaceSignals>()
            .init_resource::<NativeShellModel>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<ShopModel>()
            .init_resource::<GameShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::storage::StorageUiFeedback>()
            .init_resource::<crate::hero_model::HeroModel>()
            .init_resource::<crate::hero_model::HeroModelReceipts>()
            .init_resource::<SkillModel>()
            .init_resource::<crate::social::SocialModel>()
            .init_resource::<crate::options_effects::OptionsRuntime>()
            .init_resource::<crate::audio::NativeAudioRuntime>()
            .init_resource::<crate::audio::NativeGameplayAudioQueue>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .init_resource::<InventoryBeltDiagnostics>()
            .add_message::<CursorMoved>()
            .add_message::<MouseWheel>()
            .add_message::<bevy::window::Ime>()
            .init_resource::<text_input::ImeState>()
            .add_systems(
                Update,
                text_input::process_ime
                    .after(PendingLifecycleSet::UiReset)
                    .before(NativePlayerUiSet::Mutate),
            )
            .add_systems(
                PostUpdate,
                text_input::position_ime
                    .after(bevy::ui::UiSystems::Layout)
                    .after(mail_editor::capture_layout_system),
            )
            .add_systems(
                PostUpdate,
                mail_editor::capture_layout_system.after(bevy::ui::UiSystems::Layout),
            )
            .add_systems(Startup, spawn_overlay_root)
            .add_systems(
                Startup,
                (
                    crate::skill_binding_persistence::load_persisted_skill_bindings,
                    crate::options_effects::load_persisted_options,
                    crate::audio::initialize_native_audio,
                )
                    .chain(),
            )
            .configure_sets(
                Update,
                NativePlayerUiSet::Mutate.before(NativePlayerUiSet::Read),
            )
            .configure_sets(
                Update,
                PendingLifecycleSet::UiReset.before(NativePlayerUiSet::Mutate),
            )
            .add_systems(
                Update,
                crate::pending_operations::apply_overlay_session_reset
                    .in_set(PendingLifecycleSet::UiReset),
            )
            .add_systems(
                Update,
                (
                    sync_big_map_ui,
                    sync_local_panel_models,
                    sync_npc_dialog_inventory_location,
                    sync_storage_inventory_location,
                    sync_storage_password_prompt,
                    sync_storage_rental_confirmation,
                    sync_guild_storage_ui,
                    trade_dialog::sync,
                    sync_mail_letter_editor,
                    process_mail_service_inbox,
                    sync_mail_parcel_quote,
                )
                    .chain()
                    .in_set(NativePlayerUiSet::Mutate)
                    .before(consume_hud_buttons)
                    .before(process_overlay_keyboard),
            )
            .add_systems(
                Update,
                (
                    consume_mail_operation_feedback,
                    consume_hud_buttons,
                    (
                        process_help_drag,
                        mail_reader_drag::process,
                        mail_compose_drag::process,
                        mail_parcel::process_drag,
                        process_mail_letter_editor_pointer,
                        process_mail_letter_editor_wheel,
                    )
                        .chain(),
                    keyboard_dialog::host::process,
                    (
                        equipment_creature_host::process,
                        social_bond_dialog::host::process,
                        leave_game_dialog::process,
                        group_dialog::process,
                        skill_assign_dialog::process,
                        hero_dialog::host::observe,
                        hero_dialog::cross::process,
                        hero_dialog::host::process,
                        skill_bars::host::process,
                        status_hud::process,
                        hero_buff_hud::process,
                        guild_panel::process,
                    )
                        .chain(),
                    friend_dialog::host::process,
                    (ranking_dialog::process, process_queued_mail_letter_request).chain(),
                    trade_dialog::process_items,
                    trade_dialog::process_drag,
                    (
                        process_inventory_item_drag,
                        process_inventory_drag,
                        game_shop_dialog::process_pointer,
                    )
                        .chain(),
                    process_inventory_delete_pointer,
                    process_guild_storage_pointer,
                    (process_overlay_keyboard, options_volume::process).chain(),
                    (
                        process_overlay_buttons,
                        sync_npc_shop_inventory_location,
                        keyboard_dialog::host::sync_skill_mode,
                    )
                        .chain(),
                    crate::audio::sync_native_ui_audio,
                    consume_exit_application,
                    crate::pending_operations::observe_native_session_boundary,
                    (reconcile_native_game_shop_ui_state, game_shop_dialog::sync).chain(),
                    crate::options_effects::consume_options_effects,
                    crate::audio::sync_native_audio,
                )
                    .chain()
                    .in_set(NativePlayerUiSet::Mutate),
            )
            .add_systems(
                Update,
                npc_item_service::drain_service_notice
                    .after(process_overlay_buttons)
                    .in_set(NativePlayerUiSet::Mutate),
            )
            .add_systems(
                Update,
                (
                    (
                        render_overlays,
                        big_map_coordinates::update,
                        game_shop_dialog::render_confirmation_system,
                    )
                        .chain(),
                    social_bond_dialog::host::render_system,
                    leave_game_dialog::render,
                    group_dialog::render,
                    group_dialog::render_invitation,
                    skill_assign_dialog::render,
                    hero_dialog::cross::render_order,
                    hero_dialog::render::render,
                    hero_dialog::render::button_visuals,
                    skill_bars::host::render,
                    (
                        status_hud::render,
                        status_hud::render_hint,
                        hero_buff_hud::render,
                        hero_buff_hud::hint,
                    )
                        .chain(),
                    guild_panel::render_error,
                    guild_panel::render_buff_hint,
                    equipment_creature_host::render_system,
                    friend_dialog::host::render_system,
                    ranking_dialog::render_system,
                    keyboard_dialog::host::render_system,
                    (layout_original_item_images, mail_list::layout_icons).chain(),
                )
                    .chain()
                    .in_set(NativePlayerUiSet::Read),
            );
    }
}

/// Keep renderer-local BigMap focus and pending requests inside the current
/// authoritative map/session epoch. Opening the panel requests the current
/// map definition once; it never fabricates a map record locally.
fn sync_big_map_ui(
    state: Res<NativePlayerUiState>,
    model: Res<BigMapModel>,
    mut intents: ResMut<BigMapGatewayIntentQueue>,
    mut ui: ResMut<BigMapUiState>,
    quests: Option<Res<crate::quest_model::QuestTracker>>,
    guidance: Option<Res<crate::quest_guidance::QuestGuidance>>,
    quest_state: Option<Res<crate::quest_ui::QuestUiState>>,
    catalog: Option<Res<crate::quest_journey::NewcomerJourneyCatalog>>,
    completed: Option<Res<crate::quest_model::CompletedQuestTracker>>,
    gameplay: Option<Res<UiReadModel>>,
) {
    intents.sync_model(&model);
    let journey = catalog.as_deref().zip(guidance.as_deref())
        .zip(quests.as_deref()).zip(completed.as_deref()).zip(gameplay.as_deref())
        .and_then(|((((catalog, guidance), quests), completed), gameplay)| {
            catalog.derive(guidance, quests, completed, &gameplay.player)
        });
    let primary = quests.as_deref().zip(quest_state.as_deref()).and_then(|(quests, state)| {
        crate::quest_ui::primary_quest_index(quests, state, journey.as_ref())
    });
    let destination = model.active_map().is_some_and(|map| {
        crate::quest_destination::is_bichon_map(map.map_index)
    }) && quests.as_deref().is_some_and(crate::quest_destination::bichon_safe_arrival_pending)
        && (quest_state.is_none() || primary == Some(2_110_005));
    if ui.bichon_safe_destination != destination {
        ui.bichon_safe_destination = destination;
    }
    let regions = if guidance.as_deref().and_then(|g| g.profile_name()) == Some("newcomer-v2") {
        model.active_map().zip(quests.as_deref()).map(|(map, quests)| {
            crate::quest_hunt_regions::active_hunt_regions_for_primary(
                quests, map.map_index, model.player_location.unwrap_or_default(), primary,
            )
        }).unwrap_or_default()
    } else { Vec::new() };
    if ui.hunt_regions != regions { ui.hunt_regions = regions; }
    if ui.last_reset_epoch != Some(model.reset_epoch) {
        ui.search_focused = false;
        ui.last_reset_epoch = Some(model.reset_epoch);
        ui.requested_epoch_map = None;
    }

    let open = state.bigmap_open();
    if open {
        // MapInformation may arrive after the panel became visible. Queue the
        // request as soon as that authoritative identity exists instead of
        // tying it only to the first open frame. Never request a map that is
        // already present in the authoritative NewMapInfo cache.
        if let Some(map_index) = model.missing_current_map_index() {
            let request_key = (model.reset_epoch, map_index);
            if ui.requested_epoch_map != Some(request_key)
                && intents.request_map_info(&model, map_index)
            {
                ui.requested_epoch_map = Some(request_key);
            }
        }
    }
    if !open {
        ui.search_focused = false;
    }
}

fn sync_local_panel_models(
    shell: Res<NativeShellModel>,
    mut state: ResMut<NativePlayerUiState>,
    mut mail: ResMut<MailModel>,
    mut mail_ui: ResMut<MailUiState>,
    mut compose_ui: ResMut<MailComposeUi>,
    inventory: Res<InventoryModel>,
    mut storage: ResMut<StorageModel>,
    mut storage_ui: ResMut<StorageUiState>,
    shop: Res<ShopModel>,
    mut shop_ui: ResMut<ShopUiState>,
    mut skill_binding: ResMut<SkillBindingUi>,
    mut skills: ResMut<SkillModel>,
    mut skill_receipts: Option<ResMut<crate::skill_model::SkillModelReceipts>>,
) {
    state.mail_delete_input_consumed = false;
    state.mail_feedback_input_consumed = false;
    state.mail_recipient_input_consumed = false;
    state.mail_reader_input_consumed = false;
    state.parcel_gold_input_consumed = false;
    if shell.screen != NativeShellScreen::InGame {
        clear_mail_feedback(&mut state, &mut compose_ui);
        clear_mail_recipient_prompt(&mut state, &mut compose_ui);
        compose_ui.kind = MailComposeKind::Letter;
        compose_ui.letter_draft = None;
        compose_ui.parcel_draft = None;
        state.mail_inventory_visible = false;
    }
    reconcile_inventory_capacity(&mut state, &inventory);
    if !state.inventory_open() {
        state.inventory_delete_mode = false;
        state.inventory_delete_prompt = None;
    } else if state
        .inventory_delete_prompt
        .as_ref()
        .is_some_and(|prompt| !inventory_delete_prompt_is_current(prompt, &inventory))
    {
        // Never leave a destructive modal addressing a replaced authoritative
        // stack after an inventory refresh.
        state.cancel_inventory_delete();
    }
    mail.clamp_after_refresh(&mut mail_ui.cursor);
    if !state.mail_open() && compose_ui.recipient_prompt.is_some() {
        // This is a parent-panel/session close, not the visible prompt's
        // Cancel control. Discard the suspended payload so a hidden compose
        // cannot reappear after the Mail panel has been closed.
        clear_mail_recipient_prompt(&mut state, &mut compose_ui);
        state.mail_recipient_input_consumed = true;
        state.core.mail_compose = None;
    }
    if !state.mail_open() || state.core.mail_compose.is_none() {
        state.mail_inventory_visible = false;
        state.parcel_gold_prompt = None;
    }
    if !state.mail_open()
        || state
            .mail_delete_prompt
            .as_ref()
            .is_some_and(|prompt| !mail_delete_prompt_is_current(prompt, &mail))
    {
        state.mail_delete_input_consumed |= state.mail_delete_prompt.is_some();
        state.mail_delete_prompt = None;
    }
    if state
        .mail_reader
        .as_ref()
        .is_some_and(|reader| !mail_reader_is_current(reader, &mail))
    {
        state.mail_reader_input_consumed = true;
        state.mail_reader = None;
    }
    storage.clamp_after_refresh(&mut storage_ui.cursor);
    storage_ui.bag_selection = storage_ui.bag_selection.filter(|selection| {
        inventory_selection_for_slot(&inventory, selection.slot) == Some(*selection)
    });
    storage_ui.storage_selection = storage_ui
        .storage_selection
        .filter(|selection| storage.item_for_selection(*selection).is_some());
    shop_ui.start_index = shop_ui.start_index.min(shop.goods.len().saturating_sub(8));
    if state.npc_service_notice.is_some()
        && state.npc_service_notice_mode != Some(shop.service_mode)
    {
        state.npc_service_notice = None;
        state.npc_service_notice_mode = None;
    }

    // A transport callback and its server receipt can arrive in one frame.
    // Keep receipts until process has established the exact pending request.
    if !state.skill_assign.pending && state.skill_assign.result != Some(true) {
        if let Some(receipts) = skill_receipts.as_deref_mut() {
            for mut received in receipts.0.drain(..) {
                if let Some(draft) = state.skill_authority.reconcile(&mut received) {
                    if !state.skill_assign.open {
                        skill_binding.select_skill(draft.skill_id, &received);
                        skill_binding.set_assign_key(true);
                        state.skill_assign = draft;
                    }
                }
            }
        }
    }
    if let Some(draft) = state.skill_authority.reconcile(&mut skills) {
        if !state.skill_assign.open {
            skill_binding.select_skill(draft.skill_id, &skills);
            skill_binding.set_assign_key(true);
            state.skill_assign = draft;
        }
    }
    skill_binding.refresh(&skills);

    if shell.screen != NativeShellScreen::InGame {
        mail_ui.cursor = MailPageCursor::default();
        storage_ui.cursor = StoragePageCursor::default();
        storage_ui.bag_selection = None;
        storage_ui.storage_selection = None;
        shop_ui.start_index = 0;
        state.skill_authority = Default::default();
        skill_binding.bindings.clear();
        skill_binding.clear_selection();
        skill_binding.set_assign_key(false);
    }
}

fn reconcile_inventory_capacity(
    state: &mut NativePlayerUiState,
    inventory: &InventoryModel,
) -> bool {
    if state.inventory_page != 1 || inventory.second_bag_unlocked() {
        return false;
    }
    state.inventory_page = 0;
    state.inspect = None;
    state.inventory_operation = None;
    state.inventory_item_drag = None;
    state.drop_confirmation = None;
    true
}

fn sync_guild_storage_ui(
    shell: Res<NativeShellModel>,
    mut state: ResMut<NativePlayerUiState>,
    social: Res<crate::social::SocialModel>,
) {
    let active = shell.screen == NativeShellScreen::InGame
        && state.guild_open()
        && state.guild_left_page == GuildLeftPage::Storage;
    if !active {
        state.guild_storage.end_drag();
    }
    if state.guild_gold_prompt.as_ref().is_some_and(|prompt| {
        !active
            || social.guild.name.as_deref() != Some(prompt.guild_name.as_str())
            || (prompt.action == GuildGoldAction::Withdraw && social.guild.my_rank_id != 0)
    }) {
        state.guild_gold_prompt = None;
    }
}

fn open_guild_gold_prompt(
    state: &mut NativePlayerUiState,
    guild: &crate::social::GuildModel,
    player_gold: u32,
    action: GuildGoldAction,
    now_ms: u64,
) -> bool {
    let Some(name) = guild.name.as_ref().filter(|name| !name.is_empty()) else {
        return false;
    };
    if !state.guild_open()
        || state.guild_left_page != GuildLeftPage::Storage
        || state.amount_modal_open()
        || now_ms < state.guild_gold_ready_at_ms
        || (action == GuildGoldAction::Withdraw && guild.my_rank_id != 0)
    {
        return false;
    }
    // GuildDialog does not require CanStoreItem to donate gold. Withdrawal is
    // leader-only, independently of CanRetrieveItem. The server repeats these
    // checks and owns safe-zone, balance, capacity and mutation authority.
    let maximum = match action {
        GuildGoldAction::Deposit => player_gold,
        GuildGoldAction::Withdraw => guild.gold,
    };
    state.guild_gold_prompt = Some(GuildGoldPrompt::new(action, name.clone(), maximum));
    state.guild_storage.end_drag();
    true
}

/// A valid OK closes the amount box even for zero. Never optimistically mutate
/// gold, reuse an old guild identity, or submit against a stale rank/balance.
fn confirm_guild_gold(
    state: &mut NativePlayerUiState,
    social: &mut crate::social::SocialModel,
    player_gold: u32,
    now_ms: u64,
    intents: &mut NativePlayerUiIntentQueue,
) -> bool {
    let Some(amount) = state
        .guild_gold_prompt
        .as_ref()
        .and_then(GuildGoldPrompt::amount)
    else {
        return false;
    };
    let prompt = state
        .guild_gold_prompt
        .take()
        .expect("validated amount prompt");
    let guild = &social.guild;
    let current = state.guild_open()
        && state.guild_left_page == GuildLeftPage::Storage
        && guild.name.as_deref() == Some(prompt.guild_name.as_str())
        && match prompt.action {
            GuildGoldAction::Deposit => amount <= player_gold,
            GuildGoldAction::Withdraw => guild.my_rank_id == 0 && amount <= guild.gold,
        };
    if amount > 0
        && current
        && now_ms >= state.guild_gold_ready_at_ms
        && intents.push_social_pending(
            social,
            NativePlayerUiIntent::GuildStorageGoldChange {
                change_type: prompt.action.change_type(),
                amount,
            },
        )
    {
        state.guild_gold_ready_at_ms = now_ms.saturating_add(100);
    }
    true
}

/// Keep the native overlay's shared UiState correlation shadow aligned with
/// the runtime-owned GameShopModel. The runtime is feature-agnostic and owns
/// the receipt gate; this adapter is the only native-ui bridge that may mirror
/// or release UiState's pending request.
pub fn reconcile_native_game_shop_ui_state(
    mut state: ResMut<NativePlayerUiState>,
    game_shop: Res<GameShopModel>,
) {
    if let Some(pending) = game_shop.pending_purchase.as_ref() {
        if state.core.game_shop_pending.is_none() {
            state.core.game_shop_pending = Some(pending.clone());
            state.core.game_shop_next_request_id = game_shop.next_request_id;
            state.core.game_shop_unknown = game_shop.purchase_unknown;
        }
        return;
    }

    if let Some(receipt) = game_shop.last_receipt.as_ref() {
        if state
            .core
            .game_shop_pending
            .as_ref()
            .is_some_and(|request| receipt.matches_request(request))
        {
            let _ = state.core.apply_game_shop_receipt(receipt.clone());
        }
    } else if game_shop.purchase_unknown {
        state.core.mark_game_shop_unknown();
    } else if state.core.game_shop_pending.is_some() {
        state.core.clear_game_shop_session();
    }
    state.core.game_shop_next_request_id = game_shop.next_request_id;
}

pub fn inspect_label(item: &ItemModel) -> String {
    format!(
        "{}  x{}  [{}] slot {}",
        if item.name.is_empty() {
            item.key.as_str()
        } else {
            item.name.as_str()
        },
        item.quantity,
        container_name(item.container),
        item.slot
    )
}

pub fn container_name(container: u8) -> &'static str {
    match container {
        1 => "belt",
        2 => "equipment",
        3 => "quest",
        4 => "storage",
        _ => "inventory",
    }
}

pub fn item_unique_id(item: &ItemModel) -> Option<u64> {
    item.unique_id
}

pub fn equip_destination_for_name(name: &str) -> i32 {
    let lowered = name.to_ascii_lowercase();
    if lowered.contains("pendant") || lowered.contains("necklace") {
        4
    } else if lowered.contains("ring") {
        7
    } else if lowered.contains("bracelet") {
        5
    } else if lowered.contains("helmet") {
        2
    } else if lowered.contains("boot") {
        11
    } else if lowered.contains("belt") {
        10
    } else if lowered.contains("armour") || lowered.contains("armor") {
        1
    } else {
        0
    }
}

fn equip_destination_for_item(item: &ItemModel) -> i32 {
    let authoritative_slot =
        item.equip_slot
            .as_deref()
            .and_then(|slot| match slot.to_ascii_lowercase().as_str() {
                "weapon" => Some(0),
                "armour" | "armor" => Some(1),
                "helmet" => Some(2),
                "torch" => Some(3),
                "necklace" => Some(4),
                "braceletleft" => Some(5),
                "braceletright" => Some(6),
                "ringleft" => Some(7),
                "ringright" => Some(8),
                "amulet" => Some(9),
                "belt" => Some(10),
                "boots" => Some(11),
                "stone" => Some(12),
                "mount" => Some(13),
                _ => None,
            });
    authoritative_slot.unwrap_or_else(|| equip_destination_for_name(&item.name))
}

pub fn equipment_slot_name(slot: u32) -> &'static str {
    match slot {
        0 => "Weapon",
        1 => "Armour",
        2 => "Helmet",
        3 => "Torch",
        4 => "Necklace",
        5 => "Bracelet L",
        6 => "Bracelet R",
        7 => "Ring L",
        8 => "Ring R",
        9 => "Amulet",
        10 => "Belt",
        11 => "Boots",
        12 => "Stone",
        13 => "Mount",
        _ => "Slot",
    }
}

pub fn belt_use_intent(slot: u8) -> NativePlayerUiIntent {
    NativePlayerUiIntent::UseItem {
        key: None,
        unique_id: None,
        slot: Some(slot),
        grid: Some("belt".to_owned()),
    }
}

/// Resolve a mouse click against the current server-derived belt model. This
/// rejects an empty/legacy slot rather than sending a slot-only request that
/// could consume a newer stack after a snapshot refresh.
pub fn belt_item_use_intent(inventory: &InventoryModel, slot: u8) -> Option<NativePlayerUiIntent> {
    let item = crate::crystal_ui::hud::belt_slot_item(inventory, slot)?;
    Some(NativePlayerUiIntent::UseItem {
        key: Some(item.key.clone()),
        unique_id: Some(item.unique_id?),
        slot: Some(slot),
        grid: Some("belt".to_owned()),
    })
}

fn inventory_bag_to_belt_move_intent(
    source_slot: u32,
    unique_id: u64,
    belt_slot: u8,
) -> NativePlayerUiIntent {
    NativePlayerUiIntent::MoveItem {
        // Inventory moves in the existing web/native contract use normalized
        // bag indices. Belt marks the unambiguous compatibility path whose
        // endpoints use Crystal's unified raw inventory indices.
        grid: "belt".to_owned(),
        unique_id,
        from: i32::try_from(source_slot.saturating_add(6)).unwrap_or(i32::MAX),
        to: i32::from(belt_slot),
    }
}

fn spawn_overlay_root(mut commands: Commands) {
    commands
        .spawn((
            OverlayRoot,
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(0.0),
                top: Val::Px(0.0),
                width: Val::Px(1024.0),
                height: Val::Px(768.0),
                display: Display::None,
                ..default()
            },
            GlobalZIndex(985),
            BackgroundColor(Color::NONE),
        ))
        .with_children(|root| {
            root.spawn((
                OverlayInventory,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(INVENTORY_PANEL_ORIGIN.x as f32),
                    top: Val::Px(INVENTORY_PANEL_ORIGIN.y as f32),
                    width: Val::Px(INVENTORY_PANEL_SIZE.width as f32),
                    height: Val::Px(INVENTORY_PANEL_SIZE.height as f32),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            // A Crystal MirAmountBox/MirMessageBox is modal to the entire
            // scene. The full-stage Button consumes pointer hits that would
            // otherwise reach Inventory controls beneath the prompt.
            root.spawn((
                OverlayInventoryDeleteModal,
                Button,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_INVENTORY_DELETE_MODAL_Z),
                BackgroundColor(Color::NONE),
            ));
            // MailDialog's parcel warning and one-button result feedback
            // share a source MirMessageBox host. Feedback replaces a stale
            // warning on this root and therefore remains above the reader.
            root.spawn((
                OverlayMailDeleteModal,
                OverlayMailFeedbackModal,
                Button,
                FocusPolicy::Block,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_MAIL_FEEDBACK_MODAL_Z),
                BackgroundColor(Color::NONE),
            ));
            // StorageDialog's MirInputBox is modal to every underlying
            // control, including the concurrent bag/storage panels.
            root.spawn((
                OverlayStoragePasswordModal,
                Button,
                FocusPolicy::Block,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_INVENTORY_DELETE_MODAL_Z),
                BackgroundColor(Color::NONE),
            ));
            // StorageDialog Rent uses an ordinary MirMessageBox OK/Cancel
            // confirmation. Like the password prompt it captures the full
            // stage while visible.
            root.spawn((
                OverlayStorageRentalModal,
                Button,
                FocusPolicy::Block,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_INVENTORY_DELETE_MODAL_Z),
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayInventoryDeleteCursor,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(CRYSTAL_DELETE_CURSOR_SIZE.0),
                    height: Val::Px(CRYSTAL_DELETE_CURSOR_SIZE.1),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_INVENTORY_DELETE_CURSOR_Z),
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayGuildGoldModal,
                Button,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_INVENTORY_DELETE_MODAL_Z),
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayTrade,
                Node {
                    position_type: PositionType::Absolute,
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayTradeGoldModal,
                Button,
                Node {
                    position_type: PositionType::Absolute,
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_INVENTORY_DELETE_MODAL_Z),
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayEquipment,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(CRYSTAL_CHARACTER_PANEL_RECT.left),
                    top: Val::Px(CRYSTAL_CHARACTER_PANEL_RECT.top),
                    width: Val::Px(CRYSTAL_CHARACTER_PANEL_RECT.width),
                    height: Val::Px(CRYSTAL_CHARACTER_PANEL_RECT.height),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayMenu,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(CRYSTAL_MENU_PANEL_RECT.left),
                    top: Val::Px(CRYSTAL_MENU_PANEL_RECT.top),
                    width: Val::Px(CRYSTAL_MENU_PANEL_RECT.width),
                    height: Val::Px(CRYSTAL_MENU_PANEL_RECT.height),
                    display: Display::None,
                    ..default()
                },
                GlobalZIndex(OVERLAY_MENU_Z),
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayHelp,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(CRYSTAL_HELP_PANEL_RECT.left),
                    top: Val::Px(CRYSTAL_HELP_PANEL_RECT.top),
                    width: Val::Px(CRYSTAL_HELP_PANEL_RECT.width),
                    height: Val::Px(CRYSTAL_HELP_PANEL_RECT.height),
                    display: Display::None,
                    overflow: Overflow::clip(),
                    ..default()
                },
                GlobalZIndex(OVERLAY_NPC_DIALOG_Z),
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlaySkill,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(CRYSTAL_CHARACTER_PANEL_RECT.left),
                    top: Val::Px(CRYSTAL_CHARACTER_PANEL_RECT.top),
                    width: Val::Px(SKILL_PANEL_SIZE.width as f32),
                    height: Val::Px(SKILL_PANEL_SIZE.height as f32),
                    display: Display::None,
                    overflow: Overflow::clip(),
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayInspect,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(390.0),
                    top: Val::Px(170.0),
                    width: Val::Px(240.0),
                    display: Display::None,
                    flex_direction: FlexDirection::Column,
                    padding: UiRect::all(Val::Px(8.0)),
                    row_gap: Val::Px(4.0),
                    ..default()
                },
                BackgroundColor(PANEL_BG),
            ));
            root.spawn((
                OverlayDeath,
                GlobalZIndex(OVERLAY_DEATH_Z),
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(312.0),
                    top: Val::Px(240.0),
                    width: Val::Px(400.0),
                    display: Display::None,
                    flex_direction: FlexDirection::Column,
                    padding: UiRect::all(Val::Px(12.0)),
                    row_gap: Val::Px(6.0),
                    align_items: AlignItems::Center,
                    ..default()
                },
                BackgroundColor(Color::srgba(0.18, 0.03, 0.03, 0.88)),
            ));
            root.spawn((
                OverlayChatDraft,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(230.0),
                    top: Val::Px(648.0),
                    width: Val::Px(420.0),
                    height: Val::Px(20.0),
                    display: Display::None,
                    padding: UiRect::all(Val::Px(2.0)),
                    ..default()
                },
                BackgroundColor(Color::srgba(0.0, 0.0, 0.0, 0.75)),
            ));
            root.spawn((
                OverlayMail,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(562.0),
                    top: Val::Px(5.0),
                    width: Val::Px(312.0),
                    height: Val::Px(444.0),
                    display: Display::None,
                    flex_direction: FlexDirection::Column,
                    padding: UiRect::all(Val::Px(10.0)),
                    row_gap: Val::Px(6.0),
                    ..default()
                },
                BackgroundColor(PANEL_BG),
            ));
            root.spawn((
                OverlayMailReadLetter,
                FocusPolicy::Block,
                GlobalZIndex(OVERLAY_NPC_DIALOG_Z),
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(100.0),
                    top: Val::Px(100.0),
                    width: Val::Px(236.0),
                    height: Val::Px(300.0),
                    display: Display::None,
                    overflow: Overflow::clip(),
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayMailComposeLetter,
                FocusPolicy::Block,
                GlobalZIndex(OVERLAY_NPC_DIALOG_Z),
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(CRYSTAL_MAIL_LETTER_RECT.left),
                    top: Val::Px(CRYSTAL_MAIL_LETTER_RECT.top),
                    width: Val::Px(CRYSTAL_MAIL_LETTER_RECT.width),
                    height: Val::Px(CRYSTAL_MAIL_LETTER_RECT.height),
                    display: Display::None,
                    overflow: Overflow::clip(),
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayMailComposeParcel,
                FocusPolicy::Block,
                GlobalZIndex(OVERLAY_NPC_DIALOG_Z),
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(mail_parcel::MAIL_PARCEL_DEFAULT_POSITION.x),
                    top: Val::Px(mail_parcel::MAIL_PARCEL_DEFAULT_POSITION.y),
                    width: Val::Px(mail_parcel::MAIL_PARCEL_SIZE.x),
                    height: Val::Px(mail_parcel::MAIL_PARCEL_SIZE.y),
                    display: Display::None,
                    overflow: Overflow::clip(),
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            // Source Title675's exported frame is 236x384 even though the
            // dialog constructor declared 236x300. Its controls reach y=375.
            root.spawn((
                OverlayMailReadParcel,
                FocusPolicy::Block,
                GlobalZIndex(OVERLAY_NPC_DIALOG_Z),
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(100.0),
                    top: Val::Px(100.0),
                    width: Val::Px(236.0),
                    height: Val::Px(384.0),
                    display: Display::None,
                    overflow: Overflow::clip(),
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayBigMap,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(CRYSTAL_BIGMAP_PANEL_RECT.left),
                    top: Val::Px(CRYSTAL_BIGMAP_PANEL_RECT.top),
                    width: Val::Px(CRYSTAL_BIGMAP_PANEL_RECT.width),
                    height: Val::Px(CRYSTAL_BIGMAP_PANEL_RECT.height),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayShop,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(NPC_GOODS_PANEL_ORIGIN.x as f32),
                    top: Val::Px(NPC_GOODS_PANEL_ORIGIN.y as f32),
                    width: Val::Px(NPC_DIALOG_PANEL_SIZE.width as f32),
                    height: Val::Px(NPC_GOODS_PANEL_SIZE.height as f32),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
                FocusPolicy::Pass,
            ));
            root.spawn((
                OverlayGameShop,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px((1024.0 - GAME_SHOP_PANEL_SIZE.width as f32) / 2.0),
                    top: Val::Px((768.0 - GAME_SHOP_PANEL_SIZE.height as f32) / 2.0),
                    width: Val::Px(GAME_SHOP_PANEL_SIZE.width as f32),
                    height: Val::Px(GAME_SHOP_PANEL_SIZE.height as f32),
                    display: Display::None,
                    overflow: Overflow::clip(),
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayStorage,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(388.0),
                    height: Val::Px(346.0),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlayOptions,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(CRYSTAL_OPTIONS_PANEL_RECT.left),
                    top: Val::Px(CRYSTAL_OPTIONS_PANEL_RECT.top),
                    width: Val::Px(CRYSTAL_OPTIONS_PANEL_RECT.width),
                    height: Val::Px(CRYSTAL_OPTIONS_PANEL_RECT.height),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
            root.spawn((
                OverlaySocial,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(1024.0),
                    height: Val::Px(768.0),
                    display: Display::None,
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ));
        });
}

fn consume_hud_buttons(
    mut state: ResMut<NativePlayerUiState>,
    buttons: Query<
        (&Interaction, &CrystalHudAction, Option<&CrystalImageButton>),
        Changed<Interaction>,
    >,
    overlay_buttons: Query<&Interaction, (With<OverlayButton>, Changed<Interaction>)>,
    shell: Option<Res<NativeShellModel>>,
    inventory: Res<InventoryModel>,
    parcel: Option<Res<mail_parcel::MailParcelUi>>,
    mut intents: ResMut<NativePlayerUiIntentQueue>,
    mut pending: Option<ResMut<PendingOperations>>,
    mut ui_audio: ResMut<crate::audio::NativeUiAudioQueue>,
    diagnostics: Option<Res<InventoryBeltDiagnostics>>,
) {
    if !shell.is_some_and(|model| model.screen == NativeShellScreen::InGame)
        || state.amount_modal_open()
        || state.storage_password_prompt.is_some()
        || state.storage_rental_confirmation.is_some()
    {
        return;
    }
    // Bevy can report both controls as pressed when a foreground dialog
    // button overlaps a HUD hit target. Crystal gives the top dialog the
    // pointer, so suppress every HUD action for that press edge. This keeps a
    // CharacterDialog close at (1007, 3) from also toggling the minimap below.
    if overlay_buttons
        .iter()
        .any(|interaction| *interaction == Interaction::Pressed)
    {
        return;
    }
    for (interaction, action, image_button) in buttons.iter() {
        if let CrystalHudAction::BeltUse(slot) = action {
            belt_diagnostic(diagnostics.as_deref(), || {
                format!(
                    "hud slot={slot} interaction={interaction:?} image_enabled={} move_draft={} pending_available={}",
                    image_button.is_none_or(|button| button.enabled),
                    matches!(state.inventory_operation, Some(InventoryOperationDraft::Move { .. })),
                    pending.is_some(),
                )
            });
        }
        if *interaction != Interaction::Pressed
            || image_button.is_some_and(|button| !button.enabled)
        {
            continue;
        }
        if let Some(sound) = hud_pointer_sound(*action) {
            ui_audio.push(sound);
        }
        match action {
            CrystalHudAction::Inventory => {
                state.toggle_inventory();
                if !state.inventory_open() {
                    state.inspect = None;
                    state.inventory_operation = None;
                    state.drop_confirmation = None;
                    state.inventory_delete_mode = false;
                    state.inventory_delete_prompt = None;
                }
            }
            CrystalHudAction::Character => {
                state.activate_character_hud_button();
            }
            CrystalHudAction::Menu => {
                state.toggle_menu();
            }
            CrystalHudAction::Skill => {
                state.toggle_skill();
                if !state.skill_open() {
                    state.selected_skill_id = None;
                }
            }
            CrystalHudAction::Quest => {
                state.toggle_quest();
            }
            CrystalHudAction::Option => {
                state.toggle_options();
            }
            CrystalHudAction::Mail => {
                state.toggle_mail();
            }
            CrystalHudAction::BigMap => {
                state.toggle_bigmap();
            }
            CrystalHudAction::MinimapToggle => {
                state.toggle_minimap();
            }
            CrystalHudAction::GameShop => {
                state.toggle_shop();
                if !state.shop_open() {
                    state.shop_quantity = 1;
                }
            }
            CrystalHudAction::BeltUse(slot) => {
                if let Some(InventoryOperationDraft::Move {
                    source_slot,
                    unique_id,
                }) = state.inventory_operation.clone()
                {
                    if parcel.as_ref().is_some_and(|parcel| parcel.blocks_item(unique_id)) {
                        state.inventory_operation = None;
                        continue;
                    }
                    let Some(pending) = pending.as_deref_mut() else {
                        continue;
                    };
                    let queued = intents.push_pending_intent(
                        pending,
                        inventory_bag_to_belt_move_intent(source_slot, unique_id, *slot),
                    );
                    belt_diagnostic(diagnostics.as_deref(), || {
                        format!("hud slot={slot} move_queue={queued}")
                    });
                    if queued {
                        state.inventory_operation = None;
                        state.inspect = None;
                    }
                    continue;
                }
                if let Some(intent) = belt_item_use_intent(&inventory, *slot) {
                    intents.push_transient_unique(intent);
                }
            }
        }
    }
}

fn hud_pointer_sound(action: CrystalHudAction) -> Option<crate::audio::NativeUiSound> {
    match action {
        // Crystal `MainDialog` assigns ButtonA to the five small lower-right
        // HUD buttons. Keep this bounded to source-audited controls.
        CrystalHudAction::Inventory
        | CrystalHudAction::Character
        | CrystalHudAction::Skill
        | CrystalHudAction::Quest
        | CrystalHudAction::Option => Some(crate::audio::NativeUiSound::ButtonA),
        // Crystal `MenuButton` and `GameShopButton` use the distinct
        // `SoundList.ButtonC` local UI cue.
        CrystalHudAction::Menu | CrystalHudAction::GameShop => {
            Some(crate::audio::NativeUiSound::ButtonC)
        }
        _ => None,
    }
}

fn consume_mail_operation_feedback(
    mut mail: ResMut<MailModel>,
    mut state: ResMut<NativePlayerUiState>,
    mut compose: ResMut<MailComposeUi>,
    mut parcel: Option<ResMut<mail_parcel::MailParcelUi>>,
    mut intents: Option<ResMut<NativePlayerUiIntentQueue>>,
) {
    let Some(feedback) = mail.operation_feedback().cloned() else {
        return;
    };
    match (feedback.kind, feedback.success) {
        // Crystal's MailSent handler closes the compose dialog rather than
        // showing a success box. Candidate rejection keeps the exact draft
        // retryable because its receipt carries no more specific reason.
        (MailOperationKind::Send, true) => {
            if let (Some(parcel), Some(intents)) = (parcel.as_deref_mut(), intents.as_deref_mut()) {
                complete_mail_parcel_send(parcel, intents);
            }
            state.core.mail_compose = None;
            compose.kind = MailComposeKind::Letter;
            state.mail_inventory_visible = false;
            clear_mail_recipient_prompt(&mut state, &mut compose);
            clear_mail_feedback(&mut state, &mut compose);
        }
        (MailOperationKind::Send, false) => {
            show_mail_feedback(&mut state, &mut compose, "Mail was rejected; draft kept");
        }
        // Crystal closes MailReadParcelDialog after a successful collection;
        // its error results are ordinary OK message boxes.
        (MailOperationKind::Collect, true) => {
            if state
                .mail_reader
                .is_some_and(|reader| Some(reader.mail_id) == feedback.mail_id)
            {
                state.mail_reader = None;
            }
            clear_mail_feedback(&mut state, &mut compose);
        }
        (MailOperationKind::Collect, false) => {
            show_mail_feedback(&mut state, &mut compose, "Mail claim failed");
        }
        // Read/Delete completion has no source result box. In particular it
        // must not erase an unrelated rejected send/collect notice.
        (MailOperationKind::Delete, true) | (MailOperationKind::Read, true) => {}
        (MailOperationKind::Delete, false) => {
            show_mail_feedback(&mut state, &mut compose, "Mail delete failed");
        }
        (MailOperationKind::Read, false) => {
            show_mail_feedback(&mut state, &mut compose, "Mail read failed");
        }
    }
    mail.mails.retain(|message| message.operation.is_none());
}

/// Crystal's top-level HelpDialog is movable. The source control records the
/// cursor-to-window offset on press, follows that offset while held, clamps to
/// the fixed logical stage, and clears movement on release or Hide.
fn process_help_drag(
    mut state: ResMut<NativePlayerUiState>,
    mouse: Option<Res<ButtonInput<MouseButton>>>,
    windows: Query<&Window, With<PrimaryWindow>>,
) {
    if !state.help.open
        || state.amount_modal_open()
        || state.mail_feedback_prompt.is_some()
        || state.mail_feedback_input_consumed
        || state.mail_recipient_prompt_active
        || state.mail_recipient_input_consumed
        || state.mail_reader.is_some()
    {
        state.help.end_drag();
        return;
    }
    let Some(mouse) = mouse else {
        state.help.end_drag();
        return;
    };
    if mouse.just_released(MouseButton::Left) || !mouse.pressed(MouseButton::Left) {
        state.help.end_drag();
        return;
    }
    let Ok(window) = windows.single() else {
        state.help.end_drag();
        return;
    };
    if !window.focused {
        state.help.end_drag();
        return;
    }
    let Some(cursor) = help_cursor_logical(window) else {
        state.help.end_drag();
        return;
    };
    if mouse.just_pressed(MouseButton::Left) {
        let _ = state.help.begin_drag(cursor.x, cursor.y);
    }
    state.help.drag_to(cursor.x, cursor.y);
}

/// MailComposeLetterDialog's text body owns the pointer independently of the
/// movable frame. Hit testing is resolved against the font renderer's captured
/// shaped layout, never a guessed character width.
fn process_mail_letter_editor_pointer(
    shell: Res<NativeShellModel>,
    mut state: ResMut<NativePlayerUiState>,
    compose: Res<MailComposeUi>,
    frame: Res<mail_compose_drag::MailLetterWindow>,
    parcel: Option<Res<mail_parcel::MailParcelUi>>,
    mut editor: ResMut<mail_editor::MailLetterEditor>,
    pending: Res<PendingOperations>,
    mouse: Option<Res<ButtonInput<MouseButton>>>,
    windows: Query<&Window, With<PrimaryWindow>>,
) {
    let (window_position, body_rect, frame_dragging) = if compose.kind == MailComposeKind::Parcel {
        let Some(parcel) = parcel.as_deref() else {
            editor.set_selecting(false);
            return;
        };
        (parcel.window.position, mail_parcel::MAIL_PARCEL_BODY_RECT, parcel.window.dragging())
    } else {
        (frame.position, mail_editor::MAIL_LETTER_BODY_RECT, frame.dragging())
    };
    let visible = shell.screen == NativeShellScreen::InGame
        && state.mail_open()
        && state.core.mail_compose.is_some()
        && matches!(compose.kind, MailComposeKind::Letter | MailComposeKind::Parcel);
    let message = state
        .core
        .mail_compose
        .as_ref()
        .map(|draft| draft.message.as_str());
    if visible {
        editor.sync(true, message);
    }
    let interactive = visible
        && !state.amount_modal_open()
        && state.mail_feedback_prompt.is_none()
        && !state.mail_feedback_input_consumed
        && !state.mail_recipient_prompt_active
        && !state.mail_recipient_input_consumed
        && state.mail_reader.is_none()
        && !state.mail_reader_input_consumed
        && state.mail_delete_prompt.is_none()
        && !state.mail_delete_input_consumed
        && state.storage_password_prompt.is_none()
        && state.storage_rental_confirmation.is_none()
        && !mail_compose_drag::covered(&state)
        && !frame_dragging
        && !state.menu_pointer_consumed
        && !pending.has_pending_mail_send();
    if !interactive {
        editor.set_selecting(false);
        return;
    }
    let (Some(mouse), Ok(window)) = (mouse, windows.single()) else {
        editor.set_selecting(false);
        return;
    };
    if !window.focused {
        editor.set_selecting(false);
        return;
    }
    let Some(cursor) = help_cursor_logical(window) else {
        editor.set_selecting(false);
        return;
    };
    let local = cursor - window_position - Vec2::new(
        body_rect.left,
        body_rect.top,
    ) - mail_editor::MAIL_LETTER_CONTENT_INSET;
    let inside = local.x >= 0.0
        && local.x < mail_editor::MAIL_LETTER_CONTENT_SIZE.x
        && local.y >= 0.0
        && local.y < mail_editor::MAIL_LETTER_CONTENT_SIZE.y;
    if mouse.just_pressed(MouseButton::Left) {
        editor.set_selecting(inside);
        if inside {
            editor.pointer(local, false);
            state.menu_pointer_consumed = true;
        }
    }
    if mouse.pressed(MouseButton::Left) && editor.selecting() {
        editor.pointer(local, true);
        state.menu_pointer_consumed = true;
    }
    if mouse.just_released(MouseButton::Left) || !mouse.pressed(MouseButton::Left) {
        editor.set_selecting(false);
    }
}

/// Crystal's native multiline TextBox scrolls only while the pointer is over
/// its body. Keep that ownership separate from every other panel's wheel
/// consumer and convert touchpad pixel deltas through the same stage transform
/// used for the body hit test.
fn process_mail_letter_editor_wheel(
    shell: Res<NativeShellModel>,
    mut state: ResMut<NativePlayerUiState>,
    compose: Res<MailComposeUi>,
    frame: Res<mail_compose_drag::MailLetterWindow>,
    parcel: Option<Res<mail_parcel::MailParcelUi>>,
    mut editor: ResMut<mail_editor::MailLetterEditor>,
    pending: Res<PendingOperations>,
    windows: Query<(Entity, &Window), With<PrimaryWindow>>,
    mut wheel: MessageReader<MouseWheel>,
) {
    let Some((window_position, body_rect, frame_dragging)) = (if compose.kind == MailComposeKind::Parcel {
        parcel.as_deref().map(|parcel| (
            parcel.window.position,
            mail_parcel::MAIL_PARCEL_BODY_RECT,
            parcel.window.dragging(),
        ))
    } else {
        Some((
            frame.position,
            mail_editor::MAIL_LETTER_BODY_RECT,
            frame.dragging(),
        ))
    }) else {
        wheel.clear();
        return;
    };
    let interactive = shell.screen == NativeShellScreen::InGame
        && state.mail_open()
        && state.core.mail_compose.is_some()
        && matches!(compose.kind, MailComposeKind::Letter | MailComposeKind::Parcel)
        && editor.focused()
        && !state.amount_modal_open()
        && state.mail_feedback_prompt.is_none()
        && !state.mail_feedback_input_consumed
        && !state.mail_recipient_prompt_active
        && !state.mail_recipient_input_consumed
        && state.mail_reader.is_none()
        && !state.mail_reader_input_consumed
        && state.mail_delete_prompt.is_none()
        && !state.mail_delete_input_consumed
        && state.storage_password_prompt.is_none()
        && state.storage_rental_confirmation.is_none()
        && !mail_compose_drag::covered(&state)
        && !frame_dragging
        && !state.menu_pointer_consumed
        && !pending.has_pending_mail_send();
    let Ok((window_entity, window)) = windows.single() else {
        wheel.clear();
        return;
    };
    if !interactive || !window.focused {
        wheel.clear();
        return;
    }
    let Some(cursor) = help_cursor_logical(window) else {
        wheel.clear();
        return;
    };
    let local = cursor - window_position - Vec2::new(body_rect.left, body_rect.top)
        - mail_editor::MAIL_LETTER_CONTENT_INSET;
    let inside = local.x >= 0.0
        && local.x < mail_editor::MAIL_LETTER_CONTENT_SIZE.x
        && local.y >= 0.0
        && local.y < mail_editor::MAIL_LETTER_CONTENT_SIZE.y;
    if !inside {
        wheel.clear();
        return;
    }
    let stage_scale = super::metrics::CrystalStageTransform::fit_native(
        window.resolution.width(),
        window.resolution.height(),
    )
    .scale;
    let mut consumed = false;
    for event in wheel.read() {
        if event.window != window_entity || !event.y.is_finite() || event.y == 0.0 {
            continue;
        }
        consumed = true;
        match event.unit {
            MouseScrollUnit::Line => editor.scroll_wheel_lines(event.y),
            MouseScrollUnit::Pixel => editor.scroll_wheel_pixels(event.y / stage_scale),
        };
    }
    if consumed {
        state.menu_pointer_consumed = true;
    }
}

fn sync_mail_letter_editor(
    state: Res<NativePlayerUiState>,
    compose: Res<MailComposeUi>,
    reset: Option<Res<SessionResetRevision>>,
    mut editor: ResMut<mail_editor::MailLetterEditor>,
    mut last_reset_revision: Local<Option<u64>>,
) {
    let revision = reset.as_deref().map_or(0, |value| value.0);
    if last_reset_revision.is_some_and(|previous| previous != revision) {
        editor.clear();
    }
    *last_reset_revision = Some(revision);
    let has_suspended_compose = compose
        .recipient_prompt
        .as_ref()
        .is_some_and(|prompt| matches!(prompt.suspended_kind, MailComposeKind::Letter | MailComposeKind::Parcel));
    if !state.mail_open()
        || (state.core.mail_compose.is_none() && !has_suspended_compose)
    {
        editor.clear();
        return;
    }
    if let Some(draft) = state.core.mail_compose.as_ref() {
        editor.sync(true, Some(&draft.message));
    }
}

/// Crystal InventoryDialog sets `Movable=true`. The root keeps the original
/// cursor offset and clamps its true 316x236 size to the fixed logical stage;
/// child controls are excluded by [`inventory_drag_surface_contains`].
fn process_inventory_drag(
    mut state: ResMut<NativePlayerUiState>,
    mouse: Option<Res<ButtonInput<MouseButton>>>,
    windows: Query<(Entity, &Window), With<PrimaryWindow>>,
    mut cursor_moves: MessageReader<CursorMoved>,
) {
    if !state.inventory_open()
        || state.mail_feedback_prompt.is_some()
        || state.mail_feedback_input_consumed
        || state.mail_recipient_prompt_active
        || state.mail_recipient_input_consumed
        || state.mail_reader.is_some()
        || state.amount_modal_open()
        || state.storage_password_prompt.is_some()
        || state.storage_rental_confirmation.is_some()
    {
        state.inventory_window.end_drag();
        state.inventory_window.clear_cursor();
        return;
    }
    let Some(mouse) = mouse else {
        state.inventory_window.end_drag();
        return;
    };
    let Ok((window_entity, window)) = windows.single() else {
        state.inventory_window.end_drag();
        return;
    };
    if !window.focused {
        state.inventory_window.end_drag();
        return;
    }
    let cursor_path = cursor_moves
        .read()
        .filter(|event| event.window == window_entity)
        .map(|event| cursor_logical(window, event.position))
        .collect::<Vec<_>>();
    let current_cursor = cursor_path
        .last()
        .copied()
        .or_else(|| help_cursor_logical(window));

    // SendInput and high-polling mice can deliver press, motion and release in
    // one Bevy frame. SendInput can also move to the press point one frame
    // before the press edge and expose only the destination CursorMoved event
    // in the pressed frame. Preserve the prior cursor as the anchor whenever
    // it owns the InventoryDialog's exposed drag surface.
    if mouse.just_pressed(MouseButton::Left) {
        let observed_start = cursor_path.first().copied().or(current_cursor);
        let previous_start = state.inventory_window.last_cursor.filter(|previous| {
            inventory_drag_surface_contains(&state.inventory_window, previous.x, previous.y)
                && observed_start.is_some_and(|observed| previous.distance(observed) > 2.0)
        });
        let Some(start) = previous_start
            .or(observed_start)
            .or(state.inventory_window.last_cursor)
        else {
            state.inventory_window.end_drag();
            return;
        };
        // The accepted trade pair is drawn above Inventory. Its child cells
        // and controls own the press too, not only its draggable background.
        if (state.hero.interactive
            && hero_dialog::geometry::hit(&state.hero, [start.x, start.y], state.hero.front)
                .0
                .is_some())
            || equipment_creature_host::covers(&state, start)
            || state.trade_dialog.covers_cursor(start)
            || state.ranking.covers_cursor(start)
        {
            state.inventory_window.end_drag();
            state.inventory_window.remember_cursor(current_cursor);
            return;
        }
        if state.inventory_window.begin_drag(start.x, start.y) {
            state.hero.cross.player_front = true;
            if let Some(end) = current_cursor {
                state.inventory_window.drag_to(end.x, end.y);
            }
        }
        if mouse.just_released(MouseButton::Left) || !mouse.pressed(MouseButton::Left) {
            state.inventory_window.end_drag();
        }
        state.inventory_window.remember_cursor(current_cursor);
        return;
    }

    if mouse.just_released(MouseButton::Left) || !mouse.pressed(MouseButton::Left) {
        state.inventory_window.end_drag();
        state.inventory_window.remember_cursor(current_cursor);
        return;
    }
    let Some(cursor) = current_cursor else {
        state.inventory_window.end_drag();
        return;
    };
    state.inventory_window.drag_to(cursor.x, cursor.y);
    state.inventory_window.remember_cursor(current_cursor);
}

fn inventory_bag_slot_at_cursor(state: &NativePlayerUiState, cursor: Vec2) -> Option<u32> {
    if state.inventory_page > 1 {
        return None;
    }
    let local_x = cursor.x - state.inventory_window.left;
    let local_y = cursor.y - state.inventory_window.top;
    (0..INVENTORY_PAGE_SIZE).find_map(|local_slot| {
        let x = INVENTORY_GRID_ORIGIN.x as f32
            + (local_slot % INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.x as f32;
        let y = INVENTORY_GRID_ORIGIN.y as f32
            + (local_slot / INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.y as f32;
        CrystalRect::new(
            x,
            y,
            INVENTORY_CELL_SIZE.width as f32,
            INVENTORY_CELL_SIZE.height as f32,
        )
        .contains(local_x, local_y)
        .then_some((usize::from(state.inventory_page) * INVENTORY_PAGE_SIZE + local_slot) as u32)
    })
}

fn belt_slot_at_cursor(belt: super::hud::CrystalBeltPresentation, cursor: Vec2) -> Option<u8> {
    belt.visible.then_some(())?;
    (0..6)
        .find(|slot| super::hud::belt_slot_rect(*slot, belt.vertical).contains(cursor.x, cursor.y))
}

fn inventory_item_drag_at_cursor(
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
    parcel: Option<&mail_parcel::MailParcelUi>,
    start: Vec2,
) -> Option<InventoryItemDrag> {
    let source_slot = inventory_bag_slot_at_cursor(state, start)?;
    let item = inventory
        .items_in(0)
        .into_iter()
        .find(|item| item.slot == source_slot)?;
    let unique_id = item_unique_id(item)?;
    if parcel.is_some_and(|parcel| parcel.blocks_item(unique_id)) {
        return None;
    }
    Some(InventoryItemDrag {
        source_slot,
        unique_id,
        start,
    })
}

fn storage_slot_at_cursor(
    state: &NativePlayerUiState,
    storage: &StorageModel,
    storage_ui: &StorageUiState,
    cursor: Vec2,
) -> Option<u32> {
    if !state.storage_open() || !storage.transfers_unlocked() {
        return None;
    }
    let page = storage.page(storage_ui.cursor.page);
    if page.locked || page.rental_locked {
        return None;
    }
    page.slots.iter().enumerate().find_map(|(offset, slot)| {
        let column = offset % 10;
        let row = offset / 10;
        CrystalRect::new(
            9.0 + column as f32 * 37.0,
            60.0 + row as f32 * 33.0,
            36.0,
            32.0,
        )
        .contains(cursor.x, cursor.y)
        .then_some(slot)
        .filter(|slot| !slot.locked)
        .map(|slot| slot.slot)
    })
}

fn storage_item_drag_at_cursor(
    state: &NativePlayerUiState,
    storage: &StorageModel,
    storage_ui: &StorageUiState,
    start: Vec2,
) -> Option<StorageItemDrag> {
    let source_slot = storage_slot_at_cursor(state, storage, storage_ui, start)?;
    let item = storage.item_in_storage(source_slot)?;
    Some(StorageItemDrag {
        source_slot,
        unique_id: item_unique_id(item)?,
        start,
    })
}

/// CharacterDialog remains at the source's fixed top-right location while a
/// StorageDialog is open. Only its Character page owns these equipment cells.
fn equipment_slot_at_cursor(state: &NativePlayerUiState, cursor: Vec2) -> Option<u32> {
    if !state.storage_open()
        || !state.storage_equipment_visible
        || state.character_page != CharacterPage::Character
    {
        return None;
    }
    let local_x = cursor.x - CRYSTAL_CHARACTER_PANEL_RECT.left;
    let local_y = cursor.y - CRYSTAL_CHARACTER_PANEL_RECT.top;
    CRYSTAL_CHARACTER_EQUIPMENT_SLOTS
        .iter()
        .find_map(|(slot, rect)| rect.contains(local_x, local_y).then_some(*slot))
}

fn equipment_item_drag_at_cursor(
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
    start: Vec2,
) -> Option<EquipmentItemDrag> {
    let source_slot = equipment_slot_at_cursor(state, start)?;
    let item = inventory
        .items_in(2)
        .into_iter()
        .find(|item| item.slot == source_slot)?;
    Some(EquipmentItemDrag {
        source_slot,
        unique_id: item_unique_id(item)?,
        start,
    })
}

fn complete_live_storage_template_index(item: &ItemModel) -> Option<i32> {
    let source = item.tooltip_source.as_ref()?;
    let user_item = source.user_item.as_ref()?;
    (item.unique_id == Some(user_item.unique_id)
        && user_item.item_index == source.info.item_index
        && u16::try_from(item.quantity).ok() == Some(user_item.count))
        .then_some(source.info.item_index)
}

fn compatible_storage_stack(source: &ItemModel, target: &ItemModel) -> bool {
    complete_live_storage_template_index(source)
        .zip(complete_live_storage_template_index(target))
        .is_some_and(|(from_index, to_index)| {
            from_index == to_index
                && target
                    .tooltip_source
                    .as_ref()
                    .is_some_and(|source| {
                        target.quantity < u32::from(source.info.stack_size)
                    })
        })
}

fn first_empty_bag_slot(inventory: &InventoryModel) -> Option<u32> {
    (0..u32::from(inventory.bag_slot_capacity())).find(|slot| {
        !inventory
            .items_in(0)
            .into_iter()
            .any(|item| item.slot == *slot)
    })
}

fn push_storage_drag_merge(
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
    grid_from: &str,
    grid_to: &str,
    id_from: u64,
    id_to: u64,
) -> bool {
    let intent = NativePlayerUiIntent::MergeItem {
        grid_from: grid_from.to_owned(),
        grid_to: grid_to.to_owned(),
        id_from,
        id_to,
    };
    let Some(key) = intent.pending_key() else {
        return false;
    };
    if pending.has_storage_drag_conflict(&key) {
        return false;
    }
    intents.push_pending_intent(pending, intent)
}

fn push_equipment_storage_pending_intent(
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
    intent: NativePlayerUiIntent,
) -> bool {
    let Some(key) = intent.pending_key() else {
        return false;
    };
    if pending.has_storage_drag_conflict(&key) {
        return false;
    }
    intents.push_pending_intent(pending, intent)
}

fn enqueue_bag_to_storage_drag(
    source: &ItemModel,
    source_slot: u32,
    target_slot: u32,
    storage: &StorageModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    if !storage.transfers_unlocked() || !storage.is_valid_slot(target_slot) {
        return false;
    }
    let Some(source_id) = item_unique_id(source) else {
        return false;
    };
    let target = storage.item_in_storage(target_slot);
    if let Some(target_id) = target.filter(|item| compatible_storage_stack(source, item)).and_then(item_unique_id) {
        return push_storage_drag_merge(
            intents,
            pending,
            "inventory",
            "storage",
            source_id,
            target_id,
        );
    }
    let destination = if target.is_none() {
        Some(target_slot)
    } else {
        storage.first_empty_storage_slot()
    };
    let Some(destination) = destination else {
        return false;
    };
    intents.push_storage_drag_pending_intent(
        pending,
        true,
        source_id,
        i32::try_from(source_slot).unwrap_or(i32::MAX),
        i32::try_from(destination).unwrap_or(i32::MAX),
    )
}

fn enqueue_storage_to_storage_drag(
    source: &ItemModel,
    source_slot: u32,
    target_slot: u32,
    storage: &StorageModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    if !storage.transfers_unlocked()
        || !storage.is_valid_slot(source_slot)
        || !storage.is_valid_slot(target_slot)
        || source_slot == target_slot
    {
        return false;
    }
    let Some(source_id) = item_unique_id(source) else {
        return false;
    };
    let target = storage.item_in_storage(target_slot);
    if let Some(target_id) = target
        .filter(|item| compatible_storage_stack(source, item))
        .and_then(item_unique_id)
    {
        return push_storage_drag_merge(
            intents,
            pending,
            "storage",
            "storage",
            source_id,
            target_id,
        );
    }
    let intent = NativePlayerUiIntent::MoveItem {
        grid: "storage".to_owned(),
        unique_id: source_id,
        from: i32::try_from(source_slot).unwrap_or(i32::MAX),
        to: i32::try_from(target_slot).unwrap_or(i32::MAX),
    };
    let Some(key) = intent.pending_key() else {
        return false;
    };
    if pending.has_storage_drag_conflict(&key) {
        return false;
    }
    intents.push_pending_intent(pending, intent)
}

fn enqueue_storage_to_bag_drag(
    source: &ItemModel,
    source_slot: u32,
    target_slot: u32,
    inventory: &InventoryModel,
    storage: &StorageModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    if !storage.transfers_unlocked()
        || !storage.is_valid_slot(source_slot)
        || target_slot >= u32::from(inventory.bag_slot_capacity())
    {
        return false;
    }
    let Some(source_id) = item_unique_id(source) else {
        return false;
    };
    let target = inventory
        .items_in(0)
        .into_iter()
        .find(|item| item.slot == target_slot);
    if let Some(target_id) = target.filter(|item| compatible_storage_stack(source, item)).and_then(item_unique_id) {
        return push_storage_drag_merge(
            intents,
            pending,
            "storage",
            "inventory",
            source_id,
            target_id,
        );
    }
    let destination = if target.is_none() {
        Some(target_slot)
    } else {
        first_empty_bag_slot(inventory)
    };
    let Some(destination) = destination else {
        return false;
    };
    intents.push_storage_drag_pending_intent(
        pending,
        false,
        source_id,
        i32::try_from(source_slot).unwrap_or(i32::MAX),
        i32::try_from(destination).unwrap_or(i32::MAX),
    )
}

/// `MirItemCell.ToStorage` uses RemoveItem with Storage as the destination
/// grid for worn equipment. Its sole occupied-target exception is a complete,
/// non-full matching amulet stack; all other occupied targets use the first
/// empty storage slot fallback.
fn enqueue_equipment_to_storage_drag(
    source: &ItemModel,
    target_slot: u32,
    storage: &StorageModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    if !storage.transfers_unlocked() || !storage.is_valid_slot(target_slot) {
        return false;
    }
    let Some(unique_id) = item_unique_id(source) else {
        return false;
    };
    if source
        .tooltip_source
        .as_ref()
        .is_some_and(|tooltip| tooltip.info.item_type == 8)
    {
        if let Some(target_id) = storage
            .item_in_storage(target_slot)
            .filter(|target| compatible_storage_stack(source, target))
            .and_then(item_unique_id)
        {
            return push_storage_drag_merge(
                intents,
                pending,
                "equipment",
                "storage",
                unique_id,
                target_id,
            );
        }
    }
    let destination = if storage.item_in_storage(target_slot).is_none() {
        Some(target_slot)
    } else {
        storage.first_empty_storage_slot()
    };
    let Some(destination) = destination.and_then(|slot| i32::try_from(slot).ok()) else {
        return false;
    };
    push_equipment_storage_pending_intent(intents, pending, NativePlayerUiIntent::RemoveItem {
        unique_id,
        grid: "storage".to_owned(),
        to: destination,
    })
}

/// Source ToEquipment sends the concrete destination slot and leaves wear,
/// curse, and requirements to the authoritative server.
fn enqueue_storage_to_equipment_drag(
    source: &ItemModel,
    target_slot: u32,
    inventory: &InventoryModel,
    storage: &StorageModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    if !storage.transfers_unlocked() {
        return false;
    }
    let Some(unique_id) = item_unique_id(source) else {
        return false;
    };
    if source
        .tooltip_source
        .as_ref()
        .is_some_and(|tooltip| tooltip.info.item_type == 8)
    {
        if let Some(target_id) = inventory
            .items_in(2)
            .into_iter()
            .find(|target| target.slot == target_slot)
            .filter(|target| compatible_storage_stack(source, target))
            .and_then(item_unique_id)
        {
            return push_storage_drag_merge(
                intents,
                pending,
                "storage",
                "equipment",
                unique_id,
                target_id,
            );
        }
    }
    push_equipment_storage_pending_intent(intents, pending, NativePlayerUiIntent::EquipItem {
        unique_id,
        grid: "storage".to_owned(),
        to: i32::try_from(target_slot).unwrap_or(i32::MAX),
    })
}

fn finish_inventory_item_drag(
    state: &mut NativePlayerUiState,
    inventory: &InventoryModel,
    parcel_active: bool,
    mut parcel: Option<&mut mail_parcel::MailParcelUi>,
    mut shop: Option<&mut ShopModel>,
    storage: Option<&mut StorageModel>,
    storage_ui: Option<&mut StorageUiState>,
    cursor: Option<Vec2>,
    belt: super::hud::CrystalBeltPresentation,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
    diagnostics: Option<&InventoryBeltDiagnostics>,
) {
    let Some(drag) = state.inventory_item_drag.take() else {
        belt_diagnostic(diagnostics, || "drag release without source".to_owned());
        return;
    };
    state.inventory_item_pointer_consumed = true;
    let Some(source) = inventory.items_in(0).into_iter().find(|item| {
        item.slot == drag.source_slot && item_unique_id(item) == Some(drag.unique_id)
    }) else {
        return;
    };
    if parcel
        .as_deref()
        .is_some_and(|parcel| parcel.blocks_item(drag.unique_id))
    {
        return;
    }
    let Some(cursor) = cursor else {
        belt_diagnostic(diagnostics, || "drag release without cursor".to_owned());
        return;
    };
    if drag.start.distance(cursor) < 4.0 {
        state.inspect = Some(inspect_from_item(source));
        state.split_count = 1;
        state.drop_confirmation = None;
        belt_diagnostic(diagnostics, || "drag release below threshold".to_owned());
        return;
    }
    state.inspect = None;
    if parcel_active {
        if let Some(parcel) = parcel.as_deref_mut() {
            if mail_parcel::slot_at_cursor(parcel, cursor).is_some() {
                if let Some(draft) = state.core.mail_compose.as_mut() {
                    if parcel.attach(draft, inventory, drag.unique_id) {
                        let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem {
                            unique_id: drag.unique_id,
                            locked: true,
                        });
                    }
                }
                return;
            }
        }
    }
    if let (Some(storage), Some(storage_ui)) = (storage, storage_ui) {
        if let Some(target_slot) = storage_slot_at_cursor(state, storage, storage_ui, cursor) {
            let queued = enqueue_bag_to_storage_drag(
                source,
                drag.source_slot,
                target_slot,
                storage,
                intents,
                pending,
            );
            belt_diagnostic(diagnostics, || {
                format!("drag source={} storage_queue={queued}", drag.source_slot)
            });
            return;
        }
    }
    if shop
        .as_ref()
        .is_some_and(|shop| npc_item_service::drag_target_at_cursor(shop, state, cursor))
    {
        let selected = npc_item_service::select_bag_dragged_for_service(
            shop.as_deref_mut().expect("service drag target has shop"),
            inventory,
            state,
            drag.source_slot,
            drag.unique_id,
            intents,
            pending,
        );
        belt_diagnostic(diagnostics, || {
            format!(
                "drag source={} npc_service_selected={selected}",
                drag.source_slot
            )
        });
        return;
    }
    let intent = if let Some(to) = inventory_bag_slot_at_cursor(state, cursor) {
        if to == drag.source_slot {
            return;
        }
        let target = inventory.items_in(0).into_iter().find(|item| item.slot == to);
        if target
            .and_then(item_unique_id)
            .is_some_and(|unique_id| parcel.as_deref().is_some_and(|parcel| parcel.blocks_item(unique_id)))
        {
            return;
        }
        // MirItemCell.MoveItem merges matching, non-full stacks; otherwise
        // MoveItem swaps occupied cells or moves into an empty cell.
        let merge_target = target
            .filter(|target| {
                source.tooltip_source.as_ref()
                    .zip(target.tooltip_source.as_ref())
                    .is_some_and(|(from, to)| {
                        from.info.item_index == to.info.item_index
                            && target.quantity < u32::from(to.info.stack_size)
                    })
            })
            .and_then(item_unique_id);
        if let Some(id_to) = merge_target {
            NativePlayerUiIntent::MergeItem {
                grid_from: "inventory".to_owned(),
                grid_to: "inventory".to_owned(),
                id_from: drag.unique_id,
                id_to,
            }
        } else {
            NativePlayerUiIntent::MoveItem {
                grid: "inventory".to_owned(),
                unique_id: drag.unique_id,
                from: drag.source_slot as i32,
                to: to as i32,
            }
        }
    } else if let Some(belt_slot) = belt_slot_at_cursor(belt, cursor) {
        inventory_bag_to_belt_move_intent(drag.source_slot, drag.unique_id, belt_slot)
    } else {
        return;
    };
    let queued = intents.push_pending_intent(pending, intent);
    belt_diagnostic(diagnostics, || {
        format!(
            "drag source={} move_queue={queued}",
            drag.source_slot
        )
    });
    if queued {
        state.inspect = None;
    }
}

fn finish_storage_item_drag(
    state: &mut NativePlayerUiState,
    inventory: &InventoryModel,
    parcel: Option<&mail_parcel::MailParcelUi>,
    storage: &StorageModel,
    storage_ui: &mut StorageUiState,
    cursor: Option<Vec2>,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) {
    let Some(drag) = storage_ui.storage_item_drag.take() else {
        return;
    };
    state.inventory_item_pointer_consumed = true;
    let Some(source) = storage.item_in_storage(drag.source_slot).filter(|item| {
        item_unique_id(item) == Some(drag.unique_id)
    }) else {
        return;
    };
    let Some(cursor) = cursor else {
        return;
    };
    if drag.start.distance(cursor) < 4.0 {
        state.inspect = Some(inspect_from_item(source));
        return;
    }
    state.inspect = None;
    if let Some(target_slot) = storage_slot_at_cursor(state, storage, storage_ui, cursor) {
        let _ = enqueue_storage_to_storage_drag(
            source,
            drag.source_slot,
            target_slot,
            storage,
            intents,
            pending,
        );
        return;
    }
    if let Some(target_slot) = equipment_slot_at_cursor(state, cursor) {
        let _ = enqueue_storage_to_equipment_drag(
            source,
            target_slot,
            inventory,
            storage,
            intents,
            pending,
        );
        return;
    }
    let Some(target_slot) = inventory_bag_slot_at_cursor(state, cursor) else {
        return;
    };
    if bag_slot_is_mail_locked_opt(parcel, inventory, target_slot) {
        return;
    }
    let _ = enqueue_storage_to_bag_drag(
        source,
        drag.source_slot,
        target_slot,
        inventory,
        storage,
        intents,
        pending,
    );
}

fn finish_equipment_item_drag(
    state: &mut NativePlayerUiState,
    inventory: &InventoryModel,
    storage: &StorageModel,
    storage_ui: &StorageUiState,
    cursor: Option<Vec2>,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) {
    let Some(drag) = state.equipment_item_drag.take() else {
        return;
    };
    state.inventory_item_pointer_consumed = true;
    let Some(source) = inventory.items_in(2).into_iter().find(|item| {
        item.slot == drag.source_slot && item_unique_id(item) == Some(drag.unique_id)
    }) else {
        return;
    };
    let Some(cursor) = cursor else {
        return;
    };
    if drag.start.distance(cursor) < 4.0 {
        state.inspect = Some(inspect_from_item(source));
        return;
    }
    state.inspect = None;
    let Some(target_slot) = storage_slot_at_cursor(state, storage, storage_ui, cursor) else {
        return;
    };
    let _ = enqueue_equipment_to_storage_drag(source, target_slot, storage, intents, pending);
}

/// A click inspects on release; a carry gesture moves/merges on release.
fn process_inventory_item_drag(
    mut state: ResMut<NativePlayerUiState>,
    inventory: Res<InventoryModel>,
    compose: Option<Res<MailComposeUi>>,
    mut parcel: Option<ResMut<mail_parcel::MailParcelUi>>,
    mut shop: Option<ResMut<ShopModel>>,
    mut storage: Option<ResMut<StorageModel>>,
    mut storage_ui: Option<ResMut<StorageUiState>>,
    belt: Option<Res<super::hud::CrystalBeltPresentation>>,
    mouse: Option<Res<ButtonInput<MouseButton>>>,
    windows: Query<(Entity, &Window), With<PrimaryWindow>>,
    mut cursor_moves: MessageReader<CursorMoved>,
    ordered: Option<Res<Messages<bevy::window::WindowEvent>>>,
    mut ordered_reader: Local<bevy::ecs::message::MessageCursor<bevy::window::WindowEvent>>,
    mut intents: ResMut<NativePlayerUiIntentQueue>,
    mut pending: ResMut<PendingOperations>,
    diagnostics: Option<Res<InventoryBeltDiagnostics>>,
) {
    state.inventory_item_pointer_consumed = false;
    let ordered_events: Vec<_> = ordered
        .as_ref()
        .map(|events| ordered_reader.read(events).cloned().collect())
        .unwrap_or_default();
    // Crystal opens InventoryDialog alongside NPCDropDialog. The native core
    // currently represents the NPC panel as the active panel, so retain bag
    // drag input while the service frame is open.
    if !state.inventory_open()
        || state.mail_feedback_prompt.is_some()
        || state.mail_feedback_input_consumed
        || state.mail_recipient_prompt_active
        || state.mail_recipient_input_consumed
        || state.mail_reader.is_some()
        // StorageDialog hides the regular bag until its password prompt has
        // succeeded, so it cannot be used as an invisible drag source.
        || (state.storage_open()
            && storage
                .as_deref()
                .is_some_and(|storage| !storage.transfers_unlocked()))
        || state.amount_modal_open()
        || state.storage_password_prompt.is_some()
        || state.storage_rental_confirmation.is_some()
        || state.inventory_delete_mode
        || state.inventory_operation.is_some()
        || state.trade_dialog.open
    {
        state.inventory_item_drag = None;
        state.equipment_item_drag = None;
        if let Some(storage_ui) = storage_ui.as_deref_mut() {
            storage_ui.storage_item_drag = None;
        }
        return;
    }
    let (Some(mouse), Some(belt)) = (mouse, belt) else {
        state.inventory_item_drag = None;
        state.equipment_item_drag = None;
        if let Some(storage_ui) = storage_ui.as_deref_mut() {
            storage_ui.storage_item_drag = None;
        }
        return;
    };
    let Ok((window_entity, window)) = windows.single() else {
        state.inventory_item_drag = None;
        state.equipment_item_drag = None;
        if let Some(storage_ui) = storage_ui.as_deref_mut() {
            storage_ui.storage_item_drag = None;
        }
        return;
    };
    if !window.focused {
        state.inventory_item_drag = None;
        state.equipment_item_drag = None;
        if let Some(storage_ui) = storage_ui.as_deref_mut() {
            storage_ui.storage_item_drag = None;
        }
        return;
    }
    let cursor_path = cursor_moves
        .read()
        .filter(|event| event.window == window_entity)
        .map(|event| cursor_logical(window, event.position))
        .collect::<Vec<_>>();
    let cursor = cursor_path
        .last()
        .copied()
        .or_else(|| help_cursor_logical(window));
    // Read before `finish_inventory_item_drag` takes the mutable UI state.
    let parcel_active = state.mail_open()
        && compose
            .as_deref()
            .is_some_and(|compose| compose.kind == MailComposeKind::Parcel);

    if ordered.is_some() {
        use bevy::input::ButtonState;
        use bevy::window::WindowEvent;
        let mut cursor = state
            .inventory_window
            .last_cursor
            .or_else(|| help_cursor_logical(window));
        for event in ordered_events {
            match event {
                WindowEvent::CursorMoved(event) if event.window == window_entity => {
                    cursor = Some(cursor_logical(window, event.position));
                }
                WindowEvent::CursorLeft(event) if event.window == window_entity => {
                    cursor = None;
                    state.inventory_item_drag = None;
                    state.equipment_item_drag = None;
                    if let Some(storage_ui) = storage_ui.as_deref_mut() {
                        storage_ui.storage_item_drag = None;
                    }
                    belt_diagnostic(diagnostics.as_deref(), || "drag cursor left".to_owned());
                }
                WindowEvent::MouseButtonInput(event)
                    if event.window == window_entity && event.button == MouseButton::Left =>
                {
                    match event.state {
                        ButtonState::Pressed => {
                            state.inventory_item_drag = cursor.and_then(|start| {
                                inventory_item_drag_at_cursor(
                                    &state,
                                    &inventory,
                                    parcel.as_deref(),
                                    start,
                                )
                            });
                            state.equipment_item_drag = None;
                            if let Some(storage_ui) = storage_ui.as_deref_mut() {
                                storage_ui.storage_item_drag = if state.inventory_item_drag.is_none() {
                                    storage.as_deref().and_then(|storage| {
                                        cursor.and_then(|start| {
                                            storage_item_drag_at_cursor(&state, storage, storage_ui, start)
                                        })
                                    })
                                } else {
                                    None
                                };
                            }
                            if state.inventory_item_drag.is_none()
                                && storage_ui
                                    .as_deref()
                                    .is_none_or(|ui| ui.storage_item_drag.is_none())
                            {
                                state.equipment_item_drag = cursor.and_then(|start| {
                                    equipment_item_drag_at_cursor(&state, &inventory, start)
                                });
                            }
                            belt_diagnostic(diagnostics.as_deref(), || {
                                format!(
                                    "drag press bag={:?} storage={:?}",
                                    state.inventory_item_drag.map(|drag| drag.source_slot),
                                    storage_ui.as_deref().and_then(|ui| ui.storage_item_drag.map(|drag| drag.source_slot)),
                                )
                            });
                        }
                        ButtonState::Released => {
                            finish_inventory_item_drag(
                                &mut state,
                                &inventory,
                                parcel_active,
                                parcel.as_deref_mut(),
                                shop.as_deref_mut(),
                                storage.as_deref_mut(),
                                storage_ui.as_deref_mut(),
                                cursor,
                                *belt,
                                &mut intents,
                                &mut pending,
                                diagnostics.as_deref(),
                            );
                            if let (Some(storage), Some(storage_ui)) =
                                (storage.as_deref(), storage_ui.as_deref_mut())
                            {
                                finish_storage_item_drag(
                                    &mut state,
                                    &inventory,
                                    parcel.as_deref(),
                                    storage,
                                    storage_ui,
                                    cursor,
                                    &mut intents,
                                    &mut pending,
                                );
                                finish_equipment_item_drag(
                                    &mut state,
                                    &inventory,
                                    storage,
                                    storage_ui,
                                    cursor,
                                    &mut intents,
                                    &mut pending,
                                );
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        state.inventory_window.remember_cursor(cursor);
        return;
    }

    if mouse.just_pressed(MouseButton::Left) {
        let start = cursor_path.first().copied().or(cursor);
        state.inventory_item_drag =
            start.and_then(|start| {
                inventory_item_drag_at_cursor(&state, &inventory, parcel.as_deref(), start)
            });
        state.equipment_item_drag = None;
        if let Some(storage_ui) = storage_ui.as_deref_mut() {
            storage_ui.storage_item_drag = if state.inventory_item_drag.is_none() {
                storage.as_deref().and_then(|storage| {
                    start.and_then(|start| storage_item_drag_at_cursor(&state, storage, storage_ui, start))
                })
            } else {
                None
            };
        }
        if state.inventory_item_drag.is_none()
            && storage_ui
                .as_deref()
                .is_none_or(|ui| ui.storage_item_drag.is_none())
        {
            state.equipment_item_drag = start
                .and_then(|start| equipment_item_drag_at_cursor(&state, &inventory, start));
        }
    }

    if mouse.just_released(MouseButton::Left) || !mouse.pressed(MouseButton::Left) {
        finish_inventory_item_drag(
            &mut state,
            &inventory,
            parcel_active,
            parcel.as_deref_mut(),
            shop.as_deref_mut(),
            storage.as_deref_mut(),
            storage_ui.as_deref_mut(),
            cursor,
            *belt,
            &mut intents,
            &mut pending,
            diagnostics.as_deref(),
        );
        if let (Some(storage), Some(storage_ui)) = (storage.as_deref(), storage_ui.as_deref_mut()) {
            finish_storage_item_drag(
                &mut state,
                &inventory,
                parcel.as_deref(),
                storage,
                storage_ui,
                cursor,
                &mut intents,
                &mut pending,
            );
            finish_equipment_item_drag(
                &mut state,
                &inventory,
                storage,
                storage_ui,
                cursor,
                &mut intents,
                &mut pending,
            );
        }
    }
}

/// Crystal cancels the footer-bin toggle on a right click anywhere inside the
/// InventoryDialog. A modal delete prompt owns the pointer first, so it is not
/// dismissed by this underlying-window rule.
fn process_inventory_delete_pointer(
    mut state: ResMut<NativePlayerUiState>,
    mouse: Option<Res<ButtonInput<MouseButton>>>,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut ui_audio: ResMut<crate::audio::NativeUiAudioQueue>,
) {
    if !state.inventory_open()
        || !state.inventory_delete_mode
        || state.amount_modal_open()
        || state.storage_password_prompt.is_some()
        || state.storage_rental_confirmation.is_some()
        || !mouse.is_some_and(|mouse| mouse.just_pressed(MouseButton::Right))
    {
        return;
    }
    let Ok(window) = windows.single() else {
        return;
    };
    if !window.focused {
        return;
    }
    let Some(cursor) = help_cursor_logical(window) else {
        return;
    };
    let panel = CrystalRect::new(
        state.inventory_window.left,
        state.inventory_window.top,
        INVENTORY_PANEL_SIZE.width as f32,
        INVENTORY_PANEL_SIZE.height as f32,
    );
    if panel.contains(cursor.x, cursor.y) {
        state.cancel_inventory_delete();
        ui_audio.push(crate::audio::NativeUiSound::ButtonB);
    }
}

fn process_guild_storage_pointer(
    mut state: ResMut<NativePlayerUiState>,
    shell: Res<NativeShellModel>,
    mouse: Option<Res<ButtonInput<MouseButton>>>,
    windows: Query<(Entity, &Window), With<PrimaryWindow>>,
    mut wheel: MessageReader<MouseWheel>,
    mut cursor_moves: MessageReader<CursorMoved>,
    mut last_cursor: Local<Option<Vec2>>,
) {
    if shell.screen != NativeShellScreen::InGame
        || !state.guild_open()
        || state.guild_left_page != GuildLeftPage::Storage
        || state.amount_modal_open()
    {
        state.guild_storage.end_drag();
        wheel.clear();
        cursor_moves.clear();
        *last_cursor = None;
        return;
    }
    let Ok((window_entity, window)) = windows.single() else {
        state.guild_storage.end_drag();
        wheel.clear();
        cursor_moves.clear();
        *last_cursor = None;
        return;
    };
    if !window.focused {
        state.guild_storage.end_drag();
        wheel.clear();
        cursor_moves.clear();
        *last_cursor = None;
        return;
    }
    let origin = Vec2::new(
        state.guild_panel.rect().left + guild_storage::PAGE.left,
        state.guild_panel.rect().top + guild_storage::PAGE.top,
    );
    let cursor_path = cursor_moves
        .read()
        .filter(|event| event.window == window_entity)
        .map(|event| cursor_logical(window, event.position) - origin)
        .collect::<Vec<_>>();
    let cursor = cursor_path
        .last()
        .copied()
        .or_else(|| help_cursor_logical(window).map(|cursor| cursor - origin));
    if let Some(mouse) = mouse {
        let mut drag_from = *last_cursor;
        if mouse.just_pressed(MouseButton::Left) {
            let observed = cursor_path.first().copied().or(cursor);
            let previous = last_cursor.filter(|previous| {
                state
                    .guild_storage
                    .thumb_rect()
                    .contains(previous.x, previous.y)
                    && observed.is_some_and(|current| previous.distance(current) > 2.0)
            });
            if let Some(start) = previous.or(observed) {
                if state
                    .guild_storage
                    .begin_drag(start.x as i32, start.y as i32)
                {
                    drag_from = Some(start);
                }
            }
        }
        let moved = drag_from.zip(cursor).is_some_and(|(from, to)| from != to)
            || (!mouse.just_pressed(MouseButton::Left) && !cursor_path.is_empty());
        // MirControl.OnMouseDown only records the grab; OnMoving runs on
        // motion, not on every held frame. A stationary first press must not
        // silently normalize the source constructor's StorageIndex=1 to zero.
        if moved && (mouse.pressed(MouseButton::Left) || mouse.just_released(MouseButton::Left)) {
            if let Some(cursor) = cursor {
                state.guild_storage.drag_to(cursor.y as i32);
            }
        }
        if mouse.just_released(MouseButton::Left) || !mouse.pressed(MouseButton::Left) {
            state.guild_storage.end_drag();
        }
    } else {
        state.guild_storage.end_drag();
    }
    let within_page = cursor.is_some_and(|cursor| {
        CrystalRect::new(
            0.0,
            0.0,
            guild_storage::PAGE.width,
            guild_storage::PAGE.height,
        )
        .contains(cursor.x, cursor.y)
    });
    for event in wheel.read() {
        if within_page
            && !state.guild_storage.is_dragging()
            && event.window == window_entity
            && event.unit == MouseScrollUnit::Line
            && event.y.is_finite()
            && event.y != 0.0
        {
            // Winit reports Windows wheel delta / 120 as LineDelta. Restore
            // the source delta before its integer notch division. Pixel-unit
            // touchpad events have no Crystal WinForms equivalent here.
            state.guild_storage.wheel_delta((event.y * 120.0) as i32);
        }
    }
    *last_cursor = cursor;
}

/// StorageDialog.Show puts the ordinary bag immediately to the right of its
/// 388px frame. This transition owns only the initial placement, so a player
/// may still drag the visible bag afterwards like the Crystal client.
fn sync_storage_inventory_location(
    mut state: ResMut<NativePlayerUiState>,
    mut placement: ResMut<StorageInventoryPlacement>,
    mut storage_ui: ResMut<StorageUiState>,
) {
    let is_open = state.storage_open();
    if is_open == placement.was_open {
        return;
    }
    placement.was_open = is_open;
    state.inventory_window.end_drag();
    state.inventory_window.clear_cursor();
    state.inventory_item_drag = None;
    state.equipment_item_drag = None;
    state.inventory_item_pointer_consumed = false;
    storage_ui.storage_item_drag = None;
    if is_open {
        state.inventory_window.left = 393.0;
        state.inventory_window.top = 0.0;
    } else {
        state.storage_equipment_visible = false;
    }
}

/// StorageDialog.Show hides the bag and opens an Unlock MirInputBox when the
/// server says storage protection is active. This is deliberately driven by
/// the authoritative `has_password`/`unlocked` pair only: no local setting is
/// treated as a forced-password-setup instruction.
fn sync_storage_password_prompt(
    shell: Res<NativeShellModel>,
    mut state: ResMut<NativePlayerUiState>,
    mut storage: ResMut<StorageModel>,
    mut storage_ui: ResMut<StorageUiState>,
    pending: Res<PendingOperations>,
    feedback: Option<ResMut<crate::storage::StorageUiFeedback>>,
) {
    // This latch lasts through the current input frame only. It is set when
    // a modal action removes the prompt later in the ordered Update chain.
    state.storage_password_input_consumed = false;
    if feedback.is_some_and(|mut feedback| std::mem::take(&mut feedback.close_requested)) {
        if state.storage_open() {
            state.core.panel = if state.storage_equipment_visible {
                mir2_ui_core::state::UiPanel::Character
            } else {
                mir2_ui_core::state::UiPanel::Inventory
            };
            state.storage_equipment_visible = false;
            state.inventory_item_drag = None;
            state.equipment_item_drag = None;
            state.storage_password_prompt = None;
            storage_ui.storage_item_drag = None;
            state.storage_password_input_consumed = true;
            clear_legacy_storage_password_drafts(&mut storage);
        }
    }
    let active = shell.screen == NativeShellScreen::InGame && state.storage_open();
    if !active {
        state.storage_password_prompt = None;
        clear_legacy_storage_password_drafts(&mut storage);
        return;
    }

    if storage.has_password
        && !storage.unlocked
        && state.storage_password_prompt.is_none()
        && !pending.contains(&PendingOperationKey::StorageUnlock)
    {
        state.storage_password_prompt = Some(StoragePasswordPrompt::unlock());
        clear_legacy_storage_password_drafts(&mut storage);
        state.inventory_item_drag = None;
        state.equipment_item_drag = None;
        state.inventory_item_pointer_consumed = false;
        storage_ui.storage_item_drag = None;
    }

    if state
        .storage_password_prompt
        .as_ref()
        .is_some_and(|prompt| {
            prompt.stage == StoragePasswordStage::Unlock
                && (!storage.has_password || storage.unlocked)
        })
    {
        state.storage_password_prompt = None;
        clear_legacy_storage_password_drafts(&mut storage);
    }
}

fn clear_legacy_storage_password_drafts(storage: &mut StorageModel) {
    storage.password_draft.clear();
    storage.new_password_draft.clear();
    storage.confirm_password_draft.clear();
}


/// Keeps the Rent confirmation session-scoped. The authoritative ResizeStorage
/// receipt, rather than this presentation prompt, changes rental state.
fn sync_storage_rental_confirmation(
    shell: Res<NativeShellModel>,
    mut state: ResMut<NativePlayerUiState>,
) {
    state.storage_rental_input_consumed = false;
    if shell.screen != NativeShellScreen::InGame || !state.storage_open() {
        state.storage_rental_confirmation = None;
    }
}

fn open_storage_rental_confirmation(
    state: &mut NativePlayerUiState,
    storage: &StorageModel,
) -> bool {
    if !state.storage_open()
        || state.storage_password_prompt.is_some()
        || state.storage_rental_confirmation.is_some()
    {
        return false;
    }
    state.storage_rental_confirmation = Some(StorageRentalConfirmation::from_storage(storage));
    true
}

fn cancel_storage_rental_confirmation(state: &mut NativePlayerUiState) {
    state.storage_rental_confirmation = None;
    state.storage_rental_input_consumed = true;
}

/// Enqueue only after the source OK action. Rental rejection is ordinary chat
/// without a correlated response, so this deliberately has no pending
/// reservation that could make a later funded retry impossible.
fn submit_storage_rental_confirmation(
    state: &mut NativePlayerUiState,
    intents: &mut NativePlayerUiIntentQueue,
) -> bool {
    if state.storage_rental_confirmation.is_none()
        || !intents.push_intent(NativePlayerUiIntent::ExpandStorage)
    {
        return false;
    }
    state.storage_rental_confirmation = None;
    state.storage_rental_input_consumed = true;
    true
}

fn open_storage_password_prompt(
    state: &mut NativePlayerUiState,
    storage: &mut StorageModel,
) -> bool {
    if !state.storage_open()
        || state.storage_password_prompt.is_some()
        || state.storage_rental_confirmation.is_some()
    {
        return false;
    }
    state.storage_password_prompt = match (storage.has_password, storage.unlocked) {
        (true, false) => Some(StoragePasswordPrompt::unlock()),
        (true, true) => Some(StoragePasswordPrompt::change()),
        (false, _) => Some(StoragePasswordPrompt::setup(false)),
    };
    clear_legacy_storage_password_drafts(storage);
    true
}

fn cancel_storage_password_prompt(
    state: &mut NativePlayerUiState,
    storage: &mut StorageModel,
) {
    let close_storage = state
        .storage_password_prompt
        .as_ref()
        .is_some_and(|prompt| prompt.close_storage_on_cancel);
    state.storage_password_prompt = None;
    state.storage_password_input_consumed = true;
    clear_legacy_storage_password_drafts(storage);
    if close_storage && state.storage_open() {
        state.core.panel = mir2_ui_core::state::UiPanel::None;
        state.inventory_item_drag = None;
        state.inventory_item_pointer_consumed = false;
    }
}

/// The final stage keeps its sensitive drafts until the outbound queue accepts
/// the exact pending operation. A full queue or duplicate key leaves the
/// prompt intact for a retry.
fn submit_storage_password_prompt(
    state: &mut NativePlayerUiState,
    storage: &mut StorageModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    let Some(command) = state
        .storage_password_prompt
        .as_mut()
        .and_then(StoragePasswordPrompt::submit)
    else {
        return false;
    };
    let intent = match command {
        StoragePasswordCommand::Unlock(password) => NativePlayerUiIntent::UnlockStorage { password },
        StoragePasswordCommand::Set { current, new } => NativePlayerUiIntent::SetStoragePassword {
            current,
            new_password: new,
        },
    };
    if !intents.push_pending_intent(pending, intent) {
        return false;
    }
    state.storage_password_prompt = None;
    state.storage_password_input_consumed = true;
    clear_legacy_storage_password_drafts(storage);
    true
}

/// A service snapshot may omit the NPC text page immediately after NPCGoods.
/// Its packet-authoritative service remains open until an explicit exit;
/// absence of text alone is not Crystal's NPCResponse(empty)/NPCDialog.Hide.
fn sync_npc_dialog_inventory_location(
    mut state: ResMut<NativePlayerUiState>,
    npc_dialog: Option<Res<NpcDialogModel>>,
    mut shop: Option<ResMut<ShopModel>>,
    mut signals: Option<ResMut<UiSurfaceSignals>>,
    big_map: Option<Res<BigMapModel>>,
    mut was_open: Local<bool>,
    mut previous_npc: Local<Option<u32>>,
    mut previous_map_epoch: Local<Option<u64>>,
) {
    let explicit_exit = std::mem::take(&mut state.npc_service_exit_requested);
    let map_epoch = big_map.as_deref().map(|map| map.reset_epoch);
    let map_changed = previous_map_epoch.is_some() && map_epoch.is_some()
        && *previous_map_epoch != map_epoch;
    *previous_map_epoch = map_epoch;
    let is_open = !explicit_exit && !map_changed
        && npc_dialog.as_deref().is_some_and(|dialog| dialog.is_open);
    let npc_id = npc_dialog.as_deref().filter(|dialog| dialog.is_open)
        .and_then(|dialog| dialog.npc_object_id);
    let npc_changed = matches!((*previous_npc, npc_id), (Some(old), Some(new)) if old != new);
    let closed_service = state.npc_shop_open()
        && shop.as_deref().is_some_and(|shop| shop.service_mode == NpcShopServiceMode::Closed);
    let fresh_service = signals.as_deref().is_some_and(|signals| signals.npc_shop_open_requested);
    let discard_old_service = npc_changed && state.npc_shop_open() && !fresh_service;
    if explicit_exit || map_changed || closed_service || discard_old_service {
        state.npc_service_exit_latched = !discard_old_service;
        if let Some(signals) = signals.as_deref_mut() {
            signals.npc_shop_open_requested = false;
        }
        close_npc_service(&mut state, shop.as_deref_mut());
    }
    if map_changed {
        *previous_npc = None;
    } else if is_open && npc_id.is_some() {
        *previous_npc = npc_id;
    }
    if is_open && (!*was_open || npc_changed) {
        state.npc_service_exit_latched = false;
    }
    if is_open == *was_open && !explicit_exit && !map_changed && !closed_service && !discard_old_service {
        return;
    }
    let was_npc_shop_open = state.npc_shop_open();
    *was_open = is_open;
    state.inventory_window.end_drag();
    state.inventory_window.clear_cursor();
    state.inventory_item_drag = None;
    state.inventory_item_pointer_consumed = false;
    if is_open {
        state.inventory_window.left = NPC_SERVICE_INVENTORY_ORIGIN.x as f32;
        state.inventory_window.top = NPC_SERVICE_INVENTORY_ORIGIN.y as f32;
        return;
    }

    if !explicit_exit && was_npc_shop_open
        && shop.as_deref().is_some_and(|shop| shop.service_mode != NpcShopServiceMode::Closed)
    {
        return;
    }

    state.inventory_window.left = INVENTORY_PANEL_ORIGIN.x as f32;
    state.inventory_window.top = INVENTORY_PANEL_ORIGIN.y as f32;
    if !was_npc_shop_open && !explicit_exit {
        return;
    }

    close_npc_service(&mut state, shop.as_deref_mut());
}

fn close_npc_service(state: &mut NativePlayerUiState, shop: Option<&mut ShopModel>) {
    // An ordinary inventory/another panel is independent from the NPC child.
    let keep_inventory_open = !state.npc_inventory_hidden;
    if state.npc_shop_open() {
        state.core.panel = if keep_inventory_open {
            mir2_ui_core::state::UiPanel::Inventory
        } else {
            mir2_ui_core::state::UiPanel::None
        };
    }
    state.npc_inventory_hidden = false;
    state.shop_service_drag_count = None;
    state.shop_service_drag_unique_id = None;
    state.npc_service_hold = None;
    state.npc_service_notice = None;
    state.npc_service_notice_mode = None;
    state.shop_repair_container = 0;
    state.shop_repair_slot = None;
    if let Some(shop) = shop {
        shop.selected_id = None;
        shop.selected_bag_slot_for_sell = None;
        shop.selected_bag_slot_for_repair = None;
        let _ = shop.apply_service_signal(NpcShopServiceSignal::default());
    }
}

/// Native NPCGoods/NPCSell packets can open their service without a preceding
/// NPCDialog transition. Place the newly exposed bag after service input and
/// before rendering; watching only the parent dialogue leaves it at (0,0).
/// Run only on open/reopen or a Buy/Drop tab transition, not on ordinary frames,
/// so the player can still deliberately drag overlapping windows afterwards.
fn sync_npc_shop_inventory_location(
    mut state: ResMut<NativePlayerUiState>,
    mut shop: ResMut<ShopModel>,
    mut previous_surface: Local<Option<bool>>,
) {
    if state.npc_service_exit_latched || (previous_surface.is_some() && !state.npc_shop_open()) {
        if previous_surface.is_some() && !state.npc_shop_open() {
            state.npc_service_exit_latched = true;
        }
        close_npc_service(&mut state, Some(&mut shop));
    }
    let surface = (state.npc_shop_open() && state.inventory_open())
        .then(|| shop.allows_buy() && (!shop.allows_sell() || state.npc_shop_buy_tab));
    if surface == *previous_surface {
        return;
    }
    *previous_surface = surface;
    let Some(buy) = surface else {
        return;
    };
    let bag = CrystalRect::new(
        state.inventory_window.left,
        state.inventory_window.top,
        INVENTORY_PANEL_SIZE.width as f32,
        INVENTORY_PANEL_SIZE.height as f32,
    );
    let dialog = CrystalRect::new(
        0.0, 0.0,
        NPC_DIALOG_PANEL_SIZE.width as f32, NPC_DIALOG_PANEL_SIZE.height as f32,
    );
    let service = if buy {
        CrystalRect::new(
            NPC_GOODS_PANEL_ORIGIN.x as f32, NPC_GOODS_PANEL_ORIGIN.y as f32,
            NPC_GOODS_PANEL_SIZE.width as f32, NPC_GOODS_PANEL_SIZE.height as f32,
        )
    } else {
        CrystalRect::new(
            NPC_DROP_PANEL_ORIGIN.x as f32, NPC_DROP_PANEL_ORIGIN.y as f32,
            NPC_DROP_PANEL_SIZE.width as f32, NPC_DROP_PANEL_SIZE.height as f32,
        )
    };
    let overlaps = |other: CrystalRect| {
        bag.left < other.left + other.width && bag.left + bag.width > other.left
            && bag.top < other.top + other.height && bag.top + bag.height > other.top
    };
    if bag.is_valid_hit_target()
        && (0.0..=INVENTORY_MAX_LEFT).contains(&bag.left)
        && (0.0..=INVENTORY_MAX_TOP).contains(&bag.top)
        && !overlaps(dialog) && !overlaps(service)
    {
        return;
    }
    state.inventory_window.left = NPC_SERVICE_INVENTORY_ORIGIN.x as f32;
    state.inventory_window.top = NPC_SERVICE_INVENTORY_ORIGIN.y as f32;
    state.inventory_window.end_drag();
    state.inventory_window.clear_cursor();
    state.inventory_item_drag = None;
    state.inventory_item_pointer_consumed = false;
}

pub(crate) fn process_overlay_keyboard(
    mut state: ResMut<NativePlayerUiState>,
    mut intents: ResMut<NativePlayerUiIntentQueue>,
    mut pending: ResMut<PendingOperations>,
    mut shell_intents: ResMut<NativeUiIntentQueue>,
    mut shell: ResMut<NativeShellModel>,
    mut social: Option<ResMut<crate::social::SocialModel>>,
    keys: Res<ButtonInput<KeyCode>>,
    mut typed: MessageReader<KeyboardInput>,
    inventory: Res<InventoryModel>,
    mut compose_ui: ResMut<MailComposeUi>,
    mut game_shop: Option<ResMut<GameShopModel>>,
    mut storage: ResMut<StorageModel>,
    big_map_controls: BigMapControls,
    chat_state: Option<Res<crate::crystal_ui::chat::CrystalChatState>>,
    npc_dialog: Option<Res<NpcDialogModel>>,
    keyboard_controls: OverlayKeyboardControls,
) {
    if shell.screen != NativeShellScreen::InGame {
        // Session ownership is reset exactly once through
        // SessionResetRevision/apply_overlay_session_reset. Keyboard handling
        // must never race the typed preserving boundary or clear GameShop
        // correlation after runtime receipt ingest.
        return;
    }
    if state.ime_frame_consumed {
        typed.clear();
        return;
    }
    let BigMapControls {
        model: mut big_map,
        intents: mut big_map_intents,
        ui: mut big_map_ui,
        time,
        skill_binding: mut skill_binding,
        skills: mut skills,
        skill_persistence: mut skill_persistence,
    } = big_map_controls;
    let OverlayKeyboardControls {
        mut surface_signals,
        mut ui_audio,
        ui,
        mut mail,
        mut effects,
        mut belt,
        mut letter_editor,
        parcel,
    } = keyboard_controls;
    let fallback_parcel = mail_parcel::MailParcelUi::default();
    let parcel = parcel.as_deref().unwrap_or(&fallback_parcel);

    if keys.just_pressed(KeyCode::F12)
        && (keys.pressed(KeyCode::ControlLeft) || keys.pressed(KeyCode::ControlRight))
        && (keys.pressed(KeyCode::ShiftLeft) || keys.pressed(KeyCode::ShiftRight))
    {
        typed.clear();
        return;
    }
    if state.leave_game.blocks() {
        for event in typed.read() {
            // Other UI branches can leave raw messages unread. A key pressed
            // before this prompt opened must not confirm it on a later frame.
            if event.state == ButtonState::Pressed
                && !event.repeat
                && keys.just_pressed(event.key_code)
            {
                if matches!(
                    event.key_code,
                    KeyCode::Enter | KeyCode::NumpadEnter | KeyCode::Escape
                ) {
                    eprintln!(
                        "[native-exit] leave_answer source=keyboard key={:?} prompt={:?}",
                        event.key_code, state.leave_game.prompt
                    );
                }
                match event.key_code {
                    KeyCode::Enter | KeyCode::NumpadEnter => leave_game_dialog::finish(
                        &mut state,
                        &mut shell,
                        &mut shell_intents,
                        effects.as_deref_mut(),
                        true,
                    ),
                    KeyCode::Escape => leave_game_dialog::finish(
                        &mut state,
                        &mut shell,
                        &mut shell_intents,
                        effects.as_deref_mut(),
                        false,
                    ),
                    _ => {}
                }
            }
        }
        return;
    }
    if state.social_bonds.prompt.is_some() {
        let events: Vec<_> = typed.read().cloned().collect();
        social_bond_dialog::host::keyboard(&mut state, &mut intents, &events);
        return;
    }
    if state.group_dialog.modal() || state.group_dialog.consumed {
        let events: Vec<_> = typed.read().cloned().collect();
        if let Some(social) = social.as_deref_mut() {
            if state.group_dialog.invitation.is_some() {
                for event in &events {
                    if event.state == ButtonState::Pressed
                        && !event.repeat
                        && matches!(
                            event.key_code,
                            KeyCode::Enter | KeyCode::NumpadEnter | KeyCode::Escape
                        )
                    {
                        group_dialog::answer_invitation(
                            &mut state,
                            social,
                            &mut intents,
                            event.key_code != KeyCode::Escape,
                        );
                        break;
                    }
                }
            } else {
                state.group_dialog.keyboard(&events, &mut intents, social);
            }
        }
        return;
    }
    if state.guild_panel.blocks() {
        for event in typed.read() {
            if event.state == ButtonState::Pressed
                && !event.repeat
                && matches!(
                    event.key_code,
                    KeyCode::Enter | KeyCode::NumpadEnter | KeyCode::Escape
                )
            {
                if state.guild_panel.invite.is_some() {
                    if let Some(social) = social.as_deref_mut() {
                        guild_panel::answer_invite(
                            &mut state,
                            social,
                            &mut intents,
                            event.key_code != KeyCode::Escape,
                        );
                    }
                } else if state.guild_panel.kick_member.is_some()
                    && event.key_code != KeyCode::Escape
                {
                    if let Some(social) = social.as_deref_mut() {
                        guild_panel::confirm_kick(&mut state, social, &mut intents);
                    }
                } else if state.guild_panel.member_change.is_some()
                    && event.key_code != KeyCode::Escape
                {
                    if let Some(social) = social.as_deref_mut() {
                        guild_panel::confirm_member_rank(&mut state, social, &mut intents);
                    }
                } else if state.guild_panel.create_rank && event.key_code != KeyCode::Escape {
                    if let Some(social) = social.as_deref_mut() {
                        guild_panel::confirm_create_rank(&mut state, social, &mut intents);
                    }
                } else {
                    state.guild_panel.close_error();
                }
            }
        }
        return;
    }
    if equipment_creature_host::modal(&state) {
        let events: Vec<_> = typed.read().cloned().collect();
        equipment_creature_host::keyboard(
            &mut state,
            &mut intents,
            &events,
            time.as_ref().map_or(0, |t| t.elapsed().as_millis() as u64),
        );
        typed.clear();
        return;
    }
    if state.friends.modal.is_some()
        && !state.non_friend_amount_modal_open()
        && state.trade_dialog.message.is_none()
        && !state.keyboard.open
    {
        let events: Vec<_> = typed.read().cloned().collect();
        friend_dialog::host::keyboard(&mut state, &mut intents, &events);
        typed.clear();
        return;
    }
    if state.keyboard.input_consumed {
        typed.clear();
        return;
    }
    if state.keyboard.open {
        typed.clear();
        if state.keyboard.waiting.is_none()
            && (keyboard_dialog::host::triggered(&state.keyboard, &keys, "Keybind")
                || keyboard_dialog::host::triggered(&state.keyboard, &keys, "Closeall"))
        {
            state.keyboard.hide();
        }
        return;
    }
    if let Some(message) = state.trade_dialog.message.as_ref() {
        let revision = message.revision();
        let action = typed
            .read()
            .filter(|event| event.state == ButtonState::Pressed && !event.repeat)
            .find_map(|event| match event.key_code {
                KeyCode::Escape => Some(false),
                KeyCode::Enter | KeyCode::NumpadEnter => Some(true),
                _ => None,
            })
            .or_else(|| {
                if keys.just_pressed(KeyCode::Escape) {
                    Some(false)
                } else if keys.just_pressed(KeyCode::Enter)
                    || keys.just_pressed(KeyCode::NumpadEnter)
                {
                    Some(true)
                } else {
                    None
                }
            });
        typed.clear();
        if let Some(accept) = action {
            if let Some(social) = social.as_deref() {
                trade_dialog::answer_message(&mut state, social, &mut intents, revision, accept);
            }
        }
        return;
    }
    if state.guild_gold_prompt.is_some() {
        let events: Vec<_> = typed.read().cloned().collect();
        let action = state
            .guild_gold_prompt
            .as_mut()
            .unwrap()
            .input
            .key_action(&keys, &events);
        if action == AmountKeyAction::Cancel {
            state.guild_gold_prompt = None;
        } else if action == AmountKeyAction::Confirm {
            if state
                .guild_gold_prompt
                .as_ref()
                .is_some_and(|prompt| prompt.amount().is_none())
            {
                state.guild_gold_prompt = None;
            } else if let Some(social) = social.as_deref_mut() {
                confirm_guild_gold(
                    &mut state,
                    social,
                    ui.as_deref().map(|model| model.player.gold).unwrap_or(0),
                    time.as_deref()
                        .map(|time| time.elapsed().as_millis() as u64)
                        .unwrap_or(0),
                    &mut intents,
                );
            }
        }
        return;
    }
    if state.parcel_gold_prompt.is_some() {
        let events: Vec<_> = typed.read().cloned().collect();
        let action = state
            .parcel_gold_prompt
            .as_mut()
            .expect("checked parcel amount prompt")
            .key_action(&keys, &events);
        match action {
            AmountKeyAction::Cancel => {
                state.parcel_gold_prompt = None;
                state.parcel_gold_input_consumed = true;
            }
            AmountKeyAction::Confirm => {
                if let Some(amount) = state
                    .parcel_gold_prompt
                    .as_ref()
                    .and_then(CrystalAmountInput::amount)
                {
                    if let Some(draft) = state.core.mail_compose.as_mut() {
                        draft.gold = amount;
                    }
                }
                state.parcel_gold_prompt = None;
                state.parcel_gold_input_consumed = true;
            }
            AmountKeyAction::None => {}
        }
        return;
    }
    if state.trade_dialog.gold_prompt.is_some() {
        let events: Vec<_> = typed.read().cloned().collect();
        let action = state
            .trade_dialog
            .gold_prompt
            .as_mut()
            .unwrap()
            .input
            .key_action(&keys, &events);
        if action == AmountKeyAction::Cancel {
            state.trade_dialog.gold_prompt = None;
        } else if action == AmountKeyAction::Confirm {
            if let Some(social) = social.as_deref_mut() {
                trade_dialog::confirm_gold(
                    &mut state,
                    social,
                    ui.as_deref().map(|model| model.player.gold).unwrap_or(0),
                    &mut intents,
                );
            } else {
                state.trade_dialog.gold_prompt = None;
            }
        }
        return;
    }

    // MailDialog's Write action opens a MirInputBox before the Letter dialog.
    // It owns this frame, including the close frame, so recipient input cannot
    // reach the covered list, chat, or world controls.
    if compose_ui.recipient_prompt.is_some() {
        if keys.just_pressed(KeyCode::Escape) {
            cancel_mail_recipient_prompt(&mut state, &mut compose_ui);
            ui_audio.push(crate::audio::NativeUiSound::ButtonB);
        } else {
            if keys.just_pressed(KeyCode::Backspace) {
                if let Some(prompt) = compose_ui.recipient_prompt.as_mut() {
                    prompt.recipient.pop();
                }
            }
            for event in typed.read() {
                if event.state == ButtonState::Pressed {
                    if let Some(text) = event.text.as_deref() {
                        if let Some(prompt) = compose_ui.recipient_prompt.as_mut() {
                            for ch in text.chars().filter(|ch| !ch.is_control()) {
                                if prompt.recipient.chars().count() < 20 {
                                    prompt.recipient.push(ch);
                                }
                            }
                        }
                    }
                }
            }
            if keys.just_pressed(KeyCode::Enter) || keys.just_pressed(KeyCode::NumpadEnter) {
                let mut fallback = UiEffectQueue::default();
                let effects = effects.as_deref_mut().unwrap_or(&mut fallback);
                if confirm_mail_recipient_prompt(&mut state, &mut compose_ui, effects) {
                    ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                }
            }
        }
        typed.clear();
        return;
    }

    // Mail result/error feedback owns this input frame even after its OK
    // button, Enter, or Escape closes it. This is intentionally above the
    // reader and parcel-delete warning in both render and input order.
    if state.mail_feedback_prompt.is_some() {
        if keys.just_pressed(KeyCode::Escape)
            || keys.just_pressed(KeyCode::Enter)
            || keys.just_pressed(KeyCode::NumpadEnter)
        {
            state.mail_feedback_prompt = None;
            state.mail_feedback_input_consumed = true;
            compose_ui.last_notice = None;
            ui_audio.push(crate::audio::NativeUiSound::ButtonB);
        }
        typed.clear();
        return;
    }

    // MailDialog's parcel warning is a source MirMessageBox Yes/No. It owns
    // this entire input frame even after Enter/Escape closes it.
    if state.mail_delete_prompt.is_some() {
        if keys.just_pressed(KeyCode::Escape) {
            state.mail_delete_input_consumed = true;
            state.mail_delete_prompt = None;
            ui_audio.push(crate::audio::NativeUiSound::ButtonB);
        } else if keys.just_pressed(KeyCode::Enter) {
            state.mail_delete_input_consumed = true;
            if mail.as_deref_mut().is_some_and(|mail| {
                confirm_mail_delete(&mut state, mail, &mut intents, &mut pending)
            }) {
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
            }
        }
        typed.clear();
        return;
    }

    // Mail readers are independent source windows. Escape closes the current
    // exact-ID reader and consumes the entire frame before it can reach the
    // list, chat, or world movement handlers.
    if state.mail_reader.is_some() {
        if keys.just_pressed(KeyCode::Escape) {
            state.mail_reader = None;
            state.mail_reader_input_consumed = true;
            ui_audio.push(crate::audio::NativeUiSound::ButtonB);
        }
        typed.clear();
        return;
    }

    // MirAmountBox/MirMessageBox consume every keyboard event while modal.
    // Enter confirms, Escape follows Cancel/No, and the amount textbox accepts
    // digits only with the initial maximum value fully selected.
    if state.inventory_delete_prompt.is_some() {
        if keys.just_pressed(KeyCode::Escape) {
            state.cancel_inventory_delete();
            ui_audio.push(crate::audio::NativeUiSound::ButtonB);
            return;
        }
        if keys.just_pressed(KeyCode::Enter) {
            if confirm_inventory_delete(
                &mut state,
                &inventory,
                parcel,
                &mut intents,
                &mut pending,
            ) {
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
            }
            return;
        }
        if keys.just_pressed(KeyCode::Backspace) {
            delete_amount_backspace(&mut state);
        }
        for event in typed.read() {
            if event.state == ButtonState::Pressed {
                if let Some(text) = &event.text {
                    push_delete_amount_text(&mut state, text);
                }
            }
        }
        return;
    }

    if state.group_open() && state.group_invite_focused {
        let Some(social) = social.as_deref_mut() else {
            return;
        };
        if keys.just_pressed(KeyCode::Escape) {
            state.group_invite_focused = false;
            state.group_invite_draft.clear();
            return;
        }
        if keys.just_pressed(KeyCode::Backspace) {
            state.group_invite_draft.pop();
        }
        if keys.just_pressed(KeyCode::Enter) {
            let name = state.group_invite_draft.trim().to_owned();
            if valid_social_name(&name) && queue_group_invite_by_name(&mut intents, social, name) {
                state.group_invite_focused = false;
                state.group_invite_draft.clear();
            }
            return;
        }
        for event in typed.read() {
            if event.state == ButtonState::Pressed {
                if let Some(text) = &event.text {
                    push_social_name_text(&mut state.group_invite_draft, text);
                }
            }
        }
        return;
    }

    if state.guild_open() && state.guild_recruit_focused {
        let Some(social) = social.as_deref_mut() else {
            return;
        };
        if keys.just_pressed(KeyCode::Escape) {
            state.guild_recruit_focused = false;
            state.guild_recruit_draft.clear();
            return;
        }
        let draft = state.guild_recruit_draft.clone();
        state.guild_panel.sync_recruit(&draft);
        for event in typed.read() {
            friend_dialog::host::edit_key(&mut state.guild_panel.recruit_editor, event);
        }
        state.guild_recruit_draft = state
            .guild_panel
            .recruit_editor
            .editor
            .as_ref()
            .map(|e| e.text().to_owned())
            .unwrap_or_default();
        return;
    }

    if state.guild_open() && state.guild_left_page == GuildLeftPage::Members {
        if let Some(social) = social.as_deref() {
            let count = social
                .guild
                .members
                .iter()
                .filter(|m| !state.guild_panel.hide_offline || m.online)
                .count();
            let handled = keys
                .get_just_pressed()
                .copied()
                .any(|key| state.guild_panel.member_page_key(key, count));
            if handled {
                typed.clear();
                return;
            }
        }
    }
    if state.guild_open()
        && state.guild_left_page == GuildLeftPage::Ranks
        && state.guild_rank_name_focused
    {
        if keys.just_pressed(KeyCode::Escape) {
            state.guild_rank_name_focused = false;
            state.guild_rank_name_draft.clear();
            return;
        }
        if keys.just_pressed(KeyCode::Enter) || keys.just_pressed(KeyCode::NumpadEnter) {
            if let Some(social) = social.as_deref_mut() {
                guild_panel::save_rank_name(&mut state, social, &mut intents);
            }
            typed.clear();
            return;
        }
        let draft = state.guild_rank_name_draft.clone();
        state.guild_panel.sync_rank(&draft);
        for event in typed.read() {
            if event.text.as_deref() == Some("\\") {
                continue;
            }
            friend_dialog::host::edit_key(&mut state.guild_panel.rank_editor, event);
        }
        state.guild_rank_name_draft = state
            .guild_panel
            .rank_editor
            .editor
            .as_ref()
            .map(|e| e.text().to_owned())
            .unwrap_or_default();
        return;
    }

    if state.guild_open()
        && state.guild_left_page == GuildLeftPage::Notice
        && state.guild_notice_editing
    {
        if state.guild_notice_submission.is_some() {
            // A submitted draft stays immutable until an authoritative result
            // resolves the matching social pending operation.
            return;
        }
        if keys.just_pressed(KeyCode::Escape) {
            state.guild_notice_editing = false;
            state.guild_notice_draft.clear();
            return;
        }
        let draft = state.guild_notice_draft.clone();
        state.guild_panel.sync_notice(&draft);
        for event in typed.read() {
            friend_dialog::host::edit_key(&mut state.guild_panel.notice_editor, event);
        }
        state.guild_notice_draft = state.guild_panel.notice_draft();
        return;
    }

    if state.core.mail_compose_open() {
        if keys.just_pressed(KeyCode::Escape) {
            if pending.has_pending_mail_send() {
                compose_ui.last_notice = Some("Sending mail…".to_owned());
                typed.clear();
                return;
            }
            dispatch_ui_action(
                &mut state.core,
                &mut UiEffectQueue::default(),
                mir2_ui_core::action::UiAction::CancelMailCompose,
            );
            compose_ui.kind = MailComposeKind::Letter;
            clear_mail_feedback(&mut state, &mut compose_ui);
            return;
        }
        if pending.has_pending_mail_send() {
            compose_ui.last_notice = Some("Sending mail…".to_owned());
            typed.clear();
            return;
        }
        if compose_ui.kind == MailComposeKind::Letter
            || (compose_ui.kind == MailComposeKind::Parcel
                && compose_ui.focus == MailComposeFocus::Message)
        {
            compose_ui.focus = MailComposeFocus::Message;
            if pending.has_pending_mail_send() {
                compose_ui.last_notice = Some("Sending mail…".to_owned());
                typed.clear();
                return;
            }
            let Some(draft) = state.core.mail_compose.as_mut() else {
                return;
            };
            if let Some(editor) = letter_editor.as_deref_mut() {
                editor.sync(true, Some(&draft.message));
                for event in typed.read() {
                    editor.edit_key(event, draft);
                }
            } else {
                // Test-only hosts that exercise the shared core without the
                // native renderer retain the reducer's bounded edit behavior.
                for event in typed.read() {
                    if event.state != ButtonState::Pressed {
                        continue;
                    }
                    let mut value = friend_dialog::text_editor::FriendTextEditor::new(
                        draft.message.clone(), mail_editor::MAIL_LETTER_BODY_LIMIT, true,
                    );
                    if matches!(event.key_code, KeyCode::Enter | KeyCode::NumpadEnter) {
                        value.newline();
                    } else if let Some(text) = event.text.as_deref() {
                        value.insert_with_policy(text, friend_dialog::text_editor::InsertPolicy::FitPrefix);
                    }
                    draft.message = value.text().to_owned();
                }
            }
            return;
        }
        if keys.just_pressed(KeyCode::Tab) {
            compose_ui.focus = match compose_ui.focus {
                MailComposeFocus::Recipient => MailComposeFocus::Message,
                MailComposeFocus::Message => MailComposeFocus::Gold,
                MailComposeFocus::Gold => MailComposeFocus::Recipient,
            };
        }
        if keys.just_pressed(KeyCode::Backspace) {
            if let Some(draft) = state.core.mail_compose.as_ref() {
                match compose_ui.focus {
                    MailComposeFocus::Recipient => {
                        let mut value = draft.recipient.clone();
                        value.pop();
                        state.core.mail_compose.as_mut().unwrap().recipient = value;
                    }
                    MailComposeFocus::Message => {
                        let mut value = draft.message.clone();
                        value.pop();
                        state.core.mail_compose.as_mut().unwrap().message = value;
                    }
                    MailComposeFocus::Gold => {
                        state.core.mail_compose.as_mut().unwrap().gold /= 10;
                    }
                }
            }
        }
        for event in typed.read() {
            if event.state != ButtonState::Pressed {
                continue;
            }
            let text = event.text.as_deref().unwrap_or("");
            match compose_ui.focus {
                MailComposeFocus::Recipient if compose_ui.kind == MailComposeKind::Parcel => {
                    // Parcel recipient is the preceding MailSendRequest input
                    // box's display-only label, exactly as Crystal renders it.
                }
                MailComposeFocus::Recipient => {
                    let mut value = state
                        .core
                        .mail_compose
                        .as_ref()
                        .map(|draft| draft.recipient.clone())
                        .unwrap_or_default();
                    value.extend(text.chars().filter(|ch| !ch.is_control()));
                    dispatch_ui_action(
                        &mut state.core,
                        &mut UiEffectQueue::default(),
                        mir2_ui_core::action::UiAction::SetMailRecipient { recipient: value },
                    );
                }
                MailComposeFocus::Message => {
                    let mut value = state
                        .core
                        .mail_compose
                        .as_ref()
                        .map(|draft| draft.message.clone())
                        .unwrap_or_default();
                    if matches!(event.key_code, KeyCode::Enter | KeyCode::NumpadEnter) {
                        value.push('\n');
                    } else {
                        value.extend(text.chars().filter(|ch| !ch.is_control()));
                    }
                    dispatch_ui_action(
                        &mut state.core,
                        &mut UiEffectQueue::default(),
                        mir2_ui_core::action::UiAction::SetMailMessage { message: value },
                    );
                }
                MailComposeFocus::Gold => {
                    if let Some(draft) = state.core.mail_compose.as_mut() {
                        for digit in text.chars().filter(|ch| ch.is_ascii_digit()) {
                            if let Some(value) = draft.gold.checked_mul(10)
                                .and_then(|value| value.checked_add(digit as u32 - '0' as u32)) {
                                draft.gold = value;
                            }
                        }
                    }
                }
            }
        }
        return;
    }

    if let Some(signals) = surface_signals.as_deref_mut() {
        if signals.npc_shop_open_requested {
            state.npc_shop_buy_tab = true;
            state.npc_service_hold = None;
            if !state.npc_shop_open() && !state.npc_service_exit_latched {
                state.toggle_npc_shop();
            }
            signals.npc_shop_open_requested = false;
        }
    }

    if state.hero.modal() {
        if state.hero.assign.open
            && keys.just_pressed(KeyCode::Escape)
            && state.hero.assign.pending.is_none()
        {
            state.hero.assign = Default::default();
        }
        return;
    }
    if state.skill_assign.open {
        if keys.just_pressed(KeyCode::Escape) && !state.skill_assign.pending {
            state.skill_assign = Default::default();
            if let Some(binding) = skill_binding.as_deref_mut() {
                binding.set_assign_key(false);
            }
        }
        return;
    }

    if game_shop_dialog::keyboard(&mut state, &keys, &mut typed) {
        return;
    }
    if state.bigmap_open() && big_map_ui.as_deref().is_some_and(|ui| ui.search_focused) {
        let (Some(big_map), Some(big_map_intents), Some(big_map_ui)) = (
            big_map.as_deref_mut(),
            big_map_intents.as_deref_mut(),
            big_map_ui.as_deref_mut(),
        ) else {
            return;
        };
        if keys.just_pressed(KeyCode::Backspace) {
            let mut value = big_map.search.draft.clone();
            value.pop();
            big_map.set_search_draft(value);
        }
        for event in typed.read() {
            if event.state != ButtonState::Pressed {
                continue;
            }
            if let Some(text) = &event.text {
                let mut value = big_map.search.draft.clone();
                value.extend(text.chars().filter(|ch| !ch.is_control()));
                big_map.set_search_draft(value);
            }
        }
        if keys.just_pressed(KeyCode::Enter) {
            let now_ms = time
                .as_deref()
                .map(|clock| clock.elapsed().as_millis() as u64)
                .unwrap_or_default();
            let _ = big_map_intents.search(big_map, now_ms, BIG_MAP_SEARCH_COOLDOWN_MS);
            return;
        }
        if !keys.just_pressed(KeyCode::Escape) {
            return;
        }
        big_map_ui.search_focused = false;
    }

    if state.chat_focused() {
        if keys.just_pressed(KeyCode::Escape) {
            state.set_chat_focused(false);
            state.chat_draft.clear();
            return;
        }
        if keys.just_pressed(KeyCode::Enter) {
            let raw = state.chat_draft.clone();
            let message_opt = if let Some(cs) = chat_state.as_deref() {
                crate::crystal_ui::chat::format_chat_for_filter(cs.filter, &raw)
            } else {
                let t = raw.trim();
                if t.is_empty() {
                    None
                } else {
                    Some(t.to_owned())
                }
            };
            state.chat_draft.clear();
            state.set_chat_focused(false);
            if let Some(message) = message_opt {
                if !message.is_empty() {
                    intents.push_intent(NativePlayerUiIntent::Chat { message });
                }
            }
            return;
        }
        if keys.just_pressed(KeyCode::Backspace) {
            state.chat_draft.pop();
        }
        for event in typed.read() {
            if event.state != ButtonState::Pressed {
                continue;
            }
            if let Some(text) = &event.text {
                for ch in text.chars() {
                    if !ch.is_control() && state.chat_draft.chars().count() < 60 {
                        state.chat_draft.push(ch);
                    }
                }
            }
        }
        return;
    }

    // StorageDialog's Rent message box owns every keyboard event. Enter is
    // its OK action and Escape is Cancel; neither may fall through to chat.
    if state.storage_rental_confirmation.is_some() {
        if keys.just_pressed(KeyCode::Escape) {
            cancel_storage_rental_confirmation(&mut state);
            typed.clear();
            return;
        }
        if keys.just_pressed(KeyCode::Enter) || keys.just_pressed(KeyCode::NumpadEnter) {
            let _ = submit_storage_rental_confirmation(&mut state, &mut intents);
        }
        typed.clear();
        return;
    }

    // StorageDialog's MirInputBox owns every keyboard event. In particular,
    // Enter cannot fall through to chat and Escape cannot close an unrelated
    // panel after cancelling a password stage.
    if state.storage_password_prompt.is_some() {
        if keys.just_pressed(KeyCode::Escape) {
            cancel_storage_password_prompt(&mut state, &mut storage);
            typed.clear();
            return;
        }
        if keys.just_pressed(KeyCode::Backspace) {
            if let Some(prompt) = state.storage_password_prompt.as_mut() {
                prompt.draft.pop();
            }
        }
        for event in typed.read() {
            if event.state == ButtonState::Pressed {
                if let Some(text) = &event.text {
                    if let Some(prompt) = state.storage_password_prompt.as_mut() {
                        prompt.push_text(text);
                    }
                }
            }
        }
        if keys.just_pressed(KeyCode::Enter) || keys.just_pressed(KeyCode::NumpadEnter) {
            let _ = submit_storage_password_prompt(
                &mut state,
                &mut storage,
                &mut intents,
                &mut pending,
            );
        }
        return;
    }

    // Clear obsolete hidden drafts left by the pre-modal adapter. The visible
    // modal above is now the sole password input path.
    if state.storage_open() && storage.has_password && !storage.unlocked {
        clear_legacy_storage_password_drafts(&mut storage);
        return;
    }

    if keys.just_pressed(KeyCode::Enter) {
        state.set_chat_focused(true);
        return;
    }
    // Crystal's default Help binding is H with Ctrl and Shift explicitly
    // unpressed; Alt is a don't-care modifier. Ctrl+H remains available to
    // the attack-mode binding and Shift+H must not toggle Help.
    let help_shortcut = keyboard_dialog::host::triggered(&state.keyboard, &keys, "Help");
    if help_shortcut {
        state.help.toggle();
    }
    // Quest/NPC surfaces own Escape. This system is ordered before the quest
    // input system so returning here preserves the pre-key modal state for the
    // dedicated handler and prevents the same key from opening Menu after it
    // closes Quest/Dialog later in this update.
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Closeall")
        && (state.quest_open() || npc_dialog.as_deref().is_some_and(|dialog| dialog.is_open))
    {
        return;
    }
    if (keyboard_dialog::host::triggered(&state.keyboard, &keys, "Inventory")
        || keyboard_dialog::host::triggered(&state.keyboard, &keys, "Inventory2"))
    {
        let was_open = state.inventory_open();
        state.toggle_inventory();
        if !state.inventory_open() {
            state.inspect = None;
            state.inventory_operation = None;
            state.drop_confirmation = None;
            state.inventory_delete_mode = false;
            state.inventory_delete_prompt = None;
        } else if was_open {
            // already handled
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Skillbar")
        && skills.as_deref().is_some_and(|skills| {
            skill_bars::SkillBarsUi::has_skill(skills, 0)
                || skill_bars::SkillBarsUi::has_skill(skills, 1)
        })
    {
        state.core.options.skill_bar = !state.core.options.skill_bar;
        if let Some(effects) = effects.as_deref_mut() {
            effects.push(mir2_ui_core::effect::UiEffect::PersistOptions {
                options: state.core.options.clone(),
            });
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "DropView") {
        state.local_keys.show_drops(std::time::Instant::now());
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Autorun") {
        let on = !state.local_keys.auto_run;
        state.local_keys.set_auto_run(on);
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Cameramode") {
        state.local_keys.camera_hidden = !state.local_keys.camera_hidden;
        if !state.local_keys.camera_hidden {
            state.status_hud.restore_camera();
            if !state.minimap_visible() {
                state.toggle_minimap();
            }
            if let Some(belt) = belt.as_deref_mut() {
                belt.visible = true;
            }
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Equipment")
        || keyboard_dialog::host::triggered(&state.keyboard, &keys, "Equipment2")
    {
        // Crystal's Equipment shortcut shares the CharacterButton page
        // state machine but does not invoke MirControl.OnMouseClick, so it is
        // intentionally silent.
        state.activate_character_hud_button();
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Skills")
        || keyboard_dialog::host::triggered(&state.keyboard, &keys, "Skills2")
    {
        state.toggle_skill();
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Bigmap") {
        state.toggle_bigmap();
    }
    // V is also the native town-revive key. While dead, reserve that press for
    // revival so the minimap does not silently collapse on the respawn frame.
    let v_revives_dead_player = keys.just_pressed(KeyCode::KeyV)
        && ui
            .as_deref()
            .is_some_and(|model| model.player.hp <= 0 && model.player.max_hp > 0);
    if !v_revives_dead_player && keyboard_dialog::host::triggered(&state.keyboard, &keys, "Minimap") {
        state.toggle_minimap();
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "GameShop") {
        state.toggle_shop();
        if !state.shop_open() {
            state.shop_quantity = 1;
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Group") {
        // Crystal's default binding is P = Group. Help page one exposes this
        // binding, so the production route must not silently open Storage.
        state.toggle_group();
    }
    for (function, page) in [
        ("Mentor", social_bond_dialog::BondPage::Mentor),
        ("Relationship", social_bond_dialog::BondPage::Relationship),
    ] {
        if keyboard_dialog::host::triggered(&state.keyboard, &keys, function) {
            social_bond_dialog::host::toggle(&mut state, page);
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Friends") {
        friend_dialog::host::toggle(&mut state, &mut intents);
    }
    for (function, page) in [("MountWindow", 0), ("Fishing", 1), ("Creature", 2)] {
        if keyboard_dialog::host::triggered(&state.keyboard, &keys, function) {
            equipment_creature_host::toggle(
                &mut state,
                &mut intents,
                page,
                time.as_ref().map_or(0, |t| t.elapsed().as_millis() as u64),
            );
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Mount") {
        if let Some(mount_fishing_dialog::EquipmentIntent::Packet(packet)) =
            state.equipment_dialogs.action(
                mount_fishing_dialog::EquipmentAction::Ride,
                time.as_ref().map_or(0, |t| t.elapsed().as_millis() as u64),
            )
        {
            equipment_creature_host::enqueue(&mut state, &mut intents, packet);
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Ranking") {
        if state.ranking.open {
            state.ranking.hide();
        } else {
            state.ranking.show(0);
        }
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Closeall") {
        if state.core.panel != mir2_ui_core::state::UiPanel::None
            || state.inspect.is_some()
            || state.help_open()
            || state.equipment_dialogs.mount_open
            || state.equipment_dialogs.fishing_open
            || state.equipment_dialogs.status_open
            || state.creature.open
            || state.friends.open
            || state.ranking.open
            || state.ranking.player_inspect.is_open()
            || state.trade_dialog.open
        {
            // GameScene.Closeall deliberately omits both TradeDialogs. Escape
            // closes Inventory/other general windows, not the active exchange.
            equipment_creature_host::close_general(
                &mut state,
                &mut intents,
                time.as_ref().map_or(0, |t| t.elapsed().as_millis() as u64),
            );
            let trade = std::mem::take(&mut state.trade_dialog);
            state.close_all_windows();
            state.trade_dialog = trade;
            state.shop_quantity = 1;
            if let Some(skill_binding) = skill_binding.as_deref_mut() {
                skill_binding.clear_selection();
                skill_binding.set_assign_key(false);
            }
            storage.password_draft.clear();
            storage.new_password_draft.clear();
            storage.confirm_password_draft.clear();
        } else {
            state.toggle_menu();
        }
        return;
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Keybind") {
        state.keyboard.show();
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Guilds") {
        state.toggle_guild();
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Options")
        || keyboard_dialog::host::triggered(&state.keyboard, &keys, "Options2")
    {
        state.toggle_options();
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Trade") {
        intents.push_intent(NativePlayerUiIntent::TradeRequest);
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Logout") {
        state.leave_game.request(
            leave_game_dialog::LeaveKind::Logout,
            std::time::Instant::now(),
        );
    }
    if keyboard_dialog::host::triggered(&state.keyboard, &keys, "Exit") {
        eprintln!("[native-exit] leave_request source=keyboard_exit");
        state.leave_game.request(
            leave_game_dialog::LeaveKind::Exit,
            std::time::Instant::now(),
        );
    }
    // Cash GameShop quantity hotkeys use the cash model; NPC quantity stays
    // in the NPC-only state field.
    if state.shop_open() {
        let Some(game_shop) = game_shop.as_deref_mut() else {
            return;
        };
        if keys.just_pressed(KeyCode::BracketRight) || keys.just_pressed(KeyCode::Equal) {
            game_shop.quantity_inc();
            if let Some(item) = game_shop.selected() {
                let quantity = game_shop
                    .quantity
                    .min(game_shop_dialog::quantity_limit(item).max(1));
                state
                    .game_shop_dialog
                    .quantities
                    .insert(item.game_shop_index, quantity);
            }
        }
        if keys.just_pressed(KeyCode::BracketLeft) || keys.just_pressed(KeyCode::Minus) {
            game_shop.quantity_dec();
            if let Some(item) = game_shop.selected() {
                let quantity = game_shop
                    .quantity
                    .min(game_shop_dialog::quantity_limit(item).max(1));
                state
                    .game_shop_dialog
                    .quantities
                    .insert(item.game_shop_index, quantity);
            }
        }
    } else if state.npc_shop_open() {
        if keys.just_pressed(KeyCode::BracketRight) || keys.just_pressed(KeyCode::Equal) {
            state.shop_quantity_inc();
        }
        if keys.just_pressed(KeyCode::BracketLeft) || keys.just_pressed(KeyCode::Minus) {
            state.shop_quantity_dec();
        }
    }
}

fn process_overlay_buttons(
    mut state: ResMut<NativePlayerUiState>,
    mut effects: Option<ResMut<UiEffectQueue>>,
    mut intents: ResMut<NativePlayerUiIntentQueue>,
    mut shell_intents: ResMut<NativeUiIntentQueue>,
    mut shell: ResMut<NativeShellModel>,
    inventory: Res<InventoryModel>,
    mut mail: ResMut<MailModel>,
    mut compose_ui: ResMut<MailComposeUi>,
    mut shop: ResMut<ShopModel>,
    game_shop: Option<ResMut<GameShopModel>>,
    mut storage: ResMut<StorageModel>,
    mut social: ResMut<crate::social::SocialModel>,
    ui: Option<Res<UiReadModel>>,
    combat_target: Option<Res<crate::quest_model::CombatTargetModel>>,
    mut pending: ResMut<PendingOperations>,
    button_controls: OverlayButtonControls,
) {
    if shell.screen != NativeShellScreen::InGame {
        return;
    }
    let OverlayButtonControls {
        big_map:
            BigMapControls {
                model: mut big_map,
                intents: mut big_map_intents,
                ui: mut big_map_ui,
                time,
                skill_binding: mut skill_binding,
                skills: mut skills,
                skill_persistence: mut skill_persistence,
            },
        mut mail_ui,
        mut parcel_ui,
        mut storage_ui,
        mut shop_ui,
        mut ui_audio,
        buttons,
    } = button_controls;
    let mut fallback_effects = UiEffectQueue::default();
    let mut effects = effects.as_deref_mut().unwrap_or(&mut fallback_effects);
    // Focused panel tests can exercise storage controls without mounting the
    // optional Parcel surface. Keep those controls independent from mail.
    let mut fallback_parcel_ui = mail_parcel::MailParcelUi::default();
    let mut parcel_ui = parcel_ui.as_deref_mut().unwrap_or(&mut fallback_parcel_ui);
    let mut game_shop = game_shop;
    if let Some(expected) = state.guild_notice_submission.clone() {
        let still_pending = social.pending.iter().any(|operation| {
            matches!(
                operation,
                crate::social::SocialPendingOperation::GuildNotice { notice }
                    if notice == &expected
            )
        });
        if !still_pending {
            let explicit_result = social.last_event.as_ref().and_then(|event| {
                matches!(
                    event.packet.as_str(),
                    "GuildNoticeChange" | "GuildNoticeResult"
                )
                .then_some(event.success)
                .flatten()
            });
            let succeeded = explicit_result == Some(true) || social.guild.notice == expected;
            state.guild_notice_submission = None;
            if succeeded {
                state.guild_notice_editing = false;
                state.guild_notice_draft.clear();
                // The edit receipt does not contain the replacement body.
                // Request the authoritative page rather than copying the
                // submitted draft into SocialModel.
                let _ = intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GuildRequestInfo { info_type: 0 },
                );
            } else {
                // An explicit failure keeps the exact draft editable so the
                // player can correct it and retry.
                state.guild_notice_editing = true;
            }
        }
    }
    let (gold, credit, player_class) = ui
        .as_deref()
        .map(|model| {
            (
                model.player.gold,
                model.player.credit,
                model.player.class_name.clone().unwrap_or_default(),
            )
        })
        .unwrap_or((0, 0, String::new()));
    let gold_modal_was_open = state.guild_gold_prompt.is_some();
    let trade_modal_was_open = state.trade_dialog.gold_prompt.is_some();
    let delete_modal_was_open = state.inventory_delete_prompt.is_some();
    let mail_delete_modal_was_open = state.mail_delete_prompt.is_some();
    let mail_recipient_modal_was_open = compose_ui.recipient_prompt.is_some();
    let mail_feedback_modal_was_open = state.mail_feedback_prompt.is_some();
    let mail_reader_was_open = state.mail_reader.is_some();
    let message_was_open = state.trade_dialog.message.is_some();
    let game_shop_modal_was_open = state.game_shop_dialog.confirmation.is_some();
    let storage_rental_modal_was_open = state.storage_rental_confirmation.is_some();
    let parcel_gold_modal_was_open = state.parcel_gold_prompt.is_some();
    for (interaction, button) in buttons.iter() {
        if state.hero.modal() {
            continue;
        }
        if state.skill_assign.open
            && !matches!(
                button,
                OverlayButton::AssignSkillKey(_)
                    | OverlayButton::ClearSkillBinding
                    | OverlayButton::CloseSkillAssign
            )
        {
            continue;
        }
        if *interaction != Interaction::Pressed {
            continue;
        }
        if state.storage_password_input_consumed
            || state.storage_rental_input_consumed
            || state.mail_delete_input_consumed
            || state.mail_feedback_input_consumed
            || state.mail_recipient_input_consumed
            || state.mail_reader_input_consumed
            || state.parcel_gold_input_consumed
        {
            continue;
        }
        if mail_recipient_modal_was_open || compose_ui.recipient_prompt.is_some() {
            if !matches!(button, OverlayButton::MailRecipientSubmit | OverlayButton::MailRecipientCancel) {
                continue;
            }
        } else if mail_feedback_modal_was_open || state.mail_feedback_prompt.is_some() {
            if !matches!(button, OverlayButton::MailFeedbackAcknowledge) {
                continue;
            }
        } else {
            if (mail_reader_was_open || state.mail_reader.is_some())
                && !matches!(
                    button,
                    OverlayButton::MailReaderClose
                        | OverlayButton::MailReaderDelete
                        | OverlayButton::MailReaderLock
                        | OverlayButton::MailReaderClaim
                )
            {
                continue;
            }
            if (mail_delete_modal_was_open || state.mail_delete_prompt.is_some())
                && !matches!(
                    button,
                    OverlayButton::MailDeleteConfirm | OverlayButton::MailDeleteCancel
                )
            {
                continue;
            }
        }
        if (storage_rental_modal_was_open || state.storage_rental_confirmation.is_some())
            && !matches!(
                button,
                OverlayButton::StorageRentalConfirm | OverlayButton::StorageRentalCancel
            )
        {
            continue;
        }
        if (parcel_gold_modal_was_open || state.parcel_gold_prompt.is_some())
            && !matches!(
                button,
                OverlayButton::MailParcelGoldConfirm | OverlayButton::MailParcelGoldCancel
            )
        {
            continue;
        }
        if state.storage_password_prompt.is_some()
            && !matches!(
                button,
                OverlayButton::StoragePasswordSubmit | OverlayButton::StoragePasswordCancel
            )
        {
            continue;
        }
        if (game_shop_modal_was_open || state.game_shop_dialog.confirmation.is_some())
            && !matches!(
                button,
                OverlayButton::GameShopControl(
                    game_shop_dialog::GameShopAction::Confirm
                        | game_shop_dialog::GameShopAction::Cancel
                )
            )
        {
            continue;
        }
        if state.leave_game.blocks() {
            if matches!(
                *button,
                OverlayButton::LeaveConfirm | OverlayButton::LeaveCancel
            ) {
                eprintln!(
                    "[native-exit] leave_answer source=pointer yes={} prompt={:?}",
                    matches!(*button, OverlayButton::LeaveConfirm),
                    state.leave_game.prompt
                );
            }
            match *button {
                OverlayButton::LeaveConfirm => leave_game_dialog::finish(
                    &mut state,
                    &mut shell,
                    &mut shell_intents,
                    Some(&mut effects),
                    true,
                ),
                OverlayButton::LeaveCancel => leave_game_dialog::finish(
                    &mut state,
                    &mut shell,
                    &mut shell_intents,
                    Some(&mut effects),
                    false,
                ),
                _ => {}
            }
            continue;
        }
        if state.social_bonds.prompt.is_some() {
            continue;
        }
        if state.group_dialog.modal() || state.group_dialog.consumed {
            match *button {
                OverlayButton::GroupInviteAccept | OverlayButton::GroupInviteDecline => {
                    group_dialog::answer_invitation(
                        &mut state,
                        &mut social,
                        &mut intents,
                        *button == OverlayButton::GroupInviteAccept,
                    )
                }

                OverlayButton::GroupInputConfirm => {
                    state.group_dialog.submit(&mut intents, &mut social)
                }
                OverlayButton::GroupInputCancel => {
                    state.group_dialog.editor.cancel_modal();
                    state.group_dialog.consumed = true;
                }
                _ => {}
            }
            continue;
        }
        if state.guild_panel.blocks() {
            if matches!(
                *button,
                OverlayButton::GuildInviteAccept | OverlayButton::GuildInviteDecline
            ) {
                guild_panel::answer_invite(
                    &mut state,
                    &mut social,
                    &mut intents,
                    *button == OverlayButton::GuildInviteAccept,
                );
            }
            if matches!(*button, OverlayButton::GuildKickConfirm) {
                guild_panel::confirm_kick(&mut state, &mut social, &mut intents);
            }
            if matches!(*button, OverlayButton::GuildMemberRankConfirm) {
                guild_panel::confirm_member_rank(&mut state, &mut social, &mut intents);
            }
            if matches!(*button, OverlayButton::GuildCreateRankConfirm) {
                guild_panel::confirm_create_rank(&mut state, &mut social, &mut intents);
            }
            if matches!(*button, OverlayButton::GuildBuffErrorClose) {
                state.guild_panel.close_error();
            }
            continue;
        }
        if state.trade_dialog.input_consumed {
            continue;
        }
        if message_was_open || state.trade_dialog.message.is_some() {
            match *button {
                OverlayButton::TradeAccept(revision) => {
                    trade_dialog::answer_message(&mut state, &social, &mut intents, revision, true);
                }
                OverlayButton::TradeDecline(revision)
                | OverlayButton::TradeMessageClose(revision) => {
                    trade_dialog::answer_message(
                        &mut state,
                        &social,
                        &mut intents,
                        revision,
                        false,
                    );
                }
                _ => {}
            }
            continue;
        }
        if (trade_modal_was_open || state.trade_dialog.gold_prompt.is_some())
            && !matches!(
                *button,
                OverlayButton::TradeGoldConfirm
                    | OverlayButton::TradeGoldCancel
                    | OverlayButton::TradeGoldClose
            )
        {
            continue;
        }
        if (gold_modal_was_open || state.guild_gold_prompt.is_some())
            && !matches!(
                *button,
                OverlayButton::GuildGoldConfirm
                    | OverlayButton::GuildGoldCancel
                    | OverlayButton::GuildGoldClose
            )
        {
            continue;
        }
        if (delete_modal_was_open || state.inventory_delete_prompt.is_some())
            && !matches!(
                *button,
                OverlayButton::InventoryDeleteConfirm
                    | OverlayButton::InventoryDeleteCancel
                    | OverlayButton::InventoryDeleteAmountClose
            )
        {
            // MirAmountBox/MirMessageBox is modal; never let a covered control
            // mutate another window in the same frame.
            continue;
        }
        if (state.group_dialog.modal() || state.group_dialog.consumed)
            && !matches!(
                *button,
                OverlayButton::GroupInputConfirm | OverlayButton::GroupInputCancel
            )
        {
            continue;
        }
        if state.leave_game.blocks()
            && !matches!(
                *button,
                OverlayButton::LeaveConfirm | OverlayButton::LeaveCancel
            )
        {
            continue;
        }
        if (state.menu_pointer_consumed
            || equipment_creature_host::modal(&state)
            || state.friends.modal.is_some())
            && !matches!(
                *button,
                OverlayButton::LeaveConfirm | OverlayButton::LeaveCancel
            )
        {
            continue;
        }
        match *button {
            OverlayButton::CastSkillBar(slot) => {
                if state.core.options.skill_bar
                    && skills
                        .as_deref()
                        .is_some_and(|skills| skills.skill_for_shortcut(slot).is_some())
                {
                    state.skill_bars.armed_slot = Some(slot);
                }
            }
            OverlayButton::RefreshSkillBar => {}

            OverlayButton::ExitApplication => {
                eprintln!("[native-exit] leave_request source=menu_exit");
                state.leave_game.request(
                    leave_game_dialog::LeaveKind::Exit,
                    std::time::Instant::now(),
                );
            }
            OverlayButton::LeaveConfirm | OverlayButton::LeaveCancel => leave_game_dialog::finish(
                &mut state,
                &mut shell,
                &mut shell_intents,
                Some(&mut effects),
                matches!(*button, OverlayButton::LeaveConfirm),
            ),
            OverlayButton::CloseWindows | OverlayButton::CloseCharacter => {
                if matches!(*button, OverlayButton::CloseCharacter) {
                    // Crystal CharacterDialog.CloseButton uses ButtonA. Keep
                    // the source-audited cue local to this control rather than
                    // assigning sound to every generic CloseWindows caller.
                    ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                }
                if matches!(*button, OverlayButton::CloseCharacter)
                    && state.storage_open()
                    && state.storage_equipment_visible
                {
                    state.storage_equipment_visible = false;
                    state.equipment_item_drag = None;
                    state.inspect = None;
                    continue;
                }
                equipment_creature_host::close_general(
                    &mut state,
                    &mut intents,
                    time.as_ref().map_or(0, |t| t.elapsed().as_millis() as u64),
                );
                state.close_windows();
                state.shop_quantity = 1;
                if let Some(skill_binding) = skill_binding.as_deref_mut() {
                    skill_binding.clear_selection();
                    skill_binding.set_assign_key(false);
                }
            }
            OverlayButton::ToggleHelp => {
                state.help.toggle();
            }
            OverlayButton::ToggleKeyboard => {
                if state.keyboard.open {
                    state.keyboard.hide();
                } else {
                    state.keyboard.show();
                }
            }
            OverlayButton::ToggleMentor => {
                social_bond_dialog::host::toggle(&mut state, social_bond_dialog::BondPage::Mentor)
            }
            OverlayButton::ToggleRelationship => social_bond_dialog::host::toggle(
                &mut state,
                social_bond_dialog::BondPage::Relationship,
            ),
            OverlayButton::ToggleFriends => {
                friend_dialog::host::toggle(&mut state, &mut intents);
            }
            OverlayButton::ToggleMount
            | OverlayButton::ToggleFishing
            | OverlayButton::ToggleCreature => {
                let page = match button {
                    OverlayButton::ToggleMount => 0,
                    OverlayButton::ToggleFishing => 1,
                    _ => 2,
                };
                equipment_creature_host::toggle(
                    &mut state,
                    &mut intents,
                    page,
                    time.as_ref().map_or(0, |t| t.elapsed().as_millis() as u64),
                );
            }
            OverlayButton::ToggleRanking => {
                if state.ranking.open {
                    state.ranking.hide();
                } else {
                    state.ranking.show(
                        time.as_ref()
                            .map(|time| time.elapsed().as_millis() as u64)
                            .unwrap_or(0),
                    );
                }
            }
            OverlayButton::CloseHelp => {
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                state.help.hide();
            }
            OverlayButton::HelpPrevious => {
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                state.help.previous_page();
            }
            OverlayButton::HelpNext => {
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                state.help.next_page();
            }
            OverlayButton::CloseInspect => {
                state.inspect = None;
                state.inventory_operation = None;
                state.drop_confirmation = None;
            }
            OverlayButton::CloseMail => {
                if state.mail_open() {
                    state.core.panel = mir2_ui_core::state::UiPanel::None;
                }
                state.mail_delete_prompt = None;
                state.mail_delete_input_consumed = false;
            }
            OverlayButton::CloseBigMap => {
                if state.bigmap_open() {
                    state.core.panel = mir2_ui_core::state::UiPanel::None;
                }
                if let Some(big_map_ui) = big_map_ui.as_deref_mut() {
                    big_map_ui.search_focused = false;
                }
            }
            OverlayButton::CloseShop => {
                state.npc_service_exit_latched = true;
                if state.npc_shop_open() {
                    state.core.panel = mir2_ui_core::state::UiPanel::None;
                }
                state.shop_quantity = 1;
                state.shop_service_drag_count = None;
                state.shop_service_drag_unique_id = None;
                state.npc_inventory_hidden = false;
                state.npc_service_hold = None;
                state.npc_shop_buy_tab = true;
                state.shop_repair_container = 0;
                state.shop_repair_slot = None;
                let _ = shop.apply_service_signal(NpcShopServiceSignal::default());
            }
            OverlayButton::CloseGameShop => {
                if state.shop_open() {
                    state.core.panel = mir2_ui_core::state::UiPanel::None;
                }
            }
            OverlayButton::CloseStorage => {
                if state.storage_open() {
                    state.core.panel = mir2_ui_core::state::UiPanel::None;
                }
                state.storage_password_prompt = None;
                state.storage_rental_confirmation = None;
                state.storage_equipment_visible = false;
                state.equipment_item_drag = None;
                clear_legacy_storage_password_drafts(&mut storage);
                storage_ui.bag_selection = None;
                storage_ui.storage_selection = None;
            }
            OverlayButton::CloseOptions => {
                if state.options_open() {
                    dispatch_ui_action(
                        &mut state.core,
                        &mut effects,
                        mir2_ui_core::action::UiAction::ClosePanel,
                    );
                }
            }
            OverlayButton::SetCrystalOption(option, enabled) => {
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::SetCrystalOption { option, enabled },
                );
            }
            OverlayButton::OptionsObserve(allow) => {
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::RequestObserve { allow },
                );
                if effects.drain_observe_bounded(1) == 1 {
                    let _ = intents.push_transient_unique(NativePlayerUiIntent::Chat {
                        message: "@ALLOWOBSERVE".to_owned(),
                    });
                }
            }
            OverlayButton::OptionsMusicVolumeDown => {
                let value = state.core.options.music_volume.saturating_sub(10);
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::SetMusicVolume { volume: value },
                );
            }
            OverlayButton::OptionsMusicVolumeUp => {
                let value = state.core.options.music_volume.saturating_add(10).min(100);
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::SetMusicVolume { volume: value },
                );
            }
            OverlayButton::OptionsSoundVolumeDown => {
                let value = state.core.options.sound_volume.saturating_sub(10);
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::SetSoundVolume { volume: value },
                );
            }
            OverlayButton::OptionsSoundVolumeUp => {
                let value = state.core.options.sound_volume.saturating_add(10).min(100);
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::SetSoundVolume { volume: value },
                );
            }
            OverlayButton::ToggleInventory => {
                state.toggle_inventory();
                if !state.inventory_open() {
                    state.inspect = None;
                }
            }
            OverlayButton::ToggleEquipment => state.toggle_equipment(),
            OverlayButton::ToggleShop => {
                state.toggle_shop();
                if !state.shop_open() {
                    state.shop_quantity = 1;
                }
            }
            OverlayButton::ToggleNpcShop => {
                state.toggle_npc_shop();
            }
            OverlayButton::ToggleStorage => {
                state.toggle_storage();
                if state.storage_open() && storage.size == 0 {
                    storage.size = STORAGE_BASE_SIZE;
                }
            }
            OverlayButton::ToggleGroup => state.toggle_group(),
            OverlayButton::ToggleGuild => state.toggle_guild(),
            OverlayButton::ToggleTrade => state.toggle_trade(),
            OverlayButton::CloseSocial => {
                if state.group_open() || state.guild_open() || state.trade_open() {
                    state.core.panel = mir2_ui_core::state::UiPanel::None;
                }
                if state.guild_notice_submission.is_none() {
                    state.guild_notice_editing = false;
                    state.guild_notice_draft.clear();
                }
                state.group_invite_focused = false;
                state.group_invite_draft.clear();
                state.guild_recruit_focused = false;
                state.guild_recruit_draft.clear();
                state.guild_gold_prompt = None;
                state.guild_storage.end_drag();
                state.selected_guild_rank = None;
                state.guild_rank_name_focused = false;
                state.guild_rank_name_draft.clear();
            }
            OverlayButton::GroupInviteAccept => {
                intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GroupInvite {
                        accept_invite: true,
                    },
                );
            }
            OverlayButton::GroupInviteDecline => {
                intents.push_transient_unique(NativePlayerUiIntent::GroupInvite {
                    accept_invite: false,
                });
            }
            OverlayButton::GroupSwitch => {
                let allow_group = !social.group.allow_invites;
                intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GroupSwitch { allow_group },
                );
            }
            OverlayButton::GroupLeave => {
                if social.group.active {
                    intents.push_social_pending(
                        &mut social,
                        NativePlayerUiIntent::GroupSwitch { allow_group: false },
                    );
                }
            }
            OverlayButton::GroupAddSelected | OverlayButton::GroupRemoveSelected => {
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                let owner = ui
                    .as_ref()
                    .and_then(|u| u.player.name.as_deref())
                    .unwrap_or("");
                state.group_dialog.show_input(
                    matches!(*button, OverlayButton::GroupRemoveSelected),
                    &social.group,
                    owner,
                );
            }
            OverlayButton::GroupInputConfirm => {
                state.group_dialog.submit(&mut intents, &mut social)
            }
            OverlayButton::GroupInputCancel => {
                state.group_dialog.editor.cancel_modal();
                state.group_dialog.consumed = true;
            }
            OverlayButton::GroupInviteNameFocus => {
                state.group_invite_focused = true;
            }
            OverlayButton::GroupInviteNameSubmit => {
                let name = state.group_invite_draft.trim().to_owned();
                if valid_social_name(&name)
                    && queue_group_invite_by_name(&mut intents, &mut social, name)
                {
                    state.group_invite_focused = false;
                    state.group_invite_draft.clear();
                }
            }
            OverlayButton::SelectGroupMember(index) => {
                state.selected_group_member = Some(index);
            }
            OverlayButton::SelectGuildRightBuff(buff) => {
                state.guild_panel.right_buff = buff;
                if buff {
                    state.guild_recruit_focused = false;
                    state.guild_panel.recruit_editor.editor_focused = false;
                }
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
            }
            OverlayButton::GuildBuffActivate(row) => state.guild_panel.activate(
                row,
                &social.guild,
                time.as_ref().map_or(0, |t| t.elapsed().as_millis() as u64),
                &mut intents,
            ),
            OverlayButton::GuildBuffScroll(rows) => {
                state.guild_panel.buffs.scroll(rows);
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
            }
            OverlayButton::GuildBuffThumb => {}
            OverlayButton::GuildNoticeScroll(delta) => {
                let count = if state.guild_notice_editing {
                    state.guild_notice_draft.lines().count()
                } else {
                    social.guild.notice.len()
                };
                state.guild_panel.notice_scroll = (state.guild_panel.notice_scroll as i32 + delta)
                    .clamp(0, count.saturating_sub(25) as i32)
                    as usize;
                state.guild_panel.notice_editor.text_scroll[1] =
                    state.guild_panel.notice_scroll as f32 * 13.;
            }
            OverlayButton::GuildShowOffline => {
                state.guild_panel.hide_offline = !state.guild_panel.hide_offline;
                state.guild_panel.member_scroll = 0;
            }
            OverlayButton::GuildMembersScroll(delta) => {
                let count = social
                    .guild
                    .members
                    .iter()
                    .filter(|m| !state.guild_panel.hide_offline || m.online)
                    .count();
                state.guild_panel.member_scroll = (state.guild_panel.member_scroll as i32 + delta)
                    .clamp(0, count.saturating_sub(18) as i32)
                    as usize;
                state.guild_panel.member_menu = None;
            }
            OverlayButton::GuildMemberRankMenu(index) => {
                state.guild_panel.member_menu = Some(index);
                state.guild_panel.rank_scroll = 0;
            }
            OverlayButton::GuildMemberRankConfirm => {
                guild_panel::confirm_member_rank(&mut state, &mut social, &mut intents)
            }
            OverlayButton::GuildMemberRankSelect(index) => {
                if let Some(member) = state
                    .guild_panel
                    .member_menu
                    .and_then(|m| social.guild.members.get(m as usize))
                {
                    if let Some(rank) = social
                        .guild
                        .ranks
                        .iter()
                        .find(|r| r.index == i32::from(index))
                    {
                        if rank.index >= social.guild.my_rank_id
                            && social_has_permission(&social.guild, "changeRank")
                            && state.guild_panel.now_ms >= state.guild_panel.create_ready_ms
                        {
                            state.guild_panel.member_change =
                                Some((member.name.clone(), index, rank.name.clone()));
                        }
                    }
                }
                state.guild_panel.member_menu = None;
            }
            OverlayButton::GuildCreateRank => {
                state.guild_panel.rank_dropdown = false;
                if social.guild.ranks.len() < 255
                    && social_has_permission(&social.guild, "changeRank")
                    && state.guild_panel.now_ms >= state.guild_panel.create_ready_ms
                {
                    state.guild_panel.create_rank = true;
                }
            }
            OverlayButton::GuildCreateRankConfirm => {
                guild_panel::confirm_create_rank(&mut state, &mut social, &mut intents)
            }
            OverlayButton::GuildRankDropdown => {
                state.guild_panel.rank_dropdown = !state.guild_panel.rank_dropdown
            }
            OverlayButton::GuildRankScroll(delta) => {
                state.guild_panel.rank_scroll = (state.guild_panel.rank_scroll as i32 + delta)
                    .clamp(
                        0,
                        social.guild.ranks.len().saturating_add(1).saturating_sub(5) as i32,
                    ) as usize;
            }
            OverlayButton::GuildBuffErrorClose => state.guild_panel.close_error(),
            OverlayButton::GuildRequestInfo => {
                intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GuildRequestInfo { info_type: 0 },
                );
            }
            OverlayButton::SelectGuildLeftPage(page) => {
                if (page == GuildLeftPage::Storage && social.guild.my_options & 0x18 == 0)
                    || (page == GuildLeftPage::Ranks && social.guild.my_options & 0x01 == 0)
                {
                    continue;
                }
                state.guild_left_page = page;
                state.selected_guild_member = None;
                state.guild_recruit_focused = false;
                state.guild_gold_prompt = None;
                state.guild_storage.end_drag();
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                if page != GuildLeftPage::Ranks {
                    state.selected_guild_rank = None;
                    state.guild_rank_name_draft.clear();
                    state.guild_rank_name_focused = false;
                }
                if page != GuildLeftPage::Notice && state.guild_notice_submission.is_none() {
                    state.guild_notice_editing = false;
                    state.guild_notice_draft.clear();
                }
                if matches!(
                    page,
                    GuildLeftPage::Notice | GuildLeftPage::Members | GuildLeftPage::Ranks
                ) {
                    let info_type = if page == GuildLeftPage::Notice { 0 } else { 1 };
                    intents.push_social_pending(
                        &mut social,
                        NativePlayerUiIntent::GuildRequestInfo { info_type },
                    );
                } else if page == GuildLeftPage::Storage {
                    intents.push_transient_unique(NativePlayerUiIntent::GuildStorageItemChange {
                        change_type: 3,
                        from: 0,
                        to: 0,
                    });
                }
            }
            OverlayButton::GuildInviteAccept => {
                intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GuildInvite {
                        accept_invite: true,
                    },
                );
            }
            OverlayButton::GuildInviteDecline => {
                intents.push_transient_unique(NativePlayerUiIntent::GuildInvite {
                    accept_invite: false,
                });
            }
            OverlayButton::GuildRecruitNameFocus => {
                if social_has_permission(&social.guild, "recruit") {
                    state.guild_recruit_focused = true;
                }
            }
            OverlayButton::GuildRecruitNameSubmit => {
                let name = state.guild_recruit_draft.trim().to_owned();
                if valid_social_name(&name)
                    && social_has_permission(&social.guild, "recruit")
                    && intents.push_social_pending(
                        &mut social,
                        NativePlayerUiIntent::GuildEditMember {
                            change_type: 0,
                            rank_index: 0,
                            name,
                            rank_name: String::new(),
                        },
                    )
                {
                    state.guild_recruit_focused = false;
                    state.guild_recruit_draft.clear();
                }
            }
            OverlayButton::GuildBeginNoticeEdit => {
                let can_edit =
                    social.guild.name.is_some() && social_has_permission(&social.guild, "notice");
                if can_edit && state.guild_notice_submission.is_none() {
                    state.guild_notice_draft = social.guild.notice.join("\n");
                    state.guild_notice_editing = true;
                }
            }
            OverlayButton::GuildPublishNotice => {
                let can_edit =
                    social.guild.name.is_some() && social_has_permission(&social.guild, "notice");
                let notice = guild_notice_lines(&state.guild_notice_draft);
                if can_edit
                    && state.guild_notice_editing
                    && state.guild_notice_submission.is_none()
                    && intents.push_social_pending(
                        &mut social,
                        NativePlayerUiIntent::GuildEditNotice {
                            notice: notice.clone(),
                        },
                    )
                {
                    state.guild_panel.notice_editor.editor_focused = false;
                    state.guild_notice_submission = Some(notice);
                }
            }
            OverlayButton::GuildCancelNoticeEdit => {
                if state.guild_notice_submission.is_none() {
                    state.guild_notice_editing = false;
                    state.guild_notice_draft.clear();
                }
            }
            OverlayButton::SelectGuildMember(index) => {
                state.selected_guild_member = Some(index);
            }
            OverlayButton::GuildKickMember(index) => {
                if let Some(member) = social.guild.members.get(usize::from(index)) {
                    if social_has_permission(&social.guild, "kick")
                        && member.name != state.guild_panel.owner_name
                        && member
                            .rank_index
                            .is_some_and(|r| i32::from(r) >= social.guild.my_rank_id)
                        && state.guild_panel.now_ms >= state.guild_panel.create_ready_ms
                    {
                        state.guild_panel.kick_member = Some(member.name.clone());
                    }
                }
            }
            OverlayButton::GuildKickConfirm => {
                guild_panel::confirm_kick(&mut state, &mut social, &mut intents)
            }
            OverlayButton::GuildKickSelected => {
                let Some(index) = state.selected_guild_member else {
                    continue;
                };
                let Some(member) = social.guild.members.get(usize::from(index)) else {
                    continue;
                };
                if member.name.trim().is_empty() || !social_has_permission(&social.guild, "kick") {
                    continue;
                }
                let name = member.name.clone();
                let rank_index = member.rank_index.unwrap_or(0);
                intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GuildEditMember {
                        change_type: 1,
                        rank_index,
                        name,
                        rank_name: String::new(),
                    },
                );
            }
            OverlayButton::GuildAssignPreviousRank | OverlayButton::GuildAssignNextRank => {
                let Some(index) = state.selected_guild_member else {
                    continue;
                };
                let Some(member) = social.guild.members.get(usize::from(index)) else {
                    continue;
                };
                if !social_has_permission(&social.guild, "changeRank") {
                    continue;
                }
                let mut ranks = social
                    .guild
                    .ranks
                    .iter()
                    .filter_map(|rank| u8::try_from(rank.index).ok())
                    .collect::<Vec<_>>();
                ranks.sort_unstable();
                ranks.dedup();
                if ranks.is_empty() {
                    continue;
                }
                let current = member.rank_index.unwrap_or(ranks[0]);
                let current_position = ranks.iter().position(|rank| *rank == current).unwrap_or(0);
                let next_position = if *button == OverlayButton::GuildAssignPreviousRank {
                    current_position.checked_sub(1).unwrap_or(ranks.len() - 1)
                } else {
                    (current_position + 1) % ranks.len()
                };
                let name = member.name.clone();
                intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GuildEditMember {
                        change_type: 4,
                        rank_index: ranks[next_position],
                        name,
                        rank_name: String::new(),
                    },
                );
            }
            OverlayButton::GuildGoldDeposit | OverlayButton::GuildGoldWithdraw => {
                // MirButton defaults to ButtonB, including a click rejected
                // by StorageAddGold/StorageRemoveGold's send cooldown.
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                let action = if *button == OverlayButton::GuildGoldDeposit {
                    GuildGoldAction::Deposit
                } else {
                    GuildGoldAction::Withdraw
                };
                open_guild_gold_prompt(
                    &mut state,
                    &social.guild,
                    gold,
                    action,
                    time.as_deref()
                        .map(|time| time.elapsed().as_millis() as u64)
                        .unwrap_or(0),
                );
            }
            OverlayButton::GuildGoldConfirm => {
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                confirm_guild_gold(
                    &mut state,
                    &mut social,
                    gold,
                    time.as_deref()
                        .map(|time| time.elapsed().as_millis() as u64)
                        .unwrap_or(0),
                    &mut intents,
                );
            }
            OverlayButton::GuildGoldCancel | OverlayButton::GuildGoldClose => {
                state.guild_gold_prompt = None;
                ui_audio.push(if *button == OverlayButton::GuildGoldClose {
                    crate::audio::NativeUiSound::ButtonA
                } else {
                    crate::audio::NativeUiSound::ButtonB
                });
            }
            OverlayButton::GuildStoragePreviousRow | OverlayButton::GuildStorageNextRow => {
                if !state.guild_open() || state.guild_left_page != GuildLeftPage::Storage {
                    continue;
                }
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                if *button == OverlayButton::GuildStoragePreviousRow {
                    state.guild_storage.previous_row();
                } else {
                    state.guild_storage.next_row();
                }
            }
            OverlayButton::SelectGuildRank(rank_index) => {
                let Some(rank) = social
                    .guild
                    .ranks
                    .iter()
                    .find(|rank| u8::try_from(rank.index).ok() == Some(rank_index))
                else {
                    continue;
                };
                state.guild_panel.rank_dropdown = false;
                state.guild_panel.rank_name_ready_ms = 0;
                state.selected_guild_rank = Some(rank_index);
                state.guild_rank_name_draft = rank.name.clone();
                state.guild_rank_name_focused = false;
            }
            OverlayButton::GuildRankNameFocus => {
                if state.selected_guild_rank.is_some()
                    && social_has_permission(&social.guild, "changeRank")
                {
                    state.guild_rank_name_focused = true;
                }
            }
            OverlayButton::GuildRankNameSave => {
                guild_panel::save_rank_name(&mut state, &mut social, &mut intents)
            }
            OverlayButton::GuildRankTogglePermission(option) => {
                let Some(rank_index) = state.selected_guild_rank else {
                    continue;
                };
                let Some(rank) = social
                    .guild
                    .ranks
                    .iter()
                    .find(|rank| u8::try_from(rank.index).ok() == Some(rank_index))
                else {
                    continue;
                };
                if option > 7
                    || i32::from(rank_index) < social.guild.my_rank_id
                    || !social_has_permission(&social.guild, "changeRank")
                {
                    continue;
                }
                if state.guild_panel.now_ms < state.guild_panel.rank_option_ready_ms {
                    continue;
                }
                state.guild_panel.rank_option_ready_ms = state.guild_panel.now_ms + 300;
                let enabled = rank.options & (1_u8 << option) != 0;
                intents.push_social_pending(
                    &mut social,
                    NativePlayerUiIntent::GuildEditMember {
                        change_type: 5,
                        rank_index,
                        name: (!enabled).to_string(),
                        rank_name: option.to_string(),
                    },
                );
            }
            OverlayButton::TradeRequest => {
                // The inviter receives no request acknowledgement; refusal can
                // be only a chat line. Never leave an unresolvable pending key.
                intents.push_transient_unique(NativePlayerUiIntent::TradeRequest);
            }
            OverlayButton::TradeAccept(_)
            | OverlayButton::TradeDecline(_)
            | OverlayButton::TradeMessageClose(_) => {}
            OverlayButton::TradeGoldOffer => {
                if !pending.is_empty() {
                    continue;
                }
                trade_dialog::open_gold(&mut state, &social, gold);
            }
            OverlayButton::TradeGoldConfirm => {
                trade_dialog::confirm_gold(&mut state, &mut social, gold, &mut intents);
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
            }
            OverlayButton::TradeGoldCancel | OverlayButton::TradeGoldClose => {
                state.trade_dialog.gold_prompt = None;
                ui_audio.push(if *button == OverlayButton::TradeGoldClose {
                    crate::audio::NativeUiSound::ButtonA
                } else {
                    crate::audio::NativeUiSound::ButtonB
                });
            }
            OverlayButton::TradeConfirm => {
                if !pending.is_empty() {
                    continue;
                }
                if trade_dialog::toggle_lock(&mut state, &social, &mut intents) {
                    ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                }
            }
            OverlayButton::TradeCancel => {
                if trade_dialog::cancel(&mut state, &mut social, &mut intents) {
                    ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                }
            }
            OverlayButton::Logout => {
                state.leave_game.request(
                    leave_game_dialog::LeaveKind::Logout,
                    std::time::Instant::now(),
                );
            }
            OverlayButton::UseInspected => {
                if !inspected_bag_item_is_mail_locked(&state, &inventory, parcel_ui) {
                    if let Some(intent) = inspected_use_intent(&state, &inventory) {
                        intents.push_intent(intent);
                    }
                }
            }
            OverlayButton::EquipInspected => {
                if !inspected_bag_item_is_mail_locked(&state, &inventory, parcel_ui) {
                    if let Some(intent) = inspected_equip_intent(&state, &inventory) {
                        if intents.push_intent(intent) {
                            // Crystal disposes the item action menu as soon as the
                            // equip request is accepted. Keeping this selection
                            // alive renders the pre-swap bag item after the server
                            // moves it into the equipment grid.
                            state.inspect = None;
                        }
                    }
                }
            }
            OverlayButton::UnequipInspected => {
                if let Some(intent) = inspected_remove_intent(&state, &inventory) {
                    intents.push_intent(intent);
                }
            }
            OverlayButton::InventoryDeleteToggle => {
                if let Some(slot) =
                    inspected_inventory_item(&state, &inventory).map(|item| item.slot)
                {
                    if bag_slot_is_mail_locked(parcel_ui, &inventory, slot) {
                        continue;
                    }
                    // DelItemButton itself owns ButtonA even when an existing
                    // selected cell opens the prompt without toggling mode.
                    ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                    let _ = state.open_inventory_delete_for_slot(&inventory, slot);
                } else {
                    state.inventory_delete_mode = !state.inventory_delete_mode;
                    state.inventory_delete_prompt = None;
                    ui_audio.push(if state.inventory_delete_mode {
                        crate::audio::NativeUiSound::ButtonA
                    } else {
                        crate::audio::NativeUiSound::ButtonB
                    });
                }
            }
            OverlayButton::InventoryDeleteConfirm => {
                if confirm_inventory_delete(
                    &mut state,
                    &inventory,
                    parcel_ui,
                    &mut intents,
                    &mut pending,
                ) {
                    ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                }
            }
            OverlayButton::InventoryDeleteCancel => {
                state.cancel_inventory_delete();
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
            }
            OverlayButton::InventoryDeleteAmountClose => {
                if matches!(
                    state.inventory_delete_prompt,
                    Some(InventoryDeletePrompt::Amount { .. })
                ) {
                    // MirAmountBox.CloseButton disposes only the box. Unlike
                    // its Cancel button it does not call InventoryDialog's
                    // CancelDelete callback, so delete mode remains active.
                    state.inventory_delete_prompt = None;
                    state.inspect = None;
                    ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                }
            }
            OverlayButton::MailDeleteConfirm => {
                state.mail_delete_input_consumed = true;
                if confirm_mail_delete(&mut state, &mut mail, &mut intents, &mut pending) {
                    ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                }
            }
            OverlayButton::MailDeleteCancel => {
                state.mail_delete_prompt = None;
                state.mail_delete_input_consumed = true;
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
            }
            OverlayButton::MailFeedbackAcknowledge => {
                if state.mail_feedback_prompt.take().is_some() {
                    compose_ui.last_notice = None;
                    state.mail_feedback_input_consumed = true;
                    ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                }
            }
            OverlayButton::DropInspected => {
                if !inspected_bag_item_is_mail_locked(&state, &inventory, parcel_ui) {
                    state.drop_confirmation = inspected_drop_confirmation(&state, &inventory);
                }
            }
            OverlayButton::ConfirmDropInspected => {
                let Some(confirmation) = state.drop_confirmation.take() else {
                    continue;
                };
                if parcel_ui.blocks_item(confirmation.unique_id)
                    || !drop_confirmation_is_current(&confirmation, &inventory)
                {
                    continue;
                }
                intents.push_pending_intent(
                    &mut pending,
                    NativePlayerUiIntent::DropItem {
                        key: confirmation.key,
                        unique_id: confirmation.unique_id,
                        count: confirmation.count,
                        hero_inventory: false,
                    },
                );
            }
            OverlayButton::CancelDropInspected => {
                state.drop_confirmation = None;
            }
            OverlayButton::SplitInspected => {
                if !inspected_bag_item_is_mail_locked(&state, &inventory, parcel_ui) {
                    if let Some(item) = inspected_inventory_item(&state, &inventory) {
                        if let Some(unique_id) = item_unique_id(item) {
                            let max = item.quantity.saturating_sub(1).min(u32::from(u16::MAX)) as u16;
                            let count = state.split_count.clamp(1, max.max(1));
                            if max > 0 {
                                intents.push_pending_intent(
                                    &mut pending,
                                    NativePlayerUiIntent::SplitItem {
                                        unique_id,
                                        grid: "inventory".to_owned(),
                                        count,
                                    },
                                );
                            }
                        }
                    }
                }
            }
            OverlayButton::SplitCountDec => {
                state.split_count = state.split_count.saturating_sub(1).max(1);
            }
            OverlayButton::SplitCountInc => {
                if !inspected_bag_item_is_mail_locked(&state, &inventory, parcel_ui) {
                    if let Some(item) = inspected_inventory_item(&state, &inventory) {
                        let max = item.quantity.saturating_sub(1).min(u32::from(u16::MAX)) as u16;
                        state.split_count = state.split_count.saturating_add(1).min(max.max(1));
                    }
                }
            }
            OverlayButton::ArmMoveInspected => {
                if !inspected_bag_item_is_mail_locked(&state, &inventory, parcel_ui) {
                    if let Some(item) = inspected_inventory_item(&state, &inventory) {
                        if let Some(unique_id) = item_unique_id(item) {
                            state.inventory_operation = Some(InventoryOperationDraft::Move {
                                source_slot: item.slot,
                                unique_id,
                            });
                        }
                    }
                }
            }
            OverlayButton::ArmMergeInspected => {
                if !inspected_bag_item_is_mail_locked(&state, &inventory, parcel_ui) {
                    if let Some(item) = inspected_inventory_item(&state, &inventory) {
                        if let Some(unique_id) = item_unique_id(item) {
                            state.inventory_operation = Some(InventoryOperationDraft::Merge {
                                source_slot: item.slot,
                                unique_id,
                            });
                        }
                    }
                }
            }
            OverlayButton::CancelInventoryOperation => {
                state.inventory_operation = None;
            }
            OverlayButton::InspectBag(_) if state.trade_dialog.open => {}
            OverlayButton::InspectBag(_) if state.inventory_item_drag.is_some()
                || state.inventory_item_pointer_consumed => {}
            OverlayButton::InspectBag(slot) if bag_slot_is_mail_locked(parcel_ui, &inventory, slot) => {}
            OverlayButton::InspectBag(slot) if state.inventory_delete_mode => {
                let _ = state.open_inventory_delete_for_slot(&inventory, slot);
            }
            OverlayButton::InspectBag(slot) => match state.inventory_operation.clone() {
                Some(InventoryOperationDraft::Move {
                    source_slot,
                    unique_id,
                }) if source_slot != slot => {
                    if parcel_ui.blocks_item(unique_id)
                        || bag_slot_is_mail_locked(parcel_ui, &inventory, slot)
                    {
                        state.inventory_operation = None;
                        continue;
                    }
                    if intents.push_pending_intent(
                        &mut pending,
                        NativePlayerUiIntent::MoveItem {
                            grid: "inventory".to_owned(),
                            unique_id,
                            from: source_slot as i32,
                            to: slot as i32,
                        },
                    ) {
                        state.inventory_operation = None;
                        state.inspect = inventory
                            .items_in(0)
                            .into_iter()
                            .find(|item| item.slot == slot)
                            .map(inspect_from_item);
                    }
                }
                Some(InventoryOperationDraft::Merge {
                    source_slot,
                    unique_id: id_from,
                }) if source_slot != slot => {
                    if parcel_ui.blocks_item(id_from)
                        || bag_slot_is_mail_locked(parcel_ui, &inventory, slot)
                    {
                        state.inventory_operation = None;
                        continue;
                    }
                    let target = inventory
                        .items_in(0)
                        .into_iter()
                        .find(|item| item.slot == slot);
                    if let Some(id_to) = target.and_then(item_unique_id) {
                        if id_from != id_to
                            && intents.push_pending_intent(
                                &mut pending,
                                NativePlayerUiIntent::MergeItem {
                                    grid_from: "inventory".to_owned(),
                                    grid_to: "inventory".to_owned(),
                                    id_from,
                                    id_to,
                                },
                            )
                        {
                            state.inventory_operation = None;
                            state.inspect = target.map(inspect_from_item);
                        }
                    }
                }
                Some(_) => {}
                None => {
                    state.inspect = inventory
                        .items_in(0)
                        .into_iter()
                        .find(|item| item.slot == slot)
                        .map(inspect_from_item);
                    state.split_count = 1;
                    state.drop_confirmation = None;
                }
            },
            OverlayButton::InspectQuest(slot) => {
                if state.inventory_delete_mode {
                    // Crystal consumes the click while delete mode is active,
                    // but QuestInventory cells can never be deleted.
                    continue;
                }
                state.inspect = inventory
                    .items_in(3)
                    .into_iter()
                    .find(|item| item.slot == slot)
                    .map(inspect_from_item);
                state.split_count = 1;
                state.inventory_operation = None;
                state.drop_confirmation = None;
            }
            OverlayButton::InspectEquip(slot) => {
                state.inspect = inventory
                    .items_in(2)
                    .into_iter()
                    .find(|item| item.slot == slot)
                    .map(inspect_from_item);
                state.drop_confirmation = None;
            }
            OverlayButton::SelectSkill(skill_id) => {
                if let (Some(skill_binding), Some(skills)) =
                    (skill_binding.as_deref_mut(), skills.as_deref())
                {
                    if skill_binding.select_skill(skill_id, skills) {
                        state.selected_skill_id = Some(skill_id);
                        skill_binding.set_assign_key(true);
                        state.skill_assign.show(skill_id, skills);
                    }
                }
            }
            OverlayButton::AssignSkillKey(hotkey) => state.skill_assign.choose(hotkey),
            OverlayButton::ClearSkillBinding => state.skill_assign.choose(0),
            OverlayButton::CloseSkillAssign => state.skill_assign.save(&mut intents),
            OverlayButton::SelectCharacterPage(page) => {
                // Crystal CharacterDialog page buttons inherit
                // MirButton.Sound = SoundList.ButtonA. Keep the cue on the
                // local Changed<Interaction> press edge; switching pages must
                // never manufacture a gateway intent.
                ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                state.character_page = page;
                state.inspect = None;
            }
            OverlayButton::SelectInventoryPage(page) => {
                if page <= 2 {
                    // All three source tabs are MirButtons with ButtonA. The
                    // locked second tab still clicks (Crystal opens an
                    // expansion prompt), but it must never expose a phantom
                    // empty page while expansion authority is unavailable.
                    ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                    if page != 1 || inventory.second_bag_unlocked() {
                        state.inventory_page = page;
                        state.inspect = None;
                        state.inventory_operation = None;
                        state.drop_confirmation = None;
                    }
                }
            }
            OverlayButton::SkillPagePrev => {
                state.skill_page = state.skill_page.saturating_sub(1);
                state.selected_skill_id = None;
            }
            OverlayButton::SkillPageNext => {
                let page_count = skills
                    .as_deref()
                    .map(|model| native_skill_page_count(model.skills.len()))
                    .unwrap_or(1);
                state.skill_page = (state.skill_page + 1).min(page_count.saturating_sub(1));
                state.selected_skill_id = None;
            }
            OverlayButton::SelectMail(id) => {
                if mail.selected_id == Some(id) {
                    let _ = open_mail_reader(&mut state, &mail, &mut intents, &mut pending, id);
                } else {
                    let _ = mail.select_visible(id);
                }
            }
            OverlayButton::MailPagePrev => {
                mail_ui.cursor.page = mail_ui.cursor.page.saturating_sub(1);
                mail.selected_id = None;
            }
            OverlayButton::MailPageNext => {
                mail_ui.cursor.page =
                    (mail_ui.cursor.page + 1).min(mail.page_count().saturating_sub(1));
                mail.selected_id = None;
            }
            OverlayButton::ReadMail(id) => {
                let _ = open_mail_reader(&mut state, &mail, &mut intents, &mut pending, id);
            }
            OverlayButton::ClaimMail(id) => {
                if let Some(msg) = mail.mails.iter().find(|m| m.id == id) {
                    if mail_claim_enabled(msg) {
                        intents.push_pending_intent(
                            &mut pending,
                            NativePlayerUiIntent::ClaimMail { mail_id: id },
                        );
                    }
                }
            }
            OverlayButton::MailReply(id) => {
                if pending.has_pending_mail_operation() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                let recipient = mail
                    .mails
                    .iter()
                    .find(|message| {
                        message.id == id && message.operation.is_none() && message.can_reply
                    })
                    .map(|message| message.sender.clone());
                if let Some(recipient) = recipient {
                    activate_mail_compose(
                        &mut state,
                        &mut compose_ui,
                        &mut effects,
                        MailComposeKind::Letter,
                    );
                    dispatch_ui_action(
                        &mut state.core,
                        &mut effects,
                        mir2_ui_core::action::UiAction::SetMailRecipient { recipient },
                    );
                    compose_ui.kind = MailComposeKind::Letter;
                    compose_ui.focus = MailComposeFocus::Message;
                    clear_mail_recipient_prompt(&mut state, &mut compose_ui);
                    clear_mail_feedback(&mut state, &mut compose_ui);
                }
            }
            OverlayButton::MailReaderClose => {
                if state.mail_reader.take().is_some() {
                    state.mail_reader_input_consumed = true;
                    ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                }
            }
            OverlayButton::MailReaderDelete => {
                let mail_id = mail_reader_message(&state, &mail).and_then(|message| {
                    (message.has_attachment() == false && mail_delete_enabled(message))
                        .then_some(message.id)
                });
                if let Some(mail_id) = mail_id {
                    if intents.push_pending_intent(
                        &mut pending,
                        NativePlayerUiIntent::DeleteMail { mail_id },
                    ) {
                        state.mail_reader = None;
                        state.mail_reader_input_consumed = true;
                        ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                    }
                }
            }
            OverlayButton::MailReaderLock => {
                let lock = mail_reader_message(&state, &mail).and_then(|message| {
                    (mail_reader_kind(message) == MailReaderKind::Letter)
                        .then_some((message.id, !message.locked))
                });
                if let Some((mail_id, lock)) = lock {
                    if intents.push_pending_intent(
                        &mut pending,
                        NativePlayerUiIntent::LockMail { mail_id, lock },
                    ) {
                        ui_audio.push(crate::audio::NativeUiSound::ButtonA);
                    }
                }
            }
            OverlayButton::MailReaderClaim => {
                let mail_id = mail_reader_message(&state, &mail).and_then(|message| {
                    (mail_reader_kind(message) == MailReaderKind::Parcel && mail_claim_enabled(message))
                        .then_some(message.id)
                });
                if let Some(mail_id) = mail_id {
                    if intents.push_pending_intent(
                        &mut pending,
                        NativePlayerUiIntent::ClaimMail { mail_id },
                    ) {
                        ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                    }
                }
            }
            OverlayButton::DeleteMail(id) => {
                if let Some(msg) = mail.mails.iter().find(|m| m.id == id) {
                    if let Some(prompt) = mail_delete_prompt_for_message(msg) {
                        state.mail_delete_prompt = Some(prompt);
                    } else if mail_delete_enabled(msg) {
                        intents.push_pending_intent(
                            &mut pending,
                            NativePlayerUiIntent::DeleteMail { mail_id: id },
                        );
                    }
                }
            }
            OverlayButton::OpenMailCompose => {
                if pending.has_pending_mail_operation() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                if state.core.mail_compose.is_some() && compose_ui.kind != MailComposeKind::Parcel {
                    compose_ui.last_notice = Some("Finish or cancel the current mail first".to_owned());
                    continue;
                }
                begin_mail_recipient_prompt(&mut state, &mut compose_ui);
                clear_mail_feedback(&mut state, &mut compose_ui);
            }
            OverlayButton::OpenMailParcelCompose => {
                if pending.has_pending_mail_operation() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                if state.core.mail_compose.is_some() {
                    compose_ui.last_notice = Some("Finish or cancel the current mail first".to_owned());
                    continue;
                }
                begin_mail_recipient_prompt_for(
                    &mut state,
                    &mut compose_ui,
                    MailComposeKind::Parcel,
                );
                clear_mail_feedback(&mut state, &mut compose_ui);
            }
            OverlayButton::MailRecipientSubmit => {
                if confirm_mail_recipient_prompt(&mut state, &mut compose_ui, &mut effects) {
                    ui_audio.push(crate::audio::NativeUiSound::ButtonB);
                }
            }
            OverlayButton::MailRecipientCancel => {
                cancel_mail_recipient_prompt(&mut state, &mut compose_ui);
                ui_audio.push(crate::audio::NativeUiSound::ButtonB);
            }
            OverlayButton::MailRecipientFocus => {
                compose_ui.focus = MailComposeFocus::Recipient;
            }
            OverlayButton::MailMessageFocus => {
                compose_ui.focus = MailComposeFocus::Message;
            }
            OverlayButton::MailGoldFocus => {
                if compose_ui.kind == MailComposeKind::Parcel {
                    if pending.has_pending_mail_send() {
                        compose_ui.last_notice = Some("Sending mail…".to_owned());
                        continue;
                    }
                    let current = state
                        .core
                        .mail_compose
                        .as_ref()
                        .map_or(0, |draft| draft.gold)
                        .min(inventory.gold);
                    let mut input = CrystalAmountInput::new(inventory.gold);
                    input.draft = current.to_string();
                    input.select_all = true;
                    state.parcel_gold_prompt = Some(input);
                } else {
                    compose_ui.focus = MailComposeFocus::Gold;
                }
            }
            OverlayButton::MailGoldInc | OverlayButton::MailGoldDec => {
                if pending.has_pending_mail_send() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                if let Some(draft) = state.core.mail_compose.as_ref() {
                    let gold = if matches!(*button, OverlayButton::MailGoldInc) {
                        draft.gold.saturating_add(100)
                    } else {
                        draft.gold.saturating_sub(100)
                    };
                    dispatch_ui_action(
                        &mut state.core,
                        &mut effects,
                        mir2_ui_core::action::UiAction::SetMailGold { gold },
                    );
                }
            }
            OverlayButton::AddMailAttachment(unique_id) => {
                if pending.has_pending_mail_send() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                if compose_ui.kind == MailComposeKind::Parcel {
                    if let Some(draft) = state.core.mail_compose.as_mut() {
                        if parcel_ui.attach(draft, &inventory, unique_id) {
                            let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem {
                                unique_id,
                                locked: true,
                            });
                        }
                    }
                } else if mail_attachment_is_current(&inventory, unique_id) {
                    dispatch_ui_action(
                        &mut state.core,
                        &mut effects,
                        mir2_ui_core::action::UiAction::AddMailAttachment { unique_id },
                    );
                }
            }
            OverlayButton::RemoveMailAttachment(unique_id) => {
                if pending.has_pending_mail_send() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                if compose_ui.kind == MailComposeKind::Parcel {
                    if let Some(draft) = state.core.mail_compose.as_mut() {
                        if let Some(slot) = draft.attachment_unique_ids.iter().position(|id| *id == unique_id) {
                            if let Some(unique_id) = parcel_ui.detach_at(draft, slot) {
                                let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem { unique_id, locked: false });
                            }
                        }
                    }
                } else {
                    dispatch_ui_action(
                        &mut state.core,
                        &mut effects,
                        mir2_ui_core::action::UiAction::RemoveMailAttachment { unique_id },
                    );
                }
            }
            OverlayButton::MailParcelStamp => {
                if pending.has_pending_mail_send() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                if compose_ui.kind == MailComposeKind::Parcel {
                    let was_stamped = parcel_ui.stamped();
                    if !parcel_ui.toggle_stamp(&inventory) {
                        compose_ui.last_notice = Some("A real parcel stamp is required".to_owned());
                    } else if was_stamped {
                        // Source `UpdateParcel` covers slots 1..4 without a
                        // stamp. Never retain those now-invisible IDs for a
                        // later SendMail request.
                        if let Some(draft) = state.core.mail_compose.as_mut() {
                            while draft.attachment_unique_ids.len() > parcel_ui.slot_limit() {
                                let slot = draft.attachment_unique_ids.len() - 1;
                                if let Some(unique_id) = parcel_ui.detach_at(draft, slot) {
                                    let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem { unique_id, locked: false });
                                }
                            }
                        }
                    }
                }
            }
            OverlayButton::MailParcelSlot(slot) => {
                if pending.has_pending_mail_send() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                if compose_ui.kind == MailComposeKind::Parcel {
                    if let Some(draft) = state.core.mail_compose.as_mut() {
                        if let Some(unique_id) = parcel_ui.detach_at(draft, usize::from(slot)) {
                            let _ = intents.push_transient_unique(NativePlayerUiIntent::MailLockItem { unique_id, locked: false });
                        }
                    }
                }
            }
            OverlayButton::MailParcelGoldConfirm => {
                if let Some(amount) = state
                    .parcel_gold_prompt
                    .as_ref()
                    .and_then(CrystalAmountInput::amount)
                {
                    if let Some(draft) = state.core.mail_compose.as_mut() {
                        draft.gold = amount;
                    }
                }
                state.parcel_gold_prompt = None;
                state.parcel_gold_input_consumed = true;
            }
            OverlayButton::MailParcelGoldCancel => {
                state.parcel_gold_prompt = None;
                state.parcel_gold_input_consumed = true;
            }
            OverlayButton::SubmitMail => {
                if compose_ui.kind == MailComposeKind::Letter {
                    if let Some(draft) = state.core.mail_compose.as_mut() {
                        let clean = letter_draft(std::mem::take(draft));
                        *draft = clean;
                    }
                }
                let Some(draft) = state.core.mail_compose.clone() else {
                    continue;
                };
                if compose_ui.kind == MailComposeKind::Parcel
                    && (!parcel_ui.quote_is_current(&draft, &inventory)
                        || (parcel_ui.stamped() && !parcel_ui.stamp_available(&inventory)))
                {
                    show_mail_feedback(
                        &mut state,
                        &mut compose_ui,
                        "Postage quote is not ready",
                    );
                    continue;
                }
                let Some(ids) = valid_mail_attachment_ids(&inventory, &draft.attachment_unique_ids)
                else {
                    show_mail_feedback(
                        &mut state,
                        &mut compose_ui,
                        "Attachment is no longer in Bag1/Bag2",
                    );
                    continue;
                };
                if draft.recipient.trim().is_empty() || draft.message.trim().is_empty() {
                    show_mail_feedback(
                        &mut state,
                        &mut compose_ui,
                        "Recipient and message are required",
                    );
                    continue;
                }
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::SubmitMail,
                );
                for command in effects.drain_mail_commands() {
                    if let mir2_ui_core::effect::GatewayCommand::SendMail {
                        recipient,
                        message,
                        gold,
                        ..
                    } = command
                    {
                        let intent = NativePlayerUiIntent::SendMail {
                            recipient,
                            message,
                            gold,
                            attachment_unique_ids: ids.clone(),
                            stamped: compose_ui.kind == MailComposeKind::Parcel && parcel_ui.stamped(),
                        };
                        if !intents.push_pending_intent(&mut pending, intent) {
                            compose_ui.last_notice = Some("Mail is already being sent".to_owned());
                        } else {
                            compose_ui.last_notice = Some("Sending mail…".to_owned());
                        }
                    }
                }
            }
            OverlayButton::CancelMailCompose => {
                if pending.has_pending_mail_send() {
                    compose_ui.last_notice = Some("Sending mail…".to_owned());
                    continue;
                }
                release_mail_parcel_locks(&mut parcel_ui, &mut intents);
                dispatch_ui_action(
                    &mut state.core,
                    &mut effects,
                    mir2_ui_core::action::UiAction::CancelMailCompose,
                );
                compose_ui.kind = MailComposeKind::Letter;
                state.mail_inventory_visible = false;
                clear_mail_recipient_prompt(&mut state, &mut compose_ui);
                clear_mail_feedback(&mut state, &mut compose_ui);
            }
            OverlayButton::BigMapScrollUp => {
                if state.bigmap_open() {
                    let Some(big_map) = big_map.as_deref_mut() else {
                        continue;
                    };
                    let row = big_map.npc_scroll_row.saturating_sub(1);
                    big_map.set_npc_scroll_row(row);
                }
            }
            OverlayButton::BigMapScrollDown => {
                if state.bigmap_open() {
                    let Some(big_map) = big_map.as_deref_mut() else {
                        continue;
                    };
                    let row = big_map.npc_scroll_row.saturating_add(1);
                    big_map.set_npc_scroll_row(row);
                }
            }
            OverlayButton::BigMapWorld => {
                if state.bigmap_open() {
                    let Some(big_map) = big_map.as_deref_mut() else {
                        continue;
                    };
                    big_map.set_view(BigMapView::WorldMap);
                }
            }
            OverlayButton::BigMapMyLocation => {
                if state.bigmap_open() {
                    let Some(big_map) = big_map.as_deref_mut() else {
                        continue;
                    };
                    big_map.set_view(BigMapView::CurrentMap);
                    if let (Some(map_index), Some(big_map_intents)) =
                        (big_map.current_map_index, big_map_intents.as_deref_mut())
                    {
                        let _ = big_map_intents.request_map_info(big_map, map_index);
                    }
                }
            }
            OverlayButton::BigMapSearchFocus => {
                if state.bigmap_open() {
                    if let Some(big_map_ui) = big_map_ui.as_deref_mut() {
                        big_map_ui.search_focused = true;
                    }
                }
            }
            OverlayButton::BigMapSearchSubmit => {
                if state.bigmap_open() {
                    let now_ms = time
                        .as_deref()
                        .map(|clock| clock.elapsed().as_millis() as u64)
                        .unwrap_or_default();
                    if let (Some(big_map), Some(big_map_intents)) =
                        (big_map.as_deref_mut(), big_map_intents.as_deref_mut())
                    {
                        let _ = big_map_intents.search(big_map, now_ms, BIG_MAP_SEARCH_COOLDOWN_MS);
                    }
                }
            }
            OverlayButton::BigMapTeleport => {
                if state.bigmap_open() {
                    if let (Some(big_map), Some(big_map_intents)) =
                        (big_map.as_deref(), big_map_intents.as_deref_mut())
                    {
                        let _ = big_map_intents.teleport_selected(big_map);
                    }
                }
            }
            OverlayButton::SelectBigMapNpc(object_id) => {
                if state.bigmap_open() {
                    if let Some(big_map) = big_map.as_deref_mut() {
                        let _ = big_map.select_npc(object_id);
                    }
                }
            }
            // Shop
            OverlayButton::GameShopControl(action) => {
                if let Some(model) = game_shop.as_deref_mut() {
                    game_shop_dialog::action(
                        &mut state,
                        model,
                        action,
                        &player_class,
                        gold,
                        credit,
                        &mut intents,
                        &mut pending,
                    );
                }
            }
            OverlayButton::SelectGameShopGood(id) => {
                if state.shop_open() {
                    let Some(game_shop) = game_shop.as_deref_mut() else {
                        continue;
                    };
                    game_shop.selected_game_shop_index = Some(id);
                    if let Some(page) = native_game_shop_page_for_index(game_shop, id) {
                        state.game_shop_page = page;
                    }
                }
            }
            OverlayButton::GameShopPaymentCredit => {
                if state.shop_open() {
                    let Some(game_shop) = game_shop.as_deref_mut() else {
                        continue;
                    };
                    game_shop.payment = GameShopPaymentType::Credit;
                }
            }
            OverlayButton::GameShopPaymentGold => {
                if state.shop_open() {
                    let Some(game_shop) = game_shop.as_deref_mut() else {
                        continue;
                    };
                    game_shop.payment = GameShopPaymentType::Gold;
                }
            }
            OverlayButton::GameShopQuantityInc => {
                if state.shop_open() {
                    let Some(game_shop) = game_shop.as_deref_mut() else {
                        continue;
                    };
                    game_shop.quantity_inc();
                }
            }
            OverlayButton::GameShopQuantityDec => {
                if state.shop_open() {
                    let Some(game_shop) = game_shop.as_deref_mut() else {
                        continue;
                    };
                    game_shop.quantity_dec();
                }
            }
            OverlayButton::GameShopPagePrev => {
                if state.shop_open() {
                    state.game_shop_page = state.game_shop_page.saturating_sub(1);
                    state.game_shop_dialog.preview = None;
                    state.game_shop_dialog.quantities.clear();
                }
            }
            OverlayButton::GameShopPageNext => {
                if state.shop_open() {
                    let page_count = game_shop
                        .as_deref()
                        .map(|model| {
                            native_game_shop_page_count(
                                state
                                    .game_shop_dialog
                                    .entries(
                                        model,
                                        &player_class,
                                        game_shop_dialog::current_ticks(),
                                    )
                                    .len(),
                            )
                        })
                        .unwrap_or(1);
                    state.game_shop_page =
                        (state.game_shop_page + 1).min(page_count.saturating_sub(1));
                    state.game_shop_dialog.preview = None;
                    state.game_shop_dialog.quantities.clear();
                }
            }
            OverlayButton::GameShopBuy => {
                if state.shop_open() {
                    let Some(game_shop) = game_shop.as_deref_mut() else {
                        continue;
                    };
                    let Some(entry) = game_shop.selected().cloned() else {
                        continue;
                    };
                    let quantity = game_shop.quantity;
                    let price_type = game_shop.payment.protocol_value();
                    if game_shop.buy_enabled(gold, credit, &player_class)
                        && entry.game_shop_index >= 0
                    {
                        let _ = intents.enqueue_game_shop_purchase(
                            &mut state.core,
                            game_shop,
                            &mut pending,
                            entry.game_shop_index,
                            quantity,
                            price_type,
                        );
                    }
                }
            }
            OverlayButton::SelectShopGood(id) => {
                if state.npc_shop_open() && shop.allows_buy() {
                    shop.selected_id = Some(id);
                }
            }
            OverlayButton::ShopShowBuy => {
                if state.npc_shop_open() && shop.allows_buy() {
                    state.npc_shop_buy_tab = true;
                }
            }
            OverlayButton::ShopShowSell => {
                if state.npc_shop_open() && shop.allows_sell() {
                    state.npc_shop_buy_tab = false;
                }
            }
            OverlayButton::ShopBuy => {
                if state.npc_shop_open()
                    && shop.allows_buy()
                    && shop_buy_enabled_with_pearls(
                        &shop,
                        &inventory,
                        state.shop_quantity,
                        state.creature.pearls.max(0) as u32,
                    )
                {
                    let id = shop.selected_id.unwrap();
                    intents.push_pending_intent(
                        &mut pending,
                        NativePlayerUiIntent::BuyItem {
                            item_index: id,
                            count: shop_quantity_clamped(state.shop_quantity),
                        },
                    );
                }
            }
            OverlayButton::ShopToggleHold => {
                if state.npc_shop_open() && npc_item_service::service_action(&shop).is_some() {
                    state.npc_service_hold = if state.npc_service_hold == Some(shop.service_mode) {
                        None
                    } else {
                        Some(shop.service_mode)
                    };
                }
            }
            OverlayButton::ShopSell | OverlayButton::ShopRepair | OverlayButton::ShopSRepair => {
                let allowed = match button {
                    OverlayButton::ShopSell => shop.allows_sell(),
                    OverlayButton::ShopRepair => shop.allows_repair(),
                    OverlayButton::ShopSRepair => shop.allows_special_repair(),
                    _ => false,
                };
                if allowed {
                    npc_item_service::submit_selection(&mut shop, &inventory, &mut state, &mut intents, &mut pending);
                }
            }
            OverlayButton::ShopQuantityInc => {
                if state.npc_shop_open()
                    && matches!(
                        shop.service_mode,
                        NpcShopServiceMode::Buy | NpcShopServiceMode::Sell
                    )
                {
                    state.shop_quantity_inc();
                }
            }
            OverlayButton::ShopQuantityDec => {
                if state.npc_shop_open()
                    && matches!(
                        shop.service_mode,
                        NpcShopServiceMode::Buy | NpcShopServiceMode::Sell
                    )
                {
                    state.shop_quantity_dec();
                }
            }
            OverlayButton::ShopPageUp => {
                if state.npc_shop_open() && shop.allows_buy() {
                    shop_ui.start_index = shop_ui.start_index.saturating_sub(1);
                    shop.selected_id = None;
                }
            }
            OverlayButton::ShopPageDown => {
                if state.npc_shop_open() && shop.allows_buy() {
                    shop_ui.start_index =
                        (shop_ui.start_index + 1).min(shop.goods.len().saturating_sub(8));
                    shop.selected_id = None;
                }
            }
            OverlayButton::ShopConfirm => {
                if !state.npc_shop_open() {
                    continue;
                }
                if shop.allows_repair() || shop.allows_special_repair()
                    || (shop.allows_sell() && (!shop.allows_buy() || !state.npc_shop_buy_tab)) {
                    npc_item_service::submit_selection(&mut shop, &inventory, &mut state, &mut intents, &mut pending);
                } else if shop.allows_buy()
                    && shop_buy_enabled_with_pearls(
                        &shop,
                        &inventory,
                        state.shop_quantity,
                        state.creature.pearls.max(0) as u32,
                    )
                {
                    let id = shop.selected_id.unwrap();
                    intents.push_pending_intent(
                        &mut pending,
                        NativePlayerUiIntent::BuyItem {
                            item_index: id,
                            count: shop_quantity_clamped(state.shop_quantity),
                        },
                    );
                }
            }
            OverlayButton::ShopCancel => {
                if state.npc_shop_open() {
                    state.core.panel = mir2_ui_core::state::UiPanel::None;
                }
                state.shop_quantity = 1;
                state.shop_service_drag_count = None;
                state.shop_service_drag_unique_id = None;
                state.npc_inventory_hidden = false;
                state.npc_service_hold = None;
                state.npc_shop_buy_tab = true;
                shop.selected_id = None;
                shop.selected_bag_slot_for_sell = None;
                shop.selected_bag_slot_for_repair = None;
                state.shop_repair_container = 0;
                state.shop_repair_slot = None;
                let _ = shop.apply_service_signal(NpcShopServiceSignal::default());
            }
            OverlayButton::SelectBagForSell(slot) => {
                if state.npc_shop_open() && shop.allows_sell() {
                    shop.selected_bag_slot_for_sell = Some(slot);
                    state.shop_service_drag_count = None;
                    state.shop_service_drag_unique_id = None;
                    if state.npc_service_hold == Some(shop.service_mode) {
                        npc_item_service::submit_selection(&mut shop, &inventory, &mut state, &mut intents, &mut pending);
                    }
                }
            }
            OverlayButton::SelectBagForRepair(slot) => {
                if state.npc_shop_open() && (shop.allows_repair() || shop.allows_special_repair()) {
                    shop.selected_bag_slot_for_repair = Some(slot);
                    state.shop_service_drag_count = None;
                    state.shop_service_drag_unique_id = None;
                    state.shop_repair_container = 0;
                    state.shop_repair_slot = Some(slot);
                    if state.npc_service_hold == Some(shop.service_mode) {
                        npc_item_service::submit_selection(&mut shop, &inventory, &mut state, &mut intents, &mut pending);
                    }
                }
            }
            // Storage
            OverlayButton::SelectBagForStore(slot) => {
                storage_ui.bag_selection = inventory_selection_for_slot(&inventory, slot);
                storage.selected_bag_slot = storage_ui.bag_selection.map(|value| value.slot);
                storage.selected_storage_slot = None;
                storage_ui.storage_selection = None;
            }
            OverlayButton::SelectStorage(slot) => {
                storage_ui.storage_selection = storage.selection_for_slot(slot);
                storage.selected_storage_slot =
                    storage_ui.storage_selection.map(|value| value.slot);
                storage.selected_bag_slot = None;
                storage_ui.bag_selection = None;
            }
            OverlayButton::StoragePage(page) => {
                storage_ui.cursor.page = storage.clamp_page(page);
                storage.selected_storage_slot = None;
                storage_ui.storage_selection = None;
            }
            OverlayButton::StorageDeposit => {
                if let Some(selection) = storage_ui.bag_selection.filter(|selection| {
                    storage_deposit_enabled_for_selection(&storage, &inventory, *selection)
                }) {
                    let from = selection.slot as i32;
                    let unique_id = selection.unique_id;
                    if let Some(to) = storage.first_empty_storage_slot() {
                        intents.push_storage_pending_intent(
                            &mut pending,
                            true,
                            unique_id,
                            from,
                            i32::try_from(to).unwrap_or(i32::MAX),
                        );
                    }
                }
            }
            OverlayButton::StorageWithdraw => {
                if let Some(selection) = storage_ui.storage_selection.filter(|selection| {
                    storage_withdraw_enabled_for_selection(&storage, &inventory, *selection)
                }) {
                    let from = selection.slot as i32;
                    let unique_id = selection.unique_id;
                    if let Some(to) = first_empty_bag_slot(&inventory) {
                        intents.push_storage_pending_intent(
                            &mut pending,
                            false,
                            unique_id,
                            from,
                            i32::try_from(to).unwrap_or(i32::MAX),
                        );
                    }
                }
            }
            OverlayButton::StorageUnlock => {
                let _ = open_storage_password_prompt(&mut state, &mut storage);
            }
            OverlayButton::StorageSetPassword | OverlayButton::StorageRemovePassword => {
                // Crystal's Protect path changes an existing password; it
                // does not dispatch the legacy RemoveStoragePassword command.
                let _ = open_storage_password_prompt(&mut state, &mut storage);
            }
            OverlayButton::StoragePasswordSubmit => {
                let _ = submit_storage_password_prompt(
                    &mut state,
                    &mut storage,
                    &mut intents,
                    &mut pending,
                );
            }
            OverlayButton::StoragePasswordCancel => {
                cancel_storage_password_prompt(&mut state, &mut storage);
            }
            OverlayButton::StorageRentalConfirm => {
                let _ = submit_storage_rental_confirmation(&mut state, &mut intents);
            }
            OverlayButton::StorageRentalCancel => {
                cancel_storage_rental_confirmation(&mut state);
            }
            OverlayButton::StorageExpand => {
                let _ = open_storage_rental_confirmation(&mut state, &storage);
            }
        }
    }
}

fn consume_exit_application(
    mut effects: ResMut<UiEffectQueue>,
    mut app_exit: MessageWriter<AppExit>,
) {
    if effects.take_exit_application() {
        eprintln!("[native-exit] app_exit source=ui_effect code=success");
        app_exit.write(AppExit::Success);
    }
}

fn inspect_from_item(item: &ItemModel) -> ItemInspect {
    ItemInspect {
        container: item.container,
        slot: item.slot,
        key: item.key.clone(),
        name: item.name.clone(),
        quantity: item.quantity,
    }
}

fn inspected_inventory_item<'a>(
    state: &NativePlayerUiState,
    inventory: &'a InventoryModel,
) -> Option<&'a ItemModel> {
    let inspect = state.inspect.as_ref()?;
    (inspect.container == 0).then_some(())?;
    inventory
        .items
        .iter()
        .find(|item| item.container == 0 && item.slot == inspect.slot && item.key == inspect.key)
}

fn bag_slot_is_mail_locked(
    parcel: &mail_parcel::MailParcelUi,
    inventory: &InventoryModel,
    slot: u32,
) -> bool {
    inventory
        .items_in(0)
        .into_iter()
        .find(|item| item.slot == slot)
        .and_then(item_unique_id)
        .is_some_and(|unique_id| parcel.blocks_item(unique_id))
}

fn bag_slot_is_mail_locked_opt(
    parcel: Option<&mail_parcel::MailParcelUi>,
    inventory: &InventoryModel,
    slot: u32,
) -> bool {
    parcel.is_some_and(|parcel| bag_slot_is_mail_locked(parcel, inventory, slot))
}

fn inspected_bag_item_is_mail_locked(
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
    parcel: &mail_parcel::MailParcelUi,
) -> bool {
    inspected_inventory_item(state, inventory)
        .and_then(item_unique_id)
        .is_some_and(|unique_id| parcel.blocks_item(unique_id))
}

/// A lock echo can race a pre-existing item menu or destructive prompt.  Clear
/// only the exact bag interaction it protects; unrelated inventory operations
/// retain their normal lifecycle.
fn clear_mail_locked_inventory_interaction(
    state: &mut NativePlayerUiState,
    inventory: &InventoryModel,
    parcel: &mail_parcel::MailParcelUi,
) {
    if inspected_bag_item_is_mail_locked(state, inventory, parcel) {
        state.inspect = None;
        state.drop_confirmation = None;
    }
    if state.inventory_operation.as_ref().is_some_and(|operation| {
        let unique_id = match operation {
            InventoryOperationDraft::Move { unique_id, .. }
            | InventoryOperationDraft::Merge { unique_id, .. } => *unique_id,
        };
        parcel.blocks_item(unique_id)
    }) {
        state.inventory_operation = None;
    }
    if state.inventory_delete_prompt.as_ref().is_some_and(|prompt| {
        parcel.blocks_item(prompt.target().unique_id)
    }) {
        state.cancel_inventory_delete();
    }
}

fn inspected_use_intent(
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
) -> Option<NativePlayerUiIntent> {
    let inspect = state.inspect.as_ref()?;
    if inspect.container == 3 {
        return None;
    }
    let item = inventory.items.iter().find(|item| {
        item.container == inspect.container && item.slot == inspect.slot && item.key == inspect.key
    })?;
    Some(NativePlayerUiIntent::UseItem {
        key: Some(item.key.clone()),
        unique_id: item_unique_id(item),
        slot: u8::try_from(item.slot).ok(),
        grid: Some(container_name(item.container).to_owned()),
    })
}

fn inspected_equip_intent(
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
) -> Option<NativePlayerUiIntent> {
    let inspect = state.inspect.as_ref()?;
    if inspect.container == 3 {
        return None;
    }
    if inspect.container == 2 {
        return inspected_remove_intent(state, inventory);
    }
    let item = inventory.items.iter().find(|item| {
        item.container == inspect.container && item.slot == inspect.slot && item.key == inspect.key
    })?;
    Some(NativePlayerUiIntent::EquipItem {
        unique_id: item_unique_id(item)?,
        grid: container_name(item.container).to_owned(),
        to: equip_destination_for_item(item),
    })
}

fn inspected_remove_intent(
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
) -> Option<NativePlayerUiIntent> {
    let inspect = state.inspect.as_ref()?;
    if inspect.container != 2 {
        return None;
    }
    let item = inventory
        .items
        .iter()
        .find(|item| item.container == 2 && item.slot == inspect.slot && item.key == inspect.key)?;
    // Crystal MirItemCell.RemoveItem selects the first free bag cell, whose
    // raw Inventory-array index starts at 6. This host's WebSocket contract
    // (Simulation::remove_item_destination) uses a normalized 0-based bag
    // index instead. Do not send the raw +6 or the worn item's source grid.
    // Belt-first amulet removal/merging remains a separate protocol gap:
    // that endpoint cannot address a belt destination, so never alias one
    // to an unrelated bag cell.
    let free_bag = (0..inventory.bag_slot_capacity())
        .find(|slot| {
            !inventory
                .items
                .iter()
                .any(|candidate| candidate.container == 0 && candidate.slot == u32::from(*slot))
        })
        .map(i32::from);
    Some(NativePlayerUiIntent::RemoveItem {
        unique_id: item_unique_id(item)?,
        grid: "inventory".to_owned(),
        to: free_bag?,
    })
}

fn inventory_delete_prompt_for_item(item: &ItemModel) -> Option<InventoryDeletePrompt> {
    (item.container == 0).then_some(())?;
    let max_count = u16::try_from(item.quantity).ok()?;
    (max_count > 0).then_some(())?;
    let target = InventoryDeleteTarget {
        unique_id: item_unique_id(item)?,
        slot: item.slot,
        key: item.key.clone(),
        name: if item.name.trim().is_empty() {
            item.key.clone()
        } else {
            item.name.clone()
        },
        max_count,
    };
    Some(if max_count > 1 {
        InventoryDeletePrompt::Amount {
            draft: max_count.to_string(),
            target,
            select_all: true,
        }
    } else {
        InventoryDeletePrompt::Confirm { target }
    })
}

fn inventory_delete_target_is_current(
    target: &InventoryDeleteTarget,
    inventory: &InventoryModel,
) -> bool {
    inventory.items.iter().any(|item| {
        item.container == 0
            && item.slot == target.slot
            && item.key == target.key
            && item_unique_id(item) == Some(target.unique_id)
            && item.quantity == u32::from(target.max_count)
    })
}

fn inventory_delete_prompt_is_current(
    prompt: &InventoryDeletePrompt,
    inventory: &InventoryModel,
) -> bool {
    inventory_delete_target_is_current(prompt.target(), inventory)
}

fn inventory_delete_amount(prompt: &InventoryDeletePrompt) -> Option<u16> {
    match prompt {
        InventoryDeletePrompt::Amount { target, draft, .. } => {
            let parsed = draft.parse::<u32>().ok()?;
            Some(parsed.clamp(1, u32::from(target.max_count)) as u16)
        }
        InventoryDeletePrompt::Confirm { .. } => Some(1),
    }
}

fn delete_amount_backspace(state: &mut NativePlayerUiState) {
    let Some(InventoryDeletePrompt::Amount {
        draft, select_all, ..
    }) = state.inventory_delete_prompt.as_mut()
    else {
        return;
    };
    if *select_all {
        draft.clear();
        *select_all = false;
    } else {
        draft.pop();
    }
}

fn push_delete_amount_text(state: &mut NativePlayerUiState, text: &str) {
    let Some(InventoryDeletePrompt::Amount {
        target,
        draft,
        select_all,
    }) = state.inventory_delete_prompt.as_mut()
    else {
        return;
    };
    let digits = text
        .chars()
        .filter(char::is_ascii_digit)
        .collect::<String>();
    if digits.is_empty() {
        return;
    }
    if *select_all {
        draft.clear();
        *select_all = false;
    }
    for digit in digits.chars() {
        if draft.len() < 10 {
            draft.push(digit);
        }
        if draft
            .parse::<u32>()
            .is_ok_and(|amount| amount > u32::from(target.max_count))
        {
            *draft = target.max_count.to_string();
        }
    }
}

fn confirm_inventory_delete(
    state: &mut NativePlayerUiState,
    inventory: &InventoryModel,
    parcel: &mail_parcel::MailParcelUi,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    let Some(prompt) = state.inventory_delete_prompt.clone() else {
        return false;
    };
    if !inventory_delete_prompt_is_current(&prompt, inventory) {
        state.cancel_inventory_delete();
        return false;
    }
    if parcel.blocks_item(prompt.target().unique_id) {
        state.cancel_inventory_delete();
        return false;
    }
    let Some(count) = inventory_delete_amount(&prompt) else {
        return false;
    };
    let target = prompt.target();
    if !intents.push_pending_intent(
        pending,
        NativePlayerUiIntent::DeleteItem {
            unique_id: target.unique_id,
            count,
            hero_inventory: false,
        },
    ) {
        return false;
    }
    state.cancel_inventory_delete();
    true
}

fn mail_delete_prompt_for_message(message: &crate::mail::MailMessage) -> Option<MailDeletePrompt> {
    (mail_delete_enabled(message) && message.has_attachment()).then(|| MailDeletePrompt {
        mail_id: message.id,
        gold: message.gold,
        items: message.items.clone(),
    })
}

fn mail_delete_prompt_is_current(prompt: &MailDeletePrompt, mail: &MailModel) -> bool {
    mail.mails.iter().find(|message| message.id == prompt.mail_id).is_some_and(|message| {
        mail_delete_enabled(message)
            && message.has_attachment()
            && message.gold == prompt.gold
            && message.items == prompt.items
    })
}

fn confirm_mail_delete(
    state: &mut NativePlayerUiState,
    mail: &mut MailModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
) -> bool {
    let Some(prompt) = state.mail_delete_prompt.clone() else {
        return false;
    };
    if !mail_delete_prompt_is_current(&prompt, mail) {
        state.mail_delete_prompt = None;
        return false;
    }
    if !intents.push_pending_intent(
        pending,
        NativePlayerUiIntent::DeleteMail {
            mail_id: prompt.mail_id,
        },
    ) {
        return false;
    }
    // Crystal clears SelectedMail once its Yes handler has accepted the
    // enqueue. Keep a failed/deduplicated request selected for a later retry.
    mail.selected_id = None;
    state.mail_delete_prompt = None;
    true
}

fn inspected_drop_confirmation(
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
) -> Option<InventoryDropConfirmation> {
    let item = inspected_inventory_item(state, inventory)?;
    let count = u16::try_from(item.quantity).ok()?;
    Some(InventoryDropConfirmation {
        key: item.key.clone(),
        unique_id: item_unique_id(item)?,
        slot: item.slot,
        count: (count > 0).then_some(count)?,
    })
}

fn drop_confirmation_is_current(
    confirmation: &InventoryDropConfirmation,
    inventory: &InventoryModel,
) -> bool {
    inventory.items.iter().any(|item| {
        item.container == 0
            && item.slot == confirmation.slot
            && item.key == confirmation.key
            && item_unique_id(item) == Some(confirmation.unique_id)
            && item.quantity == u32::from(confirmation.count)
    })
}

fn selected_repair_item<'a>(
    state: &NativePlayerUiState,
    inventory: &'a InventoryModel,
) -> Option<&'a ItemModel> {
    let slot = state.shop_repair_slot?;
    inventory
        .items
        .iter()
        .find(|item| item.container == state.shop_repair_container && item.slot == slot)
}

fn repair_selection_enabled(state: &NativePlayerUiState, inventory: &InventoryModel) -> bool {
    selected_repair_item(state, inventory).is_some_and(|item| item.container == 0)
}

fn render_inventory_delete_item(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    target: &InventoryDeleteTarget,
    inventory: &InventoryModel,
    item_box: CrystalRect,
) {
    let Some(item) = inventory.items.iter().find(|item| {
        item.container == 0
            && item.slot == target.slot
            && item_unique_id(item) == Some(target.unique_id)
    }) else {
        return;
    };
    let Some(index) = item.user_item_image_index() else {
        return;
    };
    parent
        .spawn(Node {
            position_type: PositionType::Absolute,
            left: Val::Px(item_box.left),
            top: Val::Px(item_box.top),
            width: Val::Px(item_box.width),
            height: Val::Px(item_box.height),
            ..default()
        })
        .with_children(|cell| {
            spawn_original_item_image(
                cell,
                asset_server,
                index,
                item_box.width as i32,
                item_box.height as i32,
            );
        });
}

fn render_inventory_delete_modal(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
) {
    let Some(prompt) = state.inventory_delete_prompt.as_ref() else {
        return;
    };
    match prompt {
        InventoryDeletePrompt::Amount { target, draft, .. } => {
            parent
                .spawn((
                    OverlayInventoryDeleteDialog,
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.left),
                        top: Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.top),
                        width: Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.width),
                        height: Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.height),
                        overflow: Overflow::clip(),
                        ..default()
                    },
                    BackgroundColor(Color::NONE),
                ))
                .with_children(|dialog| {
                    if let Some(asset_server) = asset_server {
                        spawn_overlay_frame(
                            dialog,
                            asset_server,
                            "original-ui/Prguse/238.png",
                            CRYSTAL_DELETE_AMOUNT_RECT.width,
                            CRYSTAL_DELETE_AMOUNT_RECT.height,
                        );
                        spawn_overlay_crystal_button(
                            dialog,
                            asset_server,
                            "Prguse2",
                            360,
                            361,
                            362,
                            CrystalRect::new(180.0, 3.0, 24.0, 21.0),
                            OverlayButton::InventoryDeleteAmountClose,
                        );
                        render_inventory_delete_item(
                            dialog,
                            asset_server,
                            target,
                            inventory,
                            CrystalRect::new(15.0, 34.0, 38.0, 34.0),
                        );
                        spawn_overlay_crystal_button_enabled(
                            dialog,
                            asset_server,
                            "Title",
                            200,
                            201,
                            202,
                            CrystalRect::new(23.0, 76.0, 76.0, 25.0),
                            OverlayButton::InventoryDeleteConfirm,
                            draft.parse::<u32>().is_ok(),
                        );
                        spawn_overlay_crystal_button(
                            dialog,
                            asset_server,
                            "Title",
                            203,
                            204,
                            205,
                            CrystalRect::new(110.0, 76.0, 76.0, 25.0),
                            OverlayButton::InventoryDeleteCancel,
                        );
                    }
                    overlay_text_at(
                        dialog,
                        &crate::native_i18n::tr(&format!("Delete how many '{name}'?", name = target.name)),
                        CrystalRect::new(19.0, 8.0, 158.0, 14.0),
                        10.0,
                        TEXT,
                    );

                    let parsed = draft.parse::<u32>().ok();
                    let border = match parsed {
                        None => Color::srgb(1.0, 0.0, 0.0),
                        Some(amount) if amount == u32::from(target.max_count) => {
                            Color::srgb(1.0, 0.647, 0.0)
                        }
                        Some(_) => Color::srgb(0.0, 1.0, 0.0),
                    };
                    dialog
                        .spawn((
                            OverlayInventoryDeleteAmountInput,
                            Node {
                                position_type: PositionType::Absolute,
                                left: Val::Px(58.0),
                                top: Val::Px(43.0),
                                width: Val::Px(132.0),
                                height: Val::Px(19.0),
                                border: UiRect::all(Val::Px(1.0)),
                                padding: UiRect::axes(Val::Px(2.0), Val::Px(0.0)),
                                align_items: AlignItems::Center,
                                overflow: Overflow::clip(),
                                ..default()
                            },
                            BackgroundColor(Color::BLACK),
                            BorderColor::all(border),
                        ))
                        .with_children(|input| {
                            input.spawn((
                                Text::new(draft.clone()),
                                crate::crystal_ui::typography::crystal_text_font(10.0),
                                TextColor(TEXT),
                                TextLayout::new(Justify::Left, LineBreak::NoWrap),
                            ));
                        });
                });
        }
        InventoryDeletePrompt::Confirm { target } => {
            parent
                .spawn((
                    OverlayInventoryDeleteDialog,
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.left),
                        top: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.top),
                        width: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.width),
                        height: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.height),
                        overflow: Overflow::clip(),
                        ..default()
                    },
                    BackgroundColor(Color::NONE),
                ))
                .with_children(|dialog| {
                    if let Some(asset_server) = asset_server {
                        spawn_overlay_frame(
                            dialog,
                            asset_server,
                            "original-ui/Prguse/360.png",
                            CRYSTAL_DELETE_CONFIRM_RECT.width,
                            CRYSTAL_DELETE_CONFIRM_RECT.height,
                        );
                        spawn_overlay_crystal_button(
                            dialog,
                            asset_server,
                            "Title",
                            206,
                            207,
                            208,
                            CrystalRect::new(260.0, 157.0, 76.0, 25.0),
                            OverlayButton::InventoryDeleteConfirm,
                        );
                        spawn_overlay_crystal_button(
                            dialog,
                            asset_server,
                            "Title",
                            210,
                            211,
                            212,
                            CrystalRect::new(360.0, 157.0, 76.0, 25.0),
                            OverlayButton::InventoryDeleteCancel,
                        );
                    }
                    overlay_text_at(
                        dialog,
                        &crate::native_i18n::tr(&format!(
                            "Permanently delete '{}'? This cannot be undone.",
                            target.name
                        )),
                        CrystalRect::new(35.0, 35.0, 390.0, 110.0),
                        10.0,
                        TEXT,
                    );
                });
        }
    }
}

/// MailDialog's attachment warning uses the standard Crystal Yes/No
/// MirMessageBox frame and wording, rather than the inventory's permanent
/// item-delete message.
fn render_mail_delete_modal(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
) {
    parent
        .spawn((
            OverlayMailDeleteDialog,
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.left),
                top: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.top),
                width: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.width),
                height: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.height),
                overflow: Overflow::clip(),
                ..default()
            },
            BackgroundColor(Color::NONE),
        ))
        .with_children(|dialog| {
            if let Some(asset_server) = asset_server {
                spawn_overlay_frame(
                    dialog,
                    asset_server,
                    "original-ui/Prguse/360.png",
                    CRYSTAL_DELETE_CONFIRM_RECT.width,
                    CRYSTAL_DELETE_CONFIRM_RECT.height,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    206,
                    207,
                    208,
                    CrystalRect::new(260.0, 157.0, 76.0, 25.0),
                    OverlayButton::MailDeleteConfirm,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    210,
                    211,
                    212,
                    CrystalRect::new(360.0, 157.0, 76.0, 25.0),
                    OverlayButton::MailDeleteCancel,
                );
            }
            overlay_text_at(
                dialog,
                &crate::native_i18n::tr("This parcel contains items or gold. Are you sure you want to delete it?"),
                CrystalRect::new(35.0, 35.0, 390.0, 110.0),
                10.0,
                TEXT,
            );
        });
}

/// Mail send/parcel result and local validation feedback use Crystal's
/// one-button MirMessageBox. The full-stage parent captures clicks outside
/// this source-sized frame.
fn render_mail_feedback_modal(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    message: &str,
) {
    parent
        .spawn((
            OverlayMailFeedbackDialog,
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.left),
                top: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.top),
                width: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.width),
                height: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.height),
                overflow: Overflow::clip(),
                ..default()
            },
            BackgroundColor(Color::NONE),
        ))
        .with_children(|dialog| {
            if let Some(asset_server) = asset_server {
                spawn_overlay_frame(
                    dialog,
                    asset_server,
                    "original-ui/Prguse/360.png",
                    CRYSTAL_DELETE_CONFIRM_RECT.width,
                    CRYSTAL_DELETE_CONFIRM_RECT.height,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    200,
                    201,
                    202,
                    CrystalRect::new(360.0, 157.0, 76.0, 25.0),
                    OverlayButton::MailFeedbackAcknowledge,
                );
            }
            overlay_text_at(
                dialog,
                message,
                CrystalRect::new(35.0, 35.0, 390.0, 110.0),
                10.0,
                TEXT,
            );
        });
}

fn storage_password_caption(stage: StoragePasswordStage) -> &'static str {
    match stage {
        StoragePasswordStage::Unlock => "Enter storage password",
        StoragePasswordStage::ConfirmChange => "Change storage password?",
        StoragePasswordStage::Current => "Enter current password",
        StoragePasswordStage::New => "Enter new password",
        StoragePasswordStage::ConfirmNew => "Confirm new password",
    }
}

/// Exact StorageDialog / MirInputBox layout. The background and Title button
/// frames come from the original Crystal libraries; text input is rendered as
/// a masked, keyboard-owned field at the source coordinates.
fn render_storage_password_modal(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    prompt: Option<&StoragePasswordPrompt>,
) {
    let Some(prompt) = prompt else {
        return;
    };
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.left),
                top: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.top),
                width: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.width),
                height: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.height),
                ..default()
            },
            BackgroundColor(PANEL_BG),
        ))
        .with_children(|dialog| {
            if let Some(asset_server) = asset_server {
                spawn_overlay_frame(
                    dialog,
                    asset_server,
                    "original-ui/Prguse/660.png",
                    CRYSTAL_STORAGE_PASSWORD_RECT.width,
                    CRYSTAL_STORAGE_PASSWORD_RECT.height,
                );
            }
            overlay_centered_text_at(
                dialog,
                &crate::native_i18n::tr(storage_password_caption(prompt.stage)),
                CrystalRect::new(25.0, 25.0, 235.0, 40.0),
                10.0,
                TEXT,
            );
            dialog
                .spawn((
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(23.0),
                        top: Val::Px(86.0),
                        width: Val::Px(240.0),
                        height: Val::Px(19.0),
                        border: UiRect::all(Val::Px(1.0)),
                        padding: UiRect::axes(Val::Px(2.0), Val::Px(0.0)),
                        align_items: AlignItems::Center,
                        overflow: Overflow::clip(),
                        ..default()
                    },
                    BackgroundColor(Color::BLACK),
                    BorderColor::all(if prompt.mismatch { Color::srgb(0.85, 0.22, 0.18) } else { GOLD }),
                ))
                .with_children(|field| {
                    field.spawn((
                        Text::new(prompt.masked()),
                        crate::crystal_ui::typography::crystal_text_font(10.0),
                        TextColor(TEXT),
                        TextLayout::new(Justify::Left, LineBreak::NoWrap),
                    ));
                });
            if prompt.mismatch {
                overlay_centered_text_at(
                    dialog,
                    &crate::native_i18n::tr("Passwords do not match."),
                    CrystalRect::new(25.0, 65.0, 235.0, 16.0),
                    9.0,
                    Color::srgb(0.95, 0.34, 0.28),
                );
            }
            if let Some(asset_server) = asset_server {
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    200,
                    201,
                    202,
                    CrystalRect::new(60.0, 123.0, 76.0, 25.0),
                    OverlayButton::StoragePasswordSubmit,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    203,
                    204,
                    205,
                    CrystalRect::new(160.0, 123.0, 76.0, 25.0),
                    OverlayButton::StoragePasswordCancel,
                );
            } else {
                overlay_absolute_button(
                    dialog,
                    &crate::native_i18n::tr("OK"),
                    CrystalRect::new(60.0, 123.0, 76.0, 25.0),
                    OverlayButton::StoragePasswordSubmit,
                    true,
                );
                overlay_absolute_button(
                    dialog,
                    &crate::native_i18n::tr("Cancel"),
                    CrystalRect::new(160.0, 123.0, 76.0, 25.0),
                    OverlayButton::StoragePasswordCancel,
                    true,
                );
            }
        });
}

/// StorageDialog.Rent opens MirMessageBox(OKCancel). It uses the same
/// centered Prguse[360] message frame as Crystal's other confirmations.
fn render_storage_rental_confirmation(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    confirmation: Option<StorageRentalConfirmation>,
) {
    let Some(confirmation) = confirmation else {
        return;
    };
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.left),
                top: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.top),
                width: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.width),
                height: Val::Px(CRYSTAL_DELETE_CONFIRM_RECT.height),
                overflow: Overflow::clip(),
                ..default()
            },
            BackgroundColor(Color::NONE),
        ))
        .with_children(|dialog| {
            if let Some(asset_server) = asset_server {
                spawn_overlay_frame(
                    dialog,
                    asset_server,
                    "original-ui/Prguse/360.png",
                    CRYSTAL_DELETE_CONFIRM_RECT.width,
                    CRYSTAL_DELETE_CONFIRM_RECT.height,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    206,
                    207,
                    208,
                    CrystalRect::new(260.0, 157.0, 76.0, 25.0),
                    OverlayButton::StorageRentalConfirm,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    210,
                    211,
                    212,
                    CrystalRect::new(360.0, 157.0, 76.0, 25.0),
                    OverlayButton::StorageRentalCancel,
                );
            } else {
                overlay_absolute_button(
                    dialog,
                    &crate::native_i18n::tr("OK"),
                    CrystalRect::new(260.0, 157.0, 76.0, 25.0),
                    OverlayButton::StorageRentalConfirm,
                    true,
                );
                overlay_absolute_button(
                    dialog,
                    &crate::native_i18n::tr("Cancel"),
                    CrystalRect::new(360.0, 157.0, 76.0, 25.0),
                    OverlayButton::StorageRentalCancel,
                    true,
                );
            }
            overlay_text_at(
                dialog,
                &crate::native_i18n::tr(confirmation.message()),
                CrystalRect::new(35.0, 35.0, 390.0, 110.0),
                10.0,
                TEXT,
            );
        });
}

fn render_guild_gold_modal(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    prompt: Option<&GuildGoldPrompt>,
) {
    if let Some(prompt) = prompt {
        render_gold_amount_modal(
            parent,
            asset_server,
            prompt.action.title(),
            &prompt.input,
            [
                OverlayButton::GuildGoldConfirm,
                OverlayButton::GuildGoldCancel,
                OverlayButton::GuildGoldClose,
            ],
        );
    }
}

fn render_gold_amount_modal(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    title: &str,
    input: &CrystalAmountInput,
    actions: [OverlayButton; 3],
) {
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.left),
                top: Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.top),
                width: Val::Px(204.0),
                height: Val::Px(109.0),
                ..default()
            },
            BackgroundColor(Color::NONE),
        ))
        .with_children(|dialog| {
            if let Some(asset_server) = asset_server {
                spawn_overlay_frame(
                    dialog,
                    asset_server,
                    "original-ui/Prguse/238.png",
                    204.0,
                    109.0,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Prguse2",
                    360,
                    361,
                    362,
                    CrystalRect::new(180.0, 3.0, 24.0, 21.0),
                    actions[2],
                );
                dialog
                    .spawn(Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(15.0),
                        top: Val::Px(34.0),
                        width: Val::Px(38.0),
                        height: Val::Px(34.0),
                        ..default()
                    })
                    .with_children(|cell| {
                        spawn_original_item_image(cell, asset_server, 116, 38, 34)
                    });
                // Invalid input hides OK, rather than drawing a dim replacement.
                if input.amount().is_some() {
                    spawn_overlay_crystal_button(
                        dialog,
                        asset_server,
                        "Title",
                        200,
                        201,
                        202,
                        CrystalRect::new(23.0, 76.0, 76.0, 25.0),
                        actions[0],
                    );
                }
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    203,
                    204,
                    205,
                    CrystalRect::new(110.0, 76.0, 76.0, 25.0),
                    actions[1],
                );
            }
            overlay_text_at(
                dialog,
                title,
                CrystalRect::new(19.0, 8.0, 158.0, 14.0),
                10.0,
                Color::WHITE,
            );
            let border = match input.amount() {
                None => Color::srgb(1.0, 0.0, 0.0),
                Some(amount) if amount == input.max_amount => Color::srgb(1.0, 0.647, 0.0),
                Some(_) => Color::srgb(0.0, 1.0, 0.0),
            };
            let mut field = dialog.spawn((
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(58.0),
                    top: Val::Px(43.0),
                    width: Val::Px(132.0),
                    height: Val::Px(19.0),
                    border: UiRect::all(Val::Px(1.0)),
                    padding: UiRect::axes(Val::Px(2.0), Val::Px(0.0)),
                    align_items: AlignItems::Center,
                    overflow: Overflow::clip(),
                    ..default()
                },
                BackgroundColor(Color::BLACK),
                BorderColor::all(border),
            ));
            if actions[0] == OverlayButton::TradeGoldConfirm {
                field.insert(OverlayTradeGoldInput);
            } else {
                field.insert(OverlayGuildGoldInput);
            }
            field.with_children(|field| {
                field.spawn((
                    Text::new(input.draft.clone()),
                    crate::crystal_ui::typography::crystal_text_font(10.0),
                    TextColor(Color::WHITE),
                    TextLayout::new(Justify::Left, LineBreak::NoWrap),
                ));
            });
        });
}

fn render_overlays(
    models: OverlayRenderModels,
    windows: Query<&Window, With<PrimaryWindow>>,
    mut panels: ParamSet<(
        ParamSet<(
            Query<&mut Node, With<OverlayRoot>>,
            Query<(Entity, &mut Node), With<OverlayInventory>>,
            Query<(Entity, &mut Node), With<OverlayEquipment>>,
            Query<(Entity, &mut Node), With<OverlayMenu>>,
            Query<(Entity, &mut Node), With<OverlaySkill>>,
            Query<(Entity, &mut Node), With<OverlayInspect>>,
            Query<(Entity, &mut Node), With<OverlayDeath>>,
            Query<(Entity, &mut Node), With<OverlayChatDraft>>,
        )>,
        ParamSet<(
            Query<(Entity, &mut Node), With<OverlayMail>>,
            Query<(Entity, &mut Node), With<OverlayBigMap>>,
            Query<(Entity, &mut Node), With<OverlayShop>>,
            Query<(Entity, &mut Node), With<OverlayGameShop>>,
            Query<(Entity, &mut Node), With<OverlayStorage>>,
            Query<(Entity, &mut Node), With<OverlayOptions>>,
            Query<(Entity, &mut Node), With<OverlaySocial>>,
            Query<(Entity, &mut Node, &mut GlobalZIndex), With<OverlayHelp>>,
        )>,
        ParamSet<(
            Query<(Entity, &mut Node), With<OverlayInventoryDeleteModal>>,
            Query<(Entity, &mut Node, &mut GlobalZIndex), With<OverlayInventoryDeleteCursor>>,
            Query<(Entity, &mut Node), With<OverlayGuildGoldModal>>,
            Query<(Entity, &mut Node), With<OverlayTrade>>,
            Query<(Entity, &mut Node), With<OverlayTradeGoldModal>>,
            Query<(Entity, &mut Node), With<OverlayStoragePasswordModal>>,
            Query<(Entity, &mut Node), With<OverlayStorageRentalModal>>,
            Query<(Entity, &mut Node), With<OverlayMailDeleteModal>>,
        )>,
        ParamSet<(
            Query<(Entity, &mut Node, &mut GlobalZIndex), With<OverlayMailReadLetter>>,
            Query<(Entity, &mut Node, &mut GlobalZIndex), With<OverlayMailReadParcel>>,
            Query<(Entity, &mut Node, &mut GlobalZIndex), With<OverlayMailComposeLetter>>,
            Query<(Entity, &mut Node, &mut GlobalZIndex), With<OverlayMailComposeParcel>>,
        )>,
    )>,
    mut commands: Commands,
    mut mail_cache: Local<MailRenderCache>,
    mut game_shop_cache: Local<GameShopRenderCache>,
    mut big_map_cache: Local<big_map_coordinates::RenderCache>,
    mut last_locale_revision: Local<u64>,
) {
    if *last_locale_revision != crate::native_i18n::revision() {
        mail_cache.key = None;
        game_shop_cache.key = None;
        big_map_cache.reset();
        *last_locale_revision = crate::native_i18n::revision();
    }
    let OverlayRenderModels {
        asset_server,
        wing_materials,
        game_shop_geometry,
        shell,
        state,
        inventory,
        inventory_feedback,
        mail,
        mail_ui,
        compose_ui,
        letter_window,
        letter_editor,
        parcel_ui,
        big_map,
        big_map_ui,
        ui,
        shop,
        shop_ui,
        game_shop,
        storage,
        storage_ui,
        skills,
        skill_binding,
        skill_persistence,
        social,
        combat_target,
    } = models;
    let in_game = shell.is_some_and(|model| model.screen == NativeShellScreen::InGame);
    {
        let mut all = panels.p0();
        for mut node in all.p0().iter_mut() {
            node.display = if in_game {
                Display::Flex
            } else {
                Display::None
            };
        }
        if !in_game {
            mail_cache.key = None;
            game_shop_cache.key = None;
            big_map_cache.reset();
            return;
        }

        fill_positioned_unindexed_panel(
            &mut commands,
            &mut all.p1(),
            state.inventory_window.left,
            state.inventory_window.top,
            // StorageDialog hides InventoryDialog while its password gate is
            // active, then restores the same positioned bag after unlock.
            state.inventory_open()
                && (!state.storage_open() || storage.transfers_unlocked()),
            |parent| {
                render_inventory(
                    parent,
                    asset_server.as_deref(),
                    &inventory,
                    &ui,
                    &state,
                    &inventory_feedback,
                    &social,
                    parcel_ui.as_deref(),
                )
            },
        );
        fill_panel(
            &mut commands,
            &mut all.p2(),
            state.equipment_open(),
            |parent| {
                render_equipment(
                    parent,
                    asset_server.as_deref(),
                    wing_materials.as_deref(),
                    &inventory,
                    &ui,
                    &state,
                    &skills,
                )
            },
        );
        fill_panel(&mut commands, &mut all.p3(), state.menu_open(), |parent| {
            render_menu(parent, asset_server.as_deref())
        });
        fill_panel(
            &mut commands,
            &mut all.p4(),
            state.core.skill_open(),
            |parent| {
                render_equipment(
                    parent,
                    asset_server.as_deref(),
                    wing_materials.as_deref(),
                    &inventory,
                    &ui,
                    &state,
                    &skills,
                )
            },
        );
        fill_panel(
            &mut commands,
            &mut all.p5(),
            state.inspect.is_some(),
            |parent| render_inspect(parent, &state, &inventory, parcel_ui.as_deref()),
        );
        let dead = ui.player.max_hp > 0 && ui.player.hp <= 0;
        fill_panel(&mut commands, &mut all.p6(), dead, render_death);
        fill_panel(&mut commands, &mut all.p7(), false, |_| {});
    }
    {
        let mut secondary = panels.p1();
        fill_mail_panel(
            &mut commands,
            &mut secondary.p0(),
            state.mail_open(),
            &mail,
            &mail_ui,
            &compose_ui,
            state.core.mail_compose.as_ref(),
            &inventory,
            &mut mail_cache,
            |parent| {
                render_mail(
                    parent,
                    asset_server.as_deref(),
                    &mail,
                    &mail_ui,
                    &inventory,
                    &state,
                    &compose_ui,
                )
            },
        );
        big_map_coordinates::fill_panel(
            &mut commands,
            &mut secondary.p1(),
            state.bigmap_open(),
            &big_map,
            &big_map_ui,
            &ui,
            asset_server.as_deref(),
            &mut big_map_cache,
        );
        fill_panel(
            &mut commands,
            &mut secondary.p2(),
            state.npc_shop_open(),
            |parent| {
                render_shop(
                    parent,
                    asset_server.as_deref(),
                    &shop,
                    &shop_ui,
                    &inventory,
                    &state,
                    &ui.player,
                )
            },
        );
        for (_, mut node) in &mut secondary.p3() {
            let position = state
                .game_shop_dialog
                .position
                .unwrap_or(Vec2::new(164.0, 146.0));
            node.left = Val::Px(position.x);
            node.top = Val::Px(position.y);
        }
        fill_game_shop_panel(
            &mut commands,
            &mut secondary.p3(),
            state.shop_open(),
            &game_shop,
            &state.game_shop_dialog,
            &ui,
            &inventory,
            &mut game_shop_cache,
            |parent| {
                game_shop_dialog::render(
                    parent,
                    asset_server.as_deref(),
                    &game_shop,
                    &ui,
                    &state,
                    &inventory,
                    game_shop_geometry.as_deref(),
                )
            },
        );
        fill_panel(
            &mut commands,
            &mut secondary.p4(),
            state.storage_open(),
            |parent| {
                render_storage(
                    parent,
                    asset_server.as_deref(),
                    &storage,
                    &storage_ui,
                    &inventory,
                    &state,
                    &ui.player,
                )
            },
        );
        fill_panel(
            &mut commands,
            &mut secondary.p5(),
            state.options_open(),
            |parent| render_options(parent, asset_server.as_deref(), &state.core),
        );
        fill_panel(
            &mut commands,
            &mut secondary.p6(),
            state.group_open()
                || state.guild_open()
                || (state.core.is_trade_open() && !state.trade_dialog.open),
            |parent| {
                render_social(
                    parent,
                    asset_server.as_deref(),
                    &social,
                    &state,
                    &inventory,
                    combat_target.as_deref(),
                    &ui.player,
                )
            },
        );
        fill_positioned_panel(
            &mut commands,
            &mut secondary.p7(),
            state.help.left,
            state.help.top,
            state.help.z_index(),
            state.help_open(),
            |parent| {
                render_help(
                    parent,
                    asset_server.as_deref(),
                    state.help.page,
                    &state.keyboard,
                )
            },
        );
    }
    {
        let reader = state.mail_reader.and_then(|reader| {
            mail.mails
                .iter()
                .find(|message| {
                    message.id == reader.mail_id
                        && message.operation.is_none()
                        && mail_reader_kind(message) == reader.kind
                })
                .map(|message| (reader, message))
        });
        let mut readers = panels.p3();
        fill_positioned_panel(
            &mut commands,
            &mut readers.p0(),
            state.mail_reader_windows.position(MailReaderKind::Letter).x,
            state.mail_reader_windows.position(MailReaderKind::Letter).y,
            OVERLAY_NPC_DIALOG_Z,
            reader.is_some_and(|(reader, _)| reader.kind == MailReaderKind::Letter),
            |parent| {
                if let Some((_, message)) = reader {
                    render_mail_reader_letter(parent, asset_server.as_deref(), message);
                }
            },
        );
        fill_positioned_panel(
            &mut commands,
            &mut readers.p1(),
            state.mail_reader_windows.position(MailReaderKind::Parcel).x,
            state.mail_reader_windows.position(MailReaderKind::Parcel).y,
            OVERLAY_NPC_DIALOG_Z,
            reader.is_some_and(|(reader, _)| reader.kind == MailReaderKind::Parcel),
            |parent| {
                if let Some((_, message)) = reader {
                    render_mail_reader_parcel(parent, asset_server.as_deref(), message);
                }
            },
        );
        fill_positioned_panel(
            &mut commands,
            &mut readers.p2(),
            letter_window
                .as_deref()
                .map_or(CRYSTAL_MAIL_LETTER_RECT.left, |window| window.position.x),
            letter_window
                .as_deref()
                .map_or(CRYSTAL_MAIL_LETTER_RECT.top, |window| window.position.y),
            OVERLAY_NPC_DIALOG_Z,
            state.mail_open()
                && state.core.mail_compose.is_some()
                && compose_ui.kind == MailComposeKind::Letter,
            |parent| {
                if let Some(draft) = state.core.mail_compose.as_ref() {
                    render_mail_compose_letter(
                        parent,
                        asset_server.as_deref(),
                        draft,
                        &compose_ui,
                        letter_editor.as_deref(),
                    );
                }
            },
        );
        fill_positioned_panel(
            &mut commands,
            &mut readers.p3(),
            parcel_ui
                .as_deref()
                .map_or(mail_parcel::MAIL_PARCEL_DEFAULT_POSITION.x, |parcel| parcel.window.position.x),
            parcel_ui
                .as_deref()
                .map_or(mail_parcel::MAIL_PARCEL_DEFAULT_POSITION.y, |parcel| parcel.window.position.y),
            OVERLAY_NPC_DIALOG_Z,
            state.mail_open()
                && state.core.mail_compose.is_some()
                && compose_ui.kind == MailComposeKind::Parcel,
            |parent| {
                if let (Some(draft), Some(parcel)) = (state.core.mail_compose.as_ref(), parcel_ui.as_deref()) {
                    mail_parcel::render(
                        parent,
                        asset_server.as_deref(),
                        draft,
                        &inventory,
                        parcel,
                        letter_editor.as_deref(),
                    );
                }
            },
        );
    }
    {
        let mut delete_layers = panels.p2();
        fill_panel(
            &mut commands,
            &mut delete_layers.p3(),
            state.trade_dialog.open,
            |parent| {
                trade_dialog::render(parent, asset_server.as_deref(), &social, &state, &ui.player);
            },
        );
        fill_panel(
            &mut commands,
            &mut delete_layers.p4(),
            state.trade_dialog.gold_prompt.is_some() || state.trade_dialog.message.is_some(),
            |parent| {
                if let Some(message) = &state.trade_dialog.message {
                    trade_dialog::render_message(parent, asset_server.as_deref(), message);
                } else if let Some(prompt) = &state.trade_dialog.gold_prompt {
                    render_gold_amount_modal(
                        parent,
                        asset_server.as_deref(),
                        "Trade Amount:",
                        &prompt.input,
                        [
                            OverlayButton::TradeGoldConfirm,
                            OverlayButton::TradeGoldCancel,
                            OverlayButton::TradeGoldClose,
                        ],
                    );
                }
            },
        );
        fill_panel(
            &mut commands,
            &mut delete_layers.p2(),
            state.guild_gold_prompt.is_some() || state.parcel_gold_prompt.is_some(),
            |parent| {
                if state.guild_gold_prompt.is_some() {
                    render_guild_gold_modal(
                        parent,
                        asset_server.as_deref(),
                        state.guild_gold_prompt.as_ref(),
                    );
                } else if let Some(input) = state.parcel_gold_prompt.as_ref() {
                    render_gold_amount_modal(
                        parent,
                        asset_server.as_deref(),
                        "Gold Amount:",
                        input,
                        [
                            OverlayButton::MailParcelGoldConfirm,
                            OverlayButton::MailParcelGoldCancel,
                            OverlayButton::MailParcelGoldCancel,
                        ],
                    );
                }
            },
        );
        fill_panel(
            &mut commands,
            &mut delete_layers.p0(),
            state.inventory_delete_prompt.is_some(),
            |parent| {
                render_inventory_delete_modal(parent, asset_server.as_deref(), &state, &inventory)
            },
        );
        fill_panel(
            &mut commands,
            &mut delete_layers.p5(),
            state.storage_password_prompt.is_some(),
            |parent| {
                render_storage_password_modal(
                    parent,
                    asset_server.as_deref(),
                    state.storage_password_prompt.as_ref(),
                )
            },
        );
        fill_panel(
            &mut commands,
            &mut delete_layers.p6(),
            state.storage_rental_confirmation.is_some(),
            |parent| {
                render_storage_rental_confirmation(
                    parent,
                    asset_server.as_deref(),
                    state.storage_rental_confirmation,
                )
            },
        );
        fill_panel(
            &mut commands,
            &mut delete_layers.p7(),
            compose_ui.recipient_prompt.is_some()
                || state.mail_delete_prompt.is_some()
                || state.mail_feedback_prompt.is_some(),
            |parent| {
                if let Some(prompt) = compose_ui.recipient_prompt.as_ref() {
                    render_mail_recipient_prompt(parent, asset_server.as_deref(), prompt);
                } else if let Some(message) = state.mail_feedback_prompt.as_deref() {
                    render_mail_feedback_modal(parent, asset_server.as_deref(), message);
                } else {
                    render_mail_delete_modal(parent, asset_server.as_deref());
                }
            },
        );

        let cursor = windows
            .single()
            .ok()
            .and_then(help_cursor_logical)
            .map(|cursor| {
                (
                    cursor.x - CRYSTAL_DELETE_CURSOR_SIZE.0 / 2.0,
                    cursor.y - CRYSTAL_DELETE_CURSOR_SIZE.1,
                )
            });
        let (cursor_left, cursor_top) = cursor.unwrap_or_default();
        fill_positioned_panel(
            &mut commands,
            &mut delete_layers.p1(),
            cursor_left,
            cursor_top,
            OVERLAY_INVENTORY_DELETE_CURSOR_Z,
            state.inventory_open() && state.inventory_delete_mode && cursor.is_some(),
            |parent| {
                if let Some(asset_server) = asset_server.as_deref() {
                    spawn_static_overlay_sprite(
                        parent,
                        asset_server,
                        "original-ui/Prguse2/366.png".to_owned(),
                        CrystalRect::new(
                            0.0,
                            0.0,
                            CRYSTAL_DELETE_CURSOR_SIZE.0,
                            CRYSTAL_DELETE_CURSOR_SIZE.1,
                        ),
                    );
                }
            },
        );
    }
}

fn fill_panel<C: Component>(
    commands: &mut Commands,
    query: &mut Query<(Entity, &mut Node), With<C>>,
    visible: bool,
    render: impl FnOnce(&mut ChildSpawnerCommands),
) {
    let Some((entity, mut node)) = query.iter_mut().next() else {
        return;
    };
    node.display = if visible {
        Display::Flex
    } else {
        Display::None
    };
    commands.entity(entity).despawn_children();
    if visible {
        commands.entity(entity).with_children(render);
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct MailRenderKey {
    root: Entity,
    model: MailModel,
    ui: MailUiState,
    compose_ui: MailComposeUi,
    compose: Option<mir2_ui_core::state::MailComposeDraft>,
    compose_inventory: Option<String>,
}

#[derive(Default)]
struct MailRenderCache {
    key: Option<MailRenderKey>,
}

fn fill_mail_panel(
    commands: &mut Commands,
    query: &mut Query<(Entity, &mut Node), With<OverlayMail>>,
    visible: bool,
    mail: &MailModel,
    mail_ui: &MailUiState,
    compose_ui: &MailComposeUi,
    compose: Option<&mir2_ui_core::state::MailComposeDraft>,
    inventory: &InventoryModel,
    cache: &mut MailRenderCache,
    render: impl FnOnce(&mut ChildSpawnerCommands),
) {
    let Some((entity, mut node)) = query.iter_mut().next() else {
        cache.key = None;
        return;
    };
    node.display = if visible { Display::Flex } else { Display::None };
    if !visible {
        if cache.key.take().is_some() {
            commands.entity(entity).despawn_children();
        }
        return;
    }
    let compose = compose.cloned();
    let key = MailRenderKey {
        root: entity,
        model: mail.clone(),
        ui: mail_ui.clone(),
        compose_ui: compose_ui.clone(),
        compose: compose.clone(),
        compose_inventory: compose
            .as_ref()
            .and_then(|_| serde_json::to_string(inventory).ok()),
    };
    if cache.key.as_ref() == Some(&key) {
        return;
    }
    commands.entity(entity).despawn_children();
    commands.entity(entity).with_children(render);
    cache.key = Some(key);
}

struct GameShopRenderKey {
    root: Entity,
    model: GameShopModel,
    dialog: String,
    player: String,
    inventory: String,
}

#[derive(Default)]
struct GameShopRenderCache {
    key: Option<GameShopRenderKey>,
}

impl PartialEq for GameShopRenderKey {
    fn eq(&self, other: &Self) -> bool {
        self.root == other.root
            && self.model == other.model
            && self.dialog == other.dialog
            && self.player == other.player
            && self.inventory == other.inventory
    }
}

fn fill_game_shop_panel(
    commands: &mut Commands,
    query: &mut Query<(Entity, &mut Node), With<OverlayGameShop>>,
    visible: bool,
    model: &GameShopModel,
    dialog: &game_shop_dialog::GameShopDialogUi,
    ui: &UiReadModel,
    inventory: &InventoryModel,
    cache: &mut GameShopRenderCache,
    render: impl FnOnce(&mut ChildSpawnerCommands),
) {
    let Some((entity, mut node)) = query.iter_mut().next() else {
        cache.key = None;
        return;
    };
    node.display = if visible { Display::Flex } else { Display::None };
    if !visible {
        if cache.key.take().is_some() {
            commands.entity(entity).despawn_children();
        }
        return;
    }

    // Keep the editor's actual child tree alive while caret/selection layout is
    // being captured. The preview frame is the only per-frame value here so an
    // open paper-doll keeps animating without rebuilding an active editor.
    let editor = dialog.search_input.display_editor();
    let dialog_key = format!(
        "{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}|{:?}",
        dialog.class,
        dialog.section,
        dialog.new_visible,
        &dialog.category,
        dialog.category_start,
        &dialog.search,
        dialog.search_focused,
        &dialog.search_input.modal,
        dialog.search_input.editor_revision,
        editor,
        &dialog.quantities,
        &dialog.confirmation,
        dialog.preview,
        dialog.preview_left,
        dialog.direction,
        dialog.shift,
        dialog.preview.map(|_| dialog.frame_ms / 150),
    );
    let player_key = format!(
        "{:?}",
        (
            ui.player.class_name.as_deref(),
            ui.player.gender.as_deref(),
            ui.player.gold,
            ui.player.credit,
        )
    );
    let inventory_key = serde_json::to_string(inventory)
        .unwrap_or_else(|_| format!("{inventory:?}"));
    let key = GameShopRenderKey {
        root: entity,
        model: model.clone(),
        dialog: dialog_key,
        player: player_key,
        inventory: inventory_key,
    };
    if cache.key.as_ref() == Some(&key) {
        return;
    }
    commands.entity(entity).despawn_children();
    commands.entity(entity).with_children(render);
    cache.key = Some(key);
}

fn fill_positioned_unindexed_panel<C: Component>(
    commands: &mut Commands,
    query: &mut Query<(Entity, &mut Node), With<C>>,
    left: f32,
    top: f32,
    visible: bool,
    render: impl FnOnce(&mut ChildSpawnerCommands),
) {
    let Some((entity, mut node)) = query.iter_mut().next() else {
        return;
    };
    node.left = Val::Px(left);
    node.top = Val::Px(top);
    node.display = if visible {
        Display::Flex
    } else {
        Display::None
    };
    commands.entity(entity).despawn_children();
    if visible {
        commands.entity(entity).with_children(render);
    }
}

fn fill_positioned_panel<C: Component>(
    commands: &mut Commands,
    query: &mut Query<(Entity, &mut Node, &mut GlobalZIndex), With<C>>,
    left: f32,
    top: f32,
    z_index: i32,
    visible: bool,
    render: impl FnOnce(&mut ChildSpawnerCommands),
) {
    let Some((entity, mut node, mut rendered_z_index)) = query.iter_mut().next() else {
        return;
    };
    node.left = Val::Px(left);
    node.top = Val::Px(top);
    *rendered_z_index = GlobalZIndex(z_index);
    node.display = if visible {
        Display::Flex
    } else {
        Display::None
    };
    commands.entity(entity).despawn_children();
    if visible {
        commands.entity(entity).with_children(render);
    }
}

fn render_inventory(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    inventory: &InventoryModel,
    ui: &UiReadModel,
    state: &NativePlayerUiState,
    feedback: &InventoryOperationFeedback,
    social: &crate::social::SocialModel,
    parcel: Option<&mail_parcel::MailParcelUi>,
) {
    if let Some(asset_server) = asset_server {
        spawn_overlay_frame(
            parent,
            asset_server,
            "original-ui/Title/196.png",
            INVENTORY_PANEL_SIZE.width as f32,
            INVENTORY_PANEL_SIZE.height as f32,
        );
        spawn_inventory_tab(
            parent,
            asset_server,
            6.0,
            7.0,
            197,
            737,
            state.inventory_page == 0,
            OverlayButton::SelectInventoryPage(0),
        );
        let second_tab_index = inventory_second_tab_index(inventory, state.inventory_page == 1);
        spawn_inventory_tab(
            parent,
            asset_server,
            76.0,
            7.0,
            second_tab_index,
            second_tab_index,
            state.inventory_page == 1,
            OverlayButton::SelectInventoryPage(1),
        );
        spawn_inventory_tab(
            parent,
            asset_server,
            146.0,
            7.0,
            198,
            739,
            state.inventory_page == 2,
            OverlayButton::SelectInventoryPage(2),
        );
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Prguse2",
            360,
            361,
            362,
            CrystalRect::new(289.0, 3.0, 24.0, 21.0),
            OverlayButton::CloseWindows,
        );
        overlay_text_at(
            parent,
            &format_crystal_gold(inventory.gold),
            CrystalRect::new(
                INVENTORY_GOLD_LABEL_ORIGIN.x as f32,
                INVENTORY_GOLD_LABEL_ORIGIN.y as f32,
                INVENTORY_GOLD_LABEL_SIZE.width as f32,
                INVENTORY_GOLD_LABEL_SIZE.height as f32,
            ),
            10.0,
            TEXT,
        );
        spawn_inventory_weight_bar(parent, asset_server, ui.player.normalized_weight());
        overlay_text_at(
            parent,
            &free_inventory_slots(inventory).to_string(),
            CrystalRect::new(
                INVENTORY_FREE_SLOT_LABEL_ORIGIN.x as f32,
                INVENTORY_FREE_SLOT_LABEL_ORIGIN.y as f32,
                INVENTORY_FREE_SLOT_LABEL_SIZE.width as f32,
                INVENTORY_FREE_SLOT_LABEL_SIZE.height as f32,
            ),
            10.0,
            TEXT,
        );
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            if state.inventory_delete_mode {
                368
            } else {
                366
            },
            if state.inventory_delete_mode {
                368
            } else {
                367
            },
            368,
            CrystalRect::new(
                INVENTORY_DELETE_BUTTON_ORIGIN.x as f32,
                INVENTORY_DELETE_BUTTON_ORIGIN.y as f32,
                INVENTORY_DELETE_BUTTON_SIZE.width as f32,
                INVENTORY_DELETE_BUTTON_SIZE.height as f32,
            ),
            OverlayButton::InventoryDeleteToggle,
            true,
        );
        let (container, page_offset) = if state.inventory_page == 2 {
            (3, 0)
        } else {
            (0, usize::from(state.inventory_page) * INVENTORY_PAGE_SIZE)
        };
        parent
            .spawn((
                OverlayInventoryGridViewport,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(INVENTORY_GRID_ORIGIN.x as f32),
                    top: Val::Px(INVENTORY_GRID_ORIGIN.y as f32),
                    width: Val::Px(
                        (INVENTORY_GRID_STEP.x as usize * (INVENTORY_PAGE_COLUMNS - 1)
                            + INVENTORY_CELL_SIZE.width as usize) as f32,
                    ),
                    height: Val::Px(
                        (INVENTORY_GRID_STEP.y as usize
                            * (INVENTORY_PAGE_SIZE / INVENTORY_PAGE_COLUMNS - 1)
                            + INVENTORY_CELL_SIZE.height as usize) as f32,
                    ),
                    ..default()
                },
                BackgroundColor(Color::NONE),
            ))
            .with_children(|grid| {
                let page_items = inventory.items_in(container);
                for local_slot in 0..INVENTORY_PAGE_SIZE {
                    let slot = (page_offset + local_slot) as u32;
                    if container == 0 && slot >= u32::from(inventory.bag_slot_capacity()) {
                        continue;
                    }
                    let item = page_items
                        .iter()
                        .copied()
                        .find(|item| item.slot == slot)
                        .filter(|item| {
                            container != 0 || !trade_dialog::offered_bag_item(social, item)
                        });
                    let mail_locked = container == 0
                        && item
                            .and_then(item_unique_id)
                            .is_some_and(|unique_id| parcel.is_some_and(|parcel| parcel.blocks_item(unique_id)));
                    let enabled = !mail_locked && if container == 3 {
                        item.is_some()
                    } else {
                        match &state.inventory_operation {
                            Some(InventoryOperationDraft::Move { source_slot, .. }) => {
                                *source_slot != slot
                            }
                            Some(InventoryOperationDraft::Merge { source_slot, .. }) => {
                                *source_slot != slot && item.and_then(item_unique_id).is_some()
                            }
                            None => item.is_some(),
                        }
                    };
                    let x =
                        (local_slot % INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.x as f32;
                    let y =
                        (local_slot / INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.y as f32;
                    let rect = CrystalRect::new(
                        x,
                        y,
                        INVENTORY_CELL_SIZE.width as f32,
                        INVENTORY_CELL_SIZE.height as f32,
                    );
                    let button = if container == 3 {
                        OverlayButton::InspectQuest(slot)
                    } else {
                        OverlayButton::InspectBag(slot)
                    };
                    if let Some(item) = item {
                        overlay_absolute_item_button(
                            grid,
                            asset_server,
                            item,
                            rect,
                            button,
                            enabled,
                            mail_locked,
                            &ui.player,
                        );
                    } else {
                        overlay_absolute_inventory_cell(grid, rect, button, enabled);
                    }
                    if container == 0 {
                        trade_dialog::draw_selection(grid, state, true, slot as usize, rect);
                        hero_dialog::cross::draw_player_selection(grid, state, slot, rect);
                    }
                }
            });
        return;
    }

    title(parent, &crate::native_i18n::tr("Bag"));
    body(parent, &crate::native_i18n::tr(&format!("{} Gold", inventory.gold)));
    if let Some(draft) = &state.inventory_operation {
        let instruction = match draft {
            InventoryOperationDraft::Move { source_slot, .. } => {
                format!("Move source {source_slot}: select a different destination slot")
            }
            InventoryOperationDraft::Merge { source_slot, .. } => {
                format!("Merge source {source_slot}: select a different occupied slot")
            }
        };
        body(parent, &instruction);
    }
    if let Some(ack) = &feedback.last {
        body(
            parent,
            &crate::native_i18n::tr(&format!(
                "{}: {} (inventory remains server-authoritative)",
                ack.label(),
                if ack.success() {
                    "accepted"
                } else {
                    "rejected"
                }
            )),
        );
    }
    parent
        .spawn(Node {
            display: Display::Flex,
            flex_direction: FlexDirection::Row,
            flex_wrap: bevy::ui::FlexWrap::Wrap,
            column_gap: Val::Px(2.0),
            row_gap: Val::Px(2.0),
            ..default()
        })
        .with_children(|grid| {
            for slot in 0..BAG_SLOTS {
                let item = inventory
                    .items_in(0)
                    .into_iter()
                    .find(|item| item.slot == slot);
                let label = item
                    .map(|item| {
                        if item.quantity > 1 {
                            format!("{} x{}", short_name(&item.name, &item.key), item.quantity)
                        } else {
                            short_name(&item.name, &item.key)
                        }
                    })
                    .unwrap_or_default();
                let enabled = !item
                    .and_then(item_unique_id)
                    .is_some_and(|unique_id| parcel.is_some_and(|parcel| parcel.blocks_item(unique_id)))
                    && match &state.inventory_operation {
                    Some(InventoryOperationDraft::Move { source_slot, .. }) => *source_slot != slot,
                    Some(InventoryOperationDraft::Merge { source_slot, .. }) => {
                        *source_slot != slot && item.and_then(item_unique_id).is_some()
                    }
                    None => item.is_some(),
                };
                overlay_button(grid, &label, OverlayButton::InspectBag(slot), enabled);
            }
        });
    overlay_button(parent, &crate::native_i18n::tr("Close"), OverlayButton::CloseWindows, true);
}

fn format_crystal_gold(gold: u32) -> String {
    let digits = gold.to_string();
    let mut output = String::with_capacity(digits.len() + digits.len() / 3);
    for (index, digit) in digits.chars().enumerate() {
        if index > 0 && (digits.len() - index) % 3 == 0 {
            output.push(',');
        }
        output.push(digit);
    }
    output
}

fn inventory_weight_bar_asset(ratio: f32) -> (&'static str, u16) {
    if ratio <= 0.50 {
        ("Prguse", 24)
    } else if ratio <= 0.75 {
        ("UI_32bit", 471)
    } else {
        ("UI_32bit", 470)
    }
}

fn inventory_weight_bar_width(ratio: f32) -> f32 {
    ((INVENTORY_WEIGHT_BAR_SIZE.width as f32 - 3.0) * ratio.clamp(0.0, 1.0)).floor()
}

fn spawn_inventory_weight_bar(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    ratio: f32,
) {
    let width = inventory_weight_bar_width(ratio);
    if width <= 0.0 {
        return;
    }
    let (library, index) = inventory_weight_bar_asset(ratio);
    parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(INVENTORY_WEIGHT_BAR_ORIGIN.x as f32),
            top: Val::Px(INVENTORY_WEIGHT_BAR_ORIGIN.y as f32),
            width: Val::Px(width),
            height: Val::Px(INVENTORY_WEIGHT_BAR_SIZE.height as f32),
            overflow: Overflow::clip(),
            ..default()
        },
        ImageNode {
            image: asset_server.load(format!("original-ui/{library}/{index}.png")),
            rect: Some(bevy::math::Rect {
                min: Vec2::ZERO,
                max: Vec2::new(width, INVENTORY_WEIGHT_BAR_SIZE.height as f32),
            }),
            ..default()
        },
    ));
}

fn crystal_character_gender_offset(gender: Option<&str>) -> Option<u16> {
    let gender = gender?.trim();
    if gender.eq_ignore_ascii_case("male") {
        Some(0)
    } else if gender.eq_ignore_ascii_case("female") {
        Some(1)
    } else {
        None
    }
}

fn crystal_character_page_index(gender: Option<&str>) -> u16 {
    // A missing legacy gender keeps the structural page usable, while the
    // actual appearance layers below remain fail-closed.
    340 + crystal_character_gender_offset(gender).unwrap_or_default()
}

fn crystal_character_class_image_index(class_name: Option<&str>) -> Option<u16> {
    let class_name = class_name?.trim();
    if class_name.eq_ignore_ascii_case("warrior") {
        Some(100)
    } else if class_name.eq_ignore_ascii_case("wizard") {
        Some(101)
    } else if class_name.eq_ignore_ascii_case("taoist") {
        Some(102)
    } else if class_name.eq_ignore_ascii_case("assassin") {
        Some(103)
    } else if class_name.eq_ignore_ascii_case("archer") {
        Some(104)
    } else {
        None
    }
}

fn crystal_character_guild_label(ui: &UiReadModel) -> String {
    [
        ui.player.guild_name.as_deref(),
        ui.player.guild_rank_name.as_deref(),
    ]
    .into_iter()
    .flatten()
    .map(str::trim)
    .filter(|value| !value.is_empty())
    .collect::<Vec<_>>()
    .join(" ")
}

fn crystal_character_hair_frame(
    class_name: Option<&str>,
    gender: Option<&str>,
    hair: Option<u8>,
) -> Option<CrystalFrameSpec> {
    let gender_offset = crystal_character_gender_offset(gender)?;
    let hair = usize::from(hair?);
    if hair >= CRYSTAL_MALE_HAIR_RECTS.len() {
        return None;
    }
    let assassin = class_name
        .map(str::trim)
        .is_some_and(|value| value.eq_ignore_ascii_case("assassin"));
    let (base, mut rect) = match (gender_offset, assassin) {
        (0, false) => (441, CRYSTAL_MALE_HAIR_RECTS[hair]),
        (0, true) => (461, CRYSTAL_ASSASSIN_MALE_HAIR_RECTS[hair]),
        (1, false) => (481, CRYSTAL_FEMALE_HAIR_RECTS[hair]),
        (1, true) => (501, CRYSTAL_ASSASSIN_FEMALE_HAIR_RECTS[hair]),
        _ => return None,
    };
    // CharacterDialog.cs applies these offsets on top of the source frame's
    // intrinsic `useOffset=true` x/y for Assassin hair only.
    if assassin {
        rect.left += if gender_offset == 0 { 6.0 } else { 4.0 };
        rect.top += if gender_offset == 0 { 25.0 } else { 18.0 };
    }
    Some(CrystalFrameSpec::new("Prguse", base + hair as u16, rect))
}

fn crystal_character_state_item_frame(item: &ItemModel) -> Option<CrystalFrameSpec> {
    if item.state_image == 0 || item.state_image_width == 0 || item.state_image_height == 0 {
        return None;
    }
    Some(CrystalFrameSpec::new(
        "StateItem",
        item.state_image,
        CrystalRect::new(
            item.state_image_x as f32,
            item.state_image_y as f32,
            item.state_image_width as f32,
            item.state_image_height as f32,
        ),
    ))
}

fn crystal_character_wing_frame(
    wing_effect: Option<u8>,
    gender: Option<&str>,
) -> Option<CrystalFrameSpec> {
    let gender_offset = crystal_character_gender_offset(gender)?;
    let wing_offset = match wing_effect? {
        1 => 2,
        2 => 4,
        _ => return None,
    };
    let index = 1200 + wing_offset + gender_offset;
    // Exact `Prguse2` intrinsic rectangles (`useOffset=true`) exported from
    // the same Crystal library consumed by CharacterDialog.cs.
    let rect = match index {
        1202 => CrystalRect::new(64.0, 138.0, 148.0, 139.0),
        1203 => CrystalRect::new(64.0, 145.0, 148.0, 144.0),
        1204 => CrystalRect::new(55.0, 140.0, 156.0, 185.0),
        1205 => CrystalRect::new(56.0, 144.0, 156.0, 185.0),
        _ => return None,
    };
    Some(CrystalFrameSpec::new("Prguse2", index, rect))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum CrystalCharacterBlend {
    Alpha,
    DrawBlend,
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct CrystalCharacterLayer {
    frame: CrystalFrameSpec,
    blend: CrystalCharacterBlend,
}

impl CrystalCharacterLayer {
    const fn alpha(frame: CrystalFrameSpec) -> Self {
        Self {
            frame,
            blend: CrystalCharacterBlend::Alpha,
        }
    }

    const fn draw_blend(frame: CrystalFrameSpec) -> Self {
        Self {
            frame,
            blend: CrystalCharacterBlend::DrawBlend,
        }
    }
}

fn spawn_character_layer(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    wing_materials: Option<&CrystalCharacterWingMaterials>,
    layer: CrystalCharacterLayer,
) {
    match layer.blend {
        CrystalCharacterBlend::Alpha => {
            spawn_static_overlay_sprite(
                parent,
                asset_server,
                layer.frame.asset_path(),
                layer.frame.rect,
            );
        }
        CrystalCharacterBlend::DrawBlend => {
            let Some(material) =
                wing_materials.and_then(|materials| materials.get(layer.frame.index))
            else {
                return;
            };
            parent.spawn((
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(layer.frame.rect.left),
                    top: Val::Px(layer.frame.rect.top),
                    width: Val::Px(layer.frame.rect.width),
                    height: Val::Px(layer.frame.rect.height),
                    ..default()
                },
                MaterialNode(material.clone()),
            ));
        }
    }
}

fn crystal_character_paper_doll_layers(
    inventory: &InventoryModel,
    ui: &UiReadModel,
) -> Vec<CrystalCharacterLayer> {
    let equipped = |slot| {
        inventory
            .items
            .iter()
            .find(|item| item.container == 2 && item.slot == slot)
    };
    let mut layers = Vec::with_capacity(4);

    // Exact CharacterPage.AfterDraw condition and order: a wing is legal only
    // while an armour item exists, then armour, weapon, and helmet-or-hair.
    if let Some(armour) = equipped(1) {
        if let Some(frame) =
            crystal_character_wing_frame(ui.player.wing_effect, ui.player.gender.as_deref())
        {
            layers.push(CrystalCharacterLayer::draw_blend(frame));
        }
        if let Some(frame) = crystal_character_state_item_frame(armour) {
            layers.push(CrystalCharacterLayer::alpha(frame));
        }
    }
    if let Some(frame) = equipped(0).and_then(crystal_character_state_item_frame) {
        layers.push(CrystalCharacterLayer::alpha(frame));
    }
    if let Some(helmet) = equipped(2) {
        if let Some(frame) = crystal_character_state_item_frame(helmet) {
            layers.push(CrystalCharacterLayer::alpha(frame));
        }
    } else if let Some(frame) = crystal_character_hair_frame(
        ui.player.class_name.as_deref(),
        ui.player.gender.as_deref(),
        ui.player.hair,
    ) {
        layers.push(CrystalCharacterLayer::alpha(frame));
    }
    layers
}

fn render_character_paper_doll(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    wing_materials: Option<&CrystalCharacterWingMaterials>,
    inventory: &InventoryModel,
    ui: &UiReadModel,
) {
    for layer in crystal_character_paper_doll_layers(inventory, ui) {
        spawn_character_layer(parent, asset_server, wing_materials, layer);
    }
}

fn render_equipment(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    wing_materials: Option<&CrystalCharacterWingMaterials>,
    inventory: &InventoryModel,
    ui: &UiReadModel,
    state: &NativePlayerUiState,
    skills: &SkillModel,
) {
    if let Some(asset_server) = asset_server {
        spawn_overlay_frame(
            parent,
            asset_server,
            "original-ui/Title/504.png",
            264.0,
            380.0,
        );
        let (page_index, page_rect) = match state.character_page {
            CharacterPage::Character => (
                crystal_character_page_index(ui.player.gender.as_deref()),
                CRYSTAL_CHARACTER_PAGE_RECT,
            ),
            CharacterPage::Stats1 => (506, CRYSTAL_CHARACTER_PAGE_RECT),
            CharacterPage::Stats2 => (507, CRYSTAL_CHARACTER_PAGE_RECT),
            CharacterPage::Spells => (508, CRYSTAL_CHARACTER_PAGE_RECT),
        };
        let page_library = if matches!(state.character_page, CharacterPage::Character) {
            "Prguse"
        } else {
            "Title"
        };
        spawn_static_overlay_sprite(
            parent,
            asset_server,
            format!("original-ui/{page_library}/{page_index}.png"),
            page_rect,
        );

        for (page, left, index) in [
            (CharacterPage::Character, 8.0, 500),
            (CharacterPage::Stats1, 70.0, 501),
            (CharacterPage::Stats2, 132.0, 502),
            (CharacterPage::Spells, 194.0, 503),
        ] {
            spawn_invisible_overlay_button(
                parent,
                CrystalRect::new(left, 70.0, 64.0, 20.0),
                OverlayButton::SelectCharacterPage(page),
            );
            if state.character_page == page {
                spawn_static_overlay_sprite(
                    parent,
                    asset_server,
                    format!("original-ui/Title/{index}.png"),
                    CrystalRect::new(left, 70.0, 64.0, 20.0),
                );
            }
            if crate::native_i18n::active() {
                let caption = match page { CharacterPage::Character => "Equipment", CharacterPage::Stats1 => "Status", CharacterPage::Stats2 => "Statistics", CharacterPage::Spells => "Skills" };
                localized_art_label(parent, caption, CrystalRect::new(left + 1.0, 71.0, 60.0, 18.0), 9.0);
            }
        }
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Prguse2",
            360,
            361,
            362,
            CrystalRect::new(241.0, 3.0, 24.0, 21.0),
            OverlayButton::CloseCharacter,
        );
        overlay_centered_text_at(
            parent,
            ui.player.name.as_deref().unwrap_or(""),
            CrystalRect::new(0.0, 12.0, 264.0, 20.0),
            12.0,
            TEXT,
        );
        overlay_centered_text_at(
            parent,
            &crystal_character_guild_label(ui),
            CrystalRect::new(0.0, 33.0, 264.0, 30.0),
            10.0,
            TEXT,
        );
        if let Some(index) = crystal_character_class_image_index(ui.player.class_name.as_deref()) {
            spawn_static_overlay_sprite(
                parent,
                asset_server,
                format!("original-ui/Prguse/{index}.png"),
                CrystalRect::new(15.0, 33.0, 32.0, 32.0),
            );
        }

        match state.character_page {
            CharacterPage::Character => {
                for (slot, rect) in CRYSTAL_CHARACTER_EQUIPMENT_SLOTS {
                    let item = inventory
                        .items_in(2)
                        .into_iter()
                        .find(|item| item.slot == slot);
                    if let Some(item) = item {
                        overlay_absolute_item_button(
                            parent,
                            asset_server,
                            item,
                            rect,
                            OverlayButton::InspectEquip(slot),
                            true,
                            false,
                            &ui.player,
                        );
                    }
                }
                // CharacterPage.AfterDraw runs after its MirItemCell children.
                render_character_paper_doll(parent, asset_server, wing_materials, inventory, ui);
            }
            CharacterPage::Stats1 | CharacterPage::Stats2 => {
                if crate::native_i18n::active() {
                    let labels: &[&str] = if state.character_page == CharacterPage::Stats2 {
                        &["Experience", "Bag weight", "Equipment weight", "Hand weight", "Magic resistance", "Poison resistance", "Health recovery", "Mana recovery", "Poison recovery", "Holy Power", "Frost Power", "Poison Power"]
                    } else {
                        &["HP", "MP", "AC", "MAC", "DC", "MC", "SC", "Critical chance", "Critical damage", "Attack speed", "Accuracy", "Agility", "Luck"]
                    };
                    for (row, label) in labels.iter().enumerate() {
                        localized_art_label(parent, label, CrystalRect::new(14.0, 107.0 + row as f32 * 18.0, 115.0, 18.0), 9.0);
                    }
                }
                let weights = ui
                    .player
                    .weights
                    .map(|weights| character_stats::Weights {
                        bag: Some(i64::from(weights.bag)),
                        wear: Some(i64::from(weights.wear)),
                        hand: Some(i64::from(weights.hand)),
                    })
                    .unwrap_or_default();
                for (text, top) in character_stats::lines(
                    &ui.player,
                    state.character_page == CharacterPage::Stats2,
                    weights,
                ) {
                    overlay_text_at(
                        parent,
                        &text,
                        CrystalRect::new(134., top, 105., 16.),
                        32. / 3.,
                        TEXT,
                    );
                }
            }
            CharacterPage::Spells => skill_page::render(parent, Some(asset_server), skills, state),
        }
        return;
    }

    title(parent, &crate::native_i18n::tr("Character / Equipment"));
    let player = &ui.player;
    body(
        parent,
        &crate::native_i18n::tr(&format!(
            "{}  {}  Lv{}",
            player.name.as_deref().unwrap_or("-"),
            player.class_name.as_deref().unwrap_or("-"),
            player.level
        )),
    );
    body(
        parent,
        &crate::native_i18n::tr(&format!(
            "HP {}  MP {}  EXP {}",
            player.hp_label(),
            player.mp_label(),
            player.experience_percent_label()
        )),
    );
    body(
        parent,
        &crate::native_i18n::tr(&format!(
            "Weight {}/{}  Gold {}",
            player.current_weight,
            player.max_weight,
            player.gold_label()
        )),
    );
    for slot in 0..14 {
        let item = inventory
            .items_in(2)
            .into_iter()
            .find(|item| item.slot == slot);
        let line = item
            .map(|item| {
                format!(
                    "{}: {}",
                    equipment_slot_name(slot),
                    short_name(&item.name, &item.key)
                )
            })
            .unwrap_or_else(|| format!("{}: --", equipment_slot_name(slot)));
        overlay_button(
            parent,
            &line,
            OverlayButton::InspectEquip(slot),
            item.is_some(),
        );
    }
    overlay_button(parent, &crate::native_i18n::tr("Close"), OverlayButton::CloseWindows, true);
}

fn spawn_overlay_frame(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    path: &'static str,
    width: f32,
    height: f32,
) {
    parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(0.0),
            top: Val::Px(0.0),
            width: Val::Px(width),
            height: Val::Px(height),
            ..default()
        },
        ImageNode {
            image: asset_server.load(path),
            ..default()
        },
    ));
    if crate::native_i18n::active() {
        let caption = match path {
            "original-ui/Prguse/920.png" => Some("Help"),
            "original-ui/Title/670.png" | "original-ui/Title/671.png" => Some("Mail"),
            _ => None,
        };
        if let Some(caption) = caption { localized_art_label(parent, caption, CrystalRect::new(8.0, 4.0, width - 40.0, 22.0), 12.0); }
    }
}

fn spawn_inventory_tab(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    left: f32,
    top: f32,
    active_index: u16,
    idle_index: u16,
    active: bool,
    action: OverlayButton,
) {
    let index = if active { active_index } else { idle_index };
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Title",
        index,
        index,
        index,
        CrystalRect::new(left, top, 72.0, 23.0),
        action,
    );
}

fn inventory_second_tab_index(inventory: &InventoryModel, active: bool) -> u16 {
    if !inventory.second_bag_unlocked() {
        169
    } else if active {
        168
    } else {
        738
    }
}

fn overlay_text_at(
    parent: &mut ChildSpawnerCommands,
    text: &str,
    rect: CrystalRect,
    font_size: f32,
    color: Color,
) {
    parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            overflow: Overflow::clip(),
            ..default()
        },
        Text::new(text.to_owned()),
        crate::crystal_ui::typography::crystal_text_font(font_size),
        TextColor(color),
        TextLayout::new(Justify::Left, LineBreak::NoWrap),
    ));
}

/// Replace only a baked label rectangle; never alter the surrounding frame or
/// the independent button action. This prevents two languages being overpainted.
pub(super) fn localized_art_label(parent: &mut ChildSpawnerCommands, source: &str, rect: CrystalRect, size: f32) {
    parent.spawn((Node { position_type: PositionType::Absolute, left: Val::Px(rect.left), top: Val::Px(rect.top), width: Val::Px(rect.width), height: Val::Px(rect.height), align_items: AlignItems::Center, justify_content: JustifyContent::Center, overflow: Overflow::clip(), ..default() }, BackgroundColor(Color::srgb(0.055, 0.045, 0.03)), FocusPolicy::Pass))
        .with_children(|label| { label.spawn((Text::new(crate::native_i18n::tr(source)), crate::crystal_ui::typography::crystal_text_font(size), TextColor(TEXT), TextLayout::new(Justify::Center, LineBreak::WordBoundary), FocusPolicy::Pass)); });
}

fn overlay_centered_text_at(
    parent: &mut ChildSpawnerCommands,
    text: &str,
    rect: CrystalRect,
    font_size: f32,
    color: Color,
) {
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(rect.left),
                top: Val::Px(rect.top),
                width: Val::Px(rect.width),
                height: Val::Px(rect.height),
                align_items: AlignItems::Center,
                justify_content: JustifyContent::Center,
                overflow: Overflow::clip(),
                ..default()
            },
            BackgroundColor(Color::NONE),
        ))
        .with_children(|container| {
            container.spawn((
                Text::new(text.to_owned()),
                crate::crystal_ui::typography::crystal_text_font(font_size),
                TextColor(color),
                TextLayout::new(Justify::Center, LineBreak::NoWrap),
            ));
        });
}

fn overlay_absolute_button(
    parent: &mut ChildSpawnerCommands,
    label: &str,
    rect: CrystalRect,
    action: OverlayButton,
    enabled: bool,
) {
    let mut entity = parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            padding: UiRect::all(Val::Px(2.0)),
            align_items: AlignItems::Center,
            justify_content: JustifyContent::Center,
            overflow: Overflow::clip(),
            ..default()
        },
        BackgroundColor(if enabled {
            Color::srgba(0.10, 0.07, 0.03, 0.62)
        } else {
            Color::srgba(0.25, 0.20, 0.12, 0.28)
        }),
    ));
    if enabled {
        entity.insert((Button, action));
    }
    if !label.is_empty() {
        entity.with_children(|button| {
            button.spawn((
                Text::new(label.to_owned()),
                crate::crystal_ui::typography::crystal_text_font(9.0),
                TextColor(if enabled {
                    TEXT
                } else {
                    Color::srgba(0.75, 0.70, 0.60, 0.45)
                }),
                TextLayout::new(Justify::Center, LineBreak::NoWrap),
            ));
        });
    }
}

/// Crystal inventory/equipment cells draw original pixels, without substituting
/// abbreviated names for missing icons or clipping images to the hit rectangle.
/// Only stack counts are drawn over bag icons: full durability values such as
/// `400/400` do not fit a 32-pixel Crystal cell and belong in item details.
fn overlay_absolute_item_button(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    item: &ItemModel,
    rect: CrystalRect,
    action: OverlayButton,
    enabled: bool,
    mail_locked: bool,
    player: &crate::read_model::PlayerStats,
) {
    let mut entity = parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            ..default()
        },
        BackgroundColor(Color::NONE),
        Button,
        CrystalItemHint(crystal_item_tooltip_document(item, player)),
    ));
    if enabled {
        entity.insert(action);
    }
    entity.with_children(|cell| {
        if let Some(index) = item.user_item_image_index() {
            if mail_locked {
                crate::crystal_ui::item_image::spawn_original_item_image_tinted(
                    cell,
                    asset_server,
                    index,
                    rect.width as i32,
                    rect.height as i32,
                    Color::srgba(105.0 / 255.0, 105.0 / 255.0, 105.0 / 255.0, 0.8),
                );
            } else {
                let (marker, node, mut image) = original_item_image_bundle(
                    asset_server,
                    Some(index),
                    rect.width as i32,
                    rect.height as i32,
                );
                image.color = if enabled {
                    Color::WHITE
                } else {
                    Color::srgba(0.412, 0.412, 0.412, 0.8)
                };
                cell.spawn((marker, node, image));
            }
        }
        let detail = inventory_cell_stack_label(item);
        if !detail.is_empty() {
            overlay_inventory_count(cell, &detail, rect.width, rect.height);
        }
    });
}

fn overlay_absolute_inventory_cell(
    parent: &mut ChildSpawnerCommands,
    rect: CrystalRect,
    action: OverlayButton,
    enabled: bool,
) {
    let mut entity = parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            ..default()
        },
        BackgroundColor(Color::NONE),
    ));
    if enabled {
        entity.insert((Button, action));
    }
}

fn overlay_inventory_count(
    parent: &mut ChildSpawnerCommands,
    text: &str,
    cell_width: f32,
    cell_height: f32,
) {
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(0.0),
                top: Val::Px(0.0),
                width: Val::Px(cell_width),
                height: Val::Px(cell_height),
                align_items: AlignItems::FlexEnd,
                justify_content: JustifyContent::FlexEnd,
                overflow: Overflow::clip(),
                ..default()
            },
            BackgroundColor(Color::NONE),
        ))
        .with_children(|label| {
            label.spawn((
                Text::new(text.to_owned()),
                crate::crystal_ui::typography::crystal_text_font(10.0),
                TextColor(Color::srgb(1.0, 1.0, 0.0)),
                TextLayout::new(Justify::Right, LineBreak::NoWrap),
            ));
        });
}

fn crystal_npc_goods_cell_rect(row: usize) -> CrystalRect {
    CrystalRect::new(
        10.0,
        34.0 + row as f32 * 33.0,
        NPC_GOODS_CELL_WIDTH,
        NPC_GOODS_CELL_HEIGHT,
    )
}

fn crystal_npc_goods_new_icon_visible(good: &ShopGood, goods: &[ShopGood]) -> bool {
    let Some(source) = good.tooltip_source.as_ref() else {
        return false;
    };
    let Some(item) = source.user_item.as_ref() else {
        return false;
    };
    let item_index = source.info.item_index;
    let mut matching = 0usize;
    let mut has_non_shop_item = false;
    for candidate in goods {
        let Some(candidate_source) = candidate.tooltip_source.as_ref() else {
            continue;
        };
        if candidate_source.info.item_index != item_index {
            continue;
        }
        matching += 1;
        has_non_shop_item |= candidate_source
            .user_item
            .as_ref()
            .is_some_and(|candidate| !candidate.is_shop_item);
    }
    let multiple_available = matching > 1 && has_non_shop_item;
    !item.is_shop_item || multiple_available
}

fn localized_shop_price(good: &ShopGood) -> String {
    if !crate::native_i18n::active() {
        return crate::player_text::text(&good.price_label());
    }
    let key = if !good.use_pearls {
        "game.shop.price_gold"
    } else if good.price == 1 {
        "game.shop.price_pearl"
    } else {
        "game.shop.price_pearls"
    };
    crate::native_i18n::format_key(
        key,
        &good.price_label(),
        &[("amount", &good.price.to_string())],
    )
}

#[test]
fn localized_shop_currency_preserves_server_values_without_english_plural_suffix() {
    use crate::native_i18n::{self, Locale};
    let mut good = ShopGood {
        price: 50,
        count: 3,
        use_pearls: true,
        ..default()
    };
    let original = good.clone();
    native_i18n::with_locale(Locale::TraditionalChinese, || {
        assert_eq!(localized_shop_price(&good), "價格：50 顆珍珠");
    });
    native_i18n::with_locale(Locale::BrazilianPortuguese, || {
        assert_eq!(localized_shop_price(&good), "Preço: 50 pérolas");
    });
    assert_eq!(good, original);
    good.price = 1;
    native_i18n::with_locale(Locale::BrazilianPortuguese, || {
        assert_eq!(localized_shop_price(&good), "Preço: 1 pérola");
        good.use_pearls = false;
        assert_eq!(localized_shop_price(&good), "Preço: 1 de ouro");
    });
}

/// Crystal MirGoodsCell: one 205x32 click/hover surface, with a 40x32 icon
/// area and independent name/count/price labels at their source coordinates.
fn overlay_absolute_shop_good_button(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    good: &ShopGood,
    rect: CrystalRect,
    action: OverlayButton,
    player: &crate::read_model::PlayerStats,
    selected: bool,
    hide_added_stats: bool,
    show_new_icon: bool,
) {
    let mut entity = parent.spawn((
        OverlayNpcShopGoodCell,
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            ..default()
        },
        BackgroundColor(Color::NONE),
        Outline::new(
            Val::Px(1.0),
            Val::Px(0.0),
            if selected {
                Color::srgb(0.0, 1.0, 0.0)
            } else {
                Color::NONE
            },
        ),
        Button,
        action,
    ));
    if let Some(document) = crystal_item_tooltip_document_from_source_with_options(
        &good.name,
        good.icon,
        u32::from(good.count),
        good.tooltip_source.as_ref(),
        player,
        CrystalItemTooltipOptions { hide_added_stats },
    ) {
        entity.insert(CrystalItemHint(document));
    }
    entity.with_children(|row| {
        if let (Some(asset_server), Some(index)) = (asset_server, good.user_item_image_index()) {
            row.spawn((
                OverlayNpcShopGoodIcon,
                original_item_image_bundle(
                    asset_server,
                    Some(index),
                    NPC_GOODS_ICON_AREA_WIDTH,
                    NPC_GOODS_CELL_HEIGHT as i32,
                ),
            ));
        }
        row.spawn((
            OverlayNpcShopGoodName,
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(44.0),
                top: Val::Px(0.0),
                ..default()
            },
            Text::new(crate::player_text::name(&good.name)),
            crate::crystal_ui::typography::crystal_text_font(9.0),
            TextColor(Color::WHITE),
            TextLayout::new(Justify::Left, LineBreak::NoWrap),
        ));
        row.spawn((
            OverlayNpcShopGoodPrice,
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(44.0),
                top: Val::Px(14.0),
                ..default()
            },
            Text::new(localized_shop_price(good)),
            crate::crystal_ui::typography::crystal_text_font(9.0),
            TextColor(Color::WHITE),
            TextLayout::new(Justify::Left, LineBreak::NoWrap),
        ));
        if good.count > 1 {
            row.spawn((
                OverlayNpcShopGoodCount,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(23.0),
                    top: Val::Px(17.0),
                    ..default()
                },
                Text::new(good.count.to_string()),
                crate::crystal_ui::typography::crystal_text_font(9.0),
                TextColor(Color::srgb(1.0, 1.0, 0.0)),
                TextLayout::new(Justify::Left, LineBreak::NoWrap),
            ));
        }
        if selected {
            row.spawn((
                OverlayNpcShopGoodSelectionDivider,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(40.0),
                    top: Val::Px(0.0),
                    width: Val::Px(1.0),
                    height: Val::Px(NPC_GOODS_CELL_HEIGHT),
                    ..default()
                },
                BackgroundColor(Color::srgb(0.0, 1.0, 0.0)),
            ));
        }
        if show_new_icon {
            if let Some(asset_server) = asset_server {
                row.spawn((
                    OverlayNpcShopGoodNewIcon,
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(190.0),
                        top: Val::Px(5.0),
                        width: Val::Px(12.0),
                        height: Val::Px(9.0),
                        ..default()
                    },
                    ImageNode {
                        image: asset_server.load(NPC_GOODS_NEW_ICON_ASSET),
                        image_mode: bevy::ui::widget::NodeImageMode::Stretch,
                        ..default()
                    },
                ));
            }
        }
    });
}

/// Compact row cell used by the still-provisional Shop/Warehouse panels. It
/// uses the same authoritative icon path without inventing an icon when the
/// source record has none.
fn overlay_compact_item_button(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    item: &ItemModel,
    label: &str,
    action: OverlayButton,
    enabled: bool,
    player: &crate::read_model::PlayerStats,
) {
    let mut entity = parent.spawn((
        Node {
            min_height: Val::Px(28.0),
            display: Display::Flex,
            align_items: AlignItems::Center,
            column_gap: Val::Px(4.0),
            padding: UiRect::axes(Val::Px(3.0), Val::Px(2.0)),
            ..default()
        },
        BackgroundColor(if enabled {
            Color::srgba(0.12, 0.08, 0.04, 0.60)
        } else {
            Color::srgba(0.25, 0.20, 0.12, 0.28)
        }),
        Button,
        CrystalItemHint(crystal_item_tooltip_document(item, player)),
    ));
    if enabled {
        entity.insert(action);
    }
    entity.with_children(|row| {
        if let (Some(asset_server), Some(index)) = (asset_server, item.user_item_image_index()) {
            row.spawn(Node {
                width: Val::Px(36.0),
                height: Val::Px(32.0),
                flex_shrink: 0.0,
                ..default()
            })
            .with_children(|cell| spawn_original_item_image(cell, asset_server, index, 36, 32));
        }
        row.spawn((
            Text::new(label.to_owned()),
            crate::crystal_ui::typography::crystal_text_font(10.0),
            TextColor(if enabled {
                TEXT
            } else {
                Color::srgba(0.75, 0.70, 0.60, 0.45)
            }),
        ));
    });
}

fn spawn_static_overlay_sprite(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    path: String,
    rect: CrystalRect,
) {
    if crate::native_i18n::active() {
        let caption = match path.as_str() {
            "original-ui/Title/57.png" => Some("Help"),
            "original-ui/Title/25.png" => Some("Guild"),
            "original-ui/Title/0.png" => Some("Storage"),
            "original-ui/Title/7.png" => Some("Mail"),
            "original-ui/Title/676.png" => Some("Obtain a stamp to unlock"),
            "original-ui/Title/516.png" => Some("Lv."),
            "original-ui/Title/517.png" => Some("Exp."),
            _ => None,
        };
        if let Some(caption) = caption { localized_art_label(parent, caption, rect, 9.0); return; }
    }
    parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            ..default()
        },
        ImageNode {
            image: asset_server.load(path),
            ..default()
        },
    ));
}

fn spawn_overlay_crystal_button(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    library: &'static str,
    normal: u16,
    hover: u16,
    pressed: u16,
    rect: CrystalRect,
    action: OverlayButton,
) {
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        library,
        normal,
        hover,
        pressed,
        rect,
        action,
        true,
    );
}

fn spawn_overlay_crystal_button_enabled(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    library: &'static str,
    normal: u16,
    hover: u16,
    pressed: u16,
    rect: CrystalRect,
    action: OverlayButton,
    enabled: bool,
) {
    spawn_overlay_crystal_button_enabled_with_disabled(
        parent,
        asset_server,
        library,
        normal,
        hover,
        pressed,
        None,
        rect,
        action,
        enabled,
    );
}

#[allow(clippy::too_many_arguments)]
fn spawn_overlay_crystal_button_enabled_with_disabled(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    library: &'static str,
    normal: u16,
    hover: u16,
    pressed: u16,
    disabled: Option<u16>,
    rect: CrystalRect,
    action: OverlayButton,
    enabled: bool,
) {
    let spec = CrystalButtonSpec::new(
        library,
        normal,
        hover,
        pressed,
        rect,
        rect.width,
        rect.height,
    );
    let mut assets = CrystalButtonAssetSet::from_spec(spec);
    if let Some(disabled) = disabled {
        assets = assets.with_disabled(spec.asset_path(disabled));
    }
    spawn_crystal_image_button(parent, asset_server, spec, assets, action, false, enabled);
}

#[cfg(test)]
#[path = "native_i18n_game_visual_tests.rs"]
mod native_i18n_game_visual_tests;

const HELP_PAGE_TITLES: [&str; HELP_PAGE_COUNT as usize] = [
    "Shortcut Information",
    "Shortcut Information",
    "Chat Shortcuts",
    "Movements",
    "Attacking",
    "Collecting Items",
    "Health",
    "Skills",
    "Skills",
    "Mana",
    "Chatting",
    "Groups",
    "Durability",
    "Purchasing",
    "Selling",
    "Repairing",
    "Trading",
    "Inspecting",
    "Statistics",
    "Statistics",
    "Statistics",
    "Statistics",
    "Statistics",
    "Statistics",
    "Quests",
    "Quests",
    "Quests",
    "Quests",
    "Mounts",
    "Mounts",
    "Fishing",
    "Gems and Orbs",
    "Heroes",
    "Heroes",
    "Heroes",
    "Heroes",
    "Heroes",
    "Guild Buffs",
    "Guild Buffs",
    "Guild Buffs",
    "Awakening",
    "Awakening",
    "Awakening",
    "Awakening",
    "Awakening",
];

const HELP_SHORTCUT_PAGE_1: [(&str, &str); 18] = [
    ("Alt + Q", "Exit the game"),
    ("Alt + X", "Log out"),
    ("F1-F8", "Skill buttons"),
    ("F9", "Inventory window (open / close)"),
    ("F10", "Status window (open / close)"),
    ("F11", "Skill window (open / close)"),
    ("P", "Group window (open / close)"),
    ("T", "Trade window (open / close)"),
    ("F", "Friend window (open / close)"),
    ("V", "Minimap window (open / close)"),
    ("Ctrl + G", "Guild window (open / close)"),
    ("Y", "Gameshop window (open / close)"),
    ("L", "Engagement window (open / close)"),
    ("Ctrl + Z", "Belt window (open / close)"),
    ("F12", "Option window (open / close)"),
    ("H", "Help window (open / close)"),
    ("M", "Mount / Dismount ride"),
    ("", "Lock spell onto target not cursor location"),
];

const HELP_SHORTCUT_PAGE_2: [(&str, &str); 18] = [
    ("Ctrl + A", "Toggle pet attack pet"),
    ("Ctrl + H", "Toggle player attack mode"),
    ("", "Peace Mode - Attack monsters only"),
    (
        "",
        "Group Mode - Attack all subjects except your group members",
    ),
    (
        "",
        "Guild Mode - Attack all subjects except your guild members",
    ),
    ("", "Good/Evil Mode - Attack PK players and monsters only"),
    ("", "All Attack Mode - Attack all subjects"),
    ("B", "Show the field map"),
    ("R", "Show the skill bar"),
    ("D", "Auto run on / off"),
    ("Insert", "Show / Hide interface"),
    ("Tab", "Highlight / Pickup Items"),
    ("Ctrl + Right Click", "Show other players kits"),
    ("PrintScreen", "Screen Capture"),
    ("N", "Open / Close fishing window"),
    ("", "Mentor window (open / close)"),
    ("X", "Creature Pickup (Multi Mouse Target)"),
    ("Alt + A", "Creature Pickup (Single Mouse Target)"),
];

const HELP_SHORTCUT_PAGE_3: [(&str, &str); 3] = [
    ("/(username)", "Command to whisper to others"),
    ("!(text)", "Command to shout to others nearby"),
    ("!~(text)", "Command to guild chat"),
];

fn help_shortcut_rows(page: u8) -> Option<&'static [(&'static str, &'static str)]> {
    match page {
        0 => Some(&HELP_SHORTCUT_PAGE_1),
        1 => Some(&HELP_SHORTCUT_PAGE_2),
        2 => Some(&HELP_SHORTCUT_PAGE_3),
        _ => None,
    }
}

fn help_bound_key(
    page: u8,
    row: usize,
    fallback: &str,
    keyboard: &keyboard_dialog::KeyboardDialogUi,
) -> String {
    const FIRST: [&str; 18] = [
        "Exit",
        "Logout",
        "Bar1Skill1",
        "Inventory",
        "Equipment",
        "Skills",
        "Group",
        "Trade",
        "Friends",
        "Minimap",
        "Guilds",
        "GameShop",
        "Relationship",
        "Belt",
        "Options",
        "Help",
        "Mount",
        "TargetSpellLockOn",
    ];
    const SECOND: [&str; 18] = [
        "ChangePetmode",
        "ChangeAttackmode",
        "AttackmodePeace",
        "AttackmodeGroup",
        "AttackmodeGuild",
        "AttackmodeRedbrown",
        "AttackmodeAll",
        "Bigmap",
        "Skillbar",
        "Autorun",
        "Cameramode",
        "Pickup",
        "",
        "Screenshot",
        "Fishing",
        "Mentor",
        "CreaturePickup",
        "CreatureAutoPickup",
    ];
    let function = match page {
        0 => FIRST.get(row),
        1 => SECOND.get(row),
        _ => None,
    };
    let Some(function) = function.filter(|f| !f.is_empty()) else {
        return fallback.into();
    };
    let key = |f: &str| {
        keyboard
            .bindings
            .iter()
            .find(|b| b.function == f)
            .map(|b| b.display())
            .unwrap_or_default()
    };
    if page == 0 && row == 2 {
        format!("{}-{}", key(function), key("Bar1Skill8"))
    } else {
        key(function)
    }
}

#[cfg(test)]
#[test]
fn help_shortcut_keys_follow_loaded_binding_and_clear_unbound() {
    let mut keyboard = keyboard_dialog::KeyboardDialogUi::default();
    let guild = keyboard
        .bindings
        .iter_mut()
        .find(|b| b.function == "Guilds")
        .unwrap();
    guild.key = "F9".into();
    guild.ctrl = 1;
    guild.alt = 0;
    guild.shift = 0;
    guild.tilde = 0;
    assert_eq!(help_bound_key(0, 10, "stale", &keyboard), "Ctrl + F9");
    keyboard
        .bindings
        .iter_mut()
        .find(|b| b.function == "Guilds")
        .unwrap()
        .key = "None".into();
    assert_eq!(help_bound_key(0, 10, "stale", &keyboard), "");
    assert_eq!(
        help_bound_key(2, 0, "/(username)", &keyboard),
        "/(username)"
    );
}

fn help_image_dimensions(index: u8) -> (f32, f32) {
    match index {
        0..=28 => (512.0, 396.0),
        29 => (509.0, 396.0),
        30 => (508.0, 395.0),
        31..=33 => (509.0, 396.0),
        34..=41 => (508.0, 395.0),
        _ => (0.0, 0.0),
    }
}

fn render_help(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    page: u8,
    keyboard: &keyboard_dialog::KeyboardDialogUi,
) {
    let page = page.min(HELP_PAGE_COUNT - 1);
    let Some(asset_server) = asset_server else {
        return;
    };

    spawn_overlay_frame(
        parent,
        asset_server,
        "original-ui/Prguse/920.png",
        CRYSTAL_HELP_PANEL_RECT.width,
        CRYSTAL_HELP_PANEL_RECT.height,
    );
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Title/57.png".to_owned(),
        CrystalRect::new(18.0, 9.0, 45.0, 14.0),
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        240,
        241,
        242,
        CrystalRect::new(210.0, 485.0, 16.0, 16.0),
        OverlayButton::HelpPrevious,
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        243,
        244,
        245,
        CrystalRect::new(310.0, 485.0, 16.0, 16.0),
        OverlayButton::HelpNext,
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        360,
        361,
        362,
        CrystalRect::new(509.0, 3.0, 24.0, 21.0),
        OverlayButton::CloseHelp,
    );
    overlay_text_at(
        parent,
        &crate::native_i18n::tr(&format!("{} / {}", page + 1, HELP_PAGE_COUNT)),
        CrystalRect::new(230.0, 480.0, 80.0, 20.0),
        9.0,
        TEXT,
    );
    overlay_text_at(
        parent,
        &crate::native_i18n::tr(&format!("{}. {}", page + 1, crate::native_i18n::tr(HELP_PAGE_TITLES[usize::from(page)]))),
        CrystalRect::new(147.0, 39.0, 242.0, 30.0),
        10.0,
        TEXT,
    );

    if let Some(rows) = help_shortcut_rows(page) {
        overlay_text_at(
            parent,
            &crate::native_i18n::tr("Shortcuts"),
            CrystalRect::new(13.0, 75.0, 100.0, 30.0),
            10.0,
            TEXT,
        );
        overlay_text_at(
            parent,
            &crate::native_i18n::tr("Information"),
            CrystalRect::new(114.0, 75.0, 405.0, 30.0),
            10.0,
            TEXT,
        );
        for (row, (shortcut, information)) in rows.iter().enumerate() {
            // ShortcutInfoPage is a direct HelpDialog child at (0, 0).
            // Only the separate title/image HelpPage receives the (12, 35) offset.
            let top = 107.0 + row as f32 * 20.0;
            let current_shortcut = help_bound_key(page, row, shortcut, keyboard);
            overlay_text_at(
                parent,
                &current_shortcut,
                CrystalRect::new(18.0, top, 95.0, 23.0),
                9.0,
                GOLD,
            );
            overlay_text_at(
                parent,
                &crate::native_i18n::tr(information),
                CrystalRect::new(119.0, top, 400.0, 23.0),
                9.0,
                TEXT,
            );
        }
    } else if !localized_help::render(parent, page) {
        let image_index = page - 3;
        let (width, height) = help_image_dimensions(image_index);
        parent.spawn((
            HelpPageImageEntity { image_index },
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(12.0),
                top: Val::Px(75.0),
                width: Val::Px(width),
                height: Val::Px(height),
                ..default()
            },
            ImageNode {
                image: asset_server.load(format!("original-ui/Help/{image_index}.png")),
                ..default()
            },
        ));
    }
}

fn render_menu(parent: &mut ChildSpawnerCommands, asset_server: Option<&AssetServer>) {
    let Some(asset_server) = asset_server else {
        return;
    };
    spawn_overlay_frame(
        parent,
        asset_server,
        "original-ui/Title/567.png",
        36.0,
        282.0,
    );

    // Crystal MenuDialog is a 36x282 icon strip. Only controls backed by a
    // native surface are interactive here; unsupported late-system icons are
    // rendered faithfully but deliberately do not masquerade as working UI.
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Title",
        633,
        634,
        635,
        CrystalRect::new(3.0, 12.0, 32.0, 20.0),
        OverlayButton::ExitApplication,
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Title",
        636,
        637,
        638,
        CrystalRect::new(3.0, 31.0, 32.0, 20.0),
        OverlayButton::Logout,
    );

    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse",
        1970,
        1971,
        1972,
        CrystalRect::new(3.0, 50.0, 32.0, 20.0),
        OverlayButton::ToggleHelp,
    );

    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse",
        1973,
        1974,
        1975,
        CrystalRect::new(3.0, 69.0, 32.0, 20.0),
        OverlayButton::ToggleKeyboard,
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse",
        1982,
        1983,
        1984,
        CrystalRect::new(3.0, 183.0, 32.0, 20.0),
        OverlayButton::ToggleFriends,
    );
    for (lib, normal, top, action) in [
        ("Prguse2", 431, 126.0, OverlayButton::ToggleCreature),
        ("Prguse", 1976, 145.0, OverlayButton::ToggleMount),
        ("Prguse", 1979, 164.0, OverlayButton::ToggleFishing),
    ] {
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            lib,
            normal,
            normal + 1,
            normal + 2,
            CrystalRect::new(3.0, top, 32.0, 20.0),
            action,
        );
    }
    for (library, normal, hover, pressed, top, action) in [
        (
            "Prguse",
            1985,
            1986,
            1987,
            202.0,
            OverlayButton::ToggleMentor,
        ),
        (
            "Prguse",
            1988,
            1989,
            1990,
            221.0,
            OverlayButton::ToggleRelationship,
        ),
    ] {
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            library,
            normal,
            hover,
            pressed,
            CrystalRect::new(3.0, top, 32.0, 20.0),
            action,
            true,
        );
    }
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse",
        2000,
        2001,
        2002,
        CrystalRect::new(3.0, 88.0, 32.0, 20.0),
        OverlayButton::ToggleRanking,
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse",
        1991,
        1992,
        1993,
        CrystalRect::new(3.0, 240.0, 32.0, 20.0),
        OverlayButton::ToggleGroup,
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse",
        1994,
        1995,
        1996,
        CrystalRect::new(3.0, 259.0, 32.0, 20.0),
        OverlayButton::ToggleGuild,
    );
}

fn render_social(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    social: &crate::social::SocialModel,
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
    combat_target: Option<&crate::quest_model::CombatTargetModel>,
    player: &crate::read_model::PlayerStats,
) {
    if state.group_open() {
        render_group_panel(
            parent,
            asset_server,
            social,
            state,
            combat_target,
            player.name.as_deref().unwrap_or(""),
        );
    } else if state.guild_open() {
        render_guild_panel(parent, asset_server, social, state, player);
    } else {
        render_trade_panel(parent, asset_server, social, inventory, player);
    }
}

fn render_group_panel(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    social: &crate::social::SocialModel,
    state: &NativePlayerUiState,
    _combat_target: Option<&crate::quest_model::CombatTargetModel>,
    owner: &str,
) {
    let rect = state.group_dialog.rect();
    let group = &social.group;
    let Some(asset_server) = asset_server else {
        return;
    };
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Prguse/120.png".to_owned(),
        rect,
    );
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Title/5.png".to_owned(),
        CrystalRect::new(rect.left + 18.0, rect.top + 8.0, 55.0, 15.0),
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        360,
        361,
        362,
        CrystalRect::new(rect.left + 206.0, rect.top + 3.0, 24.0, 21.0),
        OverlayButton::CloseSocial,
    );

    for (index, member) in group
        .members
        .iter()
        .take(crate::social::MAX_GROUP_MEMBERS)
        .enumerate()
    {
        let (left, top) = group_member_position(index);
        let hint = group
            .member_maps
            .get(&member.name)
            .map(String::as_str)
            .or(member.map.as_deref())
            .unwrap_or("");
        parent
            .spawn((
                Button,
                OverlayButton::SelectGroupMember(index as u8),
                crate::crystal_ui::widget::CrystalHint::new(hint),
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(rect.left + left),
                    top: Val::Px(rect.top + top),
                    width: Val::Px(96.),
                    height: Val::Px(16.),
                    ..default()
                },
            ))
            .with_children(|p| {
                overlay_text_at(
                    p,
                    &member.name,
                    CrystalRect::new(0., 0., 96., 16.),
                    32. / 3.,
                    Color::WHITE,
                );
            });
    }

    let switch_index = if group.allow_invites { 117 } else { 114 };
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse",
        switch_index,
        switch_index + 1,
        switch_index + 2,
        CrystalRect::new(rect.left + 25.0, rect.top + 219.0, 28.0, 25.0),
        OverlayButton::GroupSwitch,
    );
    if !group_dialog::GroupDialogUi::can_manage(group, owner) {
        return;
    }
    let add_base = if group.members.is_empty() { 130 } else { 133 };
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Title",
        add_base,
        add_base + 1,
        add_base + 2,
        CrystalRect::new(rect.left + 70.0, rect.top + 219.0, 60.0, 25.0),
        OverlayButton::GroupAddSelected,
        true,
    );
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Title",
        136,
        137,
        138,
        CrystalRect::new(rect.left + 140.0, rect.top + 219.0, 60.0, 25.0),
        OverlayButton::GroupRemoveSelected,
        true,
    );
}

fn group_member_position(index: usize) -> (f32, f32) {
    if index == 0 {
        (16.0, 33.0)
    } else {
        (
            (((index + 1) % 2) * 100 + 16) as f32,
            (55 + ((index - 1) / 2) * 20) as f32,
        )
    }
}

fn render_guild_panel(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    social: &crate::social::SocialModel,
    state: &NativePlayerUiState,
    player: &crate::read_model::PlayerStats,
) {
    let rect = state.guild_panel.rect();
    let guild = &social.guild;
    let Some(asset_server) = asset_server else {
        return;
    };
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Prguse/180.png".to_owned(),
        rect,
    );
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Title/25.png".to_owned(),
        CrystalRect::new(rect.left + 18.0, rect.top + 9.0, 49.0, 15.0),
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        360,
        361,
        362,
        CrystalRect::new(rect.left + 565.0, rect.top + 4.0, 24.0, 21.0),
        OverlayButton::CloseSocial,
    );
    spawn_guild_tab(
        parent,
        asset_server,
        rect.left + 20.0,
        rect.top + 38.0,
        93,
        94,
        state.guild_left_page == GuildLeftPage::Notice,
        OverlayButton::SelectGuildLeftPage(GuildLeftPage::Notice),
    );
    spawn_guild_tab(
        parent,
        asset_server,
        rect.left + 91.0,
        rect.top + 38.0,
        99,
        100,
        state.guild_left_page == GuildLeftPage::Members,
        OverlayButton::SelectGuildLeftPage(GuildLeftPage::Members),
    );
    if guild.my_options & 0x18 != 0 {
        spawn_guild_tab(
            parent,
            asset_server,
            rect.left + 162.0,
            rect.top + 38.0,
            105,
            106,
            state.guild_left_page == GuildLeftPage::Storage,
            OverlayButton::SelectGuildLeftPage(GuildLeftPage::Storage),
        );
    }
    if guild.my_options & 0x01 != 0 {
        spawn_guild_tab(
            parent,
            asset_server,
            rect.left + 233.0,
            rect.top + 38.0,
            101,
            102,
            state.guild_left_page == GuildLeftPage::Ranks,
            OverlayButton::SelectGuildLeftPage(GuildLeftPage::Ranks),
        );
    }
    spawn_guild_tab(
        parent,
        asset_server,
        rect.left + 501.,
        rect.top + 38.,
        103,
        104,
        !state.guild_panel.right_buff,
        OverlayButton::SelectGuildRightBuff(false),
    );
    if guild.name.is_some() {
        spawn_guild_tab(
            parent,
            asset_server,
            rect.left + 430.,
            rect.top + 38.,
            95,
            96,
            state.guild_panel.right_buff,
            OverlayButton::SelectGuildRightBuff(true),
        );
    }

    match state.guild_left_page {
        GuildLeftPage::Notice => render_guild_notice(parent, asset_server, guild, state, rect),
        GuildLeftPage::Members => render_guild_members(parent, asset_server, guild, state, rect),
        GuildLeftPage::Storage => {
            render_guild_storage(parent, asset_server, guild, state, rect, player)
        }
        GuildLeftPage::Ranks => render_guild_ranks(parent, asset_server, guild, state, rect),
    }
    if state.guild_panel.right_buff {
        guild_panel::render_buff(parent, asset_server, state, guild, rect);
    } else {
        render_guild_status(parent, asset_server, guild, state, rect);
    }
}

fn spawn_guild_tab(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    left: f32,
    top: f32,
    idle: u16,
    active: u16,
    selected: bool,
    action: OverlayButton,
) {
    let normal = if selected { active } else { idle };
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Title",
        normal,
        normal,                                    // Guild tabs have no HoverIndex in Crystal.
        if idle == 101 { normal } else { active }, // Rank has no PressedIndex.
        CrystalRect::new(left, top, 72.0, 24.0),
        action,
    );
}

fn render_guild_notice(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    guild: &crate::social::GuildModel,
    state: &NativePlayerUiState,
    rect: CrystalRect,
) {
    if state.guild_notice_editing {
        friend_dialog::view::render_editor(
            parent,
            &state.guild_panel.notice_editor,
            CrystalRect::new(rect.left + 13., rect.top + 61., 322., 330.),
            true,
        );
    } else {
        let notice = guild
            .notice
            .iter()
            .skip(state.guild_panel.notice_scroll)
            .take(25)
            .cloned()
            .collect::<Vec<_>>()
            .join("\n");
        overlay_text_at(
            parent,
            &notice,
            CrystalRect::new(rect.left + 13., rect.top + 61., 322., 330.),
            10.6667,
            Color::WHITE,
        );
    }
    for (top, frame, delta) in [(61., 197, -1), (378., 207, 1)] {
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            frame,
            frame + 1,
            frame + 2,
            CrystalRect::new(rect.left + 337., rect.top + top, 12., 12.),
            OverlayButton::GuildNoticeScroll(delta),
            true,
        );
    }
    let count = if state.guild_notice_editing {
        state.guild_notice_draft.split('\n').count()
    } else {
        guild.notice.len()
    };
    let interval = 289usize.checked_div(count.saturating_sub(25)).unwrap_or(0);
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Prguse2/206.png".into(),
        CrystalRect::new(
            rect.left + 337.,
            rect.top + 60. + (16 + state.guild_panel.notice_scroll * interval).min(298) as f32,
            12.,
            18.,
        ),
    );
    let can_edit = guild.name.is_some() && social_has_permission(guild, "notice");
    if can_edit {
        let action = if state.guild_notice_editing {
            OverlayButton::GuildPublishNotice
        } else {
            OverlayButton::GuildBeginNoticeEdit
        };
        let publish_enabled = state.guild_notice_submission.is_none();
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse",
            if state.guild_notice_editing { 554 } else { 560 },
            if state.guild_notice_editing { 555 } else { 561 },
            if state.guild_notice_editing { 556 } else { 562 },
            CrystalRect::new(rect.left + 20.0, rect.top + 402.0, 28.0, 25.0),
            action,
            publish_enabled,
        );
    }
}

fn render_guild_members(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    guild: &crate::social::GuildModel,
    state: &NativePlayerUiState,
    rect: CrystalRect,
) {
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Prguse/1852.png".to_owned(),
        CrystalRect::new(rect.left + 13.0, rect.top + 61.0, 324.0, 332.0),
    );
    let can_kick = social_has_permission(guild, "kick");
    for (row, (index, member)) in guild
        .members
        .iter()
        .enumerate()
        .filter(|(_, m)| !state.guild_panel.hide_offline || m.online)
        .skip(state.guild_panel.member_scroll)
        .take(18)
        .enumerate()
    {
        let top = rect.top + 90.0 + row as f32 * 15.0;
        let shade = if row % 2 == 0 { 10 } else { 15 };
        guild_panel::closed_dropdown(
            parent,
            asset_server,
            member.rank_name.as_deref().unwrap_or(""),
            CrystalRect::new(rect.left + 24., top, 100., 14.),
            OverlayButton::GuildMemberRankMenu(index as u8),
            social_has_permission(guild, "changeRank")
                && member
                    .rank_index
                    .is_some_and(|r| i32::from(r) >= guild.my_rank_id),
            shade,
        );
        guild_panel::member_text(
            parent,
            &member.name,
            CrystalRect::new(rect.left + 125., top, 84., 14.),
            Color::WHITE,
            shade,
        );
        guild_panel::member_text(
            parent,
            &guild_panel::member_status(member),
            CrystalRect::new(rect.left + 225., top, 100., 14.),
            if member.online {
                Color::srgb_u8(50, 205, 50)
            } else {
                Color::WHITE
            },
            shade,
        );
        if can_kick
            && member.name != state.guild_panel.owner_name
            && member
                .rank_index
                .is_some_and(|r| i32::from(r) >= guild.my_rank_id)
        {
            spawn_overlay_crystal_button(
                parent,
                asset_server,
                "Prguse",
                917,
                917,
                917,
                CrystalRect::new(rect.left + 210.0, top, 16.0, 14.0),
                OverlayButton::GuildKickMember(index as u8),
            );
        }
    }

    for (top, frame, delta) in [(61., 197, -1), (378., 207, 1)] {
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            frame,
            frame + 1,
            frame + 2,
            CrystalRect::new(rect.left + 337., rect.top + top, 12., 12.),
            OverlayButton::GuildMembersScroll(delta),
            true,
        );
    }
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Prguse",
        1346,
        1346,
        1346,
        CrystalRect::new(rect.left + 230., rect.top + 370., 12., 12.),
        OverlayButton::GuildShowOffline,
        true,
    );
    if !state.guild_panel.hide_offline {
        spawn_static_overlay_sprite(
            parent,
            asset_server,
            "original-ui/Prguse/1347.png".into(),
            CrystalRect::new(rect.left + 230., rect.top + 370., 16., 12.),
        );
    }
    overlay_text_at(
        parent,
        &crate::native_i18n::tr("Show Offline"),
        CrystalRect::new(rect.left + 245., rect.top + 369., 150., 12.),
        28. / 3.,
        Color::WHITE,
    );
    let count = guild
        .members
        .iter()
        .filter(|m| !state.guild_panel.hide_offline || m.online)
        .count();
    let interval = 289usize.checked_div(count.saturating_sub(18)).unwrap_or(0);
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Prguse2/206.png".into(),
        CrystalRect::new(
            rect.left + 337.,
            rect.top + 60. + (16 + state.guild_panel.member_scroll * interval).min(298) as f32,
            12.,
            18.,
        ),
    );
    if let Some(member) = state.guild_panel.member_menu {
        let row = guild
            .members
            .iter()
            .enumerate()
            .filter(|(_, m)| !state.guild_panel.hide_offline || m.online)
            .position(|(i, _)| i == usize::from(member))
            .unwrap_or(0)
            .saturating_sub(state.guild_panel.member_scroll);
        let top = rect.top + 90. + row as f32 * 15.;
        for (row, rank) in guild
            .ranks
            .iter()
            .filter(|r| r.index >= guild.my_rank_id)
            .skip(state.guild_panel.rank_scroll)
            .take(5)
            .enumerate()
        {
            if let Ok(id) = u8::try_from(rank.index) {
                guild_panel::dropdown_row(
                    parent,
                    &rank.name,
                    CrystalRect::new(rect.left + 24., top + 15. + row as f32 * 13., 84., 16.),
                    OverlayButton::GuildMemberRankSelect(id),
                    (state.guild_panel.cursor, state.guild_panel.left_down),
                );
            }
        }
        for (dy, frame, delta) in [(14., 2021, -1), (74., 2024, 1)] {
            spawn_overlay_crystal_button_enabled(
                parent,
                asset_server,
                "Prguse",
                frame,
                frame + 1,
                frame + 2,
                CrystalRect::new(rect.left + 112., top + dy, 12., 6.),
                OverlayButton::GuildRankScroll(delta),
                true,
            );
        }
    }
}

fn render_guild_storage(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    guild: &crate::social::GuildModel,
    state: &NativePlayerUiState,
    rect: CrystalRect,
    player: &crate::read_model::PlayerStats,
) {
    debug_assert_eq!(
        guild_storage::SLOT_COUNT,
        crate::social::MAX_GUILD_STORAGE_ITEMS
    );
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(rect.left + guild_storage::PAGE.left),
                top: Val::Px(rect.top + guild_storage::PAGE.top),
                width: Val::Px(guild_storage::PAGE.width),
                height: Val::Px(guild_storage::PAGE.height),
                ..default()
            },
            BackgroundColor(Color::NONE),
        ))
        .with_children(|page| {
            spawn_static_overlay_sprite(
                page,
                asset_server,
                guild_storage::BACKGROUND.asset_path(),
                guild_storage::BACKGROUND.rect,
            );
            overlay_text_at(
                page,
                &format_crystal_gold(guild.gold),
                guild_storage::GOLD_LABEL,
                10.0,
                Color::WHITE,
            );
            for (spec, action) in [
                (guild_storage::GOLD_ADD, OverlayButton::GuildGoldDeposit),
                (guild_storage::UP, OverlayButton::GuildStoragePreviousRow),
                (guild_storage::DOWN, OverlayButton::GuildStorageNextRow),
            ] {
                spawn_crystal_image_button(
                    page,
                    asset_server,
                    spec,
                    CrystalButtonAssetSet::from_spec(spec),
                    action,
                    false,
                    true,
                );
            }
            if guild.my_rank_id == 0 {
                let spec = guild_storage::GOLD_REMOVE;
                spawn_crystal_image_button(
                    page,
                    asset_server,
                    spec,
                    CrystalButtonAssetSet::from_spec(spec),
                    OverlayButton::GuildGoldWithdraw,
                    false,
                    true,
                );
            }
            let thumb = state.guild_storage.thumb_rect();
            page.spawn((
                OverlayGuildStorageThumb,
                Button,
                Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(thumb.left),
                    top: Val::Px(thumb.top),
                    width: Val::Px(thumb.width),
                    height: Val::Px(thumb.height),
                    ..default()
                },
                ImageNode {
                    image: asset_server.load("original-ui/Prguse2/206.png"),
                    ..default()
                },
            ));
            for slot in 0..guild_storage::SLOT_COUNT {
                let Some(cell_rect) = state.guild_storage.cell_rect(slot) else {
                    continue;
                };
                let item = guild.storage_items.get(slot).and_then(Option::as_ref);
                let mut cell = page.spawn((
                    OverlayGuildStorageCell { slot },
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(cell_rect.left),
                        top: Val::Px(cell_rect.top),
                        width: Val::Px(cell_rect.width),
                        height: Val::Px(cell_rect.height),
                        // MirItemCell draws at intrinsic size, including overflow.
                        ..default()
                    },
                    BackgroundColor(Color::NONE),
                    Interaction::None,
                    FocusPolicy::Block,
                ));
                let Some(item) = item else {
                    continue;
                };
                let Some(source) = item.tooltip_source.as_ref() else {
                    continue;
                };
                let image = source.user_item_image(u32::from(item.count));
                if let Some(document) = crystal_item_tooltip_document_from_source(
                    &source.info.name,
                    image,
                    u32::from(item.count),
                    Some(source),
                    player,
                ) {
                    cell.insert(CrystalItemHint(document));
                }
                cell.with_children(|content| {
                    spawn_original_item_image(content, asset_server, image, 35, 35);
                    if source.info.stack_size > 1 {
                        overlay_inventory_count(content, &item.count.to_string(), 35.0, 35.0);
                    }
                });
            }
        });
}

fn render_guild_ranks(
    parent: &mut ChildSpawnerCommands,
    assets: &AssetServer,
    guild: &crate::social::GuildModel,
    state: &NativePlayerUiState,
    rect: CrystalRect,
) {
    let x = rect.left;
    let y = rect.top + 60.;
    for (text, left) in [("Edit rank", 42.), ("Select rank", 198.)] {
        overlay_text_at(
            parent,
            text,
            CrystalRect::new(x + left, y + 18., 150., 20.),
            10.6667,
            Color::WHITE,
        );
    }
    let selected = state
        .selected_guild_rank
        .and_then(|id| guild.ranks.iter().find(|r| r.index == i32::from(id)));
    let can_change = selected.is_some_and(|r| r.index >= i32::from(guild.my_rank_id))
        && social_has_permission(guild, "changeRank");
    friend_dialog::view::render_editor_styled(
        parent,
        &state.guild_panel.rank_editor,
        CrystalRect::new(x + 42., y + 36., 130., 16.),
        false,
        Color::srgb_u8(35, 35, 35),
    );
    guild_panel::closed_dropdown(
        parent,
        assets,
        selected.map(|r| r.name.as_str()).unwrap_or(""),
        CrystalRect::new(x + 198., y + 36., 130., 16.),
        OverlayButton::GuildRankDropdown,
        true,
        25,
    );
    spawn_overlay_crystal_button_enabled(
        parent,
        assets,
        "Title",
        90,
        91,
        92,
        CrystalRect::new(x + 155., y + 290., 40., 25.),
        OverlayButton::GuildRankNameSave,
        can_change,
    );
    for (i, label) in [
        "Edit ranks",
        "Recruit member",
        "Kick member",
        "Store item",
        "Retrieve item",
        "Alter alliance",
        "Change notice",
        "Activate Buff",
    ]
    .iter()
    .enumerate()
    {
        let bx = x + if i % 2 == 0 { 42. } else { 202. };
        let by = y + 120. + (i / 2) as f32 * 40.;
        spawn_overlay_crystal_button_enabled(
            parent,
            assets,
            "Prguse",
            1346,
            1346,
            1346,
            CrystalRect::new(bx, by, 12., 12.),
            OverlayButton::GuildRankTogglePermission(i as u8),
            can_change,
        );
        if selected.is_some_and(|r| r.options & (1 << i) != 0) {
            spawn_static_overlay_sprite(
                parent,
                assets,
                "original-ui/Prguse/1347.png".into(),
                CrystalRect::new(bx, by, 16., 12.),
            );
        }
        overlay_text_at(
            parent,
            &crate::native_i18n::tr(label),
            CrystalRect::new(bx + 17., by - 2., 135., 20.),
            10.6667,
            Color::WHITE,
        );
    }
    if state.guild_panel.rank_dropdown {
        for (offset, rank) in guild
            .ranks
            .iter()
            .skip(state.guild_panel.rank_scroll)
            .take(5)
            .enumerate()
        {
            if let Ok(id) = u8::try_from(rank.index) {
                guild_panel::dropdown_row(
                    parent,
                    &rank.name,
                    CrystalRect::new(x + 198., y + 51. + offset as f32 * 13., 114., 16.),
                    OverlayButton::SelectGuildRank(id),
                    (state.guild_panel.cursor, state.guild_panel.left_down),
                );
            }
        }
        let new_row = guild
            .ranks
            .len()
            .saturating_sub(state.guild_panel.rank_scroll);
        if new_row < 5 {
            guild_panel::dropdown_row(
                parent,
                "New Rank",
                CrystalRect::new(x + 198., y + 51. + new_row as f32 * 13., 114., 16.),
                OverlayButton::GuildCreateRank,
                (state.guild_panel.cursor, state.guild_panel.left_down),
            );
        }
        let thumb_y =
            22. + state.guild_panel.rank_scroll as f32 * 52. / guild.ranks.len().max(1) as f32;
        spawn_static_overlay_sprite(
            parent,
            assets,
            "original-ui/Prguse/2015.png".into(),
            CrystalRect::new(x + 317., y + 36. + thumb_y, 8., 14.),
        );
        for (dy, frame, delta) in [(50., 2021, -1), (110., 2024, 1)] {
            spawn_overlay_crystal_button_enabled(
                parent,
                assets,
                "Prguse",
                frame,
                frame + 1,
                frame + 2,
                CrystalRect::new(x + 316., y + dy, 12., 6.),
                OverlayButton::GuildRankScroll(delta),
                true,
            );
        }
    }
}

fn render_guild_status(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    guild: &crate::social::GuildModel,
    state: &NativePlayerUiState,
    rect: CrystalRect,
) {
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Prguse/1850.png".to_owned(),
        CrystalRect::new(rect.left + 365.0, rect.top + 62.0, 208.0, 316.0),
    );
    if crate::native_i18n::active() {
        localized_art_label(parent, "Guild Statistics", CrystalRect::new(rect.left + 373.0, rect.top + 66.0, 192.0, 26.0), 10.0);
    }
    if social_has_permission(guild, "recruit") {
        overlay_text_at(
            parent,
            &crate::native_i18n::tr("Recruit Member"),
            CrystalRect::new(rect.left + 391., rect.top + 343., 150., 15.),
            10.6667,
            Color::WHITE,
        );
        friend_dialog::view::render_editor_styled(
            parent,
            &state.guild_panel.recruit_editor,
            CrystalRect::new(rect.left + 395., rect.top + 360., 130., 21.),
            false,
            Color::srgb_u8(35, 35, 35),
        );
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Title",
            356,
            357,
            358,
            CrystalRect::new(rect.left + 525., rect.top + 358., 40., 25.),
            OverlayButton::GuildRecruitNameSubmit,
            true,
        );
    }
    for (label, value, top) in [
        ("Guild", guild.name.as_deref().unwrap_or(""), 107.0),
        ("Level", if guild.name.is_some() { "" } else { "" }, 133.0),
        ("Members", "", 159.0),
    ] {
        overlay_text_at(
            parent,
            &crate::native_i18n::tr(label),
            CrystalRect::new(rect.left + 362.0, rect.top + top, 75.0, 14.0),
            9.0,
            Color::srgb(0.55, 0.55, 0.55),
        );
        if !value.is_empty() {
            overlay_text_at(
                parent,
                value,
                CrystalRect::new(rect.left + 437.0, rect.top + top, 120.0, 14.0),
                9.0,
                TEXT,
            );
        }
    }
    if guild.name.is_some() {
        overlay_text_at(
            parent,
            &guild.level.to_string(),
            CrystalRect::new(rect.left + 437.0, rect.top + 133.0, 120.0, 14.0),
            9.0,
            TEXT,
        );
        overlay_text_at(
            parent,
            &crate::native_i18n::tr(&format!(
                "{}{}",
                guild.member_count,
                if guild.max_members == 0 {
                    String::new()
                } else {
                    format!("/{}", guild.max_members)
                }
            )),
            CrystalRect::new(rect.left + 437.0, rect.top + 159.0, 120.0, 14.0),
            9.0,
            TEXT,
        );
    }
    if guild.max_experience > 0 {
        let ratio = guild.experience as f64 / guild.max_experience as f64;
        spawn_static_overlay_sprite(
            parent,
            asset_server,
            "original-ui/Prguse2/424.png".into(),
            CrystalRect::new(rect.left + 322., rect.top + 403., 260., 22.),
        );
        if ratio > 0. {
            parent
                .spawn(Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(rect.left + 322.),
                    top: Val::Px(rect.top + 403.),
                    width: Val::Px((257. * ratio.min(1.)) as f32),
                    height: Val::Px(22.),
                    overflow: Overflow::clip(),
                    ..default()
                })
                .with_children(|p| {
                    spawn_static_overlay_sprite(
                        p,
                        asset_server,
                        "original-ui/Prguse2/423.png".into(),
                        CrystalRect::new(0., 0., 260., 22.),
                    );
                });
        }
        let value = format!("{:.2}", ratio * 100.);
        let label = format!("{}%", value.trim_end_matches('0').trim_end_matches('.'));
        parent.spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(rect.left + 322.),
                top: Val::Px(rect.top + 405.),
                width: Val::Px(260.),
                height: Val::Px(15.),
                ..default()
            },
            Text::new(label),
            crate::crystal_ui::typography::crystal_text_font(32. / 3.),
            TextColor(Color::WHITE),
            TextLayout::justify(Justify::Center),
        ));
    }
}

fn overlay_clickable_text_at(
    parent: &mut ChildSpawnerCommands,
    text: &str,
    rect: CrystalRect,
    action: OverlayButton,
    selected: bool,
    online: bool,
) {
    let mut row = parent.spawn((
        Button,
        action,
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            overflow: Overflow::clip(),
            ..default()
        },
        BackgroundColor(if selected {
            Color::srgba(0.45, 0.28, 0.05, 0.72)
        } else {
            Color::NONE
        }),
    ));
    row.with_children(|cell| {
        cell.spawn((
            Text::new(text.to_owned()),
            crate::crystal_ui::typography::crystal_text_font(9.0),
            TextColor(if online {
                TEXT
            } else {
                Color::srgb(0.5, 0.5, 0.5)
            }),
            TextLayout::new(Justify::Left, LineBreak::NoWrap),
        ));
    });
}

fn render_trade_panel(
    parent: &mut ChildSpawnerCommands,
    _asset_server: Option<&AssetServer>,
    social: &crate::social::SocialModel,
    _inventory: &InventoryModel,
    _player: &crate::read_model::PlayerStats,
) {
    // Invitations are independent modal MirMessageBoxes, not this panel.
    if social.trade.state == "open" || social.trade.state == "requested" {
        return;
    }
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(172.0),
                top: Val::Px(80.0),
                width: Val::Px(680.0),
                max_height: Val::Px(560.0),
                flex_direction: FlexDirection::Column,
                padding: UiRect::all(Val::Px(10.0)),
                row_gap: Val::Px(5.0),
                ..default()
            },
            BackgroundColor(PANEL_BG),
        ))
        .with_children(|dialog| {
            title(dialog, &crate::native_i18n::tr("Trade"));
            overlay_button(dialog, &crate::native_i18n::tr("Request trade"), OverlayButton::TradeRequest, true);
            overlay_button(dialog, &crate::native_i18n::tr("Close"), OverlayButton::CloseSocial, true);
        });
}

fn render_inspect(
    parent: &mut ChildSpawnerCommands,
    state: &NativePlayerUiState,
    inventory: &InventoryModel,
    parcel: Option<&mail_parcel::MailParcelUi>,
) {
    title(parent, &crate::native_i18n::tr("Item"));
    if let Some(inspect) = state.inspect.as_ref() {
        body(
            parent,
            &crate::native_i18n::tr(&format!(
                "{}  x{}  {} slot {}",
                if inspect.name.is_empty() {
                    inspect.key.as_str()
                } else {
                    inspect.name.as_str()
                },
                inspect.quantity,
                container_name(inspect.container),
                inspect.slot
            )),
        );
        let mail_locked = parcel.is_some_and(|parcel| {
            inspected_bag_item_is_mail_locked(state, inventory, parcel)
        });
        let use_enabled = !mail_locked && inspected_use_intent(state, inventory).is_some();
        overlay_button(parent, &crate::native_i18n::tr("Use (U)"), OverlayButton::UseInspected, use_enabled);
        if inspect.container == 2 {
            overlay_button(
                parent,
                &crate::native_i18n::tr("Unequip (G)"),
                OverlayButton::UnequipInspected,
                inspected_remove_intent(state, inventory).is_some(),
            );
        } else {
            overlay_button(
                parent,
                &crate::native_i18n::tr("Equip (G)"),
                OverlayButton::EquipInspected,
                !mail_locked && inspected_equip_intent(state, inventory).is_some(),
            );
        }
        if let Some(item) = inspected_inventory_item(state, inventory) {
            let valid_id = !mail_locked && item_unique_id(item).is_some();
            let drop_enabled =
                valid_id && u16::try_from(item.quantity).is_ok() && item.quantity > 0;
            let split_max = item.quantity.saturating_sub(1).min(u32::from(u16::MAX)) as u16;
            parent
                .spawn(Node {
                    display: Display::Flex,
                    flex_direction: FlexDirection::Row,
                    column_gap: Val::Px(4.0),
                    ..default()
                })
                .with_children(|row| {
                    overlay_button(row, &crate::native_i18n::tr("Drop all"), OverlayButton::DropInspected, drop_enabled);
                    overlay_button(
                        row,
                        &crate::native_i18n::tr("Split"),
                        OverlayButton::SplitInspected,
                        valid_id && split_max > 0 && state.split_count <= split_max,
                    );
                });
            parent
                .spawn(Node {
                    display: Display::Flex,
                    flex_direction: FlexDirection::Row,
                    column_gap: Val::Px(4.0),
                    ..default()
                })
                .with_children(|row| {
                    overlay_button(
                        row,
                        &crate::native_i18n::tr("Split -"),
                        OverlayButton::SplitCountDec,
                        split_max > 0 && state.split_count > 1,
                    );
                    body(row, &crate::native_i18n::tr(&format!("{}", state.split_count)));
                    overlay_button(
                        row,
                        &crate::native_i18n::tr("Split +"),
                        OverlayButton::SplitCountInc,
                        split_max > 0 && state.split_count < split_max,
                    );
                });
            if let Some(confirmation) = state.drop_confirmation.as_ref() {
                let current = !mail_locked && drop_confirmation_is_current(confirmation, inventory);
                body(
                    parent,
                    &crate::native_i18n::tr(&format!("Drop {} x{}?", confirmation.key, confirmation.count)),
                );
                overlay_button(
                    parent,
                    &crate::native_i18n::tr("Confirm drop"),
                    OverlayButton::ConfirmDropInspected,
                    current,
                );
                overlay_button(
                    parent,
                    &crate::native_i18n::tr("Cancel drop"),
                    OverlayButton::CancelDropInspected,
                    true,
                );
            }
            overlay_button(
                parent,
                &crate::native_i18n::tr("Move source"),
                OverlayButton::ArmMoveInspected,
                valid_id,
            );
            overlay_button(
                parent,
                &crate::native_i18n::tr("Merge source"),
                OverlayButton::ArmMergeInspected,
                valid_id && item.quantity > 0,
            );
            if state.inventory_operation.is_some() {
                overlay_button(
                    parent,
                    &crate::native_i18n::tr("Cancel move/merge"),
                    OverlayButton::CancelInventoryOperation,
                    true,
                );
            }
        }
        overlay_button(parent, &crate::native_i18n::tr("Close"), OverlayButton::CloseInspect, true);
    }
}

fn render_death(parent: &mut ChildSpawnerCommands) {
    title(parent, &crate::native_i18n::tr("You are dead"));
    body(parent, &crate::native_i18n::tr("Press V to revive in town"));
}

fn render_chat_draft(parent: &mut ChildSpawnerCommands, draft: &str) {
    body(
        parent,
        &crate::native_i18n::tr(&format!("Say: {}_", if draft.is_empty() { "" } else { draft })),
    );
}

fn mail_attachment_is_current(inventory: &InventoryModel, unique_id: u64) -> bool {
    unique_id != 0
        && inventory
            .items
            .iter()
            .any(|item| {
                item.container == 0
                    && item.slot < u32::from(inventory.bag_slot_capacity())
                    && item.unique_id == Some(unique_id)
            })
}

fn valid_mail_attachment_ids(inventory: &InventoryModel, ids: &[u64]) -> Option<Vec<u64>> {
    if ids.len() > MAX_MAIL_ATTACHMENTS
        || ids.iter().any(|id| *id == 0)
        || ids.windows(2).any(|window| window[0] == window[1])
    {
        return None;
    }
    let mut result = Vec::with_capacity(ids.len());
    for id in ids {
        if !mail_attachment_is_current(inventory, *id) || result.contains(id) {
            return None;
        }
        result.push(*id);
    }
    Some(result)
}

fn mail_reader_kind(message: &MailMessage) -> MailReaderKind {
    if message.has_attachment() {
        MailReaderKind::Parcel
    } else {
        MailReaderKind::Letter
    }
}

fn mail_reader_is_current(reader: &MailReaderUi, mail: &MailModel) -> bool {
    mail.mails.iter().any(|message| {
        message.id == reader.mail_id
            && message.operation.is_none()
            && mail_reader_kind(message) == reader.kind
    })
}

fn open_mail_reader(
    state: &mut NativePlayerUiState,
    mail: &MailModel,
    intents: &mut NativePlayerUiIntentQueue,
    pending: &mut PendingOperations,
    mail_id: u64,
) -> bool {
    let Some(message) = mail
        .mails
        .iter()
        .find(|message| message.id == mail_id && message.operation.is_none())
    else {
        return false;
    };
    if !message.read {
        // This status request has no negative acknowledgement. Opening the
        // source reader never depends on a later snapshot acknowledgement.
        let _ = intents.push_pending_intent(pending, NativePlayerUiIntent::ReadMail { mail_id });
    }
    state.mail_reader_windows.cancel();
    state.mail_reader = Some(MailReaderUi {
        mail_id,
        kind: mail_reader_kind(message),
    });
    true
}

fn mail_reader_message<'a>(
    state: &NativePlayerUiState,
    mail: &'a MailModel,
) -> Option<&'a MailMessage> {
    let reader = state.mail_reader.as_ref()?;
    mail.mails.iter().find(|message| {
        message.id == reader.mail_id
            && message.operation.is_none()
            && mail_reader_kind(message) == reader.kind
    })
}

fn mail_reader_text(message: &MailMessage) -> String {
    message.body.replace("\\r\\n", "\r\n")
}

fn overlay_wrapped_text_at(
    parent: &mut ChildSpawnerCommands,
    text: &str,
    rect: CrystalRect,
    font_size: f32,
    color: Color,
) {
    parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            overflow: Overflow::clip(),
            ..default()
        },
        Text::new(text.to_owned()),
        crate::crystal_ui::typography::crystal_text_font(font_size),
        TextColor(color),
        TextLayout::new(Justify::Left, LineBreak::WordOrCharacter),
    ));
}

fn spawn_mail_reader_button(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    library: &'static str,
    normal: u16,
    hover: u16,
    pressed: u16,
    disabled: u16,
    rect: CrystalRect,
    action: OverlayButton,
    enabled: bool,
) {
    if let Some(asset_server) = asset_server {
        spawn_overlay_crystal_button_enabled_with_disabled(
            parent,
            asset_server,
            library,
            normal,
            hover,
            pressed,
            Some(disabled),
            rect,
            action,
            enabled,
        );
    } else if enabled {
        spawn_invisible_overlay_button(parent, rect, action);
    }
}

fn render_mail_reader_header(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    message: &MailMessage,
    frame: &'static str,
    height: f32,
) {
    if let Some(asset_server) = asset_server {
        spawn_overlay_frame(parent, asset_server, frame, 236.0, height);
    }
    spawn_mail_reader_button(
        parent,
        asset_server,
        "Prguse2",
        360,
        361,
        362,
        362,
        CrystalRect::new(209.0, 3.0, 24.0, 21.0),
        OverlayButton::MailReaderClose,
        true,
    );
    overlay_text_at(
        parent,
        &message.sender,
        CrystalRect::new(70.0, 35.0, 150.0, 15.0),
        10.0,
        TEXT,
    );
    overlay_text_at(
        parent,
        &mail_date_label(message.date_sent_binary_datetime),
        CrystalRect::new(70.0, 56.0, 150.0, 15.0),
        10.0,
        TEXT,
    );
}

fn render_mail_reader_letter(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    message: &MailMessage,
) {
    render_mail_reader_header(
        parent,
        asset_server,
        message,
        "original-ui/Title/672.png",
        300.0,
    );
    overlay_wrapped_text_at(
        parent,
        &mail_reader_text(message),
        CrystalRect::new(15.0, 92.0, 202.0, 165.0),
        10.0,
        TEXT,
    );
    // Source handlers guard delete against Locked; retain the source button
    // but repeat that guard at the action boundary.
    spawn_mail_reader_button(
        parent,
        asset_server,
        "Title",
        540,
        541,
        542,
        542,
        CrystalRect::new(12.0, 265.0, 64.0, 25.0),
        OverlayButton::MailReaderDelete,
        true,
    );
    spawn_mail_reader_button(
        parent,
        asset_server,
        "Title",
        686,
        687,
        688,
        688,
        CrystalRect::new(81.0, 265.0, 64.0, 25.0),
        OverlayButton::MailReaderLock,
        true,
    );
    spawn_mail_reader_button(
        parent,
        asset_server,
        "Title",
        193,
        194,
        195,
        195,
        CrystalRect::new(154.0, 265.0, 68.0, 25.0),
        OverlayButton::MailReaderClose,
        true,
    );
}

fn render_mail_reader_parcel(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    message: &MailMessage,
) {
    render_mail_reader_header(
        parent,
        asset_server,
        message,
        "original-ui/Title/675.png",
        384.0,
    );
    overlay_wrapped_text_at(
        parent,
        &mail_reader_text(message),
        CrystalRect::new(15.0, 98.0, 202.0, 165.0),
        10.0,
        TEXT,
    );
    overlay_text_at(
        parent,
        &format_crystal_gold(message.gold),
        CrystalRect::new(63.0, 290.0, 143.0, 15.0),
        10.0,
        TEXT,
    );
    for (index, attachment) in message.items.iter().take(5).enumerate() {
        let left = 27.0 + index as f32 * 36.0;
        parent.spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(left),
                top: Val::Px(311.0),
                width: Val::Px(35.0),
                height: Val::Px(31.0),
                border: UiRect::all(Val::Px(1.0)),
                ..default()
            },
            BorderColor::all(Color::srgb(0.0, 1.0, 0.0)),
            BackgroundColor(Color::NONE),
        ));
        if let (Some(asset_server), Some(image)) = (
            asset_server,
            attachment.image.and_then(|image| u16::try_from(image).ok()),
        ) {
            parent.spawn(Node {
                position_type: PositionType::Absolute,
                left: Val::Px(left),
                top: Val::Px(311.0),
                width: Val::Px(35.0),
                height: Val::Px(31.0),
                ..default()
            }).with_children(|cell| {
                spawn_original_item_image(cell, asset_server, image, 35, 31);
            });
        }
        if attachment.count > 1 {
            overlay_text_at(
                parent,
                &attachment.count.to_string(),
                CrystalRect::new(left + 18.0, 327.0, 16.0, 12.0),
                9.0,
                Color::srgb(1.0, 1.0, 0.0),
            );
        }
    }
    let collect_enabled = mail_claim_enabled(message);
    spawn_mail_reader_button(
        parent,
        asset_server,
        "Title",
        680,
        681,
        682,
        683,
        CrystalRect::new(30.0, 350.0, 72.0, 25.0),
        OverlayButton::MailReaderClaim,
        collect_enabled,
    );
    spawn_mail_reader_button(
        parent,
        asset_server,
        "Title",
        193,
        194,
        195,
        195,
        CrystalRect::new(135.0, 350.0, 68.0, 25.0),
        OverlayButton::MailReaderClose,
        true,
    );
}

fn render_mail(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    mail: &MailModel,
    mail_ui: &MailUiState,
    inventory: &InventoryModel,
    state: &NativePlayerUiState,
    compose_ui: &MailComposeUi,
) {
    if let Some(asset_server) = asset_server {
        spawn_overlay_frame(
            parent,
            asset_server,
            "original-ui/Title/670.png",
            312.0,
            444.0,
        );
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Prguse2",
            360,
            361,
            362,
            CrystalRect::new(288.0, 3.0, 24.0, 21.0),
            OverlayButton::CloseMail,
        );
        // This is MailDialog's context-help control, not MenuDialog's global
        // HelpDialog button. Its source handler remains unimplemented here.
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            257,
            258,
            259,
            CrystalRect::new(262.0, 3.0, 24.0, 21.0),
            OverlayButton::CloseMail,
            false,
        );
    }
    let page = mail.page(mail_ui.cursor.page);
    if let Some(assets) = asset_server {
        spawn_static_overlay_sprite(parent, assets, "original-ui/Title/7.png".into(), CrystalRect::new(18.0, 9.0, 43.0, 14.0));
    }
    for (label, left, width) in [("Type", 8.0, 37.0), ("Sender", 47.0, 132.0), ("Message", 181.0, 122.0)] {
        overlay_text_at(parent, &crate::native_i18n::tr(label), CrystalRect::new(left, 34.0, width, 19.0), 10.0, TEXT);
    }
    for (row, msg) in page.entries.iter().enumerate() {
        mail_list::row(parent, asset_server, msg, row, mail.selected_id == Some(msg.id));
    }

    if let Some(asset_server) = asset_server {
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            240,
            241,
            242,
            CrystalRect::new(102.0, 389.0, 16.0, 16.0),
            OverlayButton::MailPagePrev,
            page.page > 0,
        );
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            243,
            244,
            245,
            CrystalRect::new(192.0, 389.0, 16.0, 16.0),
            OverlayButton::MailPageNext,
            page.page + 1 < page.page_count,
        );
    }
    overlay_text_at(
        parent,
        &crate::native_i18n::tr(&format!("{}/{}", page.page + 1, page.page_count)),
        CrystalRect::new(120.0, 389.0, 67.0, 15.0),
        9.0,
        TEXT,
    );

    let selected = mail.selected();
    let selected_id = selected.map(|message| message.id).unwrap_or_default();
    if let Some(asset_server) = asset_server {
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Prguse",
            563,
            564,
            565,
            CrystalRect::new(75.0, 414.0, 28.0, 25.0),
            OverlayButton::OpenMailCompose,
        );
        if selected.is_some_and(|message| message.can_reply) { spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse",
            569,
            570,
            571,
            CrystalRect::new(102.0, 414.0, 28.0, 25.0),
            OverlayButton::MailReply(selected_id),
            selected.is_some_and(|message| message.can_reply),
        ); }
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse",
            572,
            573,
            574,
            CrystalRect::new(129.0, 414.0, 28.0, 25.0),
            OverlayButton::ReadMail(selected_id),
            selected.is_some(),
        );
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse",
            557,
            558,
            559,
            CrystalRect::new(156.0, 414.0, 28.0, 25.0),
            OverlayButton::DeleteMail(selected_id),
            selected.is_some_and(mail_delete_enabled),
        );
        for (index, left) in [(520, 183.0), (523, 210.0)] {
            spawn_overlay_crystal_button_enabled(parent, asset_server, "Prguse", index, index + 1, index + 2,
                CrystalRect::new(left, 414.0, 28.0, 25.0), OverlayButton::CloseMail, false);
        }
    }
    // The explicit action is retained for ordinary mail access, but now uses
    // the same source `MailComposeParcelDialog` + recipient prompt as an NPC
    // MailSendRequest rather than a separate generic attachment form.
    overlay_button(
        parent,
        &crate::native_i18n::tr("Send items and gold"),
        OverlayButton::OpenMailParcelCompose,
        true,
    );
}

fn render_mail_compose(
    parent: &mut ChildSpawnerCommands,
    draft: &mir2_ui_core::state::MailComposeDraft,
    inventory: &InventoryModel,
) {
    body(parent, &crate::native_i18n::tr("Write mail (Tab switches field; Esc cancels)"));
    let message_label = if draft.message.is_empty() {
        "<type>".to_owned()
    } else {
        short_name(&draft.message, "<type>")
    };
    overlay_button(
        parent,
        &crate::native_i18n::tr(&format!(
            "Recipient: {}",
            if draft.recipient.is_empty() {
                "<type>"
            } else {
                &draft.recipient
            }
        )),
        OverlayButton::MailRecipientFocus,
        true,
    );
    overlay_button(
        parent,
        &crate::native_i18n::tr(&format!("Message: {message_label}")),
        OverlayButton::MailMessageFocus,
        true,
    );
    parent
        .spawn(Node {
            display: Display::Flex,
            flex_direction: FlexDirection::Row,
            column_gap: Val::Px(4.0),
            ..default()
        })
        .with_children(|row| {
            overlay_button(row, &crate::native_i18n::tr(&format!("Gold: {}", draft.gold)), OverlayButton::MailGoldFocus, true);
            overlay_button(row, "-100", OverlayButton::MailGoldDec, draft.gold >= 100);
            overlay_button(row, "+100", OverlayButton::MailGoldInc, true);
        });
    body(
        parent,
        &crate::native_i18n::tr(&format!("Attachments: {}/5", draft.attachment_unique_ids.len())),
    );
    for id in &draft.attachment_unique_ids {
        if let Some(item) = inventory
            .items
            .iter()
            .find(|item| matches!(item.container, 0 | 1) && item.unique_id == Some(*id))
        {
            parent
                .spawn(Node {
                    display: Display::Flex,
                    flex_direction: FlexDirection::Row,
                    column_gap: Val::Px(4.0),
                    ..default()
                })
                .with_children(|row| {
                    body(row, &crate::native_i18n::tr(&format!("{} ×{}", item.name, item.quantity)));
                    overlay_button(
                        row,
                        &crate::native_i18n::tr("Remove"),
                        OverlayButton::RemoveMailAttachment(*id),
                        true,
                    );
                });
        }
    }
    for item in inventory.items.iter().filter(|item| matches!(item.container, 0 | 1)) {
        let Some(id) = item.unique_id else { continue };
        if draft.attachment_unique_ids.contains(&id) {
            continue;
        }
        if draft.attachment_unique_ids.len() >= MAX_MAIL_ATTACHMENTS {
            break;
        }
        overlay_button(
            parent,
            &crate::native_i18n::tr(&format!(
                "Attach {} ×{} (Bag{} slot {})",
                item.name, item.quantity, item.container + 1, item.slot
            )),
            OverlayButton::AddMailAttachment(id),
            true,
        );
    }
    overlay_button(
        parent,
        &crate::native_i18n::tr("Send"),
        OverlayButton::SubmitMail,
        !draft.recipient.trim().is_empty() && !draft.message.trim().is_empty(),
    );
}

/// Crystal `MailComposeLetterDialog`: recipient is chosen by the preceding
/// input box and is display-only here; the message remains a real multiline
/// field instead of the list adapter's shortened preview.
fn render_mail_compose_letter(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    draft: &mir2_ui_core::state::MailComposeDraft,
    compose_ui: &MailComposeUi,
    letter_editor: Option<&mail_editor::MailLetterEditor>,
) {
    if let Some(asset_server) = asset_server {
        spawn_overlay_frame(parent, asset_server, "original-ui/Title/671.png", 236.0, 300.0);
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Prguse2",
            360,
            361,
            362,
            CrystalRect::new(209.0, 3.0, 24.0, 21.0),
            OverlayButton::CancelMailCompose,
        );
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Title",
            607,
            608,
            609,
            CrystalRect::new(30.0, 265.0, 76.0, 25.0),
            OverlayButton::SubmitMail,
        );
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Title",
            193,
            194,
            195,
            CrystalRect::new(135.0, 265.0, 68.0, 25.0),
            OverlayButton::CancelMailCompose,
        );
    }
    overlay_text_at(
        parent,
        &draft.recipient,
        CrystalRect::new(70.0, 35.0, 150.0, 15.0),
        crate::crystal_ui::typography::CRYSTAL_DEFAULT_FONT_SIZE_PX,
        TEXT,
    );
    if let Some(editor) = letter_editor {
        editor.render(parent);
    } else {
        // Lightweight renderer-only test apps may omit the editing resource.
        // The real overlay plugin initializes it before this panel can open.
        overlay_text_at(
            parent,
            &draft.message,
            mail_editor::MAIL_LETTER_BODY_RECT,
            crate::crystal_ui::typography::CRYSTAL_DEFAULT_FONT_SIZE_PX,
            TEXT,
        );
    }
    if let Some(notice) = compose_ui.last_notice.as_deref() {
        overlay_text_at(
            parent,
            notice,
            CrystalRect::new(15.0, 72.0, 202.0, 15.0),
            8.0,
            TEXT,
        );
    }
}

fn render_mail_recipient_prompt(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    prompt: &MailRecipientPrompt,
) {
    parent
        .spawn((
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.left),
                top: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.top),
                width: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.width),
                height: Val::Px(CRYSTAL_STORAGE_PASSWORD_RECT.height),
                overflow: Overflow::clip(),
                ..default()
            },
            BackgroundColor(PANEL_BG),
        ))
        .with_children(|dialog| {
            if let Some(asset_server) = asset_server {
                spawn_overlay_frame(
                    dialog,
                    asset_server,
                    "original-ui/Prguse/660.png",
                    CRYSTAL_STORAGE_PASSWORD_RECT.width,
                    CRYSTAL_STORAGE_PASSWORD_RECT.height,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    200,
                    201,
                    202,
                    CrystalRect::new(60.0, 123.0, 76.0, 25.0),
                    OverlayButton::MailRecipientSubmit,
                );
                spawn_overlay_crystal_button(
                    dialog,
                    asset_server,
                    "Title",
                    203,
                    204,
                    205,
                    CrystalRect::new(160.0, 123.0, 76.0, 25.0),
                    OverlayButton::MailRecipientCancel,
                );
            }
            overlay_centered_text_at(
                dialog,
                &crate::native_i18n::tr("Enter mail recipient name"),
                CrystalRect::new(25.0, 25.0, 235.0, 40.0),
                10.0,
                TEXT,
            );
            dialog
                .spawn((
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(23.0),
                        top: Val::Px(86.0),
                        width: Val::Px(240.0),
                        height: Val::Px(19.0),
                        border: UiRect::all(Val::Px(1.0)),
                        padding: UiRect::axes(Val::Px(2.0), Val::Px(0.0)),
                        overflow: Overflow::clip(),
                        ..default()
                    },
                    BackgroundColor(Color::BLACK),
                    BorderColor::all(Color::srgb(0.0, 1.0, 0.0)),
                ))
                .with_children(|input| {
                    input.spawn((
                        Text::new(prompt.recipient.clone()),
                        crate::crystal_ui::typography::crystal_text_font(10.0),
                        TextColor(TEXT),
                        TextLayout::new(Justify::Left, LineBreak::NoWrap),
                    ));
                });
        });
}

fn render_bigmap(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    model: &BigMapModel,
    renderer: &BigMapUiState,
    ui: &UiReadModel,
) {
    let Some(asset_server) = asset_server else {
        return;
    };
    let rendered = model.render_snapshot();
    let source_geometry = crate::big_map::BigMapImageGeometry::for_model(model);
    // The full rectangle is only a loading placeholder, never invented image geometry.
    let geometry = source_geometry.unwrap_or(crate::big_map::BigMapImageGeometry::WORLD);
    let map_name = rendered
        .title
        .as_deref()
        .or(ui.player.map_name.as_deref())
        .unwrap_or("");
    spawn_overlay_frame(
        parent,
        asset_server,
        "original-ui/Title/820.png",
        760.0,
        500.0,
    );
    if !renderer.hunt_regions.is_empty() && model.view != BigMapView::WorldMap {
        parent.spawn((Node {
            position_type: PositionType::Absolute,
            left: Val::Px(16.0), top: Val::Px(30.0),
            ..default()
        }, Text::new(crate::native_i18n::tr("Cyan: current task · Amber: other tasks (possible spawn areas)")),
           crate::crystal_ui::typography::crystal_text_font(10.0),
           TextColor(Color::srgb(1.0, 0.82, 0.2))));
    }
    parent.spawn((
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(19.0),
            top: Val::Px(6.0),
            width: Val::Px(699.0),
            height: Val::Px(20.0),
            ..default()
        },
        Text::new(crate::player_text::name(map_name)),
        crate::crystal_ui::typography::crystal_text_font(12.0),
        TextColor(Color::WHITE),
        TextLayout::justify(Justify::Center),
    ));

    parent
        .spawn(Node {
            position_type: PositionType::Absolute,
            left: Val::Px(geometry.left),
            top: Val::Px(geometry.top),
            width: Val::Px(geometry.width),
            height: Val::Px(geometry.height),
            overflow: Overflow::clip(),
            ..default()
        })
        .with_children(|viewport| {
            let asset = source_geometry.and(rendered.map_image_url.clone());
            if let Some(asset) = asset {
                viewport.spawn((
                    BigMapImageEntity { url: asset.clone() },
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(0.0),
                        top: Val::Px(0.0),
                        width: Val::Px(geometry.width),
                        height: Val::Px(geometry.height),
                        ..default()
                    },
                    ImageNode {
                        image: asset_server.load(asset),
                        image_mode: NodeImageMode::Stretch,
                        ..default()
                    },
                ));
            } else {
                viewport.spawn((
                    Node {
                        width: Val::Percent(100.0),
                        height: Val::Percent(100.0),
                        ..default()
                    },
                    BackgroundColor(Color::srgb(0.02, 0.015, 0.01)),
                ));
                viewport.spawn((
                    BigMapLoadingText,
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(0.0),
                        top: Val::Px(geometry.height * 0.5 - 8.0),
                        width: Val::Px(geometry.width),
                        height: Val::Px(16.0),
                        ..default()
                    },
                    Text::new(crate::native_i18n::tr("Loading map...")),
                    crate::crystal_ui::typography::crystal_text_font(12.0),
                    TextColor(Color::srgb(0.82, 0.74, 0.55)),
                    TextLayout::justify(Justify::Center),
                ));
            }

            if model.view == BigMapView::WorldMap && model.world.enabled {
                for index in [1365_u16, 1366_u16] {
                    viewport.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: Val::Px(0.0),
                            top: Val::Px(0.0),
                            width: Val::Px(geometry.width),
                            height: Val::Px(geometry.height),
                            ..default()
                        },
                        ImageNode {
                            image: asset_server.load(format!("original-ui/Prguse2/{index}.png")),
                            image_mode: NodeImageMode::Stretch,
                            ..default()
                        },
                    ));
                }
            } else if let Some(entry) = model.active_map().filter(|_| source_geometry.is_some()) {
                for movement in &entry.info.movements {
                    let (x, y) = geometry.view_position(
                        movement.location,
                        entry.info.width,
                        entry.info.height,
                    );
                    viewport.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: Val::Px(x - 2.0),
                            top: Val::Px(y - 2.0),
                            width: Val::Px(4.0),
                            height: Val::Px(4.0),
                            ..default()
                        },
                        BackgroundColor(GOLD),
                    ));
                }
                for (index, region) in renderer.hunt_regions.iter().enumerate() {
                    let color = if region.primary { Color::srgb(0.2, 0.9, 1.0) }
                        else { Color::srgb(1.0, 0.72, 0.1) };
                    let (left, top) = geometry.view_position(
                        BigMapPoint { x: region.center.x - region.radius, y: region.center.y - region.radius },
                        entry.info.width, entry.info.height,
                    );
                    let (right, bottom) = geometry.view_position(
                        BigMapPoint { x: region.center.x + region.radius, y: region.center.y + region.radius },
                        entry.info.width, entry.info.height,
                    );
                    viewport.spawn((Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(left), top: Val::Px(top),
                        width: Val::Px((right-left).max(4.0)), height: Val::Px((bottom-top).max(4.0)),
                        border: UiRect::all(Val::Px(2.0)),
                        ..default()
                    }, BackgroundColor(Color::srgba(1.0, 0.65, 0.0, 0.18)),
                       BorderColor::all(color)));
                    viewport.spawn((Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(left.min(geometry.width - 180.0).max(0.0)),
                        top: Val::Px(top.max(15.0) - 15.0 + index as f32 * 2.0),
                        ..default()
                    }, BackgroundColor(Color::srgba(0.02, 0.015, 0.0, 0.9)),
                       Text::new(crate::native_i18n::tr(&format!("{}{}: {} left ({},{})", if region.primary { "[Tracked] " } else { "" }, region.name, region.remaining, region.center.x, region.center.y))),
                       crate::crystal_ui::typography::crystal_text_font(11.0),
                       TextColor(Color::srgb(1.0, 0.82, 0.2))));
                }
                if renderer.bichon_safe_destination && model.view == BigMapView::CurrentMap
                    && crate::quest_destination::is_bichon_map(entry.map_index)
                {
                    use crate::quest_destination::{BICHON_SAFE_X, BICHON_SAFE_Y, BICHON_SAFE_RADIUS};
                    let (left, top) = geometry.view_position(BigMapPoint {
                        x: BICHON_SAFE_X - BICHON_SAFE_RADIUS, y: BICHON_SAFE_Y - BICHON_SAFE_RADIUS,
                    }, entry.info.width, entry.info.height);
                    let (right, bottom) = geometry.view_position(BigMapPoint {
                        x: BICHON_SAFE_X + BICHON_SAFE_RADIUS, y: BICHON_SAFE_Y + BICHON_SAFE_RADIUS,
                    }, entry.info.width, entry.info.height);
                    viewport.spawn((BichonSafeDestinationArea, Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(left), top: Val::Px(top),
                        width: Val::Px((right - left).max(4.0)),
                        height: Val::Px((bottom - top).max(4.0)),
                        border: UiRect::all(Val::Px(2.0)), ..default()
                    }, BackgroundColor(Color::srgba(0.1, 0.85, 1.0, 0.2)),
                        BorderColor::all(Color::srgb(0.2, 0.9, 1.0))));
                    viewport.spawn((Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(left.min(geometry.width - 210.0).max(0.0)),
                        top: Val::Px((top - 22.0).max(0.0)), ..default()
                    }, BackgroundColor(Color::srgba(0.01, 0.03, 0.04, 0.95)),
                        Text::new(crate::native_i18n::tr("比奇城安全区 (328,264)")),
                        TextFont { font: FontSource::Family("Microsoft YaHei".into()),
                            font_size: FontSize::Px(14.0), ..default() },
                        TextColor(Color::srgb(0.4, 0.95, 1.0))));
                }
                for npc in entry.info.npcs.iter().filter(|npc| npc.show_on_big_map) {
                    let (x, y) =
                        geometry.view_position(npc.location, entry.info.width, entry.info.height);
                    viewport.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: Val::Px(x - 2.0),
                            top: Val::Px(y - 2.0),
                            width: Val::Px(5.0),
                            height: Val::Px(5.0),
                            ..default()
                        },
                        BackgroundColor(if model.selected_npc_object_id == Some(npc.object_id) {
                            Color::srgb(1.0, 0.35, 0.12)
                        } else {
                            Color::srgb(0.25, 0.95, 0.35)
                        }),
                    ));
                }
                if let Some(location) = rendered.player_location {
                    let (px, py) =
                        geometry.view_position(location, entry.info.width, entry.info.height);
                    viewport.spawn((
                        BigMapPlayerEntity { location },
                        Node {
                            position_type: PositionType::Absolute,
                            left: Val::Px(px - 6.0),
                            top: Val::Px(py - 5.0),
                            width: Val::Px(12.0),
                            height: Val::Px(10.0),
                            ..default()
                        },
                        ImageNode {
                            image: asset_server.load("original-ui/Prguse2/1350.png"),
                            ..default()
                        },
                    ));
                }
            }
        });

    parent.spawn((
        big_map_coordinates::CoordinateLabel,
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(519.0),
            top: Val::Px(435.0),
            width: Val::Px(100.0),
            height: Val::Px(15.0),
            ..default()
        },
        Text::new(""),
        crate::crystal_ui::typography::crystal_text_font(11.0),
        TextColor(Color::WHITE),
    ));

    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        360,
        361,
        362,
        CrystalRect::new(735.0, 3.0, 24.0, 21.0),
        OverlayButton::CloseBigMap,
    );

    let filtered_count = model.filtered_npcs().len();
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Prguse2",
        197,
        198,
        199,
        CrystalRect::new(739.0, 48.0, 16.0, 16.0),
        OverlayButton::BigMapScrollUp,
        model.npc_scroll_row > 0,
    );
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Prguse2/205.png".to_owned(),
        CrystalRect::new(739.0, 61.0, 16.0, 16.0),
    );
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Prguse2",
        207,
        208,
        209,
        CrystalRect::new(739.0, 417.0, 16.0, 16.0),
        OverlayButton::BigMapScrollDown,
        model.npc_scroll_row.saturating_add(BIG_MAP_NPC_ROW_COUNT) < filtered_count,
    );
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Title",
        827,
        828,
        829,
        CrystalRect::new(250.0, 467.0, 80.0, 25.0),
        OverlayButton::BigMapWorld,
        model.world.enabled,
    );
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Title",
        824,
        825,
        826,
        CrystalRect::new(400.0, 467.0, 80.0, 25.0),
        OverlayButton::BigMapMyLocation,
        model.current_map_index.is_some(),
    );
    spawn_overlay_crystal_button_enabled_with_disabled(
        parent,
        asset_server,
        "Title",
        821,
        822,
        823,
        Some(823),
        CrystalRect::new(638.0, 432.0, 72.0, 25.0),
        OverlayButton::BigMapTeleport,
        model.selected_teleport_intent().is_some(),
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        1340,
        1341,
        1342,
        CrystalRect::new(23.0, 464.0, 32.0, 30.0),
        OverlayButton::BigMapSearchSubmit,
    );
    overlay_absolute_button(
        parent,
        &model.search.draft,
        CrystalRect::new(59.0, 468.0, 130.0, 20.0),
        OverlayButton::BigMapSearchFocus,
        true,
    );
    if renderer.search_focused {
        overlay_text_at(
            parent,
            "|",
            CrystalRect::new(183.0, 470.0, 4.0, 12.0),
            10.0,
            GOLD,
        );
    }

    for (row, npc) in rendered.npcs.iter().enumerate() {
        let label = format!("{} [{},{}]", crate::player_text::name(&npc.name), npc.location.x, npc.location.y);
        overlay_absolute_button(
            parent,
            &label,
            CrystalRect::new(590.0, 50.0 + row as f32 * 21.0, 140.0, 25.0),
            OverlayButton::SelectBigMapNpc(npc.object_id),
            npc.object_id != 0,
        );
        parent.spawn(BigMapNpcRowEntity {
            object_id: npc.object_id,
            name: npc.name.clone(),
            location: npc.location,
        });
    }
}

fn render_shop(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    shop: &ShopModel,
    shop_ui: &ShopUiState,
    inventory: &InventoryModel,
    state: &NativePlayerUiState,
    player: &crate::read_model::PlayerStats,
) {
    let show_buy = shop.allows_buy() && (!shop.allows_sell() || state.npc_shop_buy_tab);
    if !show_buy {
        npc_item_service::render(parent, asset_server, shop, inventory, state);
        return;
    }
    let buy_enabled = shop_buy_enabled_with_pearls(
        shop,
        inventory,
        state.shop_quantity,
        state.creature.pearls.max(0) as u32,
    );

    if let Some(asset_server) = asset_server {
        // Crystal NPCGoodsDialog uses the intrinsic Prguse/1000 frame size.
        spawn_overlay_frame(
            parent,
            asset_server,
            "original-ui/Prguse/1000.png",
            NPC_GOODS_PANEL_SIZE.width as f32,
            NPC_GOODS_PANEL_SIZE.height as f32,
        );
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Prguse2",
            360,
            361,
            362,
            CrystalRect::new(217.0, 3.0, 24.0, 21.0),
            OverlayButton::CloseShop,
        );
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            197,
            198,
            199,
            CrystalRect::new(219.0, 35.0, 12.0, 12.0),
            OverlayButton::ShopPageUp,
            shop_ui.start_index > 0,
        );
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Prguse2",
            207,
            208,
            209,
            CrystalRect::new(219.0, 284.0, 12.0, 12.0),
            OverlayButton::ShopPageDown,
            shop_ui.start_index.saturating_add(8) < shop.goods.len(),
        );
        let max_start = shop.goods.len().saturating_sub(8);
        let scroll_top = if max_start == 0 {
            49.0
        } else {
            49.0 + 217.0 * shop_ui.start_index as f32 / max_start as f32
        };
        spawn_static_overlay_sprite(
            parent,
            asset_server,
            "original-ui/Prguse2/205.png".to_owned(),
            CrystalRect::new(219.0, scroll_top, 12.0, 18.0),
        );
        spawn_overlay_crystal_button_enabled(
            parent,
            asset_server,
            "Title",
            312,
            313,
            314,
            CrystalRect::new(77.0, 304.0, 80.0, 25.0),
            OverlayButton::ShopBuy,
            buy_enabled,
        );
    } else {
        overlay_absolute_button(
            parent,
            &crate::native_i18n::tr("Close"),
            CrystalRect::new(217.0, 3.0, 24.0, 21.0),
            OverlayButton::CloseShop,
            true,
        );
        overlay_absolute_button(
            parent,
            "↑",
            CrystalRect::new(219.0, 35.0, 12.0, 12.0),
            OverlayButton::ShopPageUp,
            shop_ui.start_index > 0,
        );
        overlay_absolute_button(
            parent,
            "↓",
            CrystalRect::new(219.0, 284.0, 12.0, 12.0),
            OverlayButton::ShopPageDown,
            shop_ui.start_index.saturating_add(8) < shop.goods.len(),
        );
        overlay_absolute_button(
            parent,
            &crate::native_i18n::tr("Buy"),
            CrystalRect::new(77.0, 304.0, 80.0, 25.0),
            OverlayButton::ShopBuy,
            buy_enabled,
        );
    }

    for (row, good) in shop
        .goods
        .iter()
        .skip(shop_ui.start_index)
        .take(8)
        .enumerate()
    {
        let selected = shop.selected_id == Some(good.unique_id);
        let show_new_icon = crystal_npc_goods_new_icon_visible(good, &shop.goods);
        overlay_absolute_shop_good_button(
            parent,
            asset_server,
            good,
            crystal_npc_goods_cell_rect(row),
            OverlayButton::SelectShopGood(good.unique_id),
            player,
            selected,
            shop.hide_added_stats,
            show_new_icon,
        );
    }
    if shop.goods.is_empty() {
        overlay_text_at(
            parent,
            &crate::native_i18n::tr("No goods"),
            CrystalRect::new(12.0, 40.0, 195.0, 18.0),
            10.0,
            TEXT,
        );
    }
    overlay_text_at(
        parent,
        &crate::player_text::text(&format!("Gold {}", inventory.gold)),
        CrystalRect::new(10.0, 8.0, 150.0, 16.0),
        10.0,
        GOLD,
    );
    overlay_absolute_button(
        parent,
        "−",
        CrystalRect::new(12.0, 304.0, 20.0, 22.0),
        OverlayButton::ShopQuantityDec,
        state.shop_quantity > SHOP_QUANTITY_MIN,
    );
    overlay_text_at(
        parent,
        &crate::native_i18n::tr(&format!("x{}", shop_quantity_clamped(state.shop_quantity))),
        CrystalRect::new(34.0, 306.0, 36.0, 18.0),
        10.0,
        TEXT,
    );
    overlay_absolute_button(
        parent,
        "+",
        CrystalRect::new(58.0, 304.0, 18.0, 22.0),
        OverlayButton::ShopQuantityInc,
        state.shop_quantity < SHOP_QUANTITY_MAX,
    );
    if shop.allows_sell() {
        overlay_absolute_button(
            parent,
            &crate::native_i18n::tr("Sell"),
            CrystalRect::new(162.0, 304.0, 52.0, 22.0),
            OverlayButton::ShopShowSell,
            true,
        );
    }
}


fn native_skill_page_count(item_count: usize) -> usize {
    item_count
        .saturating_add(SKILL_PAGE_SIZE.saturating_sub(1))
        .checked_div(SKILL_PAGE_SIZE)
        .unwrap_or(0)
        .max(1)
}

fn native_game_shop_page_count(item_count: usize) -> usize {
    item_count
        .saturating_add(CRYSTAL_GAME_SHOP_PAGE_SIZE.saturating_sub(1))
        .checked_div(CRYSTAL_GAME_SHOP_PAGE_SIZE)
        .unwrap_or(0)
        .max(1)
}

fn native_game_shop_page_for_index(
    game_shop: &GameShopModel,
    game_shop_index: i32,
) -> Option<usize> {
    game_shop
        .items
        .iter()
        .position(|entry| entry.game_shop_index == game_shop_index)
        .map(|position| position / CRYSTAL_GAME_SHOP_PAGE_SIZE)
}

fn native_game_shop_page_entries(
    game_shop: &GameShopModel,
    page: usize,
) -> &[crate::game_shop::GameShopEntry] {
    let start = page.saturating_mul(CRYSTAL_GAME_SHOP_PAGE_SIZE);
    let end = (start + CRYSTAL_GAME_SHOP_PAGE_SIZE).min(game_shop.items.len());
    game_shop.items.get(start..end).unwrap_or(&[])
}

fn render_storage(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    storage: &StorageModel,
    storage_ui: &StorageUiState,
    _inventory: &InventoryModel,
    _state: &NativePlayerUiState,
    player: &crate::read_model::PlayerStats,
) {
    let Some(asset_server) = asset_server else {
        return;
    };
    spawn_overlay_frame(
        parent,
        asset_server,
        "original-ui/Prguse/586.png",
        388.0,
        346.0,
    );
    spawn_static_overlay_sprite(
        parent,
        asset_server,
        "original-ui/Title/0.png".to_owned(),
        CrystalRect::new(18.0, 8.0, 71.0, 15.0),
    );
    let page = storage.page(storage_ui.cursor.page);
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Title",
        if page.page == 0 { 743 } else { 744 },
        if page.page == 0 { 743 } else { 744 },
        744,
        CrystalRect::new(8.0, 36.0, 72.0, 20.0),
        OverlayButton::StoragePage(0),
    );
    // RefreshStorage2 is always a live MirButton. An un-rented page is shown
    // by the LockedPage cover below instead of disabling this tab.
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Title",
        if page.page == 1 { 745 } else { 746 },
        if page.page == 1 { 745 } else { 746 },
        746,
        CrystalRect::new(80.0, 36.0, 72.0, 20.0),
        OverlayButton::StoragePage(1),
    );
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        360,
        361,
        362,
        CrystalRect::new(363.0, 3.0, 24.0, 21.0),
        OverlayButton::CloseStorage,
    );

    if page.rental_locked {
        // NPCDialogs.RefreshStorage2: hide all cells and cover the second
        // page with Prguse[2443] until the rental becomes authoritative.
        spawn_static_overlay_sprite(
            parent,
            asset_server,
            "original-ui/Prguse/2443.png".to_owned(),
            CrystalRect::new(8.0, 59.0, 372.0, 265.0),
        );
        overlay_centered_text_at(
            parent,
            &crate::native_i18n::tr("Expanded Storage Locked"),
            CrystalRect::new(40.0, 322.0, 300.0, 16.0),
            10.0,
            Color::srgb(0.95, 0.20, 0.20),
        );
    } else {
        for (offset, slot) in page.slots.iter().enumerate() {
            let column = offset % 10;
            let row = offset / 10;
            let rect = CrystalRect::new(
                9.0 + column as f32 * 37.0,
                60.0 + row as f32 * 33.0,
                36.0,
                32.0,
            );
            if let Some(item) = slot.item {
                let selected = storage_ui.storage_selection
                    == slot.unique_id.map(|unique_id| StorageItemSelection {
                        slot: slot.slot,
                        unique_id,
                    });
                overlay_absolute_item_button(
                    parent,
                    asset_server,
                    item,
                    rect,
                    OverlayButton::SelectStorage(slot.slot),
                    !slot.locked && item.unique_id.is_some(),
                    false,
                    player,
                );
                if selected {
                    overlay_text_at(parent, "▶", rect, 10.0, GOLD);
                }
            } else {
                parent.spawn((
                    Node {
                        position_type: PositionType::Absolute,
                        left: Val::Px(rect.left),
                        top: Val::Px(rect.top),
                        width: Val::Px(rect.width),
                        height: Val::Px(rect.height),
                        ..default()
                    },
                    BackgroundColor(if slot.locked {
                        Color::srgba(0.20, 0.16, 0.11, 0.70)
                    } else {
                        Color::srgba(0.06, 0.04, 0.02, 0.35)
                    }),
                ));
            }
        }
    }

    if page.page == 1 {
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            "Title",
            483,
            484,
            485,
            CrystalRect::new(283.0, 33.0, 48.0, 25.0),
            OverlayButton::StorageExpand,
        );
        if !page.rental_locked {
            let label = storage_expiry_label(page.expiry)
                .map(|expiry| format!("{}{expiry}", crate::native_i18n::tr("Expanded Storage Expires On")))
                .unwrap_or_else(|| crate::native_i18n::tr("Expanded Storage Expires On"));
            overlay_centered_text_at(
                parent,
                &label,
                CrystalRect::new(40.0, 322.0, 300.0, 16.0),
                10.0,
                TEXT,
            );
        }
    }
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Title",
        113,
        114,
        115,
        CrystalRect::new(328.0, 33.0, 48.0, 25.0),
        if storage.has_password && !storage.unlocked {
            OverlayButton::StorageUnlock
        } else {
            OverlayButton::StorageSetPassword
        },
    );
}

/// Safely decodes the .NET DateTime binary value carried by ResizeStorage.
/// Invalid/zero values retain the source label without exposing raw ticks.
fn storage_expiry_label(binary_datetime: i64) -> Option<String> {
    const DOTNET_TICKS_MASK: u64 = 0x3fff_ffff_ffff_ffff;
    const DOTNET_KIND_MASK: u64 = 0xc000_0000_0000_0000;
    const DOTNET_KIND_LOCAL: u64 = 0x8000_0000_0000_0000;
    const DOTNET_UNIX_EPOCH_TICKS: i128 = 621_355_968_000_000_000;
    const DOTNET_MAX_TICKS: i128 = 3_155_378_975_999_999_999;
    const DOTNET_TICKS_PER_SECOND: i128 = 10_000_000;
    if binary_datetime == 0 {
        return None;
    }
    let bits = binary_datetime as u64;
    let ticks = i128::from(bits & DOTNET_TICKS_MASK);
    if ticks > DOTNET_MAX_TICKS {
        return None;
    }
    let unix_ticks = ticks - DOTNET_UNIX_EPOCH_TICKS;
    let seconds = unix_ticks.div_euclid(DOTNET_TICKS_PER_SECOND);
    let nanos = unix_ticks.rem_euclid(DOTNET_TICKS_PER_SECOND).saturating_mul(100);
    let (Ok(seconds), Ok(nanos)) = (i64::try_from(seconds), u32::try_from(nanos)) else {
        return None;
    };
    let utc = chrono::DateTime::<chrono::Utc>::from_timestamp(seconds, nanos)?;
    Some(if bits & DOTNET_KIND_MASK == DOTNET_KIND_LOCAL {
        utc.with_timezone(&chrono::Local)
            .format("%Y/%m/%d %H:%M:%S")
            .to_string()
    } else {
        utc.format("%Y/%m/%d %H:%M:%S").to_string()
    })
}

fn spawn_invisible_overlay_button(
    parent: &mut ChildSpawnerCommands,
    rect: CrystalRect,
    action: OverlayButton,
) {
    parent.spawn((
        Button,
        action,
        Node {
            position_type: PositionType::Absolute,
            left: Val::Px(rect.left),
            top: Val::Px(rect.top),
            width: Val::Px(rect.width),
            height: Val::Px(rect.height),
            ..default()
        },
        BackgroundColor(Color::NONE),
    ));
}

fn spawn_option_volume_bar(
    parent: &mut ChildSpawnerCommands,
    asset_server: &AssetServer,
    channel: options_volume::VolumeChannel,
    volume: u8,
) {
    let ratio = f32::from(volume.min(100)) / 100.0;
    let fill_width = 74.0 * ratio;
    parent
        .spawn((
            options_volume::OptionsVolumeTrack(channel),
            Node {
                position_type: PositionType::Absolute,
                left: Val::Px(options_volume::rect(channel).left),
                top: Val::Px(options_volume::rect(channel).top),
                width: Val::Px(options_volume::rect(channel).width),
                height: Val::Px(options_volume::rect(channel).height),
                overflow: Overflow::clip(),
                ..default()
            },
            FocusPolicy::Block,
            BackgroundColor(Color::NONE),
        ))
        .with_children(|track| {
            track
                .spawn(Node {
                    position_type: PositionType::Absolute,
                    left: Val::Px(0.0),
                    top: Val::Px(0.0),
                    width: Val::Px(fill_width),
                    height: Val::Px(19.0),
                    overflow: Overflow::clip(),
                    ..default()
                })
                .with_children(|clip| {
                    clip.spawn((
                        Node {
                            position_type: PositionType::Absolute,
                            left: Val::Px(0.0),
                            top: Val::Px(0.0),
                            width: Val::Px(76.0),
                            height: Val::Px(19.0),
                            ..default()
                        },
                        ImageNode {
                            image: asset_server.load("original-ui/Prguse2/468.png"),
                            ..default()
                        },
                    ));
                });
        });
    let bar = options_volume::rect(channel);
    parent.spawn((
        options_volume::OptionsVolumeThumb(channel),
        Node {
            position_type: PositionType::Absolute,
            // MainDialogs.cs puts the source `VolumeBar` control at the
            // SoundBar's x plus the clipped 74px fill, not at its older
            // adapter-only x-4 offset.
            left: Val::Px(bar.left + fill_width),
            top: Val::Px(bar.top - 7.0),
            width: Val::Px(8.0),
            height: Val::Px(22.0),
            ..default()
        },
        ImageNode {
            image: asset_server.load("original-ui/Prguse/20.png"),
            ..default()
        },
    ));
}

fn render_options(
    parent: &mut ChildSpawnerCommands,
    asset_server: Option<&AssetServer>,
    core: &mir2_ui_core::state::UiState,
) {
    let Some(asset_server) = asset_server else {
        return;
    };
    let options = &core.options;
    spawn_overlay_frame(
        parent,
        asset_server,
        "original-ui/Title/411.png",
        259.0,
        354.0,
    );
    if crate::native_i18n::active() {
        // Cover the baked English wording, preserving the original borders and
        // every source button/slider hit target. Locale preferences are separate
        // from gameplay options and are never sent to the server.
        localized_art_label(parent, "Options", CrystalRect::new(12.0, 7.0, 214.0, 25.0), 13.0);
        for (label, top) in [("Skill mode",68.0),("Skill bar",93.0),("Effects",118.0),("Ground items",143.0),("Names",168.0),("Health bars",193.0),("Sound",220.0),("Music",244.0),("Allow observation",271.0),("New movement",296.0)] {
            localized_art_label(parent, label, CrystalRect::new(12.0, top - 2.0, 138.0, 23.0), 10.0);
        }
        parent.spawn((Node { position_type: PositionType::Absolute, left: Val::Px(0.0), top: Val::Px(353.0), width: Val::Px(259.0), padding: UiRect::all(Val::Px(10.0)), row_gap: Val::Px(4.0), flex_direction: FlexDirection::Column, border: UiRect::all(Val::Px(1.0)), ..default() }, BackgroundColor(Color::srgb(0.055,0.045,0.03)), BorderColor::all(GOLD)))
            .with_children(|languages| {
                title(languages, &crate::native_i18n::tr("Language"));
                crate::native_i18n::spawn_language_choices(languages, 12.0);
            });
    }
    spawn_overlay_crystal_button(
        parent,
        asset_server,
        "Prguse2",
        360,
        361,
        362,
        CrystalRect::new(233.0, 5.0, 24.0, 21.0),
        OverlayButton::CloseOptions,
    );

    use mir2_ui_core::state::UiCrystalOption;
    for (
        option,
        value,
        library,
        selected_on,
        unselected_on,
        selected_off,
        unselected_off,
        on_pressed,
        off_pressed,
        top,
    ) in [
        (
            UiCrystalOption::SkillMode,
            options.skill_mode,
            "Prguse2",
            452,
            450,
            453,
            455,
            451,
            454,
            68.0,
        ),
        (
            UiCrystalOption::SkillBar,
            options.skill_bar,
            "Prguse2",
            458,
            456,
            459,
            461,
            457,
            460,
            93.0,
        ),
        (
            UiCrystalOption::Effect,
            options.effect,
            "Prguse2",
            458,
            456,
            459,
            461,
            457,
            460,
            118.0,
        ),
        (
            UiCrystalOption::DropView,
            options.drop_view,
            "Prguse2",
            458,
            456,
            459,
            461,
            457,
            460,
            143.0,
        ),
        (
            UiCrystalOption::NameView,
            options.name_view,
            "Prguse2",
            458,
            456,
            459,
            461,
            457,
            460,
            168.0,
        ),
        (
            UiCrystalOption::HpView,
            options.hp_view,
            "Prguse2",
            464,
            462,
            465,
            467,
            463,
            466,
            193.0,
        ),
        (
            UiCrystalOption::NewMove,
            options.new_move,
            "Title",
            853,
            851,
            848,
            850,
            853,
            850,
            296.0,
        ),
    ] {
        let on_index = if value { selected_on } else { unselected_on };
        let off_index = if value { selected_off } else { unselected_off };
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            library,
            on_index,
            on_index,
            on_pressed,
            CrystalRect::new(159.0, top, 36.0, 17.0),
            OverlayButton::SetCrystalOption(option, true),
        );
        spawn_overlay_crystal_button(
            parent,
            asset_server,
            library,
            off_index,
            off_index,
            off_pressed,
            CrystalRect::new(201.0, top, 36.0, 17.0),
            OverlayButton::SetCrystalOption(option, false),
        );
    }

    let observe_enabled = core.observe_request_pending.is_none();
    let observe_on = if core.observe_allowed { 458 } else { 456 };
    let observe_off = if core.observe_allowed { 459 } else { 461 };
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Prguse2",
        observe_on,
        observe_on,
        457,
        CrystalRect::new(159.0, 271.0, 36.0, 17.0),
        OverlayButton::OptionsObserve(true),
        observe_enabled,
    );
    spawn_overlay_crystal_button_enabled(
        parent,
        asset_server,
        "Prguse2",
        observe_off,
        observe_off,
        460,
        CrystalRect::new(201.0, 271.0, 36.0, 17.0),
        OverlayButton::OptionsObserve(false),
        observe_enabled,
    );

    let sound_volume = if options.sound_enabled {
        options.sound_volume
    } else {
        0
    };
    let music_volume = if options.music_enabled {
        options.music_volume
    } else {
        0
    };
    spawn_option_volume_bar(
        parent,
        asset_server,
        options_volume::VolumeChannel::Sound,
        sound_volume,
    );
    spawn_option_volume_bar(
        parent,
        asset_server,
        options_volume::VolumeChannel::Music,
        music_volume,
    );
}

fn short_name(name: &str, key: &str) -> String {
    let source = if name.trim().is_empty() { key } else { name };
    let mut chars = source.chars();
    let taken: String = chars.by_ref().take(8).collect();
    if chars.next().is_some() {
        // The bundled Crystal bitmap font has no U+2026 glyph. Keep the
        // truncation marker ASCII so product names never end in a tofu box.
        format!("{taken}..")
    } else {
        taken
    }
}

fn inventory_cell_stack_label(item: &ItemModel) -> String {
    item.crystal_stack_label()
}

fn title(parent: &mut ChildSpawnerCommands, text: &str) {
    parent.spawn((
        Text::new(text.to_owned()),
        crate::crystal_ui::typography::crystal_text_font(14.0),
        TextColor(GOLD),
    ));
}

fn body(parent: &mut ChildSpawnerCommands, text: &str) {
    parent.spawn((
        Text::new(text.to_owned()),
        crate::crystal_ui::typography::crystal_text_font(11.0),
        TextColor(TEXT),
    ));
}

fn overlay_button(
    parent: &mut ChildSpawnerCommands,
    label: &str,
    action: OverlayButton,
    enabled: bool,
) {
    let mut entity = parent.spawn((
        Node {
            width: Val::Percent(100.0),
            min_height: Val::Px(18.0),
            padding: UiRect::all(Val::Px(3.0)),
            justify_content: JustifyContent::FlexStart,
            align_items: AlignItems::Center,
            overflow: Overflow::clip(),
            ..default()
        },
        BackgroundColor(if enabled { BUTTON_BG } else { BUTTON_DISABLED }),
    ));
    if enabled {
        entity.insert((Button, action));
    }
    entity.with_children(|button| {
        button.spawn((
            Text::new(label.to_owned()),
            crate::crystal_ui::typography::crystal_text_font(10.0),
            TextColor(if enabled {
                TEXT
            } else {
                Color::srgba(0.8, 0.8, 0.8, 0.5)
            }),
            TextLayout::new(Justify::Left, LineBreak::NoWrap),
        ));
    });
}

#[cfg(test)]
#[path = "storage_drag_tests.rs"]
mod storage_drag_tests;

#[cfg(test)]
#[path = "npc_shop_layout_tests.rs"]
pub(crate) mod npc_shop_layout_tests;

#[cfg(test)]
#[path = "nonmodal_input_tests.rs"]
mod nonmodal_input_tests;

#[cfg(test)]
#[path = "equipment_storage_tests.rs"]
mod equipment_storage_tests;

#[cfg(test)]
#[path = "storage_password_tests.rs"]
mod storage_password_tests;

#[cfg(test)]
#[path = "storage_rental_tests.rs"]
mod storage_rental_tests;

#[cfg(test)]
#[path = "mail_delete_tests.rs"]
mod mail_delete_tests;

#[cfg(test)]
#[path = "mail_feedback_tests.rs"]
mod mail_feedback_tests;

#[cfg(test)]
#[path = "mail_reader_tests.rs"]
mod mail_reader_tests;
#[cfg(test)]
#[path = "mail_compose_input_tests.rs"]
mod mail_compose_input_tests;

#[cfg(test)]
#[path = "mail_compose_tests.rs"]
mod mail_compose_tests;

#[cfg(test)]
#[path = "mail_parcel_tests.rs"]
mod mail_parcel_tests;

#[cfg(test)]
mod tests {
    #[test]
    fn item_use_time_is_shared_across_player_hero_and_survives_draining() {
        let mut q = super::NativePlayerUiIntentQueue::default();
        let player = super::NativePlayerUiIntent::UseItem {
            key: None,
            unique_id: Some(10),
            slot: None,
            grid: Some("inventory".into()),
        };
        let hero = super::NativePlayerUiIntent::HeroPacket(mir2_protocol::ClientPacket::UseItem {
            grid: mir2_protocol::MirGridType::HeroInventory,
            unique_id: 20,
        });
        assert!(q.push_intent_at(player.clone(), 1000, 300));
        q.drain_intents();
        assert!(!q.push_intent_at(hero.clone(), 1299, 300));
        assert!(q.push_intent_at(hero.clone(), 1300, 100));
        assert!(!q.push_intent_at(player.clone(), 1399, 300));
        assert!(q.push_intent_at(player, 1400, 300));
        assert!(!q.use_item_ready(1699));
        assert!(q.use_item_ready(1700));
    }

    use super::*;
    use crate::crystal_ui::widget::CrystalImageButton;
    use crate::inventory::{
        CrystalItemInfoModel, CrystalItemTooltipSourceModel, CrystalUserItemModel,
    };
    use crate::mail::MailMessage;
    use crate::shop::ShopGood;
    use bevy::asset::{AssetApp, AssetPlugin};
    use bevy::input::keyboard::Key;

    #[test]
    fn inventory_hud_pointer_edges_enqueue_one_crystal_button_a_sound() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, consume_hud_buttons);

        let button = app
            .world_mut()
            .spawn((Interaction::None, CrystalHudAction::Inventory))
            .id();
        app.update();
        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );

        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            1
        );

        // Changed<Interaction> consumes the pointer edge, never the held state.
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            1
        );
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonA]
        );

        app.world_mut().entity_mut(button).insert(Interaction::None);
        app.update();
        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            1
        );
        app.world_mut()
            .resource_mut::<crate::audio::NativeUiAudioQueue>()
            .drain_bounded(8);

        // A stale press outside InGame is neither a click nor a sound.
        app.world_mut().resource_mut::<NativeShellModel>().screen = NativeShellScreen::Login;
        app.world_mut().entity_mut(button).insert(Interaction::None);
        app.update();
        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );

        // Keyboard inventory toggles call the state directly and never enter
        // the HUD pointer producer.
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );
    }

    #[test]
    fn crystal_character_source_geometry_matches_character_dialog() {
        assert_eq!(
            CRYSTAL_CHARACTER_PANEL_RECT,
            CrystalRect::new(760.0, 0.0, 264.0, 380.0)
        );
        assert_eq!(
            CRYSTAL_CHARACTER_PAGE_RECT,
            CrystalRect::new(8.0, 90.0, 248.0, 284.0)
        );
        assert_eq!(
            CRYSTAL_CHARACTER_EQUIPMENT_SLOTS,
            [
                (0, CrystalRect::new(131.0, 97.0, 36.0, 32.0)),
                (1, CrystalRect::new(171.0, 97.0, 36.0, 32.0)),
                (2, CrystalRect::new(211.0, 97.0, 36.0, 32.0)),
                (13, CrystalRect::new(211.0, 152.0, 36.0, 32.0)),
                (4, CrystalRect::new(211.0, 188.0, 36.0, 32.0)),
                (3, CrystalRect::new(211.0, 224.0, 36.0, 32.0)),
                (5, CrystalRect::new(16.0, 260.0, 36.0, 32.0)),
                (6, CrystalRect::new(211.0, 260.0, 36.0, 32.0)),
                (7, CrystalRect::new(16.0, 296.0, 36.0, 32.0)),
                (8, CrystalRect::new(211.0, 296.0, 36.0, 32.0)),
                (9, CrystalRect::new(16.0, 332.0, 36.0, 32.0)),
                (11, CrystalRect::new(56.0, 332.0, 36.0, 32.0)),
                (10, CrystalRect::new(96.0, 332.0, 36.0, 32.0)),
                (12, CrystalRect::new(136.0, 332.0, 36.0, 32.0)),
            ]
        );
    }

    #[test]
    fn crystal_character_gender_class_and_guild_projection_is_exact() {
        assert_eq!(crystal_character_page_index(Some("Male")), 340);
        assert_eq!(crystal_character_page_index(Some("female")), 341);
        assert_eq!(crystal_character_page_index(None), 340);
        assert_eq!(
            crystal_character_class_image_index(Some("Warrior")),
            Some(100)
        );
        assert_eq!(
            crystal_character_class_image_index(Some("Wizard")),
            Some(101)
        );
        assert_eq!(
            crystal_character_class_image_index(Some("Taoist")),
            Some(102)
        );
        assert_eq!(
            crystal_character_class_image_index(Some("Assassin")),
            Some(103)
        );
        assert_eq!(
            crystal_character_class_image_index(Some("Archer")),
            Some(104)
        );
        assert_eq!(crystal_character_class_image_index(Some("unknown")), None);

        let mut ui = UiReadModel::default();
        ui.player.guild_name = Some("  Crystal Guild ".to_owned());
        ui.player.guild_rank_name = Some(" Leader ".to_owned());
        assert_eq!(crystal_character_guild_label(&ui), "Crystal Guild Leader");
    }

    #[test]
    fn crystal_character_hair_uses_source_index_offsets_and_assassin_adjustment() {
        assert_eq!(
            crystal_character_hair_frame(Some("Warrior"), Some("Male"), Some(0)),
            Some(CrystalFrameSpec::new(
                "Prguse",
                441,
                CrystalRect::new(131.0, 173.0, 16.0, 14.0)
            ))
        );
        assert_eq!(
            crystal_character_hair_frame(Some("Assassin"), Some("Male"), Some(0)),
            Some(CrystalFrameSpec::new(
                "Prguse",
                461,
                CrystalRect::new(131.0, 172.0, 16.0, 21.0)
            ))
        );
        assert_eq!(
            crystal_character_hair_frame(Some("Wizard"), Some("Female"), Some(8)),
            Some(CrystalFrameSpec::new(
                "Prguse",
                489,
                CrystalRect::new(118.0, 168.0, 40.0, 30.0)
            ))
        );
        assert_eq!(
            crystal_character_hair_frame(Some("Assassin"), Some("Female"), Some(0)),
            Some(CrystalFrameSpec::new(
                "Prguse",
                501,
                CrystalRect::new(126.0, 174.0, 24.0, 24.0)
            ))
        );
        assert!(crystal_character_hair_frame(Some("Warrior"), None, Some(0)).is_none());
        assert!(crystal_character_hair_frame(Some("Warrior"), Some("Male"), Some(9)).is_none());
    }

    #[test]
    fn crystal_character_wings_use_exact_source_indices_offsets_and_draw_blend() {
        let source: serde_json::Value = serde_json::from_str(include_str!(
            "../../../../web/public/original-ui/Prguse2/meta.json"
        ))
        .expect("original Prguse2 export metadata");
        for (effect, gender, index, rect) in [
            (1, "Male", 1202, CrystalRect::new(64.0, 138.0, 148.0, 139.0)),
            (
                1,
                "Female",
                1203,
                CrystalRect::new(64.0, 145.0, 148.0, 144.0),
            ),
            (2, "Male", 1204, CrystalRect::new(55.0, 140.0, 156.0, 185.0)),
            (
                2,
                "Female",
                1205,
                CrystalRect::new(56.0, 144.0, 156.0, 185.0),
            ),
        ] {
            assert_eq!(
                crystal_character_wing_frame(Some(effect), Some(gender)),
                Some(CrystalFrameSpec::new("Prguse2", index, rect))
            );
            let metadata = source["frames"]
                .as_array()
                .unwrap()
                .iter()
                .find(|frame| frame["index"].as_u64() == Some(u64::from(index)))
                .expect("exact wing frame in original library");
            for (field, value) in [
                ("x", rect.left),
                ("y", rect.top),
                ("width", rect.width),
                ("height", rect.height),
            ] {
                assert_eq!(
                    metadata[field].as_f64(),
                    Some(f64::from(value)),
                    "frame {index} {field}"
                );
            }
        }
        assert!(crystal_character_wing_frame(None, Some("Male")).is_none());
        assert!(crystal_character_wing_frame(Some(0), Some("Male")).is_none());
        assert!(crystal_character_wing_frame(Some(3), Some("Female")).is_none());
        assert!(crystal_character_wing_frame(Some(1), None).is_none());

        assert_eq!(
            CRYSTAL_DRAW_BLEND_STATE.color,
            BlendComponent {
                src_factor: BlendFactor::SrcAlpha,
                dst_factor: BlendFactor::One,
                operation: BlendOperation::Add,
            }
        );
    }

    #[test]
    fn crystal_character_wing_material_installs_source_additive_pipeline_and_fixed_handles() {
        use bevy::render::render_resource::{
            ColorTargetState, ColorWrites, FragmentState, TextureFormat,
        };

        let format = TextureFormat::Bgra8UnormSrgb;
        let mut descriptor = RenderPipelineDescriptor {
            fragment: Some(FragmentState {
                targets: vec![Some(ColorTargetState {
                    format,
                    blend: Some(BlendState::ALPHA_BLENDING),
                    write_mask: ColorWrites::ALL,
                })],
                ..default()
            }),
            ..default()
        };
        CrystalAdditiveUiMaterial::specialize(
            &mut descriptor,
            UiMaterialKey {
                target_format: format,
                bind_group_data: (),
            },
        );
        assert_eq!(
            descriptor.fragment.unwrap().targets[0]
                .as_ref()
                .unwrap()
                .blend,
            Some(CRYSTAL_DRAW_BLEND_STATE)
        );
        assert!(matches!(CrystalAdditiveUiMaterial::fragment_shader(),
            ShaderRef::Handle(handle) if handle == CRYSTAL_ADDITIVE_UI_SHADER_HANDLE));

        let mut assets = Assets::<CrystalAdditiveUiMaterial>::default();
        let handles = CrystalCharacterWingMaterials(std::array::from_fn(|_| {
            assets.add(CrystalAdditiveUiMaterial {
                image: Handle::default(),
            })
        }));
        for index in 1202..=1205 {
            assert_eq!(
                handles.get(index),
                Some(&handles.0[usize::from(index - 1202)])
            );
        }
        assert!(handles.get(1201).is_none());
        assert!(handles.get(1206).is_none());
        assert_eq!(
            assets.len(),
            4,
            "one retained material per source wing frame"
        );
    }

    #[test]
    fn crystal_character_paper_doll_order_is_wing_armour_weapon_then_helmet_or_hair() {
        let state_item = |slot, image, x, y, width, height| ItemModel {
            container: 2,
            slot,
            state_image: image,
            state_image_x: x,
            state_image_y: y,
            state_image_width: width,
            state_image_height: height,
            ..Default::default()
        };
        let mut inventory = InventoryModel::default();
        inventory.items = vec![
            state_item(0, 30, 75, 186, 28, 57),
            state_item(1, 60, 92, 194, 80, 128),
        ];
        let mut ui = UiReadModel::default();
        ui.player.class_name = Some("Warrior".to_owned());
        ui.player.gender = Some("Male".to_owned());
        ui.player.hair = Some(0);
        ui.player.wing_effect = Some(1);

        let layers = crystal_character_paper_doll_layers(&inventory, &ui);
        assert_eq!(
            layers
                .iter()
                .map(|layer| layer.frame.index)
                .collect::<Vec<_>>(),
            vec![1202, 60, 30, 441]
        );
        assert_eq!(layers[0].blend, CrystalCharacterBlend::DrawBlend);
        assert_eq!(layers[1].blend, CrystalCharacterBlend::Alpha);
        assert_eq!(
            layers[0].frame.rect,
            CrystalRect::new(64.0, 138.0, 148.0, 139.0)
        );
        assert_eq!(
            layers[1].frame.rect,
            CrystalRect::new(92.0, 194.0, 80.0, 128.0)
        );

        inventory.items.push(state_item(2, 100, 120, 160, 24, 30));
        let layers = crystal_character_paper_doll_layers(&inventory, &ui);
        assert_eq!(
            layers
                .iter()
                .map(|layer| layer.frame.index)
                .collect::<Vec<_>>(),
            vec![1202, 60, 30, 100],
            "a present helmet suppresses Crystal's hair fallback"
        );

        inventory.items.retain(|item| item.slot != 1);
        let layers = crystal_character_paper_doll_layers(&inventory, &ui);
        assert_eq!(
            layers
                .iter()
                .map(|layer| layer.frame.index)
                .collect::<Vec<_>>(),
            vec![30, 100],
            "Crystal never draws a wing without an equipped armour item"
        );
    }

    #[test]
    fn character_hud_pointer_uses_button_a_and_restores_character_page() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, consume_hud_buttons);

        // Crystal keeps CharacterDialog visible and switches a non-character
        // page back to CharacterPage on the first HUD click.
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.character_page = CharacterPage::Stats1;
            state.toggle_equipment();
        }
        let button = app
            .world_mut()
            .spawn((
                Interaction::None,
                CrystalHudAction::Character,
                CrystalImageButton {
                    assets: super::super::assets::CrystalButtonAssetSet::from_spec(
                        super::super::spec::hud::CHARACTER,
                    ),
                    focused: false,
                    enabled: true,
                },
            ))
            .id();
        app.update();
        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        let state = app.world().resource::<NativePlayerUiState>();
        assert!(state.equipment_open());
        assert_eq!(state.character_page, CharacterPage::Character);
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            1
        );
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());

        // A held press neither repeats ButtonA nor invokes the callback.
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .equipment_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            1
        );
        app.world_mut()
            .resource_mut::<crate::audio::NativeUiAudioQueue>()
            .drain_bounded(8);

        // A second edge closes the already-visible CharacterPage and plays
        // exactly one new ButtonA cue.
        app.world_mut().entity_mut(button).insert(Interaction::None);
        app.update();
        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .equipment_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            1
        );
        app.world_mut()
            .resource_mut::<crate::audio::NativeUiAudioQueue>()
            .drain_bounded(8);

        // Disabled image buttons are not valid clicks even if a synthetic
        // Interaction component changes under test.
        app.world_mut()
            .entity_mut(button)
            .get_mut::<CrystalImageButton>()
            .expect("image button")
            .enabled = false;
        app.world_mut().entity_mut(button).insert(Interaction::None);
        app.update();
        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .equipment_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );

        // Keyboard activation shares the source page-state transition but
        // stays outside the pointer/audio producer.
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .activate_character_hud_button();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .equipment_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
    }

    #[test]
    fn foreground_close_press_blocks_overlapping_minimap_hud_press() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, consume_hud_buttons);
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Character;
            state.core.minimap_visible = true;
        }
        app.world_mut()
            .spawn((Interaction::Pressed, CrystalHudAction::MinimapToggle));
        app.world_mut()
            .spawn((Interaction::Pressed, OverlayButton::CloseCharacter));

        app.update();

        let state = app.world().resource::<NativePlayerUiState>();
        assert!(state.minimap_visible());
        assert!(state.equipment_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );
    }

    #[test]
    fn character_hud_activation_restores_every_non_character_page_before_closing() {
        for page in [
            CharacterPage::Stats1,
            CharacterPage::Stats2,
            CharacterPage::Spells,
        ] {
            let mut state = NativePlayerUiState::default();
            state.character_page = page;
            state.toggle_equipment();
            assert!(state.equipment_open());

            state.activate_character_hud_button();
            assert!(state.equipment_open());
            assert_eq!(state.character_page, CharacterPage::Character);

            state.activate_character_hud_button();
            assert!(!state.equipment_open());
        }
    }

    #[test]
    fn menu_hud_pointer_uses_button_c_and_toggles_menu_without_gameplay_intents() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, consume_hud_buttons);

        let button = app
            .world_mut()
            .spawn((Interaction::None, CrystalHudAction::Menu))
            .id();
        app.update();

        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        assert!(app.world().resource::<NativePlayerUiState>().menu_open());
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonC]
        );
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
    }

    #[test]
    fn five_small_main_hud_buttons_emit_button_a_on_real_press_edges() {
        for action in [
            CrystalHudAction::Inventory,
            CrystalHudAction::Character,
            CrystalHudAction::Skill,
            CrystalHudAction::Quest,
            CrystalHudAction::Option,
        ] {
            let mut app = App::new();
            app.init_resource::<NativePlayerUiState>()
                .init_resource::<InventoryModel>()
                .init_resource::<NativePlayerUiIntentQueue>()
                .init_resource::<crate::audio::NativeUiAudioQueue>()
                .insert_resource(NativeShellModel {
                    screen: NativeShellScreen::InGame,
                    ..Default::default()
                })
                .add_systems(Update, consume_hud_buttons);
            let button = app.world_mut().spawn((Interaction::None, action)).id();
            app.update();

            app.world_mut()
                .entity_mut(button)
                .insert(Interaction::Pressed);
            app.update();
            assert_eq!(
                app.world_mut()
                    .resource_mut::<crate::audio::NativeUiAudioQueue>()
                    .drain_bounded(8),
                vec![crate::audio::NativeUiSound::ButtonA],
                "{action:?} must emit exactly one Crystal ButtonA edge"
            );
            assert!(app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .is_empty());
        }
    }

    #[test]
    fn game_shop_hud_pointer_uses_button_c_and_resets_quantity_only_on_close() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, consume_hud_buttons);

        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.shop_quantity = 7;
        }
        let button = app
            .world_mut()
            .spawn((Interaction::None, CrystalHudAction::GameShop))
            .id();
        app.update();

        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        {
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(state.shop_open());
            assert_eq!(state.shop_quantity, 7);
        }
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonC]
        );

        app.world_mut().entity_mut(button).insert(Interaction::None);
        app.update();
        app.world_mut()
            .entity_mut(button)
            .insert(Interaction::Pressed);
        app.update();
        {
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(!state.shop_open());
            assert_eq!(state.shop_quantity, 1);
        }
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonC]
        );
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
    }

    #[test]
    fn compact_labels_use_supported_ascii_and_bag_cells_hide_durability() {
        assert_eq!(short_name("DestructionDrug", "fallback"), "Destruct..");

        let durable = ItemModel {
            quantity: 1,
            durability_current: Some(400),
            durability_max: Some(400),
            ..default()
        };
        assert_eq!(inventory_cell_stack_label(&durable), "");

        let stacked = ItemModel {
            quantity: 12,
            ..default()
        };
        assert_eq!(inventory_cell_stack_label(&stacked), "12");
    }

    #[test]
    fn inventory_icons_use_true_size_centering_and_fail_closed_without_geometry() {
        primary_item_image_tests::assert_inventory_icon_geometry_and_missing_source();
    }

    #[test]
    fn operation_disabled_inventory_item_remains_a_rich_tooltip_hover_target() {
        let mut app = overlay_render_test_app();
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Inventory;
            state.inventory_operation = Some(InventoryOperationDraft::Move {
                source_slot: 0,
                unique_id: 42,
            });
        }
        app.world_mut().resource_mut::<InventoryModel>().items = vec![ItemModel {
            unique_id: Some(42),
            key: "wooden-sword".to_owned(),
            name: "Wooden Sword".to_owned(),
            quantity: 1,
            slot: 0,
            container: 0,
            tooltip_source: Some(CrystalItemTooltipSourceModel {
                info: CrystalItemInfoModel {
                    item_index: 221,
                    name: "Wooden Sword".to_owned(),
                    item_type: 1,
                    durability: 4000,
                    ..Default::default()
                },
                user_item: Some(CrystalUserItemModel {
                    unique_id: 42,
                    item_index: 221,
                    current_dura: 3000,
                    max_dura: 4000,
                    count: 1,
                    ..Default::default()
                }),
                socket_infos: Vec::new(),
                ..Default::default()
            }),
            ..Default::default()
        }];

        app.update();

        let world = app.world_mut();
        let mut query =
            world.query_filtered::<(&CrystalItemHint, Option<&OverlayButton>), With<Button>>();
        let (hint, action) = query
            .iter(world)
            .find(|(hint, _)| hint.0.plain_text().contains("木剑"))
            .expect("occupied inventory cell stays hoverable while its action is disabled");
        assert!(hint.0.source_complete);
        assert!(hint.0.plain_text().contains("Weapon"));
        assert_eq!(action, None);
    }

    #[test]
    fn warehouse_uses_the_concurrent_bag_rich_tooltip_document() {
        let mut app = overlay_render_test_app();
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::Storage;
        app.world_mut().resource_mut::<InventoryModel>().items = vec![ItemModel {
            unique_id: Some(43),
            key: "small-hp-drug".to_owned(),
            name: "Small HP Drug".to_owned(),
            quantity: 5,
            slot: 0,
            container: 0,
            tooltip_source: Some(CrystalItemTooltipSourceModel {
                info: CrystalItemInfoModel {
                    item_index: 658,
                    name: "(HP)DrugSmall".to_owned(),
                    item_type: 13,
                    weight: 1,
                    stack_size: 20,
                    ..Default::default()
                },
                user_item: Some(CrystalUserItemModel {
                    unique_id: 43,
                    item_index: 658,
                    count: 5,
                    ..Default::default()
                }),
                ..Default::default()
            }),
            ..Default::default()
        }];

        app.update();

        let world = app.world_mut();
        let mut query =
            world.query_filtered::<(&CrystalItemHint, Option<&OverlayButton>), With<Button>>();
        let (hint, action) = query
            .iter(world)
            .find(|(hint, _)| hint.0.plain_text().contains("小型红药 (5)"))
            .expect("concurrent warehouse bag must remain a rich item hover target");
        assert!(hint.0.source_complete);
        assert!(hint.0.plain_text().contains("Potion"));
        assert!(matches!(action, Some(OverlayButton::InspectBag(0))));
    }

    fn surface_tooltip_source(
        item_index: i32,
        name: &str,
        image: u16,
        unique_id: u64,
        count: u16,
    ) -> CrystalItemTooltipSourceModel {
        CrystalItemTooltipSourceModel {
            info: CrystalItemInfoModel {
                item_index,
                name: name.to_owned(),
                item_type: 13,
                image,
                stack_size: 20,
                ..Default::default()
            },
            user_item: Some(CrystalUserItemModel {
                unique_id,
                item_index,
                count,
                ..Default::default()
            }),
            ..Default::default()
        }
    }

    fn assert_rendered_rich_hint(app: &mut App, expected_name: &str) {
        let world = app.world_mut();
        let mut query = world.query::<&CrystalItemHint>();
        let hint = query
            .iter(world)
            .find(|hint| hint.0.plain_text().contains(expected_name))
            .unwrap_or_else(|| panic!("missing rich hint for {expected_name}"));
        assert!(hint.0.source_complete);
        assert!(hint.0.plain_text().contains("Potion"));
    }

    #[test]
    fn npc_game_shop_guild_and_trade_cells_share_the_crystal_item_hint_lifecycle() {
        let mut app = overlay_render_test_app();

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::NpcShop;
        {
            let mut shop = app.world_mut().resource_mut::<ShopModel>();
            shop.service_mode = NpcShopServiceMode::Buy;
            shop.goods = vec![ShopGood {
                unique_id: 101,
                name: "NPC Potion".to_owned(),
                count: 3,
                icon: 532,
                tooltip_source: Some(surface_tooltip_source(658, "NPC Potion", 532, 101, 3)),
                ..Default::default()
            }];
        }
        app.update();
        assert_rendered_rich_hint(&mut app, "NPC Potion (3)");

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::GameShop;
        app.world_mut().resource_mut::<GameShopModel>().items =
            vec![crate::game_shop::GameShopEntry {
                item_index: 659,
                game_shop_index: 31,
                item_name: "Cash Potion".to_owned(),
                image: 533,
                count: 2,
                class: "All".to_owned(),
                tooltip_source: Some(surface_tooltip_source(659, "Cash Potion", 533, 0, 2)),
                ..Default::default()
            }];
        app.update();
        assert_rendered_rich_hint(&mut app, "Cash Potion (2)");

        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Guild;
            state.guild_left_page = GuildLeftPage::Storage;
        }
        app.world_mut()
            .resource_mut::<crate::social::SocialModel>()
            .guild
            .storage_items = vec![Some(crate::social::GuildStorageItemModel {
            unique_id: 202,
            item_index: 660,
            count: 4,
            user_id: 7,
            tooltip_source: Some(surface_tooltip_source(660, "Guild Potion", 534, 202, 4)),
        })];
        app.update();
        assert_rendered_rich_hint(&mut app, "Guild Potion (4)");

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::Trade;
        app.world_mut()
            .resource_mut::<crate::social::SocialModel>()
            .trade
            .partner_items = vec![Some(crate::social::TradeItemModel {
            unique_id: Some(303),
            item_index: Some(661),
            name: Some("Trade Potion".to_owned()),
            count: 5,
            tooltip_source: Some(surface_tooltip_source(661, "Trade Potion", 535, 303, 5)),
        })];
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .trade_dialog
            .open = true;
        app.update();
        assert_rendered_rich_hint(&mut app, "Trade Potion (5)");
    }

    #[test]
    fn npc_goods_cell_uses_crystal_geometry_labels_selection_and_hidden_added_stats() {
        let mut app = overlay_render_test_app();
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::NpcShop;

        let mut source = surface_tooltip_source(221, "Wooden Sword", 7, 101, 3);
        source.info.item_type = 1;
        source.info.stats = vec![
            crate::inventory::CrystalItemStatModel { stat: 4, value: 2 },
            crate::inventory::CrystalItemStatModel { stat: 5, value: 4 },
        ];
        let item = source.user_item.as_mut().expect("shop user item");
        item.is_shop_item = false;
        item.cursed = true;
        item.added_stats = vec![crate::inventory::CrystalItemStatModel { stat: 5, value: 9 }];

        {
            let mut shop = app.world_mut().resource_mut::<ShopModel>();
            shop.service_mode = NpcShopServiceMode::Buy;
            shop.hide_added_stats = true;
            shop.selected_id = Some(101);
            shop.goods = vec![ShopGood {
                unique_id: 101,
                name: "Wooden Sword".to_owned(),
                price: 50,
                count: 3,
                icon: 7,
                icon_width: 36,
                icon_height: 26,
                tooltip_source: Some(source),
                ..Default::default()
            }];
        }

        app.update();

        primary_item_image_tests::load_original_images(app.world_mut());
        {
            let world = app.world_mut();
            let mut cell_query = world.query_filtered::<
                (&Node, &Outline, &CrystalItemHint),
                With<OverlayNpcShopGoodCell>,
            >();
            let (cell, outline, hint) = cell_query.single(world).expect("NPC goods cell");
            assert_eq!(cell.left, Val::Px(10.0));
            assert_eq!(cell.top, Val::Px(34.0));
            assert_eq!(cell.width, Val::Px(205.0));
            assert_eq!(cell.height, Val::Px(32.0));
            assert_eq!(outline.width, Val::Px(1.0));
            assert_eq!(outline.color, Color::srgb(0.0, 1.0, 0.0));
            assert!(hint.0.plain_text().contains("DC + 2~4"));
            assert!(!hint.0.plain_text().contains("(+9)"));
            assert!(!hint.0.plain_text().contains("Cursed"));

            let mut icon_query = world.query_filtered::<&Node, With<OverlayNpcShopGoodIcon>>();
            let icon = icon_query.single(world).expect("true-size shop icon");
            assert_eq!(icon.left, Val::Px(2.0));
            assert_eq!(icon.top, Val::Px(3.0));
            assert_eq!(icon.width, Val::Px(36.0));
            assert_eq!(icon.height, Val::Px(26.0));

            let mut divider_query =
                world.query_filtered::<&Node, With<OverlayNpcShopGoodSelectionDivider>>();
            let divider = divider_query.single(world).expect("selection divider");
            assert_eq!(divider.left, Val::Px(40.0));
            assert_eq!(divider.height, Val::Px(32.0));

            let mut new_icon_query =
                world.query_filtered::<&Node, With<OverlayNpcShopGoodNewIcon>>();
            let new_icon = new_icon_query.single(world).expect("Crystal new icon");
            assert_eq!(new_icon.left, Val::Px(190.0));
            assert_eq!(new_icon.top, Val::Px(5.0));
            assert_eq!(new_icon.width, Val::Px(12.0));
            assert_eq!(new_icon.height, Val::Px(9.0));
        }

        let (name, name_left, name_top) = {
            let world = app.world_mut();
            let mut query = world.query_filtered::<(&Text, &Node), With<OverlayNpcShopGoodName>>();
            let (text, node) = query.single(world).expect("name label");
            (text.0.clone(), node.left, node.top)
        };
        let (price, price_left, price_top) = {
            let world = app.world_mut();
            let mut query = world.query_filtered::<(&Text, &Node), With<OverlayNpcShopGoodPrice>>();
            let (text, node) = query.single(world).expect("price label");
            (text.0.clone(), node.left, node.top)
        };
        let (count, count_left, count_top) = {
            let world = app.world_mut();
            let mut query = world.query_filtered::<(&Text, &Node), With<OverlayNpcShopGoodCount>>();
            let (text, node) = query.single(world).expect("count label");
            (text.0.clone(), node.left, node.top)
        };
        assert_eq!(name, "木剑");
        assert_eq!((name_left, name_top), (Val::Px(44.0), Val::Px(0.0)));
        assert_eq!(price, "价格：50 金币");
        assert_eq!((price_left, price_top), (Val::Px(44.0), Val::Px(14.0)));
        assert_eq!(count, "3");
        assert_eq!((count_left, count_top), (Val::Px(23.0), Val::Px(17.0)));
    }

    #[test]
    fn npc_goods_geometry_and_new_marker_match_mir_goods_cell_rules() {
        assert_eq!(
            crystal_npc_goods_cell_rect(7),
            CrystalRect::new(10.0, 265.0, 205.0, 32.0)
        );
        let mut good = ShopGood {
            icon: 7,
            icon_width: 36,
            icon_height: 26,
            tooltip_source: Some(surface_tooltip_source(221, "Sword", 7, 1, 1)),
            ..Default::default()
        };
        assert_eq!(good.user_item_image_index(), Some(7));
        good.tooltip_source
            .as_mut()
            .unwrap()
            .user_item
            .as_mut()
            .unwrap()
            .is_shop_item = true;
        assert!(!crystal_npc_goods_new_icon_visible(
            &good,
            std::slice::from_ref(&good)
        ));
    }

    #[test]
    fn options_adapter_applies_immediately_and_close_does_not_roll_back() {
        let mut state = NativePlayerUiState::default();
        let mut effects = UiEffectQueue::default();
        dispatch_ui_action(
            &mut state.core,
            &mut effects,
            mir2_ui_core::action::UiAction::OpenOptions,
        );
        dispatch_ui_action(
            &mut state.core,
            &mut effects,
            mir2_ui_core::action::UiAction::SetMusicVolume { volume: 25 },
        );
        dispatch_ui_action(
            &mut state.core,
            &mut effects,
            mir2_ui_core::action::UiAction::ClosePanel,
        );
        assert_eq!(state.core.options.music_volume, 25);
        assert_eq!(state.core.panel, mir2_ui_core::state::UiPanel::None);
        let effects = effects.drain();
        assert_eq!(effects.len(), 2);
        assert!(effects.iter().any(|effect| matches!(
            effect,
            mir2_ui_core::effect::UiEffect::ApplyAudioSettings {
                music_volume: 25,
                ..
            }
        )));
        assert!(effects.iter().any(|effect| matches!(
            effect,
            mir2_ui_core::effect::UiEffect::PersistOptions { .. }
        )));
    }

    #[test]
    fn hud_controls_remain_above_quest_world_blocker_and_options_switches_panel() {
        // This intentionally wires the real native HUD, overlay renderer and
        // quest renderer together.  A reducer-only test cannot catch the
        // full-stage quest modal blocker covering the HUD hit target.
        let mut app = App::new();
        app.add_plugins((MinimalPlugins, bevy::asset::AssetPlugin::default()))
            .init_asset::<Image>()
            .init_asset::<bevy::audio::AudioSource>()
            .init_resource::<ButtonInput<KeyCode>>()
            .add_message::<KeyboardInput>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_plugins((
                super::super::hud::Mir2CrystalHudPlugin,
                crate::quest_ui::Mir2QuestUiPlugin,
            ));

        // Startup creates the actual HUD/Quest/Options entities.
        app.update();

        let option_button = {
            let mut query = app.world_mut().query::<(Entity, &CrystalHudAction)>();
            query
                .iter(app.world())
                .find_map(|(entity, action)| {
                    matches!(action, CrystalHudAction::Option).then_some(entity)
                })
                .expect("native HUD option button should be present")
        };

        let hud_z = {
            let mut query = app
                .world_mut()
                .query_filtered::<&GlobalZIndex, With<super::super::hud::CrystalHudRoot>>();
            query.single(app.world()).expect("HUD root should exist").0
        };
        let world_blocker_z = {
            let mut query = app.world_mut().query::<(&Node, &GlobalZIndex)>();
            query
                .iter(app.world())
                .find_map(|(node, z)| {
                    (node.width == Val::Percent(100.0)
                        && node.height == Val::Percent(100.0)
                        && z.0 < 980)
                        .then_some(z.0)
                })
                .expect("quest world blocker should carry an explicit z-index")
        };
        assert!(
            world_blocker_z < hud_z,
            "quest world blocker must stay below every persistent HUD control"
        );

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::QuestLog;
        app.update();

        // Press the real HUD button entity as Bevy's pointer hit-test would.
        // The quest modal is open at this point, so this reproduces the
        // previously failing transition rather than opening Options in an
        // otherwise empty game state.
        app.world_mut()
            .entity_mut(option_button)
            .insert(Interaction::Pressed);
        app.update();

        let state = app.world().resource::<NativePlayerUiState>();
        assert_eq!(
            state.core.panel,
            mir2_ui_core::state::UiPanel::Options,
            "HUD Option must replace QuestLog, not merely close it"
        );
        assert!(
            state.blocks_world_click(),
            "Options must capture world clicks"
        );

        let options_visible = {
            let mut query = app.world_mut().query::<(&OverlayOptions, &Node)>();
            query
                .iter(app.world())
                .any(|(_, node)| node.display == Display::Flex)
        };
        assert!(
            options_visible,
            "OverlayOptions must be visible after the switch"
        );

        let quest_root_stays_in_game_layer = {
            let mut query = app.world_mut().query::<(&GlobalZIndex, &Node)>();
            query
                .iter(app.world())
                .any(|(z, node)| z.0 == 980 && node.display == Display::Flex)
        };
        assert!(
            quest_root_stays_in_game_layer,
            "QuestUiRoot remains the in-game layer"
        );
        let quest_log_hidden = {
            let mut query = app.world_mut().query::<&Node>();
            query.iter(app.world()).any(|node| {
                node.left == Val::Px(212.0)
                    && node.top == Val::Px(80.0)
                    && node.width == Val::Px(600.0)
                    && node.display == Display::None
            })
        };
        assert!(
            quest_log_hidden,
            "QuestLog panel must disappear after opening Options"
        );
        let quest_blocker_hidden = {
            let mut query = app.world_mut().query::<&Node>();
            query.iter(app.world()).any(|node| {
                node.width == Val::Percent(100.0)
                    && node.height == Val::Percent(100.0)
                    && node.display == Display::None
            })
        };
        assert!(
            quest_blocker_hidden,
            "Quest modal blocker must release the pointer"
        );

        // Release then press again to verify the same HUD control closes the
        // Options panel and does not leave a stale visible overlay behind.
        app.world_mut()
            .entity_mut(option_button)
            .insert(Interaction::None);
        app.update();
        app.world_mut()
            .entity_mut(option_button)
            .insert(Interaction::Pressed);
        app.update();

        let state = app.world().resource::<NativePlayerUiState>();
        assert_eq!(state.core.panel, mir2_ui_core::state::UiPanel::None);
        assert!(!state.blocks_world_click());
        let options_hidden = {
            let mut query = app.world_mut().query::<(&OverlayOptions, &Node)>();
            query
                .iter(app.world())
                .all(|(_, node)| node.display == Display::None)
        };
        assert!(
            options_hidden,
            "repeated Option click must hide the overlay"
        );
    }

    #[test]
    fn exit_application_effect_is_taken_once_without_swallowing_gateway_work() {
        let mut effects = UiEffectQueue::default();
        effects.push(mir2_ui_core::effect::UiEffect::GatewayCommand(
            mir2_ui_core::effect::GatewayCommand::Logout,
        ));
        effects.push(mir2_ui_core::effect::UiEffect::ExitApplication);

        assert!(effects.take_exit_application());
        assert!(!effects.take_exit_application());
        assert_eq!(
            effects.drain(),
            vec![mir2_ui_core::effect::UiEffect::GatewayCommand(
                mir2_ui_core::effect::GatewayCommand::Logout,
            )]
        );
    }

    fn item(key: &str, name: &str, container: u8, slot: u32) -> ItemModel {
        ItemModel {
            unique_id: key.parse().ok(),
            key: key.to_owned(),
            name: name.to_owned(),
            quantity: 1,
            slot,
            container,
            ..ItemModel::default()
        }
    }

    fn complete_repair_quote_metadata(item: &mut ItemModel) {
        let unique_id = item.unique_id.expect("test repair item ID");
        item.durability_current = Some(500);
        item.durability_max = Some(1000);
        item.tooltip_source = Some(CrystalItemTooltipSourceModel {
            info: CrystalItemInfoModel {
                item_index: 77,
                name: item.name.clone(),
                price: 1000,
                durability: 1000,
                ..Default::default()
            },
            user_item: Some(CrystalUserItemModel {
                unique_id,
                item_index: 77,
                current_dura: 500,
                max_dura: 1000,
                count: u16::try_from(item.quantity).expect("test repair item count"),
                ..Default::default()
            }),
            ..Default::default()
        });
    }

    pub(super) fn init_overlay_button_test_resources(app: &mut App) {
        let test_name = std::thread::current()
            .name()
            .unwrap_or("unnamed")
            .replace(|character: char| !character.is_ascii_alphanumeric(), "-");
        let skill_bindings_path = std::env::temp_dir().join(format!(
            "mir2-overlay-skill-bindings-{}-{test_name}.json",
            std::process::id()
        ));
        app.init_resource::<MailUiState>()
            .init_resource::<mail_parcel::MailParcelUi>()
            .init_resource::<StorageUiState>()
            .init_resource::<ShopUiState>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .init_resource::<BigMapModel>()
            .init_resource::<BigMapGatewayIntentQueue>()
            .init_resource::<BigMapUiState>()
            .init_resource::<SkillBindingUi>()
            .init_resource::<SkillModel>()
            .insert_resource(SkillBindingPersistenceRuntime::with_config_path(
                skill_bindings_path,
            ));
    }

    pub(super) fn overlay_render_test_app() -> App {
        let mut app = App::new();
        app.add_plugins((MinimalPlugins, bevy::asset::AssetPlugin::default()))
            .init_asset::<Image>()
            .init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<InventoryOperationFeedback>()
            .init_resource::<MailModel>()
            .init_resource::<MailUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<mail_compose_drag::MailLetterWindow>()
            .init_resource::<mail_editor::MailLetterEditor>()
            .init_resource::<mail_parcel::MailParcelUi>()
            .init_resource::<BigMapModel>()
            .init_resource::<BigMapUiState>()
            .init_resource::<UiReadModel>()
            .init_resource::<ShopModel>()
            .init_resource::<ShopUiState>()
            .init_resource::<GameShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<StorageUiState>()
            .init_resource::<SkillModel>()
            .init_resource::<SkillBindingUi>()
            .insert_resource(SkillBindingPersistenceRuntime::with_config_path(
                std::env::temp_dir().join(format!(
                    "mir2-render-test-skill-bindings-{}.json",
                    std::process::id()
                )),
            ))
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Startup, spawn_overlay_root)
            .add_systems(Update, (sync_mail_letter_editor, render_overlays).chain());
        app
    }

    fn game_shop_child_ids(app: &mut App) -> Vec<Entity> {
        let world = app.world_mut();
        let root = world
            .query_filtered::<Entity, With<OverlayGameShop>>()
            .single(world)
            .expect("game shop root");
        world
            .entity(root)
            .get::<Children>()
            .map(|children| children.iter().collect())
            .unwrap_or_default()
    }

    #[test]
    fn game_shop_editor_tree_is_retained_until_editor_or_preview_changes() {
        let mut app = overlay_render_test_app();
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::GameShop;
        app.update();
        let first = game_shop_child_ids(&mut app);
        assert!(!first.is_empty(), "the open shop must have rendered children");

        app.update();
        assert_eq!(game_shop_child_ids(&mut app), first);

        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.game_shop_dialog.search_focused = true;
            state.game_shop_dialog.search_input.modal =
                Some(friend_dialog::FriendModal::Add { blocked: false, text: "Potion".into() });
            state.game_shop_dialog.search_input.sync_editor();
        }
        app.update();
        let editor = game_shop_child_ids(&mut app);
        assert_ne!(editor, first, "opening the editor must rebuild the shop tree once");

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .game_shop_dialog
            .search_input
            .editor
            .as_mut()
            .expect("search editor")
            .select_all();
        app.update();
        let selected = game_shop_child_ids(&mut app);
        assert_ne!(selected, editor, "caret/selection changes must rebuild the editor tree");

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::None;
        app.update();
        assert!(game_shop_child_ids(&mut app).is_empty());

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::GameShop;
        app.update();
        assert_ne!(game_shop_child_ids(&mut app), selected, "reopen must invalidate the retained tree");

        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.game_shop_dialog.search_focused = false;
            state.game_shop_dialog.search_input.modal = None;
            state.game_shop_dialog.search_input.editor = None;
            state.game_shop_dialog.preview = Some(1);
            state.game_shop_dialog.frame_ms = 0;
        }
        app.update();
        let preview_frame_a = game_shop_child_ids(&mut app);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .game_shop_dialog
            .frame_ms = 150;
        app.update();
        assert_ne!(
            game_shop_child_ids(&mut app),
            preview_frame_a,
            "preview animation bucket changes must rebuild the preview"
        );
    }

    #[test]
    fn skill_shortcut_uses_one_real_character_dialog_with_all_four_tabs() {
        let mut app = overlay_render_test_app();
        app.world_mut().resource_mut::<UiReadModel>().player.name = Some("SkillTester".into());
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_skill();
        app.update();
        let world = app.world_mut();
        let state = world.resource::<NativePlayerUiState>();
        assert!(state.equipment_open());
        assert!(state.skill_open());
        assert!(!state.core.skill_open(), "no separate placeholder window");
        assert_eq!(state.character_page, CharacterPage::Spells);
        assert_eq!(
            world
                .query::<&OverlayButton>()
                .iter(world)
                .filter(|action| matches!(action, OverlayButton::SelectCharacterPage(_)))
                .count(),
            4
        );
        assert!(world
            .query::<&Text>()
            .iter(world)
            .any(|text| text.0 == "SkillTester"));
        assert_eq!(
            world
                .query::<&ImageNode>()
                .iter(world)
                .filter(|image| image
                    .image
                    .path()
                    .is_some_and(|path| path.to_string() == "original-ui/Title/504.png"))
                .count(),
            1
        );
        let mut state = world.resource_mut::<NativePlayerUiState>();
        state.character_page = CharacterPage::Stats1;
        state.toggle_skill();
        assert!(
            state.equipment_open(),
            "F11 from another tab keeps the dialog open"
        );
        assert_eq!(state.character_page, CharacterPage::Spells);
        state.toggle_skill();
        assert!(
            !state.equipment_open(),
            "F11 closes only the already-selected spells page"
        );
    }

    fn mail_msg(id: u64, claimed: bool, locked: bool, gold: u32, items: Vec<&str>) -> MailMessage {
        MailMessage {
            id,
            sender: "System".to_owned(),
            subject: format!("Test {}", id),
            body: "Hello world".to_owned(),
            gold,
            items: items
                .into_iter()
                .map(|s| crate::mail::MailAttachment {
                    name: Some(s.to_owned()),
                    ..Default::default()
                })
                .collect(),
            operation: None,
            claimed,
            locked,
            read: false,
            ..Default::default()
        }
    }

    fn shop_good(id: u64, name: &str, price: u32, stock: i32) -> ShopGood {
        ShopGood {
            unique_id: id,
            name: name.to_owned(),
            price,
            count: 1,
            stock,
            panel_type: 0,
            ..ShopGood::default()
        }
    }

    #[test]
    fn crystal_page_helpers_keep_all_authoritative_rows_reachable() {
        assert_eq!(native_skill_page_count(0), 1);
        assert_eq!(native_skill_page_count(7), 1);
        assert_eq!(native_skill_page_count(8), 2);
        assert_eq!(native_game_shop_page_count(105), 14);

        let mut model = GameShopModel::default();
        for index in 0..105 {
            model.items.push(crate::game_shop::GameShopEntry {
                game_shop_index: index,
                item_name: format!("Product {index}"),
                ..Default::default()
            });
        }
        let flattened = (0..native_game_shop_page_count(model.items.len()))
            .flat_map(|page| native_game_shop_page_entries(&model, page))
            .map(|entry| entry.game_shop_index)
            .collect::<Vec<_>>();
        assert_eq!(flattened, (0..105).collect::<Vec<_>>());
        assert!(native_game_shop_page_entries(&model, 0).len() <= 8);
        assert_eq!(native_game_shop_page_entries(&model, 13).len(), 1);
    }

    #[test]
    fn npc_shop_renders_the_visible_inventory_drag_source_with_single_core_panel() {
        let mut app = overlay_render_test_app();
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::NpcShop;
            state.inventory_window.left = 445.0;
            state.inventory_window.top = 0.0;
        }
        app.world_mut().resource_mut::<ShopModel>().service_mode = NpcShopServiceMode::Sell;
        app.world_mut().resource_mut::<InventoryModel>().items.push(ItemModel {
            unique_id: Some(7),
            container: 0,
            slot: 2,
            quantity: 1,
            ..Default::default()
        });
        app.update();

        let state = app.world().resource::<NativePlayerUiState>();
        assert!(state.npc_shop_open());
        assert!(
            !state.core.inventory_open(),
            "the shared core has only one active panel"
        );
        assert!(state.inventory_open(), "NPC service exposes its ordinary bag");
        let inventory = app
            .world_mut()
            .query_filtered::<&Node, With<OverlayInventory>>()
            .single(app.world())
            .expect("visible inventory alongside NPC shop");
        assert_eq!(inventory.display, Display::Flex);
        assert_eq!((inventory.left, inventory.top), (Val::Px(445.0), Val::Px(0.0)));
        assert_eq!(
            *app.world_mut()
                .query_filtered::<&FocusPolicy, With<OverlayShop>>()
                .single(app.world())
                .expect("shop mode container focus policy"),
            FocusPolicy::Pass
        );
        assert_eq!(
            app.world_mut()
                .query_filtered::<&OverlayButton, With<Button>>()
                .iter(app.world())
                .filter(|button| **button == OverlayButton::InspectBag(2))
                .count(),
            1,
            "the visible source bag cell owns the normal inventory action"
        );
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        assert!(app.world().resource::<NativePlayerUiState>().npc_shop_open());
        assert!(!app.world().resource::<NativePlayerUiState>().inventory_open());
        app.update();
        assert_eq!(
            app.world_mut()
                .query_filtered::<&Node, With<OverlayInventory>>()
                .single(app.world())
                .expect("hidden inventory panel")
                .display,
            Display::None
        );
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        assert!(app.world().resource::<NativePlayerUiState>().npc_shop_open());
        assert!(app.world().resource::<NativePlayerUiState>().inventory_open());
        app.update();
        assert_eq!(
            app.world_mut()
                .query_filtered::<&Node, With<OverlayInventory>>()
                .single(app.world())
                .expect("reopened inventory panel")
                .display,
            Display::Flex
        );
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::None;
        app.update();
        assert_eq!(
            app.world_mut()
                .query_filtered::<&Node, With<OverlayInventory>>()
                .single(app.world())
                .expect("inventory panel")
                .display,
            Display::None
        );
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.npc_inventory_hidden = true;
            state.toggle_npc_shop();
        }
        assert!(app.world().resource::<NativePlayerUiState>().inventory_open());
    }

    #[test]
    fn npc_dialog_explicit_exit_moves_the_bag_and_closes_only_its_service_children() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<ShopModel>()
            .insert_resource(NpcDialogModel::default())
            .add_systems(Update, sync_npc_dialog_inventory_location);
        app.world_mut().resource_mut::<NpcDialogModel>().is_open = true;
        app.update();
        assert_eq!(
            (
                app.world().resource::<NativePlayerUiState>().inventory_window.left,
                app.world().resource::<NativePlayerUiState>().inventory_window.top,
            ),
            (445.0, 0.0)
        );
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.inventory_window.left = 500.0;
            state.inventory_window.top = 90.0;
        }
        app.update();
        assert_eq!(
            (
                app.world().resource::<NativePlayerUiState>().inventory_window.left,
                app.world().resource::<NativePlayerUiState>().inventory_window.top,
            ),
            (500.0, 90.0),
            "an open parent dialogue must not overwrite a user bag drag"
        );
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::NpcShop;
            state.shop_service_drag_unique_id = Some(7);
            state.shop_repair_slot = Some(2);
            state.npc_service_hold = Some(NpcShopServiceMode::Repair);
            state.inventory_item_drag = Some(InventoryItemDrag {
                source_slot: 2,
                unique_id: 7,
                start: Vec2::new(465.0, 40.0),
            });
        }
        {
            let mut shop = app.world_mut().resource_mut::<ShopModel>();
            shop.service_mode = NpcShopServiceMode::Repair;
            shop.selected_bag_slot_for_repair = Some(2);
        }
        app.world_mut().resource_mut::<NpcDialogModel>().is_open = false;
        app.world_mut().resource_mut::<NativePlayerUiState>().npc_service_exit_requested = true;
        app.update();
        let state = app.world().resource::<NativePlayerUiState>();
        assert_eq!(state.core.panel, mir2_ui_core::state::UiPanel::Inventory);
        assert_eq!((state.inventory_window.left, state.inventory_window.top), (0.0, 0.0));
        assert_eq!(state.shop_service_drag_unique_id, None);
        assert_eq!(state.shop_repair_slot, None);
        assert_eq!(state.npc_service_hold, None);
        assert_eq!(state.inventory_item_drag, None);
        assert_eq!(
            app.world().resource::<ShopModel>().service_mode,
            NpcShopServiceMode::Closed
        );
    }

    #[test]
    fn native_panel_ecs_bounds_inventory_skill_and_cash_shop_at_1024x768() {
        let mut app = overlay_render_test_app();
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::Inventory;
        app.update();

        let inventory_node = app
            .world_mut()
            .query_filtered::<&Node, With<OverlayInventory>>()
            .single(app.world())
            .expect("inventory panel");
        assert_eq!(inventory_node.width, Val::Px(316.0));
        assert_eq!(inventory_node.height, Val::Px(236.0));
        assert_eq!(inventory_node.left, Val::Px(0.0));
        assert_eq!(inventory_node.top, Val::Px(0.0));
        let inventory_viewports = app
            .world_mut()
            .query_filtered::<&Node, With<OverlayInventoryGridViewport>>()
            .iter(app.world())
            .count();
        assert_eq!(inventory_viewports, 1);

        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.inventory_window.left = 120.0;
            state.inventory_window.top = 90.0;
        }
        app.update();
        let inventory_node = app
            .world_mut()
            .query_filtered::<&Node, With<OverlayInventory>>()
            .single(app.world())
            .expect("moved inventory panel");
        assert_eq!(inventory_node.left, Val::Px(120.0));
        assert_eq!(inventory_node.top, Val::Px(90.0));

        // Exercise the real F11/HUD entry, which now selects CharacterDialog's
        // spells tab instead of constructing the removed placeholder panel.
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_skill();
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .equipment_open());
        let skill_viewports = app
            .world_mut()
            .query_filtered::<&Node, With<OverlaySkillListViewport>>()
            .iter(app.world())
            .count();
        assert_eq!(skill_viewports, 1);

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::GameShop;
        for index in 0..105 {
            app.world_mut().resource_mut::<GameShopModel>().items.push(
                crate::game_shop::GameShopEntry {
                    game_shop_index: index,
                    item_name: format!("Product {index}"),
                    ..Default::default()
                },
            );
        }
        app.update();
        let shop_node = app
            .world_mut()
            .query_filtered::<&Node, With<OverlayGameShop>>()
            .single(app.world())
            .expect("cash shop panel");
        assert_eq!(shop_node.width, Val::Px(696.0));
        assert_eq!(shop_node.height, Val::Px(476.0));
        let product_count = app
            .world_mut()
            .query_filtered::<Entity, With<OverlayGameShopProduct>>()
            .iter(app.world())
            .count();
        assert_eq!(product_count, 8);
    }

    #[test]
    fn crystal_social_panels_use_original_geometry_and_bounded_rows() {
        assert_eq!(
            CRYSTAL_GROUP_PANEL_RECT,
            CrystalRect::new(396.0, 259.0, 232.0, 249.0)
        );
        assert_eq!(
            CRYSTAL_GUILD_PANEL_RECT,
            CrystalRect::new(217.0, 168.0, 590.0, 432.0)
        );
        assert_eq!(group_member_position(0), (16.0, 33.0));
        assert_eq!(group_member_position(1), (16.0, 55.0));
        assert_eq!(group_member_position(2), (116.0, 55.0));
        assert_eq!(group_member_position(14), (116.0, 175.0));

        let mut app = overlay_render_test_app();
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Group;
        }
        app.world_mut()
            .resource_mut::<crate::social::SocialModel>()
            .group
            .members = (0..crate::social::MAX_GROUP_MEMBERS)
            .map(|index| crate::social::GroupMemberModel {
                name: format!("Member{index}"),
                online: true,
                leader: index == 0,
                ..Default::default()
            })
            .collect();
        app.update();

        let social_node = app
            .world_mut()
            .query_filtered::<&Node, With<OverlaySocial>>()
            .single(app.world())
            .expect("social root");
        assert_eq!(social_node.width, Val::Px(1024.0));
        assert_eq!(social_node.height, Val::Px(768.0));
        let group_rows = app
            .world_mut()
            .query::<&OverlayButton>()
            .iter(app.world())
            .filter(|action| matches!(action, OverlayButton::SelectGroupMember(_)))
            .count();
        assert_eq!(group_rows, crate::social::MAX_GROUP_MEMBERS);

        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Guild;
            state.guild_left_page = GuildLeftPage::Members;
        }
        app.world_mut()
            .resource_mut::<crate::social::SocialModel>()
            .guild
            .members = (0..25)
            .map(|index| crate::social::GuildMemberModel {
                name: format!("GuildMember{index}"),
                online: true,
                ..Default::default()
            })
            .collect();
        app.update();
        let guild_rows = app
            .world_mut()
            .query::<&Text>()
            .iter(app.world())
            .filter(|text| text.0.starts_with("GuildMember"))
            .count();
        assert_eq!(guild_rows, 18);
    }

    #[test]
    fn guild_tabs_request_the_matching_authoritative_page() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);

        let button = app
            .world_mut()
            .spawn((
                Button,
                Interaction::Pressed,
                OverlayButton::SelectGuildLeftPage(GuildLeftPage::Members),
            ))
            .id();
        app.update();
        app.world_mut().despawn(button);

        assert_eq!(
            app.world()
                .resource::<NativePlayerUiState>()
                .guild_left_page,
            GuildLeftPage::Members
        );
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .iter()
            .any(|intent| matches!(
                intent,
                NativePlayerUiIntent::GuildRequestInfo { info_type: 1 }
            )));
    }

    #[test]
    fn guild_notice_preserves_source_lines_and_leaves_200_line_rejection_to_server() {
        let draft = format!("{}\n\nfinal  ", "x".repeat(100));
        assert_eq!(
            guild_notice_lines(&draft),
            vec!["x".repeat(100), String::new(), "final  ".into()]
        );
        assert_eq!(guild_notice_lines(&vec!["a"; 200].join("\n")).len(), 200);
        assert_eq!(guild_notice_lines(&vec!["a"; 201].join("\n")).len(), 201);
    }

    #[test]
    fn guild_notice_editor_consumes_real_keyboard_messages_before_chat() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<StorageModel>()
            .init_resource::<ButtonInput<KeyCode>>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .add_message::<KeyboardInput>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, process_overlay_keyboard);
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Guild;
            state.guild_left_page = GuildLeftPage::Notice;
            state.guild_notice_editing = true;
        }
        app.world_mut().write_message(KeyboardInput {
            key_code: KeyCode::KeyN,
            logical_key: Key::Character("New notice".into()),
            state: ButtonState::Pressed,
            text: Some("New notice".into()),
            repeat: false,
            window: Entity::PLACEHOLDER,
        });
        app.update();
        let state = app.world().resource::<NativePlayerUiState>();
        assert_eq!(state.guild_notice_draft, "New notice");
        assert!(!state.chat_focused());
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
    }

    #[test]
    fn guild_notice_edit_publish_failure_retry_and_receipt_stay_authoritative() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Guild;
            state.guild_left_page = GuildLeftPage::Notice;
        }
        {
            let mut social = app.world_mut().resource_mut::<crate::social::SocialModel>();
            social.guild.name = Some("TestGuild".into());
            social.guild.permissions = vec!["notice".into()];
            social.guild.notice = vec!["Old".into()];
        }
        fn press(app: &mut App, button: OverlayButton) {
            let entity = app
                .world_mut()
                .spawn((Interaction::Pressed, button, Button))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        }

        press(&mut app, OverlayButton::GuildBeginNoticeEdit);
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            assert!(state.guild_notice_editing);
            assert_eq!(state.guild_notice_draft, "Old");
            state.guild_notice_draft = "New line\nSecond".into();
        }
        press(&mut app, OverlayButton::GuildPublishNotice);
        assert_eq!(
            app.world()
                .resource::<crate::social::SocialModel>()
                .guild
                .notice,
            vec!["Old"],
            "submitting a draft must not mutate the authoritative notice"
        );
        assert!(matches!(
            app.world()
                .resource::<crate::social::SocialModel>()
                .pending
                .as_slice(),
            [crate::social::SocialPendingOperation::GuildNotice { notice }]
                if notice == &vec!["New line".to_owned(), "Second".to_owned()]
        ));
        let first = app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        assert!(matches!(
            first.as_slice(),
            [NativePlayerUiIntent::GuildEditNotice { notice }]
                if notice == &vec!["New line".to_owned(), "Second".to_owned()]
        ));

        {
            let current = app.world().resource::<crate::social::SocialModel>().clone();
            let mut incoming = current.clone();
            incoming.pending.clear();
            assert!(
                incoming.apply_packet("GuildNoticeResult", &serde_json::json!({"success":false}))
            );
            app.world_mut()
                .resource_mut::<crate::social::SocialModel>()
                .apply_authoritative(incoming);
        }
        app.update();
        {
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(state.guild_notice_editing);
            assert!(state.guild_notice_submission.is_none());
            assert_eq!(state.guild_notice_draft, "New line\nSecond");
        }

        press(&mut app, OverlayButton::GuildPublishNotice);
        let retry = app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        assert!(matches!(
            retry.as_slice(),
            [NativePlayerUiIntent::GuildEditNotice { .. }]
        ));
        {
            let current = app.world().resource::<crate::social::SocialModel>().clone();
            let mut incoming = current.clone();
            incoming.pending.clear();
            assert!(incoming.apply_packet(
                "GuildNoticeChange",
                &serde_json::json!({"update":-1,"notice":[]})
            ));
            app.world_mut()
                .resource_mut::<crate::social::SocialModel>()
                .apply_authoritative(incoming);
        }
        app.update();
        let state = app.world().resource::<NativePlayerUiState>();
        assert!(!state.guild_notice_editing);
        assert!(state.guild_notice_submission.is_none());
        assert_eq!(
            app.world()
                .resource::<crate::social::SocialModel>()
                .guild
                .notice,
            vec!["Old"]
        );
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .iter()
            .any(|intent| matches!(
                intent,
                NativePlayerUiIntent::GuildRequestInfo { info_type: 0 }
            )));
    }

    #[test]
    fn inspect_and_equip_mapping_cover_quest_rewards() {
        let pendant = item("77", "GoldenPendant", 0, 3);
        assert_eq!(item_unique_id(&pendant), Some(77));
        assert_eq!(equip_destination_for_name(&pendant.name), 4);
        assert_eq!(equip_destination_for_name("CopperRing"), 7);
        assert!(inspect_label(&pendant).contains("GoldenPendant"));
    }

    #[test]
    fn inspected_equip_prefers_authoritative_slot_over_display_name() {
        fn equip_target(mut item: ItemModel, equip_slot: Option<&str>) -> i32 {
            item.equip_slot = equip_slot.map(str::to_owned);
            let state = NativePlayerUiState {
                inspect: Some(inspect_from_item(&item)),
                ..default()
            };
            let inventory = InventoryModel {
                items: vec![item],
                ..default()
            };
            match inspected_equip_intent(&state, &inventory) {
                Some(NativePlayerUiIntent::EquipItem { to, .. }) => to,
                other => panic!("expected equip intent, got {other:?}"),
            }
        }

        assert_eq!(
            equip_target(item("317", "BaseDress(M)", 0, 3), Some("armour")),
            1
        );
        assert_eq!(
            equip_target(item("245", "DragonSword", 0, 4), Some("weapon")),
            0
        );
        assert_eq!(
            equip_target(item("900", "RidingToken", 0, 5), Some("mount")),
            13
        );
        assert_eq!(
            equip_target(item("901", "HandLamp", 0, 6), Some("torch")),
            3
        );
        assert_eq!(
            equip_target(item("902", "FallbackArmour", 0, 7), Some("unknown")),
            1,
            "unknown metadata keeps the legacy name fallback"
        );
        assert_eq!(
            equip_target(item("903", "FallbackRing", 0, 8), None),
            7,
            "missing metadata keeps the legacy name fallback"
        );
    }

    #[test]
    fn chat_focus_blocks_gameplay_keys_not_bag() {
        let mut state = NativePlayerUiState::default();
        state.core.panel = mir2_ui_core::state::UiPanel::Inventory;
        assert!(!state.blocks_gameplay_keys());
        assert!(state.blocks_world_click());
        state.core.chat_focused = true;
        assert!(state.blocks_gameplay_keys());
    }

    #[test]
    fn belt_use_intent_targets_belt_grid() {
        match belt_use_intent(3) {
            NativePlayerUiIntent::UseItem {
                slot,
                grid,
                unique_id,
                key,
            } => {
                assert_eq!(slot, Some(3));
                assert_eq!(grid.as_deref(), Some("belt"));
                assert_eq!(unique_id, None);
                assert_eq!(key, None);
            }
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn belt_mouse_intent_requires_the_current_unique_instance() {
        let mut inventory = InventoryModel::default();
        assert!(belt_item_use_intent(&inventory, 0).is_none());
        inventory.items.push(ItemModel {
            unique_id: None,
            key: "legacy".to_owned(),
            name: "Legacy".to_owned(),
            quantity: 1,
            slot: 0,
            container: 1,
            ..ItemModel::default()
        });
        assert!(belt_item_use_intent(&inventory, 0).is_none());
        inventory.items[0].unique_id = Some(99);
        assert!(matches!(
            belt_item_use_intent(&inventory, 0),
            Some(NativePlayerUiIntent::UseItem {
                unique_id: Some(99),
                slot: Some(0),
                ref grid,
                ..
            }) if grid.as_deref() == Some("belt")
        ));
        // Replacing the authoritative belt model invalidates the old item
        // identity; a previously pressed HUD node must fail closed.
        inventory.items.clear();
        assert!(belt_item_use_intent(&inventory, 0).is_none());
    }

    #[test]
    fn armed_bag_move_uses_crystal_raw_source_when_empty_belt_slot_is_clicked() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, consume_hud_buttons);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .inventory_operation = Some(InventoryOperationDraft::Move {
            source_slot: 2,
            unique_id: 7001,
        });
        let belt = app
            .world_mut()
            .spawn((Interaction::None, CrystalHudAction::BeltUse(0)))
            .id();
        app.update();
        app.world_mut()
            .entity_mut(belt)
            .insert(Interaction::Pressed);
        app.update();

        assert_eq!(
            app.world_mut()
                .resource_mut::<NativePlayerUiIntentQueue>()
                .drain_intents(),
            vec![NativePlayerUiIntent::MoveItem {
                grid: "belt".to_owned(),
                unique_id: 7001,
                from: 8,
                to: 0,
            }]
        );
        let state = app.world().resource::<NativePlayerUiState>();
        assert!(state.inventory_operation.is_none());
        assert!(state.inspect.is_none());
    }

    fn read_player_ui(_state: Res<NativePlayerUiState>) {}

    #[test]
    fn overlay_mutate_set_runs_before_res_readers() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MapModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<ButtonInput<KeyCode>>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .add_message::<KeyboardInput>()
            .configure_sets(
                Update,
                NativePlayerUiSet::Mutate.before(NativePlayerUiSet::Read),
            )
            .add_systems(
                Update,
                process_overlay_keyboard.in_set(NativePlayerUiSet::Mutate),
            )
            .add_systems(Update, read_player_ui.in_set(NativePlayerUiSet::Read));
        let mut shell = NativeShellModel::default();
        shell.screen = NativeShellScreen::InGame;
        app.insert_resource(shell);
        app.update();
        app.update();
    }

    #[test]
    fn non_ingame_keyboard_defers_session_clear_to_revision_pipeline() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MapModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<ButtonInput<KeyCode>>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .add_message::<KeyboardInput>()
            .add_systems(Update, process_overlay_keyboard);
        let mut shell = NativeShellModel::default();
        shell.screen = NativeShellScreen::ConnectionLost;
        app.insert_resource(shell);
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::Inventory;
            state.core.panel = mir2_ui_core::state::UiPanel::Character;
            state.core.panel = mir2_ui_core::state::UiPanel::Menu;
            state.core.panel = mir2_ui_core::state::UiPanel::Skill;
            state.core.panel = mir2_ui_core::state::UiPanel::Mail;
            state.core.panel = mir2_ui_core::state::UiPanel::BigMap;
            state.core.panel = mir2_ui_core::state::UiPanel::NpcShop;
            state.core.panel = mir2_ui_core::state::UiPanel::Storage;
            state.core.chat_focused = true;
            state.chat_draft = "hello".to_owned();
            state.core.minimap_visible = false;
            state.bigmap_zoom = 2.0;
        }
        {
            let mut mail = app.world_mut().resource_mut::<MailModel>();
            mail.mails.push(mail_msg(1, false, false, 100, vec![]));
            mail.selected_id = Some(1);
        }
        {
            let mut shop = app.world_mut().resource_mut::<ShopModel>();
            shop.goods.push(shop_good(1, "Potion", 100, 10));
            shop.selected_id = Some(1);
        }
        {
            let mut storage = app.world_mut().resource_mut::<StorageModel>();
            storage.items.push(item("10", "Sword", 4, 0));
            storage.password_draft = "secret".to_owned();
            storage.has_password = true;
            storage.unlocked = false;
        }
        app.update();
        let state = app.world().resource::<NativePlayerUiState>();
        assert_eq!(state.core.panel, mir2_ui_core::state::UiPanel::Storage);
        assert!(state.core.chat_focused);
        assert_eq!(state.chat_draft, "hello");
        assert!(!state.core.minimap_visible);
        assert_eq!(state.bigmap_zoom, 2.0);
        let mail = app.world().resource::<MailModel>();
        assert_eq!(mail.mails.len(), 1);
        assert_eq!(mail.selected_id, Some(1));
        let shop = app.world().resource::<ShopModel>();
        assert_eq!(shop.goods.len(), 1);
        assert_eq!(shop.selected_id, Some(1));
        let storage = app.world().resource::<StorageModel>();
        assert_eq!(storage.items.len(), 1);
        assert_eq!(storage.password_draft, "secret");
    }

    #[test]
    fn overlay_keyboard_toggles_inventory_with_i() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MapModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<ButtonInput<KeyCode>>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .add_message::<KeyboardInput>()
            .add_systems(Update, process_overlay_keyboard);
        let mut shell = NativeShellModel::default();
        shell.screen = NativeShellScreen::InGame;
        app.insert_resource(shell);
        {
            let mut keys = app.world_mut().resource_mut::<ButtonInput<KeyCode>>();
            keys.press(KeyCode::KeyI);
        }
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_open());
    }

    #[test]
    fn revive_v_does_not_toggle_minimap_but_alive_v_does() {
        for (hp, expected_visible) in [(0, true), (30, false)] {
            let mut app = App::new();
            app.init_resource::<NativePlayerUiState>()
                .init_resource::<MailComposeUi>()
                .init_resource::<NativePlayerUiIntentQueue>()
                .init_resource::<PendingOperations>()
                .init_resource::<NativeUiIntentQueue>()
                .init_resource::<InventoryModel>()
                .init_resource::<MailModel>()
                .init_resource::<MapModel>()
                .init_resource::<ShopModel>()
                .init_resource::<StorageModel>()
                .init_resource::<ButtonInput<KeyCode>>()
                .init_resource::<crate::audio::NativeUiAudioQueue>()
                .add_message::<KeyboardInput>()
                .add_systems(Update, process_overlay_keyboard);
            app.insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
            let mut ui = UiReadModel::default();
            ui.player.hp = hp;
            ui.player.max_hp = 30;
            app.insert_resource(ui);
            app.world_mut()
                .resource_mut::<ButtonInput<KeyCode>>()
                .press(KeyCode::KeyV);
            app.update();
            assert_eq!(
                app.world().resource::<NativePlayerUiState>().minimap_visible(),
                expected_visible,
                "hp={hp}"
            );
        }
    }

    #[test]
    fn overlay_keyboard_toggles_skills_with_f11() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MapModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<ButtonInput<KeyCode>>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .add_message::<KeyboardInput>()
            .add_systems(Update, process_overlay_keyboard);
        app.insert_resource(NativeShellModel {
            screen: NativeShellScreen::InGame,
            ..Default::default()
        });

        app.world_mut()
            .resource_mut::<ButtonInput<KeyCode>>()
            .press(KeyCode::F11);
        app.update();
        assert!(app.world().resource::<NativePlayerUiState>().skill_open());

        {
            let mut keys = app.world_mut().resource_mut::<ButtonInput<KeyCode>>();
            keys.release(KeyCode::F11);
            keys.clear();
            keys.press(KeyCode::F11);
        }
        app.update();
        assert!(!app.world().resource::<NativePlayerUiState>().skill_open());
    }

    #[test]
    fn character_c_and_f10_share_source_page_semantics_without_click_audio() {
        for key in [KeyCode::KeyC, KeyCode::F10] {
            let mut app = App::new();
            app.init_resource::<NativePlayerUiState>()
                .init_resource::<MailComposeUi>()
                .init_resource::<NativePlayerUiIntentQueue>()
                .init_resource::<PendingOperations>()
                .init_resource::<NativeUiIntentQueue>()
                .init_resource::<InventoryModel>()
                .init_resource::<MailModel>()
                .init_resource::<MapModel>()
                .init_resource::<ShopModel>()
                .init_resource::<StorageModel>()
                .init_resource::<ButtonInput<KeyCode>>()
                .init_resource::<crate::audio::NativeUiAudioQueue>()
                .add_message::<KeyboardInput>()
                .add_systems(Update, process_overlay_keyboard);
            app.insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
            {
                let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
                state.character_page = CharacterPage::Stats2;
                state.toggle_equipment();
            }

            app.world_mut()
                .resource_mut::<ButtonInput<KeyCode>>()
                .press(key);
            app.update();
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(state.equipment_open());
            assert_eq!(state.character_page, CharacterPage::Character);

            {
                let mut keys = app.world_mut().resource_mut::<ButtonInput<KeyCode>>();
                keys.release(key);
                keys.clear();
                keys.press(key);
            }
            app.update();
            assert!(!app
                .world()
                .resource::<NativePlayerUiState>()
                .equipment_open());

            {
                let mut keys = app.world_mut().resource_mut::<ButtonInput<KeyCode>>();
                keys.release(key);
                keys.clear();
                keys.press(key);
            }
            app.update();
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(state.equipment_open());
            assert_eq!(state.character_page, CharacterPage::Character);
            assert_eq!(
                app.world()
                    .resource::<crate::audio::NativeUiAudioQueue>()
                    .len(),
                0
            );
            assert!(app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .is_empty());
        }
    }

    #[test]
    fn mail_open_blocks_world_click_and_uses_reducer() {
        let mut state = NativePlayerUiState::default();
        assert!(!state.blocks_world_click());
        state.core.panel = mir2_ui_core::state::UiPanel::Mail;
        assert!(state.blocks_world_click());
        if state.mail_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.panel = mir2_ui_core::state::UiPanel::BigMap;
        assert!(state.blocks_world_click());
        // Minimap visible should not block
        if state.bigmap_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.minimap_visible = false;
        assert!(!state.blocks_world_click());
        state.core.minimap_visible = true;
        assert!(!state.blocks_world_click());
        // Verify mail toggle via reducer mirrors inventory logic without opening inventory
        let core_state = mir2_ui_core::state::UiState {
            screen: mir2_ui_core::state::UiScreen::InGame,
            panel: mir2_ui_core::state::UiPanel::None,
            ..Default::default()
        };
        let t =
            mir2_ui_core::reducer::reduce(&core_state, mir2_ui_core::action::UiAction::OpenMail);
        assert_eq!(t.state.panel, mir2_ui_core::state::UiPanel::Mail);
        assert_ne!(t.state.panel, mir2_ui_core::state::UiPanel::Inventory);
        let t2 =
            mir2_ui_core::reducer::reduce(&core_state, mir2_ui_core::action::UiAction::OpenBigMap);
        assert_eq!(t2.state.panel, mir2_ui_core::state::UiPanel::BigMap);
        let core_minimap = mir2_ui_core::state::UiState {
            screen: mir2_ui_core::state::UiScreen::InGame,
            minimap_visible: true,
            ..Default::default()
        };
        let t3 = mir2_ui_core::reducer::reduce(
            &core_minimap,
            mir2_ui_core::action::UiAction::ToggleMinimap,
        );
        assert!(!t3.state.minimap_visible);
    }

    #[test]
    fn mail_panel_cache_keeps_children_until_mail_inputs_change() {
        #[derive(Resource)]
        struct MailOpen(bool);

        fn render_test_mail(
            mut commands: Commands,
            mut panels: Query<(Entity, &mut Node), With<OverlayMail>>,
            mut cache: Local<MailRenderCache>,
            open: Res<MailOpen>,
            mail: Res<MailModel>,
            mail_ui: Res<MailUiState>,
            compose_ui: Res<MailComposeUi>,
            state: Res<NativePlayerUiState>,
            inventory: Res<InventoryModel>,
        ) {
            fill_mail_panel(
                &mut commands,
                &mut panels,
                open.0,
                &mail,
                &mail_ui,
                &compose_ui,
                state.core.mail_compose.as_ref(),
                &inventory,
                &mut cache,
                |parent| {
                    parent.spawn(Node::default());
                },
            );
        }

        fn child_ids(world: &mut World) -> Vec<Entity> {
            let mut query = world.query_filtered::<&Children, With<OverlayMail>>();
            query
                .single(world)
                .map(|children| children.iter().collect())
                .unwrap_or_default()
        }

        let mut app = App::new();
        app.insert_resource(MailOpen(true))
            .init_resource::<MailModel>()
            .init_resource::<MailUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .add_systems(Update, render_test_mail);
        app.world_mut().spawn((OverlayMail, Node::default()));

        app.update();
        let first = child_ids(app.world_mut());
        assert_eq!(first.len(), 1);
        app.update();
        assert_eq!(child_ids(app.world_mut()), first);

        app.world_mut().resource_mut::<MailModel>().selected_id = Some(9);
        app.update();
        let refreshed = child_ids(app.world_mut());
        assert_eq!(refreshed.len(), 1);
        assert_ne!(refreshed, first);

        app.world_mut().resource_mut::<MailOpen>().0 = false;
        app.update();
        assert!(child_ids(app.world_mut()).is_empty());
        app.world_mut().resource_mut::<MailOpen>().0 = true;
        app.update();
        let reopened = child_ids(app.world_mut());
        assert_eq!(reopened.len(), 1);
        assert_ne!(reopened, refreshed);
    }

    #[test]
    fn mail_claim_and_delete_disabled_states() {
        let unclaimed = mail_msg(1, false, false, 100, vec!["Gold"]);
        let claimed = mail_msg(2, true, false, 100, vec!["Gold"]);
        let locked = mail_msg(3, false, true, 100, vec!["Gold"]);
        let no_attach = mail_msg(4, false, false, 0, vec![]);
        assert!(mail_claim_enabled(&unclaimed));
        assert!(!mail_claim_enabled(&claimed));
        assert!(!mail_claim_enabled(&locked));
        assert!(!mail_claim_enabled(&no_attach));
        assert!(mail_delete_enabled(&unclaimed));
        assert!(mail_delete_enabled(&claimed));
        assert!(!mail_delete_enabled(&locked));
        // Selection and unread count
        let mut model = MailModel {
            mails: vec![unclaimed.clone(), claimed.clone(), locked.clone()],
            selected_id: Some(1),
        };
        assert_eq!(model.unread_count(), 3);
        assert_eq!(model.selected().unwrap().id, 1);
        model.mails[0].read = true;
        assert_eq!(model.unread_count(), 2);
    }

    #[test]
    fn bigmap_zoom_is_clamped_and_retained() {
        assert_eq!(bigmap_zoom_clamped(0.1), BIGMAP_ZOOM_MIN);
        assert_eq!(bigmap_zoom_clamped(10.0), BIGMAP_ZOOM_MAX);
        assert_eq!(bigmap_zoom_in(1.0), 1.25);
        assert_eq!(bigmap_zoom_out(1.0), 0.75);
        assert_eq!(bigmap_zoom_in(BIGMAP_ZOOM_MAX), BIGMAP_ZOOM_MAX);
        assert_eq!(bigmap_zoom_out(BIGMAP_ZOOM_MIN), BIGMAP_ZOOM_MIN);
        // Close windows retains minimap and zoom
        let mut state = NativePlayerUiState {
            core: mir2_ui_core::state::UiState {
                panel: mir2_ui_core::state::UiPanel::Mail,
                minimap_visible: false,
                screen: mir2_ui_core::state::UiScreen::InGame,
                chat_focused: false,
                ..Default::default()
            },
            bigmap_zoom: 2.0,
            ..Default::default()
        };
        state.close_windows();
        assert!(!state.mail_open());
        assert!(!state.bigmap_open());
        assert!(!state.shop_open());
        assert!(!state.storage_open());
        assert!(!state.minimap_visible());
        assert_eq!(state.bigmap_zoom, 2.0);
    }

    fn spawn_big_map_render_test(
        mut commands: Commands,
        asset_server: Res<AssetServer>,
        model: Res<BigMapModel>,
        renderer: Res<BigMapUiState>,
        ui: Res<UiReadModel>,
    ) {
        commands.spawn(Node::default()).with_children(|parent| {
            render_bigmap(parent, Some(&asset_server), &model, &renderer, &ui);
        });
    }

    #[test]
    fn big_map_images_and_player_markers_use_centered_source_viewport() {
        for index in [8, 14, 101, i32::MAX] {
            let mut app = App::new();
            app.add_plugins(MinimalPlugins).add_plugins(AssetPlugin::default())
                .init_asset::<Image>().init_resource::<UiReadModel>()
                .init_resource::<BigMapUiState>()
                .add_systems(Startup, spawn_big_map_render_test);
            let mut model = BigMapModel::default();
            model.set_current_map(1);
            model.apply_new_map_info(1, crate::big_map::BigMapInfo {
                title: "Geometry".into(), width: 700, height: 700, big_map: index,
                movements: vec![], npcs: vec![],
            });
            model.set_player_location(Some(1), BigMapPoint { x: 350, y: 350 });
            app.insert_resource(model);
            app.update();
            let world = app.world_mut();
            let images = world.query::<(&BigMapImageEntity, &Node, &ChildOf)>()
                .iter(world).map(|(_,node,parent)| (node.clone(), parent.parent())).collect::<Vec<_>>();
            let players = world.query::<(&BigMapPlayerEntity, &Node)>()
                .iter(world).map(|(_,node)| (node.left,node.top)).collect::<Vec<_>>();
            let Some(g) = crate::big_map::BigMapImageGeometry::for_image(index as u32) else {
                assert!(images.is_empty());
                assert!(players.is_empty());
                continue;
            };
            assert_eq!(images.len(),1);
            assert_eq!((images[0].0.width,images[0].0.height),(Val::Px(g.width),Val::Px(g.height)));
            let viewport = world.get::<Node>(images[0].1).unwrap();
            assert_eq!((viewport.left,viewport.top),(Val::Px(g.left),Val::Px(g.top)));
            assert_eq!(players,vec![(Val::Px(g.width/2.-6.),Val::Px(g.height/2.-5.))]);
        }
    }

    #[test]
    fn bichon_destination_ecs_only_renders_unfinished_arrival_on_bichon() {
        use crate::quest_model::{Quest, QuestTracker};
        for (map_index, current, status, visible) in [
            (1, 0, "inProgress", true),
            (1, 1, "inProgress", false),
            (1, 0, "completed", false),
            (0, 0, "inProgress", false),
        ] {
            let quest: Quest = serde_json::from_value(serde_json::json!({
                "questIndex": 2110005, "title": "Safe arrival", "status": status,
                "objectives": [{"objectiveId":"flag:2210051", "text":"Arrival", "current":current,"target":1}],
                "rewards": []
            })).unwrap();
            let mut app = App::new();
            app.add_plugins(MinimalPlugins)
                .add_plugins(AssetPlugin::default()).init_asset::<Image>()
                .init_resource::<UiReadModel>().init_resource::<NativePlayerUiState>()
                .init_resource::<BigMapGatewayIntentQueue>().init_resource::<BigMapUiState>()
                .insert_resource(QuestTracker { active_quests: vec![quest] })
                .add_systems(Update, (sync_big_map_ui, spawn_big_map_render_test).chain());
            let mut model = BigMapModel::default();
            model.set_current_map(map_index);
            model.apply_new_map_info(map_index, crate::big_map::BigMapInfo {
                title: "BichonProvince".into(), width: 700, height: 700, big_map: 101,
                movements: vec![], npcs: vec![],
            });
            app.insert_resource(model);
            app.update();
            assert_eq!(app.world().resource::<BigMapUiState>().bichon_safe_destination, visible);
            let count = app.world_mut().query_filtered::<&Node, With<BichonSafeDestinationArea>>()
                .iter(app.world()).count();
            assert_eq!(count, usize::from(visible));
            let label = app.world_mut().query::<(&Text, &TextFont)>().iter(app.world())
                .find(|(text, _)| text.0 == "比奇城安全区 (328,264)");
            assert_eq!(label.is_some(), visible);
            if let Some((_, font)) = label {
                assert_eq!(font.font, FontSource::Family("Microsoft YaHei".into()));
            }
        }
    }

    #[test]
    fn big_map_hunt_regions_render_remaining_target() {
        let mut app = App::new();
        app.add_plugins(MinimalPlugins)
            .add_plugins(AssetPlugin::default())
            .init_asset::<Image>()
            .init_resource::<UiReadModel>()
            .add_systems(Startup, spawn_big_map_render_test);
        let mut model = BigMapModel::default();
        model.set_current_map(1);
        model.apply_new_map_info(1, crate::big_map::BigMapInfo {
            title: "BichonProvince".into(), width: 800, height: 800, big_map: 101,
            movements: vec![], npcs: vec![],
        });
        app.insert_resource(model);
        app.insert_resource(BigMapUiState {
            hunt_regions: vec![crate::quest_hunt_regions::QuestHuntRegion {
                primary: false,
                monster_index: 44, name: "RakingCat".into(),
                center: BigMapPoint { x: 340, y: 550 }, radius: 50, remaining: 2,
            }],
            ..Default::default()
        });
        app.update();
        assert!(app.world_mut().query::<&Text>().iter(app.world())
            .any(|text| text.0 == "RakingCat: 2 left (340,550)"));
    }

    #[test]
    fn big_map_ecs_spawns_authoritative_image_player_and_npc_rows() {
        let mut app = App::new();
        app.add_plugins(MinimalPlugins)
            .add_plugins(AssetPlugin::default())
            .init_asset::<Image>()
            .init_resource::<BigMapUiState>()
            .init_resource::<UiReadModel>()
            .add_systems(Startup, spawn_big_map_render_test);

        let mut model = BigMapModel::default();
        model.set_current_map(1);
        model.set_player_location(Some(1), BigMapPoint { x: 257, y: 594 });
        model.apply_world_map_setup(false, Vec::new(), 3_000);
        model.apply_new_map_info(
            1,
            crate::big_map::BigMapInfo {
                title: "BichonProvince".to_owned(),
                width: 700,
                height: 700,
                big_map: 101,
                movements: Vec::new(),
                npcs: vec![crate::big_map::BigMapNpc {
                    index: 1,
                    file_name: "NPC/00".to_owned(),
                    name: "Village Guide".to_owned(),
                    map_index: 1,
                    location: BigMapPoint { x: 330, y: 270 },
                    image: 0,
                    rate: 0,
                    show_on_big_map: true,
                    big_map_icon: 0,
                    object_id: 77,
                    icon: 0,
                    can_teleport_to: false,
                }],
            },
        );
        app.insert_resource(model);
        app.update();

        let world = app.world_mut();
        let images = world
            .query::<(&BigMapImageEntity, &ImageNode)>()
            .iter(world)
            .map(|(marker, image)| (marker.url.clone(), image.image.id()))
            .collect::<Vec<_>>();
        assert_eq!(images.len(), 1);
        assert_eq!(images[0].0, "original-ui/MMap/101.png");
        let asset_server = world.resource::<AssetServer>();
        assert_eq!(
            asset_server
                .get_path(images[0].1)
                .map(|path| path.path().to_string_lossy().replace('\\', "/")),
            Some("original-ui/MMap/101.png".to_owned())
        );

        let players = world
            .query::<(&BigMapPlayerEntity, &Node, &ImageNode)>()
            .iter(world)
            .map(|(marker, node, _)| (marker.location, node.left, node.top))
            .collect::<Vec<_>>();
        assert_eq!(players.len(), 1);
        assert_eq!(players[0].0, BigMapPoint { x: 257, y: 594 });
        let (player_x, player_y) = crate::big_map::BigMapImageGeometry::for_image(101).unwrap().view_position(BigMapPoint { x: 257, y: 594 }, 700, 700);
        assert_eq!(players[0].1, Val::Px(player_x - 6.0));
        assert_eq!(players[0].2, Val::Px(player_y - 5.0));

        let rows = world
            .query::<&BigMapNpcRowEntity>()
            .iter(world)
            .cloned()
            .collect::<Vec<_>>();
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0].object_id, 77);
        assert_eq!(rows[0].name, "Village Guide");
        assert_eq!(rows[0].location, BigMapPoint { x: 330, y: 270 });
        assert_eq!(
            app.world_mut()
                .query::<&BigMapLoadingText>()
                .iter(app.world())
                .count(),
            0,
            "an authoritative map image must replace the loading state"
        );
    }

    #[test]
    fn big_map_ecs_shows_loading_text_without_authoritative_image() {
        let mut app = App::new();
        app.add_plugins(MinimalPlugins)
            .add_plugins(AssetPlugin::default())
            .init_asset::<Image>()
            .init_resource::<BigMapModel>()
            .init_resource::<BigMapUiState>()
            .init_resource::<UiReadModel>()
            .add_systems(Startup, spawn_big_map_render_test);

        app.update();

        let world = app.world_mut();
        let loading = world
            .query::<(&BigMapLoadingText, &Text)>()
            .iter(world)
            .map(|(_, text)| text.0.clone())
            .collect::<Vec<_>>();
        assert_eq!(loading, vec!["Loading map...".to_owned()]);
        assert_eq!(
            world.query::<&BigMapImageEntity>().iter(world).count(),
            0,
            "waiting for authority must not fabricate a map image"
        );
    }

    #[test]
    fn big_map_disabled_teleport_uses_explicit_crystal_title_823_frame() {
        let mut app = App::new();
        app.add_plugins(MinimalPlugins)
            .add_plugins(AssetPlugin::default())
            .init_asset::<Image>()
            .init_resource::<BigMapModel>()
            .init_resource::<BigMapUiState>()
            .init_resource::<UiReadModel>()
            .add_systems(Startup, spawn_big_map_render_test);
        app.update();

        let world = app.world_mut();
        let (entity, button, sprite_entity) = {
            let mut buttons =
                world.query::<(Entity, &OverlayButton, &CrystalImageButton, &Children)>();
            let (entity, _, button, children) = buttons
                .iter(world)
                .find(|(_, action, _, _)| matches!(action, OverlayButton::BigMapTeleport))
                .expect("BigMap Teleport button");
            let sprite_entity = children.iter().next().expect("Teleport button sprite");
            (entity, button.clone(), sprite_entity)
        };
        assert!(!button.enabled);
        assert!(!world.entity(entity).contains::<Button>());
        assert_eq!(
            button.assets.disabled.as_deref(),
            Some("original-ui/Title/823.png")
        );
        let image = world
            .get::<ImageNode>(sprite_entity)
            .expect("Teleport sprite image");
        assert_eq!(
            world
                .resource::<AssetServer>()
                .get_path(image.image.id())
                .map(|path| path.path().to_string_lossy().replace('\\', "/")),
            Some("original-ui/Title/823.png".to_owned())
        );
    }

    #[test]
    fn open_big_map_requests_authoritative_info_when_map_identity_arrives_late() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<BigMapModel>()
            .init_resource::<BigMapGatewayIntentQueue>()
            .init_resource::<BigMapUiState>()
            .add_systems(Update, sync_big_map_ui);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::BigMap;

        app.update();
        assert_eq!(
            app.world().resource::<BigMapGatewayIntentQueue>().len(),
            0,
            "no map request may be invented before MapInformation"
        );

        app.world_mut()
            .resource_mut::<BigMapModel>()
            .set_current_map(1);
        app.update();
        let intents = app
            .world_mut()
            .resource_mut::<BigMapGatewayIntentQueue>()
            .drain_intents();
        assert_eq!(
            intents,
            vec![crate::big_map::BigMapGatewayIntent::RequestMapInfo { map_index: 1 }]
        );

        app.update();
        assert_eq!(
            app.world().resource::<BigMapGatewayIntentQueue>().len(),
            0,
            "the same authoritative map identity must not flood requests"
        );
    }

    #[test]
    fn crystal_menu_options_and_bigmap_use_source_geometry() {
        assert_eq!(
            CRYSTAL_MENU_PANEL_RECT,
            CrystalRect::new(988.0, 349.0, 36.0, 282.0)
        );
        assert_eq!(
            CRYSTAL_OPTIONS_PANEL_RECT,
            CrystalRect::new(382.0, 207.0, 259.0, 354.0)
        );
        assert_eq!(
            CRYSTAL_BIGMAP_PANEL_RECT,
            CrystalRect::new(132.0, 134.0, 760.0, 500.0)
        );
        assert_eq!(BIGMAP_WIDTH, 568.0);
        assert_eq!(BIGMAP_HEIGHT, 380.0);
    }

    #[test]
    fn minimap_toggle_retains_state_and_mail_bigmap_esc_behavior() {
        let mut state = NativePlayerUiState::default();
        assert!(state.minimap_visible());
        state.core.minimap_visible = false;
        state.core.panel = mir2_ui_core::state::UiPanel::Mail;
        state.core.panel = mir2_ui_core::state::UiPanel::BigMap;
        // Simulate ESC handling via close_windows
        state.close_windows();
        assert!(!state.mail_open());
        assert!(!state.bigmap_open());
        // minimap_visible retained
        assert!(!state.minimap_visible());
        // Zoom retained
        let mut state2 = NativePlayerUiState::default();
        state2.bigmap_zoom = 2.5;
        state2.core.panel = mir2_ui_core::state::UiPanel::BigMap;
        state2.close_windows();
        assert_eq!(state2.bigmap_zoom, 2.5);
    }

    #[test]
    fn overlay_buttons_mail_flow_generates_intents() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MapModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>();
        let mut shell = NativeShellModel::default();
        shell.screen = NativeShellScreen::InGame;
        app.insert_resource(shell);
        // Seed mail with unclaimed attachment
        {
            let mut mail = app.world_mut().resource_mut::<MailModel>();
            mail.mails
                .push(mail_msg(10, false, false, 500, vec!["Potion"]));
            mail.mails.push(mail_msg(11, true, false, 0, vec![]));
            mail.mails.push(mail_msg(12, false, true, 100, vec![]));
        }
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);
        // Helper to press button
        fn press(app: &mut App, button: OverlayButton) {
            let entity = app
                .world_mut()
                .spawn((Interaction::Pressed, button, Button))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        }
        // Selection is local, but read state stays authoritative until a
        // refreshed MailModel arrives.
        press(&mut app, OverlayButton::SelectMail(10));
        {
            let mail = app.world().resource::<MailModel>();
            assert_eq!(mail.selected_id, Some(10));
            assert!(!mail.mails.iter().find(|m| m.id == 10).unwrap().read);
            assert!(app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .is_empty());
        }
        press(&mut app, OverlayButton::ReadMail(10));
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents
                .iter()
                .any(|i| matches!(i, NativePlayerUiIntent::ReadMail { mail_id: 10 })));
        }
        // Clear intents
        app.world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        press(&mut app, OverlayButton::SelectMail(10));
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
        // A second source row click opens the reader. The remaining legacy
        // list-action assertions model closing it before returning to MailDialog.
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.mail_reader = None;
            state.mail_reader_input_consumed = false;
        }
        assert!(
            !app.world()
                .resource::<MailModel>()
                .mails
                .iter()
                .find(|mail| mail.id == 10)
                .unwrap()
                .read
        );
        // Claim mail 10 should be enabled and push intent
        press(&mut app, OverlayButton::ClaimMail(10));
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents
                .iter()
                .any(|i| matches!(i, NativePlayerUiIntent::ClaimMail { mail_id: 10 })));
        }
        app.world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        // Claim mail 11 (already claimed) should not push
        press(&mut app, OverlayButton::ClaimMail(11));
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents.is_empty());
        }
        // Delete locked mail 12 should not push (disabled)
        press(&mut app, OverlayButton::DeleteMail(12));
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents.is_empty());
        }
        // A parcel warning is covered by focused mail_delete_tests. A plain
        // row keeps MailDialog's direct-delete path.
        press(&mut app, OverlayButton::DeleteMail(11));
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents
                .iter()
                .any(|i| matches!(i, NativePlayerUiIntent::DeleteMail { mail_id: 11 })));
        }
    }

    #[test]
    fn overlay_bigmap_zoom_buttons_clamp() {
        let mut state = NativePlayerUiState::default();
        assert_eq!(state.bigmap_zoom, 1.0);
        for _ in 0..10 {
            state.zoom_in();
        }
        assert_eq!(state.bigmap_zoom, BIGMAP_ZOOM_MAX);
        for _ in 0..20 {
            state.zoom_out();
        }
        assert_eq!(state.bigmap_zoom, BIGMAP_ZOOM_MIN);
    }

    #[test]
    fn hud_mail_bigmap_minimap_actions_are_exhaustively_handled() {
        // Ensure every CrystalHudAction is handled and Mail/BigMap go through reducer
        let actions = vec![
            CrystalHudAction::Mail,
            CrystalHudAction::BigMap,
            CrystalHudAction::MinimapToggle,
            CrystalHudAction::Inventory,
            CrystalHudAction::Quest,
            CrystalHudAction::Option,
        ];
        for action in actions {
            let state = NativePlayerUiState::default();
            let core_state_mail = mir2_ui_core::state::UiState {
                screen: mir2_ui_core::state::UiScreen::InGame,
                panel: mir2_ui_core::state::UiPanel::None,
                ..Default::default()
            };
            match action {
                CrystalHudAction::Mail => {
                    let t = mir2_ui_core::reducer::reduce(
                        &core_state_mail,
                        mir2_ui_core::action::UiAction::OpenMail,
                    );
                    assert_eq!(t.state.panel, mir2_ui_core::state::UiPanel::Mail);
                }
                CrystalHudAction::BigMap => {
                    let t = mir2_ui_core::reducer::reduce(
                        &core_state_mail,
                        mir2_ui_core::action::UiAction::OpenBigMap,
                    );
                    assert_eq!(t.state.panel, mir2_ui_core::state::UiPanel::BigMap);
                }
                CrystalHudAction::MinimapToggle => {
                    let s = mir2_ui_core::state::UiState {
                        screen: mir2_ui_core::state::UiScreen::InGame,
                        minimap_visible: true,
                        ..Default::default()
                    };
                    let t = mir2_ui_core::reducer::reduce(
                        &s,
                        mir2_ui_core::action::UiAction::ToggleMinimap,
                    );
                    assert!(!t.state.minimap_visible);
                    let _ = state.minimap_visible(); // ensure field exists
                }
                _ => {}
            }
        }
    }

    #[test]
    fn shop_quantity_and_buy_sell_disabled_states() {
        let mut shop = ShopModel::default();
        shop.goods.push(shop_good(1, "Potion", 100, 10));
        shop.goods.push(shop_good(2, "Sword", 400, 1));
        shop.selected_id = Some(1);
        let mut inventory = InventoryModel {
            gold: 50,
            items: vec![],
            ..Default::default()
        };
        // Not enough gold
        assert!(!shop_buy_enabled(&shop, &inventory, 1));
        inventory.gold = 500;
        assert!(shop_buy_enabled(&shop, &inventory, 1));
        // Quantity 2 costs 200, still enabled
        assert!(shop_buy_enabled(&shop, &inventory, 2));
        // Quantity clamping
        assert_eq!(shop_quantity_clamped(0), 1);
        assert_eq!(shop_quantity_clamped(100), 99);
        assert_eq!(shop_quantity_inc(99), 99);
        assert_eq!(shop_quantity_dec(1), 1);
        assert_eq!(shop_quantity_inc(1), 2);
        // Out of stock
        shop.selected_id = Some(2);
        assert!(!shop_buy_enabled(&shop, &inventory, 2)); // stock 1, qty2 fails
        assert!(shop_buy_enabled(&shop, &inventory, 1));
        // Full bag blocks buy
        let mut full_inventory = InventoryModel {
            gold: 10000,
            items: vec![],
            ..Default::default()
        };
        for slot in 0..BAG_SLOTS {
            full_inventory
                .items
                .push(item(&slot.to_string(), "Item", 0, slot));
        }
        shop.selected_id = Some(1);
        assert!(!shop_buy_enabled(&shop, &full_inventory, 1));
        // Sell enabled only when bag slot occupied
        assert!(shop_sell_enabled(&full_inventory, Some(0)));
        assert!(!shop_sell_enabled(&full_inventory, Some(99)));
        assert!(!shop_sell_enabled(&full_inventory, None));
        // Repair
        assert!(crate::shop::shop_repair_enabled(&full_inventory, Some(0)));
        assert!(!crate::shop::shop_repair_enabled(&full_inventory, Some(99)));
    }

    #[test]
    fn shop_blocks_world_click_and_uses_reducer() {
        let mut state = NativePlayerUiState::default();
        assert!(!state.blocks_world_click());
        state.core.panel = mir2_ui_core::state::UiPanel::GameShop;
        assert!(state.blocks_world_click());
        if state.shop_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.panel = mir2_ui_core::state::UiPanel::Storage;
        assert!(state.blocks_world_click());
        if state.storage_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        assert!(!state.blocks_world_click());
        // GameShop reducer not opening inventory
        let core_state = mir2_ui_core::state::UiState {
            screen: mir2_ui_core::state::UiScreen::InGame,
            panel: mir2_ui_core::state::UiPanel::None,
            ..Default::default()
        };
        let t = mir2_ui_core::reducer::reduce(
            &core_state,
            mir2_ui_core::action::UiAction::OpenGameShop,
        );
        assert_eq!(t.state.panel, mir2_ui_core::state::UiPanel::GameShop);
        assert_ne!(t.state.panel, mir2_ui_core::state::UiPanel::Inventory);
        // toggle off
        let core_shop = mir2_ui_core::state::UiState {
            screen: mir2_ui_core::state::UiScreen::InGame,
            panel: mir2_ui_core::state::UiPanel::GameShop,
            ..Default::default()
        };
        let t2 =
            mir2_ui_core::reducer::reduce(&core_shop, mir2_ui_core::action::UiAction::OpenGameShop);
        assert_eq!(t2.state.panel, mir2_ui_core::state::UiPanel::None);
    }

    #[test]
    fn storage_deposit_withdraw_and_password_disabled_states() {
        let mut storage = StorageModel::default();
        storage.size = STORAGE_BASE_SIZE;
        storage.has_password = true;
        storage.unlocked = false;
        storage.password_draft = "ab".to_owned();
        assert!(!storage_unlock_enabled(&storage));
        storage.password_draft = "abcd".to_owned();
        assert!(storage_unlock_enabled(&storage));
        storage.unlocked = true;
        storage.new_password_draft = "newpass".to_owned();
        storage.confirm_password_draft = "newpass".to_owned();
        storage.password_draft = "oldpass".to_owned();
        assert!(storage_set_password_enabled(&storage));
        storage.confirm_password_draft = "mismatch".to_owned();
        assert!(!storage_set_password_enabled(&storage));
        storage.confirm_password_draft = "newpass".to_owned();
        assert!(storage_remove_password_enabled(&storage));
        storage.has_password = false;
        assert!(!storage_remove_password_enabled(&storage));

        // deposit / withdraw
        let inventory = InventoryModel {
            gold: 500000,
            items: vec![item("1", "Potion", 0, 0)],
            ..Default::default()
        };
        let mut storage2 = StorageModel {
            size: 10,
            has_password: false,
            unlocked: true,
            ..Default::default()
        };
        storage2.selected_bag_slot = Some(0);
        assert!(storage_deposit_enabled(&storage2, &inventory));
        storage2.selected_bag_slot = None;
        assert!(!storage_deposit_enabled(&storage2, &inventory));
        // locked blocks
        storage2.has_password = true;
        storage2.unlocked = false;
        storage2.selected_bag_slot = Some(0);
        assert!(!storage_deposit_enabled(&storage2, &inventory));
        storage2.unlocked = true;
        assert!(storage_deposit_enabled(&storage2, &inventory));
        // withdraw
        storage2.items.push(item("2", "StoredSword", 4, 0));
        storage2.selected_storage_slot = Some(0);
        storage2.selected_bag_slot = None;
        assert!(storage_withdraw_enabled(&storage2, &inventory));
        // bag full blocks withdraw
        let mut full_inv = InventoryModel {
            gold: 0,
            items: vec![],
            ..Default::default()
        };
        for slot in 0..BAG_SLOTS {
            full_inv.items.push(item(&slot.to_string(), "X", 0, slot));
        }
        assert!(!storage_withdraw_enabled(&storage2, &full_inv));
        // expand
        let cheap_storage = StorageModel {
            has_expanded: false,
            ..Default::default()
        };
        assert!(!storage_expand_enabled(&cheap_storage, 500));
        assert!(storage_expand_enabled(&cheap_storage, 2_000_000));
        let expanded = StorageModel {
            has_expanded: true,
            ..Default::default()
        };
        assert!(storage_expand_enabled(&expanded, 2_000_000));
    }

    #[test]
    fn storage_blocks_world_click_and_close_retains_minimap() {
        let mut state = NativePlayerUiState {
            core: mir2_ui_core::state::UiState {
                panel: mir2_ui_core::state::UiPanel::Storage,
                minimap_visible: false,
                screen: mir2_ui_core::state::UiScreen::InGame,
                chat_focused: false,
                ..Default::default()
            },
            bigmap_zoom: 2.0,
            ..Default::default()
        };
        assert!(state.blocks_world_click());
        state.close_windows();
        assert!(!state.storage_open());
        assert!(!state.minimap_visible());
        assert_eq!(state.bigmap_zoom, 2.0);
    }

    #[test]
    fn inventory_buttons_use_explicit_instance_ids_and_suppress_duplicate_presses() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>();
        app.insert_resource(NativeShellModel {
            screen: NativeShellScreen::InGame,
            ..Default::default()
        });
        app.world_mut().resource_mut::<InventoryModel>().items = vec![
            ItemModel {
                unique_id: Some(42),
                key: "small-hp-drug".into(),
                name: "Small HP Drug".into(),
                quantity: 4,
                slot: 0,
                container: 0,
                ..ItemModel::default()
            },
            ItemModel {
                unique_id: Some(43),
                key: "small-hp-drug".into(),
                name: "Small HP Drug".into(),
                quantity: 2,
                slot: 1,
                container: 0,
                ..ItemModel::default()
            },
            ItemModel {
                unique_id: None,
                key: "legacy-template".into(),
                name: "Legacy".into(),
                quantity: 2,
                slot: 3,
                container: 0,
                ..ItemModel::default()
            },
            ItemModel {
                unique_id: Some(44),
                key: "sharp-dagger".into(),
                name: "SharpDagger".into(),
                quantity: 1,
                slot: 4,
                container: 0,
                equip_slot: Some("weapon".into()),
                ..ItemModel::default()
            },
        ];
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);
        fn press(app: &mut App, button: OverlayButton) {
            let entity = app
                .world_mut()
                .spawn((Interaction::Pressed, button, Button))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        }

        press(&mut app, OverlayButton::InspectBag(0));
        press(&mut app, OverlayButton::InventoryDeleteToggle);
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_delete_prompt
            .is_some());
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
        press(&mut app, OverlayButton::InventoryDeleteCancel);
        press(&mut app, OverlayButton::InspectBag(0));
        press(&mut app, OverlayButton::DropInspected);
        press(&mut app, OverlayButton::DropInspected);
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .drop_confirmation
            .is_some());
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
        press(&mut app, OverlayButton::ConfirmDropInspected);
        press(&mut app, OverlayButton::ConfirmDropInspected);
        press(&mut app, OverlayButton::SplitInspected);
        press(&mut app, OverlayButton::SplitInspected);
        press(&mut app, OverlayButton::ArmMoveInspected);
        press(&mut app, OverlayButton::InspectBag(2));
        press(&mut app, OverlayButton::InspectBag(0));
        press(&mut app, OverlayButton::ArmMergeInspected);
        press(&mut app, OverlayButton::InspectBag(1));

        let intents = app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        assert_eq!(intents.len(), 4);
        assert!(matches!(
            &intents[0],
            NativePlayerUiIntent::DropItem {
                key,
                unique_id: 42,
                count: 4,
                hero_inventory: false,
            } if key == "small-hp-drug"
        ));
        assert!(matches!(
            &intents[1],
            NativePlayerUiIntent::SplitItem {
                unique_id: 42,
                grid,
                count: 1,
            } if grid == "inventory"
        ));
        assert!(matches!(
            &intents[2],
            NativePlayerUiIntent::MoveItem {
                unique_id: 42,
                from: 0,
                to: 2,
                ..
            }
        ));
        assert!(matches!(
            &intents[3],
            NativePlayerUiIntent::MergeItem {
                id_from: 42,
                id_to: 43,
                ..
            }
        ));

        press(&mut app, OverlayButton::InspectBag(3));
        press(&mut app, OverlayButton::DropInspected);
        press(&mut app, OverlayButton::SplitInspected);
        press(&mut app, OverlayButton::ArmMoveInspected);
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_operation
            .is_none());
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .drop_confirmation
            .is_none());

        press(&mut app, OverlayButton::InspectBag(4));
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inspect
            .is_some());
        press(&mut app, OverlayButton::EquipInspected);
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inspect
            .is_none());
        assert_eq!(
            app.world_mut()
                .resource_mut::<NativePlayerUiIntentQueue>()
                .drain_intents(),
            vec![NativePlayerUiIntent::EquipItem {
                unique_id: 44,
                grid: "inventory".to_owned(),
                to: 0,
            }]
        );
    }

    #[test]
    fn inventory_delete_mode_uses_exact_stack_or_single_item_flow() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>();
        app.insert_resource(NativeShellModel {
            screen: NativeShellScreen::InGame,
            ..Default::default()
        });
        app.world_mut().resource_mut::<InventoryModel>().items = vec![
            ItemModel {
                unique_id: Some(42),
                key: "small-hp-drug".into(),
                name: "Small HP Drug".into(),
                quantity: 4,
                slot: 0,
                container: 0,
                ..ItemModel::default()
            },
            ItemModel {
                unique_id: Some(43),
                key: "guide-ring".into(),
                name: "Guide Ring".into(),
                quantity: 1,
                slot: 1,
                container: 0,
                ..ItemModel::default()
            },
            ItemModel {
                unique_id: Some(44),
                key: "quest-leaf".into(),
                name: "Cannibal Leaves".into(),
                quantity: 5,
                slot: 0,
                container: 3,
                ..ItemModel::default()
            },
        ];
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);
        fn press(app: &mut App, button: OverlayButton) {
            let entity = app
                .world_mut()
                .spawn((Interaction::Pressed, button, Button))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        }

        // No selected bag cell: the footer enters persistent delete mode.
        press(&mut app, OverlayButton::InventoryDeleteToggle);
        assert!(
            app.world()
                .resource::<NativePlayerUiState>()
                .inventory_delete_mode
        );
        press(&mut app, OverlayButton::InspectQuest(0));
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inspect
            .is_none());

        // A stack opens MirAmountBox semantics with the maximum selected.
        press(&mut app, OverlayButton::InspectBag(0));
        {
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(matches!(
                state.inventory_delete_prompt.as_ref(),
                Some(InventoryDeletePrompt::Amount {
                    target,
                    draft,
                    select_all: true,
                }) if target.unique_id == 42 && target.max_count == 4 && draft == "4"
            ));
        }
        push_delete_amount_text(
            &mut app.world_mut().resource_mut::<NativePlayerUiState>(),
            "2",
        );
        press(&mut app, OverlayButton::InventoryDeleteConfirm);

        // A selected one-count item opens the source Yes/No message box.
        press(&mut app, OverlayButton::InspectBag(1));
        press(&mut app, OverlayButton::InventoryDeleteToggle);
        assert!(matches!(
            app.world()
                .resource::<NativePlayerUiState>()
                .inventory_delete_prompt,
            Some(InventoryDeletePrompt::Confirm { .. })
        ));
        press(&mut app, OverlayButton::InventoryDeleteConfirm);

        let intents = app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        assert_eq!(intents.len(), 2);
        assert!(matches!(
            intents[0],
            NativePlayerUiIntent::DeleteItem {
                unique_id: 42,
                count: 2,
                hero_inventory: false,
            }
        ));
        assert!(matches!(
            intents[1],
            NativePlayerUiIntent::DeleteItem {
                unique_id: 43,
                count: 1,
                hero_inventory: false,
            }
        ));
        let pending = app.world().resource::<PendingOperations>();
        assert!(pending.contains(&PendingOperationKey::DeleteItem {
            unique_id: 42,
            count: 2,
        }));
        assert!(pending.contains(&PendingOperationKey::DeleteItem {
            unique_id: 43,
            count: 1,
        }));
        let state = app.world().resource::<NativePlayerUiState>();
        assert!(!state.inventory_delete_mode);
        assert!(state.inventory_delete_prompt.is_none());
    }

    #[test]
    fn inventory_delete_amount_editing_clamps_and_close_matches_crystal() {
        let inventory = InventoryModel {
            items: vec![ItemModel {
                unique_id: Some(7),
                key: "potion".into(),
                name: "Potion".into(),
                quantity: 12,
                slot: 3,
                container: 0,
                ..ItemModel::default()
            }],
            ..Default::default()
        };
        let mut state = NativePlayerUiState {
            inventory_delete_mode: true,
            ..Default::default()
        };
        assert!(state.open_inventory_delete_for_slot(&inventory, 3));
        push_delete_amount_text(&mut state, "9");
        assert!(matches!(
            state.inventory_delete_prompt,
            Some(InventoryDeletePrompt::Amount { ref draft, .. }) if draft == "9"
        ));
        push_delete_amount_text(&mut state, "9");
        assert!(matches!(
            state.inventory_delete_prompt,
            Some(InventoryDeletePrompt::Amount { ref draft, .. }) if draft == "12"
        ));
        delete_amount_backspace(&mut state);
        assert!(matches!(
            state.inventory_delete_prompt,
            Some(InventoryDeletePrompt::Amount { ref draft, .. }) if draft == "1"
        ));
        // The amount-box X disposes the modal without invoking CancelDelete.
        state.inventory_delete_prompt = None;
        assert!(state.inventory_delete_mode);
    }

    #[test]
    fn stale_inventory_delete_prompt_cannot_delete_a_replacement_stack() {
        let mut inventory = InventoryModel {
            items: vec![ItemModel {
                unique_id: Some(7),
                key: "potion".into(),
                name: "Potion".into(),
                quantity: 3,
                slot: 2,
                container: 0,
                ..ItemModel::default()
            }],
            ..Default::default()
        };
        let mut state = NativePlayerUiState {
            inventory_delete_mode: true,
            ..Default::default()
        };
        assert!(state.open_inventory_delete_for_slot(&inventory, 2));
        inventory.items[0].unique_id = Some(8);
        let mut intents = NativePlayerUiIntentQueue::default();
        let mut pending = PendingOperations::default();
        let parcel = mail_parcel::MailParcelUi::default();
        assert!(!confirm_inventory_delete(
            &mut state,
            &inventory,
            &parcel,
            &mut intents,
            &mut pending,
        ));
        assert!(intents.drain_intents().is_empty());
        assert!(!state.inventory_delete_mode);
        assert!(state.inventory_delete_prompt.is_none());
    }

    #[test]
    fn inventory_delete_dialog_uses_source_centered_geometry() {
        let mut app = overlay_render_test_app();
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        app.world_mut().resource_mut::<InventoryModel>().items = vec![ItemModel {
            unique_id: Some(42),
            key: "potion".into(),
            name: "Potion".into(),
            quantity: 4,
            slot: 0,
            container: 0,
            icon: 7,
            icon_width: 36,
            icon_height: 26,
            ..ItemModel::default()
        }];
        {
            let inventory = app.world().resource::<InventoryModel>().clone();
            assert!(app
                .world_mut()
                .resource_mut::<NativePlayerUiState>()
                .open_inventory_delete_for_slot(&inventory, 0));
        }
        app.update();
        app.update();

        let dialog = app
            .world_mut()
            .query_filtered::<&Node, With<OverlayInventoryDeleteDialog>>()
            .single(app.world())
            .expect("amount dialog");
        assert_eq!(dialog.left, Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.left));
        assert_eq!(dialog.top, Val::Px(CRYSTAL_DELETE_AMOUNT_RECT.top));
        assert_eq!(dialog.width, Val::Px(204.0));
        assert_eq!(dialog.height, Val::Px(109.0));

        let input = app
            .world_mut()
            .query_filtered::<&Node, With<OverlayInventoryDeleteAmountInput>>()
            .single(app.world())
            .expect("amount input");
        assert_eq!(input.left, Val::Px(58.0));
        assert_eq!(input.top, Val::Px(43.0));
        assert_eq!(input.width, Val::Px(132.0));
        assert_eq!(input.height, Val::Px(19.0));
    }

    #[test]
    fn character_unequip_addresses_first_real_free_bag_cell_and_never_mutates_locally() {
        let armour = ItemModel {
            unique_id: Some(121),
            key: "crystal-item-375".to_owned(),
            container: 2,
            slot: 1,
            quantity: 1,
            ..default()
        };
        let state = NativePlayerUiState {
            inspect: Some(inspect_from_item(&armour)),
            ..default()
        };
        let mut inventory = InventoryModel {
            items: vec![armour.clone()],
            ..default()
        };
        assert!(matches!(inspected_remove_intent(&state, &inventory),
            Some(NativePlayerUiIntent::RemoveItem { unique_id: 121, grid, to: 0 }) if grid == "inventory"));
        assert_eq!(
            inventory.items,
            vec![armour.clone()],
            "receipt owns equipment changes"
        );

        for slot in 0..40 {
            inventory.items.push(ItemModel {
                container: 0,
                slot,
                ..default()
            });
        }
        assert!(
            inspected_remove_intent(&state, &inventory).is_none(),
            "normal gear cannot target a locked bag page or use a guessed -1 destination"
        );
        inventory.capacity = 54;
        assert!(matches!(
            inspected_remove_intent(&state, &inventory),
            Some(NativePlayerUiIntent::RemoveItem { to: 40, .. })
        ));
        inventory
            .items
            .retain(|item| !(item.container == 0 && item.slot == 17));
        assert!(
            matches!(
                inspected_equip_intent(&state, &inventory),
                Some(NativePlayerUiIntent::RemoveItem { to: 17, .. })
            ),
            "keyboard G and pointer unequip use the same slot mapping"
        );
        let mut stale = state;
        stale.inspect.as_mut().unwrap().container = 3;
        assert!(inspected_remove_intent(&stale, &inventory).is_none());
    }

    #[test]
    fn character_unequip_never_aliases_a_free_belt_slot_to_an_occupied_bag_slot() {
        let mut source = crate::inventory::CrystalItemTooltipSourceModel::default();
        source.info.item_type = 8; // Crystal ItemType.Amulet.
        let amulet = ItemModel {
            unique_id: Some(700),
            key: "amulet".to_owned(),
            container: 2,
            slot: 9,
            tooltip_source: Some(source),
            ..default()
        };
        let state = NativePlayerUiState {
            inspect: Some(inspect_from_item(&amulet)),
            ..default()
        };
        let mut inventory = InventoryModel {
            items: vec![amulet],
            ..default()
        };
        for slot in 0..40 {
            inventory.items.push(ItemModel {
                container: 0,
                slot,
                ..default()
            });
        }
        assert!(
            inspected_remove_intent(&state, &inventory).is_none(),
            "the current normalized-bag endpoint must not misroute a free belt cell"
        );
        inventory
            .items
            .retain(|item| !(item.container == 0 && item.slot == 17));
        assert!(matches!(
            inspected_remove_intent(&state, &inventory),
            Some(NativePlayerUiIntent::RemoveItem { to: 17, .. })
        ));
    }

    #[test]
    fn character_slots_and_item_actions_fail_closed_without_a_live_item() {
        let mut state = NativePlayerUiState::default();
        let inventory = InventoryModel::default();
        state.inspect = Some(ItemInspect {
            container: 0,
            slot: 4,
            key: "stale".to_owned(),
            name: "Stale".to_owned(),
            quantity: 1,
        });

        assert!(inspected_use_intent(&state, &inventory).is_none());
        assert!(inspected_equip_intent(&state, &inventory).is_none());
        assert!(inspected_remove_intent(&state, &inventory).is_none());
        assert!(inspected_drop_confirmation(&state, &inventory).is_none());
    }

    #[test]
    fn quest_inventory_items_are_inspectable_but_read_only() {
        let inventory = InventoryModel {
            items: vec![ItemModel {
                unique_id: Some(124),
                key: "cannibal-leaves".to_owned(),
                name: "Cannibal Leaves".to_owned(),
                quantity: 5,
                slot: 0,
                container: 3,
                ..ItemModel::default()
            }],
            ..InventoryModel::default()
        };
        let mut state = NativePlayerUiState::default();
        state.inspect = inventory
            .items_in(3)
            .into_iter()
            .find(|item| item.slot == 0)
            .map(inspect_from_item);

        assert_eq!(container_name(3), "quest");
        assert_eq!(state.inspect.as_ref().map(|item| item.quantity), Some(5));
        assert!(inspected_inventory_item(&state, &inventory).is_none());
        assert!(inspected_use_intent(&state, &inventory).is_none());
        assert!(inspected_equip_intent(&state, &inventory).is_none());
        assert!(inspected_remove_intent(&state, &inventory).is_none());
        assert!(inspected_drop_confirmation(&state, &inventory).is_none());
    }

    #[test]
    fn stale_drop_confirmation_cannot_address_a_replacement_stack() {
        let confirmation = InventoryDropConfirmation {
            key: "Potion".to_owned(),
            unique_id: 7,
            slot: 2,
            count: 3,
        };
        let replacement = InventoryModel {
            gold: 0,
            items: vec![ItemModel {
                unique_id: Some(8),
                key: "Potion".to_owned(),
                name: "Potion".to_owned(),
                quantity: 3,
                slot: 2,
                container: 0,
                ..ItemModel::default()
            }],
            ..Default::default()
        };
        assert!(!drop_confirmation_is_current(&confirmation, &replacement));
    }

    #[test]
    fn skill_selection_is_local_and_clears_when_windows_close() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(SkillModel {
                authority: Default::default(),
                skill_key_ack: None,
                skills: vec![crate::skill_model::SkillEntry {
                    id: 17,
                    name: "Fire Ball".to_owned(),
                    level: 2,
                    key: Some("fire-ball".to_owned()),
                    cooldown_ms: 800,
                    mp_cost: 5,
                }],
                ..Default::default()
            })
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);

        let selected = app
            .world_mut()
            .spawn((Interaction::Pressed, OverlayButton::SelectSkill(17), Button))
            .id();
        app.update();
        app.world_mut().despawn(selected);
        assert_eq!(
            app.world()
                .resource::<NativePlayerUiState>()
                .selected_skill_id,
            Some(17)
        );

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .close_windows();
        assert_eq!(
            app.world()
                .resource::<NativePlayerUiState>()
                .selected_skill_id,
            None
        );
    }

    #[test]
    fn assigning_a_skill_key_uses_server_command_without_rewriting_legacy_file() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(SkillModel {
                authority: Default::default(),
                skill_key_ack: None,
                skills: vec![crate::skill_model::SkillEntry {
                    id: 17,
                    name: "Fire Ball".to_owned(),
                    level: 2,
                    key: Some("fire-ball".to_owned()),
                    cooldown_ms: 800,
                    mp_cost: 5,
                }],
                bindings: vec![crate::skill_model::SkillBinding {
                    skill_id: 17,
                    spell: Some("FireBall".into()),
                    hotkey: Some(0),
                    ..default()
                }],
            })
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
        init_overlay_button_test_resources(&mut app);
        app.init_resource::<MailUiState>()
            .init_resource::<StorageUiState>()
            .init_resource::<ShopUiState>()
            .init_resource::<crate::skill_model::SkillModelReceipts>();
        let path = app
            .world()
            .resource::<SkillBindingPersistenceRuntime>()
            .config_path
            .clone();
        let _ = std::fs::remove_file(&path);
        let _ = std::fs::remove_file(path.with_extension("json.bak"));
        let _ = std::fs::remove_file(path.with_extension("json.tmp"));
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::Skill;
        app.add_systems(
            Update,
            (
                sync_local_panel_models,
                process_overlay_buttons,
                skill_assign_dialog::process,
            )
                .chain(),
        );

        for button in [
            OverlayButton::SelectSkill(17),
            OverlayButton::AssignSkillKey(3),
            OverlayButton::CloseSkillAssign,
        ] {
            let entity = app
                .world_mut()
                .spawn((Interaction::Pressed, button, Button))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        }

        assert!(
            app.world()
                .resource::<SkillBindingUi>()
                .skill_for_hotkey(3)
                .is_none(),
            "draft does not change cast binding before dispatch"
        );
        let request_id = app
            .world()
            .resource::<NativePlayerUiState>()
            .skill_assign
            .request_id;
        assert_eq!(
            app.world_mut()
                .resource_mut::<NativePlayerUiIntentQueue>()
                .drain_intents(),
            vec![NativePlayerUiIntent::MagicKey {
                request_id,
                spell: "FireBall".into(),
                key: 3,
                old_key: 0
            }]
        );
        let mut receipt = app.world().resource::<SkillModel>().clone();
        receipt.bindings[0].hotkey = Some(3);
        receipt.skill_key_ack = Some(crate::skill_model::SkillKeyAck {
            request_id,
            spell: "FireBall".into(),
            key: 3,
            old_key: 0,
            accepted: true,
        });
        app.world_mut()
            .resource_mut::<crate::skill_model::SkillModelReceipts>()
            .0
            .push_back(receipt);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .skill_assign
            .dispatched(request_id, "FireBall", 3, 0, true);
        app.update();
        assert_eq!(
            app.world().resource::<SkillBindingUi>().skill_for_hotkey(3),
            Some(17)
        );
        app.update(); // The complete receipt is consumed after dispatch establishes pending.
        app.world_mut().resource_mut::<SkillModel>().bindings[0].hotkey = Some(0);
        app.update();
        assert_eq!(
            app.world().resource::<SkillBindingUi>().skill_for_hotkey(3),
            None,
            "an exact receipt retired the optimistic overlay"
        );
        assert!(
            !path.exists(),
            "server-owned bindings must not create/rewrite the legacy global file"
        );
        let _ = std::fs::remove_file(&path);
        let _ = std::fs::remove_file(path.with_extension("json.bak"));
        let _ = std::fs::remove_file(path.with_extension("json.tmp"));
    }

    #[test]
    fn crystal_character_inventory_and_skill_page_actions_are_local_and_real() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);

        for page in [
            CharacterPage::Stats1,
            CharacterPage::Stats2,
            CharacterPage::Spells,
            CharacterPage::Character,
        ] {
            let entity = app
                .world_mut()
                .spawn((
                    Button,
                    Interaction::Pressed,
                    OverlayButton::SelectCharacterPage(page),
                ))
                .id();
            app.update();
            assert_eq!(
                app.world().resource::<NativePlayerUiState>().character_page,
                page
            );
            assert_eq!(
                app.world_mut()
                    .resource_mut::<crate::audio::NativeUiAudioQueue>()
                    .drain_bounded(8),
                vec![crate::audio::NativeUiSound::ButtonA]
            );

            // A held button is not another Crystal click edge.
            app.update();
            assert_eq!(
                app.world()
                    .resource::<crate::audio::NativeUiAudioQueue>()
                    .len(),
                0
            );

            // Release and press again produces exactly one new cue.
            app.world_mut().entity_mut(entity).insert(Interaction::None);
            app.update();
            assert_eq!(
                app.world()
                    .resource::<crate::audio::NativeUiAudioQueue>()
                    .len(),
                0
            );
            app.world_mut()
                .entity_mut(entity)
                .insert(Interaction::Pressed);
            app.update();
            assert_eq!(
                app.world_mut()
                    .resource_mut::<crate::audio::NativeUiAudioQueue>()
                    .drain_bounded(8),
                vec![crate::audio::NativeUiSound::ButtonA]
            );
            app.world_mut().despawn(entity);
        }

        for page in [
            CharacterPage::Character,
            CharacterPage::Stats1,
            CharacterPage::Stats2,
            CharacterPage::Spells,
        ] {
            {
                let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
                state.core.panel = mir2_ui_core::state::UiPanel::Character;
                state.character_page = page;
            }
            let entity = app
                .world_mut()
                .spawn((Button, Interaction::Pressed, OverlayButton::CloseCharacter))
                .id();
            app.update();
            assert!(!app
                .world()
                .resource::<NativePlayerUiState>()
                .equipment_open());
            assert_eq!(
                app.world().resource::<NativePlayerUiState>().character_page,
                CharacterPage::Character,
                "the shared close lifecycle resets transient page state"
            );
            assert_eq!(
                app.world_mut()
                    .resource_mut::<crate::audio::NativeUiAudioQueue>()
                    .drain_bounded(8),
                vec![crate::audio::NativeUiSound::ButtonA]
            );

            // A held close control is not a second Crystal click edge.
            app.update();
            assert_eq!(
                app.world()
                    .resource::<crate::audio::NativeUiAudioQueue>()
                    .len(),
                0
            );

            app.world_mut().entity_mut(entity).insert(Interaction::None);
            app.update();
            app.world_mut()
                .resource_mut::<NativePlayerUiState>()
                .core
                .panel = mir2_ui_core::state::UiPanel::Character;
            app.world_mut()
                .entity_mut(entity)
                .insert(Interaction::Pressed);
            app.update();
            assert!(!app
                .world()
                .resource::<NativePlayerUiState>()
                .equipment_open());
            assert_eq!(
                app.world_mut()
                    .resource_mut::<crate::audio::NativeUiAudioQueue>()
                    .drain_bounded(8),
                vec![crate::audio::NativeUiSound::ButtonA]
            );
            app.world_mut().despawn(entity);
        }

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::Character;
        app.world_mut().resource_mut::<NativeShellModel>().screen =
            NativeShellScreen::ConnectionLost;
        let blocked_close = app
            .world_mut()
            .spawn((Button, Interaction::Pressed, OverlayButton::CloseCharacter))
            .id();
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .equipment_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );
        app.world_mut().despawn(blocked_close);
        app.world_mut().resource_mut::<NativeShellModel>().screen = NativeShellScreen::InGame;

        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
        assert!(app.world().resource::<NativeUiIntentQueue>().is_empty());

        let press = |app: &mut App, action: OverlayButton| {
            let entity = app
                .world_mut()
                .spawn((Button, Interaction::Pressed, action))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        };
        press(&mut app, OverlayButton::SelectInventoryPage(1));
        assert_eq!(
            app.world().resource::<NativePlayerUiState>().inventory_page,
            0,
            "the source length 46 keeps the second bag locked"
        );
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonA],
            "Crystal's locked MirButton still emits its click cue"
        );
        app.world_mut().resource_mut::<InventoryModel>().capacity = 54;
        press(&mut app, OverlayButton::SelectInventoryPage(1));
        assert_eq!(
            app.world().resource::<NativePlayerUiState>().inventory_page,
            1,
            "an explicit expanded Crystal array unlocks page two"
        );
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonA]
        );
        press(&mut app, OverlayButton::SkillPageNext);
        assert_eq!(
            app.world().resource::<NativePlayerUiState>().skill_page,
            0,
            "an empty authoritative skill model must not create a phantom page"
        );
        press(&mut app, OverlayButton::SkillPagePrev);
        assert_eq!(app.world().resource::<NativePlayerUiState>().skill_page, 0);
    }

    #[test]
    fn inventory_capacity_downgrade_closes_the_second_page_fail_closed() {
        let mut state = NativePlayerUiState {
            inventory_page: 1,
            ..Default::default()
        };
        let expanded = InventoryModel {
            capacity: 54,
            ..Default::default()
        };
        assert!(!reconcile_inventory_capacity(&mut state, &expanded));
        assert_eq!(state.inventory_page, 1);

        let locked = InventoryModel::default();
        assert!(reconcile_inventory_capacity(&mut state, &locked));
        assert_eq!(state.inventory_page, 0);
        assert!(state.inspect.is_none());
        assert!(state.inventory_operation.is_none());
        assert!(state.drop_confirmation.is_none());
    }

    #[test]
    fn inventory_second_tab_uses_exact_crystal_locked_and_page_assets() {
        let locked = InventoryModel::default();
        assert_eq!(inventory_second_tab_index(&locked, false), 169);
        assert_eq!(inventory_second_tab_index(&locked, true), 169);

        let expanded = InventoryModel {
            capacity: 54,
            ..Default::default()
        };
        assert_eq!(inventory_second_tab_index(&expanded, false), 738);
        assert_eq!(inventory_second_tab_index(&expanded, true), 168);
    }

    #[test]
    fn inventory_footer_uses_crystal_gold_and_weight_rules() {
        assert_eq!(format_crystal_gold(0), "0");
        assert_eq!(format_crystal_gold(1_280), "1,280");
        assert_eq!(format_crystal_gold(12_345_678), "12,345,678");

        assert_eq!(inventory_weight_bar_asset(0.0), ("Prguse", 24));
        assert_eq!(inventory_weight_bar_asset(0.50), ("Prguse", 24));
        assert_eq!(inventory_weight_bar_asset(0.75), ("UI_32bit", 471));
        assert_eq!(inventory_weight_bar_asset(0.76), ("UI_32bit", 470));
        assert_eq!(inventory_weight_bar_width(0.0), 0.0);
        assert_eq!(inventory_weight_bar_width(0.5), 40.0);
        assert_eq!(inventory_weight_bar_width(1.0), 81.0);
        assert_eq!(inventory_weight_bar_width(2.0), 81.0);
    }

    #[test]
    fn inventory_drag_matches_mircontrol_child_hit_and_stage_clamp_rules() {
        let mut window = InventoryDialogUi::default();
        assert_eq!((window.left, window.top), (0.0, 0.0));

        assert!(!window.begin_drag(10.0, 10.0), "first tab owns the hit");
        assert!(!window.begin_drag(10.0, 40.0), "item cells own the hit");
        assert!(!window.begin_drag(50.0, 216.0), "gold label owns the hit");
        assert!(
            !window.begin_drag(292.0, 213.0),
            "delete button owns the hit"
        );
        assert!(!window.begin_drag(300.0, 10.0), "close button owns the hit");
        assert!(
            !window.begin_drag(250.0, 10.0),
            "visible add button owns the hit"
        );
        assert!(
            window.begin_drag(182.0, 217.0),
            "WeightBar is NotControl in Crystal, so the parent owns its hit"
        );
        assert!(window.dragging());
        window.drag_to(300.0, 300.0);
        assert_eq!((window.left, window.top), (118.0, 83.0));
        window.drag_to(-100.0, -100.0);
        assert_eq!((window.left, window.top), (0.0, 0.0));
        window.drag_to(10_000.0, 10_000.0);
        assert_eq!(
            (window.left, window.top),
            (INVENTORY_MAX_LEFT, INVENTORY_MAX_TOP)
        );

        window.end_drag();
        assert!(!window.dragging());
        let stopped = (window.left, window.top);
        window.drag_to(200.0, 200.0);
        assert_eq!((window.left, window.top), stopped);
    }

    #[test]
    fn inventory_drag_system_uses_shared_stage_transform_and_preserves_location() {
        let mut app = App::new();
        let mut primary = Window::default();
        primary.resolution.set(2048.0, 1536.0);
        primary.set_cursor_position(Some(Vec2::new(450.0, 20.0)));
        app.world_mut().spawn((primary, PrimaryWindow));
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<ButtonInput<MouseButton>>()
            .add_message::<CursorMoved>()
            .add_systems(Update, process_inventory_drag);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .press(MouseButton::Left);
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_window
            .dragging());

        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .clear_just_pressed(MouseButton::Left);
        app.world_mut()
            .query_filtered::<&mut Window, With<PrimaryWindow>>()
            .single_mut(app.world_mut())
            .expect("primary window")
            .set_cursor_position(Some(Vec2::new(600.0, 400.0)));
        app.update();
        assert_eq!(
            {
                let inventory = &app
                    .world()
                    .resource::<NativePlayerUiState>()
                    .inventory_window;
                (inventory.left, inventory.top)
            },
            (75.0, 190.0)
        );

        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .release(MouseButton::Left);
        app.update();
        let state = app.world().resource::<NativePlayerUiState>();
        assert!(!state.inventory_window.dragging());
        assert_eq!(
            (state.inventory_window.left, state.inventory_window.top),
            (75.0, 190.0)
        );
    }

    #[test]
    fn inventory_item_drag_to_empty_belt_emits_one_raw_slot_move() {
        let mut app = App::new();
        let mut primary = Window::default();
        primary.focused = true;
        primary.resolution.set(1024.0, 768.0);
        let window = app.world_mut().spawn((primary, PrimaryWindow)).id();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<ShopModel>()
            .init_resource::<crate::crystal_ui::hud::CrystalBeltPresentation>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<ButtonInput<MouseButton>>()
            .add_message::<CursorMoved>()
            .add_systems(Update, process_inventory_item_drag);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        app.world_mut()
            .resource_mut::<InventoryModel>()
            .items
            .push(ItemModel {
                unique_id: Some(7002),
                key: "small-hp-drug".to_owned(),
                name: "(HP)DrugSmall".to_owned(),
                quantity: 1,
                slot: 2,
                container: 0,
                ..Default::default()
            });
        {
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(state.inventory_open());
            assert!(!state.amount_modal_open());
            assert!(!state.inventory_delete_mode);
            assert!(state.inventory_operation.is_none());
            assert!(!state.trade_dialog.open);
        }

        let source = Vec2::new(
            INVENTORY_GRID_ORIGIN.x as f32 + 2.0 * INVENTORY_GRID_STEP.x as f32 + 2.0,
            INVENTORY_GRID_ORIGIN.y as f32 + 2.0,
        );
        let belt = crate::crystal_ui::hud::belt_slot_rect(0, false);
        let destination = Vec2::new(belt.left + 2.0, belt.top + 2.0);
        {
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(state.inventory_open());
            assert!(!state.amount_modal_open());
            assert_eq!(inventory_bag_slot_at_cursor(state, source), Some(2));
        }
        assert_eq!(
            belt_slot_at_cursor(
                *app.world()
                    .resource::<crate::crystal_ui::hud::CrystalBeltPresentation>(),
                destination,
            ),
            Some(0)
        );
        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .press(MouseButton::Left);
        app.world_mut().write_message(CursorMoved {
            window,
            position: source,
            delta: None,
        });
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_item_drag
            .is_some());

        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .clear_just_pressed(MouseButton::Left);
        app.world_mut().write_message(CursorMoved {
            window,
            position: destination,
            delta: Some(destination - source),
        });
        app.update();
        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .release(MouseButton::Left);
        app.world_mut().write_message(CursorMoved {
            window,
            position: destination,
            delta: None,
        });
        app.update();

        assert_eq!(
            app.world_mut()
                .resource_mut::<NativePlayerUiIntentQueue>()
                .drain_intents(),
            vec![NativePlayerUiIntent::MoveItem {
                grid: "belt".to_owned(),
                unique_id: 7002,
                from: 8,
                to: 0,
            }]
        );
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_item_drag
            .is_none());
    }

    fn ordered_inventory_drag_motion(app: &mut App, window: Entity, position: Vec2) {
        app.world_mut()
            .entity_mut(window)
            .get_mut::<Window>()
            .unwrap()
            .set_cursor_position(Some(position));
        app.world_mut()
            .write_message(bevy::window::WindowEvent::CursorMoved(CursorMoved {
                window,
                position,
                delta: None,
            }));
    }

    fn ordered_inventory_drag_button(app: &mut App, window: Entity, pressed: bool) {
        app.world_mut()
            .write_message(bevy::window::WindowEvent::MouseButtonInput(
                bevy::input::mouse::MouseButtonInput {
                    window,
                    button: MouseButton::Left,
                    state: if pressed {
                        bevy::input::ButtonState::Pressed
                    } else {
                        bevy::input::ButtonState::Released
                    },
                },
            ));
    }

    fn batched_inventory_drag_app() -> (App, Entity, Vec2, Vec2) {
        let mut app = App::new();
        let mut primary = Window::default();
        primary.focused = true;
        primary.resolution.set(1024.0, 768.0);
        let window = app.world_mut().spawn((primary, PrimaryWindow)).id();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<InventoryModel>()
            .init_resource::<ShopModel>()
            .init_resource::<crate::crystal_ui::hud::CrystalBeltPresentation>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<ButtonInput<MouseButton>>()
            .add_message::<CursorMoved>()
            .add_message::<bevy::window::WindowEvent>()
            .add_systems(Update, process_inventory_item_drag);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        app.world_mut()
            .resource_mut::<InventoryModel>()
            .items
            .push(ItemModel {
                unique_id: Some(7003),
                key: "small-hp-drug".to_owned(),
                name: "(HP)DrugSmall".to_owned(),
                quantity: 2,
                slot: 2,
                container: 0,
                ..Default::default()
            });
        let source = Vec2::new(
            INVENTORY_GRID_ORIGIN.x as f32 + 2.0 * INVENTORY_GRID_STEP.x as f32 + 2.0,
            INVENTORY_GRID_ORIGIN.y as f32 + 2.0,
        );
        let belt = crate::crystal_ui::hud::belt_slot_rect(0, false);
        let destination = Vec2::new(belt.left + 2.0, belt.top + 2.0);
        (app, window, source, destination)
    }

    fn assert_batched_inventory_drag_intent(app: &mut App) {
        assert_eq!(
            app.world_mut()
                .resource_mut::<NativePlayerUiIntentQueue>()
                .drain_intents(),
            vec![NativePlayerUiIntent::MoveItem {
                grid: "belt".to_owned(),
                unique_id: 7003,
                from: 8,
                to: 0,
            }]
        );
    }

    fn npc_service_drag_app(
        mode: NpcShopServiceMode,
        hold: bool,
    ) -> (App, Entity, Vec2, Vec2) {
        let (mut app, window, _, _) = batched_inventory_drag_app();
        complete_repair_quote_metadata(
            app.world_mut()
                .resource_mut::<InventoryModel>()
                .items
                .first_mut()
                .expect("test drag item"),
        );
        // The complete two-item source fixture quotes 250 ordinary / 750
        // special repair at rate 1.0, so Hold reaches the service assertion.
        app.world_mut().resource_mut::<InventoryModel>().gold = 750;
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.toggle_npc_shop();
            // Source NPCDialog.Show places the visible ordinary bag at (445,0).
            // This focused service fixture has no NpcDialogModel transition.
            state.inventory_window.left = 445.0;
            state.inventory_window.top = 0.0;
            state.npc_service_hold = hold.then_some(mode);
        }
        let source = {
            let state = app.world().resource::<NativePlayerUiState>();
            Vec2::new(
                state.inventory_window.left + INVENTORY_GRID_ORIGIN.x as f32 + 2.0 * INVENTORY_GRID_STEP.x as f32 + 2.0,
                state.inventory_window.top + INVENTORY_GRID_ORIGIN.y as f32 + 2.0,
            )
        };
        {
            let mut shop = app.world_mut().resource_mut::<ShopModel>();
            shop.service_mode = mode;
            shop.repair_rate = matches!(
                mode,
                NpcShopServiceMode::Repair | NpcShopServiceMode::SpecialRepair
            )
            .then_some(1.0);
        }
        // NPCDropDialog is anchored at (264, NPCDialog.Size.Height), where
        // NPCDialog's Prguse/995 source frame is 224 px tall.
        let target = Vec2::new(304.0, 298.0);
        (app, window, source, target)
    }

    #[test]
    fn ordered_bag_drag_to_npc_target_selects_sale_without_inventory_move() {
        let (mut app, window, source, target) =
            npc_service_drag_app(NpcShopServiceMode::Sell, false);
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_button(&mut app, window, true);
        ordered_inventory_drag_motion(&mut app, window, target);
        ordered_inventory_drag_button(&mut app, window, false);

        app.update();
        assert_eq!(
            app.world().resource::<ShopModel>().selected_bag_slot_for_sell,
            Some(2)
        );
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
        app.update();
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
    }

    #[test]
    fn ordered_bag_drag_to_old_npc_service_origin_does_not_select_or_move() {
        let (mut app, window, source, _) = npc_service_drag_app(NpcShopServiceMode::Sell, false);
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_button(&mut app, window, true);
        ordered_inventory_drag_motion(&mut app, window, Vec2::new(40.0, 298.0));
        ordered_inventory_drag_button(&mut app, window, false);

        app.update();
        assert_eq!(
            app.world().resource::<ShopModel>().selected_bag_slot_for_sell,
            None
        );
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
    }

    #[test]
    fn deferred_npc_sale_confirm_rejects_a_replaced_drag_source() {
        let (mut app, window, source, target) =
            npc_service_drag_app(NpcShopServiceMode::Sell, false);
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_button(&mut app, window, true);
        ordered_inventory_drag_motion(&mut app, window, target);
        ordered_inventory_drag_button(&mut app, window, false);
        app.update();
        assert_eq!(
            app.world().resource::<NativePlayerUiState>().shop_service_drag_unique_id,
            Some(7003)
        );

        app.world_mut().resource_mut::<InventoryModel>().items[0].unique_id = Some(9999);
        let inventory = app.world().resource::<InventoryModel>().clone();
        let mut state = app
            .world_mut()
            .remove_resource::<NativePlayerUiState>()
            .expect("native UI state");
        let mut shop = app
            .world_mut()
            .remove_resource::<ShopModel>()
            .expect("shop model");
        let mut intents = app
            .world_mut()
            .remove_resource::<NativePlayerUiIntentQueue>()
            .expect("intent queue");
        let mut pending = app
            .world_mut()
            .remove_resource::<PendingOperations>()
            .expect("pending operations");

        assert!(!npc_item_service::submit_selection(
            &mut shop,
            &inventory,
            &mut state,
            &mut intents,
            &mut pending,
        ));
        assert_eq!(shop.selected_bag_slot_for_sell, None);
        assert_eq!(state.shop_service_drag_unique_id, None);
        assert!(intents.drain_intents().is_empty());

        app.world_mut().insert_resource(state);
        app.world_mut().insert_resource(shop);
        app.world_mut().insert_resource(intents);
        app.world_mut().insert_resource(pending);
    }

    #[test]
    fn deferred_npc_repair_confirms_reject_replaced_drag_sources() {
        for mode in [
            NpcShopServiceMode::Repair,
            NpcShopServiceMode::SpecialRepair,
        ] {
            let (mut app, window, source, target) = npc_service_drag_app(mode, false);
            ordered_inventory_drag_motion(&mut app, window, source);
            ordered_inventory_drag_button(&mut app, window, true);
            ordered_inventory_drag_motion(&mut app, window, target);
            ordered_inventory_drag_button(&mut app, window, false);
            app.update();
            assert_eq!(
                app.world().resource::<NativePlayerUiState>().shop_service_drag_unique_id,
                Some(7003)
            );

            app.world_mut().resource_mut::<InventoryModel>().items[0].unique_id = Some(9999);
            let inventory = app.world().resource::<InventoryModel>().clone();
            let mut state = app
                .world_mut()
                .remove_resource::<NativePlayerUiState>()
                .expect("native UI state");
            let mut shop = app
                .world_mut()
                .remove_resource::<ShopModel>()
                .expect("shop model");
            let mut intents = app
                .world_mut()
                .remove_resource::<NativePlayerUiIntentQueue>()
                .expect("intent queue");
            let mut pending = app
                .world_mut()
                .remove_resource::<PendingOperations>()
                .expect("pending operations");

            assert!(!npc_item_service::submit_selection(
                &mut shop,
                &inventory,
                &mut state,
                &mut intents,
                &mut pending,
            ));
            assert_eq!(shop.selected_bag_slot_for_repair, None);
            assert_eq!(state.shop_repair_slot, None);
            assert_eq!(state.shop_service_drag_unique_id, None);
            assert!(intents.drain_intents().is_empty());

            app.world_mut().insert_resource(state);
            app.world_mut().insert_resource(shop);
            app.world_mut().insert_resource(intents);
            app.world_mut().insert_resource(pending);
        }
    }

    #[test]
    fn ordered_bag_drag_to_npc_target_uses_the_active_service_and_hold_once() {
        for (mode, expected) in [
            (
                NpcShopServiceMode::Sell,
                NativePlayerUiIntent::SellItem {
                    unique_id: 7003,
                    count: 2,
                },
            ),
            (
                NpcShopServiceMode::Repair,
                NativePlayerUiIntent::RepairItem { unique_id: 7003 },
            ),
            (
                NpcShopServiceMode::SpecialRepair,
                NativePlayerUiIntent::SRepairItem { unique_id: 7003 },
            ),
        ] {
            let (mut app, window, source, target) = npc_service_drag_app(mode, true);
            ordered_inventory_drag_motion(&mut app, window, source);
            ordered_inventory_drag_button(&mut app, window, true);
            ordered_inventory_drag_motion(&mut app, window, target);
            ordered_inventory_drag_button(&mut app, window, false);

            app.update();
            assert_eq!(
                app.world_mut()
                    .resource_mut::<NativePlayerUiIntentQueue>()
                    .drain_intents(),
                vec![expected]
            );
            assert!(app
                .world()
                .resource::<NativePlayerUiState>()
                .inventory_item_drag
                .is_none());
            app.update();
            assert!(app
                .world_mut()
                .resource_mut::<NativePlayerUiIntentQueue>()
                .drain_intents()
                .is_empty());
        }
    }

    #[test]
    fn ordered_npc_service_drag_rejects_replaced_source_identity() {
        let (mut app, window, source, target) =
            npc_service_drag_app(NpcShopServiceMode::SpecialRepair, true);
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_button(&mut app, window, true);
        app.update();
        app.world_mut().resource_mut::<InventoryModel>().items[0].unique_id = Some(9999);
        ordered_inventory_drag_motion(&mut app, window, target);
        ordered_inventory_drag_button(&mut app, window, false);

        app.update();
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
        assert_eq!(
            app.world().resource::<ShopModel>().selected_bag_slot_for_repair,
            None
        );
    }

    #[test]
    fn inventory_item_drag_uses_ordered_same_frame_press_motion_release() {
        let (mut app, window, source, destination) = batched_inventory_drag_app();
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_button(&mut app, window, true);
        ordered_inventory_drag_motion(&mut app, window, destination);
        ordered_inventory_drag_button(&mut app, window, false);

        app.update();
        assert_batched_inventory_drag_intent(&mut app);
    }

    #[test]
    fn inventory_item_drag_bag_destinations_use_source_merge_or_swap_rules() {
        for (target_index, target_count, expected_merge) in [
            (None, 0, false), (Some(100), 3, true),
            (Some(100), 20, false), (Some(101), 3, false),
        ] {
            let (mut app, window, source, _) = batched_inventory_drag_app();
            app.init_resource::<MailComposeUi>()
                .init_resource::<NativeUiIntentQueue>()
                .init_resource::<MailModel>()
                .init_resource::<ShopModel>()
                .init_resource::<GameShopModel>()
                .init_resource::<StorageModel>()
                .init_resource::<crate::social::SocialModel>()
                .insert_resource(NativeShellModel {
                    screen: NativeShellScreen::InGame,
                    ..Default::default()
                });
            init_overlay_button_test_resources(&mut app);
            app.add_systems(Update, process_overlay_buttons.after(process_inventory_item_drag));
            {
                let mut inventory = app.world_mut().resource_mut::<InventoryModel>();
                inventory.items[0].tooltip_source = Some(surface_tooltip_source(100, "Drug", 1, 7003, 2));
                if let Some(index) = target_index {
                    inventory.items.push(ItemModel {
                        unique_id: Some(7004), slot: 12, container: 0,
                        quantity: target_count,
                        tooltip_source: Some(surface_tooltip_source(index, "Drug", 1, 7004, target_count as u16)),
                        ..Default::default()
                    });
                }
            }
            let destination = Vec2::new(
                INVENTORY_GRID_ORIGIN.x as f32 + (12 % INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.x as f32 + 2.0,
                INVENTORY_GRID_ORIGIN.y as f32 + (12 / INVENTORY_PAGE_COLUMNS) as f32 * INVENTORY_GRID_STEP.y as f32 + 2.0,
            );
            ordered_inventory_drag_motion(&mut app, window, source);
            ordered_inventory_drag_button(&mut app, window, true);
            let cell = app.world_mut().spawn((Button, Interaction::Pressed, OverlayButton::InspectBag(2))).id();
            app.update();
            assert!(app.world().resource::<NativePlayerUiState>().inspect.is_none());
            app.world_mut().despawn(cell);
            ordered_inventory_drag_motion(&mut app, window, destination);
            ordered_inventory_drag_button(&mut app, window, false);
            // A batched pointer edge may also leave a pressed destination
            // interaction in this frame; it must not reopen the item menu.
            let cell = app.world_mut().spawn((Button, Interaction::Pressed, OverlayButton::InspectBag(12))).id();
            app.update();
            app.world_mut().despawn(cell);
            let expected = if expected_merge {
                NativePlayerUiIntent::MergeItem { grid_from: "inventory".into(), grid_to: "inventory".into(), id_from: 7003, id_to: 7004 }
            } else {
                NativePlayerUiIntent::MoveItem { grid: "inventory".into(), unique_id: 7003, from: 2, to: 12 }
            };
            assert_eq!(app.world_mut().resource_mut::<NativePlayerUiIntentQueue>().drain_intents(), vec![expected]);
            let state = app.world().resource::<NativePlayerUiState>();
            assert!(state.inspect.is_none());
            assert!(state.inventory_item_drag.is_none());
            assert!(state.inventory_item_pointer_consumed);
            app.update();
            assert!(app.world_mut().resource_mut::<NativePlayerUiIntentQueue>().drain_intents().is_empty());
        }
    }

    #[test]
    fn inventory_item_drag_rejects_replaced_source_between_press_and_release() {
        let (mut app, window, source, destination) = batched_inventory_drag_app();
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_button(&mut app, window, true);
        app.update();
        app.world_mut().resource_mut::<InventoryModel>().items[0].unique_id = Some(9999);
        ordered_inventory_drag_motion(&mut app, window, destination);
        ordered_inventory_drag_button(&mut app, window, false);
        app.update();
        assert!(app.world_mut().resource_mut::<NativePlayerUiIntentQueue>().drain_intents().is_empty());
    }

    #[test]
    fn inventory_item_drag_uses_ordered_cross_frame_press_and_release() {
        let (mut app, window, source, destination) = batched_inventory_drag_app();
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_button(&mut app, window, true);
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_item_drag
            .is_some());

        ordered_inventory_drag_motion(&mut app, window, destination);
        ordered_inventory_drag_button(&mut app, window, false);
        app.update();
        assert_batched_inventory_drag_intent(&mut app);
    }

    #[test]
    fn inventory_item_motion_without_button_edges_does_not_move() {
        let (mut app, window, source, destination) = batched_inventory_drag_app();
        ordered_inventory_drag_motion(&mut app, window, source);
        ordered_inventory_drag_motion(&mut app, window, destination);
        app.update();
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
    }

    #[test]
    fn inventory_drag_keeps_same_frame_press_motion_release() {
        let mut app = App::new();
        let mut primary = Window::default();
        primary.resolution.set(1024.0, 768.0);
        let window = app.world_mut().spawn((primary, PrimaryWindow)).id();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<ButtonInput<MouseButton>>()
            .add_message::<CursorMoved>()
            .add_systems(Update, process_inventory_drag);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();
        {
            let mut mouse = app.world_mut().resource_mut::<ButtonInput<MouseButton>>();
            mouse.press(MouseButton::Left);
            mouse.release(MouseButton::Left);
        }
        app.world_mut().write_message(CursorMoved {
            window,
            position: Vec2::new(225.0, 10.0),
            delta: None,
        });
        app.world_mut().write_message(CursorMoved {
            window,
            position: Vec2::new(500.0, 300.0),
            delta: Some(Vec2::new(275.0, 290.0)),
        });

        app.update();

        let state = app.world().resource::<NativePlayerUiState>();
        assert_eq!(
            (state.inventory_window.left, state.inventory_window.top),
            (275.0, 290.0)
        );
        assert!(!state.inventory_window.dragging());
    }

    #[test]
    fn inventory_drag_uses_prepress_cursor_when_sendinput_batches_the_destination() {
        let mut app = App::new();
        let mut primary = Window::default();
        primary.resolution.set(1024.0, 768.0);
        let window = app.world_mut().spawn((primary, PrimaryWindow)).id();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<ButtonInput<MouseButton>>()
            .add_message::<CursorMoved>()
            .add_systems(Update, process_inventory_drag);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_inventory();

        // Windows SendInput first moves the pointer to the source while the
        // button is still up. The press edge and destination can then arrive
        // together in the following render frame.
        app.world_mut().write_message(CursorMoved {
            window,
            position: Vec2::new(225.0, 10.0),
            delta: None,
        });
        app.update();
        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .press(MouseButton::Left);
        app.world_mut().write_message(CursorMoved {
            window,
            position: Vec2::new(500.0, 218.0),
            delta: Some(Vec2::new(275.0, 208.0)),
        });
        app.update();

        {
            let inventory = &app
                .world()
                .resource::<NativePlayerUiState>()
                .inventory_window;
            assert_eq!((inventory.left, inventory.top), (275.0, 208.0));
            assert!(inventory.dragging());
        }

        {
            let mut mouse = app.world_mut().resource_mut::<ButtonInput<MouseButton>>();
            mouse.clear_just_pressed(MouseButton::Left);
            mouse.release(MouseButton::Left);
        }
        app.update();
        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .inventory_window
            .dragging());
    }

    #[test]
    fn overlay_buttons_shop_storage_flow_generates_intents() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MapModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>();
        let mut shell = NativeShellModel::default();
        shell.screen = NativeShellScreen::InGame;
        app.insert_resource(shell);
        {
            let mut inv = app.world_mut().resource_mut::<InventoryModel>();
            inv.gold = 5000;
            let mut potion = item("1", "Potion", 0, 0);
            complete_repair_quote_metadata(&mut potion);
            inv.items.push(potion);
            let mut sword = item("2", "Sword", 0, 1);
            complete_repair_quote_metadata(&mut sword);
            inv.items.push(sword);
        }
        {
            let mut shop = app.world_mut().resource_mut::<ShopModel>();
            shop.goods.push(shop_good(100, "Potion", 100, 10));
            shop.goods.push(shop_good(101, "Sword", 500, 5));
            assert!(shop.apply_service_signal(NpcShopServiceSignal {
                mode: NpcShopServiceMode::Buy,
                repair_rate: None,
            }));
        }
        {
            let mut storage = app.world_mut().resource_mut::<StorageModel>();
            storage.size = 10;
            storage.has_password = false;
            storage.unlocked = true;
        }
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_npc_shop();
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);
        fn press(app: &mut App, button: OverlayButton) {
            let entity = app
                .world_mut()
                .spawn((Interaction::Pressed, button, Button))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        }
        // Select shop good 100
        press(&mut app, OverlayButton::SelectShopGood(100));
        assert_eq!(app.world().resource::<ShopModel>().selected_id, Some(100));
        // Buy should be enabled and push intent
        press(&mut app, OverlayButton::ShopBuy);
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents.iter().any(|i| matches!(
                i,
                NativePlayerUiIntent::BuyItem {
                    item_index: 100,
                    count: 1
                }
            )));
        }
        app.world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        // A Buy service must not authorize Sell.
        press(&mut app, OverlayButton::SelectBagForSell(0));
        press(&mut app, OverlayButton::ShopSell);
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
        assert!(app
            .world_mut()
            .resource_mut::<ShopModel>()
            .apply_service_signal(NpcShopServiceSignal {
                mode: NpcShopServiceMode::Sell,
                repair_rate: None,
            }));
        assert!(app.world().resource::<ShopModel>().allows_buy());
        assert!(app.world().resource::<ShopModel>().allows_sell());
        assert!(
            app.world()
                .resource::<NativePlayerUiState>()
                .npc_shop_buy_tab,
            "NPCGoods followed by NPCSell must keep the Buy entry visible"
        );
        press(&mut app, OverlayButton::ShopShowSell);
        assert!(
            !app.world()
                .resource::<NativePlayerUiState>()
                .npc_shop_buy_tab
        );
        // Select bag for sell
        press(&mut app, OverlayButton::SelectBagForSell(0));
        assert_eq!(
            app.world()
                .resource::<ShopModel>()
                .selected_bag_slot_for_sell,
            Some(0)
        );
        assert_eq!(
            app.world().resource::<StorageModel>().selected_bag_slot,
            None
        );
        assert_eq!(
            app.world()
                .resource::<ShopModel>()
                .selected_bag_slot_for_repair,
            None
        );
        press(&mut app, OverlayButton::ShopSell);
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents
                .iter()
                .any(|i| matches!(i, NativePlayerUiIntent::SellItem { .. })));
        }
        app.world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        press(&mut app, OverlayButton::ShopShowBuy);
        assert!(
            app.world()
                .resource::<NativePlayerUiState>()
                .npc_shop_buy_tab
        );
        press(&mut app, OverlayButton::SelectShopGood(101));
        press(&mut app, OverlayButton::ShopConfirm);
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .iter()
            .any(|intent| matches!(
                intent,
                NativePlayerUiIntent::BuyItem {
                    item_index: 101,
                    count: 1
                }
            )));
        assert!(app
            .world_mut()
            .resource_mut::<ShopModel>()
            .apply_service_signal(NpcShopServiceSignal {
                mode: NpcShopServiceMode::Repair,
                repair_rate: Some(1.0),
            }));
        // Repair does nothing without its own selection, then uses only that selection.
        press(&mut app, OverlayButton::ShopRepair);
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
        press(&mut app, OverlayButton::SelectBagForRepair(1));
        press(&mut app, OverlayButton::ShopRepair);
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .iter()
            .any(|intent| matches!(intent, NativePlayerUiIntent::RepairItem { unique_id: 2 })));
        assert!(app
            .world_mut()
            .resource_mut::<ShopModel>()
            .apply_service_signal(NpcShopServiceSignal {
                mode: NpcShopServiceMode::SpecialRepair,
                repair_rate: Some(2.0),
            }));
        press(&mut app, OverlayButton::SelectBagForRepair(1));
        press(&mut app, OverlayButton::ShopRepair);
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .is_empty());
        press(&mut app, OverlayButton::ShopSRepair);
        assert!(app
            .world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents()
            .iter()
            .any(|intent| matches!(intent, NativePlayerUiIntent::SRepairItem { unique_id: 2 })));
        assert_eq!(
            app.world()
                .resource::<ShopModel>()
                .selected_bag_slot_for_sell,
            None
        );
        assert_eq!(
            app.world()
                .resource::<ShopModel>()
                .selected_bag_slot_for_repair,
            None,
            "successful repair enqueue clears Crystal's target item"
        );
        assert_eq!(
            app.world().resource::<StorageModel>().selected_bag_slot,
            None
        );
        // Shop quantity inc/dec
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.core.panel = mir2_ui_core::state::UiPanel::NpcShop;
            state.shop_quantity = 1;
        }
        assert!(app
            .world_mut()
            .resource_mut::<ShopModel>()
            .apply_service_signal(NpcShopServiceSignal {
                mode: NpcShopServiceMode::Sell,
                repair_rate: None,
            }));
        press(&mut app, OverlayButton::ShopQuantityInc);
        assert_eq!(
            app.world().resource::<NativePlayerUiState>().shop_quantity,
            2
        );
        press(&mut app, OverlayButton::ShopQuantityDec);
        assert_eq!(
            app.world().resource::<NativePlayerUiState>().shop_quantity,
            1
        );
        // Storage deposit
        press(&mut app, OverlayButton::SelectBagForStore(0));
        press(&mut app, OverlayButton::StorageDeposit);
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents.iter().any(|i| matches!(
                i,
                NativePlayerUiIntent::StoreItem { request_id, .. }
                    if request_id == "st-0000000000000001"
            )));
        }
        app.world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        // Storage withdraw: need item in storage
        {
            let mut storage = app.world_mut().resource_mut::<StorageModel>();
            storage.items.push(item("5", "StoredItem", 4, 0));
        }
        press(&mut app, OverlayButton::SelectStorage(0));
        press(&mut app, OverlayButton::StorageWithdraw);
        {
            let intents = app
                .world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .clone();
            assert!(intents.iter().any(|i| matches!(
                i,
                NativePlayerUiIntent::TakeBackItem { request_id, .. }
                    if request_id == "st-0000000000000002"
            )));
        }
        app.world_mut()
            .resource_mut::<NativePlayerUiIntentQueue>()
            .drain_intents();
        // Expand storage
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .core
            .panel = mir2_ui_core::state::UiPanel::Storage;
        {
            let mut inv = app.world_mut().resource_mut::<InventoryModel>();
            inv.gold = 2_000_000;
        }
        press(&mut app, OverlayButton::StorageExpand);
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .storage_rental_confirmation
            .is_some());
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
        press(&mut app, OverlayButton::StorageRentalConfirm);
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .iter()
            .any(|i| matches!(i, NativePlayerUiIntent::ExpandStorage)));
    }

    #[test]
    fn storage_request_ids_survive_queue_clear_for_connection_reset() {
        let mut queue = NativePlayerUiIntentQueue::default();
        let mut pending = PendingOperations::default();

        assert!(queue.push_storage_pending_intent(&mut pending, true, 10, 3, 9));
        let first = queue.drain_intents();
        assert!(matches!(
            first.as_slice(),
            [NativePlayerUiIntent::StoreItem { request_id, .. }]
                if request_id == "st-0000000000000001"
        ));

        queue.clear();
        assert!(queue.push_storage_pending_intent(&mut pending, false, 11, 9, 3));
        let second = queue.drain_intents();
        assert!(matches!(
            second.as_slice(),
            [NativePlayerUiIntent::TakeBackItem { request_id, .. }]
                if request_id == "st-0000000000000002"
        ));
    }

    #[test]
    fn cash_shop_selection_pages_beyond_first_eight_rows_is_receipt_deduped() {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<GameShopModel>()
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
        let mut ui = UiReadModel::default();
        ui.player.gold = 100;
        app.insert_resource(ui);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .toggle_shop();
        {
            let mut game_shop = app.world_mut().resource_mut::<GameShopModel>();
            for index in 0..105 {
                game_shop.upsert(crate::game_shop::GameShopEntry {
                    item_index: 1000 + index,
                    game_shop_index: index,
                    item_name: format!("Cash {index}"),
                    gold_price: 10,
                    can_buy_gold: true,
                    ..Default::default()
                });
            }
        }
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);

        fn press(app: &mut App, button: OverlayButton) {
            let entity = app
                .world_mut()
                .spawn((Interaction::Pressed, button, Button))
                .id();
            app.update();
            app.world_mut().despawn(entity);
        }

        press(&mut app, OverlayButton::SelectGameShopGood(25));
        assert_eq!(
            app.world()
                .resource::<GameShopModel>()
                .selected_game_shop_index,
            Some(25)
        );
        assert_eq!(
            app.world().resource::<NativePlayerUiState>().game_shop_page,
            3,
            "selecting gIndex 25 must move to the fourth Crystal 4x2 page"
        );

        press(&mut app, OverlayButton::GameShopBuy);
        assert_eq!(app.world().resource::<PendingOperations>().len(), 1);
        assert!(app
            .world()
            .resource::<GameShopModel>()
            .pending_purchase
            .is_some());
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .iter()
            .any(|intent| matches!(
                intent,
                NativePlayerUiIntent::GameShopBuy { g_index: 25, .. }
            )));
        press(&mut app, OverlayButton::GameShopBuy);
        assert_eq!(
            app.world()
                .resource::<NativePlayerUiIntentQueue>()
                .intents
                .iter()
                .filter(|intent| matches!(
                    intent,
                    NativePlayerUiIntent::GameShopBuy { g_index: 25, .. }
                ))
                .count(),
            1,
            "same-frame duplicate cash purchase must be blocked without inventing an ACK"
        );
    }

    #[test]
    fn full_social_intent_queue_rejects_without_pending_or_eviction() {
        let mut queue = NativePlayerUiIntentQueue::default();
        let mut social = crate::social::SocialModel::default();
        for index in 0..MAX_QUEUED {
            queue.push_intent(NativePlayerUiIntent::Chat {
                message: format!("queued-{index}"),
            });
        }

        assert!(!queue.push_social_pending(
            &mut social,
            NativePlayerUiIntent::TradeDepositItem { from: 2, to: 0 },
        ));
        assert_eq!(queue.intents.len(), MAX_QUEUED);
        assert!(
            matches!(queue.intents.front(), Some(NativePlayerUiIntent::Chat { message }) if message == "queued-0")
        );
        assert!(
            matches!(queue.intents.back(), Some(NativePlayerUiIntent::Chat { message }) if message == "queued-23")
        );
        assert!(social.pending.is_empty());
    }

    #[test]
    fn full_intent_queue_rejects_game_shop_without_any_pending_state() {
        let mut queue = NativePlayerUiIntentQueue::default();
        for index in 0..MAX_QUEUED {
            assert!(queue.push_intent(NativePlayerUiIntent::Chat {
                message: format!("queued-{index}"),
            }));
        }
        let mut core = mir2_ui_core::state::UiState::default();
        let mut game_shop = GameShopModel::default();
        let mut pending = PendingOperations::default();

        assert!(queue
            .enqueue_game_shop_purchase(&mut core, &mut game_shop, &mut pending, 31, 2, 1)
            .is_none());
        assert!(core.game_shop_pending.is_none());
        assert!(game_shop.pending_purchase.is_none());
        assert!(pending.is_empty());
        assert_eq!(queue.intents.len(), MAX_QUEUED);
    }

    #[test]
    fn queued_game_shop_is_non_evicting_and_drains_exactly_once_after_flood() {
        let mut queue = NativePlayerUiIntentQueue::default();
        for index in 0..MAX_QUEUED - 1 {
            assert!(queue.push_intent(NativePlayerUiIntent::Chat {
                message: format!("before-{index}"),
            }));
        }
        let mut core = mir2_ui_core::state::UiState::default();
        let mut game_shop = GameShopModel::default();
        let mut pending = PendingOperations::default();
        let request = queue
            .enqueue_game_shop_purchase(&mut core, &mut game_shop, &mut pending, 31, 2, 1)
            .expect("transaction fits in final slot");

        for index in 0..(MAX_QUEUED * 4) {
            assert!(queue.push_intent(NativePlayerUiIntent::Chat {
                message: format!("after-{index}"),
            }));
        }
        assert_eq!(queue.intents.len(), MAX_QUEUED);
        assert_eq!(
            queue
                .intents
                .iter()
                .filter(|intent| matches!(
                    intent,
                    NativePlayerUiIntent::GameShopBuy { request_id, .. }
                        if request_id == &request.request_id
                ))
                .count(),
            1
        );

        let drained = queue.drain_intents();
        assert_eq!(
            drained
                .iter()
                .filter(|intent| matches!(
                    intent,
                    NativePlayerUiIntent::GameShopBuy { request_id, .. }
                        if request_id == &request.request_id
                ))
                .count(),
            1
        );
        assert!(queue.drain_intents().is_empty());
        assert!(pending.contains(&PendingOperationKey::GameShop(request.request_id)));
    }

    #[test]
    fn enter_focuses_escape_cancels_and_empty_not_sent() {
        // Enter focuses chat
        let mut state = NativePlayerUiState::default();
        assert!(!state.chat_focused());
        // Simulate process_overlay_keyboard Enter when not focused -> focuses
        state.core.chat_focused = false;
        // focus via Enter
        state.core.chat_focused = true;
        assert!(state.chat_focused());
        // Draft non-empty trimmed sends on second Enter (blur)
        state.chat_draft = "  hello world  ".to_owned();
        let msg = state.trimmed_chat_to_send().unwrap();
        assert_eq!(msg, "hello world");
        state.chat_draft.clear();
        state.core.chat_focused = false;
        assert!(!state.chat_focused());
        // Escape cancels draft
        state.core.chat_focused = true;
        state.chat_draft = "some draft".to_owned();
        // simulate Escape
        state.core.chat_focused = false;
        state.chat_draft.clear();
        assert!(!state.chat_focused());
        assert!(state.chat_draft.is_empty());
        // Empty not sent
        state.chat_draft = "   ".to_owned();
        assert!(state.trimmed_chat_to_send().is_none());
        state.chat_draft = "".to_owned();
        assert!(state.trimmed_chat_to_send().is_none());
    }

    #[test]
    fn send_after_blur_requires_refocus() {
        let mut state = NativePlayerUiState::default();
        state.core.chat_focused = true;
        state.chat_draft = "test message".to_owned();
        let msg = state.trimmed_chat_to_send().expect("should send");
        // Simulate Enter handling: clear and blur
        state.chat_draft.clear();
        state.core.chat_focused = false;
        assert_eq!(msg, "test message");
        assert!(!state.chat_focused());
        // Next Enter should focus, not send
        state.core.chat_focused = true;
        assert!(state.chat_focused());
        assert!(state.chat_draft.is_empty());
    }

    #[test]
    fn inventory_allows_world_pointer_outside_but_keeps_drag_and_modal_capture() {
        let mut state = NativePlayerUiState::default();
        state.core.panel = mir2_ui_core::state::UiPanel::Inventory;
        assert!(state.blocks_world_pointer_at(20.0, 60.0));
        assert!(!state.blocks_world_pointer_at(500.0, 400.0));
        state.inventory_window.left = 400.0;
        state.inventory_window.top = 200.0;
        assert!(state.blocks_world_pointer_at(500.0, 250.0));
        assert!(!state.blocks_world_pointer_at(20.0, 60.0));
        state.inventory_window.dragging = true;
        assert!(state.blocks_world_pointer_at(20.0, 60.0));
        state.inventory_window.dragging = false;
        state.menu_pointer_consumed = true;
        assert!(state.blocks_world_pointer_at(20.0, 60.0));
        state.menu_pointer_consumed = false;
        state.core.panel = mir2_ui_core::state::UiPanel::Storage;
        assert!(state.blocks_world_pointer_at(20.0, 60.0));
    }

    #[test]
    fn any_window_blocks_world_click_and_action() {
        let mut state = NativePlayerUiState::default();
        assert!(!state.blocks_world_click());
        state.core.panel = mir2_ui_core::state::UiPanel::Inventory;
        assert!(state.blocks_world_click());
        if state.inventory_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.panel = mir2_ui_core::state::UiPanel::Skill;
        assert!(state.blocks_world_click(), "skill window must block");
        if state.skill_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.panel = mir2_ui_core::state::UiPanel::QuestLog;
        assert!(state.blocks_world_click());
        if state.quest_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.panel = mir2_ui_core::state::UiPanel::GameShop;
        assert!(state.blocks_world_click());
        if state.shop_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.panel = mir2_ui_core::state::UiPanel::Storage;
        assert!(state.blocks_world_click());
        if state.storage_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.chat_focused = true;
        assert!(state.blocks_world_click());
        state.core.chat_focused = false;
        state.inspect = Some(ItemInspect {
            container: 0,
            slot: 0,
            key: "k".into(),
            name: "n".into(),
            quantity: 1,
        });
        assert!(state.blocks_world_click());
        state.inspect = None;
        assert!(!state.blocks_world_click());
        // With dialog or dead also blocks via blocks_world_action
        assert!(state.blocks_world_action(true, false));
        assert!(state.blocks_world_action(false, true));
        assert!(!state.blocks_world_action(false, false));
    }

    #[test]
    fn dragging_window_scrollbar_or_button_captures_pointer_and_blocks_movement() {
        let mut state = NativePlayerUiState::default();
        // No window, but dragging window captures
        assert!(state.captures_pointer(true, false, false));
        assert!(state.captures_pointer(false, true, false));
        assert!(state.captures_pointer(false, false, true));
        // Even without drag, open window blocks
        state.core.panel = mir2_ui_core::state::UiPanel::Inventory;
        assert!(state.captures_pointer(false, false, false));
        if state.inventory_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        assert!(!state.captures_pointer(false, false, false));
        // Chat focused also blocks
        state.core.chat_focused = true;
        assert!(state.captures_pointer(false, false, false));
    }

    #[test]
    fn z_order_and_modal_priority_correct() {
        assert!(is_overlay_z_order_correct());
        assert_eq!(z_for_modal(OverlayModalPriority::Hud), OVERLAY_HUD_Z);
        assert_eq!(
            z_for_modal(OverlayModalPriority::SystemMenu),
            OVERLAY_MENU_Z
        );
        // Priority ordering: Menu > Death > Chat > NpcDialog > Hud
        assert!(OverlayModalPriority::SystemMenu > OverlayModalPriority::Death);
        assert!(OverlayModalPriority::Death > OverlayModalPriority::Chat);
        assert!(OverlayModalPriority::Chat > OverlayModalPriority::NpcDialog);
        // Test modal_priority_for_state
        let mut state = NativePlayerUiState::default();
        assert_eq!(modal_priority_for_state(&state, false, false), None);
        state.core.panel = mir2_ui_core::state::UiPanel::Menu;
        assert_eq!(
            modal_priority_for_state(&state, false, false),
            Some(OverlayModalPriority::SystemMenu)
        );
        if state.menu_open() {
            state.core.panel = mir2_ui_core::state::UiPanel::None;
        }
        state.core.chat_focused = true;
        assert_eq!(
            modal_priority_for_state(&state, false, true),
            Some(OverlayModalPriority::Death),
            "death overrides chat"
        );
        state.core.chat_focused = true;
        // dead true should prioritize death over chat
        state.core.chat_focused = true;
        // even with chat focused, dead wins
        // quest/dialog
        state.core.chat_focused = false;
        assert_eq!(
            modal_priority_for_state(&state, true, false),
            Some(OverlayModalPriority::NpcDialog)
        );
        state.core.panel = mir2_ui_core::state::UiPanel::QuestLog;
        assert_eq!(
            modal_priority_for_state(&state, false, false),
            Some(OverlayModalPriority::NpcDialog)
        );
    }

    #[test]
    fn group_invite_name_is_bounded_ordered_and_authoritative() {
        let mut queue = NativePlayerUiIntentQueue::default();
        let mut social = crate::social::SocialModel::default();

        assert!(!valid_social_name(""));
        assert!(!valid_social_name(" leading"));
        assert!(!valid_social_name(&"x".repeat(33)));
        assert!(valid_social_name("PlayerOne"));

        assert!(queue_group_invite_by_name(
            &mut queue,
            &mut social,
            "PlayerOne".to_owned()
        ));
        assert_eq!(
            social.pending,
            vec![crate::social::SocialPendingOperation::GroupAdd {
                name: "PlayerOne".to_owned()
            }]
        );
        assert_eq!(
            queue.drain_intents(),
            vec![
                NativePlayerUiIntent::GroupSwitch { allow_group: true },
                NativePlayerUiIntent::GroupAddMember {
                    name: "PlayerOne".to_owned()
                }
            ]
        );
        assert!(social.group.members.is_empty());
        assert!(!queue_group_invite_by_name(
            &mut queue,
            &mut social,
            "PlayerOne".to_owned()
        ));
    }

    #[test]
    fn guild_permission_aliases_accept_authoritative_bit_names() {
        let mut guild = crate::social::GuildModel {
            permissions: vec![
                "CanRecruit".to_owned(),
                "CanKick".to_owned(),
                "CanChangeRank".to_owned(),
                "CanChangeNotice".to_owned(),
            ],
            ..Default::default()
        };
        assert!(social_has_permission(&guild, "recruit"));
        assert!(social_has_permission(&guild, "kick"));
        assert!(social_has_permission(&guild, "changeRank"));
        assert!(social_has_permission(&guild, "notice"));
        assert!(!social_has_permission(&guild, "retrieveItem"));

        guild.permissions = vec!["changeNotice".to_owned()];
        assert!(social_has_permission(&guild, "notice"));
    }

    #[test]
    fn guild_storage_and_rank_intents_register_exact_authoritative_pending_keys() {
        let mut queue = NativePlayerUiIntentQueue::default();
        let mut social = crate::social::SocialModel::default();

        assert!(queue.push_social_pending(
            &mut social,
            NativePlayerUiIntent::GuildStorageGoldChange {
                change_type: 0,
                amount: 500,
            }
        ));
        assert!(queue.push_social_pending(
            &mut social,
            NativePlayerUiIntent::GuildStorageItemChange {
                change_type: 2,
                from: 3,
                to: 4,
            }
        ));
        assert!(queue.push_social_pending(
            &mut social,
            NativePlayerUiIntent::GuildEditMember {
                change_type: 4,
                rank_index: 2,
                name: "Member".to_owned(),
                rank_name: String::new(),
            }
        ));
        assert_eq!(
            social.pending,
            vec![
                crate::social::SocialPendingOperation::GuildStorageGold {
                    change_type: 0,
                    amount: 500,
                },
                crate::social::SocialPendingOperation::GuildStorageItem {
                    change_type: 2,
                    from: 3,
                    to: 4,
                },
                crate::social::SocialPendingOperation::GuildMember {
                    change_type: 4,
                    rank_index: 2,
                    name: "Member".to_owned(),
                },
            ]
        );
        assert_eq!(queue.drain_intents().len(), 3);
        assert!(!queue.push_social_pending(
            &mut social,
            NativePlayerUiIntent::GuildStorageGoldChange {
                change_type: 0,
                amount: 500,
            }
        ));
    }

    pub(super) fn help_keyboard_test_app() -> App {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<MapModel>()
            .init_resource::<ShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<ButtonInput<KeyCode>>()
            .init_resource::<crate::audio::NativeUiAudioQueue>()
            .add_message::<KeyboardInput>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            })
            .add_systems(Update, process_overlay_keyboard);
        app
    }

    pub(super) fn help_button_test_app() -> App {
        let mut app = App::new();
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<MailComposeUi>()
            .init_resource::<NativePlayerUiIntentQueue>()
            .init_resource::<PendingOperations>()
            .init_resource::<NativeUiIntentQueue>()
            .init_resource::<InventoryModel>()
            .init_resource::<MailModel>()
            .init_resource::<ShopModel>()
            .init_resource::<GameShopModel>()
            .init_resource::<StorageModel>()
            .init_resource::<crate::social::SocialModel>()
            .insert_resource(NativeShellModel {
                screen: NativeShellScreen::InGame,
                ..Default::default()
            });
        init_overlay_button_test_resources(&mut app);
        app.add_systems(Update, process_overlay_buttons);
        app
    }

    pub(super) fn press_help_button(app: &mut App, action: OverlayButton) {
        let button = app
            .world_mut()
            .spawn((Button, Interaction::Pressed, action))
            .id();
        app.update();
        app.world_mut().despawn(button);
    }

    #[test]
    fn help_catalog_matches_the_crystal_45_page_contract() {
        assert_eq!(HELP_PAGE_TITLES.len(), 45);
        assert_eq!(HELP_PAGE_TITLES[0], "Shortcut Information");
        assert_eq!(HELP_PAGE_TITLES[2], "Chat Shortcuts");
        assert_eq!(HELP_PAGE_TITLES[44], "Awakening");
        assert_eq!(help_shortcut_rows(0).unwrap().len(), 18);
        assert_eq!(help_shortcut_rows(1).unwrap().len(), 18);
        assert_eq!(help_shortcut_rows(2).unwrap().len(), 3);
        assert!(help_shortcut_rows(3).is_none());
        assert_eq!(help_image_dimensions(0), (512.0, 396.0));
        assert_eq!(help_image_dimensions(29), (509.0, 396.0));
        assert_eq!(help_image_dimensions(30), (508.0, 395.0));
        assert_eq!(help_image_dimensions(33), (509.0, 396.0));
        assert_eq!(help_image_dimensions(41), (508.0, 395.0));
    }

    #[test]
    fn help_navigation_wraps_clamps_and_hide_preserves_page() {
        let mut help = HelpDialogUi::default();
        assert_eq!(
            (help.left, help.top),
            (CRYSTAL_HELP_PANEL_RECT.left, CRYSTAL_HELP_PANEL_RECT.top)
        );
        assert_eq!(help.z_index(), OVERLAY_NPC_DIALOG_Z);
        help.previous_page();
        assert_eq!(help.page, 44);
        help.next_page();
        assert_eq!(help.page, 0);
        help.display_page(999);
        assert!(help.open);
        assert_eq!(help.page, 44);
        help.hide();
        assert!(!help.open);
        assert_eq!(help.page, 44);
        help.toggle();
        assert!(help.open);
        assert_eq!(help.page, 44);
        assert_eq!(help.z_index(), OVERLAY_HELP_SORTED_Z);
    }

    #[test]
    fn help_sort_true_raises_on_show_and_drag_below_modal_layers() {
        let mut help = HelpDialogUi::default();
        assert_eq!(help.z_index(), OVERLAY_NPC_DIALOG_Z);

        help.toggle();
        assert_eq!(help.z_index(), OVERLAY_HELP_SORTED_Z);
        assert!(help.z_index() > OVERLAY_NPC_DIALOG_Z);
        assert!(help.z_index() < OVERLAY_DEATH_Z);

        help.z_index = OVERLAY_NPC_DIALOG_Z;
        assert!(help.begin_drag(help.left + 100.0, help.top + 10.0));
        assert_eq!(help.z_index(), OVERLAY_HELP_SORTED_Z);
    }

    #[test]
    fn help_drag_preserves_grab_offset_clamps_and_stops_on_release() {
        let mut help = HelpDialogUi::default();
        help.open = true;
        assert!(help.begin_drag(help.left + 100.0, help.top + 10.0));
        assert!(help.dragging());

        help.drag_to(300.0, 200.0);
        assert_eq!((help.left, help.top), (200.0, 190.0));
        help.drag_to(-100.0, -100.0);
        assert_eq!((help.left, help.top), (0.0, 0.0));
        help.drag_to(10_000.0, 10_000.0);
        assert_eq!((help.left, help.top), (HELP_MAX_LEFT, HELP_MAX_TOP));

        help.end_drag();
        assert!(!help.dragging());
        let stopped = (help.left, help.top);
        help.drag_to(200.0, 200.0);
        assert_eq!((help.left, help.top), stopped);
    }

    #[test]
    fn help_drag_uses_only_blank_header_and_hide_clears_movement() {
        let mut help = HelpDialogUi::default();
        assert!(!help.begin_drag(help.left + 100.0, help.top + 10.0));
        help.open = true;
        assert!(!help.begin_drag(help.left + 20.0, help.top + 10.0));
        assert!(!help.begin_drag(help.left + 100.0, help.top + 100.0));
        assert!(!help.begin_drag(help.left + 510.0, help.top + 10.0));
        assert!(help.begin_drag(help.left + 100.0, help.top + 10.0));
        help.drag_to(400.0, 300.0);
        let moved = (help.left, help.top);
        help.hide();
        assert!(!help.dragging());
        assert_eq!((help.left, help.top), moved, "Hide preserves location");

        help = HelpDialogUi::default();
        assert_eq!(
            (help.left, help.top),
            (CRYSTAL_HELP_PANEL_RECT.left, CRYSTAL_HELP_PANEL_RECT.top),
            "session reset reconstructs the centered source location"
        );
    }

    #[test]
    fn help_drag_system_uses_the_shared_stage_transform_and_release_edge() {
        let mut app = App::new();
        let mut window = Window::default();
        window.resolution.set(2048.0, 1536.0);
        window.set_cursor_position(Some(Vec2::new(
            (CRYSTAL_HELP_PANEL_RECT.left + 100.0) * 2.0,
            (CRYSTAL_HELP_PANEL_RECT.top + 10.0) * 2.0,
        )));
        app.world_mut().spawn((window, PrimaryWindow));
        app.init_resource::<NativePlayerUiState>()
            .init_resource::<ButtonInput<MouseButton>>()
            .add_systems(Update, process_help_drag);
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .help
            .open = true;
        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .press(MouseButton::Left);
        app.update();
        assert!(app
            .world()
            .resource::<NativePlayerUiState>()
            .help
            .dragging());

        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .clear_just_pressed(MouseButton::Left);
        app.world_mut()
            .query_filtered::<&mut Window, With<PrimaryWindow>>()
            .single_mut(app.world_mut())
            .expect("primary window")
            .set_cursor_position(Some(Vec2::new(600.0, 400.0)));
        app.update();
        assert_eq!(
            {
                let help = &app.world().resource::<NativePlayerUiState>().help;
                (help.left, help.top)
            },
            (200.0, 190.0)
        );

        app.world_mut()
            .resource_mut::<ButtonInput<MouseButton>>()
            .release(MouseButton::Left);
        app.update();
        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .help
            .dragging());
    }

    #[test]
    fn help_drag_system_fails_closed_without_headless_input_resources() {
        let mut state = NativePlayerUiState::default();
        state.help.open = true;
        let cursor = (state.help.left + 100.0, state.help.top + 10.0);
        assert!(state.help.begin_drag(cursor.0, cursor.1));

        let mut app = App::new();
        app.insert_resource(state)
            .add_systems(Update, process_help_drag);
        app.update();

        assert!(!app
            .world()
            .resource::<NativePlayerUiState>()
            .help
            .dragging());
    }

    #[test]
    fn help_shortcut_requires_ctrl_and_shift_unpressed_but_ignores_alt() {
        fn opens(modifiers: &[KeyCode], chat_focused: bool) -> bool {
            let mut app = help_keyboard_test_app();
            app.world_mut()
                .resource_mut::<NativePlayerUiState>()
                .core
                .chat_focused = chat_focused;
            {
                let mut keys = app.world_mut().resource_mut::<ButtonInput<KeyCode>>();
                for modifier in modifiers {
                    keys.press(*modifier);
                }
                keys.press(KeyCode::KeyH);
            }
            app.update();
            app.world().resource::<NativePlayerUiState>().help_open()
        }

        assert!(opens(&[], false));
        assert!(opens(&[KeyCode::AltLeft], false));
        assert!(!opens(&[KeyCode::ControlLeft], false));
        assert!(!opens(&[KeyCode::ShiftLeft], false));
        assert!(!opens(&[], true), "chat input owns typed H");
    }

    #[test]
    fn crystal_p_shortcut_opens_group_even_while_help_is_visible() {
        let mut app = help_keyboard_test_app();
        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .help
            .display_page(0);
        app.world_mut()
            .resource_mut::<ButtonInput<KeyCode>>()
            .press(KeyCode::KeyP);
        app.update();

        let state = app.world().resource::<NativePlayerUiState>();
        assert!(state.help_open(), "Crystal Help coexists with core panels");
        assert!(state.group_open(), "Help page one declares P = Group");
        assert!(!state.storage_open(), "P must not route to Storage");
    }

    #[test]
    fn help_escape_closes_all_without_opening_menu_and_preserves_page() {
        let mut app = help_keyboard_test_app();
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.toggle_inventory();
            state.help.display_page(17);
        }
        app.world_mut()
            .resource_mut::<ButtonInput<KeyCode>>()
            .press(KeyCode::Escape);
        app.update();

        let state = app.world().resource::<NativePlayerUiState>();
        assert!(!state.inventory_open());
        assert!(!state.help_open());
        assert!(!state.menu_open());
        assert_eq!(state.help.page, 17);
    }

    #[test]
    fn panel_close_keeps_coexisting_help_while_session_reset_clears_it() {
        let mut state = NativePlayerUiState::default();
        state.toggle_inventory();
        state.help.display_page(9);
        state.close_windows();
        assert!(!state.inventory_open());
        assert!(state.help_open());
        assert_eq!(state.help.page, 9);
        state.reset_session();
        assert!(!state.help_open());
        assert_eq!(state.help.page, 0);
    }

    #[test]
    fn help_captures_its_surface_and_has_dialog_priority_without_chat_key_capture() {
        let mut state = NativePlayerUiState::default();
        state.help.open = true;
        assert!(state.blocks_world_pointer_at(300.0, 200.0));
        assert!(!state.blocks_world_pointer_at(900.0, 600.0));
        assert!(!state.blocks_gameplay_keys());
        assert_eq!(
            modal_priority_for_state(&state, false, false),
            Some(OverlayModalPriority::NpcDialog)
        );
        state.toggle_menu();
        assert_eq!(
            modal_priority_for_state(&state, false, false),
            Some(OverlayModalPriority::SystemMenu)
        );
    }

    #[test]
    fn help_internal_buttons_emit_one_button_a_while_menu_toggle_is_silent() {
        let mut app = help_button_test_app();

        press_help_button(&mut app, OverlayButton::ToggleHelp);
        assert!(app.world().resource::<NativePlayerUiState>().help_open());
        assert_eq!(
            app.world()
                .resource::<crate::audio::NativeUiAudioQueue>()
                .len(),
            0
        );

        press_help_button(&mut app, OverlayButton::HelpPrevious);
        assert_eq!(app.world().resource::<NativePlayerUiState>().help.page, 44);
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonA]
        );

        press_help_button(&mut app, OverlayButton::HelpNext);
        assert_eq!(app.world().resource::<NativePlayerUiState>().help.page, 0);
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonA]
        );

        press_help_button(&mut app, OverlayButton::CloseHelp);
        assert!(!app.world().resource::<NativePlayerUiState>().help_open());
        assert_eq!(
            app.world_mut()
                .resource_mut::<crate::audio::NativeUiAudioQueue>()
                .drain_bounded(8),
            vec![crate::audio::NativeUiSound::ButtonA]
        );
        assert!(app
            .world()
            .resource::<NativePlayerUiIntentQueue>()
            .intents
            .is_empty());
        assert!(app.world().resource::<NativeUiIntentQueue>().is_empty());
    }

    #[test]
    fn help_dynamic_pages_keep_every_source_row_above_the_footer() {
        let mut app = overlay_render_test_app();
        for page in 0..3 {
            app.world_mut()
                .resource_mut::<NativePlayerUiState>()
                .help
                .display_page(page);
            app.update();
            let world = app.world_mut();
            let mut text_nodes = world.query::<(&Text, &Node)>();
            for (label, left, top) in [("Shortcuts", 13.0, 75.0), ("Information", 114.0, 75.0)] {
                let (_, node) = text_nodes
                    .iter(world)
                    .find(|(text, _)| text.0 == label)
                    .unwrap();
                assert_eq!(node.left, Val::Px(left));
                assert_eq!(node.top, Val::Px(top));
            }
            let rows = help_shortcut_rows(page as u8).unwrap();
            for (row, (_, information)) in rows.iter().enumerate() {
                let matching: Vec<_> = text_nodes
                    .iter(world)
                    .filter(|(text, _)| text.0 == *information)
                    .collect();
                assert_eq!(matching.len(), 1, "page {page} row {row} remains present");
                let node = matching[0].1;
                assert_eq!(node.left, Val::Px(119.0));
                assert_eq!(node.width, Val::Px(400.0));
                let Val::Px(top) = node.top else {
                    panic!("absolute row top")
                };
                let Val::Px(height) = node.height else {
                    panic!("absolute row height")
                };
                assert_eq!(top, 107.0 + row as f32 * 20.0);
                assert_eq!(height, 23.0);
                assert!(
                    top >= 105.0 && top + height <= 480.0,
                    "page {page} row {row} must fit below headings and above pager"
                );
                assert!(text_nodes
                    .iter(world)
                    .any(|(_, key_node)| key_node.left == Val::Px(18.0)
                        && key_node.top == node.top
                        && key_node.width == Val::Px(95.0)
                        && key_node.height == node.height));
            }
        }
    }

    #[test]
    fn help_renderer_maps_dynamic_and_image_pages_without_fabrication() {
        let mut app = overlay_render_test_app();
        let peer_dialog = app
            .world_mut()
            .spawn(GlobalZIndex(OVERLAY_NPC_DIALOG_Z))
            .id();
        {
            let mut state = app.world_mut().resource_mut::<NativePlayerUiState>();
            state.help.left = 32.0;
            state.help.top = 41.0;
            state.help.display_page(0);
        }
        app.update();
        {
            let world = app.world_mut();
            let help_node = world
                .query_filtered::<&Node, With<OverlayHelp>>()
                .single(world)
                .expect("Help root");
            assert_eq!(help_node.left, Val::Px(32.0));
            assert_eq!(help_node.top, Val::Px(41.0));
            let help_z = *world
                .query_filtered::<&GlobalZIndex, With<OverlayHelp>>()
                .single(world)
                .expect("Help z index");
            let peer_z = *world
                .get::<GlobalZIndex>(peer_dialog)
                .expect("peer dialog z index");
            assert_eq!(help_z, GlobalZIndex(OVERLAY_HELP_SORTED_Z));
            assert!(help_z.0 > peer_z.0, "Sort=true raises Help above peers");
            assert_eq!(world.query::<&HelpPageImageEntity>().iter(world).count(), 0);
            assert!(world
                .query::<&Text>()
                .iter(world)
                .any(|text| text.0 == "1 / 45"));
        }

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .help
            .display_page(3);
        app.update();
        {
            let world = app.world_mut();
            let indices = world
                .query::<&HelpPageImageEntity>()
                .iter(world)
                .map(|image| image.image_index)
                .collect::<Vec<_>>();
            assert_eq!(indices, vec![0]);
        }

        app.world_mut()
            .resource_mut::<NativePlayerUiState>()
            .help
            .display_page(44);
        app.update();
        let world = app.world_mut();
        let indices = world
            .query::<&HelpPageImageEntity>()
            .iter(world)
            .map(|image| image.image_index)
            .collect::<Vec<_>>();
        assert_eq!(indices, vec![41]);
        assert!(world
            .query::<&Text>()
            .iter(world)
            .any(|text| text.0 == "45 / 45"));
    }
}
