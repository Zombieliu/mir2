import hashlib
import json
from pathlib import Path

root=Path('C:/mir2-playtest-releases/20261007-mining-r19')
trace=root/'native-run-03-public/movement.jsonl'
events=[json.loads(line) for line in trace.read_text().splitlines()]
commands=[r for r in events if r['type']=='commandSent']
confirm=[r for r in events if r['type']=='authoritative' and r.get('packet')=='UserLocation' and r.get('tsDisposition')=='confirmed']
assert len(commands)==1 and confirm[-1]['x']==289 and confirm[-1]['y']==618
source=Path('C:/mir2-build/mining-r19-public-wss02-20261007.mjs').read_text(encoding='utf-8')
source=source.replace("const root=base+'/public-wss-02';","const root=base+'/public-wss-03';")
old="const cohort=JSON.parse(await fs.readFile(base+'/public-wss-01/private/accounts.json','utf8'));\nneed(cohort.length===3&&cohort.every(a=>Number.isSafeInteger(a.characterIndex)),'Actual previously created ordinary actors');"
new="const cohort=JSON.parse(await fs.readFile(base+'/public-wss-02/private/accounts.json','utf8')).filter(a=>a.class==='Wizard');\nneed(cohort.length===1&&cohort[0].characterIndex===24,'Actual native-public actor');\ncohort[0].saved={map:'0',x:289,y:618};"
assert source.count(old)==1
source=source.replace(old,new).replace("for(const phase of ['verification','relogin'])","for(const phase of ['relogin'])").replace('results.length===6','results.length===1')
source=source.replace("previousWholeReport:'public-wss-01/RESULT.json remains failed; all four actual moves occurred, but the harness used a mutated self reference'","nativeSavedPositionWitness:'native-run-03-public/movement.jsonl',nativeTraceSha256:'"+hashlib.sha256(trace.read_bytes()).hexdigest()+"'")
target=Path('C:/mir2-build/mining-r19-public-wss03-20261007.mjs')
assert not target.exists()
target.write_text(source,encoding='utf-8',newline='\n')
print(json.dumps({'passed':True,'nativeInputSavedPosition':{'x':289,'y':618},'sourceTraceSha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'ordinaryLoginOnly':True}))
