import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root=Path('C:/mir2-playtest-releases/20261007-mining-r19')
project=Path('C:/Users/Administrator/.codex/worktrees/native-packed-resources/mir2-player-journey/mir2-web3')
clean=Path('C:/Users/Administrator/.codex/worktrees/m19u/mir2-player-journey')
archive=project/'docs/generated/player-qa/native-delivery-20261006/local-install-perf-01/PUBLICATION14.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='8e9d193a752c80751b59d17ecffda16abcda56b723239347751eceb99a26a01a'
assert subprocess.check_output(['git','-C',str(clean),'rev-parse','HEAD'],text=True).strip()=='b4390ee4c987bbf000ba1d95761151e39fc0d54f'
assert subprocess.check_output(['git','-C',str(clean),'status','--porcelain'],text=True)==''
out=root/'native-https15-probe'
out.mkdir()
(out/'src').mkdir()
(out/'source14').mkdir()
with zipfile.ZipFile(archive) as z:
    original=z.read('native-https14-probe/src/main.rs')
    cargo_original=z.read('native-https14-probe/Cargo.toml')
    (out/'source14/main.rs').write_bytes(original)
    (out/'source14/Cargo.toml').write_bytes(cargo_original)
main=original.decode().replace('\r\r\n','\n').replace('\r\n','\n')
replacements={
    'Some("14")':'Some("15")',
    'b5b29a4992c6cf6f276d35e2fba28a2a6b5aa640a0156e3474b81bb14a04f454':'11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c',
    '8e4c9e0800ea4724d05f600552df4cb62275097e88fba833ba1e09cfd9fe288b':'742d8403f6179697d58e5aa5b66c2b45ce4f485bdb573edbe0bf4b9212236ef5',
    'updater-8CDDDC11E89E3328-s14':'updater-9213EC3FE1A992F7-s15',
    'da47b670b127af8f62c6771f624ef75ded9d76fb365e49b0eccd0858467baa78':'82fed6853aed2ed3d8c8c7520b9d4b84aacd4ac2723c2e47506eb4d001cb99b0',
    '7f15daf54c7c5b5a87e774c6050645b7fcf88f43afaf1d96abfb7bd440926d65':'c19efee65316762e459ae48afc6123184e4c66defcb33f274fec046c66908a2b',
    '8cdddc11e89e3328276dd9ea7b7c8666ac4004d47566bd187e7b7302d614bb2e':'9213ec3fe1a992f757ea48c53981afa661765b42e637c1ad811e326060b170b8',
    '0b77fc6ce3e22cc0b81ede90b2802a16babddd460fb4e3f434052fcd629425bd':'ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03',
    'bytes 0-1023/27525634':'bytes 0-1023/29245069',
    'C:/mir2-playtest-releases/20261006-local-install-perf-01/bootstrap14/artifacts/Numeron-Legend-of-Rebirth-20261006-r17-Bootstrap.exe':'C:/mir2-playtest-releases/20261007-mining-r19/bootstrap-03/artifacts/Numeron-Legend-of-Rebirth-20261007-r19-Bootstrap.exe',
    '"directCdnSequence":14':'"directCdnSequence":15',
}
for old,new in replacements.items():
    assert old in main,old
    main=main.replace(old,new)
marker='    let r = agent.get("https://assets.mir2.obelisk.build/client-updates/installers/'
assert main.count(marker)==1
game_checks='''    let statement = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.json", 707, "e614b21b5ffa3ce82dfaf8c39270f317a3defed0bf0c1c378b52637b03ac0b24", &dir)?;
    let statement_sig = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.p7s", 1614, "d8a9d7162e4c851fa66b7d86cc206621f514e7348da28e933b80139932bfd3b1", &dir)?;
    platform::verify_cms(&statement, &statement_sig, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let value: serde_json::Value = serde_json::from_slice(&statement)?;
    ensure!(value["gitRevision"] == "2b04e82c4f42b22f895f5f95b5bd79a8147eacdf" && value["worktreeDirty"] == false && value["exeSha256"] == "3ABC0C7B74AF234D797705AC9CE32A68ABEFAC70BF43095093A353C81145F297", "actual game source and executable binding");
    let delivery = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.json", 10560229, "b7ba15b5478bff38a04b2678ccb52377e572ac0f7996b7af69403f1d137cf45a", &dir)?;
    let delivery_sig = get(&agent, "releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.p7s", 1614, "5d53e88d692f490a27a85404e68f3db1785673037565787cc96276897040e732", &dir)?;
    platform::verify_cms(&delivery, &delivery_sig, SIGNING_KEY).map_err(anyhow::Error::msg)?;
'''
main=main.replace(marker,game_checks+marker)
main=main.replace('"gameLaunched":false','"gameSource":"2b04e82c4f42b22f895f5f95b5bd79a8147eacdf","engineSource":"b4390ee4c987bbf000ba1d95761151e39fc0d54f","gameStatementCmsVerified":true,"deliveryCmsVerified":true,"gameLaunched":false')
(out/'src/main.rs').write_text(main,encoding='utf-8',newline='\n')
cargo=cargo_original.decode().replace('\r\r\n','\n').replace('\r\n','\n').replace('mir2-native-cdn14-readonly-proof','mir2-native-cdn15-readonly-proof').replace('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3/apps/game-client/windows-updater',str(clean/'mir2-web3/apps/game-client/windows-updater').replace('\\','/'))
(out/'Cargo.toml').write_text(cargo,encoding='utf-8',newline='\n')
receipt={'schema':'mir2.native.r19.https-probe-recipe.v1','engineSource':'b4390ee4c987bbf000ba1d95761151e39fc0d54f','gameSource':'2b04e82c4f42b22f895f5f95b5bd79a8147eacdf','priorSourceArchiveSha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'candidateSourceSha256':hashlib.sha256((out/'src/main.rs').read_bytes()).hexdigest(),'originalReadOnlySourceRetained':True,'networkExecuted':False}
(out/'RECIPE.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
