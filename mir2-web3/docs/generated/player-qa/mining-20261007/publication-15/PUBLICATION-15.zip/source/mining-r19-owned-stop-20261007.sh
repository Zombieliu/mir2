set -eu
python3 /home/ubuntu/mir2-playtest-preflight-20260929/mining-r19-20261007/mining-r19-owned-realm-v5-20261007.py stop --expected-elf 1c2eab2da38f31c7a96c308fff80c00fccfe6b1edb6602878c2b5c8845c44d83
