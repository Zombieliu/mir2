import ast
import json
from pathlib import Path

base = Path('C:/mir2-playtest-releases/20261007-mining-r19/operators-01')
original = (base / 'SEAL-STAGE-01.command').read_text(encoding='utf-8')
rows = ast.literal_eval(next(line[6:] for line in original.splitlines() if line.startswith('files=')))
assert len(rows) == 45 and len({r['name'] for r in rows}) == 45
fingerprint = [64769, 2932579, 16832, 0, 1791332304441057540, 1791332304441057540]
chmod = """python3 -B - <<'PY'
import hashlib, json, os, pathlib, stat
user=pathlib.Path('/tmp/mir2-origin-r19-s15-20261007-01')
root=pathlib.Path('/srv/.mir2-origin-r19-s15-20261007-01')
def ident(i): return (i.st_dev,i.st_ino,i.st_mode,i.st_uid,i.st_nlink,i.st_size,i.st_mtime_ns,i.st_ctime_ns)
""" + 'files=' + repr(rows) + "\n" + """assert os.geteuid()==1000
i=user.lstat()
assert stat.S_ISDIR(i.st_mode) and i.st_uid==1000 and i.st_mode & 0o777==0o700
fd=os.open(user,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:
    assert ident(os.fstat(fd))==ident(i)
    assert set(os.listdir(fd))=={r['name'] for r in files}
    for row in files:
        name=row['name']
        assert pathlib.Path(name).name==name and name not in ('.','..')
        p=os.stat(name,dir_fd=fd,follow_symlinks=False)
        assert stat.S_ISREG(p.st_mode) and p.st_uid==1000 and p.st_nlink==1 and p.st_mode & 0o777 in (0o664,0o600) and p.st_size==row['size']
        f=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
        with os.fdopen(f,'rb') as stream:
            assert ident(os.fstat(stream.fileno()))==ident(p)
            h=hashlib.sha256()
            size=0
            while True:
                chunk=stream.read(1024*1024)
                if not chunk: break
                size+=len(chunk)
                h.update(chunk)
            assert size==row['size'] and h.hexdigest()==row['sha256']
            assert ident(os.fstat(stream.fileno()))==ident(p) and ident(os.stat(name,dir_fd=fd,follow_symlinks=False))==ident(p)
            os.fchmod(stream.fileno(),0o600)
            after=os.fstat(stream.fileno())
            assert after.st_mode & 0o777==0o600 and after.st_uid==1000 and after.st_size==p.st_size and after.st_ino==p.st_ino and after.st_dev==p.st_dev and after.st_nlink==1 and after.st_mtime_ns==p.st_mtime_ns
            assert ident(os.stat(name,dir_fd=fd,follow_symlinks=False))==ident(after)
    assert ident(os.fstat(fd))==ident(i) and ident(user.lstat())==ident(i)
    assert set(os.listdir(fd))=={r['name'] for r in files}
finally: os.close(fd)
print(json.dumps({'schema':'mir2.origin.r19.private-mode-repair.v1','passed':True,'count':len(files),'mode':'0600','contentPinsVerified':True,'publicMutations':False}))
PY
"""
(base / 'PRIVATE-MODES-02.command').write_text(chmod, encoding='utf-8', newline='\n')
old = "assert not root.exists() and not root.is_symlink(), 'fresh-root-stage-required'"
new = """r=root.lstat()
assert [r.st_dev,r.st_ino,r.st_mode,r.st_uid,r.st_mtime_ns,r.st_ctime_ns]==""" + repr(fingerprint) + ", 'known-empty-failed-stage-identity-required'\nassert stat.S_ISDIR(r.st_mode) and r.st_uid==0 and r.st_mode & 0o777==0o700 and list(root.iterdir())==[], 'known-empty-root-stage-required'"
assert original.count(old)==1 and original.count('root.mkdir(mode=0o700)')==1
sealed=original.replace(old,new).replace('root.mkdir(mode=0o700)','').replace("assert ident(os.fstat(userfd))==ident(info), 'user-dir-open-race'", "assert ident(os.fstat(userfd))==ident(info), 'user-dir-open-race'\nassert ident(os.fstat(rootfd))==ident(r), 'root-dir-open-race'\nassert set(os.listdir(userfd))=={p['name'] for p in files}, 'closed-input-set-required'")
(base / 'SEAL-STAGE-02.command').write_text(sealed, encoding='utf-8', newline='\n')
print(json.dumps({'passed':True,'count':len(rows),'originalFailureRetained':True,'files':['PRIVATE-MODES-02.command','SEAL-STAGE-02.command']}))
