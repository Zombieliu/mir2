import hashlib
import json
import os
from pathlib import Path
import subprocess

root=Path('C:/mir2-playtest-releases/20261007-mining-r19')
candidate=Path('C:/Users/Administrator/.codex/worktrees/m19/mir2-player-journey/mir2-web3/dist/r19')
assert json.loads((root/'public-wss-02/RESULT.json').read_bytes())['passed'] is True
account=next(a for a in json.loads((root/'public-wss-02/private/accounts.json').read_bytes()) if a['class']=='Wizard')
assert account['characterIndex']==24
out=root/'native-run-03-public'
out.mkdir()
source=candidate/'mir2-platform-windows.exe'
expected='3abc0c7b74af234d797705ac9ce32a68abefac70bf43095093a353c81145f297'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(source)==expected
exe=out/source.name
with source.open('rb') as src,exe.open('xb') as dst:
    while chunk:=src.read(1024*1024):dst.write(chunk)
assert digest(exe)==expected
with (out/'mir2-client.toml').open('xb') as h:h.write((candidate/'mir2-client.toml').read_bytes())
for name in ['appdata','localappdata']:(out/name).mkdir()
env={k:v for k,v in os.environ.items() if not k.upper().startswith(('MIR2_','CRYSTAL_'))}
env.update({'MIR2_NATIVE_ACCOUNT':account['accountId'],'MIR2_NATIVE_PASSWORD':account['password'],'MIR2_NATIVE_CHARACTER_INDEX':str(account['characterIndex']),'MIR2_NATIVE_ASSET_ROOT':str(candidate/'mir2-assets'),'MIR2_GATEWAY_WS_URL':'wss://165.154.65.136.sslip.io/playtest/ws','MIR2_NATIVE_MOVEMENT_TRACE_PATH':str(out/'movement.jsonl'),'MIR2_NATIVE_INPUT_TRACE':'1','APPDATA':str(out/'appdata'),'LOCALAPPDATA':str(out/'localappdata')})
with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
    process=subprocess.Popen([str(exe)],cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,creationflags=subprocess.CREATE_NO_WINDOW)
receipt={'schema':'mir2.mining.r19.public-native-launch.v1','gameSource':'2b04e82c4f42b22f895f5f95b5bd79a8147eacdf','exeSha256':expected,'pid':process.pid,'endpoint':'wss://165.154.65.136.sslip.io/playtest/ws','class':'Wizard','accountId':account['accountId'],'characterIndex':24,'ordinaryLevel':1,'trustedLevelPositionFixtures':False,'settingsIsolated':True,'originalAssetRoot':str(candidate/'mir2-assets'),'passwordLogged':False,'gameInstallationTouched':False}
(out/'LAUNCH.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pid':process.pid,'class':'Wizard','ordinaryLevel':1,'settingsIsolated':True,'gameSource':receipt['gameSource']}))
