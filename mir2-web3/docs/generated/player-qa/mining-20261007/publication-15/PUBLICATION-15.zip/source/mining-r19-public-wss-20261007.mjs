import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const base='C:/mir2-playtest-releases/20261007-mining-r19';
const root=base+'/public-wss-01';
await fs.mkdir(root);
await fs.mkdir(root+'/private');
const vendor='C:/Users/Administrator/.codex/worktrees/native-packed-resources/mir2-player-journey/mir2-web3/docs/generated/player-qa/crowded-combat-escape-20261003/dense-v6-offline-20261004/source/vendor';
const wsBytes=await fs.readFile(vendor+'/ws.cjs');
if(crypto.createHash('sha256').update(wsBytes).digest('hex')!=='7b9865c26b0b6c148b4ed0d00dfc5409aff21e6a65851a2c5352b689f7351574')throw Error('Frozen WebSocket dependency differs');
const WebSocket=createRequire(import.meta.url)(vendor+'/ws.cjs');
const {applyProtocolObservation}=await import(pathToFileURL(vendor+'/protocol-observation.mjs'));
const cohort=[['A','Warrior','Male'],['B','Wizard','Female'],['C','Taoist','Male']].map(([s,klass,gender])=>({accountId:'PubR19'+s+'07',name:'PubMiner'+s+'07',class:klass,gender,password:crypto.randomBytes(12).toString('hex')}));
await fs.writeFile(root+'/private/accounts.json',JSON.stringify(cohort),{flag:'wx'});
const secrets=cohort.map(a=>a.password);
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function need(v,m){if(!v)throw Error(m);}
function safe(v){if(Array.isArray(v))return v.map(safe);if(v&&typeof v==='object')return Object.fromEntries(Object.entries(v).map(([k,x])=>[k,/password|secret|token|authorization|cookie|pepper|private.?key/i.test(k)?'[redacted]':safe(x)]));return typeof v==='string'?secrets.reduce((s,p)=>s.split(p).join('[redacted]'),v):v;}
const allowed=new Set(['clientVersion','newAccount','login','newCharacter','startGame','keepAlive','turn','walk','logOut']);
class Client{
 constructor(a,phase){this.a=a;this.phase=phase;this.events=[];this.sequence=0;this.queue=Promise.resolve();}
 record(direction,v){const e={sequence:++this.sequence,utc:new Date().toISOString(),direction,...safe(v)};this.events.push(e);this.queue=this.queue.then(()=>fs.appendFile(root+'/'+this.phase+'-'+this.a.class+'.jsonl',JSON.stringify(e)+'\n'));}
 async wait(f,label,ms=30000){const deadline=Date.now()+ms;while(Date.now()<deadline){if(this.error)throw this.error;const v=f();if(v)return v;await delay(25);}throw Error('Timed out: '+label);}
 send(v){need(allowed.has(v.type),'Ordinary command whitelist');this.record('sent',v);this.ws.send(JSON.stringify(v));}
 async req(v,packet){const n=this.sequence;this.send(v);return this.wait(()=>this.events.find(e=>e.sequence>n&&e.direction==='received'&&e.packet===packet),packet);}
 async open(){this.ws=new WebSocket('wss://165.154.65.136.sslip.io/playtest/ws',{origin:'https://165.154.65.136.sslip.io',handshakeTimeout:15000,rejectUnauthorized:true});this.ws.on('message',b=>{try{const v=JSON.parse(b);this.record('received',v);if(v.packet==='UserInformation')this.info=v.payload;this.snapshot=applyProtocolObservation(this.snapshot,v);if(v.type==='error')this.error=Error('Ordinary gateway command rejected');}catch(e){this.error=e;}});this.ws.on('error',()=>{this.error=Error('Public WSS connection failed');});await this.wait(()=>this.ws.readyState===1,'TLS WebSocket open',15000);this.send({type:'clientVersion'});this.timer=setInterval(()=>{if(this.ws.readyState===1)this.send({type:'keepAlive',time:Date.now()});},2000);}
 async login(){await this.req({type:'login',accountId:this.a.accountId,password:this.a.password},'LoginSuccess');}
 async start(){const n=this.sequence;const started=await this.req({type:'startGame',characterIndex:this.a.characterIndex},'StartGame');need(started.payload.result===4,'Normal authenticated StartGame result4');await this.wait(()=>this.events.find(e=>e.sequence>n&&e.packet==='UserInformation'),'owner UserInformation');await this.wait(()=>this.snapshot?.entities?.some(e=>e.objectId===this.snapshot.playerObjectId&&e.name===this.a.name),'actual shared owner snapshot');need(this.info.level===1&&this.info.hp>0,'Unmodified normal level1 actor');}
 async close(){clearInterval(this.timer);if(this.ws?.readyState===1){const prior=this.error;this.error=null;try{await this.req({type:'logOut'},'LogOutSuccess');this.normalLogout=true;}catch{}finally{this.error=prior;this.ws.close(1000);}}await this.queue;}
}
const results=[];
for(const a of cohort){
 for(const phase of ['registration','relogin']){
  const c=new Client(a,phase),row={class:a.class,accountId:a.accountId,characterName:a.name,phase,ordinaryCommandsOnly:true,trustedFixtures:false,nativeInputAcceptance:false,tlsVerified:true,passed:false};
  try{
   await c.open();
   if(phase==='registration'){
    const newAccount=await c.req({type:'newAccount',accountId:a.accountId,password:a.password,birthDateBinary:0,userName:'Release QA',secretQuestion:'q',secretAnswer:'a',emailAddress:''},'NewAccount');need(newAccount.payload.result===8,'Normal account creation result8');
    await c.login();const created=await c.req({type:'newCharacter',name:a.name,class:a.class,gender:a.gender},'NewCharacterSuccess');a.characterIndex=created.payload.character.index;need(Number.isSafeInteger(a.characterIndex),'Actual character index');
   }else await c.login();
   await c.start();row.characterIndex=a.characterIndex;row.level=c.info.level;row.map=c.snapshot.mapFileName;
   const self=c.snapshot.entities.find(e=>e.objectId===c.snapshot.playerObjectId);row.start={x:self.x,y:self.y};
   if(phase==='registration'){
    await c.req({type:'turn',direction:'Right'},'UserLocation');
    let moved=null;
    for(const [direction,dx,dy]of [['Down',0,1],['Right',1,0],['Left',-1,0],['Up',0,-1]]){
     const n=c.sequence;c.send({type:'walk',direction});
     try{moved=await c.wait(()=>c.events.find(e=>e.sequence>n&&e.packet==='UserLocation'&&e.payload.x===self.x+dx&&e.payload.y===self.y+dy),'normal one-tile move',1500);break;}catch{}
    }
    need(moved,'Actual ordinary move required');a.saved={map:c.snapshot.mapFileName,x:moved.payload.x,y:moved.payload.y};row.movedTo=a.saved;
   }else need(c.snapshot.mapFileName===a.saved.map&&self.x===a.saved.x&&self.y===a.saved.y,'Ordinary transform saved and loaded');
   row.passed=true;
  }catch(e){row.error=e.message;}
  finally{await c.close();row.normalLogoutConfirmed=c.normalLogout===true;row.passed=row.passed&&row.normalLogoutConfirmed;await fs.writeFile(root+'/'+phase+'-'+a.class+'.report.json',JSON.stringify(row,null,2),{flag:'wx'});results.push(row);}
  if(!row.passed)break;
 }
}
await fs.writeFile(root+'/private/accounts.json',JSON.stringify(cohort));
const receipt={schema:'mir2.mining.r19.public-wss-acceptance.v1',passed:results.length===6&&results.every(r=>r.passed),gameSource:'2b04e82c4f42b22f895f5f95b5bd79a8147eacdf',endpoint:'wss://165.154.65.136.sslip.io/playtest/ws',tlsVerified:true,ordinaryCommandsOnly:true,gmAdminCommands:false,qaLevelOrPositionPreparation:false,nativeInputAcceptance:false,actualMiningCoverage:'Separate original D401 paired-ELF class witnesses; these public actors are normal level1',results};
await fs.writeFile(root+'/RESULT.json',JSON.stringify(receipt,null,2),{flag:'wx'});console.log(JSON.stringify(receipt));if(!receipt.passed)process.exitCode=1;
