sudo -n python3 -B - <<'PY'
import hashlib,json,os,pathlib,stat,subprocess,urllib.request
def health(port):
    with urllib.request.urlopen('http://127.0.0.1:'+str(port)+'/health',timeout=10) as response:
        data=response.read(1048577)
        assert len(data)<1048577
        return json.loads(data)
main=health(7210)
old=health(7110)
assert main['ok'] is True and main['revision']=='2b04e82c4f42b22f895f5f95b5bd79a8147eacdf' and old['ok'] is True
states={}
for unit in ['mir2-playtest.service','mir2-gateway.service','caddy.service']:
    raw=subprocess.check_output(['systemctl','show',unit,'-p','MainPID','-p','Result','-p','NRestarts'],text=True)
    states[unit]=dict(line.split('=',1) for line in raw.splitlines())
assert states['mir2-playtest.service']['MainPID']=='2930135' and states['mir2-playtest.service']['Result']=='success' and states['mir2-playtest.service']['NRestarts']=='0'
assert states['mir2-gateway.service']['MainPID']=='3855184'
exe=pathlib.Path('/proc/2930135/exe').resolve(strict=True)
assert str(exe)=='/opt/mir2-playtest/releases/2b04e82c4f42b22f895f5f95b5bd79a8147eacdf/mir2-gateway'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='1c2eab2da38f31c7a96c308fff80c00fccfe6b1edb6602878c2b5c8845c44d83'
feed=pathlib.Path('/srv/mir2-client-updates/feed-current/latest.json')
if not feed.is_file():
    candidates=[p for p in pathlib.Path('/srv').glob('*/feed-current/latest.json') if p.is_file()]
    assert len(candidates)==1
    feed=candidates[0]
raw=feed.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c'
journal=subprocess.check_output(['journalctl','-b','-u','mir2-playtest.service','_PID=2930135','--no-pager','-o','cat'],text=True)
assert not any(v in journal for v in ['panicked at','Cannot start a runtime','panic in a destructor'])
backup=pathlib.Path('/var/backups/mir2-playtest-before-2b04e82c4f42b22f895f5f95b5bd79a8147eacdf')
assert backup.is_dir() and backup.stat().st_mode&0o777==0o700 and (backup/'result.json').is_file()
receipt={'schema':'mir2.mining.r19.post-publication-health.v1','passed':True,'revision':main['revision'],'binarySha256':'1c2eab2da38f31c7a96c308fff80c00fccfe6b1edb6602878c2b5c8845c44d83','capacity':main['capacity'],'serviceStates':states,'originalRealmHealthy':True,'originalRealmPidPreserved':True,'originFeed15Sha256':hashlib.sha256(raw).hexdigest(),'privateBackupRetained':True,'candidateJournalPanic':False,'playerSavesReadOrRewritten':False}
print(json.dumps(receipt))
PY
