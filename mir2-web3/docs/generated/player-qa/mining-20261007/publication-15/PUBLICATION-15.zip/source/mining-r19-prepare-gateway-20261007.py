import hashlib
import json
from pathlib import Path

base=Path('C:/mir2-playtest-releases/20261007-mining-r19')
ops=base/'operators-01'
game='2b04e82c4f42b22f895f5f95b5bd79a8147eacdf'
source='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-'+game
sealed='/srv/.mir2-gateway-r19-20261007-01'
rows=[]
batch=[]
for name,local,expected in [
    ('mir2-gateway',base/'server-ci-01/mir2-gateway','1c2eab2da38f31c7a96c308fff80c00fccfe6b1edb6602878c2b5c8845c44d83'),
    ('RELEASE.json',base/'server-ci-01/RELEASE.json','ba1e8f72119a9a5d3d1872a985f4e531f81fd538d2a1c2c883c9dbead4b5abbe'),
    ('VERIFIED-FILES.json',ops/'VERIFIED-FILES.json','833c76390bcc7752a7f8b8fb2b6fcd3e5fe5d5acadcb8911b272b99598d1d515'),
    ('upgrade-r19-gateway-01.py',ops/'upgrade-r19-gateway-01.py','7de335743dfcafe8717d566e3bf4193096a4dd77e954be7031f68fa91f1251c7'),
]:
    data=local.read_bytes()
    assert hashlib.sha256(data).hexdigest()==expected
    rows.append({'name':name,'size':len(data),'sha256':expected})
    batch.append([str(local),source+'/'+name])
(ops/'GATEWAY-UPLOAD-BATCH-01.json').write_text(json.dumps(batch,indent=2)+'\n',encoding='utf-8')
prepare="""python3 -B - <<'PY'
import json, os, pathlib, stat
"""+'p=pathlib.Path('+repr(source)+')\n'+"""assert os.geteuid()==1000
assert p.parent.resolve(strict=True)==p.parent
i=p.parent.lstat()
assert stat.S_ISDIR(i.st_mode) and i.st_uid==1000 and not i.st_mode & 0o022
assert not p.exists() and not p.is_symlink()
p.mkdir(mode=0o700)
print(json.dumps({'passed':True,'preparedPrivateSource':str(p),'publicMutations':False}))
PY
"""
(ops/'GATEWAY-CREATE-01.command').write_text(prepare,encoding='utf-8',newline='\n')
seal="""sudo -n python3 -B - <<'PY'
import hashlib, json, os, pathlib, stat
def ident(i):return(i.st_dev,i.st_ino,i.st_mode,i.st_uid,i.st_nlink,i.st_size,i.st_mtime_ns,i.st_ctime_ns)
"""+'p=pathlib.Path('+repr(source)+')\nr=pathlib.Path('+repr(sealed)+')\nrows='+repr(rows)+'\n'+"""assert os.geteuid()==0
i=p.lstat()
assert stat.S_ISDIR(i.st_mode) and i.st_uid==1000 and i.st_mode & 0o777==0o700 and p.resolve(strict=True)==p
fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
assert ident(os.fstat(fd))==ident(i) and set(os.listdir(fd))=={v['name'] for v in rows}
contents={}
try:
    for row in rows:
        old=os.stat(row['name'],dir_fd=fd,follow_symlinks=False)
        assert stat.S_ISREG(old.st_mode) and old.st_uid==1000 and old.st_nlink==1 and old.st_size==row['size'] and old.st_mode & 0o777==0o664
        f=os.open(row['name'],os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
        with os.fdopen(f,'rb') as h:
            assert ident(os.fstat(h.fileno()))==ident(old)
            data=h.read(row['size']+1)
            assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
            assert ident(os.fstat(h.fileno()))==ident(old) and ident(os.stat(row['name'],dir_fd=fd,follow_symlinks=False))==ident(old)
            os.fchmod(h.fileno(),0o600)
            new=os.fstat(h.fileno())
            assert new.st_uid==1000 and new.st_mode & 0o777==0o600 and new.st_nlink==1 and new.st_size==row['size']
            assert ident(os.stat(row['name'],dir_fd=fd,follow_symlinks=False))==ident(new)
        if row['name'].endswith('.py'):contents[row['name']]=data
    assert ident(os.fstat(fd))==ident(i) and ident(p.lstat())==ident(i)
finally:os.close(fd)
assert len(contents)==1 and not r.exists() and not r.is_symlink()
for parent in [*reversed(r.parent.parents),r.parent]:
    j=parent.lstat()
    assert stat.S_ISDIR(j.st_mode) and j.st_uid==0 and not j.st_mode & 0o022
r.mkdir(mode=0o700)
for name,data in contents.items():
    f=os.open(r/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(f,'wb') as h:h.write(data);h.flush();os.fsync(h.fileno())
for d in [r,r.parent]:
    f=os.open(d,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:os.fsync(f)
    finally:os.close(f)
print(json.dumps({'passed':True,'verifiedFiles':rows,'sealedOperator':str(r),'gameSource':'2b04e82c4f42b22f895f5f95b5bd79a8147eacdf','publicMutations':False}))
PY
"""
(ops/'GATEWAY-SEAL-01.command').write_text(seal,encoding='utf-8',newline='\n')
args=['--revision',game,'--expected-current','6032ef8b3e27dd97bad0b20c8676ef9f185db64b','--manifest-sha256','833c76390bcc7752a7f8b8fb2b6fcd3e5fe5d5acadcb8911b272b99598d1d515','--expected-active','51']
for mode in ('PREFLIGHT','APPLY'):
    command="""sudo -n python3 -B - <<'PY'
import hashlib, os, pathlib, stat, sys
"""+'p=pathlib.Path('+repr(sealed+'/upgrade-r19-gateway-01.py')+')\n'+"""assert os.geteuid()==0 and p.parent.resolve(strict=True)==p.parent
d=p.parent.lstat()
assert stat.S_ISDIR(d.st_mode) and d.st_uid==0 and d.st_mode & 0o777==0o700
i=p.lstat()
assert stat.S_ISREG(i.st_mode) and i.st_uid==0 and i.st_nlink==1 and i.st_mode & 0o777==0o600 and i.st_size<131072
f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
with os.fdopen(f,'rb') as h:
    j=os.fstat(h.fileno())
    assert (i.st_dev,i.st_ino,i.st_mode,i.st_size,i.st_mtime_ns,i.st_ctime_ns)==(j.st_dev,j.st_ino,j.st_mode,j.st_size,j.st_mtime_ns,j.st_ctime_ns)
    data=h.read(131073)
assert hashlib.sha256(data).hexdigest()=='7de335743dfcafe8717d566e3bf4193096a4dd77e954be7031f68fa91f1251c7'
"""+'sys.argv=[str(p)]+ '+repr(args+(['--apply'] if mode=='APPLY' else []))+"\nexec(compile(data,str(p),'exec'),{'__name__':'__main__','__file__':str(p)})\nPY\n"
    (ops/('GATEWAY-'+mode+'-01.command')).write_text(command,encoding='utf-8',newline='\n')
print(json.dumps({'passed':True,'rows':len(rows),'revision':game,'publicMutations':False}))
