from pathlib import Path
import hashlib
import json

original=Path('C:/mir2-build/mining-r19-public-wss-20261007.mjs')
source=original.read_text(encoding='utf-8')
old="const cohort=[['A','Warrior','Male'],['B','Wizard','Female'],['C','Taoist','Male']].map(([s,klass,gender])=>({accountId:'PubR19'+s+'07',name:'PubMiner'+s+'07',class:klass,gender,password:crypto.randomBytes(12).toString('hex')}));"
new="const cohort=JSON.parse(await fs.readFile(base+'/public-wss-01/private/accounts.json','utf8'));\nneed(cohort.length===3&&cohort.every(a=>Number.isSafeInteger(a.characterIndex)),'Actual previously created ordinary actors');"
assert source.count(old)==1
source=source.replace(old,new).replace("const root=base+'/public-wss-01';","const root=base+'/public-wss-02';")
source=source.replace("for(const phase of ['registration','relogin'])","for(const phase of ['verification','relogin'])")
start="   if(phase==='registration'){\n    const newAccount="
end="   }else await c.login();"
a=source.index(start);b=source.index(end,a)+len(end)
source=source[:a]+"   await c.login();"+source[b:]
source=source.replace("if(phase==='registration')","if(phase==='verification')")
source=source.replace("const self=c.snapshot.entities.find(e=>e.objectId===c.snapshot.playerObjectId);","const self={...c.snapshot.entities.find(e=>e.objectId===c.snapshot.playerObjectId)};")
source=source.replace("ordinaryCommandsOnly:true,gmAdminCommands:false,qaLevelOrPositionPreparation:false","ordinaryCommandsOnly:true,gmAdminCommands:false,qaLevelOrPositionPreparation:false,previousWholeReport:'public-wss-01/RESULT.json remains failed; all four actual moves occurred, but the harness used a mutated self reference'")
assert "newAccount=await" not in source
target=Path('C:/mir2-build/mining-r19-public-wss02-20261007.mjs')
assert not target.exists()
target.write_text(source,encoding='utf-8',newline='\n')
print(json.dumps({'passed':True,'oldSourceSha256':hashlib.sha256(original.read_bytes()).hexdigest(),'newSourceSha256':hashlib.sha256(target.read_bytes()).hexdigest(),'onlyHarnessChanged':True,'ordinaryExistingAccounts':True,'failedReportRetained':True}))
