"""Freeze bounded operators from reviewed prior recipes. No remote mutations."""
import hashlib, json, pathlib, re

ROOT=pathlib.Path('C:/mir2-playtest-releases/20261007-mining-r19')
PROJECT=pathlib.Path('C:/Users/Administrator/.codex/worktrees/native-packed-resources/mir2-player-journey/mir2-web3')
OLD=pathlib.Path('C:/mir2-playtest-releases/20261004-native-r18/cf-authorized-publication-20261005-01')
GAME='2b04e82c4f42b22f895f5f95b5bd79a8147eacdf'
ENGINE='b4390ee4c987bbf000ba1d95761151e39fc0d54f'
PREVIOUS='6032ef8b3e27dd97bad0b20c8676ef9f185db64b'
OUT=ROOT/'operators-01'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def put(name,raw):
    if isinstance(raw,str):raw=raw.encode('utf-8')
    p=OUT/name
    with p.open('xb') as f:f.write(raw)
    return p
def replace_once(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)

OUT.mkdir(exist_ok=False)
definition=json.loads((PROJECT/'infra/cloudflare/mir2-r2-bulk-upload/src/native-r19-s15-publication-plan.json').read_bytes())
planraw=(ROOT/'publication-01/PUBLICATION-PLAN.json').read_bytes()
proofraw=(ROOT/'publication-01/ROOT-VERIFICATION.json').read_bytes()
publication=json.loads(planraw);proof=json.loads(proofraw)
assert definition['admission']=='admitted' and definition['sourcePlanSha256']==sha(planraw)
assert definition['rootVerificationSha256']==sha(proofraw) and proof['cmsVerified'] is True
assert len(definition['objects'])==40 and publication['candidate']['sequence']==15
by_path={o['path']:o for o in publication['objects']}
objects=definition['objects']
assert len(by_path)==40 and {o['path'] for o in objects}==set(by_path)
guardraw=(OLD/'guards.py').read_bytes()
assert sha(guardraw)=='10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811'
put('guards.py',guardraw)
prepared={'schema':'mir2.native-origin.r19-s15.preparation.v1','gameSource':GAME,'engineSource':ENGINE,'candidate':publication['candidate'],'objects':objects,'published':False}
preparedraw=(json.dumps(prepared,indent=2)+'\n').encode()
put('APPEND-INPUTS.prepared.json',preparedraw)
put('PUBLICATION-PLAN.json',planraw);put('ROOT-VERIFICATION.json',proofraw)
olddef=json.loads((PROJECT/'infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-s14-publication-plan.json').read_bytes())
oldfeed={name:{k:o[k] for k in ('size','sha256')} for name,o in zip(('latest.json','latest.p7s'),olddef['objects'][:2])}
names={o['index']:f"{o['index']:02d}-"+pathlib.Path(o['path']).name for o in objects}
sourcefiles=[]
for obj in objects:
    p=pathlib.Path(by_path[obj['path']]['source'])
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    assert h==obj['sha256'] and p.stat().st_size==obj['size']
    sourcefiles.append({'source':str(p),'name':names[obj['index']],'size':obj['size'],'sha256':h})
pins={'prepared':sha(preparedraw),'guards':sha(guardraw),'proof':sha(proofraw),'publication':sha(planraw),'config':'4f54f9ca961771de96efff9b24d983815cfbbf5c69369bed9da5e9c61dec4632','feed14':oldfeed,'new':objects,'sourceNames':names}
template=(OLD/'origin_preview13.template.py').read_bytes()
assert sha(template)=='f3ae6378a0144f0ea4316688847d133c5d6816fa20dc138faca3b8c9d245c7cb'
text=template.decode().replace('\r\n','\n')
text=replace_once(text,'PINS = __PINS__','PINS = '+repr(pins))
text=text.replace('preview13','r19-s15').replace('20261005-01','20261007-01')
text=replace_once(text,"GAME = '"+PREVIOUS+"'","GAME = '"+GAME+"'")
text=replace_once(text,"ENGINE = '48454bba7623694ca7432613af52bee28e83970e'","ENGINE = '"+ENGINE+"'")
text=text.replace("PINS['feed12']","PINS['feed14']").replace("value['sequence']==12","value['sequence']==14")
text=text.replace("proof['sequence']==13","proof['sequence']==15").replace("value['sequence']==13 and value['expiresUnix']","value['sequence']==15 and value['expiresUnix']")
text=text.replace('feed12','feed14').replace('feed13','feed15').replace('fixed6','fixed40').replace('closed36','closed40')
text=text.replace('len(objects)==36','len(objects)==40').replace("for o in objects})==36","for o in objects})==40")
text=text.replace("game-source-preserved","game-source-binding")
mapping="{0:'00-latest.json',1:'01-latest.p7s',2:'02-Mir2Setup.exe',33:'33-ENGINE.json',34:'34-ENGINE.p7s',35:'35-Mir2Updater.exe'}"
assert text.count(mapping)==3
text=text.replace(mapping,"PINS['sourceNames']")
text=text.replace("require(len(baseline)==30,'original30-required')","require(not baseline,'all40-selected-required')")
text=text.replace('for index in (35,34,33,2,1,0):','for index in reversed(range(40)):')
start=text.index('def routes(');end=text.index('def main():',start)
text=text[:start]+text[end:]
text=text.replace("('preflight','append','routes')","('preflight','append')")
text=text.replace("        elif mode=='routes':\n            result['caddy']=routes(g,ops,feed_before)\n",'')
assert 'len(objects)==40' in text and 'for index in reversed(range(40))' in text
assert 'def routes(' not in text and 'fixed40' in text
compile(text,'origin_r19_s15.py','exec')
put('origin_r19_s15.py',text)

# Preserve the original atomic directory exchange and local TLS verification.
promoter=(pathlib.Path('C:/mir2-playtest-releases/20261006-local-install-perf-01/origin14/FEED-PROMOTE-01.command')).read_text().replace('\r\n','\n')
promoter=promoter.replace('preview14','r19-s15').replace('origin_r19-s15.py','origin_r19_s15.py').replace('20261006-01','20261007-01')
promoter=replace_once(promoter,'14043cc37e94798e7b83a0c09d59a124b5c57bcce27cbf4f6c3c6c72aa285989',sha(text.encode()))
promoter=promoter.replace('feed14-ready','feed15-ready').replace('feed14.v1','feed15.v1').replace("'sequence':14","'sequence':15").replace("w.PINS['feed13']","w.PINS['feed14']").replace('oldFeed13','oldFeed14').replace('complete36','complete40')
assert '/srv/.mir2-origin-r19-s15-20261007-01' in promoter
put('FEED-PROMOTE-01.command',promoter)

# Seal all complete inputs under root before any public writes. Template retains
# O_NOFOLLOW, same-FD hashes, same-filesystem and directory identity checks.
localfiles=[{'source':str(p),'name':p.name,'size':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in OUT.iterdir() if p.is_file() and p.suffix!='.command']
files=localfiles+sourcefiles
sealrows=[{k:r[k] for k in ('name','size','sha256')} for r in files]
put('SEAL-INPUTS-01.json',json.dumps(sealrows,indent=2)+'\n')
remote='/tmp/mir2-origin-r19-s15-20261007-01/'
put('UPLOAD-BATCH-01.json',json.dumps([[r['source'],remote+r['name']] for r in files],indent=2)+'\n')
generator=(OLD/'prepare_remote_commands.py').read_bytes()
assert sha(generator)=='67865d66a93416a445c55afe796a0fbbdc0ecfdf4e809cdb37ff057e2c8a9267'
commandgen=generator.decode().replace('\r\n','\n').replace('preview13','r19-s15').replace('origin_r19-s15.py','origin_r19_s15.py').replace('20261005-01','20261007-01').replace("('preflight','append','routes')","('preflight','append')")
# The template is fixed and input inventory is fully frozen above; it is only
# evaluated locally to produce Linux commands, without network/process calls.
assert 'subprocess' not in commandgen and 'os.system' not in commandgen
put('prepare_remote_commands.py',commandgen)
exec(compile(commandgen,str(OUT/'prepare_remote_commands.py'),'exec'),{'__file__':str(OUT/'prepare_remote_commands.py')})

# Gateway remains a separate drained-realm action, with its own private backup.
gatewaybase=pathlib.Path('C:/mir2-playtest-releases/20261004-native-r18/upgrade-r18-gateway-01.py').read_bytes()
assert sha(gatewaybase)=='ebc6673bbc63bfec37a2744bb59b9d2009934be2979bf2abae3bc6ae546c34bf'
gateway=gatewaybase.decode().replace('\r\n','\n').replace('321316b791120a6fe549e4006623e63333a5543f',GAME).replace('R17-to-R18','R17-to-R19')
gateway=replace_once(gateway,'def rollback(context, error):\n    failures = []','''def rollback(context, error):
    # A started v7 runtime may already have written mining checkpoints. Never
    # auto-run the v6 executable against newly persisted data or restore saves.
    if context.get("candidateStarted") is True:
        result = {"ok": False, "applied": False, "rolledBack": False,
                  "manualRecoveryRequired": True, "databaseRestored": False,
                  "configurationRetainedForV7": True, "backup": str(context["backup"]),
                  "error": str(error) if isinstance(error, SafetyError) else type(error).__name__}
        write_json(context["backup"] / "failure.json", result)
        return result
    failures = []''')
gateway=replace_once(gateway,'        first, candidate_pid = verify_live(context, True)','        context["candidateStarted"] = True\n        first, candidate_pid = verify_live(context, True)')
# Mark possible successful service start before executing it (unknown outcomes
# are conservative). Do not make an exception erase the migration boundary.
gateway=replace_once(gateway,'        run(["systemctl", "start", UNIT])\n        context["candidateStarted"] = True','        context["candidateStarted"] = True\n        run(["systemctl", "start", UNIT])')
compile(gateway,'upgrade-r19-gateway-01.py','exec');put('upgrade-r19-gateway-01.py',gateway)
artifact=ROOT/'server-ci-01';release=json.loads((artifact/'RELEASE.json').read_bytes())
assert release['gitRevision']==GAME and release['gitDirty'] is False
entries=[]
for name,mode in [('mir2-gateway',0o755),('RELEASE.json',0o644)]:
    p=artifact/name
    with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    entries.append({'path':name,'mode':mode,'size':p.stat().st_size,'sha256':h})
assert entries[0]['sha256']==release['binarySha256'] and entries[0]['size']==release['binarySizeBytes']
manifest=(json.dumps({'revision':GAME,'files':entries},indent=2)+'\n').encode()
put('VERIFIED-FILES.json',manifest)
put('OPERATOR-RECIPES.json',json.dumps({'schema':'mir2.mining.r19.operator-recipes.v1','gameSource':GAME,'engineSource':ENGINE,'oldGame':PREVIOUS,'originObjectCount':40,'sourceBytesVerified':sum(o['size'] for o in objects),'originWriterSha256':sha(text.encode()),'gatewayOperatorSha256':sha(gateway.encode()),'gatewayManifestSha256':sha(manifest),'guardSha256':sha(guardraw),'originConfigSha256':pins['config'],'publicMutations':False,'automaticV6RollbackAfterV7Start':False},indent=2)+'\n')
print(json.dumps({'prepared':str(OUT),'objects':40,'bytes':sum(o['size'] for o in objects),'gatewayManifestSha256':sha(manifest),'mutations':False}))
