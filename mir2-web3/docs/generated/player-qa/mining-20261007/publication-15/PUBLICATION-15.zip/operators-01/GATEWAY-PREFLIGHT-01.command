sudo -n python3 -B - <<'PY'
import hashlib, os, pathlib, stat, sys
p=pathlib.Path('/srv/.mir2-gateway-r19-20261007-01/upgrade-r19-gateway-01.py')
assert os.geteuid()==0 and p.parent.resolve(strict=True)==p.parent
d=p.parent.lstat()
assert stat.S_ISDIR(d.st_mode) and d.st_uid==0 and d.st_mode & 0o777==0o700
i=p.lstat()
assert stat.S_ISREG(i.st_mode) and i.st_uid==0 and i.st_nlink==1 and i.st_mode & 0o777==0o600 and i.st_size<131072
f=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
with os.fdopen(f,'rb') as h:
    j=os.fstat(h.fileno())
    assert (i.st_dev,i.st_ino,i.st_mode,i.st_size,i.st_mtime_ns,i.st_ctime_ns)==(j.st_dev,j.st_ino,j.st_mode,j.st_size,j.st_mtime_ns,j.st_ctime_ns)
    data=h.read(131073)
assert hashlib.sha256(data).hexdigest()=='7de335743dfcafe8717d566e3bf4193096a4dd77e954be7031f68fa91f1251c7'
sys.argv=[str(p)]+ ['--revision', '2b04e82c4f42b22f895f5f95b5bd79a8147eacdf', '--expected-current', '6032ef8b3e27dd97bad0b20c8676ef9f185db64b', '--manifest-sha256', '833c76390bcc7752a7f8b8fb2b6fcd3e5fe5d5acadcb8911b272b99598d1d515', '--expected-active', '51']
exec(compile(data,str(p),'exec'),{'__name__':'__main__','__file__':str(p)})
PY
