sudo -n python3 -B - <<'PY'
import hashlib, json, os, pathlib, stat
def ident(i): return (i.st_dev,i.st_ino,i.st_mode,i.st_uid,i.st_nlink,i.st_size,i.st_mtime_ns,i.st_ctime_ns)
user=pathlib.Path('/tmp/mir2-origin-r19-s15-20261007-01')
root=pathlib.Path('/srv/.mir2-origin-r19-s15-20261007-01')
files=[{'name': 'APPEND-INPUTS.prepared.json', 'size': 25182, 'sha256': '55dd34c86173db9df2554132e039f30f80d98abb5f470367a3adbd7138f38408'}, {'name': 'guards.py', 'size': 47951, 'sha256': '10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811'}, {'name': 'origin_r19_s15.py', 'size': 36329, 'sha256': '95c6b60ff94cbd72f6caf5fabf05ab275052e9a869fbdd20594418c430545710'}, {'name': 'PUBLICATION-PLAN.json', 'size': 15343, 'sha256': '852b474af0f9c7a5512b1ea1b3d9d2c957cc512dec95e366b8907052641c2356'}, {'name': 'ROOT-VERIFICATION.json', 'size': 424, 'sha256': '099702223680a43d63fb500740763e8b8f67442c6fcd414b6d5f178293d7d7a3'}, {'name': '00-latest.json', 'size': 1159, 'sha256': '11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c'}, {'name': '01-latest.p7s', 'size': 1614, 'sha256': '742d8403f6179697d58e5aa5b66c2b45ce4f485bdb573edbe0bf4b9212236ef5'}, {'name': '02-Mir2Setup.exe', 'size': 29245069, 'sha256': 'ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03'}, {'name': '03-BUILD-ATTESTATION.json', 'size': 1493, 'sha256': '48be8a769aa9ab3c0e8e730f12d481998ebad42a5abbc8202a5ee95299783dd6'}, {'name': '04-CONTROLS.txt', 'size': 10612, 'sha256': 'b9ad2a5a01b3ecbe673a3d38b1974b38492d3a62a0e28932eb8367ce19ebf7c6'}, {'name': '05-DELIVERY.json', 'size': 10560229, 'sha256': 'b7ba15b5478bff38a04b2678ccb52377e572ac0f7996b7af69403f1d137cf45a'}, {'name': '06-DELIVERY.p7s', 'size': 1614, 'sha256': '5d53e88d692f490a27a85404e68f3db1785673037565787cc96276897040e732'}, {'name': '07-KNOWN-ISSUES.md', 'size': 2152, 'sha256': 'd2a2ffca1d2170ee0a0f2e3d3fdf0eff644f2fe4472c5ba7e6120ce12c4eadc9'}, {'name': '08-MULTILINGUAL-SOURCES.json', 'size': 8618, 'sha256': '1528b614dedb07860e22ac2e1cf62528b0ed126230657dc008fb88d2f01f6d11'}, {'name': '09-NotoSansTC-OFL.txt', 'size': 4481, 'sha256': 'e35ffdebb2225b49814c31889cbb3ce69cb3509e6a9f431edaba5e1a6de8cd15'}, {'name': '10-OFL-NotoSans.txt', 'size': 4396, 'sha256': 'cee9892f9f0cc8fe882c9e9537ee6a89621d86ee7ceaf70b02e2b2b1c25c061a'}, {'name': '11-OFL-NotoSansArabic.txt', 'size': 4382, 'sha256': 'a7a5a25eb188bf1cd96982030d53e23c33485c69b1044a562254226857ee13af'}, {'name': '12-OFL-NotoSansDevanagari.txt', 'size': 4386, 'sha256': 'a216f6f8d85c7228093e0ee5e258d9d377e6671f68acb4db1930b29583d0f331'}, {'name': '13-OFL-NotoSansThai.txt', 'size': 4380, 'sha256': 'dad6e6abc2bf3fc37cc698af7607c3f4d4235039695713b222e5a034fb5b9b1c'}, {'name': '14-PACKAGE-MANIFEST.json', 'size': 31537753, 'sha256': '71277a8af15632a715d5e8d72ca95004fbee9a687ad4f963df8016e5368897ba'}, {'name': '15-README-START.txt', 'size': 49328, 'sha256': '720a139384723b1211d8b6efb1caa18d7d9062b1bca8a8f8e93f0f13de3f1551'}, {'name': '16-RELEASE-STATEMENT.json', 'size': 707, 'sha256': 'e614b21b5ffa3ce82dfaf8c39270f317a3defed0bf0c1c378b52637b03ac0b24'}, {'name': '17-RELEASE-STATEMENT.p7s', 'size': 1614, 'sha256': 'd8a9d7162e4c851fa66b7d86cc206621f514e7348da28e933b80139932bfd3b1'}, {'name': '18-VERSION.json', 'size': 1221, 'sha256': '66e60b50a181511acb7a9076c959d1d23c9d890d9e2fa6caa168e42ccbf52681'}, {'name': '19-0335ad7cdf9c3ff44fb3bee101e8f50fd839a4796be9a5fddbf7822fd680e7e0.m2b.gz', 'size': 60714170, 'sha256': '0335ad7cdf9c3ff44fb3bee101e8f50fd839a4796be9a5fddbf7822fd680e7e0'}, {'name': '20-252ff6897b3b3813badb123752b463af8e1c068a57cb6a11ffe9261a07b66d87.m2b.gz', 'size': 63807337, 'sha256': '252ff6897b3b3813badb123752b463af8e1c068a57cb6a11ffe9261a07b66d87'}, {'name': '21-3dee530c49de40dfad3afb3b7b83f0d9426fa0ac202202567f2c01f20ea21a38.m2b.gz', 'size': 46880754, 'sha256': '3dee530c49de40dfad3afb3b7b83f0d9426fa0ac202202567f2c01f20ea21a38'}, {'name': '22-53a489c9be927fbad4087d595567604c6cfa33a4960bb48eba646a631203974b.m2b.gz', 'size': 65601792, 'sha256': '53a489c9be927fbad4087d595567604c6cfa33a4960bb48eba646a631203974b'}, {'name': '23-565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2.m2b.gz', 'size': 66861961, 'sha256': '565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2'}, {'name': '24-5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd.m2b.gz', 'size': 12699131, 'sha256': '5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd'}, {'name': '25-6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4.m2b.gz', 'size': 60049219, 'sha256': '6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4'}, {'name': '26-6fb1307f7539f7454f9552ad2639f6e8ef3f75344c958b6ede94207641301a4e.m2b.gz', 'size': 65556826, 'sha256': '6fb1307f7539f7454f9552ad2639f6e8ef3f75344c958b6ede94207641301a4e'}, {'name': '27-74769fd0ba6af20b4c9f7a7b66a08890590772c5854d84466429d39b12b16722.m2b.gz', 'size': 55867713, 'sha256': '74769fd0ba6af20b4c9f7a7b66a08890590772c5854d84466429d39b12b16722'}, {'name': '28-84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7.m2b.gz', 'size': 66910012, 'sha256': '84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7'}, {'name': '29-a0ede1b679d255a2dcfe5c22269036e105b321a618b3c0f122fc2bbe468ced11.m2d.gz', 'size': 25543855, 'sha256': 'a0ede1b679d255a2dcfe5c22269036e105b321a618b3c0f122fc2bbe468ced11'}, {'name': '30-ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe.m2b.gz', 'size': 59737743, 'sha256': 'ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe'}, {'name': '31-c407ba4eaf8b686ef8ccdaf7d8a8e4d41a98df2c75b9270850940d0de3c5b60f.m2b.gz', 'size': 36299805, 'sha256': 'c407ba4eaf8b686ef8ccdaf7d8a8e4d41a98df2c75b9270850940d0de3c5b60f'}, {'name': '32-cb84a498f2e024905c52930a5c07018d168fe58279550ed5815536aabae63e4c.m2b.gz', 'size': 55134787, 'sha256': 'cb84a498f2e024905c52930a5c07018d168fe58279550ed5815536aabae63e4c'}, {'name': '33-e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9.m2b.gz', 'size': 60049370, 'sha256': 'e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9'}, {'name': '34-e83e50787df75d6e3d4a64aef7640e0d36b849e17aaae87568f8a1d526d6b25b.m2b.gz', 'size': 65610644, 'sha256': 'e83e50787df75d6e3d4a64aef7640e0d36b849e17aaae87568f8a1d526d6b25b'}, {'name': '35-mir2-client.toml', 'size': 231, 'sha256': '58a5a7cf2ed6e880a7a7f259243dd9ab96150fc43e1a346e6fc79b8de6ee3641'}, {'name': '36-mir2-platform-windows.exe', 'size': 111107072, 'sha256': '3abc0c7b74af234d797705ac9ce32a68abefac70bf43095093a353c81145f297'}, {'name': '37-ENGINE.json', 'size': 421, 'sha256': '82fed6853aed2ed3d8c8c7520b9d4b84aacd4ac2723c2e47506eb4d001cb99b0'}, {'name': '38-ENGINE.p7s', 'size': 1614, 'sha256': 'c19efee65316762e459ae48afc6123184e4c66defcb33f274fec046c66908a2b'}, {'name': '39-Mir2Updater.exe', 'size': 1952256, 'sha256': '9213ec3fe1a992f757ea48c53981afa661765b42e637c1ad811e326060b170b8'}]
assert os.geteuid()==0
info=user.lstat()
assert stat.S_ISDIR(info.st_mode) and info.st_uid==1000 and info.st_mode & 0o777 == 0o700, 'private-upload-stage-required'
r=root.lstat()
assert [r.st_dev,r.st_ino,r.st_mode,r.st_uid,r.st_mtime_ns,r.st_ctime_ns]==[64769, 2932579, 16832, 0, 1791332304441057540, 1791332304441057540], 'known-empty-failed-stage-identity-required'
assert stat.S_ISDIR(r.st_mode) and r.st_uid==0 and r.st_mode & 0o777==0o700 and list(root.iterdir())==[], 'known-empty-root-stage-required'
for p in [*reversed(root.parent.parents),root.parent]:
    i=p.lstat()
    assert stat.S_ISDIR(i.st_mode) and i.st_uid==0 and not i.st_mode & 0o022, 'root-parent-unsafe'

rootfd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
userfd=os.open(user,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
assert ident(os.fstat(userfd))==ident(info), 'user-dir-open-race'
assert ident(os.fstat(rootfd))==ident(r), 'root-dir-open-race'
assert set(os.listdir(userfd))=={p['name'] for p in files}, 'closed-input-set-required'
try:
    for pin in files:
        name=pin['name']
        assert pathlib.Path(name).name==name and name not in ('.','..')
        i=os.stat(name,dir_fd=userfd,follow_symlinks=False)
        assert stat.S_ISREG(i.st_mode) and i.st_uid==1000 and i.st_nlink==1 and not i.st_mode & 0o022
        source=os.open(name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=userfd)
        with os.fdopen(source,'rb') as stream:
            assert ident(os.fstat(stream.fileno()))==ident(i) and i.st_size==pin['size']
            data=stream.read(pin['size']+1)
            assert len(data)==pin['size'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'input-pin:'+name
            assert ident(os.fstat(stream.fileno()))==ident(i) and ident(os.stat(name,dir_fd=userfd,follow_symlinks=False))==ident(i)
        dest=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=rootfd)
        with os.fdopen(dest,'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        assert os.stat(name,dir_fd=rootfd,follow_symlinks=False).st_uid==0
    assert ident(user.lstat())==ident(info) and ident(os.fstat(userfd))==ident(info), 'user-stage-changed'
    os.fsync(rootfd)
    parentfd=os.open(root.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try: os.fsync(parentfd)
    finally: os.close(parentfd)
finally:
    os.close(rootfd)
    os.close(userfd)
print(json.dumps({'schema':'mir2.origin.fixed6-sealed-inputs.v1','passed':True,'files':files,'publicMutations':False}))
PY
