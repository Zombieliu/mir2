"""Root's fixed six-file append; no general deployment or credentials."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

PINS = {'prepared': '55dd34c86173db9df2554132e039f30f80d98abb5f470367a3adbd7138f38408', 'guards': '10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811', 'proof': '099702223680a43d63fb500740763e8b8f67442c6fcd414b6d5f178293d7d7a3', 'publication': '852b474af0f9c7a5512b1ea1b3d9d2c957cc512dec95e366b8907052641c2356', 'config': '4f54f9ca961771de96efff9b24d983815cfbbf5c69369bed9da5e9c61dec4632', 'feed14': {'latest.json': {'size': 1159, 'sha256': 'b5b29a4992c6cf6f276d35e2fba28a2a6b5aa640a0156e3474b81bb14a04f454'}, 'latest.p7s': {'size': 1614, 'sha256': '8e4c9e0800ea4724d05f600552df4cb62275097e88fba833ba1e09cfd9fe288b'}}, 'new': [{'path': 'feeds/s15-11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c/latest.json', 'size': 1159, 'sha256': '11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c', 'index': 0, 'r2Key': 'mir2/native/windows-invited/feeds/s15-11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c/latest.json', 'originRelativePath': 'feeds/s15-11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c/latest.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'feeds/s15-11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c/latest.p7s', 'size': 1614, 'sha256': '742d8403f6179697d58e5aa5b66c2b45ce4f485bdb573edbe0bf4b9212236ef5', 'index': 1, 'r2Key': 'mir2/native/windows-invited/feeds/s15-11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c/latest.p7s', 'originRelativePath': 'feeds/s15-11a2c8eaaa5f18e654d185223312b18d1c5c32412f844aec64bb341df1c5009c/latest.p7s', 'contentType': 'application/pkcs7-signature', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'installers/ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03/Mir2Setup.exe', 'size': 29245069, 'sha256': 'ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03', 'index': 2, 'r2Key': 'mir2/native/windows-invited/installers/ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03/Mir2Setup.exe', 'originRelativePath': 'installers/ea1e4b3cbccd9a79cf042d9e0d1d08bcd4e016006df0e3d9f021c9c034d46e03/Mir2Setup.exe', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/BUILD-ATTESTATION.json', 'size': 1493, 'sha256': '48be8a769aa9ab3c0e8e730f12d481998ebad42a5abbc8202a5ee95299783dd6', 'index': 3, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/BUILD-ATTESTATION.json', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/BUILD-ATTESTATION.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/CONTROLS.txt', 'size': 10612, 'sha256': 'b9ad2a5a01b3ecbe673a3d38b1974b38492d3a62a0e28932eb8367ce19ebf7c6', 'index': 4, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/CONTROLS.txt', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/CONTROLS.txt', 'contentType': 'text/plain; charset=utf-8', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.json', 'size': 10560229, 'sha256': 'b7ba15b5478bff38a04b2678ccb52377e572ac0f7996b7af69403f1d137cf45a', 'index': 5, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.json', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.p7s', 'size': 1614, 'sha256': '5d53e88d692f490a27a85404e68f3db1785673037565787cc96276897040e732', 'index': 6, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.p7s', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/DELIVERY.p7s', 'contentType': 'application/pkcs7-signature', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/KNOWN-ISSUES.md', 'size': 2152, 'sha256': 'd2a2ffca1d2170ee0a0f2e3d3fdf0eff644f2fe4472c5ba7e6120ce12c4eadc9', 'index': 7, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/KNOWN-ISSUES.md', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/KNOWN-ISSUES.md', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/MULTILINGUAL-SOURCES.json', 'size': 8618, 'sha256': '1528b614dedb07860e22ac2e1cf62528b0ed126230657dc008fb88d2f01f6d11', 'index': 8, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/MULTILINGUAL-SOURCES.json', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/MULTILINGUAL-SOURCES.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/NotoSansTC-OFL.txt', 'size': 4481, 'sha256': 'e35ffdebb2225b49814c31889cbb3ce69cb3509e6a9f431edaba5e1a6de8cd15', 'index': 9, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/NotoSansTC-OFL.txt', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/NotoSansTC-OFL.txt', 'contentType': 'text/plain; charset=utf-8', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSans.txt', 'size': 4396, 'sha256': 'cee9892f9f0cc8fe882c9e9537ee6a89621d86ee7ceaf70b02e2b2b1c25c061a', 'index': 10, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSans.txt', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSans.txt', 'contentType': 'text/plain; charset=utf-8', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansArabic.txt', 'size': 4382, 'sha256': 'a7a5a25eb188bf1cd96982030d53e23c33485c69b1044a562254226857ee13af', 'index': 11, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansArabic.txt', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansArabic.txt', 'contentType': 'text/plain; charset=utf-8', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansDevanagari.txt', 'size': 4386, 'sha256': 'a216f6f8d85c7228093e0ee5e258d9d377e6671f68acb4db1930b29583d0f331', 'index': 12, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansDevanagari.txt', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansDevanagari.txt', 'contentType': 'text/plain; charset=utf-8', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansThai.txt', 'size': 4380, 'sha256': 'dad6e6abc2bf3fc37cc698af7607c3f4d4235039695713b222e5a034fb5b9b1c', 'index': 13, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansThai.txt', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/OFL-NotoSansThai.txt', 'contentType': 'text/plain; charset=utf-8', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/PACKAGE-MANIFEST.json', 'size': 31537753, 'sha256': '71277a8af15632a715d5e8d72ca95004fbee9a687ad4f963df8016e5368897ba', 'index': 14, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/PACKAGE-MANIFEST.json', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/PACKAGE-MANIFEST.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/README-START.txt', 'size': 49328, 'sha256': '720a139384723b1211d8b6efb1caa18d7d9062b1bca8a8f8e93f0f13de3f1551', 'index': 15, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/README-START.txt', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/README-START.txt', 'contentType': 'text/plain; charset=utf-8', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.json', 'size': 707, 'sha256': 'e614b21b5ffa3ce82dfaf8c39270f317a3defed0bf0c1c378b52637b03ac0b24', 'index': 16, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.json', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.p7s', 'size': 1614, 'sha256': 'd8a9d7162e4c851fa66b7d86cc206621f514e7348da28e933b80139932bfd3b1', 'index': 17, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.p7s', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/RELEASE-STATEMENT.p7s', 'contentType': 'application/pkcs7-signature', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/VERSION.json', 'size': 1221, 'sha256': '66e60b50a181511acb7a9076c959d1d23c9d890d9e2fa6caa168e42ccbf52681', 'index': 18, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/VERSION.json', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/VERSION.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/0335ad7cdf9c3ff44fb3bee101e8f50fd839a4796be9a5fddbf7822fd680e7e0.m2b.gz', 'size': 60714170, 'sha256': '0335ad7cdf9c3ff44fb3bee101e8f50fd839a4796be9a5fddbf7822fd680e7e0', 'index': 19, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/0335ad7cdf9c3ff44fb3bee101e8f50fd839a4796be9a5fddbf7822fd680e7e0.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/0335ad7cdf9c3ff44fb3bee101e8f50fd839a4796be9a5fddbf7822fd680e7e0.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/252ff6897b3b3813badb123752b463af8e1c068a57cb6a11ffe9261a07b66d87.m2b.gz', 'size': 63807337, 'sha256': '252ff6897b3b3813badb123752b463af8e1c068a57cb6a11ffe9261a07b66d87', 'index': 20, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/252ff6897b3b3813badb123752b463af8e1c068a57cb6a11ffe9261a07b66d87.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/252ff6897b3b3813badb123752b463af8e1c068a57cb6a11ffe9261a07b66d87.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/3dee530c49de40dfad3afb3b7b83f0d9426fa0ac202202567f2c01f20ea21a38.m2b.gz', 'size': 46880754, 'sha256': '3dee530c49de40dfad3afb3b7b83f0d9426fa0ac202202567f2c01f20ea21a38', 'index': 21, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/3dee530c49de40dfad3afb3b7b83f0d9426fa0ac202202567f2c01f20ea21a38.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/3dee530c49de40dfad3afb3b7b83f0d9426fa0ac202202567f2c01f20ea21a38.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/53a489c9be927fbad4087d595567604c6cfa33a4960bb48eba646a631203974b.m2b.gz', 'size': 65601792, 'sha256': '53a489c9be927fbad4087d595567604c6cfa33a4960bb48eba646a631203974b', 'index': 22, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/53a489c9be927fbad4087d595567604c6cfa33a4960bb48eba646a631203974b.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/53a489c9be927fbad4087d595567604c6cfa33a4960bb48eba646a631203974b.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2.m2b.gz', 'size': 66861961, 'sha256': '565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2', 'index': 23, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd.m2b.gz', 'size': 12699131, 'sha256': '5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd', 'index': 24, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4.m2b.gz', 'size': 60049219, 'sha256': '6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4', 'index': 25, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/6fb1307f7539f7454f9552ad2639f6e8ef3f75344c958b6ede94207641301a4e.m2b.gz', 'size': 65556826, 'sha256': '6fb1307f7539f7454f9552ad2639f6e8ef3f75344c958b6ede94207641301a4e', 'index': 26, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/6fb1307f7539f7454f9552ad2639f6e8ef3f75344c958b6ede94207641301a4e.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/6fb1307f7539f7454f9552ad2639f6e8ef3f75344c958b6ede94207641301a4e.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/74769fd0ba6af20b4c9f7a7b66a08890590772c5854d84466429d39b12b16722.m2b.gz', 'size': 55867713, 'sha256': '74769fd0ba6af20b4c9f7a7b66a08890590772c5854d84466429d39b12b16722', 'index': 27, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/74769fd0ba6af20b4c9f7a7b66a08890590772c5854d84466429d39b12b16722.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/74769fd0ba6af20b4c9f7a7b66a08890590772c5854d84466429d39b12b16722.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7.m2b.gz', 'size': 66910012, 'sha256': '84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7', 'index': 28, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/a0ede1b679d255a2dcfe5c22269036e105b321a618b3c0f122fc2bbe468ced11.m2d.gz', 'size': 25543855, 'sha256': 'a0ede1b679d255a2dcfe5c22269036e105b321a618b3c0f122fc2bbe468ced11', 'index': 29, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/a0ede1b679d255a2dcfe5c22269036e105b321a618b3c0f122fc2bbe468ced11.m2d.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/a0ede1b679d255a2dcfe5c22269036e105b321a618b3c0f122fc2bbe468ced11.m2d.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe.m2b.gz', 'size': 59737743, 'sha256': 'ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe', 'index': 30, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/c407ba4eaf8b686ef8ccdaf7d8a8e4d41a98df2c75b9270850940d0de3c5b60f.m2b.gz', 'size': 36299805, 'sha256': 'c407ba4eaf8b686ef8ccdaf7d8a8e4d41a98df2c75b9270850940d0de3c5b60f', 'index': 31, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/c407ba4eaf8b686ef8ccdaf7d8a8e4d41a98df2c75b9270850940d0de3c5b60f.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/c407ba4eaf8b686ef8ccdaf7d8a8e4d41a98df2c75b9270850940d0de3c5b60f.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/cb84a498f2e024905c52930a5c07018d168fe58279550ed5815536aabae63e4c.m2b.gz', 'size': 55134787, 'sha256': 'cb84a498f2e024905c52930a5c07018d168fe58279550ed5815536aabae63e4c', 'index': 32, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/cb84a498f2e024905c52930a5c07018d168fe58279550ed5815536aabae63e4c.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/cb84a498f2e024905c52930a5c07018d168fe58279550ed5815536aabae63e4c.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9.m2b.gz', 'size': 60049370, 'sha256': 'e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9', 'index': 33, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/e83e50787df75d6e3d4a64aef7640e0d36b849e17aaae87568f8a1d526d6b25b.m2b.gz', 'size': 65610644, 'sha256': 'e83e50787df75d6e3d4a64aef7640e0d36b849e17aaae87568f8a1d526d6b25b', 'index': 34, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/delivery/e83e50787df75d6e3d4a64aef7640e0d36b849e17aaae87568f8a1d526d6b25b.m2b.gz', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/delivery/e83e50787df75d6e3d4a64aef7640e0d36b849e17aaae87568f8a1d526d6b25b.m2b.gz', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/mir2-client.toml', 'size': 231, 'sha256': '58a5a7cf2ed6e880a7a7f259243dd9ab96150fc43e1a346e6fc79b8de6ee3641', 'index': 35, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/mir2-client.toml', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/mir2-client.toml', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/game-WN-CANDIDATE-20261007-invited-19/mir2-platform-windows.exe', 'size': 111107072, 'sha256': '3abc0c7b74af234d797705ac9ce32a68abefac70bf43095093a353c81145f297', 'index': 36, 'r2Key': 'mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261007-invited-19/mir2-platform-windows.exe', 'originRelativePath': 'releases/game-WN-CANDIDATE-20261007-invited-19/mir2-platform-windows.exe', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/updater-9213EC3FE1A992F7-s15/ENGINE.json', 'size': 421, 'sha256': '82fed6853aed2ed3d8c8c7520b9d4b84aacd4ac2723c2e47506eb4d001cb99b0', 'index': 37, 'r2Key': 'mir2/native/windows-invited/releases/updater-9213EC3FE1A992F7-s15/ENGINE.json', 'originRelativePath': 'releases/updater-9213EC3FE1A992F7-s15/ENGINE.json', 'contentType': 'application/json', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/updater-9213EC3FE1A992F7-s15/ENGINE.p7s', 'size': 1614, 'sha256': 'c19efee65316762e459ae48afc6123184e4c66defcb33f274fec046c66908a2b', 'index': 38, 'r2Key': 'mir2/native/windows-invited/releases/updater-9213EC3FE1A992F7-s15/ENGINE.p7s', 'originRelativePath': 'releases/updater-9213EC3FE1A992F7-s15/ENGINE.p7s', 'contentType': 'application/pkcs7-signature', 'cacheControl': 'public, max-age=31536000, immutable'}, {'path': 'releases/updater-9213EC3FE1A992F7-s15/Mir2Updater.exe', 'size': 1952256, 'sha256': '9213ec3fe1a992f757ea48c53981afa661765b42e637c1ad811e326060b170b8', 'index': 39, 'r2Key': 'mir2/native/windows-invited/releases/updater-9213EC3FE1A992F7-s15/Mir2Updater.exe', 'originRelativePath': 'releases/updater-9213EC3FE1A992F7-s15/Mir2Updater.exe', 'contentType': 'application/octet-stream', 'cacheControl': 'public, max-age=31536000, immutable'}], 'sourceNames': {0: '00-latest.json', 1: '01-latest.p7s', 2: '02-Mir2Setup.exe', 3: '03-BUILD-ATTESTATION.json', 4: '04-CONTROLS.txt', 5: '05-DELIVERY.json', 6: '06-DELIVERY.p7s', 7: '07-KNOWN-ISSUES.md', 8: '08-MULTILINGUAL-SOURCES.json', 9: '09-NotoSansTC-OFL.txt', 10: '10-OFL-NotoSans.txt', 11: '11-OFL-NotoSansArabic.txt', 12: '12-OFL-NotoSansDevanagari.txt', 13: '13-OFL-NotoSansThai.txt', 14: '14-PACKAGE-MANIFEST.json', 15: '15-README-START.txt', 16: '16-RELEASE-STATEMENT.json', 17: '17-RELEASE-STATEMENT.p7s', 18: '18-VERSION.json', 19: '19-0335ad7cdf9c3ff44fb3bee101e8f50fd839a4796be9a5fddbf7822fd680e7e0.m2b.gz', 20: '20-252ff6897b3b3813badb123752b463af8e1c068a57cb6a11ffe9261a07b66d87.m2b.gz', 21: '21-3dee530c49de40dfad3afb3b7b83f0d9426fa0ac202202567f2c01f20ea21a38.m2b.gz', 22: '22-53a489c9be927fbad4087d595567604c6cfa33a4960bb48eba646a631203974b.m2b.gz', 23: '23-565af7b642a235bec7518966243b586bf4668fa93f730e96f747c9400690d2e2.m2b.gz', 24: '24-5efcf2a7a6e22850479f2a007e2565515ae277830e5f61eadc6899e8676128cd.m2b.gz', 25: '25-6634d75a99bbb0d3486917599b048d07ade067aa7cfc9a980bb09033a513e4c4.m2b.gz', 26: '26-6fb1307f7539f7454f9552ad2639f6e8ef3f75344c958b6ede94207641301a4e.m2b.gz', 27: '27-74769fd0ba6af20b4c9f7a7b66a08890590772c5854d84466429d39b12b16722.m2b.gz', 28: '28-84ff6726ef8065d8b18e9ce6a796fb22782be8df1f36a65305fd4ae594d782e7.m2b.gz', 29: '29-a0ede1b679d255a2dcfe5c22269036e105b321a618b3c0f122fc2bbe468ced11.m2d.gz', 30: '30-ba1d18a6fc2ae0e87f4b41ccf730a87e2e4d5f31188957ce348a376b36d08fbe.m2b.gz', 31: '31-c407ba4eaf8b686ef8ccdaf7d8a8e4d41a98df2c75b9270850940d0de3c5b60f.m2b.gz', 32: '32-cb84a498f2e024905c52930a5c07018d168fe58279550ed5815536aabae63e4c.m2b.gz', 33: '33-e14bb6681791c37ac1ddb771841db1756b7e9df00df46d240e529cdbb087ceb9.m2b.gz', 34: '34-e83e50787df75d6e3d4a64aef7640e0d36b849e17aaae87568f8a1d526d6b25b.m2b.gz', 35: '35-mir2-client.toml', 36: '36-mir2-platform-windows.exe', 37: '37-ENGINE.json', 38: '38-ENGINE.p7s', 39: '39-Mir2Updater.exe'}}
STAGE = Path('/srv/.mir2-origin-r19-s15-20261007-01')
PUBLIC = Path('/srv/mir2-client-updates')
LOCK = Path('/var/backups/mir2-client-updates/.publisher.lock')
CONFIG = Path('/etc/caddy/Caddyfile')
GAME = '2b04e82c4f42b22f895f5f95b5bd79a8147eacdf'
ENGINE = 'b4390ee4c987bbf000ba1d95761151e39fc0d54f'
OLD_MATCH = b'@mir2_native_payload path /client-updates/releases/*'
NEW_MATCH = OLD_MATCH + b' /client-updates/feeds/* /client-updates/installers/*'

def require(value, label):
    if not value:
        raise RuntimeError(label)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def fingerprint(info):
    return (info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)

def boot():
    require(sys.platform.startswith('linux') and os.geteuid()==0, 'linux-root-required')
    require(Path(__file__).resolve().parent == STAGE, 'fixed-root-stage-required')
    for parent in [*reversed(STAGE.parents),STAGE]:
        info=parent.lstat()
        require(stat.S_ISDIR(info.st_mode) and info.st_uid==0 and not info.st_mode & 0o022, 'unsafe-root-stage-parent')
    require(not STAGE.stat().st_mode & 0o077, 'root-stage-not-private')
    path=STAGE/'guards.py'
    before=path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_uid==0 and before.st_nlink==1 and not before.st_mode & 0o077, 'unsafe-guard-file')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    with os.fdopen(fd,'rb') as stream:
        require(fingerprint(os.fstat(stream.fileno()))==fingerprint(before), 'guard-open-race')
        raw=stream.read(131073)
        require(len(raw)<=131072 and digest(raw)==PINS['guards'], 'guard-source-mismatch')
        require(fingerprint(os.fstat(stream.fileno()))==fingerprint(before) and fingerprint(path.lstat())==fingerprint(before), 'guard-read-race')
    spec=importlib.util.spec_from_file_location('origin_exact_guards',path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    # Execute exactly the bytes just verified, with no second pathname read.
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module.Guard(),module.Operations()

def write_new(g,ops,path,data,mode=0o600):
    g.parents(path)
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
        os.fchmod(stream.fileno(),mode)
        os.fsync(stream.fileno())
    g.file_info(path)
    ops.sync_dir(g,path.parent)

def snapshot_services():
    names=['caddy.service','mir2-gateway.service','mir2-playtest.service','mir2-periodic-qa.service',
           'mir2-commonware-gateway.service','mir2-admin-api.service','mir2-zone-ucloud.service']
    listeners=subprocess.run(['ss','-Hlntp'],capture_output=True,text=True,check=True).stdout.splitlines()
    connections=subprocess.run(['ss','-Hntp','state','established'],capture_output=True,text=True,check=True).stdout.splitlines()
    states={}
    for name in names:
        result=subprocess.run(['systemctl','show',name,'--property=MainPID,ActiveState'],capture_output=True,text=True,check=True)
        state=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
        pid=state['MainPID']
        ports={line.split()[3].rsplit(':',1)[-1] for line in listeners if 'pid='+pid+',' in line}
        state['incoming']=sum(1 for line in connections if 'pid='+pid+',' in line and line.split()[2].rsplit(':',1)[-1] in ports)
        states[name]=state
    return states

def same_pids(before,after):
    require(all(before[n]['MainPID']==after[n]['MainPID'] and before[n]['ActiveState']==after[n]['ActiveState'] for n in before),'service-pid-or-state-changed')

def stable_feed(g):
    identities={}
    for name,pin in PINS['feed14'].items():
        path=PUBLIC/'feed-current'/name
        raw=g.read(path,32768,pin)
        identities[name]=g.identity(g.file_info(path))
        if name=='latest.json':
            value=json.loads(raw)
            require(value['sequence']==14 and value['game']['directory']=='releases/game-WN-CANDIDATE-20261004-invited-17','feed14-game-binding')
            require(value['expiresUnix']>=int(time.time()),'feed14-expired')
    return identities

def fixed_envelope(g):
    names={'ROOT-VERIFICATION.json':'proof','PUBLICATION-PLAN.json':'publication','APPEND-INPUTS.prepared.json':'prepared'}
    values={}
    for name,key in names.items():
        raw=g.read(STAGE/name,32*1024*1024)
        require(digest(raw)==PINS[key],'envelope-hash:'+name)
        values[name]=json.loads(raw)
    proof=values['ROOT-VERIFICATION.json']
    require(proof['passed'] is True and proof['cmsVerified'] is True and proof['candidateVerified'] is True and proof['sequence']==15 and proof['sourceRevision']==ENGINE,'genuine-root-proof-binding')
    publication=values['PUBLICATION-PLAN.json']
    objects=publication['objects']
    require(len(objects)==40 and len({o['path'] for o in objects})==40,'closed40-required')
    closure=sorted([{k:o[k] for k in ('path','size','sha256')} for o in objects],key=lambda o:o['path'])
    canonical=(json.dumps(closure,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
    require(digest(canonical)==proof['objectsSha256'],'closed40-proof-digest')
    selected={o['path']:o for o in objects}
    for obj in PINS['new']:
        bound=selected[obj['path']]
        require(all(bound[k]==obj[k] for k in ('size','sha256')),'fixed40-proof-mismatch')
    require(values['APPEND-INPUTS.prepared.json']['gameSource']==GAME,'game-source-binding')
    feed=g.read(STAGE/'00-latest.json',32768,PINS['new'][0])
    value=json.loads(feed)
    require(value['sequence']==15 and value['expiresUnix']>=int(time.time()),'feed15-expired-or-mismatch')
    return objects

def ensure_parent(g,ops,path):
    require(path.is_relative_to(PUBLIC) and '..' not in path.parts,'target-escape')
    relative=path.relative_to(PUBLIC)
    current=PUBLIC
    for part in relative.parts:
        require(re.fullmatch(r'[A-Za-z0-9_.-]+',part) and part not in ('.','..'),'target-component')
        current=current/part
        if not current.exists() and not current.is_symlink():
            g.directory(current.parent)
            try:
                os.mkdir(current,0o755)
                ops.sync_dir(g,current.parent)
            except FileExistsError:
                pass
        g.directory(current)

def check_target(g,obj):
    target=PUBLIC/obj['path']
    require(target.is_relative_to(PUBLIC) and '..' not in Path(obj['path']).parts and not Path(obj['path']).is_absolute(),'target-escape')
    # Every existing ancestor is checked even for an absent leaf.
    current=PUBLIC
    g.directory(current)
    for part in Path(obj['path']).parts[:-1]:
        current=current/part
        if current.exists() or current.is_symlink():
            g.directory(current)
        else:
            break
    if target.exists() or target.is_symlink():
        g.match(target,obj)
        require(stat.S_IMODE(g.file_info(target).st_mode)==0o444,'new-target-not-public-immutable')
        return 'exact-existing'
    return 'absent'

def append(g,ops,objects,feed_before):
    new_names={o['path'] for o in PINS['new']}
    baseline={o['path']:g.match(PUBLIC/o['path'],o) for o in objects if o['path'] not in new_names}
    require(not baseline,'all40-selected-required')
    for obj in PINS['new']:
        source=STAGE/(PINS['sourceNames'][obj['index']])
        g.match(source,obj)
        check_target(g,obj)
    require(stable_feed(g)==feed_before,'feed-changed-before-append')
    events=[]
    by_index={o['index']:o for o in PINS['new']}
    for index in reversed(range(40)):
        obj=by_index[index]
        status=check_target(g,obj)
        if status=='absent':
            ensure_parent(g,ops,(PUBLIC/obj['path']).parent)
            original=STAGE/(PINS['sourceNames'][index])
            staged=STAGE/f'append-{index:02}'
            if staged.exists() or staged.is_symlink():
                g.match(staged,obj)
                require(stat.S_IMODE(g.file_info(staged).st_mode)==0o444,'staged-mode-conflict')
            else:
                data=g.read(original,128*1024*1024,obj)
                write_new(g,ops,staged,data,0o444)
            g.match(staged,obj)
            require(stable_feed(g)==feed_before,'feed-changed-during-append')
            try:
                ops.rename_new(g,staged,PUBLIC/obj['path'])
                status='created'
            except FileExistsError:
                check_target(g,obj)
                status='raced-exact-existing'
        check_target(g,obj)
        require(stable_feed(g)==feed_before,'feed-changed-after-append')
        event={'index':index,'path':obj['path'],'status':status,'size':obj['size'],'sha256':obj['sha256']}
        audit=STAGE/f'APPEND-EVENT-{index:02}.json'
        if audit.exists() or audit.is_symlink():
            previous=json.loads(g.read(audit,32768))
            require(all(previous[k]==event[k] for k in ('index','path','size','sha256')) and previous['status'] in ('created','exact-existing','raced-exact-existing'),'append-audit-conflict')
        else:
            write_new(g,ops,audit,(json.dumps(event,sort_keys=True)+'\n').encode())
        events.append(event)
    for obj in objects:
        identity=g.match(PUBLIC/obj['path'],obj)
        if obj['path'] in baseline:
            require(identity==baseline[obj['path']],'original30-fingerprint-changed')
    return events

def main():
    require(len(sys.argv)==2 and sys.argv[1] in ('preflight','append'),'fixed-operation-required')
    mode=sys.argv[1]
    g,ops=boot()
    g.directory(PUBLIC)
    g.directory(STAGE,private=True)
    require(STAGE.stat().st_dev==PUBLIC.stat().st_dev,'stage-filesystem-mismatch')
    states=snapshot_services()
    with ops.lock(g,LOCK):
        feed_before=stable_feed(g)
        objects=fixed_envelope(g)
        result={'schema':'mir2.origin-r19-s15.fixed40.v1','operation':mode,'gameSource':GAME,'engineSource':ENGINE,'rootProofSha256':PINS['proof'],'createdUnix':int(time.time()),'changedCurrentFeed':False,'gameServiceRestart':False}
        if mode=='append':
            result['events']=append(g,ops,objects,feed_before)
        else:
            selected={o['path'] for o in PINS['new']}
            result['objects']=[{'path':o['path'],'status':check_target(g,o) if o['path'] in selected else 'original-exact','identity':None if o['path'] in selected else g.match(PUBLIC/o['path'],o)} for o in objects]
            for obj in PINS['new']:
                name=PINS['sourceNames'][obj['index']]
                g.match(STAGE/name,obj)
            require(digest(g.read(CONFIG,128*1024))==PINS['config'],'caddy-preflight-conflict')
        require(stable_feed(g)==feed_before,'feed-final-conflict')
        same_pids(states,snapshot_services())
        result.update(passed=True,feed14FingerprintPreserved=True,allServicePidsPreserved=True)
        raw=(json.dumps(result,indent=2)+'\n').encode()
        write_new(g,ops,STAGE/f'{mode.upper()}-01.json',raw)
        print(raw.decode(),end='')

if __name__=='__main__':
    main()
