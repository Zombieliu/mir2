python3 -B - <<'PY'
import json, os, pathlib, stat
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-2b04e82c4f42b22f895f5f95b5bd79a8147eacdf')
assert os.geteuid()==1000
assert p.parent.resolve(strict=True)==p.parent
i=p.parent.lstat()
assert stat.S_ISDIR(i.st_mode) and i.st_uid==1000 and not i.st_mode & 0o022
assert not p.exists() and not p.is_symlink()
p.mkdir(mode=0o700)
print(json.dumps({'passed':True,'preparedPrivateSource':str(p),'publicMutations':False}))
PY
