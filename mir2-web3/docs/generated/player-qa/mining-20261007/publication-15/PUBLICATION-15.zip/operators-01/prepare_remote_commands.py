import hashlib
import json
from pathlib import Path

out=Path(__file__).resolve().parent
files=json.loads((out/'SEAL-INPUTS-01.json').read_text())
user='/tmp/mir2-origin-r19-s15-20261007-01'
root='/srv/.mir2-origin-r19-s15-20261007-01'
create=f'''python3 - <<'PY'
import json, os, pathlib, stat
path=pathlib.Path({user!r})
assert not path.exists() and not path.is_symlink(), 'fresh-stage-required'
assert stat.S_ISDIR(path.parent.lstat().st_mode), 'tmp-type'
path.mkdir(mode=0o700)
assert path.lstat().st_uid == os.geteuid() and path.lstat().st_mode & 0o777 == 0o700
print(json.dumps({{'schema':'mir2.private-upload-stage.v1','created':True,'path':str(path)}}))
PY
'''
(out/'CREATE-STAGE-01.command').write_text(create,encoding='utf-8',newline='\n')
seal=f'''sudo -n python3 -B - <<'PY'
import hashlib, json, os, pathlib, stat
def ident(i): return (i.st_dev,i.st_ino,i.st_mode,i.st_uid,i.st_nlink,i.st_size,i.st_mtime_ns,i.st_ctime_ns)
user=pathlib.Path({user!r})
root=pathlib.Path({root!r})
files={files!r}
assert os.geteuid()==0
info=user.lstat()
assert stat.S_ISDIR(info.st_mode) and info.st_uid==1000 and info.st_mode & 0o777 == 0o700, 'private-upload-stage-required'
assert not root.exists() and not root.is_symlink(), 'fresh-root-stage-required'
for p in [*reversed(root.parent.parents),root.parent]:
    i=p.lstat()
    assert stat.S_ISDIR(i.st_mode) and i.st_uid==0 and not i.st_mode & 0o022, 'root-parent-unsafe'
root.mkdir(mode=0o700)
rootfd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
userfd=os.open(user,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
assert ident(os.fstat(userfd))==ident(info), 'user-dir-open-race'
try:
    for pin in files:
        name=pin['name']
        assert pathlib.Path(name).name==name and name not in ('.','..')
        i=os.stat(name,dir_fd=userfd,follow_symlinks=False)
        assert stat.S_ISREG(i.st_mode) and i.st_uid==1000 and i.st_nlink==1 and not i.st_mode & 0o022
        source=os.open(name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=userfd)
        with os.fdopen(source,'rb') as stream:
            assert ident(os.fstat(stream.fileno()))==ident(i) and i.st_size==pin['size']
            data=stream.read(pin['size']+1)
            assert len(data)==pin['size'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'input-pin:'+name
            assert ident(os.fstat(stream.fileno()))==ident(i) and ident(os.stat(name,dir_fd=userfd,follow_symlinks=False))==ident(i)
        dest=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=rootfd)
        with os.fdopen(dest,'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        assert os.stat(name,dir_fd=rootfd,follow_symlinks=False).st_uid==0
    assert ident(user.lstat())==ident(info) and ident(os.fstat(userfd))==ident(info), 'user-stage-changed'
    os.fsync(rootfd)
    parentfd=os.open(root.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try: os.fsync(parentfd)
    finally: os.close(parentfd)
finally:
    os.close(rootfd)
    os.close(userfd)
print(json.dumps({{'schema':'mir2.origin.fixed6-sealed-inputs.v1','passed':True,'files':files,'publicMutations':False}}))
PY
'''
(out/'SEAL-STAGE-01.command').write_text(seal,encoding='utf-8',newline='\n')
for mode in ('preflight','append'):
    (out/f'{mode.upper()}-01.command').write_text(f'sudo -n python3 -B {root}/origin_r19_s15.py {mode}\n',encoding='utf-8',newline='\n')
(out/'NEGATIVE-CHECKS-01.command').write_text(f'sudo -n python3 -B {root}/origin_negative_checks.py\n',encoding='utf-8',newline='\n')
print(json.dumps({'preparedCommands':5,'uploadedFiles':len(files),'cloudMutations':False}))
