python3 - <<'PY'
import json, os, pathlib, stat
path=pathlib.Path('/tmp/mir2-origin-r19-s15-20261007-01')
assert not path.exists() and not path.is_symlink(), 'fresh-stage-required'
assert stat.S_ISDIR(path.parent.lstat().st_mode), 'tmp-type'
path.mkdir(mode=0o700)
assert path.lstat().st_uid == os.geteuid() and path.lstat().st_mode & 0o777 == 0o700
print(json.dumps({'schema':'mir2.private-upload-stage.v1','created':True,'path':str(path)}))
PY
