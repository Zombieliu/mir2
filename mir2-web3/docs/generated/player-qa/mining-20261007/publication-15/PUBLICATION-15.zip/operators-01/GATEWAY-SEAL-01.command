sudo -n python3 -B - <<'PY'
import hashlib, json, os, pathlib, stat
def ident(i):return(i.st_dev,i.st_ino,i.st_mode,i.st_uid,i.st_nlink,i.st_size,i.st_mtime_ns,i.st_ctime_ns)
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-2b04e82c4f42b22f895f5f95b5bd79a8147eacdf')
r=pathlib.Path('/srv/.mir2-gateway-r19-20261007-01')
rows=[{'name': 'mir2-gateway', 'size': 80656512, 'sha256': '1c2eab2da38f31c7a96c308fff80c00fccfe6b1edb6602878c2b5c8845c44d83'}, {'name': 'RELEASE.json', 'size': 1538, 'sha256': 'ba1e8f72119a9a5d3d1872a985f4e531f81fd538d2a1c2c883c9dbead4b5abbe'}, {'name': 'VERIFIED-FILES.json', 'size': 412, 'sha256': '833c76390bcc7752a7f8b8fb2b6fcd3e5fe5d5acadcb8911b272b99598d1d515'}, {'name': 'upgrade-r19-gateway-01.py', 'size': 30745, 'sha256': '7de335743dfcafe8717d566e3bf4193096a4dd77e954be7031f68fa91f1251c7'}]
assert os.geteuid()==0
i=p.lstat()
assert stat.S_ISDIR(i.st_mode) and i.st_uid==1000 and i.st_mode & 0o777==0o700 and p.resolve(strict=True)==p
fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
assert ident(os.fstat(fd))==ident(i) and set(os.listdir(fd))=={v['name'] for v in rows}
contents={}
try:
    for row in rows:
        old=os.stat(row['name'],dir_fd=fd,follow_symlinks=False)
        assert stat.S_ISREG(old.st_mode) and old.st_uid==1000 and old.st_nlink==1 and old.st_size==row['size'] and old.st_mode & 0o777==0o664
        f=os.open(row['name'],os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
        with os.fdopen(f,'rb') as h:
            assert ident(os.fstat(h.fileno()))==ident(old)
            data=h.read(row['size']+1)
            assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
            assert ident(os.fstat(h.fileno()))==ident(old) and ident(os.stat(row['name'],dir_fd=fd,follow_symlinks=False))==ident(old)
            os.fchmod(h.fileno(),0o600)
            new=os.fstat(h.fileno())
            assert new.st_uid==1000 and new.st_mode & 0o777==0o600 and new.st_nlink==1 and new.st_size==row['size']
            assert ident(os.stat(row['name'],dir_fd=fd,follow_symlinks=False))==ident(new)
        if row['name'].endswith('.py'):contents[row['name']]=data
    assert ident(os.fstat(fd))==ident(i) and ident(p.lstat())==ident(i)
finally:os.close(fd)
assert len(contents)==1 and not r.exists() and not r.is_symlink()
for parent in [*reversed(r.parent.parents),r.parent]:
    j=parent.lstat()
    assert stat.S_ISDIR(j.st_mode) and j.st_uid==0 and not j.st_mode & 0o022
r.mkdir(mode=0o700)
for name,data in contents.items():
    f=os.open(r/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(f,'wb') as h:h.write(data);h.flush();os.fsync(h.fileno())
for d in [r,r.parent]:
    f=os.open(d,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:os.fsync(f)
    finally:os.close(f)
print(json.dumps({'passed':True,'verifiedFiles':rows,'sealedOperator':str(r),'gameSource':'2b04e82c4f42b22f895f5f95b5bd79a8147eacdf','publicMutations':False}))
PY
