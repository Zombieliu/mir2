sudo -n python3 -B /srv/.mir2-origin-r19-s15-20261007-01/origin_negative_checks.py
