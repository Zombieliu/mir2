/usr/bin/python3 - <<'PY'
STAGE='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-c70436f34eabb432d769e0082c0afa23303294b0'
REVISION='c70436f34eabb432d769e0082c0afa23303294b0'
PINS={'gateway-package.tar.gz': {'size': 34210732, 'sha256': '2e7c16189ec3367648ca5b387b57876d46ac5ecefed4989c7a7a57b44e9a450c'}, 'VERIFIED-FILES.json': {'size': 412, 'sha256': '4c8bac55946f772699d420fd5930ddabcbfd4d36086eff2f6d2b78ba91ce7d10'}, 'upgrade-purification-gateway-01.py': {'size': 31552, 'sha256': '348aae49431bc4cdff465cc10fbb5f998a53deb45bd6e71c0e1ed6b1dcbad478'}}
import hashlib,json,os,pathlib,stat,tarfile
p=pathlib.Path(STAGE)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
assert set(x.name for x in p.iterdir())==set(PINS)
for name,pin in PINS.items():
 f=p/name;info=f.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.geteuid()
 assert info.st_size==pin['size'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
manifest=json.loads((p/'VERIFIED-FILES.json').read_text())
assert manifest['revision']==REVISION
expected={row['path']:row for row in manifest['files']}
assert set(expected)=={'mir2-gateway','RELEASE.json'}
seen=set()
with tarfile.open(p/'gateway-package.tar.gz','r:gz') as packed:
 for item in packed.getmembers():
  assert item.isfile() and item.name in {'mir2-gateway','zone_host','RELEASE.json','README.txt'}
  assert item.name not in seen and 0<item.size<=268435456
  seen.add(item.name)
  if item.name not in expected: continue
  data=packed.extractfile(item).read();entry=expected[item.name]
  assert len(data)==entry['size'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  fd=os.open(p/item.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,entry['mode'])
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.chmod(p/item.name,entry['mode'])
assert seen=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
print(json.dumps({'artifactStageVerified':True,'revision':REVISION,'publicServiceChanged':False}))
PY
