import hashlib,json,subprocess,sys
from pathlib import Path

ROOT=Path('E:/mir2-player-journey/tmp')
RELEASE=Path('C:/mir2-build/p4-purification-map-20261009-ci/server-rollout-01')
CI=Path('C:/mir2-build/p4-purification-map-20261009-ci/server-ci-01/artifact-01')
REMOTE_HELPER='C:/mir2-ui-repair-20260921/playtest-release-20260928/remote.py'
REVISION='c70436f34eabb432d769e0082c0afa23303294b0'
PREVIOUS='faefb69671272843958f68781b4f8ca2f4014522'
STAGE='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-'+REVISION

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def new(path,data):
    if path.exists():
        assert not path.is_symlink() and path.read_bytes()==data,'Existing command differs; inspection required'
        return
    with path.open('xb') as stream:stream.write(data)
def invoke(args,log,timeout=300):
    if (RELEASE/log).exists():
        base=Path(log)
        log=next(base.stem+'-retry-%02d'%attempt+base.suffix for attempt in range(1,100)
            if not (RELEASE/(base.stem+'-retry-%02d'%attempt+base.suffix)).exists())
    with (RELEASE/log).open('xb') as stream:
        result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
    data=(RELEASE/log).read_text(encoding='utf-8',errors='replace')
    if result.returncode:
        print(data)
        raise SystemExit(result.returncode)
    return data
def remote(file,log,timeout=60):
    return invoke(['python',REMOTE_HELPER,'--user','ubuntu','--command-file',str(file),
                   '--timeout',str(timeout)],log,timeout+90)


from datetime import datetime, timezone
assert sys.argv[1:] == ['--verify-only'], 'Post-deployment verification only'
proof=json.loads((CI/'CI-VERIFIED.json').read_text())
assert proof['revision']==REVISION and proof['runConclusion']=='success'
assert sha(CI/'mir2-gateway')==proof['binarySha256']
assert sha(CI/'VERIFIED-FILES.json')==proof['manifestSha256']
applied=json.loads((RELEASE/'DEPLOYED-01.json').read_text())
assert applied['applied'] is True and applied['revision']==REVISION
assert applied['previousRevision']==PREVIOUS and applied['binarySha256']==proof['binarySha256']
assert applied['candidateShutdownPanic'] is False
before_raw=(RELEASE/'deploy-before-01.log').read_text()
before=json.loads(next(line for line in before_raw.splitlines() if line.startswith('{')))
assert before['test']['revision']==PREVIOUS
count_keys=['currentWsConnections','currentActiveSessions','currentReconnectLeases',
            'currentLoginInFlight','currentNewCharacterInFlight','currentStartGameInFlight']
current_raw=remote(ROOT/'gateway-lifecycle-read-public-01.sh','postdeploy-before-01.log',40)
current=json.loads(next(line for line in current_raw.splitlines() if line.startswith('{')))
assert current['ok'] is True and current['test']['revision']==REVISION
assert current['binarySha256']==proof['binarySha256']
assert current['original']==before['original']
assert current['test']['capacity']['currentActiveSessions']<=44
for folder,script,proof_name,log in (
    ('ordinary-public-01','public-smoke.mjs','preparedHarnessSha256','public-ordinary-01.log'),
    ('native-resume-public-01','native-resume-smoke.mjs','preparedHarnessSha256','public-native-resume-01.log')):
    root=RELEASE/folder;spec=json.loads((root/'PREPARATION.json').read_text())
    assert sha(root/script)==spec[proof_name]
    invoke(['node',str(root/script)],log,300)
    report=json.loads((root/'RESULT.json').read_text())
    assert report['passed'] is True and report['sourceRevision']==REVISION
    print(json.dumps({'verified':folder,'passed':True}),flush=True)
after_raw=remote(ROOT/'gateway-lifecycle-read-public-01.sh','deploy-after-01.log',40)
after=json.loads(next(line for line in after_raw.splitlines() if line.startswith('{')))
assert after['test']['revision']==REVISION and after['test']['ok'] is True
assert after['original']==before['original'] and after['files']==before['files'] | {
    '/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf':after['files']['/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf']}
assert all(after['test']['capacity'][key]==0 for key in count_keys) and after['tcp7200']==0
final={'schema':'mir2.gateway.disconnect-public-verification.v1','revision':REVISION,
    'runId':proof['runId'],'binarySha256':proof['binarySha256'],'ordinaryChecks':44,'nativeResumeChecks':18,
    'normalPublicChecks':62,'originalRealmUnchanged':True,'clientReinstallRequired':False,
    'nativeUiAccepted':False,'fullGoalComplete':False,'after':after}
new(RELEASE/'PUBLIC-VERIFIED-01.json',(json.dumps(final,indent=2)+'\n').encode())
print(json.dumps({'passed':True,'publicChecks':62,'revision':REVISION}))

reports=[json.loads((RELEASE/folder/'RESULT.json').read_text())
         for folder in ('ordinary-public-01','native-resume-public-01')]
assert len(reports[0]['rows'])==44 and len(reports[1]['checks'])==18
assert all(r['passed'] is True and r['sourceRevision']==REVISION for r in reports)
assert all(row['confirmed'] is True for r in reports for row in r['normalLogouts'])
assert len(reports[0]['normalLogouts'])==8 and len(reports[1]['normalLogouts'])==6
assert after['binarySha256']==proof['binarySha256']
assert after['unit']['MainPID']==applied['pid'] and after['unit']['NRestarts']=='0'
assert after['unit']['Result']=='success' and after['unit']['ExecMainStatus']=='0'
assert after['test']['spectator']['activeViewers']==0
summary={
    'schema':'mir2.purification-map.postdeploy-completion.v1',
    'createdUtc':datetime.now(timezone.utc).isoformat(),
    'revision':REVISION,'previousRevision':PREVIOUS,
    'originalDriverExit':1,
    'originalDriverFailure':'Missing local ordinary-public-01/PREPARATION.json after successful service switch',
    'applyRepeated':False,'serverSwitched':True,
    'ciRunId':proof['runId'],'binarySha256':proof['binarySha256'],
    'ordinaryChecks':len(reports[0]['rows']),'nativeResumeChecks':len(reports[1]['checks']),
    'confirmedNormalLogouts':sum(len(r['normalLogouts']) for r in reports),
    'reports':[{'path':folder+'/RESULT.json','sha256':sha(RELEASE/folder/'RESULT.json')}
               for folder in ('ordinary-public-01','native-resume-public-01')],
    'afterReadbackSha256':sha(RELEASE/'deploy-after-01.log'),
    'originalRealmUnchanged':True,'clientReinstallRequired':False,
    'nativeRenderedGameplayAcceptance':False,'fullGoalComplete':False,
}
new(RELEASE/'POSTDEPLOY-COMPLETED-01.json',(json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary),flush=True)
