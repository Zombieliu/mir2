/usr/bin/python3 - <<'PY'
import os,pathlib,stat,json
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-c70436f34eabb432d769e0082c0afa23303294b0')
assert p.parent.resolve(strict=True)==p.parent and p.parent.stat().st_uid in (0,os.geteuid())
assert not p.exists() and not p.is_symlink(), 'Existing staging requires inspection; refusing a blind rerun'
p.mkdir(mode=0o700)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
print(json.dumps({'stageCreated':True}))
PY
