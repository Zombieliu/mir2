import ast
import hashlib
import json
from pathlib import Path

SOURCE = Path('C:/mir2-playtest-releases/20261009-target-r23/server-rollout-01')
DEST = Path('C:/mir2-build/p4-purification-map-20261009-ci/server-rollout-01')
REVISION = 'c70436f34eabb432d769e0082c0afa23303294b0'
PREVIOUS = 'faefb69671272843958f68781b4f8ca2f4014522'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def fresh(path, data):
    with path.open('xb') as stream:
        stream.write(data)

receipts = []
for folder, name, expected in (
    ('ordinary-public-01', 'public-smoke.mjs', '014b735c4bb001edbc287653bb8ce52a09bbe83f8c5ba6297e1721702f5332de'),
    ('native-resume-public-01', 'native-resume-smoke.mjs', '92ea271d371b42398d5c206023144a349394e76a75e10066e56f70e221b8cb80'),
):
    source = SOURCE / folder / name
    raw = source.read_bytes()
    assert sha(raw) == expected
    text = raw.decode('utf-8')
    old_root = "const root='" + (SOURCE / folder).as_posix() + "';"
    new_root = "const root='" + (DEST / folder).as_posix() + "';"
    old_rev = "const revision='" + PREVIOUS + "';"
    new_rev = "const revision='" + REVISION + "';"
    assert text.count(old_root) == 1 and text.count(old_rev) == 1
    prepared = text.replace(old_root, new_root).replace(old_rev, new_rev)
    assert prepared.replace(new_root, old_root).replace(new_rev, old_rev).encode('utf-8') == raw
    target = DEST / folder
    target.mkdir()
    data = prepared.encode('utf-8')
    fresh(target / name, data)
    receipt = {
        'schema': 'mir2.purification-map.postdeploy-harness-derivation.v1',
        'sourceHarnessSha256': expected,
        'preparedHarnessSha256': sha(data),
        'candidate': REVISION,
        'comparisonAssertionsChanged': False,
        'credentialsCopied': False,
        'onlyRootAndRevisionChanged': True,
        'executedAgainstServer': False,
    }
    fresh(target / 'PREPARATION.json', (json.dumps(receipt, indent=2) + '\n').encode())
    receipts.append({'folder': folder, **receipt})

driver = DEST / 'deploy-purification-gateway-01.py'
raw = driver.read_bytes()
assert sha(raw) == '3a319f0fb367d9e677f99d0e268577ae6c9c5e205dd464ac38df18a7580202f2'
text = raw.decode('utf-8')
prefix = text.split("assert sys.argv[1:]", 1)[0]
tail = text[text.index('for folder,script,proof_name,log in ('):]
assert '--apply' not in tail and '--resume-verified-stage' not in tail
assert 'upgrade-' not in tail and 'remote-apply' not in tail
setup = '''
from datetime import datetime, timezone
assert sys.argv[1:] == ['--verify-only'], 'Post-deployment verification only'
proof=json.loads((CI/'CI-VERIFIED.json').read_text())
assert proof['revision']==REVISION and proof['runConclusion']=='success'
assert sha(CI/'mir2-gateway')==proof['binarySha256']
assert sha(CI/'VERIFIED-FILES.json')==proof['manifestSha256']
applied=json.loads((RELEASE/'DEPLOYED-01.json').read_text())
assert applied['applied'] is True and applied['revision']==REVISION
assert applied['previousRevision']==PREVIOUS and applied['binarySha256']==proof['binarySha256']
assert applied['candidateShutdownPanic'] is False
before_raw=(RELEASE/'deploy-before-01.log').read_text()
before=json.loads(next(line for line in before_raw.splitlines() if line.startswith('{')))
assert before['test']['revision']==PREVIOUS
count_keys=['currentWsConnections','currentActiveSessions','currentReconnectLeases',
            'currentLoginInFlight','currentNewCharacterInFlight','currentStartGameInFlight']
current_raw=remote(ROOT/'gateway-lifecycle-read-public-01.sh','postdeploy-before-01.log',40)
current=json.loads(next(line for line in current_raw.splitlines() if line.startswith('{')))
assert current['ok'] is True and current['test']['revision']==REVISION
assert current['binarySha256']==proof['binarySha256']
assert current['original']==before['original']
assert current['test']['capacity']['currentActiveSessions']<=44
'''
extended = '''
reports=[json.loads((RELEASE/folder/'RESULT.json').read_text())
         for folder in ('ordinary-public-01','native-resume-public-01')]
assert len(reports[0]['rows'])==44 and len(reports[1]['checks'])==18
assert all(r['passed'] is True and r['sourceRevision']==REVISION for r in reports)
assert all(row['confirmed'] is True for r in reports for row in r['normalLogouts'])
assert len(reports[0]['normalLogouts'])==8 and len(reports[1]['normalLogouts'])==6
assert after['binarySha256']==proof['binarySha256']
assert after['unit']['MainPID']==applied['pid'] and after['unit']['NRestarts']=='0'
assert after['unit']['Result']=='success' and after['unit']['ExecMainStatus']=='0'
assert after['test']['spectator']['activeViewers']==0
summary={
    'schema':'mir2.purification-map.postdeploy-completion.v1',
    'createdUtc':datetime.now(timezone.utc).isoformat(),
    'revision':REVISION,'previousRevision':PREVIOUS,
    'originalDriverExit':1,
    'originalDriverFailure':'Missing local ordinary-public-01/PREPARATION.json after successful service switch',
    'applyRepeated':False,'serverSwitched':True,
    'ciRunId':proof['runId'],'binarySha256':proof['binarySha256'],
    'ordinaryChecks':len(reports[0]['rows']),'nativeResumeChecks':len(reports[1]['checks']),
    'confirmedNormalLogouts':sum(len(r['normalLogouts']) for r in reports),
    'reports':[{'path':folder+'/RESULT.json','sha256':sha(RELEASE/folder/'RESULT.json')}
               for folder in ('ordinary-public-01','native-resume-public-01')],
    'afterReadbackSha256':sha(RELEASE/'deploy-after-01.log'),
    'originalRealmUnchanged':True,'clientReinstallRequired':False,
    'nativeRenderedGameplayAcceptance':False,'fullGoalComplete':False,
}
new(RELEASE/'POSTDEPLOY-COMPLETED-01.json',(json.dumps(summary,indent=2)+'\\n').encode())
print(json.dumps(summary),flush=True)
'''
prepared = (prefix + setup + tail + extended).encode('utf-8')
old_funcs = [ast.dump(n, include_attributes=False) for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)]
new_funcs = [ast.dump(n, include_attributes=False) for n in ast.parse(prepared.decode()).body if isinstance(n, ast.FunctionDef)]
assert old_funcs == new_funcs and len(old_funcs) == 4
fresh(DEST / 'verify-purification-postdeploy-01.py', prepared)
result = {'candidate': REVISION, 'harnesses': receipts,
          'driverSourceSha256': sha(raw), 'preparedVerifierSha256': sha(prepared),
          'originalDriverFunctionsIdentical': 4, 'originalPostdeployAssertionsUnchanged': True,
          'applyRepeated': False, 'credentialsCopied': False}
fresh(DEST / 'POSTDEPLOY-PREPARATION-01.json', (json.dumps(result, indent=2) + '\n').encode())
print(json.dumps(result))
