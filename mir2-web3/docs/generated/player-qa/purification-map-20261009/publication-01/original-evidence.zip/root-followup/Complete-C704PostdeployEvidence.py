import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

BASE = Path('C:/mir2-build/p4-purification-map-20261009-ci/server-rollout-01')
CI = BASE.parent / 'server-ci-01/artifact-01'
REV = 'c70436f34eabb432d769e0082c0afa23303294b0'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

proof = json.loads((CI / 'CI-VERIFIED.json').read_text())
deployed = json.loads((BASE / 'DEPLOYED-01.json').read_text())
public = json.loads((BASE / 'PUBLIC-VERIFIED-01.json').read_text())
assert all(row['revision'] == REV for row in (proof, deployed, public))
assert proof['runConclusion'] == 'success' and deployed['applied'] is True
assert proof['binarySha256'] == deployed['binarySha256'] == public['binarySha256']
assert sha(CI / 'mir2-gateway') == proof['binarySha256']
reports = [json.loads((BASE / folder / 'RESULT.json').read_text()) for folder in
           ('ordinary-public-01', 'native-resume-public-01')]
ordinary, resumed = reports
assert all(row['passed'] is True and row['sourceRevision'] == REV for row in reports)
assert len(ordinary['rows']) == 44 and len(resumed['checks']) == 18
assert len(ordinary['normalLogouts']) == 8
assert all(row['confirmed'] is True for row in ordinary['normalLogouts'])
assert resumed['cycles'] == 3
logout_checks = [row for row in resumed['checks'] if row['name'].endswith('.logoutAndFreshLogin')]
assert len(logout_checks) == 3
assert all(row['status'] == 'passed' and row['evidence']['normalLogouts'] == 2
           and row['evidence']['exactState'] is True for row in logout_checks)
traces = list((BASE / 'native-resume-public-01').glob('*.jsonl'))
assert len(traces) == 12
confirmed = []
for trace in traces:
    events = [json.loads(line) for line in trace.read_text().splitlines() if line]
    sends = [row for row in events if row.get('direction') == 'sent' and row.get('type') == 'logOut']
    acks = [row for row in events if row.get('direction') == 'received'
            and row.get('packet') == 'LogOutSuccess']
    if '-resumed-' in trace.name or '-cold-login-' in trace.name:
        assert len(sends) == len(acks) == 1 and acks[0]['sequence'] > sends[0]['sequence']
        confirmed.append({'path': trace.name, 'sha256': sha(trace),
                          'requestSequence': sends[0]['sequence'], 'ackSequence': acks[0]['sequence']})
    else:
        assert len(sends) == len(acks) == 0
assert len(confirmed) == 6
with (BASE / 'postdeploy-final-read-01.log').open('xb') as stream:
    result = subprocess.run(['python', 'C:/mir2-ui-repair-20260921/playtest-release-20260928/remote.py',
                             '--user', 'ubuntu', '--command-file',
                             'E:/mir2-player-journey/tmp/gateway-lifecycle-read-public-01.sh',
                             '--timeout', '40'], stdout=stream, stderr=subprocess.STDOUT, timeout=130)
assert result.returncode == 0, 'Fresh readback failed; inspect retained log'
after = json.loads(next(line for line in (BASE / 'postdeploy-final-read-01.log').read_text().splitlines()
                        if line.startswith('{')))
before = json.loads(next(line for line in (BASE / 'deploy-before-01.log').read_text().splitlines()
                         if line.startswith('{')))
assert after['ok'] is True and after['test']['ok'] is True and after['test']['revision'] == REV
assert after['binarySha256'] == proof['binarySha256'] and after['original'] == before['original']
assert after['files'] == before['files'] | {
    '/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf':
    after['files']['/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf']}
assert after['unit']['MainPID'] == deployed['pid'] and after['unit']['NRestarts'] == '0'
assert after['unit']['Result'] == 'success' and after['unit']['ExecMainStatus'] == '0'
keys = ['currentWsConnections', 'currentActiveSessions', 'currentReconnectLeases',
        'currentLoginInFlight', 'currentNewCharacterInFlight', 'currentStartGameInFlight']
assert all(after['test']['capacity'][key] == 0 for key in keys)
assert after['tcp7200'] == 0 and after['test']['spectator']['activeViewers'] == 0
summary = {
    'schema': 'mir2.purification-map.postdeploy-completion.v1',
    'createdUtc': datetime.now(timezone.utc).isoformat(), 'revision': REV,
    'previousRevision': deployed['previousRevision'], 'serverSwitched': True,
    'applyRepeated': False, 'ciRunId': proof['runId'], 'binarySha256': proof['binarySha256'],
    'ordinaryChecks': 44, 'nativeResumeChecks': 18, 'confirmedNormalLogouts': 14,
    'nativeResumeLogouts': confirmed, 'afterReadbackSha256': sha(BASE / 'postdeploy-final-read-01.log'),
    'originalRealmUnchanged': True, 'clientReinstallRequired': False,
    'nativeRenderedGameplayAcceptance': False, 'fullGoalComplete': False,
    'observedDriverFailures': [
        {'script': 'deploy-purification-gateway-01.py', 'exit': 1,
         'phase': 'After successful server switch',
         'error': 'FileNotFoundError: local ordinary-public-01/PREPARATION.json missing',
         'stdoutEvidence': 'Tool session 80258 returned output; inner remote apply log retained'},
        {'script': 'verify-purification-postdeploy-01.py', 'exit': 1,
         'phase': 'After original 62 checks and PUBLIC-VERIFIED-01.json succeeded',
         'error': "KeyError: 'normalLogouts' in newly added metadata finalization",
         'stdoutEvidence': 'Tool session 30212 returned output; both original result/trace logs retained'},
    ],
    'metadataRecoveryOnly': True, 'productCodeOrTestsWeakened': False,
}
with (BASE / 'POSTDEPLOY-COMPLETED-01.json').open('x', encoding='utf-8') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps(summary))
