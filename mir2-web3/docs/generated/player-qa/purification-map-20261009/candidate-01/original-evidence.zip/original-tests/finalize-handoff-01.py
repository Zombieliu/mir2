from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re

root = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3')
evidence = Path('C:/mir2-build/p4-purification-map-20261009-evidence')
paths = [
    'apps/simulation/src/runtime/zone/manager.rs',
    'apps/simulation/src/runtime/zone/runtime.rs',
    'apps/simulation/src/runtime/zone/runtime/purification_tests.rs',
    'apps/simulation/tests/shared_purification_map_transfer.rs',
    'apps/gateway/tests/shared_purification_map_transfer.rs',
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def source_map(data):
    return {p['Path'].replace('\\', '/').lower(): p['Hash'].lower() for p in data['source']}

logs = []
for result_path in sorted(evidence.glob('*-result.json')):
    stem = result_path.name.removesuffix('-result.json')
    result = read(result_path)
    before = read(evidence / (stem + '-before.json'))
    after = read(evidence / (stem + '-after.json'))
    log_path = evidence / (stem + '.log')
    results = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', log_path.read_text(encoding='utf-8-sig'))
    logs.append({
        'stem': stem, 'command': before['command'], 'exitCode': result['exitCode'],
        'results': [{'status': state, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)} for state, passed, failed, ignored in results],
        'utcStarted': result['utcStarted'], 'utcFinished': result['utcFinished'],
        'log': str(log_path), 'logSHA256': sha(log_path),
        'before': str(evidence / (stem + '-before.json')), 'beforeSHA256': sha(evidence / (stem + '-before.json')),
        'after': str(evidence / (stem + '-after.json')), 'afterSHA256': sha(evidence / (stem + '-after.json')),
        'ownedSourceUnchangedDuringCommand': source_map(before) == source_map(after),
    })

current = {str(root / relative).replace('\\', '/').lower(): sha(root / relative) for relative in paths}
for stem in [
    '21-purification-and-preflight-private-final',
    '22-normal-manager-map-lifecycle-final',
    '23-normal-gateway-release-live-and-relogin',
    '24-all-purification-source-final',
    '25-adjacent-pet-and-hell-final',
]:
    assert source_map(read(evidence / (stem + '-after.json'))) == current, stem + ': final Source changed'
    assert read(evidence / (stem + '-result.json'))['exitCode'] == 0, stem

handoff = {
    'utc': datetime.now(timezone.utc).isoformat(),
    'declaredParentBaseSource': '5860815944e8077537cc12a7f32885b21c6d0a80',
    'gitVerification': 'Not queried by this worker; Git belongs to Root.',
    'checkout': str(root), 'writeOwnership': 'All five owned Source files returned to Root; no further worker writes.',
    'source': [{'path': str(root / relative), 'bytes': (root / relative).stat().st_size, 'SHA256': sha(root / relative)} for relative in paths],
    'sourceFunctions': [
        {'path': paths[0], 'function': 'ZoneManager::handle_for_key', 'lines': [610, 628, 679], 'change': 'Take opaque state only on true retain_online map detach; adopt after final online presence refresh.'},
        {'path': paths[1], 'function': 'OnlinePurificationTransfer / take_online_purification_transfer / adopt_online_purification_transfer', 'lines': [524, 7567, 7584], 'change': 'Move-only live value with exact full actor authority, original pending records and all actual buffs/absolute expiry. No serialization, proof signing or AddBuff fabrication.'},
        {'path': paths[1], 'function': 'can_player_cast_magic / native_player_magic_admission / player_cast_native_player_magic', 'lines': [2091, 5706, 5752], 'change': 'Real Player preflight before native Monster lookup; a shared read-only predicate rechecks original current permission/resource/clock policy on dispatch, preserving resource rejection correction.'},
        {'path': paths[2], 'function': 'Three new player preflight tests and three new opaque transfer tests', 'lines': [513, 555, 730, 1076, 1125, 1163]},
        {'path': paths[3], 'function': '13 ordinary Manager integration cases', 'lines': [251, 272, 338, 348, 390, 420, 451, 462, 491, 522, 545, 563, 590]},
        {'path': paths[4], 'function': 'Four ordinary GatewaySession adapter cases', 'lines': [293, 355, 494, 608]},
    ],
    'finalGates': {
        'privateModule': {'logStem': '21-purification-and-preflight-private-final', 'passed': 21},
        'normalManager': {'logStem': '22-normal-manager-map-lifecycle-final', 'passed': 13},
        'normalGatewayRelease': {'logStem': '23-normal-gateway-release-live-and-relogin', 'passed': 4},
        'allPurificationSource': {'logStem': '24-all-purification-source-final', 'passed': 23},
        'adjacentOriginalPetHell': {'logStem': '25-adjacent-pet-and-hell-final', 'passed': [17, 38]},
    },
    'retainedFullZoneBaseline': {'logStem': '13-full-shared-zone', 'passed': 201, 'failed': 8, 'rerunAfterPreflight': False, 'remainingFixturesEdited': False},
    'limits': [
        'Gateway evidence is isolated ordinary GatewaySession adapter with prepared accounts, skills, bag supplies and map. No public TCP/WS, native/client UI or human acceptance.',
        'Default InProcess inventory adapter proves one live powder debit then normal LogOut persistence and fresh Login/StartGame quantity99. Every rejection proves no live debit and fresh quantity100. No before-ACK durable Source CAS claim.',
        'Real Map0 TownTeleport chain passes original500ms deadline in release. Debug deadline misses remain retained in logs14/15/20; no threshold relaxation or ignored test.',
        'Original600ms spell action/movement, typed Nodes/lives, cold/logout/non-retain/revive/conflict denial retained. No checkpoint/auth/schema changes.',
        'Existing private-stat/native Curse SC aggregation concern is independent and unresolved in this round; not modified.',
        'No Source/docs/workflow/Git/service/credentials/real-save/UI actions outside assigned Source scope. Root owns review, integration, docs, Git, CI and release.',
    ],
    'logs': logs,
}
path = evidence / 'FINAL-HANDOFF-01.json'
path.write_text(json.dumps(handoff, indent=2, ensure_ascii=False), encoding='utf-8')
print(json.dumps({'handoff': str(path), 'SHA256': sha(path), 'source': handoff['source'], 'logs': len(logs), 'allSourceStableWithinCommand': all(row['ownedSourceUnchangedDuringCommand'] for row in logs)}, indent=2))
