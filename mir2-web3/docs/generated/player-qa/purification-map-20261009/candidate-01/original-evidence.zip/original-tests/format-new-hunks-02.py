from pathlib import Path
import hashlib
import json
import subprocess

root = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3')
evidence = Path('C:/mir2-build/p4-purification-map-20261009-evidence')
records = []

def digest(data):
    return hashlib.sha256(data).hexdigest()

for relative in [
    'apps/simulation/tests/shared_purification_map_transfer.rs',
    'apps/gateway/tests/shared_purification_map_transfer.rs',
]:
    path = root / relative
    before = path.read_bytes()
    subprocess.run(['rustfmt', '+1.95.0', '--edition', '2021', str(path)], check=True)
    records.append({'path': relative, 'scope': 'new file only', 'beforeSHA256': digest(before), 'afterSHA256': digest(path.read_bytes())})

relative = 'apps/simulation/src/runtime/zone/runtime/purification_tests.rs'
path = root / relative
before = path.read_bytes()
newline = '\r\n' if b'\r\n' in before else '\n'
source = before.decode('utf-8').replace('\r\n', '\n')
spans = [
    ('#[test]\nfn player_magic_item_preflight_admits_the_real_hostile_player_target()', '#[test]\nfn purification_accepts_current_source_group_guild_enemy_guild_and_pk_199()'),
    ('#[test]\nfn purification_live_transfer_moves_only_the_exact_caster_and_preserves_original_records()', None),
]
for start_marker, end_marker in spans:
    start = source.index(start_marker)
    end = source.index(end_marker, start) if end_marker else len(source)
    original = source[start:end]
    result = subprocess.run(['rustfmt', '+1.95.0', '--edition', '2021', '--emit', 'stdout'], input=original, text=True, capture_output=True, check=True)
    formatted = result.stdout.replace('\r\n', '\n').rstrip() + '\n\n'
    source = source[:start] + formatted + source[end:]
path.write_bytes(source.replace('\n', newline).encode('utf-8'))
records.append({'path': relative, 'scope': 'six newly added test functions only', 'beforeSHA256': digest(before), 'afterSHA256': digest(path.read_bytes())})
(evidence / 'NEW-HUNKS-FORMAT-02.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
print(json.dumps(records, indent=2))
