param([Parameter(Mandatory=$true)][string]$LogStem,[Parameter(Mandatory=$true)][string[]]$CargoArgs)
$ErrorActionPreference='Stop'
$taskRoot='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p4-purification-map-20261009-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
Set-Location -LiteralPath $taskRoot
$taskPaths=@('apps/simulation/src/runtime/zone/manager.rs','apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/runtime/purification_tests.rs','apps/simulation/tests/shared_purification_map_transfer.rs','apps/gateway/tests/shared_purification_map_transfer.rs')
function Write-SourceHashes([string]$phase) {
 $taskHashes=@($taskPaths | Where-Object { Test-Path -LiteralPath $_ } | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
 [ordered]@{declaredBaseSource='5860815944e8077537cc12a7f32885b21c6d0a80';utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=@('cargo','+1.95.0')+$CargoArgs;source=$taskHashes} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding UTF8
}
Write-SourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& cargo +1.95.0 @CargoArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Write-SourceHashes 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;log="$taskEvidence/$LogStem.log"} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 55
exit $taskExit
