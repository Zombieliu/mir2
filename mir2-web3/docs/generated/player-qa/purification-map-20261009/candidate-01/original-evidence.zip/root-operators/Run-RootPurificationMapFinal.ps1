$ErrorActionPreference='Stop'
$taskRunner='C:/mir2-build/p4-purification-map-20261009-evidence/run-numbered.ps1'
& $taskRunner -LogStem '32-root-final-manager' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--test','shared_purification_map_transfer','--','--test-threads=1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskRunner -LogStem '33-root-final-purification' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--lib','purification','--','--test-threads=1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskRunner -LogStem '34-root-final-pet-hell' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--features','test-support','--test','shared_pet_pvp','--test','shared_monster_hell_ai','--','--test-threads=1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskRunner -LogStem '35-root-final-full-zone' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--lib','runtime::zone::','--','--test-threads=1')
# The full Zone result is deliberately returned unchanged. Root separately
# compares its actual failures with the retained earlier RED result.
exit $LASTEXITCODE
