$ErrorActionPreference='Stop'
$taskRoot='C:/Users/Administrator/.codex/worktrees/purification-baseline-586/mir2-player-journey'
$taskEvidence='C:/mir2-build/p4-purification-map-20261009-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
Set-Location -LiteralPath "$taskRoot/mir2-web3"
$taskGit=@('-c',"safe.directory=$taskRoot",'-c','gc.auto=0','-c','maintenance.auto=false','-C',$taskRoot)
$taskHead=& git @taskGit rev-parse HEAD
if ($LASTEXITCODE -ne 0 -or $taskHead.Trim() -ne '5860815944e8077537cc12a7f32885b21c6d0a80') { throw 'Baseline source mismatch' }
$taskDirty=& git @taskGit status --porcelain
if ($LASTEXITCODE -ne 0 -or $taskDirty) { throw 'Baseline checkout must be clean' }
$taskStarted=[DateTime]::UtcNow
$taskArgs=@('test','--offline','--locked','-p','mir2-simulation','--lib','runtime::zone::','--','--test-threads=1')
$taskSource=@('apps/simulation/src/runtime/zone/manager.rs','apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/runtime/purification_tests.rs')
$taskBefore=@($taskSource | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
[ordered]@{utc=$taskStarted.ToString('o');head=$taskHead.Trim();clean=$true;command=@('cargo','+1.95.0')+$taskArgs;source=$taskBefore} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath "$taskEvidence/37-baseline-full-zone-before.json" -Encoding UTF8
& cargo +1.95.0 @taskArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/37-baseline-full-zone.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
$taskAfter=@($taskSource | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
$taskFinalDirty=& git @taskGit status --porcelain
if ($LASTEXITCODE -ne 0 -or $taskFinalDirty) { throw 'Baseline changed during execution' }
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');head=$taskHead.Trim();clean=$true;exitCode=$taskExit;source=$taskAfter} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath "$taskEvidence/37-baseline-full-zone-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/37-baseline-full-zone.log" | Select-String -Pattern '^    runtime::zone::','^test result:' | ForEach-Object { $_.Line }
exit $taskExit
