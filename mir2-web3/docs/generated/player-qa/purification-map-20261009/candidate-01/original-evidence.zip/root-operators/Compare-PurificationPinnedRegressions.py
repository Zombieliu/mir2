import hashlib, json, re
from datetime import datetime, timezone
from pathlib import Path

root = Path('C:/mir2-build/p4-purification-map-20261009-evidence')
def parsed(stem):
    raw = (root / (stem + '.log')).read_bytes()
    text = raw.decode('utf-8-sig')
    failures = sorted(re.findall(r'^test (\S+) \.\.\. FAILED\r?$', text, re.M))
    results = re.findall(r'^test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    assert len(results) == 1 and len(failures) == int(results[0][1])
    return dict(log=stem + '.log', sha256=hashlib.sha256(raw).hexdigest(),
                passed=int(results[0][0]), failed=int(results[0][1]),
                ignored=int(results[0][2]), failures=failures)
baseline = parsed('37-baseline-full-zone')
current = parsed('35-root-final-full-zone')
assert baseline['failed'] == current['failed'] == 8
assert baseline['failures'] == current['failures']
assert baseline['passed'] == 299 and current['passed'] == 305
record = dict(utc=datetime.now(timezone.utc).isoformat(),
    baselineHead='5860815944e8077537cc12a7f32885b21c6d0a80',
    baselineCleanCheckout=True, sameFailures=True, baseline=baseline, current=current,
    fullSuiteGreen=False, addedCases=6)
with (root / 'ROOT-PINNED-BASELINE-COMPARISON.json').open('x', encoding='utf-8') as target:
    json.dump(record, target, indent=2); target.write('\n')
print(json.dumps({key: record[key] for key in ['baselineHead','sameFailures','fullSuiteGreen','addedCases']}))
