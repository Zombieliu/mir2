use super::entity_combat::ZoneEntityCombatState;
use super::intelligent_creature_host::CreatureHost;
use super::{PetSpecialWorld, TreeQueenWorld};
use crate::runtime::zone::intelligent_creatures::{CreatureOperation, CreaturePickupIntent};
use std::collections::{BTreeMap, BTreeSet};

use mir2_protocol::{
    decode_server_packet, encode_server_packet, ObjectHealthInfo, ObjectManaInfo, Point,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

use super::{
    canonical_ground_drop_claim_idempotency_key, canonical_ground_drop_payload_digest,
    HellWorldState, HornedEncounterWorld, NativePeriodicPlayerPoison,
    PendingNativeGroundSpellAction, PendingNativeMonsterHit, PendingNativePlayerHeal,
    PendingNativePlayerHit, PendingNativeProjectile, PendingNativeSummon, ZoneHazardState,
    ZoneObjectDeadState, ZoneRuntime,
};
use crate::runtime::zone::types::{
    GroundDropClaimTicket, SessionId, ZoneGroundDrop, ZoneGroundDropClaim, ZoneKey,
    ZoneNativeMonster, ZoneNativeMonsterRespawn, ZoneObject, ZonePlayer, ZonePlayerBuff,
};
use crate::runtime::zone::ZoneCollision;
use crate::runtime::zone::online_identity::{OnlineOwner, OnlinePresenceSnapshot};
use crate::runtime::zone::types::ZoneGroundDropCustody;

const LEGACY_CANONICAL_ZONE_STATE_VERSION: u32 = 1;
const LEGACY_CANONICAL_ZONE_STATE_DOMAIN: &[u8] = b"obelisk.mir2.zone-state.v1\0";
const LEGACY_V2_CANONICAL_ZONE_STATE_VERSION: u32 = 2;
const LEGACY_V2_CANONICAL_ZONE_STATE_DOMAIN: &[u8] = b"obelisk.mir2.zone-state.v2\0";
const LEGACY_V3_CANONICAL_ZONE_STATE_VERSION: u32 = 3;
const LEGACY_V3_CANONICAL_ZONE_STATE_DOMAIN: &[u8] = b"obelisk.mir2.zone-state.v3\0";
const LEGACY_V4_CANONICAL_ZONE_STATE_VERSION: u32 = 4;
const LEGACY_V4_CANONICAL_ZONE_STATE_DOMAIN: &[u8] = b"obelisk.mir2.zone-state.v4\0";
const LEGACY_V5_CANONICAL_ZONE_STATE_DOMAIN: &[u8] = b"obelisk.mir2.zone-state.v5\0";
const LEGACY_V6_CANONICAL_ZONE_STATE_DOMAIN: &[u8] = b"obelisk.mir2.zone-state.v6\0";
const CANONICAL_ZONE_STATE_VERSION: u32 = 7;
const CANONICAL_ZONE_STATE_DOMAIN: &[u8] = b"obelisk.mir2.zone-state.v7\0";
const LEGACY_ZONE_RUNTIME_CHECKPOINT_VERSION: u32 = 1;
const LEGACY_V2_ZONE_RUNTIME_CHECKPOINT_VERSION: u32 = 2;
const LEGACY_V3_ZONE_RUNTIME_CHECKPOINT_VERSION: u32 = 3;
const LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION: u32 = 4;
const LEGACY_V5_ZONE_RUNTIME_CHECKPOINT_VERSION: u32 = 5;
const LEGACY_V6_ZONE_RUNTIME_CHECKPOINT_VERSION: u32 = 6;
const ZONE_RUNTIME_CHECKPOINT_VERSION: u32 = 7;

fn legacy_v2_ground_drop_claim_idempotency_key(
    key: &ZoneKey,
    object_id: u32,
    drop_generation: u64,
    claim_id: u64,
    payload_digest: &str,
) -> String {
    format!(
        "ground-drop:{}:{}:{}:{}:{}:{}:{}:{}",
        key.shard_id,
        key.map_file_name,
        key.channel_id,
        key.instance_id,
        object_id,
        drop_generation,
        claim_id,
        payload_digest
    )
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum StateRootPolicy {
    Strict,
    ReanchorVerifiedWorldCheckpoint,
}

/// The authoritative portion of a zone. Collision data is selected by the
/// signed game module and `ZoneKey`; occupancy, AOI grids, and the ECS mirror
/// are derived indexes rebuilt from these fields and therefore are not hashed.
#[derive(Serialize)]
struct CanonicalZoneState<'a> {
    version: u32,
    key: &'a ZoneKey,
    collision: &'a ZoneCollision,
    players: &'a BTreeMap<SessionId, ZonePlayer>,
    objects: &'a BTreeMap<u32, ZoneObject>,
    dead_object_ids: &'a BTreeMap<u32, ZoneObjectDeadState>,
    revived_object_ids: &'a BTreeSet<u32>,
    removed_object_ids: &'a BTreeSet<u32>,
    harvested_object_ids: &'a BTreeSet<u32>,
    native_monsters: &'a BTreeMap<u32, ZoneNativeMonster>,
    pending_native_hits: &'a [PendingNativeMonsterHit],
    pending_native_projectiles: &'a [PendingNativeProjectile],
    pending_native_player_hits: &'a [PendingNativePlayerHit],
    pending_native_player_heals: &'a [PendingNativePlayerHeal],
    pending_native_summons: &'a [PendingNativeSummon],
    pending_native_ground_spells: &'a [PendingNativeGroundSpellAction],
    ground_drops: &'a BTreeMap<u32, ZoneGroundDrop>,
    claimed_ground_drops: &'a BTreeMap<u32, ZoneGroundDropClaim>,
    next_ground_drop_generation: u64,
    next_ground_drop_claim_id: u64,
    open_doors: &'a BTreeMap<u8, u64>,
    hazard: &'a ZoneHazardState,
    next_object_id: u32,
}

#[derive(Serialize)]
struct CanonicalZoneStateV4<'a> {
    version: u32,
    key: &'a ZoneKey,
    collision: &'a ZoneCollision,
    players: &'a BTreeMap<SessionId, ZonePlayer>,
    objects: &'a BTreeMap<u32, ZoneObject>,
    dead_object_ids: &'a BTreeMap<u32, ZoneObjectDeadState>,
    revived_object_ids: &'a BTreeSet<u32>,
    removed_object_ids: &'a BTreeSet<u32>,
    harvested_object_ids: &'a BTreeSet<u32>,
    native_monsters: &'a BTreeMap<u32, ZoneNativeMonster>,
    native_monster_respawns: &'a BTreeMap<u32, ZoneNativeMonsterRespawn>,
    pending_native_hits: &'a [PendingNativeMonsterHit],
    pending_native_projectiles: &'a [PendingNativeProjectile],
    pending_native_player_hits: &'a [PendingNativePlayerHit],
    pending_native_player_heals: &'a [PendingNativePlayerHeal],
    pending_native_summons: &'a [PendingNativeSummon],
    pending_native_ground_spells: &'a [PendingNativeGroundSpellAction],
    ground_drops: &'a BTreeMap<u32, ZoneGroundDrop>,
    claimed_ground_drops: &'a BTreeMap<u32, ZoneGroundDropClaim>,
    next_ground_drop_generation: u64,
    next_ground_drop_claim_id: u64,
    open_doors: &'a BTreeMap<u8, u64>,
    hazard: &'a ZoneHazardState,
    #[serde(skip_serializing_if = "Option::is_none")]
    hell_world: &'a Option<HellWorldState>,
    #[serde(skip_serializing_if = "Option::is_none")]
    horned_encounter_world: &'a Option<HornedEncounterWorld>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pet_special_world: &'a Option<PetSpecialWorld>,
    #[serde(skip_serializing_if = "Option::is_none")]
    entity_combat: &'a Option<ZoneEntityCombatState>,
    #[serde(skip_serializing_if = "checkpoint_counter_is_zero")]
    next_monster_incarnation: u64,
    #[serde(skip_serializing_if = "Option::is_none")]
    tree_queen_world: &'a Option<TreeQueenWorld>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    native_periodic_player_poisons: &'a Vec<NativePeriodicPlayerPoison>,
    next_object_id: u32,
    #[serde(skip_serializing_if = "BTreeMap::is_empty")]
    intelligent_creatures: &'a BTreeMap<SessionId, CreatureHost>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    intelligent_creature_intents: &'a Vec<CreaturePickupIntent>,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    intelligent_creature_operations: &'a Vec<CreatureOperation>,
    #[serde(skip_serializing_if = "Option::is_none")]
    online_presence: Option<&'a OnlinePresenceSnapshot>,
    #[serde(skip_serializing_if = "Option::is_none")]
    detached_ground_drop_custody: Option<&'a BTreeMap<u32, ZoneGroundDropCustody>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    issued_native_monster_awards: Option<&'a BTreeMap<String, OnlineOwner>>,
    #[serde(skip_serializing_if = "Option::is_none")]
    mining: Option<&'a super::mining::ZoneMiningState>,
}

#[derive(Serialize)]
struct LegacyCanonicalZoneState<'a> {
    version: u32,
    key: &'a ZoneKey,
    collision: &'a ZoneCollision,
    players: &'a BTreeMap<SessionId, ZonePlayer>,
    objects: &'a BTreeMap<u32, ZoneObject>,
    dead_object_ids: &'a BTreeMap<u32, ZoneObjectDeadState>,
    revived_object_ids: &'a BTreeSet<u32>,
    removed_object_ids: &'a BTreeSet<u32>,
    harvested_object_ids: &'a BTreeSet<u32>,
    native_monsters: &'a BTreeMap<u32, ZoneNativeMonster>,
    pending_native_hits: &'a [PendingNativeMonsterHit],
    pending_native_projectiles: &'a [PendingNativeProjectile],
    pending_native_player_hits: &'a [PendingNativePlayerHit],
    pending_native_player_heals: &'a [PendingNativePlayerHeal],
    pending_native_summons: &'a [PendingNativeSummon],
    pending_native_ground_spells: &'a [PendingNativeGroundSpellAction],
    ground_drops: BTreeMap<u32, LegacyZoneGroundDrop<'a>>,
    claimed_ground_drops: BTreeMap<u32, LegacyZoneGroundDropClaim<'a>>,
    open_doors: &'a BTreeMap<u8, u64>,
    hazard: &'a ZoneHazardState,
    next_object_id: u32,
}

#[derive(Serialize)]
struct LegacyZoneGroundDrop<'a> {
    drop: &'a crate::config::GroundDropSnapshot,
    owner_expires_at_ms: Option<u64>,
}

#[derive(Serialize)]
struct LegacyZoneGroundDropClaim<'a> {
    session_id: &'a SessionId,
    drop: &'a crate::config::GroundDropSnapshot,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ZoneRuntimeCheckpoint {
    version: u32,
    state_root: String,
    key: ZoneKey,
    players: BTreeMap<SessionId, ZonePlayer>,
    objects: BTreeMap<u32, ZoneObjectCheckpoint>,
    dead_object_ids: BTreeMap<u32, ZoneObjectDeadState>,
    revived_object_ids: BTreeSet<u32>,
    removed_object_ids: BTreeSet<u32>,
    harvested_object_ids: BTreeSet<u32>,
    native_monsters: BTreeMap<u32, ZoneNativeMonster>,
    #[serde(default)]
    native_monster_respawns: BTreeMap<u32, ZoneNativeMonsterRespawn>,
    pending_native_hits: Vec<PendingNativeMonsterHit>,
    pending_native_projectiles: Vec<PendingNativeProjectile>,
    pending_native_player_hits: Vec<PendingNativePlayerHit>,
    pending_native_player_heals: Vec<PendingNativePlayerHeal>,
    pending_native_summons: Vec<PendingNativeSummon>,
    pending_native_ground_spells: Vec<PendingNativeGroundSpellAction>,
    ground_drops: BTreeMap<u32, ZoneGroundDrop>,
    claimed_ground_drops: BTreeMap<u32, ZoneGroundDropClaim>,
    #[serde(default)]
    next_ground_drop_generation: u64,
    #[serde(default)]
    next_ground_drop_claim_id: u64,
    open_doors: BTreeMap<u8, u64>,
    hazard: ZoneHazardState,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    hell_world: Option<HellWorldState>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    horned_encounter_world: Option<HornedEncounterWorld>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pet_special_world: Option<PetSpecialWorld>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    entity_combat: Option<ZoneEntityCombatState>,
    #[serde(default, skip_serializing_if = "checkpoint_counter_is_zero")]
    next_monster_incarnation: u64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    tree_queen_world: Option<TreeQueenWorld>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    native_periodic_player_poisons: Vec<NativePeriodicPlayerPoison>,
    next_object_id: u32,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    intelligent_creatures: BTreeMap<SessionId, CreatureHost>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    intelligent_creature_intents: Vec<CreaturePickupIntent>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    intelligent_creature_operations: Vec<CreatureOperation>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    online_presence: Option<OnlinePresenceSnapshot>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    detached_ground_drop_custody: Option<BTreeMap<u32, ZoneGroundDropCustody>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    issued_native_monster_awards: Option<BTreeMap<String, OnlineOwner>>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    mining: Option<super::mining::ZoneMiningState>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct ZoneObjectCheckpoint {
    object_id: u32,
    position: Point,
    packet_frame: Vec<u8>,
    health: Option<ObjectHealthInfo>,
    mana: Option<ObjectManaInfo>,
    expires_at_ms: Option<u64>,
    buffs: BTreeMap<u8, ZonePlayerBuff>,
}

impl ZoneObjectCheckpoint {
    fn capture(object: &ZoneObject) -> Result<Self, String> {
        Ok(Self {
            object_id: object.object_id,
            position: object.position.clone(),
            packet_frame: encode_server_packet(&object.packet)
                .map_err(|error| format!("failed to encode retained Zone packet: {error}"))?,
            health: object.health.clone(),
            mana: object.mana.clone(),
            expires_at_ms: object.expires_at_ms,
            buffs: object.buffs.clone(),
        })
    }

    fn restore(self) -> Result<ZoneObject, String> {
        Ok(ZoneObject {
            object_id: self.object_id,
            position: self.position,
            packet: decode_server_packet(&self.packet_frame)
                .map_err(|error| format!("failed to decode retained Zone packet: {error}"))?,
            health: self.health,
            mana: self.mana,
            expires_at_ms: self.expires_at_ms,
            buffs: self.buffs,
        })
    }
}

impl ZoneRuntime {
    /// Canonical SHA-256 commitment to the complete authoritative zone state.
    /// BTree collections and struct field order make the JSON byte stream
    /// deterministic for a fixed signed game-module version.
    pub fn canonical_state_root(&self) -> Result<String, String> {
        self.canonical_state_root_for_schema(
            CANONICAL_ZONE_STATE_VERSION, CANONICAL_ZONE_STATE_DOMAIN,
            &self.native_monsters, &self.pending_native_hits,
        )
    }

    fn canonical_state_root_for_schema(
        &self,
        version: u32,
        domain: &[u8],
        native_monsters: &BTreeMap<u32, ZoneNativeMonster>,
        pending_native_hits: &[PendingNativeMonsterHit],
    ) -> Result<String, String> {
        let mut monsters = native_monsters.clone();
        let (ground_drops, claimed_ground_drops) = if version < 6 {
            for monster in monsters.values_mut() {
                if let Some(owner) = monster.experience_owner.as_mut() { owner.online_owner = None; }
            }
            self.legacy_ground_metadata_free_state()
        } else { (self.ground_drops.clone(), self.claimed_ground_drops.clone()) };
        let state = CanonicalZoneStateV4 {
            mining: (version >= 7).then_some(&self.mining),
            online_presence: (version >= 6).then_some(&self.online_presence),
            detached_ground_drop_custody: (version >= 6).then_some(&self.detached_ground_drop_custody),
            issued_native_monster_awards: (version >= 6).then_some(&self.issued_native_monster_awards),
            intelligent_creatures: &self.intelligent_creatures,
            intelligent_creature_intents: &self.intelligent_creature_intents,
            intelligent_creature_operations: &self.intelligent_creature_operations,
            version,
            key: &self.key,
            collision: &self.collision,
            players: &self.players,
            objects: &self.objects,
            dead_object_ids: &self.dead_object_ids,
            revived_object_ids: &self.revived_object_ids,
            removed_object_ids: &self.removed_object_ids,
            harvested_object_ids: &self.harvested_object_ids,
            native_monsters: &monsters,
            native_monster_respawns: &self.native_monster_respawns,
            pending_native_hits,
            pending_native_projectiles: &self.pending_native_projectiles,
            pending_native_player_hits: &self.pending_native_player_hits,
            pending_native_player_heals: &self.pending_native_player_heals,
            pending_native_summons: &self.pending_native_summons,
            pending_native_ground_spells: &self.pending_native_ground_spells,
            ground_drops: &ground_drops,
            claimed_ground_drops: &claimed_ground_drops,
            next_ground_drop_generation: self.next_ground_drop_generation,
            next_ground_drop_claim_id: self.next_ground_drop_claim_id,
            open_doors: &self.open_doors,
            hazard: &self.hazard,
            hell_world: &self.hell_world,
            horned_encounter_world: &self.horned_encounter_world,
            pet_special_world: &self.pet_special_world,
            entity_combat: &self.entity_combat,
            next_monster_incarnation: self.next_monster_incarnation,
            tree_queen_world: &self.tree_queen_world,
            native_periodic_player_poisons: &self.native_periodic_player_poisons,
            next_object_id: self.next_object_id,
        };
        let bytes = serde_json::to_vec(&state)
            .map_err(|error| format!("failed to serialize canonical zone state: {error}"))?;
        let mut hasher = Sha256::new();
        hasher.update(domain);
        hasher.update(bytes);
        Ok(hex_lower(&hasher.finalize()))
    }

    pub(super) fn legacy_v4_canonical_state_root(&self) -> Result<String, String> {
        let (monsters, hits) = self.legacy_ownership_free_monsters_and_hits();
        self.canonical_state_root_for_schema(
            LEGACY_V4_CANONICAL_ZONE_STATE_VERSION, LEGACY_V4_CANONICAL_ZONE_STATE_DOMAIN,
            &monsters, &hits,
        )
    }

    fn legacy_v5_canonical_state_root(&self) -> Result<String, String> {
        self.canonical_state_root_for_schema(5, LEGACY_V5_CANONICAL_ZONE_STATE_DOMAIN,
            &self.native_monsters, &self.pending_native_hits)
    }
    fn legacy_v6_canonical_state_root(&self)->Result<String,String> {
        self.canonical_state_root_for_schema(6,LEGACY_V6_CANONICAL_ZONE_STATE_DOMAIN,
            &self.native_monsters,&self.pending_native_hits)
    }
    fn legacy_ground_metadata_free_state(&self)
        -> (BTreeMap<u32, ZoneGroundDrop>, BTreeMap<u32, ZoneGroundDropClaim>) {
        let mut drops = self.ground_drops.clone();
        let mut claims = self.claimed_ground_drops.clone();
        for stored in drops.values_mut() { stored.native_owner = None; }
        for claim in claims.values_mut() { claim.custody = None; }
        (drops, claims)
    }

    fn legacy_ownership_free_monsters_and_hits(
        &self,
    ) -> (BTreeMap<u32, ZoneNativeMonster>, Vec<PendingNativeMonsterHit>) {
        let mut monsters = self.native_monsters.clone();
        let mut hits = self.pending_native_hits.clone();
        for monster in monsters.values_mut() {
            monster.experience_owner = None;
        }
        for hit in &mut hits {
            hit.force_experience_owner = false;
        }
        (monsters, hits)
    }

    fn legacy_canonical_state_root(&self) -> Result<String, String> {
        let (monsters, hits) = self.legacy_ownership_free_monsters_and_hits();
        let ground_drops = self
            .ground_drops
            .iter()
            .map(|(object_id, stored)| {
                (
                    *object_id,
                    LegacyZoneGroundDrop {
                        drop: &stored.drop,
                        owner_expires_at_ms: stored.owner_expires_at_ms,
                    },
                )
            })
            .collect();
        let claimed_ground_drops = self
            .claimed_ground_drops
            .iter()
            .map(|(object_id, claim)| {
                (
                    *object_id,
                    LegacyZoneGroundDropClaim {
                        session_id: &claim.session_id,
                        drop: &claim.drop,
                    },
                )
            })
            .collect();
        let state = LegacyCanonicalZoneState {
            version: LEGACY_CANONICAL_ZONE_STATE_VERSION,
            key: &self.key,
            collision: &self.collision,
            players: &self.players,
            objects: &self.objects,
            dead_object_ids: &self.dead_object_ids,
            revived_object_ids: &self.revived_object_ids,
            removed_object_ids: &self.removed_object_ids,
            harvested_object_ids: &self.harvested_object_ids,
            native_monsters: &monsters,
            pending_native_hits: &hits,
            pending_native_projectiles: &self.pending_native_projectiles,
            pending_native_player_hits: &self.pending_native_player_hits,
            pending_native_player_heals: &self.pending_native_player_heals,
            pending_native_summons: &self.pending_native_summons,
            pending_native_ground_spells: &self.pending_native_ground_spells,
            ground_drops,
            claimed_ground_drops,
            open_doors: &self.open_doors,
            hazard: &self.hazard,
            next_object_id: self.next_object_id,
        };
        let bytes = serde_json::to_vec(&state)
            .map_err(|error| format!("failed to serialize legacy canonical zone state: {error}"))?;
        let mut hasher = Sha256::new();
        hasher.update(LEGACY_CANONICAL_ZONE_STATE_DOMAIN);
        hasher.update(bytes);
        Ok(hex_lower(&hasher.finalize()))
    }

    fn legacy_v2_canonical_state_root(&self) -> Result<String, String> {
        let (monsters, hits) = self.legacy_ownership_free_monsters_and_hits();
        let (ground_drops, claimed_ground_drops) = self.legacy_ground_metadata_free_state();
        // v2 committed the original claim-scoped idempotency key. Keep this
        // schema exact so a v2 checkpoint is authenticated before the
        // post-verification v3 re-anchor removes claim_id from the economic
        // key. The claim id itself remains part of the ticket for ABA
        // protection; only the ledger identity changes.
        let state = CanonicalZoneState {
            version: LEGACY_V2_CANONICAL_ZONE_STATE_VERSION,
            key: &self.key,
            collision: &self.collision,
            players: &self.players,
            objects: &self.objects,
            dead_object_ids: &self.dead_object_ids,
            revived_object_ids: &self.revived_object_ids,
            removed_object_ids: &self.removed_object_ids,
            harvested_object_ids: &self.harvested_object_ids,
            native_monsters: &monsters,
            pending_native_hits: &hits,
            pending_native_projectiles: &self.pending_native_projectiles,
            pending_native_player_hits: &self.pending_native_player_hits,
            pending_native_player_heals: &self.pending_native_player_heals,
            pending_native_summons: &self.pending_native_summons,
            pending_native_ground_spells: &self.pending_native_ground_spells,
            ground_drops: &ground_drops,
            claimed_ground_drops: &claimed_ground_drops,
            next_ground_drop_generation: self.next_ground_drop_generation,
            next_ground_drop_claim_id: self.next_ground_drop_claim_id,
            open_doors: &self.open_doors,
            hazard: &self.hazard,
            next_object_id: self.next_object_id,
        };
        let bytes = serde_json::to_vec(&state).map_err(|error| {
            format!("failed to serialize legacy v2 canonical zone state: {error}")
        })?;
        let mut hasher = Sha256::new();
        hasher.update(LEGACY_V2_CANONICAL_ZONE_STATE_DOMAIN);
        hasher.update(bytes);
        Ok(hex_lower(&hasher.finalize()))
    }

    fn legacy_v3_canonical_state_root(&self) -> Result<String, String> {
        let (monsters, hits) = self.legacy_ownership_free_monsters_and_hits();
        let (ground_drops, claimed_ground_drops) = self.legacy_ground_metadata_free_state();
        let state = CanonicalZoneState {
            version: LEGACY_V3_CANONICAL_ZONE_STATE_VERSION,
            key: &self.key,
            collision: &self.collision,
            players: &self.players,
            objects: &self.objects,
            dead_object_ids: &self.dead_object_ids,
            revived_object_ids: &self.revived_object_ids,
            removed_object_ids: &self.removed_object_ids,
            harvested_object_ids: &self.harvested_object_ids,
            native_monsters: &monsters,
            pending_native_hits: &hits,
            pending_native_projectiles: &self.pending_native_projectiles,
            pending_native_player_hits: &self.pending_native_player_hits,
            pending_native_player_heals: &self.pending_native_player_heals,
            pending_native_summons: &self.pending_native_summons,
            pending_native_ground_spells: &self.pending_native_ground_spells,
            ground_drops: &ground_drops,
            claimed_ground_drops: &claimed_ground_drops,
            next_ground_drop_generation: self.next_ground_drop_generation,
            next_ground_drop_claim_id: self.next_ground_drop_claim_id,
            open_doors: &self.open_doors,
            hazard: &self.hazard,
            next_object_id: self.next_object_id,
        };
        let bytes = serde_json::to_vec(&state).map_err(|error| {
            format!("failed to serialize legacy v3 canonical zone state: {error}")
        })?;
        let mut hasher = Sha256::new();
        hasher.update(LEGACY_V3_CANONICAL_ZONE_STATE_DOMAIN);
        hasher.update(bytes);
        Ok(hex_lower(&hasher.finalize()))
    }

    fn hydrate_legacy_ground_drop_claim_authority(&mut self) -> Result<(), String> {
        // v1 state roots intentionally predate every field below. Once the
        // legacy root has verified, none of those uncommitted v2 fields can be
        // trusted: JSON can carry them even though the v1 root did not cover
        // them. Start from the v1 payload only, then rebuild the authority
        // deterministically in BTree/object-id order.
        self.next_ground_drop_generation = 0;
        self.next_ground_drop_claim_id = 0;
        for stored in self.ground_drops.values_mut() {
            stored.drop_generation = 0;
            stored.payload_digest.clear();
        }
        for claim in self.claimed_ground_drops.values_mut() {
            claim.ticket = None;
        }

        let mut next_generation = 1_u64;
        let mut next_claim_id = 1_u64;
        for stored in self.ground_drops.values_mut() {
            stored.drop_generation = next_generation;
            next_generation = next_generation
                .checked_add(1)
                .ok_or_else(|| "legacy ground drop generation space exhausted".to_string())?;
            stored.payload_digest = canonical_ground_drop_payload_digest(&stored.drop);
        }
        let key = self.key.clone();
        for (object_id, claim) in &mut self.claimed_ground_drops {
            let drop_generation = next_generation;
            next_generation = next_generation
                .checked_add(1)
                .ok_or_else(|| "legacy ground drop generation space exhausted".to_string())?;
            let claim_id = next_claim_id;
            next_claim_id = next_claim_id
                .checked_add(1)
                .ok_or_else(|| "legacy ground drop claim-id space exhausted".to_string())?;
            let payload_digest = canonical_ground_drop_payload_digest(&claim.drop);
            claim.ticket = Some(GroundDropClaimTicket {
                claim_id,
                object_id: *object_id,
                drop_generation,
                payload_digest: payload_digest.clone(),
                idempotency_key: canonical_ground_drop_claim_idempotency_key(
                    &key,
                    *object_id,
                    drop_generation,
                    &payload_digest,
                ),
                session_id: claim.session_id.clone(),
                owner_object_id: claim.drop.owner_object_id,
                drop: claim.drop.clone(),
            });
        }
        self.next_ground_drop_generation = next_generation.max(1);
        self.next_ground_drop_claim_id = next_claim_id.max(1);
        Ok(())
    }
    fn validate_ground_drop_claim_authority(&self) -> Result<(), String> {
        let mut max_generation = 0_u64;
        let mut max_claim_id = 0_u64;
        for (object_id, stored) in &self.ground_drops {
            if stored.drop.object_id != *object_id
                || stored.drop_generation == 0
                || stored.payload_digest != canonical_ground_drop_payload_digest(&stored.drop)
            {
                return Err(format!("invalid authoritative ground drop {object_id}"));
            }
            max_generation = max_generation.max(stored.drop_generation);
        }
        for (object_id, claim) in &self.claimed_ground_drops {
            let Some(ticket) = claim.ticket.as_ref() else {
                return Err(format!(
                    "claimed ground drop {object_id} is missing its ticket"
                ));
            };
            if ticket.object_id != *object_id
                || !self.ground_drop_claim_ticket_matches(claim, &claim.session_id, ticket)
            {
                return Err(format!("invalid claimed ground drop ticket {object_id}"));
            }
            max_generation = max_generation.max(ticket.drop_generation);
            max_claim_id = max_claim_id.max(ticket.claim_id);
        }
        if self.next_ground_drop_generation <= max_generation
            || self.next_ground_drop_claim_id <= max_claim_id
        {
            return Err(
                "ground-drop authority counters do not exceed persisted values".to_string(),
            );
        }
        Ok(())
    }

    fn validate_legacy_v2_ground_drop_claim_authority(&self) -> Result<(), String> {
        let mut max_generation = 0_u64;
        let mut max_claim_id = 0_u64;
        for (object_id, stored) in &self.ground_drops {
            if stored.drop.object_id != *object_id
                || stored.drop_generation == 0
                || stored.payload_digest != canonical_ground_drop_payload_digest(&stored.drop)
            {
                return Err(format!("invalid authoritative ground drop {object_id}"));
            }
            max_generation = max_generation.max(stored.drop_generation);
        }
        for (object_id, claim) in &self.claimed_ground_drops {
            let Some(ticket) = claim.ticket.as_ref() else {
                return Err(format!(
                    "claimed ground drop {object_id} is missing its legacy v2 ticket"
                ));
            };
            let legacy_key = legacy_v2_ground_drop_claim_idempotency_key(
                &self.key,
                ticket.object_id,
                ticket.drop_generation,
                ticket.claim_id,
                &ticket.payload_digest,
            );
            let stable_key = canonical_ground_drop_claim_idempotency_key(
                &self.key,
                ticket.object_id,
                ticket.drop_generation,
                &ticket.payload_digest,
            );
            // v2 was written with the claim-scoped key before this migration,
            // but short-lived v2 builds could already have emitted the stable
            // key. The v2 root authenticates the exact stored value in either
            // case; both forms are re-anchored to v3 below.
            if ticket.object_id != *object_id
                || claim.session_id != ticket.session_id
                || claim.drop != ticket.drop
                || ticket.object_id != ticket.drop.object_id
                || ticket.owner_object_id != ticket.drop.owner_object_id
                || ticket.claim_id == 0
                || ticket.drop_generation == 0
                || ticket.payload_digest.is_empty()
                || canonical_ground_drop_payload_digest(&ticket.drop) != ticket.payload_digest
                || (ticket.idempotency_key != legacy_key && ticket.idempotency_key != stable_key)
            {
                return Err(format!(
                    "invalid legacy v2 claimed ground drop ticket {object_id}"
                ));
            }
            max_generation = max_generation.max(ticket.drop_generation);
            max_claim_id = max_claim_id.max(ticket.claim_id);
        }
        if self.next_ground_drop_generation <= max_generation
            || self.next_ground_drop_claim_id <= max_claim_id
        {
            return Err(
                "legacy v2 ground-drop authority counters do not exceed persisted values"
                    .to_string(),
            );
        }
        Ok(())
    }

    fn reanchor_legacy_v2_ground_drop_claim_idempotency_keys(&mut self) {
        for claim in self.claimed_ground_drops.values_mut() {
            if let Some(ticket) = claim.ticket.as_mut() {
                ticket.idempotency_key = canonical_ground_drop_claim_idempotency_key(
                    &self.key,
                    ticket.object_id,
                    ticket.drop_generation,
                    &ticket.payload_digest,
                );
            }
        }
    }

    pub fn checkpoint_bytes(&self) -> Result<Vec<u8>, String> {
        let checkpoint = ZoneRuntimeCheckpoint {
            mining: Some(self.mining.clone()),
            online_presence: Some(self.online_presence.clone()),
            detached_ground_drop_custody: Some(self.detached_ground_drop_custody.clone()),
            issued_native_monster_awards: Some(self.issued_native_monster_awards.clone()),
            intelligent_creatures: self.intelligent_creatures.clone(),
            intelligent_creature_intents: self.intelligent_creature_intents.clone(),
            intelligent_creature_operations: self.intelligent_creature_operations.clone(),
            version: ZONE_RUNTIME_CHECKPOINT_VERSION,
            state_root: self.canonical_state_root()?,
            key: self.key.clone(),
            players: self.players.clone(),
            objects: self
                .objects
                .iter()
                .map(|(object_id, object)| Ok((*object_id, ZoneObjectCheckpoint::capture(object)?)))
                .collect::<Result<BTreeMap<_, _>, String>>()?,
            dead_object_ids: self.dead_object_ids.clone(),
            revived_object_ids: self.revived_object_ids.clone(),
            removed_object_ids: self.removed_object_ids.clone(),
            harvested_object_ids: self.harvested_object_ids.clone(),
            native_monsters: self.native_monsters.clone(),
            native_monster_respawns: self.native_monster_respawns.clone(),
            pending_native_hits: self.pending_native_hits.clone(),
            pending_native_projectiles: self.pending_native_projectiles.clone(),
            pending_native_player_hits: self.pending_native_player_hits.clone(),
            pending_native_player_heals: self.pending_native_player_heals.clone(),
            pending_native_summons: self.pending_native_summons.clone(),
            pending_native_ground_spells: self.pending_native_ground_spells.clone(),
            ground_drops: self.ground_drops.clone(),
            claimed_ground_drops: self.claimed_ground_drops.clone(),
            next_ground_drop_generation: self.next_ground_drop_generation,
            next_ground_drop_claim_id: self.next_ground_drop_claim_id,
            open_doors: self.open_doors.clone(),
            hazard: self.hazard.clone(),
            hell_world: self.hell_world.clone(),
            horned_encounter_world: self.horned_encounter_world.clone(),
            pet_special_world: self.pet_special_world.clone(),
            entity_combat: self.entity_combat.clone(),
            next_monster_incarnation: self.next_monster_incarnation,
            tree_queen_world: self.tree_queen_world.clone(),
            native_periodic_player_poisons: self.native_periodic_player_poisons.clone(),
            next_object_id: self.next_object_id,
        };
        serde_json::to_vec(&checkpoint)
            .map_err(|error| format!("failed to encode zone runtime checkpoint: {error}"))
    }

    pub fn restore_checkpoint(bytes: &[u8]) -> Result<Self, String> {
        Self::restore_checkpoint_with_policy(bytes, StateRootPolicy::Strict)
    }

    /// Restore bytes already covered by a verified, higher-level World
    /// Director checkpoint commitment and re-anchor them to the current signed
    /// game module. The canonical Zone root includes collision data, which is
    /// intentionally not duplicated in the checkpoint and can change between
    /// releases; a strict old root therefore cannot survive a module upgrade.
    pub(crate) fn restore_verified_world_checkpoint(bytes: &[u8]) -> Result<Self, String> {
        Self::restore_checkpoint_with_policy(
            bytes,
            StateRootPolicy::ReanchorVerifiedWorldCheckpoint,
        )
    }

    fn restore_checkpoint_with_policy(
        bytes: &[u8],
        state_root_policy: StateRootPolicy,
    ) -> Result<Self, String> {
        let checkpoint: ZoneRuntimeCheckpoint = serde_json::from_slice(bytes)
            .map_err(|error| format!("failed to decode zone runtime checkpoint: {error}"))?;
        if checkpoint.version != LEGACY_ZONE_RUNTIME_CHECKPOINT_VERSION
            && checkpoint.version != LEGACY_V2_ZONE_RUNTIME_CHECKPOINT_VERSION
            && checkpoint.version != LEGACY_V3_ZONE_RUNTIME_CHECKPOINT_VERSION
            && checkpoint.version != LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION
            && checkpoint.version != LEGACY_V5_ZONE_RUNTIME_CHECKPOINT_VERSION
            && checkpoint.version != LEGACY_V6_ZONE_RUNTIME_CHECKPOINT_VERSION
            && checkpoint.version != ZONE_RUNTIME_CHECKPOINT_VERSION
        {
            return Err(format!(
                "unsupported zone runtime checkpoint version {}, expected {}, {}, {}, {}, {}, {}, or {}",
                checkpoint.version,
                LEGACY_ZONE_RUNTIME_CHECKPOINT_VERSION,
                LEGACY_V2_ZONE_RUNTIME_CHECKPOINT_VERSION,
                LEGACY_V3_ZONE_RUNTIME_CHECKPOINT_VERSION,
                LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION,
                LEGACY_V5_ZONE_RUNTIME_CHECKPOINT_VERSION,
                LEGACY_V6_ZONE_RUNTIME_CHECKPOINT_VERSION,
                ZONE_RUNTIME_CHECKPOINT_VERSION
            ));
        }
        let checkpoint_version = checkpoint.version;
        let expected_state_root = checkpoint.state_root.clone();
        for (session_id, player) in &checkpoint.players {
            if session_id != &player.session_id {
                return Err(format!(
                    "zone runtime checkpoint player key {} does not match embedded session {}",
                    session_id.as_str(),
                    player.session_id.as_str()
                ));
            }
        }
        for (object_id, object) in &checkpoint.objects {
            if object_id != &object.object_id {
                return Err(format!(
                    "zone runtime checkpoint object key {object_id} does not match embedded id {}",
                    object.object_id
                ));
            }
        }

        let mut runtime = Self::new(checkpoint.key);
        // Legacy roots never committed mining fields. Discard any injected
        // forward data before authenticating their old schema commitment.
        if checkpoint_version>=7 {runtime.mining=checkpoint.mining.unwrap_or_default();}
        runtime.players = checkpoint.players;
        runtime.objects = checkpoint
            .objects
            .into_iter()
            .map(|(object_id, object)| Ok((object_id, object.restore()?)))
            .collect::<Result<BTreeMap<_, _>, String>>()?;
        runtime.dead_object_ids = checkpoint.dead_object_ids;
        runtime.revived_object_ids = checkpoint.revived_object_ids;
        runtime.removed_object_ids = checkpoint.removed_object_ids;
        runtime.harvested_object_ids = checkpoint.harvested_object_ids;
        runtime.native_monsters = checkpoint.native_monsters;
        runtime.native_monster_respawns = checkpoint.native_monster_respawns;
        if checkpoint_version >= LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION {
            runtime.intelligent_creatures = checkpoint.intelligent_creatures;
            runtime.intelligent_creature_intents = checkpoint.intelligent_creature_intents;
            runtime.intelligent_creature_operations = checkpoint.intelligent_creature_operations;
        }
        if checkpoint_version < LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION {
            // v1-v3 roots did not commit respawn policy/due state. Ignore any
            // forward fields injected into legacy JSON before authenticating
            // and re-anchoring it under the current schema.
            runtime.native_monster_respawns.clear();
        }
        for monster in runtime.native_monsters.values_mut() {
            // Legacy checkpoints had only the AI-derived boolean. Without the
            // explicit authoritative disposition they must remain untargetable
            // and must not target players.
            monster.hostile_to_player =
                monster.disposition == Some(crate::config::WorldEntityDisposition::Hostile);
        }
        runtime.pending_native_hits = checkpoint.pending_native_hits;
        if checkpoint_version < LEGACY_V5_ZONE_RUNTIME_CHECKPOINT_VERSION {
            // v1-v4 roots never committed generic EXPOwner or the successful
            // TurnUndead impact flag. Ignore injected forward fields before
            // legacy authentication; they cannot become reward authority.
            for monster in runtime.native_monsters.values_mut() {
                monster.experience_owner = None;
            }
            for hit in &mut runtime.pending_native_hits {
                hit.force_experience_owner = false;
            }
        }
        runtime.pending_native_projectiles = checkpoint.pending_native_projectiles;
        runtime.pending_native_player_hits = checkpoint.pending_native_player_hits;
        runtime.pending_native_player_heals = checkpoint.pending_native_player_heals;
        runtime.pending_native_summons = checkpoint.pending_native_summons;
        runtime.pending_native_ground_spells = checkpoint.pending_native_ground_spells;
        runtime.ground_drops = checkpoint.ground_drops;
        runtime.claimed_ground_drops = checkpoint.claimed_ground_drops;
        runtime.online_presence = checkpoint.online_presence.unwrap_or_default();
        runtime.detached_ground_drop_custody = checkpoint.detached_ground_drop_custody.unwrap_or_default();
        runtime.issued_native_monster_awards = checkpoint.issued_native_monster_awards.unwrap_or_default();
        runtime.next_ground_drop_generation = checkpoint.next_ground_drop_generation;
        runtime.next_ground_drop_claim_id = checkpoint.next_ground_drop_claim_id;
        runtime.open_doors = checkpoint.open_doors;
        runtime.hazard = checkpoint.hazard;
        if checkpoint_version >= LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION {
            runtime.hell_world = checkpoint.hell_world;
            runtime.horned_encounter_world = checkpoint.horned_encounter_world;
            runtime.pet_special_world = checkpoint.pet_special_world;
            runtime.entity_combat = checkpoint.entity_combat;
            runtime.next_monster_incarnation = checkpoint.next_monster_incarnation;
            runtime.tree_queen_world = checkpoint.tree_queen_world;
            runtime.native_periodic_player_poisons = checkpoint.native_periodic_player_poisons;
        }
        // Legacy commitments do not authenticate these forward fields.

        runtime.next_monster_incarnation = runtime.next_monster_incarnation.max(
            runtime
                .native_monsters
                .values()
                .map(|m| m.incarnation)
                .max()
                .unwrap_or(0),
        );
        runtime.next_object_id = checkpoint.next_object_id;

        for door_index in runtime.open_doors.keys().copied().collect::<Vec<_>>() {
            runtime.collision.open_door(door_index);
        }
        for (session_id, player) in &runtime.players {
            let tile = (player.position.x, player.position.y);
            if runtime.occupancy.insert(tile, session_id.clone()).is_some() {
                return Err(format!(
                    "zone runtime checkpoint has multiple players at {},{}",
                    tile.0, tile.1
                ));
            }
            runtime
                .player_grid
                .insert(session_id.clone(), &player.position);
            runtime
                .ecs
                .upsert_player(session_id, player.object_id, &player.position);
        }
        for (object_id, object) in &runtime.objects {
            runtime.object_grid.insert(*object_id, &object.position);
        }

        let restored_root = match checkpoint_version {
            LEGACY_ZONE_RUNTIME_CHECKPOINT_VERSION => runtime.legacy_canonical_state_root()?,
            LEGACY_V2_ZONE_RUNTIME_CHECKPOINT_VERSION => {
                runtime.legacy_v2_canonical_state_root()?
            }
            LEGACY_V3_ZONE_RUNTIME_CHECKPOINT_VERSION => {
                runtime.legacy_v3_canonical_state_root()?
            }
            LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION => {
                runtime.legacy_v4_canonical_state_root()?
            }
            LEGACY_V5_ZONE_RUNTIME_CHECKPOINT_VERSION => runtime.legacy_v5_canonical_state_root()?,
            LEGACY_V6_ZONE_RUNTIME_CHECKPOINT_VERSION => runtime.legacy_v6_canonical_state_root()?,
            ZONE_RUNTIME_CHECKPOINT_VERSION => runtime.canonical_state_root()?,
            _ => unreachable!("checkpoint version was validated above"),
        };
        if restored_root != expected_state_root && state_root_policy == StateRootPolicy::Strict {
            return Err(format!(
                "zone runtime checkpoint state root mismatch: expected {}, got {restored_root}",
                expected_state_root
            ));
        }
        // Only now has the ORIGINAL legacy canonical shape been verified.
        // New-looking metadata on v1-v5 bytes was never committed by that root.
        if checkpoint_version < LEGACY_V6_ZONE_RUNTIME_CHECKPOINT_VERSION {
            for stored in runtime.ground_drops.values_mut() { stored.native_owner = None; }
            for claim in runtime.claimed_ground_drops.values_mut() { claim.custody = None; }
            runtime.detached_ground_drop_custody.clear();
        } else {
            runtime.validate_native_ground_custody()?;
        }
        match checkpoint_version {
            LEGACY_ZONE_RUNTIME_CHECKPOINT_VERSION => {
                runtime.hydrate_legacy_ground_drop_claim_authority()?;
            }
            LEGACY_V2_ZONE_RUNTIME_CHECKPOINT_VERSION => {
                runtime.validate_legacy_v2_ground_drop_claim_authority()?;
                runtime.reanchor_legacy_v2_ground_drop_claim_idempotency_keys();
                runtime.validate_ground_drop_claim_authority()?;
            }
            LEGACY_V3_ZONE_RUNTIME_CHECKPOINT_VERSION | LEGACY_V4_ZONE_RUNTIME_CHECKPOINT_VERSION | LEGACY_V5_ZONE_RUNTIME_CHECKPOINT_VERSION => {
                runtime.validate_ground_drop_claim_authority()?;
            }
            LEGACY_V6_ZONE_RUNTIME_CHECKPOINT_VERSION | ZONE_RUNTIME_CHECKPOINT_VERSION => {
                runtime.validate_ground_drop_claim_authority()?;
            }
            _ => unreachable!("checkpoint version was validated above"),
        }
        runtime.validate_intelligent_creature_checkpoint()?;
        // Public deserialization is cold recovery, never an online Node mint.
        // Retained live-runtime resume does not deserialize these bytes.
        runtime.clear_online_authority();
        Ok(runtime)
    }
}

fn hex_lower(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut output = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        output.push(HEX[(byte >> 4) as usize] as char);
        output.push(HEX[(byte & 0x0f) as usize] as char);
    }
    output
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::{GroundDropLootSnapshot, GroundDropSnapshot};
    use crate::runtime::zone::types::{
        ZoneChatProfile, ZoneCommand, ZoneJoin, ZoneMonsterDefense, ZoneMonsterRespawnPolicy,
        ZoneMonsterSpawn, ZoneOutbound, ZonePlayerCombatStats,
    };
    use mir2_protocol::{MirClass, MirDirection, MirGender};

    #[test]
    fn mining_schema_seven_round_trip_and_integrity() {
        // Use the map's own collision identity; checkpoint recovery must never
        // substitute a synthetic test collision for a signed map's collision.
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("mining-checkpoint-fixture"));
        runtime.mining = serde_json::from_value(serde_json::json!({
            "spots": {"5,4": {"stones_left":27,"regen_at_ms":300_001}},
            "sequence":3,"effects":[]
        })).unwrap();
        let bytes = runtime.checkpoint_bytes().unwrap();
        let restored = ZoneRuntime::restore_checkpoint(&bytes).unwrap();
        assert_eq!(serde_json::to_value(&restored.mining).unwrap(), serde_json::to_value(&runtime.mining).unwrap());
        for field in ["sequence", "stones_left", "regen_at_ms"] {
            let mut altered: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
            if field == "sequence" { altered["mining"][field] = serde_json::json!(4); }
            else { altered["mining"]["spots"]["5,4"][field] = serde_json::json!(99); }
            assert!(ZoneRuntime::restore_checkpoint(&serde_json::to_vec(&altered).unwrap())
                .unwrap_err().contains("state root mismatch"));
        }
    }

    #[test]
    fn legacy_v6_retains_authenticated_custody_and_discards_unbound_mining() {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("legacy-v6-mining-policy"));
        runtime.handle(ZoneCommand::Join(ZoneJoin {
            session_id: SessionId::new("v6-owner"), account_id: "v6-account".into(),
            character_index: 1, object_id: 501, name: "Owner".into(), class: MirClass::Warrior,
            gender: MirGender::Male, level: 20, hp: 100, max_hp: 100, mp: 0,
            map_file_name: "legacy-v6-mining-policy".into(), position: Point { x: 11, y: 34 },
            direction: MirDirection::Right, chat_profile: Default::default(),
            combat_stats: Default::default(),
        }));
        let mut drop = checkpoint_gold_drop(703);
        drop.owner_object_id = Some(501);
        let mut stored = runtime.new_zone_ground_drop(drop, Some(60_100)).unwrap();
        stored.native_owner = runtime.bind_native_ground_owner(501, 100);
        let custody = runtime.capture_ground_drop_custody(&stored);
        assert!(custody.native_owner.is_some());
        runtime.detached_ground_drop_custody.insert(703, custody.clone());
        runtime.removed_object_ids.insert(703);
        let mut fixture: serde_json::Value = serde_json::from_slice(&runtime.checkpoint_bytes().unwrap()).unwrap();
        fixture["version"] = serde_json::json!(6);
        fixture["state_root"] = serde_json::json!(runtime.legacy_v6_canonical_state_root().unwrap());
        fixture["mining"] = serde_json::json!({"spots":{"5,4":{"stones_left":79,"regen_at_ms":999}},
            "sequence":999,"effects":[]});
        let restored = ZoneRuntime::restore_checkpoint(&serde_json::to_vec(&fixture).unwrap()).unwrap();
        assert_eq!(serde_json::to_value(&restored.mining).unwrap(),
            serde_json::json!({"spots":{},"sequence":0,"effects":[]}));
        assert_eq!(serde_json::to_value(&restored.detached_ground_drop_custody[&703]).unwrap(),
            serde_json::to_value(&custody).unwrap());
        assert!(restored.online_presence.is_empty(), "cold recovery cannot mint online authority");
        fixture["detached_ground_drop_custody"]["703"]["payload_digest"] = serde_json::json!("tampered");
        assert!(ZoneRuntime::restore_checkpoint(&serde_json::to_vec(&fixture).unwrap())
            .unwrap_err().contains("state root mismatch"));
    }

    #[test]
    fn legacy_v5_authenticates_original_item_before_ignoring_unbound_forward_owner_fields() {
        let mut runtime=ZoneRuntime::new(ZoneKey::for_map("legacy-v5-native-policy"));
        let mut drop=checkpoint_gold_drop(701); drop.owner_object_id=Some(501);
        let stored=runtime.new_zone_ground_drop(drop,Some(6_000)).unwrap();
        runtime.ground_drops.insert(701,stored);
        let mut fixture:serde_json::Value=serde_json::from_slice(&runtime.checkpoint_bytes().unwrap()).unwrap();
        fixture["version"]=serde_json::json!(5);
        fixture["state_root"]=serde_json::json!(runtime.legacy_v5_canonical_state_root().unwrap());
        let proof=serde_json::json!({"namespace":"00112233445566778899aabbccddeeff","epoch":7,
            "session_id":"forged-old-online","account_id":"forged-account","character_index":1,"object_id":501});
        fixture["ground_drops"]["701"]["native_owner"]=serde_json::json!({
            "owner":proof,"source":runtime.key,"born_at_ms":0,"expires_at_ms":60000});
        fixture["online_presence"]=serde_json::json!({"forged-old-online":{
            "owner":proof,"key":runtime.key,"dead":false,"name":"forged-name","group_members":[]}});
        fixture["issued_native_monster_awards"]=serde_json::json!({"forged-issued-key":proof});
        let restored=ZoneRuntime::restore_checkpoint(&serde_json::to_vec(&fixture).unwrap()).unwrap();
        assert!(restored.online_presence.is_empty()); assert!(restored.issued_native_monster_awards.is_empty());
        assert!(restored.ground_drops[&701].native_owner.is_none());
        assert_eq!(restored.ground_drops[&701].owner_expires_at_ms,None);
        assert_eq!(restored.ground_drops[&701].drop.loot,GroundDropLootSnapshot::Gold{amount:25});
        fixture["ground_drops"]["701"]["drop"]["loot"]["amount"]=serde_json::json!(26);
        assert!(ZoneRuntime::restore_checkpoint(&serde_json::to_vec(&fixture).unwrap()).unwrap_err().contains("state root mismatch"));
    }

    #[test]
    fn new_online_metadata_is_integrity_bound_but_cold_decode_never_grants_authority() {
        let mut runtime=ZoneRuntime::new(ZoneKey::for_map("cold-native-policy"));
        runtime.handle(ZoneCommand::Join(ZoneJoin{session_id:SessionId::new("original-online"),
            account_id:"original-account".into(),character_index:1,object_id:501,name:"Owner".into(),
            class:MirClass::Warrior,gender:MirGender::Male,level:20,hp:100,max_hp:100,mp:0,
            map_file_name:"cold-native-policy".into(),position:Point{x:11,y:34},direction:MirDirection::Right,
            chat_profile:Default::default(),combat_stats:Default::default()}));
        let mut drop=checkpoint_gold_drop(702); drop.owner_object_id=Some(501);
        let mut stored=runtime.new_zone_ground_drop(drop,Some(60_100)).unwrap();
        stored.native_owner=runtime.bind_native_ground_owner(501,100);
        runtime.ground_drops.insert(702,stored);
        let bytes=runtime.checkpoint_bytes().unwrap();
        let restored=ZoneRuntime::restore_checkpoint(&bytes).unwrap();
        assert!(restored.online_presence.is_empty());
        assert_eq!(restored.ground_drops[&702].owner_expires_at_ms,None);
        assert_eq!(restored.ground_drops[&702].drop.owner_object_id,Some(501),"immutable loot identity remains");
        let mut changed:serde_json::Value=serde_json::from_slice(&bytes).unwrap();
        changed["ground_drops"]["702"]["native_owner"]["owner"]["epoch"]=serde_json::json!(99);
        assert!(ZoneRuntime::restore_checkpoint(&serde_json::to_vec(&changed).unwrap()).unwrap_err().contains("state root mismatch"));
    }

    fn checkpoint_gold_drop(object_id: u32) -> GroundDropSnapshot {
        GroundDropSnapshot {
            object_id,
            name: "Gold".to_string(),
            name_colour_argb: -1,
            icon: 0,
            x: 12,
            y: 34,
            quantity: 1,
            source_monster: "legacy-checkpoint".to_string(),
            owner_object_id: None,
            ownership_remaining_ticks: Some(20),
            loot: GroundDropLootSnapshot::Gold { amount: 25 },
        }
    }

    fn checkpoint_scheduled_monster(object_id: u32) -> ZoneMonsterSpawn {
        ZoneMonsterSpawn {
            crystal_drop_seed: None,
            object_id,
            name: "CheckpointWasp".to_string(),
            name_colour_argb: -1,
            image: 0,
            ai: 0,
            disposition: Some(crate::config::WorldEntityDisposition::Hostile),
            level: 1,
            max_hp: 20,
            hp: 20,
            experience: 0,
            move_speed_ms: 0,
            attack_speed_ms: 0,
            friendly_guild: None,
            position: Point { x: 30, y: 30 },
            direction: MirDirection::Down,
            defense: ZoneMonsterDefense::default(),
            respawn: Some(ZoneMonsterRespawnPolicy {
                minimum_delay_ms: 0,
                base_delay_ms: 100,
                random_delay_step_ms: 0,
                random_delay_steps: 1,
                random_delay_subtract_steps: 0,
                rule_index: 0,
                slot_index: 0,
            }),
            drops: Vec::new(),
        }
    }

    /// A real v1-shaped fixture: every authority field added by v2 is absent,
    /// and the root is calculated from the v1 canonical schema only.
    fn legacy_v1_ground_drop_fixture() -> serde_json::Value {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("legacy-drop-map"));
        let active = checkpoint_gold_drop(101);
        let active_stored = runtime
            .new_zone_ground_drop(active.clone(), Some(6_000))
            .expect("ground-drop generation");
        runtime.ground_drops.insert(active.object_id, active_stored);

        let claimed = checkpoint_gold_drop(102);
        runtime.claimed_ground_drops.insert(
            claimed.object_id,
            ZoneGroundDropClaim {
                session_id: SessionId::new("legacy-claimer"),
                drop: claimed,
                ticket: None,
                custody: None,
            },
        );
        let legacy_root = runtime
            .legacy_canonical_state_root()
            .expect("legacy fixture root");
        let mut fixture: serde_json::Value =
            serde_json::from_slice(&runtime.checkpoint_bytes().expect("checkpoint source bytes"))
                .expect("checkpoint JSON");
        fixture["version"] = serde_json::json!(LEGACY_ZONE_RUNTIME_CHECKPOINT_VERSION);
        fixture["state_root"] = serde_json::json!(legacy_root);
        fixture
            .as_object_mut()
            .expect("checkpoint object")
            .remove("next_ground_drop_generation");
        fixture
            .as_object_mut()
            .expect("checkpoint object")
            .remove("next_ground_drop_claim_id");
        for stored in fixture["ground_drops"]
            .as_object_mut()
            .expect("ground drops")
            .values_mut()
        {
            let stored = stored.as_object_mut().expect("ground drop object");
            stored.remove("drop_generation");
            stored.remove("payload_digest");
        }
        for claim in fixture["claimed_ground_drops"]
            .as_object_mut()
            .expect("claimed ground drops")
            .values_mut()
        {
            claim
                .as_object_mut()
                .expect("claimed ground drop object")
                .remove("ticket");
        }
        fixture
    }

    #[test]
    fn exact_ground_drop_identity_is_checkpointed_and_state_root_protected() {
        use crate::config::{GroundDropItemPayload, GroundDropLootSnapshot, GroundDropSnapshot};
        use mir2_protocol::{UserItem, UserItemExpireInfo, UserItemStat};

        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("drop-identity-checkpoint"));
        let exact_item = GroundDropItemPayload {
            item: UserItem {
                unique_id: 8_888,
                item_index: 404,
                current_dura: 4_321,
                max_dura: 5_432,
                count: 1,
                soul_bound_id: 17,
                identified: false,
                cursed: true,
                slots: Vec::new(),
                gem_count: 0,
                added_stats: vec![UserItemStat { stat: 17, value: 9 }],
                awake_type: 2,
                awake_values: vec![3, 4],
                refined_value: 5,
                refine_added: 6,
                refine_success_chance: 77,
                wedding_ring: 23,
                expire_info: Some(UserItemExpireInfo {
                    expiry_binary_datetime: 123_456,
                }),
                rental_information: None,
                is_shop_item: true,
                sealed_info: None,
                gm_made: true,
            },
            uid_assigned: true,
        };
        let snapshot = GroundDropSnapshot {
            object_id: 91,
            name: "CopperRing".to_string(),
            name_colour_argb: -1,
            icon: 0,
            x: 12,
            y: 34,
            quantity: 1,
            source_monster: "checkpoint-test".to_string(),
            owner_object_id: None,
            ownership_remaining_ticks: None,
            loot: GroundDropLootSnapshot::InventoryItem {
                key: "crystal-item-404".to_string(),
                name: "CopperRing".to_string(),
                description: String::new(),
                weight: 1,
                durability_current: Some(4_321),
                durability_max: Some(5_432),
                added_attack: 0,
                added_defence: 0,
                added_stats: vec![UserItemStat { stat: 17, value: 9 }],
                cursed: true,
                socket_slots: 0,
                show_group_pickup: false,
                exact_item: Some(exact_item),
            },
        };
        let stored = runtime
            .new_zone_ground_drop(snapshot.clone(), None)
            .expect("ground-drop generation");
        runtime.ground_drops.insert(snapshot.object_id, stored);
        let mut claimed_snapshot = snapshot.clone();
        claimed_snapshot.object_id = 92;
        let claimed_stored = runtime
            .new_zone_ground_drop(claimed_snapshot.clone(), None)
            .expect("ground-drop generation");
        let claim_id = runtime
            .allocate_ground_drop_claim_id()
            .expect("ground-drop claim id");
        let claim_session_id = SessionId::new("drop-identity-claim");
        let ticket = GroundDropClaimTicket {
            claim_id,
            object_id: claimed_snapshot.object_id,
            drop_generation: claimed_stored.drop_generation,
            payload_digest: claimed_stored.payload_digest.clone(),
            idempotency_key: canonical_ground_drop_claim_idempotency_key(
                &runtime.key,
                claimed_snapshot.object_id,
                claimed_stored.drop_generation,
                &claimed_stored.payload_digest,
            ),
            session_id: claim_session_id.clone(),
            owner_object_id: claimed_snapshot.owner_object_id,
            drop: claimed_snapshot.clone(),
        };
        runtime.claimed_ground_drops.insert(
            claimed_snapshot.object_id,
            ZoneGroundDropClaim {
                session_id: claim_session_id,
                drop: claimed_snapshot.clone(),
                ticket: Some(ticket),
                custody: None,
            },
        );

        let bytes = runtime.checkpoint_bytes().expect("identity checkpoint");
        let restored = ZoneRuntime::restore_checkpoint(&bytes).expect("identity restore");
        assert_eq!(
            restored
                .ground_drops
                .get(&snapshot.object_id)
                .expect("restored ground drop")
                .drop,
            snapshot
        );
        assert_eq!(
            restored
                .claimed_ground_drops
                .get(&claimed_snapshot.object_id)
                .expect("restored claimed ground drop")
                .drop,
            claimed_snapshot
        );

        let mut checkpoint: ZoneRuntimeCheckpoint =
            serde_json::from_slice(&bytes).expect("checkpoint JSON");
        let GroundDropLootSnapshot::InventoryItem {
            exact_item: Some(exact_item),
            ..
        } = &mut checkpoint
            .claimed_ground_drops
            .get_mut(&92)
            .expect("checkpoint claimed ground drop")
            .drop
            .loot
        else {
            panic!("exact checkpoint payload");
        };
        exact_item.item.awake_type = exact_item.item.awake_type.saturating_add(1);
        let tampered = serde_json::to_vec(&checkpoint).expect("tampered identity checkpoint");
        let error = ZoneRuntime::restore_checkpoint(&tampered)
            .expect_err("identity tamper must fail state-root verification");
        assert!(error.contains("state root mismatch"), "{error}");
    }

    #[test]
    fn legacy_v2_checkpoint_verifies_old_root_then_reanchors_pending_ticket_key() {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("legacy-v2-drop-map"));
        let claimed_snapshot = checkpoint_gold_drop(202);
        let stored = runtime
            .new_zone_ground_drop(claimed_snapshot.clone(), None)
            .expect("ground-drop generation");
        let claim_id = runtime
            .allocate_ground_drop_claim_id()
            .expect("ground-drop claim id");
        let session_id = SessionId::new("legacy-v2-claimer");
        let legacy_ticket = GroundDropClaimTicket {
            claim_id,
            object_id: claimed_snapshot.object_id,
            drop_generation: stored.drop_generation,
            payload_digest: stored.payload_digest.clone(),
            idempotency_key: legacy_v2_ground_drop_claim_idempotency_key(
                &runtime.key,
                claimed_snapshot.object_id,
                stored.drop_generation,
                claim_id,
                &stored.payload_digest,
            ),
            session_id: session_id.clone(),
            owner_object_id: claimed_snapshot.owner_object_id,
            drop: claimed_snapshot.clone(),
        };
        runtime.claimed_ground_drops.insert(
            claimed_snapshot.object_id,
            ZoneGroundDropClaim {
                session_id: session_id.clone(),
                drop: claimed_snapshot,
                ticket: Some(legacy_ticket.clone()),
                custody: None,
            },
        );
        let legacy_root = runtime
            .legacy_v2_canonical_state_root()
            .expect("legacy v2 checkpoint root");
        let mut checkpoint: ZoneRuntimeCheckpoint = serde_json::from_slice(
            &runtime
                .checkpoint_bytes()
                .expect("current checkpoint source bytes"),
        )
        .expect("checkpoint JSON");
        checkpoint.version = LEGACY_V2_ZONE_RUNTIME_CHECKPOINT_VERSION;
        checkpoint.state_root = legacy_root;
        checkpoint
            .claimed_ground_drops
            .get_mut(&legacy_ticket.object_id)
            .and_then(|claim| claim.ticket.as_mut())
            .expect("legacy v2 ticket")
            .idempotency_key = legacy_ticket.idempotency_key.clone();

        let mut forged = checkpoint.clone();
        forged
            .claimed_ground_drops
            .get_mut(&legacy_ticket.object_id)
            .and_then(|claim| claim.ticket.as_mut())
            .expect("forged legacy v2 ticket")
            .claim_id = legacy_ticket.claim_id.saturating_add(1);
        let error = ZoneRuntime::restore_checkpoint(
            &serde_json::to_vec(&forged).expect("forged legacy v2 checkpoint bytes"),
        )
        .expect_err("v2 fields outside the verified root must fail closed");
        assert!(error.contains("state root mismatch"), "{error}");

        let restored = ZoneRuntime::restore_checkpoint(
            &serde_json::to_vec(&checkpoint).expect("legacy v2 checkpoint bytes"),
        )
        .expect("strict v2 checkpoint restore");
        let ticket = restored
            .claimed_ground_drops
            .get(&legacy_ticket.object_id)
            .and_then(|claim| claim.ticket.as_ref())
            .expect("re-anchored pending ticket");
        assert_eq!(ticket.claim_id, legacy_ticket.claim_id);
        assert_eq!(ticket.session_id, legacy_ticket.session_id);
        assert_eq!(ticket.drop, legacy_ticket.drop);
        assert_eq!(
            ticket.idempotency_key,
            canonical_ground_drop_claim_idempotency_key(
                &restored.key,
                ticket.object_id,
                ticket.drop_generation,
                &ticket.payload_digest,
            )
        );
        assert_ne!(ticket.idempotency_key, legacy_ticket.idempotency_key);
        assert!(restored.has_pending_ground_drop_claim_ticket(&session_id, ticket));

        // A short-lived v2 writer could already emit the stable key before the
        // checkpoint version bump. Its v2 root still commits that exact shape,
        // so it restores through the same re-anchor path.
        let mut already_stable_v2: ZoneRuntimeCheckpoint = serde_json::from_slice(
            &restored
                .checkpoint_bytes()
                .expect("stable v2 source checkpoint bytes"),
        )
        .expect("stable v2 source checkpoint JSON");
        already_stable_v2.version = LEGACY_V2_ZONE_RUNTIME_CHECKPOINT_VERSION;
        already_stable_v2.state_root = restored
            .legacy_v2_canonical_state_root()
            .expect("stable v2 checkpoint root");
        let restored_stable_v2 = ZoneRuntime::restore_checkpoint(
            &serde_json::to_vec(&already_stable_v2).expect("stable v2 checkpoint bytes"),
        )
        .expect("strict stable v2 checkpoint restore");
        assert!(restored_stable_v2.has_pending_ground_drop_claim_ticket(&session_id, ticket));

        let reanchored: ZoneRuntimeCheckpoint = serde_json::from_slice(
            &restored
                .checkpoint_bytes()
                .expect("re-anchored checkpoint bytes"),
        )
        .expect("re-anchored checkpoint JSON");
        assert_eq!(reanchored.version, ZONE_RUNTIME_CHECKPOINT_VERSION);
    }
    #[test]
    fn legacy_v3_checkpoint_ignores_forward_respawn_and_live_sync_rehydrates_policy() {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("legacy-v3-respawn-map"));
        let spawn = checkpoint_scheduled_monster(8_301);
        assert!(runtime.spawn_world_event_monster(&spawn, 0).0);
        let mut checkpoint: ZoneRuntimeCheckpoint = serde_json::from_slice(
            &runtime
                .checkpoint_bytes()
                .expect("current checkpoint source bytes"),
        )
        .expect("current checkpoint JSON");
        checkpoint.version = LEGACY_V3_ZONE_RUNTIME_CHECKPOINT_VERSION;
        checkpoint
            .native_monster_respawns
            .get_mut(&spawn.object_id)
            .expect("forward-injected respawn")
            .due_at_ms = Some(0);
        checkpoint.state_root = runtime
            .legacy_v3_canonical_state_root()
            .expect("legacy v3 state root");

        let mut restored = ZoneRuntime::restore_checkpoint(
            &serde_json::to_vec(&checkpoint).expect("legacy v3 checkpoint bytes"),
        )
        .expect("strict legacy v3 restore");
        assert!(restored.native_monster_respawns.is_empty());
        assert!(
            !restored
                .spawn_authoritative_monster_internal(&spawn, 1_000, false, false)
                .0
        );
        let hydrated = restored
            .native_monster_respawns
            .get(&spawn.object_id)
            .expect("trusted live sync must rehydrate policy");
        assert_eq!(hydrated.due_at_ms, None);
        let reanchored: ZoneRuntimeCheckpoint = serde_json::from_slice(
            &restored
                .checkpoint_bytes()
                .expect("re-anchored v4 checkpoint bytes"),
        )
        .expect("re-anchored v4 checkpoint JSON");
        assert_eq!(reanchored.version, ZONE_RUNTIME_CHECKPOINT_VERSION);
        assert!(reanchored
            .native_monster_respawns
            .contains_key(&spawn.object_id));
    }

    #[test]
    fn legacy_v3_dead_monster_policy_hydration_never_revives_immediately() {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("legacy-v3-dead-map"));
        let spawn = checkpoint_scheduled_monster(8_302);
        assert!(runtime.spawn_world_event_monster(&spawn, 0).0);
        let monster = runtime
            .native_monsters
            .get_mut(&spawn.object_id)
            .expect("scheduled monster");
        monster.dead = true;
        monster.hp = 0;
        runtime
            .native_monster_respawns
            .get_mut(&spawn.object_id)
            .expect("scheduled policy")
            .due_at_ms = Some(1);
        let mut checkpoint: ZoneRuntimeCheckpoint = serde_json::from_slice(
            &runtime
                .checkpoint_bytes()
                .expect("current checkpoint bytes"),
        )
        .expect("current checkpoint JSON");
        checkpoint.version = LEGACY_V3_ZONE_RUNTIME_CHECKPOINT_VERSION;
        checkpoint.state_root = runtime
            .legacy_v3_canonical_state_root()
            .expect("legacy v3 state root");

        let mut restored = ZoneRuntime::restore_checkpoint(
            &serde_json::to_vec(&checkpoint).expect("legacy v3 checkpoint bytes"),
        )
        .expect("strict legacy v3 restore");
        assert!(restored.native_monster_respawns.is_empty());
        let (changed, outbounds) =
            restored.spawn_authoritative_monster_internal(&spawn, 5_000, false, false);
        assert!(!changed);
        assert!(outbounds.is_empty());
        assert!(restored
            .native_monsters
            .get(&spawn.object_id)
            .is_some_and(|monster| monster.dead && monster.hp == 0));
        assert_eq!(
            restored
                .native_monster_respawns
                .get(&spawn.object_id)
                .and_then(|respawn| respawn.due_at_ms),
            Some(5_100)
        );
    }

    #[test]
    fn complete_zone_checkpoint_restores_authoritative_and_derived_state() {
        let session_id = SessionId::new("checkpoint-player");
        let mut runtime = ZoneRuntime::new_with_collision(
            ZoneKey::for_map("checkpoint-map"),
            ZoneCollision::unbounded(),
        );
        runtime.handle(ZoneCommand::Join(ZoneJoin {
            session_id: session_id.clone(),
            account_id: "checkpoint-account".to_string(),
            character_index: 7,
            object_id: 77,
            name: "Checkpoint".to_string(),
            class: MirClass::Warrior,
            gender: MirGender::Male,
            level: 12,
            hp: 55,
            max_hp: 80,
            mp: 21,
            map_file_name: "checkpoint-map".to_string(),
            position: Point { x: 14, y: 27 },
            direction: MirDirection::DownRight,
            chat_profile: ZoneChatProfile::default(),
            combat_stats: ZonePlayerCombatStats::default(),
        }));
        runtime.handle(ZoneCommand::SyncPlayerVitals {
            session_id: session_id.clone(),
            hp: 43,
            max_hp: 80,
            mp: 17,
        });
        runtime.handle(ZoneCommand::ConfigureHazards {
            session_id: session_id.clone(),
            lightning: true,
            fire: true,
            lightning_damage: 9,
            fire_damage: 4,
        });

        let expected_root = runtime.canonical_state_root().expect("state root");
        let bytes = runtime.checkpoint_bytes().expect("checkpoint bytes");
        let saved: ZoneRuntimeCheckpoint = serde_json::from_slice(&bytes).expect("saved state");
        assert_eq!(saved.state_root, expected_root, "original checkpoint is authenticated before cold revocation");
        assert!(saved.online_presence.as_ref().unwrap().contains_key(&session_id));
        let mut tampered = saved.clone();
        tampered.players.get_mut(&session_id).unwrap().hp += 1;
        assert!(ZoneRuntime::restore_checkpoint(&serde_json::to_vec(&tampered).unwrap())
            .unwrap_err().contains("state root mismatch"));
        let mut restored = ZoneRuntime::restore_checkpoint(&bytes).expect("checkpoint restore");

        assert_ne!(
            restored.canonical_state_root().expect("restored root"),
            expected_root
        );
        assert!(restored.online_presence.is_empty());
        assert!(restored.issued_native_monster_awards.is_empty());
        assert_eq!(serde_json::to_value(&restored.players).unwrap(), serde_json::to_value(&saved.players).unwrap(),
            "cold revocation must retain the complete authoritative player payload");
        assert_eq!(serde_json::to_value(&restored.hazard).unwrap(), serde_json::to_value(&saved.hazard).unwrap());
        assert_eq!(
            restored.player_position(&session_id),
            Some(Point { x: 14, y: 27 })
        );
        assert_eq!(restored.player_vitals(&session_id), Some((43, 80, 17)));
        assert!(restored.ecs_mirror_matches_players());
    }

    #[test]
    fn checkpoint_state_root_authenticates_removed_object_tombstones() {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("tombstone-integrity-map"));
        runtime.removed_object_ids.insert(8_021);
        let bytes = runtime.checkpoint_bytes().expect("checkpoint bytes");
        let mut checkpoint: ZoneRuntimeCheckpoint =
            serde_json::from_slice(&bytes).expect("checkpoint JSON");
        assert!(checkpoint.removed_object_ids.remove(&8_021));
        let tampered = serde_json::to_vec(&checkpoint).expect("tampered checkpoint JSON");

        let error = ZoneRuntime::restore_checkpoint(&tampered)
            .expect_err("removing a detached-drop tombstone must fail");
        assert!(error.contains("state root mismatch"), "{error}");
    }
    #[test]
    fn complete_zone_checkpoint_rejects_valid_json_with_changed_state() {
        let runtime = ZoneRuntime::new(ZoneKey::for_map("tamper-map"));
        let bytes = runtime.checkpoint_bytes().expect("checkpoint bytes");
        let mut checkpoint: ZoneRuntimeCheckpoint =
            serde_json::from_slice(&bytes).expect("checkpoint JSON");
        checkpoint.next_object_id = checkpoint.next_object_id.saturating_add(1);
        let tampered = serde_json::to_vec(&checkpoint).expect("tampered checkpoint JSON");

        let error =
            ZoneRuntime::restore_checkpoint(&tampered).expect_err("tampered state must fail");
        assert!(error.contains("state root mismatch"), "{error}");
    }

    #[test]
    fn verified_world_checkpoint_reanchors_a_module_dependent_state_root() {
        let runtime = ZoneRuntime::new(ZoneKey::for_map("module-upgrade-map"));
        let bytes = runtime.checkpoint_bytes().expect("checkpoint bytes");
        let mut checkpoint: ZoneRuntimeCheckpoint =
            serde_json::from_slice(&bytes).expect("checkpoint JSON");
        checkpoint.state_root = "0".repeat(64);
        let previous_module = serde_json::to_vec(&checkpoint).expect("previous module checkpoint");

        assert!(ZoneRuntime::restore_checkpoint(&previous_module).is_err());
        let restored = ZoneRuntime::restore_verified_world_checkpoint(&previous_module)
            .expect("outer-verified World checkpoint should re-anchor");
        assert_ne!(restored.canonical_state_root().unwrap(), "0".repeat(64));
    }

    #[test]
    fn legacy_v1_ground_drop_fixture_rebuilds_authority_from_legacy_payload_only() {
        let fixture = legacy_v1_ground_drop_fixture();
        assert!(fixture.get("next_ground_drop_generation").is_none());
        assert!(fixture.get("next_ground_drop_claim_id").is_none());
        assert!(fixture["ground_drops"]["101"]
            .get("drop_generation")
            .is_none());
        assert!(fixture["ground_drops"]["101"]
            .get("payload_digest")
            .is_none());
        assert!(fixture["claimed_ground_drops"]["102"]
            .get("ticket")
            .is_none());

        let restored = ZoneRuntime::restore_checkpoint(
            &serde_json::to_vec(&fixture).expect("legacy fixture bytes"),
        )
        .expect("strict v1 fixture restore");
        let active = restored
            .ground_drops
            .get(&101)
            .expect("restored active drop");
        assert_eq!(active.drop_generation, 1);
        assert_eq!(
            active.payload_digest,
            canonical_ground_drop_payload_digest(&active.drop)
        );
        let ticket = restored
            .claimed_ground_drops
            .get(&102)
            .and_then(|claim| claim.ticket.as_ref())
            .expect("rebuilt claimed-drop ticket");
        assert_eq!(ticket.claim_id, 1);
        assert_eq!(ticket.drop_generation, 2);
        assert_eq!(
            ticket.payload_digest,
            canonical_ground_drop_payload_digest(&ticket.drop)
        );
        assert_eq!(
            ticket.idempotency_key,
            canonical_ground_drop_claim_idempotency_key(
                &restored.key,
                ticket.object_id,
                ticket.drop_generation,
                &ticket.payload_digest,
            )
        );
        assert_eq!(restored.next_ground_drop_generation, 3);
        assert_eq!(restored.next_ground_drop_claim_id, 2);
    }

    #[test]
    fn legacy_v1_restore_ignores_injected_v2_ground_drop_authority_fields() {
        let mut fixture = legacy_v1_ground_drop_fixture();
        fixture["next_ground_drop_generation"] = serde_json::json!(999_u64);
        fixture["next_ground_drop_claim_id"] = serde_json::json!(998_u64);
        fixture["ground_drops"]["101"]["drop_generation"] = serde_json::json!(777_u64);
        fixture["ground_drops"]["101"]["payload_digest"] = serde_json::json!("forged-active");
        fixture["claimed_ground_drops"]["102"]["ticket"] =
            serde_json::to_value(GroundDropClaimTicket {
                claim_id: 555,
                object_id: 102,
                drop_generation: 666,
                payload_digest: "forged-claim".to_string(),
                idempotency_key: "forged-idempotency-key".to_string(),
                session_id: SessionId::new("forged-session"),
                owner_object_id: Some(123),
                drop: checkpoint_gold_drop(102),
            })
            .expect("forged ticket JSON");

        let restored = ZoneRuntime::restore_checkpoint(
            &serde_json::to_vec(&fixture).expect("injected legacy fixture bytes"),
        )
        .expect("injected v2 fields must not affect verified v1 restore");
        let active = restored
            .ground_drops
            .get(&101)
            .expect("restored active drop");
        assert_eq!(active.drop_generation, 1);
        assert_ne!(active.payload_digest, "forged-active");
        assert_eq!(
            active.payload_digest,
            canonical_ground_drop_payload_digest(&active.drop)
        );
        let ticket = restored
            .claimed_ground_drops
            .get(&102)
            .and_then(|claim| claim.ticket.as_ref())
            .expect("rebuilt claimed-drop ticket");
        assert_eq!(ticket.claim_id, 1);
        assert_eq!(ticket.drop_generation, 2);
        assert_ne!(ticket.payload_digest, "forged-claim");
        assert_ne!(ticket.idempotency_key, "forged-idempotency-key");
        assert_eq!(ticket.session_id, SessionId::new("legacy-claimer"));
        assert_eq!(ticket.owner_object_id, None);
        assert_eq!(
            ticket.idempotency_key,
            canonical_ground_drop_claim_idempotency_key(
                &restored.key,
                ticket.object_id,
                ticket.drop_generation,
                &ticket.payload_digest,
            )
        );
        assert_eq!(restored.next_ground_drop_generation, 3);
        assert_eq!(restored.next_ground_drop_claim_id, 2);
    }

    #[test]
    fn ground_drop_authority_allocators_fail_closed_at_u64_exhaustion() {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("authority-id-exhaustion"));
        runtime.next_ground_drop_generation = u64::MAX;
        runtime.next_ground_drop_claim_id = u64::MAX;

        assert_eq!(runtime.allocate_ground_drop_generation(), None);
        assert_eq!(runtime.allocate_ground_drop_claim_id(), None);
        assert!(runtime
            .new_zone_ground_drop(checkpoint_gold_drop(200), None)
            .is_none());
        assert_eq!(runtime.next_ground_drop_generation, u64::MAX);
        assert_eq!(runtime.next_ground_drop_claim_id, u64::MAX);
    }
    #[test]
    fn verified_world_checkpoint_keeps_v2_ground_drop_authority_validation() {
        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("v2-drop-validation"));
        let drop = checkpoint_gold_drop(201);
        let stored = runtime
            .new_zone_ground_drop(drop.clone(), None)
            .expect("ground-drop generation");
        runtime.ground_drops.insert(drop.object_id, stored);
        let mut checkpoint: ZoneRuntimeCheckpoint =
            serde_json::from_slice(&runtime.checkpoint_bytes().expect("v2 checkpoint bytes"))
                .expect("v2 checkpoint JSON");
        checkpoint
            .ground_drops
            .get_mut(&drop.object_id)
            .expect("v2 stored drop")
            .payload_digest = "forged-v2-digest".to_string();

        let error = ZoneRuntime::restore_verified_world_checkpoint(
            &serde_json::to_vec(&checkpoint).expect("forged v2 checkpoint bytes"),
        )
        .expect_err("v2 authority validation must survive world-root reanchoring");
        assert!(
            error.contains("invalid authoritative ground drop"),
            "{error}"
        );
    }
    #[test]
    fn world_event_monster_without_player_is_authoritative_and_checkpointed() {
        use crate::runtime::zone::types::{ZoneMonsterDefense, ZoneMonsterSpawn};

        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("D022"));
        let spawn = ZoneMonsterSpawn {
            crystal_drop_seed: None,
            object_id: 9_100_001,
            name: "WoomaSoldier".to_string(),
            name_colour_argb: -1,
            image: 135,
            ai: 2,
            disposition: Some(crate::config::WorldEntityDisposition::Hostile),
            level: 24,
            max_hp: 500,
            hp: 500,
            experience: 1_000,
            move_speed_ms: 0,
            attack_speed_ms: 0,
            friendly_guild: None,
            position: Point { x: 30, y: 30 },
            direction: MirDirection::Down,
            defense: ZoneMonsterDefense::default(),
            respawn: None,
            drops: Vec::new(),
        };
        let (spawned, outbounds) = runtime.spawn_world_event_monster(&spawn, 1_000);
        assert!(spawned);
        assert!(outbounds.is_empty(), "empty Zone has no AOI recipients");
        assert!(runtime.has_native_monster(spawn.object_id));

        let bytes = runtime.checkpoint_bytes().expect("event checkpoint");
        let restored = ZoneRuntime::restore_checkpoint(&bytes).expect("event checkpoint restore");
        assert!(restored.has_native_monster(spawn.object_id));
        assert_eq!(restored.native_monster_count(), 1);
        assert_eq!(
            restored.canonical_state_root().unwrap(),
            runtime.canonical_state_root().unwrap()
        );
    }

    #[test]
    fn legacy_checkpoint_missing_monster_disposition_fails_closed() {
        use crate::runtime::zone::types::{ZoneMonsterDefense, ZoneMonsterSpawn};

        let mut runtime = ZoneRuntime::new(ZoneKey::for_map("D022"));
        let spawn = ZoneMonsterSpawn {
            crystal_drop_seed: None,
            object_id: 9_100_099,
            name: "LegacyHostile".to_string(),
            name_colour_argb: -1,
            image: 0,
            ai: 0,
            disposition: Some(crate::config::WorldEntityDisposition::Hostile),
            level: 1,
            max_hp: 10,
            hp: 10,
            experience: 0,
            move_speed_ms: 0,
            attack_speed_ms: 0,
            friendly_guild: None,
            position: Point { x: 30, y: 30 },
            direction: MirDirection::Down,
            defense: ZoneMonsterDefense::default(),
            respawn: None,
            drops: Vec::new(),
        };
        assert!(runtime.spawn_world_event_monster(&spawn, 0).0);
        let mut checkpoint: serde_json::Value =
            serde_json::from_slice(&runtime.checkpoint_bytes().expect("checkpoint bytes"))
                .expect("checkpoint JSON");
        checkpoint["native_monsters"][spawn.object_id.to_string()]
            .as_object_mut()
            .expect("retained native monster")
            .remove("disposition");

        let legacy_bytes = serde_json::to_vec(&checkpoint).expect("legacy checkpoint bytes");
        let restored = ZoneRuntime::restore_verified_world_checkpoint(&legacy_bytes)
            .expect("verified legacy checkpoint should restore");
        let monster = restored
            .native_monster_snapshots()
            .into_iter()
            .find(|monster| monster.object_id == spawn.object_id)
            .expect("legacy monster");
        assert_eq!(monster.disposition, None);
        assert!(!monster.hostile_to_player);
    }

    #[test]
    fn online_player_receives_world_event_monster_spawn_packet() {
        use crate::runtime::zone::types::{ZoneMonsterDefense, ZoneMonsterSpawn};

        let session_id = SessionId::new("director-witness");
        let mut runtime =
            ZoneRuntime::new_with_collision(ZoneKey::for_map("D024"), ZoneCollision::unbounded());
        runtime.handle(ZoneCommand::Join(ZoneJoin {
            session_id,
            account_id: "witness-account".to_string(),
            character_index: 9,
            object_id: 99,
            name: "Witness".to_string(),
            class: MirClass::Warrior,
            gender: MirGender::Male,
            level: 30,
            hp: 300,
            max_hp: 300,
            mp: 80,
            map_file_name: "D024".to_string(),
            position: Point { x: 30, y: 30 },
            direction: MirDirection::Down,
            chat_profile: ZoneChatProfile::default(),
            combat_stats: ZonePlayerCombatStats::default(),
        }));
        let spawn = ZoneMonsterSpawn {
            crystal_drop_seed: None,
            object_id: 9_100_002,
            name: "WoomaTaurus".to_string(),
            name_colour_argb: -65_281,
            image: 139,
            ai: 58,
            disposition: Some(crate::config::WorldEntityDisposition::Hostile),
            level: 40,
            max_hp: 10_000,
            hp: 10_000,
            experience: 20_000,
            move_speed_ms: 0,
            attack_speed_ms: 0,
            friendly_guild: None,
            position: Point { x: 31, y: 30 },
            direction: MirDirection::Down,
            defense: ZoneMonsterDefense::default(),
            respawn: None,
            drops: Vec::new(),
        };
        let (spawned, outbounds) = runtime.spawn_world_event_monster(&spawn, 2_000);
        assert!(spawned);
        assert!(outbounds.iter().any(|outbound| match outbound {
            ZoneOutbound::ToSession { packets, .. } | ZoneOutbound::ToMany { packets, .. } => {
                packets.iter().any(|packet| {
                    matches!(
                        packet,
                        mir2_protocol::ServerPacket::ObjectMonster { info }
                            if info.object_id == spawn.object_id && info.name == "WoomaTaurus"
                    )
                })
            }
            _ => false,
        }));
    }
}

fn checkpoint_counter_is_zero(value: &u64) -> bool {
    *value == 0
}
