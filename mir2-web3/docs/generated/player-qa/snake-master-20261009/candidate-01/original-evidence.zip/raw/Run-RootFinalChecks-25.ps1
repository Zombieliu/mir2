#Requires -Version 7.2
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
$taskProject='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p4-snake-master-20261009-evidence'
$taskTarget='C:/mir2-build/p1-gateway-lifecycle-target-20261009-01'
$taskVswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$taskVs=(& $taskVswhere -latest -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath).Trim()
Import-Module (Join-Path $taskVs 'Common7/Tools/Microsoft.VisualStudio.DevShell.dll')
Enter-VsDevShell -VsInstallPath $taskVs -SkipAutomaticLocation -DevCmdArguments '-arch=x64 -host_arch=x64' | Out-Null
Set-Location -LiteralPath $taskProject
$env:CARGO_TARGET_DIR=$taskTarget
$taskSources=@('apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/runtime/owned_pet_combat.rs','apps/simulation/src/runtime/zone/runtime/snake_totem_ai.rs','apps/simulation/src/runtime/zone/runtime/experience_ownership.rs','apps/simulation/src/runtime/zone/runtime/owned_pet_immediate_master_tests.rs','apps/simulation/tests/shared_snake_master_lifecycle.rs','apps/simulation/tests/shared_zone.rs','../.github/workflows/gateway-release.yml')
$taskHashes=[ordered]@{}
foreach ($taskFile in $taskSources) { $taskHashes[$taskFile]=(Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant() }
$taskCommon=@('+1.95.0','test','--locked','--offline','--jobs','2','--config','profile.test.package.mir2-simulation.debug="line-tables-only"','--config','profile.test.package.mir2-simulation.codegen-units=193','-p','mir2-simulation')
$taskSuites=@(
 @{name='25-final-private';args=@('--lib','--','--test-threads=1','owned_pet_immediate_master_tests','owned_pet_combat::tests','experience_ownership')},
 @{name='26-final-zone-api';args=@('--test','shared_snake_master_lifecycle','--','--test-threads=1','--nocapture')},
 @{name='27-final-pet-api';args=@('--features','test-support','--test','shared_pet_pvp','--','--test-threads=1')},
 @{name='28-final-broad-zone';args=@('--test','shared_zone','--','--test-threads=1')}
)
$taskResults=@()
foreach ($taskSuite in $taskSuites) {
 $taskLog=Join-Path $taskEvidence ($taskSuite.name+'.log')
 $taskReceiptPath=$taskLog+'.json'
 if ((Test-Path -LiteralPath $taskLog) -or (Test-Path -LiteralPath $taskReceiptPath)) { throw 'Immutable fresh evidence required' }
 $taskDrive=[IO.DriveInfo]::new('C:/')
 if ($taskDrive.AvailableFreeSpace -lt 50GB) { throw 'Original disk reserve required' }
 foreach ($taskFile in $taskSources) { if ((Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant() -cne $taskHashes[$taskFile]) { throw 'Source changed before test' } }
 $taskArgs=$taskCommon+$taskSuite.args
 $taskStart=[DateTimeOffset]::UtcNow.ToString('o')
 & cargo @taskArgs *> $taskLog
 $taskExit=$LASTEXITCODE
 foreach ($taskFile in $taskSources) { if ((Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant() -cne $taskHashes[$taskFile]) { throw 'Source changed during test' } }
 $taskResult=[ordered]@{suite=$taskSuite.name;started=$taskStart;completed=[DateTimeOffset]::UtcNow.ToString('o');exitCode=$taskExit;arguments=$taskArgs;project=$taskProject;target=$taskTarget;sourceSha256=$taskHashes;log=$taskLog;logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant();summary=@(Select-String -LiteralPath $taskLog -Pattern '^test result:','^failures:','^    zone_' | ForEach-Object {$_.Line})}
 $taskJson=[Text.UTF8Encoding]::new($false).GetBytes(($taskResult|ConvertTo-Json -Depth 8))
 $taskStream=[IO.File]::Open($taskReceiptPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try {$taskStream.Write($taskJson);$taskStream.Flush($true)} finally {$taskStream.Dispose()}
 $taskResults+=$taskResult
 $taskResult|ConvertTo-Json -Depth 8 -Compress
 if ($taskExit -ne 0 -and $taskSuite.name -cne '28-final-broad-zone') { exit $taskExit }
}
if (@($taskResults|Where-Object {$_.exitCode -ne 0}).Count -gt 0) { exit 1 }
exit 0
