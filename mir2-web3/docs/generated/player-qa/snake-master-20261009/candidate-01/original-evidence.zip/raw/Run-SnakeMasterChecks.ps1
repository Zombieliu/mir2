param(
    [Parameter(Mandatory=$true)][string]$Run,
    [Parameter(Mandatory=$true)][ValidateSet('snake-public','snake-private','owned-private','pet-public','snake-adjacent','experience-adjacent')][string]$Suite
)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
$taskProject = 'E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence = 'C:/mir2-build/p4-snake-master-20261009-evidence'
$taskTarget = 'C:/mir2-build/p1-gateway-lifecycle-target-20261009-01'
$taskLog = Join-Path $taskEvidence "$Run-$Suite.log"
if (Test-Path -LiteralPath $taskLog) { throw 'Refusing to overwrite evidence' }
$taskDrive = [IO.DriveInfo]::new('C:/')
if ($taskDrive.AvailableFreeSpace -lt 50GB) { throw 'Insufficient disk reserve' }
$taskFreeBefore = $taskDrive.AvailableFreeSpace
$env:CARGO_TARGET_DIR = $taskTarget
Set-Location -LiteralPath $taskProject
$taskArgs = @('+1.95.0','test','--locked','--offline','--jobs','2','--config','profile.test.package.mir2-simulation.debug="line-tables-only"','--config','profile.test.package.mir2-simulation.codegen-units=193','-p','mir2-simulation')
switch ($Suite) {
    'snake-public' { $taskArgs += @('--test','shared_snake_master_lifecycle','--','--test-threads=1','--nocapture') }
    'snake-private' { $taskArgs += @('--lib','owned_pet_immediate_master_tests','--','--test-threads=1','--nocapture') }
    'owned-private' { $taskArgs += @('--lib','owned_pet_combat::tests','--','--test-threads=1') }
    'pet-public' { $taskArgs += @('--features','test-support','--test','shared_pet_pvp','--','--test-threads=1') }
    'snake-adjacent' { $taskArgs += @('--test','shared_zone','--','--test-threads=1','zone_native_archer_summon_snakes_spawns_static_totem_profile','zone_native_charmed_snake_hit_applies_paralysis_poison','zone_native_snake_totem_caps_minions_and_respawns_after_minion_expiry','zone_native_snake_totem_self_destruct_kills_owned_minions') }
    'experience-adjacent' { $taskArgs += @('--lib','experience_ownership','--','--test-threads=1') }
}
$taskSources = @('apps/simulation/src/runtime/zone/runtime/owned_pet_combat.rs','apps/simulation/src/runtime/zone/runtime/snake_totem_ai.rs','apps/simulation/src/runtime/zone/runtime/experience_ownership.rs','apps/simulation/tests/shared_snake_master_lifecycle.rs')
if (Test-Path -LiteralPath 'apps/simulation/src/runtime/zone/runtime/owned_pet_immediate_master_tests.rs') { $taskSources += 'apps/simulation/src/runtime/zone/runtime/owned_pet_immediate_master_tests.rs' }
$taskSourceHashes = @{}
foreach ($taskFile in $taskSources) { $taskSourceHashes[$taskFile] = (Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant() }
$taskStarted = [DateTime]::UtcNow.ToString('o')
& cargo @taskArgs *> $taskLog
$taskExit = $LASTEXITCODE
[ordered]@{
    suite=$Suite; run=$Run; startedUtc=$taskStarted; completedUtc=[DateTime]::UtcNow.ToString('o'); exitCode=$taskExit;
    executable='cargo'; arguments=$taskArgs; project=$taskProject; target=$taskTarget;
    sourceSha256=$taskSourceHashes; freeBytesBefore=$taskFreeBefore; freeBytesAfter=$taskDrive.AvailableFreeSpace;
    log=$taskLog; logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskLog.json" -Encoding utf8
Get-Content -LiteralPath $taskLog -Tail 22 | Where-Object { $_ -notmatch '^  = note: "' }
exit $taskExit
