import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';

const base='C:/mir2-playtest-releases/20261007-remote-player-r21';
const root='C:/mir2-playtest-releases/20261008-classic-r22/public-smoke-01';
const revision='a41dfe72d7e5858f11169adf88673dc44ed24200';
const endpoint='wss://165.154.65.136.sslip.io/playtest/ws';
function need(value,message){if(!value)throw Error(message);}
need(process.env.NODE_TLS_REJECT_UNAUTHORIZED!=='0','Normal TLS verification is required');
need(crypto.createHash('sha256').update(await fs.readFile(base+'/ws-transport-02.cjs')).digest('hex')==='7b9865c26b0b6c148b4ed0d00dfc5409aff21e6a65851a2c5352b689f7351574','Pinned WebSocket transport differs');
const WebSocketTransport=createRequire(import.meta.url)(base+'/ws-transport-02.cjs');
need(crypto.createHash('sha256').update(await fs.readFile(base+'/protocol-observation.mjs')).digest('hex')==='b69ba03e9f6ee05286d401341c6dbbe6dac4a6e5014fa6a67e9c6167c072d097','Frozen source observation differs');
const {applyProtocolObservation}=await import(pathToFileURL(base+'/protocol-observation.mjs'));
const health=await fetch('https://165.154.65.136.sslip.io/playtest/health',{redirect:'error',signal:AbortSignal.timeout(15000)}).then(r=>{need(r.ok,'Public health HTTP status');return r.json();});
need(health.ok===true&&health.revision===revision,'Public playtest must run the pinned appearance candidate');
need(health.capacity.currentActiveSessions<=44,'Five owned clients require available normal capacity');
await fs.access(base+'/public-wss-03/private');
const priorReport=JSON.parse(await fs.readFile(base+'/public-wss-03/RESULT.json','utf8'));
need(priorReport.passed===true&&priorReport.sourceRevision==='c6c32381a646dae1067dafdeec57691f606b1779','Owned ordinary cohort provenance');
const owned=JSON.parse(await fs.readFile(base+'/public-wss-03/private/accounts.json','utf8'));
const {cohort,female}=owned;
need(cohort.length===5&&female.class==='Taoist'&&female.gender==='Female','Six existing owned class/gender variants');
for(const account of [...cohort,female])need(Number.isSafeInteger(account.characterIndex),'Reuse exact ordinary-created character index');
const secrets=cohort.map(a=>a.password);
const ordinary=new Set(['clientVersion','login','newCharacter','startGame','keepAlive','walk','logOut']);
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function safe(value){
 if(Array.isArray(value))return value.map(safe);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,/password|secret|token|authorization|cookie|pepper|private.?key/i.test(k)?'[redacted]':safe(v)]));
 return typeof value==='string'?secrets.reduce((s,p)=>s.split(p).join('[redacted]'),value):value;
}
class Client {
 constructor(account,phase){this.account=account;this.phase=phase;this.events=[];this.sequence=0;this.queue=Promise.resolve();}
 record(direction,value){const event={sequence:++this.sequence,utc:new Date().toISOString(),direction,...safe(value)};this.events.push(event);this.queue=this.queue.then(()=>fs.appendFile(path.join(root,`${this.phase}-${this.account.name}.jsonl`),JSON.stringify(event)+'\n'));}
 async wait(predicate,label,ms=20000){const end=Date.now()+ms;while(Date.now()<end){if(this.error)throw this.error;const value=predicate();if(value)return value;await delay(25);}throw Error('Timed out: '+label);}
 send(value){need(ordinary.has(value.type),'Only ordinary public commands are admitted');this.record('sent',value);this.ws.send(JSON.stringify(value));}
 async request(value,packet){const prior=this.sequence;this.send(value);return this.wait(()=>this.events.find(e=>e.sequence>prior&&e.direction==='received'&&e.packet===packet),packet);}
 async open(){
  this.ws=new WebSocketTransport(endpoint,{origin:'https://165.154.65.136.sslip.io',handshakeTimeout:10000});
  this.ws.addEventListener('message',event=>{try{const value=JSON.parse(String(event.data));this.record('received',value);if(value.packet==='UserInformation')this.info=value.payload;this.snapshot=applyProtocolObservation(this.snapshot,value);if(value.type==='error')this.error=Error('Public gateway rejected an ordinary command: '+value.message);}catch(error){this.error=error;}});
  this.ws.addEventListener('error',()=>{this.error=Error('Verified public WSS failed');});
  await this.wait(()=>this.ws.readyState===1,'TLS WebSocket open',15000);
  this.send({type:'clientVersion'});
  this.timer=setInterval(()=>{if(this.ws.readyState===1)this.send({type:'keepAlive',time:Date.now()});},2000);
 }
 async login(createCharacter=false){
  const a=this.account;
  await this.request({type:'login',accountId:a.accountId,password:a.password},'LoginSuccess');
  if(createCharacter){const reply=await this.request({type:'newCharacter',name:a.name,class:a.class,gender:a.gender},'NewCharacterSuccess');a.characterIndex=reply.payload.character.index;need(Number.isSafeInteger(a.characterIndex),'Actual newly created character index');}
 }
 async start(){
  const prior=this.sequence;
  const reply=await this.request({type:'startGame',characterIndex:this.account.characterIndex},'StartGame');
  need(reply.payload.result===4,'Authenticated StartGame result4');
  await this.wait(()=>this.events.find(e=>e.sequence>prior&&e.packet==='UserInformation'),'owner UserInformation');
  await this.wait(()=>this.snapshot?.entities?.find(e=>e.objectId===this.snapshot.playerObjectId&&e.name===this.account.name),'normal shared owner snapshot');
  need(this.info.level===1&&this.info.hp>0,'Normal level1 actor without trusted preparation');
 }
 owner(){return this.snapshot.entities.find(e=>e.objectId===this.snapshot.playerObjectId);}
 async seen(account,after=0){return this.wait(()=>this.events.filter(e=>e.sequence>after&&e.packet==='ObjectPlayer'&&e.payload.name===account.name).at(-1),'remote ObjectPlayer '+account.name);}
 async close(){
  clearInterval(this.timer);
  if(this.ws?.readyState===1){const previousError=this.error;this.error=null;try{await this.request({type:'logOut'},'LogOutSuccess');this.normalLogout=true;}catch{}finally{this.error=previousError;this.ws.close(1000);}}
  await this.queue;
 }
}
function verifyAppearance(event,owner){
 const info=event.payload;
 need(info.transformType===-1,'Ordinary remote actor must not use Transform/00');
 need(info.class===owner.account.class&&info.gender===owner.account.gender,'Remote class and gender are authoritative');
 need(info.sprite?.bodyLibrary?.startsWith('CArmour/'),'Released ordinary armour body is selected');
 need(JSON.stringify(info.sprite)===JSON.stringify(owner.owner().sprite),'Complete remote sprite equals ordinary owner snapshot');
 return {observerBody:info.sprite.bodyLibrary,weapon:info.sprite.weaponLibrary,gender:info.gender,class:info.class,transformType:info.transformType,objectId:info.objectId};
}
const clients=[],rows=[],variants=new Set();
async function spawn(account,phase,createCharacter=false){const client=new Client(account,phase);clients.push(client);await client.open();await client.login(createCharacter);await client.start();variants.add(account.class+'/'+account.gender);return client;}
async function relation(observer,owner,phase,after=0){const event=await observer.seen(owner.account,after);rows.push({phase,observer:observer.account.name,subject:owner.account.name,...verifyAppearance(event,owner)});}
async function moveAndRelogin(actor,observers,phase){
 const start={...actor.owner()},before=observers.map(c=>c.sequence);
 let moved=null;
 for(const [direction,dx,dy]of [['Down',0,1],['Right',1,0],['Left',-1,0],['Up',0,-1],['DownRight',1,1],['DownLeft',-1,1],['UpRight',1,-1],['UpLeft',-1,-1]]){
  const prior=actor.sequence;actor.send({type:'walk',direction});
  try{moved=await actor.wait(()=>actor.events.find(e=>e.sequence>prior&&e.packet==='UserLocation'&&e.payload.x===start.x+dx&&e.payload.y===start.y+dy),'one ordinary tile move',2000);break;}catch{}
 }
 need(moved,'At least one ordinary acknowledged move is required');
 const oldId=(await observers[0].seen(actor.account)).payload.objectId;
 for(let i=0;i<observers.length;i++){const seen=await observers[i].wait(()=>observers[i].events.find(e=>e.sequence>before[i]&&e.packet==='ObjectWalk'&&e.payload.objectId===oldId&&e.payload.x===moved.payload.x&&e.payload.y===moved.payload.y),'AOI ObjectWalk');rows.push({phase:phase+'-walk',observer:observers[i].account.name,objectId:oldId,location:{x:seen.payload.x,y:seen.payload.y}});}
 const beforeLogout=observers.map(c=>c.sequence);
 await actor.close();need(actor.normalLogout===true,'Ordinary actor logout must save normally');
 for(let i=0;i<observers.length;i++)await observers[i].wait(()=>observers[i].events.find(e=>e.sequence>beforeLogout[i]&&e.packet==='ObjectRemove'&&e.payload.objectId===oldId),'AOI leave remove');
 const beforeRejoin=observers.map(c=>c.sequence),returning=await spawn(actor.account,phase+'-relogin');
 need(returning.owner().x===moved.payload.x&&returning.owner().y===moved.payload.y,'Normal logout/relogin preserves actual acknowledged transform');
 for(let i=0;i<observers.length;i++)await relation(observers[i],returning,phase+'-relogin',beforeRejoin[i]);
 return returning;
}
let failure=null;
try{
 const active=[];
 for(const account of cohort)active.push(await spawn(account,'initial'));
 for(const observer of active)for(const owner of active)if(observer!==owner)await relation(observer,owner,'initial');
 active[0]=await moveAndRelogin(active[0],active.slice(1),'warrior');
 const male=active[4],oldId=(await active[0].seen(male.account)).payload.objectId,beforeLogout=active.slice(0,4).map(c=>c.sequence);
 await male.close();need(male.normalLogout===true,'Male Taoist logout before owned character switch');
 for(let i=0;i<4;i++)await active[i].wait(()=>active[i].events.find(e=>e.sequence>beforeLogout[i]&&e.packet==='ObjectRemove'&&e.payload.objectId===oldId),'Male Taoist leave remove');
 const beforeJoin=active.slice(0,4).map(c=>c.sequence);
 active[4]=await spawn(female,'female-taoist',false);
 for(let i=0;i<4;i++){await relation(active[i],active[4],'female-taoist',beforeJoin[i]);await relation(active[4],active[i],'female-taoist');}
 active[4]=await moveAndRelogin(active[4],active.slice(0,4),'female-taoist');
}catch(error){failure=error.message;}
finally{for(const client of clients)await client.close();}
const report={schema:'mir2.r22.ordinary-public-smoke.v1',passed:failure===null&&rows.length===44&&variants.size===6&&clients.length===8&&clients.every(c=>c.normalLogout===true)&&clients.every(c=>c.events.every(e=>e.direction!=='sent'||e.type!=='newCharacter')),sourceRevision:revision,endpoint,tlsVerified:true,origin:'https://165.154.65.136.sslip.io',ownedAccounts:5,ownedCharacterVariants:[...variants],maximumConcurrentActors:5,newAccountRegistrations:0,newCharacterCreations:0,privateCredentialCopiesCreated:false,initialAppearanceRelations:20,genderSwitchAppearanceRelations:8,movementRelations:8,reloginAppearanceRelations:8,ordinaryCommandsOnly:true,adminCommands:false,qaStatePreparation:false,nativeRenderAcceptance:false,failure,normalLogouts:clients.map(c=>({name:c.account.name,phase:c.phase,confirmed:c.normalLogout===true})),rows};
await fs.writeFile(root+'/RESULT.json',JSON.stringify(safe(report),null,2),{flag:'wx'});
console.log(JSON.stringify(safe(report)));
if(!report.passed)process.exitCode=1;
