sudo -n /usr/bin/python3 - <<'PY'
import datetime,json,pathlib,re,subprocess,time
pid='3420651'
p=pathlib.Path('/proc')/pid
before=p.joinpath('stat').read_text().split()
started=time.monotonic()
time.sleep(2)
after=p.joinpath('stat').read_text().split()
raw=subprocess.run(['journalctl','-u','mir2-playtest.service','--since','2026-10-11 23:23:30 UTC','--until','2026-10-11 23:25:30 UTC','-o','cat','--no-pager'],check=True,capture_output=True,timeout=15).stdout.decode(errors='replace')
lines=[]
for line in raw.splitlines():
 if any(word in line.lower() for word in ('password','token','secret','authorization','stripe','postgres://','postgresql://')): continue
 if any(word in line.lower() for word in ('error','warn','panic','startgame','snapshot','r2100cccbba','failed','timeout')):
  line=re.sub(r'(?i)https?://\S+','[redacted-url]',line)
  lines.append(line[:600])
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':pid,'cpuTickDelta':sum(int(after[i])-int(before[i]) for i in (13,14)),'observedSeconds':time.monotonic()-started,'journalTotalLines':len(raw.splitlines()),'selectedSanitizedLines':lines[-60:],'serverChanged':False}))
PY
