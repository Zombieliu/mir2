/usr/bin/python3 - <<'PY'
import os,pathlib,stat,json
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-f574d214a10c7efd62176ec94cea37821095b8fe')
assert p.parent.resolve(strict=True)==p.parent and p.parent.stat().st_uid in (0,os.geteuid())
assert not p.exists() and not p.is_symlink(), 'Existing staging requires inspection; refusing a blind rerun'
p.mkdir(mode=0o700)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
print(json.dumps({'stageCreated':True}))
PY
