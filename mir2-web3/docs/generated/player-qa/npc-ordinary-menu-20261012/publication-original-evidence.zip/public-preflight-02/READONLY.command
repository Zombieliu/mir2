sudo -n /usr/bin/python3 - <<'PY'
import hashlib,json,pathlib,re,subprocess,urllib.request
def run(args):
    return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15).stdout.decode()
def health(port):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open('http://127.0.0.1:%d/health'%port,timeout=5) as r:
        return json.load(r)
test=health(7210)
original=health(7110)
unit=run(['systemctl','show','mir2-playtest.service','-p','MainPID','-p','Result','-p','ExecMainStatus','-p','NRestarts','-p','DropInPaths'])
count=len([x for x in run(['ss','-Htn','state','established','sport = :7200']).splitlines() if x.strip()])
files={}
for name in ('/etc/mir2-playtest/gateway.env','/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf','/etc/systemd/system/mir2-playtest.service.d/90-spectator-watch.conf','/etc/systemd/system/mir2-playtest.service'):
    p=pathlib.Path(name)
    assert p.is_file() and not p.is_symlink()
    data=p.read_bytes()
    files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
release=pathlib.Path('/opt/mir2-playtest/releases')/test['revision']
meta=json.loads((release/'RELEASE.json').read_text())
binary=release/'mir2-gateway'
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest==meta['binarySha256'] and binary.stat().st_size==meta['binarySizeBytes']
pid=re.search(r'^MainPID=(\d+)$',unit,re.M).group(1)
held=pathlib.Path('/proc/'+pid+'/exe')
assert held.resolve()==binary and hashlib.sha256(held.read_bytes()).hexdigest()==digest
process_env=dict(entry.split(b'=',1) for entry in pathlib.Path('/proc/'+pid+'/environ').read_bytes().split(b'\0') if b'=' in entry)
rpc_keys=(b'MIR2_ZONE_HOST_ADDR',b'MIR2_ZONE_HOST_ADDRS',b'MIR2_ZONE_HOST_ACTIVE_ADDRS',b'MIR2_ZONE_HOST_STANDBY_ADDRS')
remote_zone_configured=any(bool(process_env.get(key)) for key in rpc_keys)
original_pids=re.findall(r'pid=(\d+)',run(['ss','-ltnpH','sport = :7110']))
import stat
public_files={}
for name,limit in (('/etc/caddy/Caddyfile',131072),
    ('/srv/mir2-client-updates/feed-current/latest.json',32768),
    ('/srv/mir2-client-updates/feed-current/latest.p7s',32768)):
 p=pathlib.Path(name);info=p.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_uid==0 and info.st_nlink==1
 assert info.st_size<=limit and not info.st_mode & 0o022
 data=p.read_bytes()
 public_files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 files[name]=public_files[name]
feed=json.loads(pathlib.Path('/srv/mir2-client-updates/feed-current/latest.json').read_bytes())
assert pid=='3397094' and test['revision']=='75c5b2e1f65816e062d2032c9b941bb725152f7c'
assert digest=='22bee6075c24a5cf25d86f6fcf51a02d9f07c5d4208da2eed40d0072fa6be449'
env_pin=files['/etc/mir2-playtest/gateway.env']
assert env_pin['sha256']=='41d0939baa6f164a5db0605ef441647c4c8214a6b4ac1dd7c69ab1da65c647c0'
assert process_env.get(b'MIR2_STRIPE_ENABLED')==b'1'
assert process_env.get(b'MIR2_STRIPE_SECRET_KEY',b'').startswith((b'sk_test_',b'rk_test_'))
assert process_env.get(b'MIR2_MONTHLY_CARD_CREDIT_PRICE')==b'1000'
assert process_env.get(b'MIR2_MONTHLY_CARD_REQUIRED',b'0') in (b'0',b'false')
assert process_env.get(b'MIR2_ACCOUNT_STORE_BACKEND')==b'postgres'
assert not remote_zone_configured and original_pids==['3855184']
assert public_files['/srv/mir2-client-updates/feed-current/latest.json']['sha256']=='a08a45735bffc7d6f1eaff9eb4edf4c210e1a27b278d7cb411f4afc20f141a9d'
assert public_files['/srv/mir2-client-updates/feed-current/latest.p7s']['sha256']=='0f88d31feb50b69970e43108a65245ef899eb7b72133d4ced04c342408acd9d3'
print(json.dumps({'ok':True,'test':test,'unit':dict(line.split('=',1) for line in unit.splitlines()),'tcp7200':count,'files':files,'remoteZoneConfigured':remote_zone_configured,'binarySha256':digest,'binaryBytes':binary.stat().st_size,'original':{'ok':original.get('ok'),'revision':original.get('revision'),'pids':original_pids,'release':str(pathlib.Path('/opt/mir2/gateway/current').resolve())}},sort_keys=True))
PY
