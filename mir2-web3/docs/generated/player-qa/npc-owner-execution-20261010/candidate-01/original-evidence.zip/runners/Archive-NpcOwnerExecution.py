import hashlib, json, re, subprocess, zipfile
from datetime import datetime, timezone
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
root = repo / 'mir2-web3'
evidence = Path('C:/mir2-build/p7-npc-owner-binding-20261010-evidence')
git_evidence = Path('C:/mir2-build/p7-npc-population-20261010-git-publication-01')
out = root / 'docs/generated/player-qa/npc-owner-execution-20261010/candidate-01'
assert not out.exists()
final = {'05-final-binding-after-format':9, '06-original-owner-leases':7,
    '07-original-hosted-auth-economy':1, '08-original-source-sequence-checkpoint':1,
    '09-original-production-command-guard':1, '10-original-security-lifecycle':20,
    '11-original-optimized-purification-map-flow':4}
records, names = {}, set()
for stem, expected in final.items():
    before = json.loads((evidence/(stem+'-before.json')).read_text(encoding='utf-8-sig'))
    after = json.loads((evidence/(stem+'-after.json')).read_text(encoding='utf-8-sig'))
    assert before['source'] == after['source'], stem
    assert len(after['source']) == 21
    for row in after['source']:
        assert hashlib.sha256(Path(row['Path']).read_bytes()).hexdigest().upper() == row['Hash'], (stem,row['Path'])
    result = json.loads((evidence/(stem+'-result.json')).read_text(encoding='utf-8-sig'))
    log = (evidence/(stem+'.log')).read_text(encoding='utf-8-sig')
    match = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    found = re.findall(r'^test (\S+) \.\.\. ok$',log,re.M)
    assert result['exitCode'] == 0 and match and tuple(map(int,match.groups())) == (expected,0,0)
    assert len(found) == len(set(found)) == expected
    assert not names.intersection(found), 'Distinct final count must not contain repeated cases'
    names.update(found)
    records[stem] = {'passed':expected,'failed':0,'ignored':0,'exitCode':0,
        'selectedPaths':len(after['source']),'beforeAfterStableAndCurrent':True}
assert len(names) == sum(final.values()) == 43
failure = (evidence/'03-owner-entry-and-lifetime-final.log').read_text(encoding='utf-8-sig')
assert 'test result: FAILED. 7 passed; 1 failed; 0 ignored;' in failure
assert 'could not compile' in (evidence/'01-real-owner-scope-and-node.log').read_text(encoding='utf-8-sig')
publication = json.loads((git_evidence/'exact-api/PUBLISHED-VERIFIED.json').read_text(encoding='utf-8-sig'))
assert publication['head'] == '85586311e5e1bd2e36d9375b58dd972cae23cb7a'
assert publication['candidateSourcePublishedToGit'] is True and publication['force'] is False
ref = json.loads((git_evidence/'exact-api/REF-MCP-FRESH-READBACK.json').read_text(encoding='utf-8-sig'))
assert ref['object']['sha'] == publication['head']
git = ['git','-c','safe.directory='+repo.as_posix(),'-c','gc.auto=0','-c','maintenance.auto=false','-C',str(repo)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip() == publication['head']
subprocess.run(git+['diff','--check'],check=True)
entries = {}
def add(name,path):
    assert name not in entries
    data = Path(path).read_bytes()
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',data), name
    entries[name] = data
for path in sorted(evidence.iterdir()):
    if path.is_file(): add('local/'+path.name,path)
owned = ['.github/workflows/gateway-release.yml',
    'mir2-web3/apps/gateway/src/routing.rs',
    'mir2-web3/apps/gateway/src/routing/npc_population_binding.rs',
    'mir2-web3/apps/simulation/src/lib.rs', 'mir2-web3/apps/simulation/src/runtime/mod.rs',
    'mir2-web3/apps/simulation/src/world_runtime.rs',
    'mir2-web3/apps/simulation/tests/security_lifecycle.rs',
    'mir2-web3/apps/gateway/tests/shared_purification_map_transfer.rs']
for name in owned: add('final-source/'+name,repo/name)
for name in ['Run-NpcOwnerBindingRoot.ps1','Archive-NpcOwnerExecution.py',
    'Prepare-NpcPopulationPinnedCommit.py','Complete-NpcPopulationGitRest.py',
    'Push-NpcPopulationOrdinaryGit.py','Push-NpcPopulationHttpsGit.py']:
    add('runners/'+name,repo.parent/name)
for name in ['LOCAL-COMMIT.json','exact-api/PREPARED-OBJECTS.json',
    'exact-api/TREE-REQUEST.json','exact-api/TREE-REST-REQUEST.json',
    'exact-api/TREE-REST-RESULT.json','exact-api/TREE-REST-STDERR.log',
    'exact-api/TREE-MCP-RESULT.json','exact-api/TREE-RESULT.json',
    'exact-api/request-1003.json','exact-api/response-1003.json',
    'exact-api/REF-REQUEST.json','exact-api/REF-MCP-RESULT.json',
    'exact-api/REF-MCP-FRESH-READBACK.json','exact-api/COMMIT-MCP-FRESH-READBACK.json',
    'exact-api/PUBLISHED-VERIFIED.json','ordinary-git-01/RESULT.json','https-git-01/RESULT.json']:
    add('predecessor-git/'+name,git_evidence/name)
preflight = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-rollout-01/preflight-read-03.log')
add('held-public/preflight-read-03.log',preflight)
snapshot = json.loads(next(line for line in preflight.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')))
assert snapshot['test']['revision'] == 'c70436f34eabb432d769e0082c0afa23303294b0'
assert snapshot['test']['capacity']['currentWsConnections'] == 1
source = Path('E:/mir2/Crystal')
for name in ['Server/MirObjects/NPC/NPCSegment.cs','Server/MirObjects/PlayerObject.cs',
    'Server/MirEnvir/Map.cs','Server/MirDatabase/MapInfo.cs']:
    add('original-crystal/'+name,source/name)
out.mkdir(parents=True)
archive = out/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in entries.items(): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(entries)
    assert all(z.read(name) == data for name,data in entries.items())
record = {'createdUtc':datetime.now(timezone.utc).isoformat(), 'baseSource':publication['head'],
    'ownerExecutionScopeIntegrated':True,'privatePopulationCapturePrepared':True,
    'localTestsPassed':True,'uniqueTestsPassed':len(names),'finalTests':records,
    'firstCompileFailureRetained':True,'wrongUnauthenticatedTurnTestExpectationRetained':True,
    'productionAuthenticationOrOriginalAssertionsChanged':False,
    'independentReviewReadOnly':True,'predecessorActuallyPushed':True,
    'earlierGitRestSshHttpsFailuresRetained':True,
    'newSourcePushed':False,'exactLinuxPassed':False,'gatewayPublished':False,'humanAccepted':False,
    'ordinaryNpcPopulationConsumerImplemented':False,'successfulSourceLoadProducerImplemented':False,
    'fullNpcPageBodyBindingImplemented':False,'standbyPopulationTranscriptImplemented':False,
    'sourceCasCapacityReservationWorldOutboxImplemented':False,
    'publicGateway':snapshot['test']['revision'],'publicClient':'R23/sourcefaef/signedfeed18',
    'qualifiedEcdRolloutHeld':True,'heldWsConnections':1,'productionSwitched':False,
    'limits':['21 selected input hashes, not whole Cargo/toolchain/workspace closure',
        'accepted request is not a replacement lease-validation receipt',
        'ordinary CHECKHUM still uses its original fixed-one adapter',
        'actor lifetime predicate does not prove population freshness or reserve capacity',
        'hosted Replay cleanup tests do not verify transport/journal read transcripts',
        'full P1-P7/Mentor/natural/native/human and exact new Linux remain open'],
    'archive':{'file':archive.name,'entries':len(entries),'bytes':archive.stat().st_size,
        'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'everyEntryByteVerified':True},
    'entries':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in entries.items()}}
(out/'EVIDENCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in record.items() if key not in ['entries','finalTests']},indent=2))
