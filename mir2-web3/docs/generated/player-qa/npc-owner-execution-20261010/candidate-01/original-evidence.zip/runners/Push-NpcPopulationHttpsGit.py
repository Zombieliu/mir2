import hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
out = Path('C:/mir2-build/p7-npc-population-20261010-git-publication-01/https-git-01')
parent = 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9'
head = '85586311e5e1bd2e36d9375b58dd972cae23cb7a'
branch = 'codex/gateway-disconnect-lifecycle-20261008'
git = ['git','-c','safe.directory='+repo.as_posix(),'-c','gc.auto=0',
       '-c','maintenance.auto=false','-C',str(repo)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip() == head
assert not subprocess.check_output(git+['status','--porcelain']).strip()
remote = subprocess.check_output(git+['remote','get-url','origin']).decode().strip()
assert remote in ['git@github.com:Zombieliu/mir2.git','https://github.com/Zombieliu/mir2.git']
out.mkdir()
read = subprocess.run(['gh','api','-H','Cache-Control: no-cache',
    'repos/Zombieliu/mir2/git/ref/heads/'+branch],capture_output=True,timeout=55)
(out/'before.json').write_bytes(read.stdout)
assert read.returncode == 0 and json.loads(read.stdout)['object']['sha'] == parent
env = os.environ.copy()
env['GIT_TERMINAL_PROMPT'] = '0'
env['GCM_INTERACTIVE'] = 'Never'
command = git+['push','--porcelain','https://github.com/Zombieliu/mir2.git',
               head+':refs/heads/'+branch]
try:
    result = subprocess.run(command,capture_output=True,timeout=55,env=env,stdin=subprocess.DEVNULL)
    stdout,stderr,code = result.stdout,result.stderr,result.returncode
except subprocess.TimeoutExpired as failure:
    stdout,stderr,code = failure.stdout or b'',failure.stderr or b'',124
(out/'stdout.private-log').write_bytes(stdout)
(out/'stderr.private-log').write_bytes(stderr)
after = subprocess.run(['gh','api','-H','Cache-Control: no-cache',
    'repos/Zombieliu/mir2/git/ref/heads/'+branch],capture_output=True,timeout=55)
(out/'after.json').write_bytes(after.stdout)
actual = json.loads(after.stdout)['object']['sha'] if after.returncode == 0 else None
record = {'createdUtc':datetime.now(timezone.utc).isoformat(),'source':head,'parent':parent,
    'force':False,'onlyRequestedBranch':branch,'pushExit':code,'remoteAfter':actual,
    'sourcePublishedAndVerified':actual == head,'originalRemoteConfigurationUnchanged':True,
    'originalOutputRetainedPrivately':True,'stderrSha256':hashlib.sha256(stderr).hexdigest(),
    'terminalAndCredentialUiDisabled':True,
    'possibleCorruptObjectFailure':any(value in stderr.lower() for value in
        [b'corrupt',b'bad object',b'unable to read',b'missing object']),
    'authenticationFailure':any(value in stderr.lower() for value in
        [b'authentication failed',b'could not read username',b'could not read password']),
    'gatewayPublished':False}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
if actual == head:
    publication = {'createdUtc':record['createdUtc'],'repository':'Zombieliu/mir2','branch':branch,
        'head':head,'parent':parent,'tree':'85587918e4b91f22e2b120a154f608f2513047b5',
        'transport':'ordinary HTTPS git push','force':False,'remoteExactHeadVerified':True,
        'readbackSha256':hashlib.sha256(after.stdout).hexdigest(),
        'candidateSourcePublishedToGit':True,'foundationIntegratedIntoNpc':False,
        'newLinuxPassed':False,'gatewayPublished':False}
    with (out.parent/'exact-api/PUBLISHED-VERIFIED.json').open('x',encoding='utf-8') as stream:
        json.dump(publication,stream,indent=2)
elif code:
    raise SystemExit(code)
else:
    raise RuntimeError('Push result not attested by fresh exact remote readback')
