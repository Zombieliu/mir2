"""Exact immutable tree and guarded fast-forward when Git MCP tools are absent."""
import argparse, hashlib, json, subprocess
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--phase', choices=['tree','ref'], required=True)
args = parser.parse_args()
root = Path('C:/mir2-build/p7-npc-population-20261010-git-publication-01/exact-api')
prepared = json.loads((root/'PREPARED-OBJECTS.json').read_bytes())
assert prepared['commit'] == '85586311e5e1bd2e36d9375b58dd972cae23cb7a'
assert prepared['parent'] == 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9'
assert prepared['tree'] == '85587918e4b91f22e2b120a154f608f2513047b5'
assert prepared['branch'] == 'codex/gateway-disconnect-lifecycle-20261008'
repository = 'Zombieliu/mir2'
def api(endpoint, stem, method=None, body=None):
    command = ['gh','api','-H','Cache-Control: no-cache','repos/'+repository+'/'+endpoint]
    if body is not None:
        request = root/(stem+'-REQUEST.json')
        with request.open('x',encoding='utf-8') as stream: json.dump(body,stream,indent=2)
        command += ['--method',method,'--input',str(request)]
    try:
        result = subprocess.run(command,capture_output=True,timeout=55)
        stdout,stderr,code = result.stdout,result.stderr,result.returncode
    except subprocess.TimeoutExpired as failure:
        stdout,stderr,code = failure.stdout or b'',failure.stderr or b'',124
    with (root/(stem+'-RESULT.json')).open('xb') as stream: stream.write(stdout)
    with (root/(stem+'-STDERR.log')).open('xb') as stream: stream.write(stderr)
    if code:
        raise RuntimeError(f'{stem} exit {code}; original retained, read back before repeating')
    return json.loads(stdout)
current = api('git/ref/heads/'+prepared['branch'],args.phase.upper()+'-PRECONDITION')
assert current['object']['sha'] == prepared['parent'], 'Branch must remain exact predecessor'
if args.phase == 'tree':
    request = json.loads((root/'TREE-REQUEST.json').read_bytes())
    assert request['repository_full_name'] == repository and len(request['tree_elements']) == 20
    result = api('git/trees','TREE-REST','POST',
        {'base_tree':request['base_tree_sha'],'tree':request['tree_elements']})
    assert result['sha'] == prepared['tree'] and result.get('truncated') is False
    with (root/'TREE-RESULT.json').open('x',encoding='utf-8') as stream: json.dump(result,stream,indent=2)
    print(json.dumps({'actualTransport':'gh REST','mcpGitToolsAvailable':False,
        'tree':result['sha'],'exactIdentityVerified':True,'branchUpdated':False}))
else:
    request = json.loads((root/'REF-REQUEST.json').read_bytes())
    assert request == {'repository_full_name':repository,'branch_name':prepared['branch'],
        'expected_sha':prepared['parent'],'sha':prepared['commit'],'force':False}
    commit = api('git/commits/'+prepared['commit'],'REF-EXACT-COMMIT')
    assert commit['sha'] == prepared['commit'] and commit['tree']['sha'] == prepared['tree']
    assert [row['sha'] for row in commit['parents']] == [prepared['parent']]
    # GitHub REST does not expose expected_sha. Recheck exact predecessor,
    # then require a non-forced fast-forward; a divergent concurrent writer
    # cannot be overwritten. There is no claim of an atomic expected-sha API.
    current = api('git/ref/heads/'+prepared['branch'],'REF-IMMEDIATE-PRECONDITION')
    assert current['object']['sha'] == prepared['parent']
    result = api('git/refs/heads/'+prepared['branch'],'REF-REST','PATCH',
        {'sha':prepared['commit'],'force':False})
    assert result['object']['sha'] == prepared['commit']
    current = api('git/ref/heads/'+prepared['branch'],'REF-FRESH-READBACK')
    assert current['object']['sha'] == prepared['commit']
    record = {'createdUtc':datetime.now(timezone.utc).isoformat(),'repository':repository,
        'branch':prepared['branch'],'head':prepared['commit'],'parent':prepared['parent'],
        'tree':prepared['tree'],'force':False,'transport':'gh REST; Git MCP not available',
        'exactPredecessorReadImmediatelyBeforePatch':True,'atomicExpectedShaApi':False,
        'nonForcedFastForwardRequired':True,'remoteExactHeadVerified':True,
        'readbackSha256':hashlib.sha256((root/'REF-FRESH-READBACK-RESULT.json').read_bytes()).hexdigest(),
        'candidateSourcePublishedToGit':True,'foundationIntegratedIntoNpc':False,
        'newLinuxPassed':False,'gatewayPublished':False}
    with (root/'PUBLISHED-VERIFIED.json').open('x',encoding='utf-8') as stream:
        json.dump(record,stream,indent=2)
    print(json.dumps(record))
