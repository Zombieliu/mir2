param([Parameter(Mandatory=$true)][string]$LogStem,[Parameter(Mandatory=$true)][string[]]$ToolArgs)
$ErrorActionPreference='Stop'
$taskRoot='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p7-npc-owner-binding-20261010-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
New-Item -ItemType Directory -Path $taskEvidence -Force | Out-Null
Set-Location -LiteralPath $taskRoot
$taskPaths=@('Cargo.lock','Cargo.toml','apps/simulation/Cargo.toml','apps/gateway/Cargo.toml','apps/simulation/src/lib.rs','apps/simulation/src/world_runtime.rs','apps/simulation/src/runtime/mod.rs','apps/simulation/src/runtime/npc_population.rs','apps/simulation/src/runtime/npc_script.rs','apps/simulation/src/runtime/default_npc_events.rs','apps/simulation/src/runtime/shared_guild_experience.rs','apps/simulation/src/runtime/zone/mod.rs','apps/simulation/src/runtime/zone/manager.rs','apps/simulation/src/runtime/zone/npc_population.rs','apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/online_identity.rs','apps/gateway/src/routing.rs','apps/gateway/src/routing/npc_population_binding.rs','apps/gateway/src/zone_rpc.rs','apps/gateway/tests/shared_purification_map_transfer.rs','../.github/workflows/gateway-release.yml')
if (Test-Path -LiteralPath "$taskEvidence/$LogStem.log") { throw 'Original evidence stem already exists' }
$taskCommand=@('cargo')+$ToolArgs
function Write-SourceHashes([string]$phase) {
 $taskHashes=@($taskPaths | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
 [ordered]@{declaredBaseSource='85586311e5e1bd2e36d9375b58dd972cae23cb7a';utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=$taskCommand;scope="$($taskPaths.Count) selected paths, not whole-workspace input closure";source=$taskHashes} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding UTF8
}
Write-SourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& cargo @ToolArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Write-SourceHashes 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;log="$taskEvidence/$LogStem.log"} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 48
exit $taskExit
