"""Prepare exact local Git objects; branch advancement remains a separate guarded call."""
import argparse
import base64
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--parent',required=True)
    parser.add_argument('--branch',required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--phase',choices=['objects','commit'],required=True)
    args=parser.parse_args()
    repository='Zombieliu/mir2'
    def git(*values):
        return subprocess.run(['git','-c','safe.directory='+args.repo.as_posix(),'-c','gc.auto=0',
            '-c','maintenance.auto=false','-C',str(args.repo),*values],capture_output=True,check=True).stdout
    target=git('rev-parse','HEAD').decode().strip()
    assert git('rev-parse','HEAD^').decode().strip()==args.parent
    assert args.repo.resolve()==Path('C:/Users/Administrator/.codex/worktrees/npc-population-85586311e5/mir2-player-journey').resolve()
    assert target=='85586311e5e1bd2e36d9375b58dd972cae23cb7a'
    assert args.branch=='codex/gateway-disconnect-lifecycle-20261008'
    assert not git('branch','--show-current').decode().strip(), 'The pinned managed checkout must remain detached'
    assert not git('status','--porcelain=v1','--untracked-files=all')
    counter=0
    if args.phase=='objects':
        args.out.mkdir()
    else:
        assert args.out.is_dir()
        counter=1000
    def api(endpoint,body=None):
        nonlocal counter
        for attempt in range(1,4):
            counter+=1
            command=['gh','api','repos/'+repository+'/'+endpoint]
            if body is not None:
                path=args.out/('request-%04d.json'%counter)
                with path.open('x',encoding='utf-8') as stream:json.dump(body,stream,ensure_ascii=False)
                command+=['--method','POST','--input',str(path)]
            try:
                result=subprocess.run(command,capture_output=True,timeout=55)
                output,error,code=result.stdout,result.stderr,result.returncode
            except subprocess.TimeoutExpired as failure:
                output,error,code=failure.stdout or b'',failure.stderr or b'',124
            (args.out/('response-%04d.json'%counter)).write_bytes(output)
            (args.out/('stderr-%04d.log'%counter)).write_bytes(error)
            if code==0:return json.loads(output)
            print(json.dumps({'boundedApiFailure':attempt,'exitCode':code,'responseRetained':True}),flush=True)
        raise RuntimeError('Three API failures; no ref update attempted')
    assert api('git/ref/heads/'+args.branch)['object']['sha']==args.parent,'Ref must still be the exact predecessor'
    raw=git('cat-file','commit',target).decode()
    header,message=raw.split('\n\n',1)
    fields={}
    for line in header.splitlines():
        key,value=line.split(' ',1)
        fields.setdefault(key,[]).append(value)
    assert set(fields)=={'tree','parent','author','committer'} and fields['parent']==[args.parent]
    files=git('diff','--name-only',args.parent,target).decode().splitlines()
    assert 0<len(files)<=150
    if args.phase=='objects':
        entries=[]
        for name in sorted(files):
            row=git('ls-tree','-z',target,'--',name).decode().rstrip('\0')
            props,actual=row.split('\t',1)
            mode,kind,digest=props.split()
            assert mode in ('100644','100755') and kind=='blob' and actual==name
            data=git('cat-file','blob',digest)
            assert 0<len(data)<=3*1024*1024
            if name.endswith('.github/workflows/gateway-release.yml'):
                assert args.branch=='codex/gateway-disconnect-lifecycle-20261008'
            blob=api('git/blobs',{'encoding':'base64','content':base64.b64encode(data).decode('ascii')})
            assert blob['sha']==digest
            entries.append({'path':name,'mode':mode,'type':'blob','sha':digest})
            print(json.dumps({'verifiedBlob':name,'bytes':len(data)}),flush=True)
        request={'repository_full_name':repository,'base_tree_sha':git('rev-parse',args.parent+'^{tree}').decode().strip(),
                 'tree_elements':entries}
        with (args.out/'TREE-REQUEST.json').open('x',encoding='utf-8') as stream:json.dump(request,stream,indent=2)
        proof={'repository':repository,'branch':args.branch,'commit':target,'parent':args.parent,
               'tree':fields['tree'][0],'files':files,'branchUpdated':False}
        with (args.out/'PREPARED-OBJECTS.json').open('x',encoding='utf-8') as stream:json.dump(proof,stream,indent=2)
        print(json.dumps({key:proof[key] for key in ('commit','parent','tree','branchUpdated')}),flush=True)
    else:
        proof=json.loads((args.out/'PREPARED-OBJECTS.json').read_bytes())
        result=json.loads((args.out/'TREE-RESULT.json').read_bytes())
        assert proof['commit']==target and proof['parent']==args.parent and result['sha']==fields['tree'][0]
        tree=api('git/trees/'+fields['tree'][0])
        assert tree['sha']==fields['tree'][0]
        def identity(value):
            found=re.fullmatch(r'(.*) <([^>]+)> (\d+) ([+-]\d{4})',value)
            assert found
            name,email,epoch,offset=found.groups()
            minutes=(int(offset[1:3])*60+int(offset[3:]))*(-1 if offset[0]=='-' else 1)
            date=datetime.datetime.fromtimestamp(int(epoch),datetime.timezone(datetime.timedelta(minutes=minutes))).isoformat(timespec='seconds')
            return {'name':name,'email':email,'date':date}
        commit=api('git/commits',{'tree':fields['tree'][0],'parents':[args.parent],'message':message,
            'author':identity(fields['author'][0]),'committer':identity(fields['committer'][0])})
        assert commit['sha']==target,'Original exact commit identity required'
        assert api('git/ref/heads/'+args.branch)['object']['sha']==args.parent
        request={'repository_full_name':repository,'branch_name':args.branch,'expected_sha':args.parent,
                 'sha':target,'force':False}
        with (args.out/'REF-REQUEST.json').open('x',encoding='utf-8') as stream:json.dump(request,stream,indent=2)
        print(json.dumps({'commit':target,'tree':fields['tree'][0],'exactIdentityVerified':True,'branchUpdated':False}),flush=True)

if __name__=='__main__':main()
