from pathlib import Path
import hashlib, json

base = Path(__file__).resolve().parent
receipt = json.loads((base / 'commands/resume-final-02.command.json').read_text())
assert receipt['exitCode'] == 101 and receipt['guard'] is None
source = Path(receipt['cwd']) / 'src/resume_tests.rs'
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == receipt['sourceBefore']['src/resume_tests.rs']['sha256']
with (base / 'raw-header-fixture-diagnostic-source/resume_tests-before-03.rs').open('xb') as stream:
    stream.write(data)
with (base / 'raw-header-fixture-diagnostic-source/DIAGNOSTIC-02.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'sourceSha256': hashlib.sha256(data).hexdigest(), 'result': '12 pass / 1 grouped fixture failure',
               'failedCase': 'pinned ureq ignores invalid unknown header-name tokens at response.rs583-589',
               'nextFixture': '101 actual valid headers exercises BadHeader/MAX_HEADER_COUNT100',
               'dependencyChanged': False, 'productionChangedForFixture': False}, stream, indent=2)
    stream.write('\n')
print('second raw header parser boundary retained before fixture correction')
