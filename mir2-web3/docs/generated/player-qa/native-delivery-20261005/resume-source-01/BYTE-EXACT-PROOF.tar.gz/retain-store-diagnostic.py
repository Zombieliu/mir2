from pathlib import Path
import hashlib, json

base = Path(__file__).resolve().parent
data = (base / 'store-proof.py').read_bytes()
with (base / 'store-proof.failed01.py').open('xb') as stream:
    stream.write(data)
with (base / 'STORE-PREFLIGHT-FAILURE-01.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'sourceSha256': hashlib.sha256(data).hexdigest(), 'reportedToolExitCode': 1,
               'reportedError': 'SyntaxError: closing parenthesis does not match opening bracket at line62',
               'phase': 'Python parse before any program statement', 'sourceOrOutputWrittenByFailedRun': False,
               'productTestFailure': False}, stream, indent=2)
    stream.write('\n')
print('inert proof-helper parse diagnostic retained')
