from pathlib import Path
import datetime, hashlib, json, os, re, stat, tarfile

BASE = Path(__file__).resolve().parent
ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
OUTPUT = ROOT / 'mir2-web3/docs/generated/player-qa/native-delivery-20261005/resume-source-01'
crate = ROOT / 'mir2-web3/apps/game-client/windows-updater'
unit = json.loads((BASE / 'commands/adjacent-library-final-02.command.json').read_text())
check = json.loads((BASE / 'commands/entrypoints-final-01.command.json').read_text())
for receipt in [unit, check]:
    assert receipt['exitCode'] == 0 and receipt['guard'] is None and receipt['processExited']
    for name in ['stdout', 'stderr']:
        data = Path(receipt[name]['path']).read_bytes()
        assert len(data) == receipt[name]['bytes'] and hashlib.sha256(data).hexdigest() == receipt[name]['sha256']
stdout = Path(unit['stdout']['path']).read_text()
assert '65 passed; 0 failed; 4 ignored;' in stdout
new_passes = re.findall(r'^test update::resume_tests::(\S+) \.\.\. ok$', stdout, re.M)
assert len(new_passes) == 14
final_source = BASE / 'final-source'
final_source.mkdir(exist_ok=False)
for relative, expected in unit['sourceBefore'].items():
    data = (crate / relative).read_bytes()
    assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    assert check['sourceBefore'][relative] == expected
    target = final_source / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream: stream.write(data)
result = {'createdUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'parentCommit': '2afdac8ca4d06e30d9fe4d40c283d301b884ace3',
          'source': unit['sourceBefore'], 'unitPassed': 65, 'unitFailed': 0, 'unitIgnored': 4,
          'newResumeTestsIncludedInUnitCount': new_passes,
          'newResumeTestsOverlapEarlierFocusedRuns': True,
          'actualNetwork': 'test-only loopback HTTP, synthetic immutable FileEntry fixtures',
          'realWindowsHandleChecks': True, 'actualCdnHttpsOrCmsCheckedThisRound': False,
          'actualLinuxCheckedThisRound': False, 'realPartialResumeInstallOrSpeedAccepted': False,
          'releaseEngineBuiltOrPublished': False, 'gatewayRestarted': False, 'userInstallOrSavesChanged': False,
          'rawFailuresRetained': ['resume-red-01', 'bundle-interruption-red-01', 'resume-final-01', 'resume-final-02'],
          'dependencyParserBoundary': 'unknown colonless headers are tolerated; invalid unknown names are discarded by pinned ureq; replacement101-header fixture verifies its actual BadHeader path',
          'journalSchema': 1, 'existingShaSyncAndFreshGameGuardsPreserved': True}
with (BASE / 'FINAL-SOURCE-REVIEW.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(result, stream, indent=2); stream.write('\n')
files = []
for directory, directories, names in os.walk(BASE, followlinks=False):
    directories[:] = [name for name in directories if name != 'owned-temp']
    for name in sorted(names):
        path = Path(directory) / name
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not (getattr(info, 'st_file_attributes', 0) & 0x400)
        assert path.resolve().is_relative_to(BASE.resolve())
        data = path.read_bytes()
        files.append({'path': path.relative_to(BASE).as_posix(), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
files.sort(key=lambda item: item['path'])
OUTPUT.mkdir(exist_ok=False)
with (OUTPUT / '.gitattributes').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write('* -text -diff\n**/* -text -diff\nREADME.md text eol=lf diff\n')
archive = OUTPUT / 'BYTE-EXACT-PROOF.tar.gz'
with archive.open('xb') as stream:
    with tarfile.open(fileobj=stream, mode='w:gz') as tar:
        for record in files:
            tar.add(BASE / record['path'], arcname=record['path'], recursive=False)
for source, target_name in [(BASE / 'FINAL-SOURCE-REVIEW.json', 'FINAL-SOURCE-REVIEW.json'),
                           (BASE / 'commands/adjacent-library-final-02.command.json', 'WINDOWS-UNIT-COMMAND.json'),
                           (BASE / 'commands/adjacent-library-final-02.stdout.log', 'WINDOWS-UNIT.stdout.log'),
                           (BASE / 'commands/adjacent-library-final-02.stderr.log', 'WINDOWS-UNIT.stderr.log'),
                           (BASE / 'commands/entrypoints-final-01.command.json', 'WINDOWS-ENTRYPOINTS-COMMAND.json')]:
    with (OUTPUT / target_name).open('xb') as stream: stream.write(source.read_bytes())
data = archive.read_bytes()
inventory = {'archive': {'path': archive.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()},
             'members': files, 'count': len(files), 'ownedTempAndBuildArtifactsExcluded': True}
with (OUTPUT / 'PROOF-INVENTORY.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(inventory, stream, indent=2); stream.write('\n')
print(json.dumps({'proofMembers': len(files), 'archiveBytes': len(data), 'archiveSha256': inventory['archive']['sha256'], 'unitPassed': 65, 'newTestsIncluded': 14}))
