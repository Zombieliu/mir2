from pathlib import Path
import hashlib, json

base = Path(__file__).resolve().parent
receipt = json.loads((base / 'commands/resume-red-01.command.json').read_text())
assert receipt['exitCode'] == 101 and receipt['guard'] is None
root = Path(receipt['cwd'])
out = base / 'red-source'
out.mkdir(exist_ok=False)
records = []
for relative, expected in receipt['sourceBefore'].items():
    data = (root / relative).read_bytes()
    assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
    records.append({'path': relative, **expected})
with (out / 'RED-SOURCE-FREEZE.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'baselineCommit': '2afdac8ca4d06e30d9fe4d40c283d301b884ace3', 'sources': records,
               'actualAssertionFailure': 'interruption must retain the partial resource',
               'publishedChanged': False, 'signedFilesActivated': False}, stream, indent=2)
    stream.write('\n')
print('genuine loopback interruption RED and exact old source retained')
