from pathlib import Path
import hashlib, json

base = Path(__file__).resolve().parent
receipt = json.loads((base / 'commands/bundle-interruption-red-01.command.json').read_text())
assert receipt['exitCode'] == 101 and receipt['guard'] is None
root = Path(receipt['cwd'])
out = base / 'bundle-red-source'
out.mkdir(exist_ok=False)
for relative, expected in receipt['sourceBefore'].items():
    data = (root / relative).read_bytes()
    assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
with (out / 'RED-SOURCE-FREEZE.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'sources': receipt['sourceBefore'],
               'actualAssertionFailure': 'network interruption must stop instead of switching to raw file downloads',
               'publishedChanged': False, 'signedFilesActivated': False}, stream, indent=2)
    stream.write('\n')
print('actual accelerator interruption RED and exact pre-fix source retained')
