from pathlib import Path
import hashlib, json

base = Path(__file__).resolve().parent
receipt = json.loads((base / 'commands/resume-final-01.command.json').read_text())
assert receipt['exitCode'] == 101 and receipt['guard'] is None
root = Path(receipt['cwd'])
out = base / 'raw-header-fixture-diagnostic-source'
out.mkdir(exist_ok=False)
for relative, expected in receipt['sourceBefore'].items():
    data = (root / relative).read_bytes()
    assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    target = out / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
with (out / 'DIAGNOSTIC.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump({'sources': receipt['sourceBefore'], 'result': '12 pass / 1 failed grouped test',
               'failedCase': 'unknown colonless bad-header-without-colon was accepted by pinned ureq',
               'boundary': 'payload checks validate interpreted size/range/encoding/framing and SHA; not all HTTP grammar beyond ureq parser',
               'nextFixture': 'invalid token in header name exercises the actual BadHeader error path',
               'dependencyChanged': False, 'publishedChanged': False}, stream, indent=2)
    stream.write('\n')
print('raw parser/fixture diagnostic and exact source retained')
