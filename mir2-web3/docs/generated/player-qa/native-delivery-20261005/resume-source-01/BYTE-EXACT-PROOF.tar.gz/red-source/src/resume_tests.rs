//! Actual loopback HTTP/body/file regressions. HTTPS/CMS and public CDN
//! acceptance remain separate; production origins and redirect rules stay pinned.
use super::*;
use std::{
    net::TcpListener,
    sync::{Arc, Mutex},
    thread,
};

struct Reply {
    source: HttpsSource,
    request: Arc<Mutex<String>>,
    server: thread::JoinHandle<()>,
}
impl Reply {
    fn new(status: &str, headers: &str, body: Vec<u8>) -> Self {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        listener.set_nonblocking(true).unwrap();
        let base = url::Url::parse(&format!("http://{}/updates/", listener.local_addr().unwrap()))
            .unwrap();
        let response = format!("HTTP/1.1 {status}\r\nConnection: close\r\n{headers}\r\n");
        let request = Arc::new(Mutex::new(String::new()));
        let captured = request.clone();
        let server = thread::spawn(move || {
            let start = Instant::now();
            let mut stream = loop {
                match listener.accept() {
                    Ok((stream, _)) => break stream,
                    Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                        assert!(start.elapsed() < Duration::from_secs(5), "HTTP test request missing");
                        thread::sleep(Duration::from_millis(5));
                    }
                    Err(e) => panic!("HTTP test accept: {e}"),
                }
            };
            stream.set_read_timeout(Some(Duration::from_secs(5))).unwrap();
            stream.set_write_timeout(Some(Duration::from_secs(5))).unwrap();
            let mut bytes = Vec::new();
            let mut buf = [0u8; 1024];
            while !bytes.windows(4).any(|w| w == b"\r\n\r\n") {
                let n = stream.read(&mut buf).unwrap();
                assert!(n != 0 && bytes.len() + n <= 16384);
                bytes.extend_from_slice(&buf[..n]);
            }
            *captured.lock().unwrap() = String::from_utf8(bytes).unwrap();
            // Rejection/cancellation may close the reader before the response ends.
            let _ = stream.write_all(response.as_bytes());
            let _ = stream.write_all(&body);
        });
        let source = HttpsSource {
            base: base.clone(),
            legacy_base: base,
            agent: ureq::AgentBuilder::new()
                .redirects(0)
                .timeout_connect(Duration::from_secs(2))
                .timeout_read(Duration::from_secs(2))
                .build(),
        };
        Self { source, request, server }
    }
    fn finish(self) -> String {
        self.server.join().unwrap();
        Arc::try_unwrap(self.request).unwrap().into_inner().unwrap()
    }
}

struct Quiet;
impl Status for Quiet {
    fn set(&self, _: &str, _: u32) {}
    fn cancelled(&self) -> bool { false }
}
fn entry(data: &[u8]) -> FileEntry {
    FileEntry { path: "delivery/resource.m2b.gz".into(), size: data.len() as u64, sha256: hash(data) }
}
fn part(root: &Path, entry: &FileEntry) -> PathBuf {
    root.join(format!(".update/downloads/{}.part", entry.sha256))
}

#[test]
fn red_interrupted_http_preserves_prefix_then_reopen_requests_only_remaining_bytes() {
    let root = tempfile::tempdir().unwrap();
    let data: Vec<u8> = (0..262144).map(|i| (i % 251) as u8).collect();
    let file = entry(&data);
    let interrupted = Reply::new("200 OK", &format!("Content-Length: {}\r\n", data.len()), data[..131072].to_vec());
    let mut first = Transfers::default();
    assert!(cached_payload(root.path(), &interrupted.source, "releases/test/resource.m2b.gz", &file, &Quiet, (0, file.size), &mut first).is_err());
    let request = interrupted.finish();
    assert!(!request.to_ascii_lowercase().contains("range:"));
    let prefix = safe::read_bounded(&part(root.path(), &file), file.size).expect("interruption must retain the partial resource");
    assert!(!prefix.is_empty() && prefix.len() < data.len());
    assert_eq!(prefix, data[..prefix.len()]);
    let offset = prefix.len();
    let remaining = Reply::new("206 Partial Content", &format!("Content-Length: {}\r\nContent-Range: bytes {}-{}/{}\r\n", data.len()-offset, offset, data.len()-1, data.len()), data[offset..].to_vec());
    let mut second = Transfers::default();
    let (cache, downloaded) = cached_payload(root.path(), &remaining.source, "releases/test/resource.m2b.gz", &file, &Quiet, (0, file.size), &mut second).unwrap();
    let request = remaining.finish().to_ascii_lowercase();
    assert!(request.contains(&format!("range: bytes={offset}-\r\n")));
    assert!(request.contains("accept-encoding: identity\r\n"));
    assert!(downloaded && safe::matches(&cache, &file).unwrap());
    assert_eq!(second.wire_bytes, (data.len()-offset) as u64);
    assert_eq!(second.downloaded_bytes, second.wire_bytes);
    assert!(!part(root.path(), &file).exists());
    assert!(!root.path().join("game").exists(), "download does not install or launch");
}
