from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, time

BASE = Path(__file__).resolve().parent
ROOT = Path(subprocess.check_output(['git', '-c', 'gc.auto=0', 'rev-parse', '--show-toplevel'], text=True).strip())
CRATE = ROOT / 'mir2-web3/apps/game-client/windows-updater'
name, timeout, *argv = sys.argv[1:]
assert name.replace('-', '').isalnum() and argv
timeout = int(timeout)
assert 1 <= timeout <= 7200
assert subprocess.check_output(['git', '-c', 'gc.auto=0', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == 'b87aa8a8ac94d569893a1ee653be49d857d2b063'
assert shutil.disk_usage('C:/').free >= 50 * 1024**3
prefix = BASE / 'commands' / name
prefix.parent.mkdir(exist_ok=True)
owned_temp = BASE / 'owned-temp'
owned_temp.mkdir(exist_ok=True)
env = dict(os.environ, TEMP=str(owned_temp), TMP=str(owned_temp))

def fingerprint(paths, parent):
    return {p.relative_to(parent).as_posix(): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths}
def source_hashes():
    files = sorted(CRATE.joinpath('src').rglob('*.rs'))
    files += [CRATE / name for name in ['Cargo.toml', 'Cargo.lock', 'scripts/build-updater-release.ps1', 'scripts/verify-updater-bundle.ps1']]
    return fingerprint(files, ROOT)
def helper_hashes():
    return fingerprint([BASE / name for name in ['run.py', 'run-signed.ps1', 'fixtures-fresh.json', 'fixtures-delta.json']], BASE)

before = source_hashes()
helpers_before = helper_hashes()
revision = subprocess.check_output(['git', '-c', 'gc.auto=0', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
start = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
minimum_free = shutil.disk_usage('C:/').free
guard = None
with prefix.with_suffix('.stdout.log').open('xb') as out, prefix.with_suffix('.stderr.log').open('xb') as err:
    child = subprocess.Popen(argv, cwd=CRATE, env=env, stdout=out, stderr=err)
    with prefix.with_suffix('.running.json').open('x', encoding='utf-8') as stream:
        json.dump({'pid': child.pid, 'argv': argv, 'startedUtc': started, 'sourceRevision': revision, 'timeoutSeconds': timeout}, stream)
    print(json.dumps({'name': name, 'childPid': child.pid, 'startedUtc': started}), flush=True)
    while child.poll() is None:
        minimum_free = min(minimum_free, shutil.disk_usage('C:/').free)
        if minimum_free < 50 * 1024**3 or time.monotonic() - start > timeout:
            guard = 'owned command resource/time limit'
            # Only this wrapper's live child process and its descendants are stopped.
            subprocess.run(['taskkill', '/PID', str(child.pid), '/T', '/F'], stdout=out, stderr=err, timeout=30, check=False)
            if child.poll() is None:
                child.kill()
            break
        time.sleep(0.2)
    rc = child.wait()
after = source_hashes()
receipt = {'argv': argv, 'cwd': str(CRATE), 'sourceRevision': revision, 'startedUtc': started,
           'pid': child.pid, 'exitCode': rc, 'elapsedSeconds': time.monotonic() - start,
           'minimumCFreeBytes': minimum_free, 'guard': guard, 'timeoutSeconds': timeout,
           'ownedTemp': str(owned_temp), 'processExited': True, 'sourceBefore': before,
           'sourceAfter': after, 'compiledSourceUnchanged': before == after,
           'helperSourceBefore': helpers_before, 'helperSourceAfter': helper_hashes(),
           'publicationPerformed': False, 'userInstallationTouched': False}
for stream in ['stdout', 'stderr']:
    p = prefix.with_suffix('.' + stream + '.log')
    data = p.read_bytes()
    receipt[stream] = {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
with prefix.with_suffix('.command.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({'name': name, 'passed': rc == 0 and before == after, 'exitCode': rc,
                 'elapsedSeconds': receipt['elapsedSeconds'], 'receipt': str(prefix.with_suffix('.command.json'))}))
sys.exit(rc if rc else (0 if before == after else 1))
