param([ValidateSet('build','fresh','delta')][string]$Mode)
$ErrorActionPreference = 'Stop'
$base = 'C:/mir2-playtest-releases/20261004-native-r18/current-signed-release-qa-01'
$target = 'C:/mir2-build/updater-resume-release-20261005'
if ($Mode -eq 'build') {
    & cargo +1.95.0 test --offline --locked --jobs 2 --release --manifest-path Cargo.toml --target-dir $target --lib --no-run
} else {
    $env:MIR2_UPDATER_DELIVERY_FIXTURES = "$base/fixtures-$Mode.json"
    $test = if ($Mode -eq 'fresh') {
        'signed_metadata_only_seed_uses_bundles_and_failed_first_launch_restores_incomplete_seed'
    } else {
        'signed_delta_then_tampered_delivery_fallback_preserve_state_and_zero_payload_recheck'
    }
    & cargo +1.95.0 test --offline --locked --jobs 2 --release --manifest-path Cargo.toml --target-dir $target --lib $test -- --ignored --test-threads=1 --nocapture
}
exit $LASTEXITCODE
