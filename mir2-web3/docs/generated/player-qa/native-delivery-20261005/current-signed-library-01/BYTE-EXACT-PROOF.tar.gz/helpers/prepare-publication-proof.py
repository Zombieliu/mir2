"""Create an isolated actual CMS/closure verifier for the exact built preview.

No credentials, signing, network, install, or promotion. Old tooling is copied
byte-for-byte except the source assertion, explicitly bound to the real build.
"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
BASE = Path('C:/mir2-playtest-releases/20261004-native-r18/current-signed-release-qa-01/publication-proof-01')
OLD = Path('C:/mir2-playtest-releases/20261004-native-r18/native-updater-progress-worker-01/updater/scripts')
BUILD = Path('C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/commands/build-engine-01.command.json')
ENGINE_SOURCE = '48454bba7623694ca7432613af52bee28e83970e'
ROOT_HEAD = 'b87aa8a8ac94d569893a1ee653be49d857d2b063'

def git(*args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-C', str(ROOT), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD').decode().strip() == ROOT_HEAD
assert not git('status', '--porcelain=v1', '--untracked-files=all')
build = json.loads(BUILD.read_bytes())
assert build['exitCode'] == 0 and build['compiledSourceUnchanged'] is True
assert build['sourceRevision'] == ENGINE_SOURCE
assert build['sourceBefore'] == build['sourceAfter'] and len(build['sourceBefore']) == 20
source_representations = {}
for rel, record in build['sourceBefore'].items():
    assert rel.startswith('mir2-web3/apps/game-client/windows-updater/')
    data = (ROOT / rel).read_bytes()
    assert len(data) == record['bytes'] and sha(data) == record['sha256']
    canonical = git('show', ENGINE_SOURCE + ':' + rel)
    checkout = git('cat-file', '--filters', ENGINE_SOURCE + ':' + rel)
    assert data == canonical or data == checkout
    source_representations[rel] = {'physicalSHA256': sha(data),
        'canonicalGitSHA256': sha(canonical), 'gitCheckoutSHA256': sha(checkout),
        'canonicalEqual': data == canonical, 'checkoutEqual': data == checkout}

BASE.mkdir(exist_ok=False)
tools = BASE / 'tools'
tools.mkdir()
names = ['prepare-signed-native-publication.ps1', 'prepare-native-publication.py',
         'verify-native-delivery.py', 'archive-update-release.py', 'publish-native-r2.py']
bindings = {}
for name in names:
    data = (OLD / name).read_bytes()
    bindings[name] = {'originalSHA256': sha(data), 'originalBytes': len(data)}
    if name == names[0]:
        original = data.decode('utf-8')
        project = "$project=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../..'))"
        assert original.count(project) == 1
        original = original.replace(project, "$project='" + str(ROOT / 'mir2-web3').replace('\\', '/') + "'")
        start = original.index('function AssertSource {')
        end = original.index('\nAssertSource', start)
        original_assertion = original[start:end]
        assert "Exact clean committed publication tooling required" in original_assertion
        replacement = r'''function AssertSource {
    $repo='C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey'
    if((& git -c gc.auto=0 -C $repo rev-parse HEAD).Trim()-cne'b87aa8a8ac94d569893a1ee653be49d857d2b063' -or $LASTEXITCODE-ne0 -or
       @(& git -c gc.auto=0 -C $repo status --porcelain=v1 --untracked-files=all).Count-ne0){throw 'Exact clean verifier root required'}
    if($SourceRevision-cne'48454bba7623694ca7432613af52bee28e83970e'){throw 'Exact built engine source required'}
    $build=Get-Content -LiteralPath 'C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/commands/build-engine-01.command.json' -Raw|ConvertFrom-Json
    if($build.exitCode-ne0 -or $build.compiledSourceUnchanged-ne$true -or $build.sourceRevision-cne$SourceRevision){throw 'Actual unchanged successful build required'}
    $entries=@($build.sourceBefore.PSObject.Properties)
    if($entries.Count-ne20){throw 'Exact20 build inputs required'}
    foreach($entry in $entries){
        if(!$entry.Name.StartsWith('mir2-web3/apps/game-client/windows-updater/') -or $entry.Name.Contains('..')){throw 'Build input scope'}
        $path=Join-Path $repo $entry.Name;NoLinks $path
        $actual=Get-Item -LiteralPath $path -Force
        if($actual.Length-ne$entry.Value.bytes -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()-cne$entry.Value.sha256){throw 'Build source changed'}
        $after=$build.sourceAfter.PSObject.Properties[$entry.Name].Value
        if($after.bytes-ne$entry.Value.bytes -or $after.sha256-cne$entry.Value.sha256){throw 'Build before/after mismatch'}
    }
}'''
        updated = original[:start] + replacement + original[end:]
        data = updated.encode('utf-8')
        bindings[name]['adaptation'] = 'only project location and exact clean root/build-source assertion'
        bindings[name]['originalSourceAssertionSHA256'] = sha(original_assertion.encode('utf-8'))
    with (tools / name).open('xb') as stream:
        stream.write(data)
    bindings[name].update({'preparedSHA256': sha(data), 'preparedBytes': len(data)})

args = ['pwsh', '-NoProfile', '-File', str(tools / names[0]),
    '-CandidateRoot', 'C:/Users/Administrator/.codex/worktrees/r17/mir2-player-journey/mir2-web3/dist/r17',
    '-DeliveryRoot', 'C:/mir2-playtest-releases/20261004-native-r18/r17-download-acceleration-02',
    '-EngineRoot', 'C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/artifacts/engine-release',
    '-FeedRoot', 'C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/artifacts/feed',
    '-OutputRoot', str(BASE / 'verified'), '-SourceRevision', ENGINE_SOURCE,
    '-BootstrapExe', 'C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/bootstrap/artifacts/Numeron-Legend-of-Rebirth-20261005-r17-Bootstrap.exe',
    '-PythonPath', 'C:/Python313/python.exe', '-IncludeRootFiles']
proof = {'schema': 'mir2.native.preview.cms-verifier-preparation.v1', 'rootHead': ROOT_HEAD,
    'engineSourceRevision': ENGINE_SOURCE, 'buildReceiptSHA256': sha(BUILD.read_bytes()),
    'buildSourceRepresentations': source_representations,
    'inputs': bindings, 'argv': args, 'executed': False, 'published': False, 'credentialsUsed': False}
with (BASE / 'PREPARATION.json').open('x', encoding='utf-8', newline='\n') as stream:
    json.dump(proof, stream, indent=2)
    stream.write('\n')
print(json.dumps({'prepared': True, 'files': len(bindings), 'directory': str(BASE), 'executed': False}))
