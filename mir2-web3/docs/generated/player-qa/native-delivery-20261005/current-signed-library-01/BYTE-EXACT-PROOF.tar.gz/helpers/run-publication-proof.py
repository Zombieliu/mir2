from pathlib import Path
import hashlib, json, subprocess, sys

base = Path(__file__).resolve().parent
proof_dir = base / 'publication-proof-01'
prepared = json.loads((proof_dir / 'PREPARATION.json').read_bytes())
assert prepared['executed'] is False and prepared['credentialsUsed'] is False
assert prepared['rootHead'] == 'b87aa8a8ac94d569893a1ee653be49d857d2b063'
for name, item in prepared['inputs'].items():
    assert '/' not in name and '\\' not in name
    data = (proof_dir / 'tools' / name).read_bytes()
    assert len(data) == item['preparedBytes']
    assert hashlib.sha256(data).hexdigest() == item['preparedSHA256']
args = prepared['argv']
assert args[:3] == ['pwsh', '-NoProfile', '-File']
assert Path(args[3]) == proof_dir / 'tools' / 'prepare-signed-native-publication.ps1'
assert '-ExpectedCurrent' not in args
assert not (proof_dir / 'verified').exists()
sys.exit(subprocess.call([sys.executable, '-B', str(base / 'run.py'),
                         'publication-cms-01', '1800', *args]))
