"""Freeze actual terminal library/CMS evidence; exclude game/cache/private data."""
from pathlib import Path
import datetime, hashlib, json, os, stat, tarfile

BASE = Path(__file__).resolve().parent
OUT = BASE / 'public-proof-01'
OUT.mkdir(exist_ok=False)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and not (getattr(s, 'st_file_attributes', 0) & 0x400)
    data = path.read_bytes()
    assert s.st_size == len(data) and (s.st_ino, s.st_size, s.st_mtime_ns) == (path.stat().st_ino, path.stat().st_size, path.stat().st_mtime_ns)
    return data

def load(rel):
    return json.loads(read(BASE / rel))

receipts = {}
for name in ['build-signed-01', 'signed-fresh-01', 'signed-delta-01', 'publication-cms-01']:
    value = load('commands/' + name + '.command.json')
    assert value['exitCode'] == 0 and value['processExited'] and value['compiledSourceUnchanged']
    assert value['sourceRevision'] == 'b87aa8a8ac94d569893a1ee653be49d857d2b063'
    for field in ['stdout', 'stderr']:
        raw = read(value[field]['path'])
        assert len(raw) == value[field]['bytes'] and digest(raw) == value[field]['sha256']
    if name in ['signed-fresh-01', 'signed-delta-01']:
        stdout = read(value['stdout']['path'])
        assert b'1 passed; 0 failed; 0 ignored; 0 measured; 68 filtered out' in stdout
    receipts[name] = value
assert all(v['sourceBefore'] == receipts['signed-fresh-01']['sourceBefore'] for v in receipts.values())
fresh = load('results/signed-bundle-seed-report.json')
delta = load('results/signed-delta-and-fallback-report.json')
assert fresh['passed'] and fresh['allTargetHashesVerified'] and fresh['outcome']['sequence'] == 13
assert fresh['outcome']['changedGameFiles'] == 125965 and fresh['outcome']['delivery']['bundles'] == 11
assert fresh['outcome']['downloadedFiles'] == 11 and fresh['pendingLaunchRecheckWireBytes'] == 0
assert fresh['rolledBackToIncompleteSeed'] and fresh['incompleteSeedCannotLaunch'] and not fresh['gameLaunched']
assert delta['passed'] and delta['rollbackVerified'] and delta['allTargetHashesVerified']
assert delta['delta']['delivery']['patches'] == 1 and delta['delta']['downloadedBytes'] == 27334062
assert delta['tamperedDescriptorFallback']['delivery']['fallbacks'] == 1
assert delta['acceptedRecheck']['downloadedFiles'] == delta['acceptedRecheck']['changedGameFiles'] == 0
assert not delta['gameLaunched']
events = [json.loads(line) for line in read(BASE / 'results/bundle-seed/.update/last-run.jsonl').splitlines()]
phases = [e['detail'] for e in events if e['event'] == 'local-phase-end']
for name in ['staging', 'preparing', 'installing', 'recovering']:
    found = [p for p in phases if p['phase'] == name]
    assert len(found) == 1 and found[0]['outcome'] == 'complete'
cms = load('publication-proof-01/verified/ROOT-VERIFICATION.json')
publication = load('publication-proof-01/verified/PREPARE-PUBLICATION.json')
assert cms['passed'] and cms['cmsVerified'] and cms['candidateVerified'] and cms['sequence'] == 13
assert cms['objectsSha256'] == '1084f10c192a0f0751352898c9a8f2caab3a3f32e506a5fd1f0a7650713fcdaa'
assert publication['objects'] == 36 and publication['published'] is False and publication['credentialsUsed'] is False
summary = {
    'schema': 'mir2.native.signed-release.library-root-review.v1',
    'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'compiledSourceRevision': receipts['signed-fresh-01']['sourceRevision'],
    'engineSourceRevision': '48454bba7623694ca7432613af52bee28e83970e',
    'gameSourceRevision': '6032ef8b3e27dd97bad0b20c8676ef9f185db64b',
    'selectedExistingIgnoredTests': {'fresh': 1, 'delta': 1, 'failed': 0},
    'fresh': {'commandElapsedSeconds': receipts['signed-fresh-01']['elapsedSeconds'],
              'checkUpdateElapsedMs': fresh['elapsedMs'], 'localPhases': phases,
              'bundleEventElapsedSumMs': sum(e['detail']['elapsedMs'] for e in events if e['event'] == 'delivery-bundle'),
              'targetFiles': 125965, 'bundles': 11, 'bundleBytes': 620189573,
              'pendingRecheckPayloads': 0, 'rollback': 'real quarantine rollback to incomplete seed'},
    'delta': {'commandElapsedSeconds': receipts['signed-delta-01']['elapsedSeconds'],
              'deltaCheckUpdateMs': delta['deltaElapsedMs'], 'fallbackCheckUpdateMs': delta['fallbackElapsedMs'],
              'deltaPayloadBytes': 27334062, 'rollback': 'direct transaction rollback/full old byte verification',
              'acceptedRecheckGamePayloads': 0},
    'cmsPublication': publication,
    'scope': {'releaseProfileLibrary': True, 'fileMappedSource': True,
              'shippedExeOrInstallerExecuted': False, 'gameLaunched': False,
              'actualHealthLaunchAcceptance': False, 'realAccountOrAppDataTested': False,
              'syntheticPersonalWitnesses': 4, 'networkThroughputMeasured': False,
              'cloudflareAuthenticated': False, 'publicFeedChanged': False,
              'originObjectsAppendedThisPhase': False, 'userInstallTouched': False},
    'freshBaselinePhysicalInputs': {'ordinaryFiles': 20, 'directories': 5,
                                   'installerRecipeDeclaresFiles': 29,
                                   'recipeFontFilesNotCopiedByLibraryFixture': 9},
    'boundaries': ['check_update timing includes stage/prepare/install but excludes subsequent full target checks and rollback',
                   'bundle event elapsed includes local transfer/extract/cache validation, not public network speed',
                   'size/SHA verification is actual125965 targets; no native/game or another laptop acceptance',
                   'delta accept is direct test API, not health; fresh retry rejection type is not asserted specifically',
                   'engine13 is preseeded in fresh; delta starts oldengine/seed11 and calls actual updater',
                   'manual preparation failure observation remains failed; CRLF input correction is a new helper']
}
with (OUT / 'ROOT-REVIEW.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(summary, f, indent=2)
    f.write('\n')

paths = []
for name in ['run.py', 'run-signed.ps1', 'fixtures-fresh.json', 'fixtures-delta.json',
             'prepare-publication-proof.py', 'prepare-publication-proof.failed01.py',
             'PUBLICATION-PREPARATION-FAILED01.json', 'run-publication-proof.py', 'prepare-public-proof.py']:
    paths.append((BASE / name, 'helpers/' + name))
for name in receipts:
    for extension in ['command.json', 'running.json', 'stdout.log', 'stderr.log']:
        paths.append((BASE / 'commands' / (name + '.' + extension), 'commands/' + name + '.' + extension))
for rel in ['results/signed-bundle-seed-report.json', 'results/signed-delta-and-fallback-report.json',
            'results/bundle-seed/.update/last-run.jsonl', 'results/delta/.update/last-run.jsonl']:
    path = BASE / rel
    if path.exists():
        paths.append((path, rel))
for path in sorted((BASE / 'publication-proof-01').rglob('*')):
    if path.is_file():
        assert path.suffix.lower() in ['.json', '.ps1', '.py', '.log']
        paths.append((path, path.relative_to(BASE).as_posix()))
paths.append((OUT / 'ROOT-REVIEW.json', 'ROOT-REVIEW.json'))
assert len({name for _, name in paths}) == len(paths)
inventory = [{'path': name, 'bytes': len(read(path)), 'sha256': digest(read(path))} for path, name in paths]
with (OUT / 'INVENTORY.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'schema': 'mir2.public.byte-inventory.v1', 'files': inventory}, f, indent=2)
    f.write('\n')
archive = OUT / 'BYTE-EXACT-PROOF.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for path, name in paths:
        tar.add(path, arcname=name, recursive=False)
data = read(archive)
with (OUT / 'ARCHIVE.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump({'path': archive.name, 'bytes': len(data), 'sha256': digest(data),
               'regularMembers': len(paths), 'privateDataIncluded': False}, f, indent=2)
    f.write('\n')
print(json.dumps({'passed': True, 'members': len(paths), 'bytes': len(data), 'sha256': digest(data)}))
