from pathlib import Path
import hashlib, json, tarfile

base = Path(__file__).resolve().parent
out = base / 'public-proof-01' / 'delta-log-addendum-01'
out.mkdir(exist_ok=False)
path = base / 'results/delta-and-fallback/.update/last-run.jsonl'
data = path.read_bytes()
events = [json.loads(line) for line in data.splitlines()]
assert events and any(e['event'] == 'local-phase-end' for e in events)
original = json.loads((base / 'public-proof-01/ARCHIVE.json').read_bytes())
proof = {'schema': 'mir2.native.delta-phase-log-addendum.v1',
         'originalArchiveSHA256': original['sha256'], 'originalArchiveUnchanged': True,
         'path': path.relative_to(base).as_posix(), 'bytes': len(data),
         'sha256': hashlib.sha256(data).hexdigest(),
         'reason': 'The original41-member archive used an optional delta path; actual directory is delta-and-fallback. This additive archive retains the complete observed delta/fallback phase log.',
         'originalCommandResultsChanged': False}
with (out / 'ADDENDUM.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(proof, f, indent=2)
    f.write('\n')
archive = out / 'BYTE-EXACT-ADDENDUM.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    tar.add(path, arcname=proof['path'], recursive=False)
    tar.add(out / 'ADDENDUM.json', arcname='ADDENDUM.json', recursive=False)
    tar.add(Path(__file__), arcname='prepare-delta-log-addendum.py', recursive=False)
raw = archive.read_bytes()
index = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'regularMembers': 3}
with (out / 'ARCHIVE.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(index, f, indent=2)
    f.write('\n')
print(json.dumps(index))
