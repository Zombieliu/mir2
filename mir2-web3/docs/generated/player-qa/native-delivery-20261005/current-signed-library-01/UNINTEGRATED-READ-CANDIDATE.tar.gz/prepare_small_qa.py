"""Prepare the owned original-body crate and deterministic future benchmark.

This performs no Cargo, tests, network, installation or benchmark execution.
It rejects replacement of an existing output and records the prior source pins.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat

OWNED = Path(r"C:/mir2-playtest-releases/20261004-native-r18/updater-read-handle-implementation-01")
SOURCE = Path(r"C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3/apps/game-client/windows-updater")
WORKER = OWNED / "worker-crate"
ORIGINAL = OWNED / "original-crate"
HOOK = b'\n#[cfg(test)]\n#[path = "fs_safe_read_tests.rs"]\nmod read_tests;\n'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path, directory=False):
    if not path.is_absolute():
        raise RuntimeError("relative input")
    for ancestor in [path, *path.parents]:
        info = os.lstat(ancestor)
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("linked input: " + str(ancestor))
    info = os.lstat(path)
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise RuntimeError("not a directory: " + str(path))
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise RuntimeError("not an ordinary independent file: " + str(path))


def fresh_write(path, data):
    ordinary(path.parent, directory=True)
    with path.open("xb") as output:
        output.write(data)
    ordinary(path)


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main():
    ordinary(OWNED, directory=True)
    before_path = OWNED / "BEFORE-SOURCE-01.json"
    ordinary(before_path)
    before = json.loads(before_path.read_bytes())
    if ORIGINAL.exists():
        raise RuntimeError("original output already exists; never overwrite")
    original_inputs = []
    for item in before["files"]:
        relative = item["path"]
        source = SOURCE / relative
        ordinary(source)
        data = source.read_bytes()
        if len(data) != item["size"] or sha(data) != item["sha256"]:
            raise RuntimeError("root source pin changed: " + relative)
        original_inputs.append((relative, data))
    ordinary(WORKER / "src/fs_safe_read_tests.rs")
    test_data = (WORKER / "src/fs_safe_read_tests.rs").read_bytes()
    ORIGINAL.mkdir()
    for relative, source_data in original_inputs:
        destination = ORIGINAL / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = source_data + HOOK if relative == "src/fs_safe.rs" else source_data
        fresh_write(destination, data)
    fresh_write(ORIGINAL / "src/fs_safe_read_tests.rs", test_data)

    fixture = OWNED / "benchmark-fixture-01"
    if fixture.exists():
        raise RuntimeError("benchmark fixture already exists; never overwrite")
    fixture.mkdir()
    rows, actual_files = [], []
    for kind in ("valid", "same-size-corrupt", "size-mismatch", "missing"):
        (fixture / kind).mkdir()
        for index in range(32):
            expected = bytes(((position * 17 + index * 29 + position // 256) & 255) for position in range(8192))
            actual = expected
            if kind == "same-size-corrupt":
                changed = bytearray(expected)
                changed[4096] ^= 0x80
                actual = bytes(changed)
            elif kind == "size-mismatch":
                actual = expected[:-1]
            relative = f"{kind}/file-{index:02}.bin"
            row = {"kind": kind, "path": relative, "expectedSize": len(expected),
                   "expectedSha256": sha(expected).upper(), "actualSize": None,
                   "actualSha256": None}
            if kind != "missing":
                fresh_write(fixture / relative, actual)
                row.update(actualSize=len(actual), actualSha256=sha(actual).upper())
                actual_files.append({"path": relative, "size": len(actual), "sha256": sha(actual)})
            rows.append(row)
    manifest = {"schema": "mir2.updater.read-handle.benchmark-fixture.v1", "root": str(fixture),
                "filesPerClass": 32, "repeatsPerClass": 32, "cases": rows}
    manifest_data = json_bytes(manifest)
    fresh_write(fixture / "FIXTURE.json", manifest_data)
    for name in ("logs", "tmp-original", "tmp-worker", "benchmark-reports"):
        (OWNED / name).mkdir()

    source_files = []
    for variant, crate in (("original", ORIGINAL), ("checked-handle", WORKER)):
        for relative, _ in original_inputs:
            path = crate / relative
            ordinary(path)
            data = path.read_bytes()
            source_files.append({"variant": variant, "path": relative, "size": len(data), "sha256": sha(data)})
        path = crate / "src/fs_safe_read_tests.rs"
        data = path.read_bytes()
        source_files.append({"variant": variant, "path": "src/fs_safe_read_tests.rs", "size": len(data), "sha256": sha(data)})
    report = {
        "schema": "mir2.updater.read-handle.source-preparation.v2",
        "recordedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "sourceRevision": before["sourceRevision"], "sourceBeforeSha256": sha(before_path.read_bytes()),
        "rootSource18Unchanged": True, "plainIndependentCopy": True,
        "originalProductionBodyExact": {"path": "src/fs_safe.rs", "bytes": len(dict(original_inputs)["src/fs_safe.rs"]),
                                        "sha256": sha(dict(original_inputs)["src/fs_safe.rs"])},
        "originalTestHookOnly": HOOK.decode(), "sameTestFileBothVariants": True,
        "files": source_files,
        "fixture": {"root": str(fixture), "manifest": str(fixture / "FIXTURE.json"),
                    "manifestBytes": len(manifest_data), "manifestSha256": sha(manifest_data),
                    "actualFiles": actual_files, "actualFileCount": len(actual_files),
                    "actualPayloadBytes": sum(row["size"] for row in actual_files),
                    "missingPaths": 32, "timedCallsPerFutureInvocation": 5120,
                    "rounds": 6, "balancedOrder": ["original,checked-handle", "checked-handle,original"] * 3},
        "benchExecuted": False, "testsExecuted": False, "networkExecuted": False,
        "commandsOnlyBenchmarkPendingRootAuthorization": True,
        "historicalEditsReady01Preserved": True,
    }
    fresh_write(OWNED / "SOURCE-PREP-02.json", json_bytes(report))
    print(json.dumps({"prepared": True, "sourceFiles": len(source_files), "fixtureFiles": len(actual_files),
                      "fixtureBytes": report["fixture"]["actualPayloadBytes"], "report": str(OWNED / "SOURCE-PREP-02.json")}))


if __name__ == "__main__":
    main()
