"""Execute the separately authorized twelve exact frozen benchmark commands.

No source or existing receipt is edited. A timeout leaves the owned PID intact,
records it and stops the sequence for parent review rather than killing processes.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import stat
import subprocess
import time

ROOT = Path(r"C:/mir2-playtest-releases/20261004-native-r18/updater-read-handle-implementation-01")
OUTPUT = ROOT / "benchmark-execution-01"
FREEZE_SHA = "225e519b1375f2becc46381d782adbec66c04f27701e15eee2d0fb8655147eed"
PLAN_SHA = "b8ef2211c1c824c2472eed6b51827b4aa83103cec4d565855e256a61cf90d72f"


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path):
    for ancestor in [path, *path.parents]:
        metadata = os.lstat(ancestor)
        if stat.S_ISLNK(metadata.st_mode) or getattr(metadata, "st_file_attributes", 0) & 0x400:
            raise RuntimeError("linked path: " + str(ancestor))
    metadata = os.lstat(path)
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
        raise RuntimeError("not an independent ordinary file: " + str(path))


def read(path):
    ordinary(path)
    return path.read_bytes()


def write_json(path, value):
    with path.open("xb") as output:
        output.write((json.dumps(value, indent=2) + "\n").encode())


def verify(rows):
    for item in rows:
        data = read(ROOT / item["path"])
        if len(data) != item["bytes"] or sha(data) != item["sha256"]:
            raise RuntimeError("frozen hash mismatch: " + item["path"])
    return {"checkedFiles": len(rows), "allMatched": True, "recordedUtc": utc()}


def main():
    freeze_bytes = read(ROOT / "FROZEN-SMALL-QA-01.json")
    plan_bytes = read(ROOT / "BENCHMARK-COMMAND-PLAN-01.json")
    if sha(freeze_bytes) != FREEZE_SHA or sha(plan_bytes) != PLAN_SHA:
        raise RuntimeError("freeze or command plan pin mismatch")
    freeze, plan = json.loads(freeze_bytes), json.loads(plan_bytes)
    if len(freeze["files"]) != 156 or len(plan["commands"]) != 12:
        raise RuntimeError("unexpected frozen count")
    before = verify(freeze["files"])
    if OUTPUT.exists():
        raise RuntimeError("fresh output required; never overwrite or retry")
    OUTPUT.mkdir()
    source_fixture_rows = [row for row in freeze["files"]
                           if row["path"].startswith(("original-crate/", "worker-crate/", "benchmark-fixture-01/"))]
    code_binary_before = []
    small_review = json.loads(read(ROOT / "FINAL-SMALL-QA-01.json"))
    for item in small_review["releaseTestExecutables"]:
        data = read(Path(item["path"]))
        if len(data) != item["bytes"] or sha(data) != item["sha256"]:
            raise RuntimeError("precompiled unit-test executable changed")
        code_binary_before.append(item)
    inputs = {
        "schema": "mir2.updater.read-handle.benchmark-execution-inputs.v1", "recordedUtc": utc(),
        "freezeSha256": FREEZE_SHA, "commandPlanSha256": PLAN_SHA, "frozen156VerificationBefore": before,
        "runner": {"path": str(Path(__file__)), "sha256": sha(read(Path(__file__)))},
        "sourceFixtureFilesCheckedEachBeforeAfter": len(source_fixture_rows),
        "precompiledUnitTestExecutables": code_binary_before,
        "authorization": "Parent separately authorized frozen twelve sequential exact ignored-one-test commands after signed-delta terminal",
        "commandsChanged": False, "sourceChanges": False, "noSourceSpeedExtrapolation": True,
    }
    write_json(OUTPUT / "INPUTS-01.json", inputs)
    receipts = []
    for index, command in enumerate(plan["commands"], 1):
        variant, rnd, slot = command["variant"], command["round"], command["orderSlot"]
        expected_order = ["original", "checked-handle"] if rnd % 2 else ["checked-handle", "original"]
        if variant != expected_order[slot - 1] or rnd != (index + 1) // 2 or slot != (index - 1) % 2 + 1:
            raise RuntimeError("unbalanced or changed execution order")
        argv = command["argv"]
        if argv[-7:] != ["--lib", "fs_safe::read_tests::matched_read_handle_benchmark", "--", "--ignored", "--exact", "--nocapture", "--test-threads=1"]:
            raise RuntimeError("wrong exact test selection")
        if command["timeoutSeconds"] != 120:
            raise RuntimeError("wrong per-invocation timeout")
        precheck = verify(source_fixture_rows)
        env = dict(os.environ)
        for key in list(env):
            if key.startswith("MIR2_READ_HANDLE_BENCH_"):
                del env[key]
        env.update(command["environmentOverrides"])
        report_path = Path(env["MIR2_READ_HANDLE_BENCH_REPORT"])
        if report_path.exists():
            raise RuntimeError("fresh planned report path required")
        label = f"{index:02}-round-{rnd:02}-slot-{slot}-{variant}"
        out_path, err_path = OUTPUT / (label + ".stdout.log"), OUTPUT / (label + ".stderr.log")
        started, timer, timed_out = utc(), time.monotonic(), False
        with out_path.open("xb") as stdout, err_path.open("xb") as stderr:
            process = subprocess.Popen(argv, cwd=command["cwd"], env=env, stdout=stdout, stderr=stderr)
            try:
                exit_code = process.wait(timeout=120)
            except subprocess.TimeoutExpired:
                timed_out, exit_code = True, None
        postcheck = verify(source_fixture_rows)
        result, invalid = None, []
        raw_out, raw_err = read(out_path), read(err_path)
        if timed_out:
            invalid.append("timeout: owned PID remains untouched for parent review; sequence stops")
        if exit_code != 0:
            invalid.append("nonzero or unfinished Cargo exit")
        output_text = raw_out.decode("utf-8", errors="replace")
        outcome = re.search(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", output_text)
        if not outcome or tuple(map(int, outcome.groups())) != (1, 0, 0):
            invalid.append("not exactly one successful selected benchmark")
        if report_path.exists():
            result = json.loads(read(report_path))
            if result.get("variant") != variant or result.get("round") != rnd or result.get("orderSlot") != slot:
                invalid.append("result identity mismatch")
            if result.get("manifestSha256") != env["MIR2_READ_HANDLE_BENCH_MANIFEST_SHA256"]:
                invalid.append("fixture pin mismatch")
            if result.get("fsSafeSourceSha256") != env["MIR2_READ_HANDLE_BENCH_SOURCE_SHA256"]:
                invalid.append("source pin mismatch")
            if result.get("timedCalls") != 5120 or len(result.get("measurements", [])) != 5:
                invalid.append("measurement count mismatch")
            expected = [("matches", kind) for kind in plan["matchesClasses"]] + [("digest_file", "valid")]
            for measurement, pair in zip(result.get("measurements", []), expected):
                if (measurement.get("operation"), measurement.get("class")) != pair or measurement.get("calls") != 1024:
                    invalid.append("measurement class/calls mismatch")
                if type(measurement.get("elapsedNs")) is not int or measurement["elapsedNs"] <= 0:
                    invalid.append("invalid elapsed measurement")
        else:
            invalid.append("result report missing")
        receipt = {
            "schema": "mir2.updater.read-handle.benchmark-command.v1", "index": index, "round": rnd,
            "orderSlot": slot, "variant": variant, "argv": argv, "cwd": command["cwd"],
            "environmentOverrides": command["environmentOverrides"], "timeoutSeconds": 120,
            "startedUtc": started, "completedUtc": utc(), "wallSeconds": time.monotonic() - timer,
            "ownedPid": process.pid, "exitCode": exit_code, "timedOut": timed_out,
            "beforeSourceFixtureVerification": precheck, "afterSourceFixtureVerification": postcheck,
            "stdout": {"path": str(out_path), "bytes": len(raw_out), "sha256": sha(raw_out)},
            "stderr": {"path": str(err_path), "bytes": len(raw_err), "sha256": sha(raw_err)},
            "resultReport": {"path": str(report_path), "sha256": sha(read(report_path))} if report_path.exists() else None,
            "validMeasurement": not invalid, "invalidReasons": invalid,
            "measurements": result.get("measurements") if result else None,
            "commandPlanChanged": False, "sourceChanged": False,
        }
        write_json(OUTPUT / (label + ".json"), receipt)
        receipts.append(receipt)
        print(json.dumps({"index": index, "round": rnd, "variant": variant, "exitCode": exit_code,
                          "valid": not invalid, "wallSeconds": receipt["wallSeconds"],
                          "measurements": receipt["measurements"]}), flush=True)
        if timed_out:
            raise SystemExit(124)
        # Keep remaining exact commands after an ordinary failed assertion;
        # it remains invalid, cannot silently turn into a performance sample.
    final_verification = verify(freeze["files"])
    binary_checks = []
    for item in code_binary_before:
        data = read(Path(item["path"]))
        exact = len(data) == item["bytes"] and sha(data) == item["sha256"]
        binary_checks.append({"variant": item["variant"], "sha256": sha(data), "exactBeforeAfter": exact})
        if not exact:
            raise RuntimeError("compiled unit-test binary changed during exact selection")
    finish = {
        "schema": "mir2.updater.read-handle.benchmark-terminal.v1", "recordedUtc": utc(),
        "commands": len(receipts), "validCommands": sum(receipt["validMeasurement"] for receipt in receipts),
        "failures": [receipt["index"] for receipt in receipts if not receipt["validMeasurement"]],
        "all156BeforeAfterMatched": final_verification["allMatched"], "frozen156VerificationAfter": final_verification,
        "unitTestBinaryBeforeAfter": binary_checks, "sourceChanges": False,
        "scope": "ordinary Windows release library 8 KiB warm fixture only; no install/network/shipped-EXE inference",
    }
    write_json(OUTPUT / "TERMINAL-01.json", finish)
    print(json.dumps(finish), flush=True)
    raise SystemExit(0 if finish["validCommands"] == 12 else 1)


if __name__ == "__main__":
    main()
