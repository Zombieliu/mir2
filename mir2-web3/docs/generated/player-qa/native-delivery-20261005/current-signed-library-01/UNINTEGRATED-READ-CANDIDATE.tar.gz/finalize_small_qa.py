"""Verify and freeze only public allowlisted source/fixture/test evidence."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import re
import stat

OWNED = Path(r"C:/mir2-playtest-releases/20261004-native-r18/updater-read-handle-implementation-01")
SOURCE = Path(r"C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3/apps/game-client/windows-updater")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ordinary(path):
    for ancestor in [path, *path.parents]:
        metadata = os.lstat(ancestor)
        assert not stat.S_ISLNK(metadata.st_mode)
        assert not getattr(metadata, "st_file_attributes", 0) & 0x400
    metadata = os.lstat(path)
    assert stat.S_ISREG(metadata.st_mode) and metadata.st_nlink == 1


def read(path):
    ordinary(path)
    return path.read_bytes()


def fresh_json(path, value):
    with path.open("xb") as output:
        output.write((json.dumps(value, indent=2) + "\n").encode())


def function_body(text, name):
    start = text.index(f"pub fn {name}(")
    position = text.index("{", start)
    depth = 0
    for end in range(position, len(text)):
        depth += (text[end] == "{") - (text[end] == "}")
        if depth == 0:
            return text[start:end + 1]
    raise RuntimeError("unterminated function")


def main():
    before = json.loads(read(OWNED / "BEFORE-SOURCE-01.json"))
    pre_freeze = json.loads(read(OWNED / "FROZEN-SOURCE-02.json"))
    for item in pre_freeze["files"]:
        data = read(OWNED / item["path"])
        assert len(data) == item["bytes"] and sha(data) == item["sha256"], item["path"]
    for item in before["files"]:
        data = read(SOURCE / item["path"])
        assert len(data) == item["size"] and sha(data) == item["sha256"], item["path"]

    original = read(SOURCE / "src/fs_safe.rs").decode()
    worker = read(OWNED / "worker-crate/src/fs_safe.rs").decode()
    protected_names = ["ancestors", "target", "regular", "open_download", "read_bounded",
                       "write_new", "atomic_write", "clear_scratch", "install_root"]
    protected = []
    for name in protected_names:
        exact = function_body(original, name) == function_body(worker, name)
        assert exact, name
        protected.append({"function": name, "exactBodyUnchanged": exact})
    patch = "".join(difflib.unified_diff(original.splitlines(keepends=True), worker.splitlines(keepends=True),
                                      fromfile="b87-original/src/fs_safe.rs", tofile="worker-crate/src/fs_safe.rs"))
    with (OWNED / "FILESYSTEM-CHANGE-02.patch").open("xb") as output:
        output.write(patch.encode())

    executions = []
    expectations = {
        "original-sharing-red-01": (101, 0, 4, 0),
        "worker-focused-green-01": (0, 12, 0, 1),
        "worker-adjacent-green-01": (0, 77, 0, 5),
    }
    for name, (expected_exit, passed, failed, ignored) in expectations.items():
        receipt = json.loads(read(OWNED / "logs" / f"{name}.json"))
        assert receipt["exitCode"] == expected_exit and not receipt["timedOut"]
        for key in ("stdout", "stderr"):
            data = read(Path(receipt[key]["path"]))
            assert len(data) == receipt[key]["bytes"] and sha(data) == receipt[key]["sha256"]
        text = read(Path(receipt["stdout"]["path"])).decode()
        result = re.search(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", text)
        assert result and tuple(map(int, result.groups())) == (passed, failed, ignored)
        stderr = read(Path(receipt["stderr"]["path"])).decode()
        assert "Finished `release` profile" in stderr and "error[E" not in stderr
        executions.append({"name": name, "cargoExitCode": receipt["exitCode"], "passed": passed,
                           "failed": failed, "ignored": ignored, "wallSeconds": receipt["wallSeconds"],
                           "receipt": f"logs/{name}.json", "receiptSha256": sha(read(OWNED / "logs" / f"{name}.json"))})

    code = []
    for relative in ("worker-crate/src/fs_safe.rs", "worker-crate/src/fs_safe_read_tests.rs",
                     "original-crate/src/fs_safe.rs", "original-crate/src/fs_safe_read_tests.rs"):
        data = read(OWNED / relative)
        code.append({"path": relative, "bytes": len(data), "sha256": sha(data)})
    binaries = []
    for variant in ("original", "checked-handle"):
        directory = Path(r"C:/mir2-build/updater-read-handle-20261005") / variant / "x86_64-pc-windows-msvc/release/deps"
        selected = list(directory.glob("mir2_windows_updater-*.exe"))
        assert len(selected) == 1
        data = read(selected[0])
        binaries.append({"variant": variant, "path": str(selected[0]), "bytes": len(data), "sha256": sha(data),
                         "scope": "library unit-test executable only, not shipped launcher/engine"})
    review = {
        "schema": "mir2.updater.read-handle.small-qa-final.v1",
        "recordedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "sourceRevision": before["sourceRevision"], "root18Unchanged": True,
        "preRunFreezeRevalidated": True, "sourceHelperFreezePredatesExecution": True,
        "code": code, "protectedFunctions": protected, "executions": executions,
        "releaseTestExecutables": binaries, "sameTestFileBothVariants": code[1]["sha256"] == code[3]["sha256"],
        "distinctPassingLibraryChecks": 77, "focused12OverlapFull77": True,
        "compileDiagnosticsObserved": False, "testCorrectionsAfterExecution": False,
        "genuineRed": "Four compiled actual old-body sharing assertions failed on Ok; not syntax/import/fixture failure",
        "benchmarkCommandPlan": {"path": "BENCHMARK-COMMAND-PLAN-01.json",
                                 "sha256": sha(read(OWNED / "BENCHMARK-COMMAND-PLAN-01.json")), "executed": False},
        "patch": {"path": "FILESYSTEM-CHANGE-02.patch", "sha256": sha(read(OWNED / "FILESYSTEM-CHANGE-02.patch"))},
        "claims": {"performanceMeasured": False, "throughputImproved": False, "unixTestsRun": False,
                   "shippedExeAcceptance": False, "httpsAcceptance": False, "fullSignedInstallRun": False,
                   "rootWritten": False, "userInstallationTouched": False, "productionPublished": False},
        "next": "Await separate parent authorization after signed-delta terminal before any matched benchmark execution",
    }
    assert review["sameTestFileBothVariants"]
    fresh_json(OWNED / "FINAL-SMALL-QA-01.json", review)
    paths = [row["path"] for row in pre_freeze["files"]]
    paths += ["BEFORE-SOURCE-01.json", "EDITS-READY-01.json", "FILESYSTEM-CHANGE-01.patch",
              "FROZEN-SOURCE-02.json", "BENCHMARK-COMMAND-PLAN-01.json", "README-SMALL-QA-01.md",
              "finalize_small_qa.py", "FILESYSTEM-CHANGE-02.patch", "FINAL-SMALL-QA-01.json"]
    for name in expectations:
        paths += [f"logs/{name}.{extension}" for extension in ("json", "stdout.log", "stderr.log")]
    inventory = []
    for relative in sorted(set(paths)):
        data = read(OWNED / relative)
        inventory.append({"path": relative, "bytes": len(data), "sha256": sha(data)})
    freeze = {"schema": "mir2.updater.read-handle.final-small-qa-freeze.v1",
              "recordedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "files": inventory, "fileCount": len(inventory), "benchmarkExecuted": False,
              "sourceHelperShaUnchangedFromPreRun": True,
              "priorReceiptsPreserved": True, "root18Unchanged": True,
              "scope": "explicit public inputs/logs only; no target artifacts/temp contents/private stores"}
    fresh_json(OWNED / "FROZEN-SMALL-QA-01.json", freeze)
    print(json.dumps({"files": len(inventory), "freezeSha256": sha(read(OWNED / "FROZEN-SMALL-QA-01.json")),
                      "reviewSha256": sha(read(OWNED / "FINAL-SMALL-QA-01.json")), "root18Unchanged": True,
                      "green": 77, "benchmarkExecuted": False}))


if __name__ == "__main__":
    main()
