// These fixtures call only the existing public hash APIs. The writer/delete
// cases can therefore be run against the original implementation for real RED.
use super::{digest_file, matches};
use crate::model::FileEntry;
use sha2::{Digest, Sha256};
use std::{fs, path::Path};

fn entry(bytes: &[u8]) -> FileEntry {
    FileEntry {
        path: "fixture.bin".into(),
        size: bytes.len() as u64,
        sha256: format!("{:X}", Sha256::digest(bytes)),
    }
}

fn fixture(bytes: &[u8]) -> (tempfile::TempDir, std::path::PathBuf, FileEntry) {
    let directory = tempfile::tempdir().unwrap();
    let path = directory.path().join("fixture.bin");
    fs::write(&path, bytes).unwrap();
    (directory, path, entry(bytes))
}

fn assert_rejected(path: &Path, expected: &FileEntry) {
    assert!(matches(path, expected).is_err());
    assert!(digest_file(path).is_err());
}

#[test]
fn exact_bytes_and_empty_file_keep_original_digest_api() {
    for bytes in [&b"abcdefgh"[..], &b""[..]] {
        let (_directory, path, expected) = fixture(bytes);
        assert!(matches(&path, &expected).unwrap());
        assert_eq!(
            digest_file(&path).unwrap(),
            (expected.size, expected.sha256)
        );
    }
}

#[test]
fn same_size_corruption_is_not_reused_across_calls() {
    let (_directory, path, expected) = fixture(b"abcdefgh");
    assert!(matches(&path, &expected).unwrap());
    fs::write(&path, b"ABCDEFGH").unwrap();
    assert!(!matches(&path, &expected).unwrap());
    let changed = entry(b"ABCDEFGH");
    assert_eq!(digest_file(&path).unwrap(), (changed.size, changed.sha256));
    fs::write(&path, b"abcdefgh").unwrap();
    assert!(matches(&path, &expected).unwrap());
}

#[test]
fn size_mismatch_is_false_and_missing_file_stays_false() {
    let (_directory, path, mut expected) = fixture(b"abcdefgh");
    expected.size -= 1;
    assert!(!matches(&path, &expected).unwrap());
    let missing = path.with_file_name("missing.bin");
    assert!(!matches(&missing, &expected).unwrap());
    assert!(digest_file(&missing).is_err());
}

#[test]
fn nonregular_directory_is_rejected_without_opening_as_payload() {
    let directory = tempfile::tempdir().unwrap();
    assert_rejected(directory.path(), &entry(b""));
}

#[test]
fn hardlinked_file_and_original_name_are_both_rejected() {
    let (directory, path, expected) = fixture(b"abcdefgh");
    let alias = directory.path().join("alias.bin");
    fs::hard_link(&path, &alias).unwrap();
    assert_rejected(&path, &expected);
    assert_rejected(&alias, &expected);
}

#[cfg(windows)]
mod windows {
    use super::*;
    use std::{io, os::windows::fs::OpenOptionsExt};
    use windows_sys::Win32::Storage::FileSystem::{
        DELETE, FILE_SHARE_DELETE, FILE_SHARE_READ, FILE_SHARE_WRITE,
    };

    fn assert_sharing_violation(error: anyhow::Error) {
        assert!(error.chain().any(|cause| {
            cause
                .downcast_ref::<io::Error>()
                .is_some_and(|cause| cause.raw_os_error() == Some(32))
        }), "expected an actual Windows sharing violation: {error:#}");
    }

    fn writer(path: &Path) -> fs::File {
        fs::OpenOptions::new()
            .write(true)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE)
            .open(path)
            .unwrap()
    }

    fn delete_handle(path: &Path) -> fs::File {
        fs::OpenOptions::new()
            .access_mode(DELETE)
            .share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE)
            .open(path)
            .unwrap()
    }

    #[test]
    fn existing_writer_is_rejected_by_matches() {
        let (_directory, path, expected) = fixture(b"abcdefgh");
        let held = writer(&path);
        assert_sharing_violation(matches(&path, &expected).unwrap_err());
        drop(held);
        assert!(matches(&path, &expected).unwrap());
    }

    #[test]
    fn existing_writer_is_rejected_by_digest_file() {
        let (_directory, path, expected) = fixture(b"abcdefgh");
        let held = writer(&path);
        assert_sharing_violation(digest_file(&path).unwrap_err());
        drop(held);
        assert_eq!(digest_file(&path).unwrap(), (expected.size, expected.sha256));
    }

    #[test]
    fn existing_delete_handle_is_rejected_by_matches() {
        let (_directory, path, expected) = fixture(b"abcdefgh");
        let held = delete_handle(&path);
        assert_sharing_violation(matches(&path, &expected).unwrap_err());
        drop(held);
        assert!(matches(&path, &expected).unwrap());
    }

    #[test]
    fn existing_delete_handle_is_rejected_by_digest_file() {
        let (_directory, path, expected) = fixture(b"abcdefgh");
        let held = delete_handle(&path);
        assert_sharing_violation(digest_file(&path).unwrap_err());
        drop(held);
        assert_eq!(digest_file(&path).unwrap(), (expected.size, expected.sha256));
    }

    #[test]
    fn ordinary_concurrent_reader_is_allowed() {
        let (_directory, path, expected) = fixture(b"abcdefgh");
        let _held = fs::OpenOptions::new()
            .read(true)
            .share_mode(FILE_SHARE_READ)
            .open(&path)
            .unwrap();
        assert!(matches(&path, &expected).unwrap());
        assert_eq!(digest_file(&path).unwrap(), (expected.size, expected.sha256));
    }

    #[test]
    fn reparse_leaf_and_ancestor_are_rejected() {
        let (directory, path, expected) = fixture(b"abcdefgh");
        let leaf = directory.path().join("linked.bin");
        std::os::windows::fs::symlink_file(&path, &leaf).unwrap();
        assert_rejected(&leaf, &expected);
        let linked_directory = directory.path().join("linked-directory");
        let source_directory = directory.path().join("source-directory");
        fs::create_dir(&source_directory).unwrap();
        fs::write(source_directory.join("fixture.bin"), b"abcdefgh").unwrap();
        std::os::windows::fs::symlink_dir(&source_directory, &linked_directory).unwrap();
        assert_rejected(&linked_directory.join("fixture.bin"), &expected);
    }

    #[test]
    fn original_utf16_unicode_case_and_long_local_path_are_valid() {
        use std::os::windows::ffi::OsStrExt;
        let directory = tempfile::tempdir().unwrap();
        let mut parent = fs::canonicalize(directory.path()).unwrap();
        for index in 0..13 {
            parent.push(format!("path-{index:02}-{}", "x".repeat(35)));
        }
        fs::create_dir_all(&parent).unwrap();
        let path = parent.join("Étage-Δοκιμή-地圖-🌕.bin");
        fs::write(&path, b"abcdefgh").unwrap();
        assert!(path.as_os_str().encode_wide().count() > 512);
        let expected = entry(b"abcdefgh");
        assert!(matches(&path, &expected).unwrap());
        assert_eq!(
            digest_file(&path).unwrap(),
            (expected.size, expected.sha256.clone())
        );
        let case_alias = parent.join("étage-δοκιμή-地圖-🌕.bin");
        assert!(matches(&case_alias, &expected).unwrap());
        assert_eq!(digest_file(&case_alias).unwrap(), (expected.size, expected.sha256));
    }
}

#[cfg(unix)]
#[test]
fn unix_symlink_leaf_and_ancestor_are_rejected() {
    let (directory, path, expected) = fixture(b"abcdefgh");
    let leaf = directory.path().join("linked.bin");
    std::os::unix::fs::symlink(&path, &leaf).unwrap();
    assert_rejected(&leaf, &expected);
    let linked_directory = directory.path().join("linked-directory");
    let source_directory = directory.path().join("source-directory");
    fs::create_dir(&source_directory).unwrap();
    fs::write(source_directory.join("fixture.bin"), b"abcdefgh").unwrap();
    std::os::unix::fs::symlink(&source_directory, &linked_directory).unwrap();
    assert_rejected(&linked_directory.join("fixture.bin"), &expected);
}

#[cfg(windows)]
#[test]
#[ignore = "requires immutable owned benchmark fixture and separate root timing authorization"]
fn matched_read_handle_benchmark() {
    use std::{hint::black_box, path::PathBuf, time::Instant};

    struct Case {
        kind: String,
        path: PathBuf,
        expected: FileEntry,
    }
    let manifest_path =
        PathBuf::from(std::env::var("MIR2_READ_HANDLE_BENCH_MANIFEST").unwrap());
    assert!(manifest_path.is_absolute());
    let manifest_bytes = super::read_bounded(&manifest_path, 131_072).unwrap();
    let manifest_sha = format!("{:X}", Sha256::digest(&manifest_bytes));
    assert_eq!(
        manifest_sha,
        std::env::var("MIR2_READ_HANDLE_BENCH_MANIFEST_SHA256").unwrap()
    );
    let manifest: serde_json::Value = serde_json::from_slice(&manifest_bytes).unwrap();
    assert_eq!(manifest["schema"], "mir2.updater.read-handle.benchmark-fixture.v1");
    assert_eq!(manifest["filesPerClass"], 32);
    assert_eq!(manifest["repeatsPerClass"], 32);
    let root = PathBuf::from(manifest["root"].as_str().unwrap());
    assert!(root.is_absolute());
    super::ancestors(&root).unwrap();
    let kinds = ["valid", "same-size-corrupt", "size-mismatch", "missing"];
    let rows = manifest["cases"].as_array().unwrap();
    assert_eq!(rows.len(), kinds.len() * 32);
    let mut cases = Vec::new();
    for (kind_index, kind) in kinds.iter().enumerate() {
        for index in 0..32 {
            let row = &rows[kind_index * 32 + index];
            let relative = format!("{kind}/file-{index:02}.bin");
            assert_eq!(row["kind"], *kind);
            assert_eq!(row["path"], relative);
            let path = root.join(&relative);
            let expected = FileEntry {
                path: relative,
                size: row["expectedSize"].as_u64().unwrap(),
                sha256: row["expectedSha256"].as_str().unwrap().to_owned(),
            };
            assert_eq!(expected.size, 8192);
            if *kind == "missing" {
                assert!(!path.exists());
                assert!(row["actualSize"].is_null() && row["actualSha256"].is_null());
            } else {
                let actual = digest_file(&path).unwrap();
                assert_eq!(actual.0, row["actualSize"].as_u64().unwrap());
                assert_eq!(actual.1, row["actualSha256"].as_str().unwrap());
                if *kind == "size-mismatch" {
                    assert_eq!(actual.0, expected.size - 1);
                } else {
                    assert_eq!(actual.0, expected.size);
                    assert_eq!(actual.1 == expected.sha256, *kind == "valid");
                }
            }
            // One untimed common warm-up per path. All fixture/identity checks
            // and Cargo startup remain outside the measurements below.
            assert_eq!(matches(&path, &expected).unwrap(), *kind == "valid");
            cases.push(Case {
                kind: (*kind).to_owned(),
                path,
                expected,
            });
        }
    }
    let variant = std::env::var("MIR2_READ_HANDLE_BENCH_VARIANT").unwrap();
    assert!(variant == "original" || variant == "checked-handle");
    let round = std::env::var("MIR2_READ_HANDLE_BENCH_ROUND")
        .unwrap()
        .parse::<u32>()
        .unwrap();
    assert!((1..=6).contains(&round));
    let order_slot = std::env::var("MIR2_READ_HANDLE_BENCH_ORDER_SLOT")
        .unwrap()
        .parse::<u32>()
        .unwrap();
    assert!((1..=2).contains(&order_slot));
    let source_sha = std::env::var("MIR2_READ_HANDLE_BENCH_SOURCE_SHA256").unwrap();
    assert!(crate::model::valid_hash(&source_sha));
    let mut measurements = Vec::new();
    for kind in kinds {
        let selected = cases.iter().filter(|case| case.kind == kind).collect::<Vec<_>>();
        assert_eq!(selected.len(), 32);
        let started = Instant::now();
        for _ in 0..32 {
            for case in &selected {
                let actual = matches(black_box(&case.path), black_box(&case.expected)).unwrap();
                assert_eq!(actual, kind == "valid");
                black_box(actual);
            }
        }
        measurements.push(serde_json::json!({
            "operation":"matches","class":kind,"calls":1024,
            "elapsedNs":u64::try_from(started.elapsed().as_nanos()).unwrap()
        }));
    }
    let valid = cases.iter().filter(|case| case.kind == "valid").collect::<Vec<_>>();
    let started = Instant::now();
    for _ in 0..32 {
        for case in &valid {
            let actual = digest_file(black_box(&case.path)).unwrap();
            assert_eq!(actual.0, case.expected.size);
            assert_eq!(actual.1, case.expected.sha256);
            black_box(actual);
        }
    }
    measurements.push(serde_json::json!({
        "operation":"digest_file","class":"valid","calls":1024,
        "elapsedNs":u64::try_from(started.elapsed().as_nanos()).unwrap()
    }));
    let report = serde_json::json!({
        "schema":"mir2.updater.read-handle.benchmark-round.v1",
        "variant":variant,"round":round,"orderSlot":order_slot,
        "manifestSha256":manifest_sha,"fsSafeSourceSha256":source_sha,
        "fixturePrechecked":true,"commonWarmup":true,
        "measurements":measurements,"timedCalls":5120,
        "scope":"release Windows library hash APIs; not install, HTTPS or shipped EXE speed"
    });
    let report_path = PathBuf::from(std::env::var("MIR2_READ_HANDLE_BENCH_REPORT").unwrap());
    assert!(report_path.is_absolute());
    assert!(!report_path.exists());
    super::write_new(&report_path, &serde_json::to_vec_pretty(&report).unwrap()).unwrap();
    println!("MIR2_READ_HANDLE_BENCH_RESULT {}", serde_json::to_string(&report).unwrap());
}
