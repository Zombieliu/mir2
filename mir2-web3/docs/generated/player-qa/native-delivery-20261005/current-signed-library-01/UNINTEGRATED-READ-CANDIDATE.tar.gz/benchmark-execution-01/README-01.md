# Actual matched Windows release hash-check measurements

All twelve frozen benchmark commands completed successfully, with exactly one
selected test each, no failure or timeout. The order was A/B, B/A, A/B, B/A,
A/B, B/A. Every one of the 156 earlier frozen files and both precompiled library
test executables still matched their original size/SHA after execution. Each
invocation also checked the 135 source/fixture files before and after. No source,
repository, existing evidence, installed game or live service changed.

The checked-read implementation remains an unintegrated Candidate. Root decided
not to merge or ship it as a download performance fix because the actual result
is mixed. Earlier meaningful RED (four compiled original-body sharing failures)
and GREEN (12 focused, overlapping the 77 library passes) remain valid and frozen.

Each table cell is milliseconds for 1,024 calls. The elapsed change is the median
of six paired new/original ratios; negative means less time, positive means more.
It is distinct from a ratio of the two distribution medians. No fastest sample
was selected or discarded.

| Operation and case | Original median ms | Checked-read median ms | Paired median elapsed change |
| --- | ---: | ---: | ---: |
| matches, valid bytes | 204.62685 | 162.86560 | -19.60585% |
| matches, same-size corruption | 205.61085 | 165.20680 | -19.52135% |
| matches, size mismatch | 91.60575 | 131.12670 | +43.55342% |
| matches, missing path | 78.38015 | 75.96920 | -3.07524% |
| digest_file, valid bytes | 113.64135 | 163.07715 | +44.28388% |

The immutable fixture has 32 files per existing class: valid, same-size-corrupt,
size-mismatch, plus 32 absent paths. Expected length is 8 KiB; size-mismatch files
are one byte shorter. Existing content is 96 files / 786,400 bytes. Full actual
fixture SHA checks and one common untimed warmup precede each measurement. Each
class runs 32 repeats, and direct valid digest is a fifth class: 5,120 timed calls
per invocation / 61,440 across all twelve invocations. Every actual file and source
uses the same bytes for both versions. The recorded timeout was 120 seconds per
invocation; actual command wall times were under one second each.

This is an ordinary Windows release **library** measurement of repeated 8 KiB
warm files. It differs from large game/EXE payload bytes, real first-install
missing-file mix, unpacking, cache publication, durable transaction copies,
fresh game-process checks, actual shipped EXE execution, or HTTPS throughput.
Background antivirus/disk activity is not controlled. There is no measured total
install improvement and no extrapolation to 125,965 files or player laptops.

Every six-round array, per-round paired ratio, minimum/maximum and median is in
DISTRIBUTIONS-01.json. The exact command/timeout/exit, all stdout/stderr, selected
test results and report hashes are indexed by PUBLIC-INDEX-01.json. INPUTS-01.json
binds the runner, the original 156-file freeze and the unchanged command plan;
TERMINAL-01.json records the successful twelve-command lifecycle and final hash
verification. The original frozen plan's `executed=false` and earlier receipt's
`benchmarkExecuted=false` remain historical statements at their creation time;
they were never rewritten to backdate this later execution.

Raw invocation reports reside in the adjacent benchmark-reports directory, as
the original command plan required. FROZEN-PUBLIC-01.json explicitly allows all
new public inputs/results/index files and their checksums; it excludes Cargo
target directories, temporary contents, private stores and unrelated files.
No additional tests, benchmark rounds, builds or performance optimizations were
performed after the twelve authorized invocations.
