# Isolated actual-handle hash checks: bounded release QA

The checked-handle implementation is external to the repository. The original
eighteen updater source files still match the recorded b87aa8a8 baseline, whose
updater production bytes match 48454. No root, original frozen QA, installed game,
player saves, game processes, live service or publication was changed.

Only the owned worker's `src/fs_safe.rs` changes production behavior. The owned
`src/fs_safe_read_tests.rs` is new and supplies public-API checks plus one ignored
benchmark. The independent original crate uses the exact original fs_safe body
and only appends the same test-module hook; both crates use identical tests.

## Actual sequential release results

- Rust 1.95.0, Windows MSVC, release, locked, offline, jobs 2.
- Original body: successful compilation followed by four actual failures; 0
  passed / 4 failed, Cargo exit 101. Existing write/delete handles were accepted
  by the original matches/digest APIs, producing Ok instead of the expected
  actual Windows sharing violation. This is meaningful RED, not a compile error.
- Checked handle focused: 12 passed / 0 failed / 1 ignored. Actual held writers
  and delete handles are rejected; concurrent readers, empty/exact content,
  fresh same-size-corruption detection, size mismatch/missing, hardlinks,
  leaf/ancestor reparse points, Unicode case aliases and local paths longer than
  512 UTF-16 units pass. The ignored item is the benchmark.
- Checked handle adjacent library: 77 passed / 0 failed / 5 ignored, 14.22 s.
  The focused twelve overlap this set. The five ignored checks are four existing
  signed full-size fixtures and the one new benchmark.

No compile failure or assertion correction occurred in these three commands.
Every raw stdout/stderr and exact argv/timeout/exit receipt is retained in logs.
Owned TEMP/TMP and independent target directories were used. No benchmark was
executed, and successful library checks are not shipped-EXE/HTTPS acceptance.

## Preserved safety boundary

One validated read-only handle provides both size and SHA. Windows share mode
permits readers but denies write/delete access throughout the hash operation;
actual handle links, reparse attributes and normalized original UTF-16 ordinal
path are checked, with bounded long-path buffers. Unix code additionally checks
actual/named device/inode, links and end size/timestamps; Unix tests were not run.
There is no cross-call digest cache. Size mismatch still returns false before
payload hashing. Both public API signatures remain unchanged.

The original bodies of ancestors, target, regular, open_download, read_bounded,
write_new, atomic_write, clear_scratch and install_root are byte-identical. CMS,
SHA expectations, dependencies/lockfile, download/resume logic, journal recovery,
transaction copies/fsync and per-file fresh game-process guards were not changed.

The pre-run FROZEN-SOURCE-02 receipt predates all test executions. The earlier
BEFORE-SOURCE-01 and EDITS-READY-01 receipts are retained as historical records;
EDITS-READY-01 describes the twelve-test state before the authorized benchmark
was added. SOURCE-PREP-02 and the later freeze provide the new test-file hash.

## Prepared A/B commands: do not execute without next authorization

BENCHMARK-COMMAND-PLAN-01.json contains all twelve exact command arrays and
per-command environment overrides. Each selects only
`fs_safe::read_tests::matched_read_handle_benchmark`, with `--ignored --exact`;
it cannot accidentally select the existing full signed-install fixtures.
Both versions use one unchanged 786,400-byte ordinary fixture: 32 files each
for valid, same-size-corrupt and size-mismatch, plus 32 absent paths. Every
actual size/SHA is checked before timing. Each class receives one common untimed
warmup, then 32 repeats (1,024 calls per class); valid digest adds 1,024 calls.
There are 5,120 timed calls per invocation and 61,440 across six pairs.

The order is A/B, B/A, A/B, B/A, A/B, B/A. All per-round/per-class results and
failures must be retained, with paired comparisons rather than the fastest
sample. The commands allow 120 s per invocation and require fresh report paths.

The exact Cargo shape is:

```powershell
& 'C:/Users/Administrator/.cargo/bin/cargo.exe' +1.95.0 test `
  --manifest-path '<owned original-crate or worker-crate>/Cargo.toml' `
  --locked --offline --jobs 2 --release --target x86_64-pc-windows-msvc `
  --target-dir 'C:/mir2-build/updater-read-handle-20261005/<variant>' `
  --lib fs_safe::read_tests::matched_read_handle_benchmark `
  -- --ignored --exact --nocapture --test-threads=1
```

Apply the exact bound environment values from the JSON; do not guess or substitute
the source/fixture hashes. This is a warm-cache library microbenchmark, not a
fresh-install, decompression, commit, public network or user's laptop measurement.
Background disk and antivirus activity are not controlled. No speed improvement
is claimed before the actual matched measurements.
