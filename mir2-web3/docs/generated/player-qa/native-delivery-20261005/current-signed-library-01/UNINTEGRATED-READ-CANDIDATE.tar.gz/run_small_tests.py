"""Execute only explicitly named small, offline release test selections.

The ignored benchmark is deliberately absent from this runner. Logs and receipts
are never overwritten; compile failures and assertion failures are both retained.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

OWNED = Path(r"C:/mir2-playtest-releases/20261004-native-r18/updater-read-handle-implementation-01")
CARGO = Path(r"C:/Users/Administrator/.cargo/bin/cargo.exe")
TARGET_ROOT = Path(r"C:/mir2-build/updater-read-handle-20261005")
PLAN = {
    "original-sharing-red-01": ("original", "original-crate", "fs_safe::read_tests::windows::existing_", 900),
    "worker-focused-green-01": ("checked-handle", "worker-crate", "fs_safe::read_tests::", 900),
    "worker-adjacent-green-01": ("checked-handle", "worker-crate", None, 300),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    name = sys.argv[1]
    if name not in PLAN:
        raise RuntimeError("unreviewed test selection")
    variant, crate_name, selector, timeout = PLAN[name]
    receipt = OWNED / "logs" / f"{name}.json"
    if receipt.exists():
        raise RuntimeError("receipt exists; no rerun or overwrite")
    prepared = json.loads((OWNED / "SOURCE-PREP-02.json").read_bytes())
    crate = OWNED / crate_name
    for item in prepared["files"]:
        if item["variant"] == variant:
            path = crate / item["path"]
            if path.stat().st_size != item["size"] or sha(path) != item["sha256"]:
                raise RuntimeError("prepared source changed: " + item["path"])
    argv = [str(CARGO), "+1.95.0", "test", "--manifest-path", str(crate / "Cargo.toml"),
            "--locked", "--offline", "--jobs", "2", "--release", "--target", "x86_64-pc-windows-msvc",
            "--target-dir", str(TARGET_ROOT / variant), "--lib"]
    if selector:
        argv.append(selector)
    argv += ["--", "--nocapture", "--test-threads=1"]
    env = dict(os.environ)
    temporary = OWNED / ("tmp-original" if variant == "original" else "tmp-worker")
    env.update(TEMP=str(temporary), TMP=str(temporary))
    for key in list(env):
        if key.startswith("MIR2_READ_HANDLE_BENCH_"):
            del env[key]
    out_path = OWNED / "logs" / f"{name}.stdout.log"
    err_path = OWNED / "logs" / f"{name}.stderr.log"
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    timed_out = False
    with out_path.open("xb") as stdout, err_path.open("xb") as stderr:
        # Own this Cargo process only. On timeout record it and leave its PID
        # untouched for parent review; never enumerate or terminate other games.
        process = subprocess.Popen(argv, cwd=crate, env=env, stdout=stdout, stderr=stderr)
        try:
            exit_code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            exit_code = None
    value = {
        "schema": "mir2.updater.read-handle.small-command.v1", "name": name, "variant": variant,
        "argv": argv, "cwd": str(crate), "environmentOverrides": {"TEMP": str(temporary), "TMP": str(temporary)},
        "sourcePreparationSha256": sha(OWNED / "SOURCE-PREP-02.json"),
        "startedUtc": started, "completedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "wallSeconds": time.monotonic() - clock, "timeoutSeconds": timeout, "timedOut": timed_out,
        "ownedPid": process.pid, "exitCode": exit_code, "ignoredBenchmarkExecuted": False,
        "stdout": {"path": str(out_path), "bytes": out_path.stat().st_size, "sha256": sha(out_path)},
        "stderr": {"path": str(err_path), "bytes": err_path.stat().st_size, "sha256": sha(err_path)},
        "rootWritten": False, "network": False, "userInstallationTouched": False,
        "meaningfulRedRequiresCompiledFourActualAssertionFailures": name == "original-sharing-red-01",
    }
    with receipt.open("xb") as output:
        output.write((json.dumps(value, indent=2) + "\n").encode())
    print(json.dumps({"name": name, "exitCode": exit_code, "timedOut": timed_out, "wallSeconds": value["wallSeconds"],
                      "receipt": str(receipt)}), flush=True)
    if timed_out:
        raise SystemExit(124)
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
