"""Archive only approved public candidate sources/receipts; do not integrate."""
from pathlib import Path
import hashlib, json, stat, tarfile

source = Path('C:/mir2-playtest-releases/20261004-native-r18/updater-read-handle-implementation-01')
out = Path(__file__).resolve().parent / 'candidate-benchmark-proof-01'
out.mkdir(exist_ok=False)
files = {}
allowed = {'.py', '.rs', '.json', '.log', '.md', '.patch', '.toml', '.lock'}
for name in ['FROZEN-SMALL-QA-01.json', 'benchmark-execution-01/FROZEN-PUBLIC-01.json']:
    freeze_path = source / name
    raw = freeze_path.read_bytes()
    freeze = json.loads(raw)
    for entry in freeze['files']:
        rel = entry['path']
        path = source / rel
        assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
        data = path.read_bytes()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']
        if path.suffix.lower() in allowed:
            files[rel] = path
    files[name] = freeze_path
for rel in ['FINAL-SMALL-QA-01.json', 'FILESYSTEM-CHANGE-01.patch', 'BENCHMARK-COMMAND-PLAN-01.json']:
    files[rel] = source / rel
inventory = []
for rel, path in sorted(files.items()):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info, 'st_file_attributes', 0) & 0x400
    data = path.read_bytes()
    inventory.append({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'schema': 'mir2.updater.unintegrated-read-candidate-proof.v1',
            'files': inventory, 'integrated': False, 'shipped': False,
            'overallInstallImprovementProved': False,
            'scope': 'four real original-body sharing RED, 12 focused GREEN within77 library passes, 12 actual balanced8KiB warm-release benchmark invocations; candidate not accepted as download speed fix',
            'excluded': '96 binary synthetic fixture payloads, all target/compiled EXEs, temporary contents, credentials and user data'}
with (out / 'INVENTORY.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(manifest, f, indent=2)
    f.write('\n')
archive = out / 'BYTE-EXACT-PROOF.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for rel, path in sorted(files.items()):
        tar.add(path, arcname=rel, recursive=False)
    tar.add(Path(__file__), arcname='freeze-candidate-benchmark-proof.py', recursive=False)
data = archive.read_bytes()
info = {'path': archive.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'regularMembers': len(files) + 1, 'integrated': False, 'shipped': False}
with (out / 'ARCHIVE.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(info, f, indent=2)
    f.write('\n')
print(json.dumps(info))
