# R17 native CI delivery helper — frozen local implementation

This directory contains two new Python files for root review. It changes no
checkout, workflow, server, public pointer, player store or earlier evidence.
Python 3.13.6 on Windows passed all 46 focused test methods. There were no real
network requests or credentials in these tests.

## Exact production scope

`scripts/native_r17_r2_delivery.py` has only `stage` and `promote` modes. Its
immutable plan is loaded from the fixed repository-relative path
`infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json`.
There is no command-line or environment plan, host, URL, key or query override.
Literal plan SHA is
`4a7eda51fd375b64a250faa8d1709f8b611af8d60172aabf7c1032b864e490fc`.

Only verified HTTPS to `assets.mir2.obelisk.build:443` is permitted. Public
GET/HEAD is limited to the 36 literal `/client-updates/` paths and two latest
aliases. Private bearer requests are limited to POST `/upload/native-r17/import`
with exactly one bounded index, GET/HEAD `/upload/native-r17/objects/<index>`,
GET/HEAD `/upload/native-r17/pointer` and POST `/upload/native-r17/promote` with
the direct stage envelope. The sole credential input is the opaque CI environment
variable `MIR2_R2_UPLOAD_SECRET`; it is never emitted into receipts, stdout,
exceptions or request descriptions. There is no redirect, proxy or retry.

The TLS context uses `PROTOCOL_TLS_CLIENT`, `CERT_REQUIRED`, hostname verification
and system default CA loading. Explicit construction avoids the implicit
`SSLKEYLOGFILE` side effect of `ssl.create_default_context`. The final test uses
real SSLContext construction with mocked CA loading and HTTPS, and proves no
keylog file is created or written. It performs no TLS handshake.

## Stage and promote gates

Stage first checks private plan headers and an absent or byte-exact candidate
pointer. For every object it checks private resume metadata, sends the exact
index POST, checks post-import metadata and streams the complete public object
through size and SHA-256 validation. Only after all 36 streams and response
closures pass does it create the stage envelope. Stage never writes a pointer.

Promote accepts a retained regular, single-link, create-only stage receipt with
an operator-supplied byte SHA. It checks the exact source, plan pins, candidate,
36-object closure, verified counters, typed flags and complete 145-call stage
order. It sends the direct envelope once, then independently verifies private
pointer canonical bytes and both public latest aliases. Each alias must pass
full SHA, size, no-store and the actual public Worker's selected headers.
An ambiguous send, response or readback retains `pointerOutcomeUnknown`; there
is no automatic retry, delete, rollback or pointer rewrite.

Public object MIME and cache validation follows the frozen public Worker, not
stored R2 metadata: `.gz` is `application/gzip`, `.json` is `application/json`,
`.p7s` is `application/pkcs7-signature`; other artifact paths are octet-stream.
Immutable responses require one-year immutable caching and HIT/MISS; alias
responses require no-store and BYPASS plus the selected sequence/feed paths.
Content encoding, partial responses, redirect responses and duplicate headers
are rejected.

Public reads use bounded 64 KiB chunks with a two-chunk producer queue. Every
request has its own absolute deadline, including stalled connection/headers.
Cancellation after a delayed connect is checked before any bearer request is
sent. Receipt paths use fresh creation, regular-file, single-link and
symlink/reparse/parent identity checks, with POSIX openat and 0600 checks.

An operator must require BOTH exit code 0 and the complete source-bound written
receipt. A partial file left after a receipt write/fsync/close error is not an
accepted result, even if its partial bytes contain an optimistic field. Parent
CI integration and post-process exit handling remain root-owned.

## Retained RED and GREEN

| Run | Test methods | Passed methods | Failed methods | Failure assertions | Errors / skips |
| --- | ---: | ---: | ---: | ---: | --- |
| RED01 | 32 | 19 | 13 | 23 | 0 / 0 |
| GREEN02 | 32 | 32 | 0 | 0 | 0 / 0 |
| RED03 receipt fences | 45 | 41 | 4 | 4 | 0 / 0 |
| GREEN04 receipt fences | 45 | 45 | 0 | 0 | 0 / 0 |
| RED05 keylog | 46 | 45 | 1 | 1 | 0 / 0 |
| GREEN06 final | 46 | 46 | 0 | 0 | 0 / 0 |

RED01's original mechanical pass counter subtracted 23 subtest assertions from
32 methods and reported 9. Its raw evidence is unchanged. The separate
`evidence/ACCOUNTING-DIAGNOSTIC-01.json` derives the correct 19 passed / 13 failed
method count from the retained raw failure records. Later runner receipts count
distinct failed methods separately.

RED03 proves numeric booleans in envelopes, mismatched retained receipt SHA and
new hardlinks during input/output processing were initially accepted and are now
rejected. RED05 retains the fixture keylog file created by the old TLS factory;
it contains only an OpenSSL comment header, no session keys, because there was
no handshake. No raw log, baseline snapshot or failed fixture was deleted.

Final raw log is `evidence/local-tests-06-final-green.log`; final machine receipt
is `evidence/TEST-RECEIPT-1791160500482901900.json`. Exact commands and all run
input/log hashes are retained in the `RUN-*.json` files.

## Evidence boundaries

The source input table binds the frozen importer README, four approved files,
its freeze receipt, the real 1159-byte feed / 1614-byte CMS fixture and the
public Worker source/config. `INPUT-RECHECK-01.json` proves all ten remained
byte-identical at final packaging. Python hashes do not authenticate CMS.

Successful fake stage/promote tests use the real tiny feed pair plus 34 small
synthetic objects through the dependency-injected internal core. The CLI cannot
select that toy plan. A synthetic 111,013,376-byte zero stream exercises bounded
memory but deliberately fails the real executable hash. No fake success counts
as the actual 817,657,896-byte source or CDN closure, and short mock deadlines
are not download-speed evidence.

Remaining gates are explicit: root review and integration, independent Linux
POSIX/0600 tests, opaque CI authority, actual private Worker/R2 staging, full
public CDN 36-object TLS verification, original CMS verification, promote
readback/aliases and retained CI exit/receipt handling. No deployment, actual
Cloudflare authorization, CMS acceptance, live route or throughput is claimed.

After `FROZEN-DELIVERY.json` creation this directory is frozen. Root owns any
future repository integration and actual authenticated operation.
