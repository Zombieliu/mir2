// Local-only harness. The frozen import implementation is delegated without
// factory injection or any modification of its literal 36-object plan.
import frozenWorker from './src/index.ts';

function hex(bytes) {
  return [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

export default {
  async fetch(request, env, ctx) {
    const path = new URL(request.url).pathname;
    if (path === '/__local/platform') {
      const bytes = Uint8Array.from(atob(env.LOCAL_FEED_BASE64), character => character.charCodeAt(0));
      const fixed = new FixedLengthStream(bytes.byteLength);
      const digest = new crypto.DigestStream('SHA-256');
      const digestResult = digest.digest;
      const pipe = fixed.readable.pipeTo(digest);
      const writer = fixed.writable.getWriter();
      await writer.write(bytes.subarray(0, 257));
      await writer.write(bytes.subarray(257));
      await writer.close();
      await pipe;
      return Response.json({
        runtime: 'workerd-native', fixedLengthStream: typeof FixedLengthStream,
        digestStream: typeof crypto.DigestStream, bytes: bytes.byteLength,
        sha256: hex(await digestResult),
      });
    }
    if (path === '/__local/deny') {
      try {
        const result = await fetch('https://unmatched-must-not-connect.invalid/no-fixture');
        await result.body?.cancel();
        return Response.json({status: result.status});
      } catch {
        return Response.json({fetchRejected: true});
      }
    }
    if (path === '/__local/fixed-underflow' || path === '/__local/fixed-overflow') {
      const original = Uint8Array.from(atob(env.LOCAL_FEED_BASE64), character => character.charCodeAt(0));
      const supplied = path.endsWith('underflow') ? original.subarray(0, -1)
        : Uint8Array.from([...original, 0]);
      const fixed = new FixedLengthStream(original.byteLength);
      const digest = new crypto.DigestStream('SHA-256');
      const source = new ReadableStream({start(controller) {controller.enqueue(supplied); controller.close();}});
      const results = await Promise.allSettled([
        source.pipeTo(fixed.writable), fixed.readable.pipeTo(digest), digest.digest,
      ]);
      return Response.json({expectedBytes: original.byteLength, suppliedBytes: supplied.byteLength,
        settled: results.map(result => ({status: result.status,
          error: result.status === 'rejected' ? String(result.reason?.message ?? result.reason) : null}))});
    }
    return frozenWorker.fetch(request, env, ctx);
  },
};
