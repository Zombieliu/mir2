from pathlib import Path
import subprocess
import sys
import json
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
attempt = sys.argv[1]
case = sys.argv[2:]
assert len(case) <= 1
assert attempt.startswith('attempt-') and len(attempt) == 10 and attempt[-2:].isdigit()
out = root / 'evidence'
stdout_path = out / f'{attempt}.stdout.log'
stderr_path = out / f'{attempt}.stderr.log'
command_path = out / f'{attempt}.command.json'
for filename in [stdout_path, stderr_path, command_path]:
    if filename.exists():
        raise RuntimeError(f'Refusing to overwrite earlier attempt: {filename}')
argv = ['C:/Program Files/nodejs/node.exe', str(root / 'run-local-workerd.mjs'), attempt, *case]
started = datetime.now(timezone.utc).isoformat()
with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
    process = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr, timeout=300)
command_path.write_text(json.dumps({
    'argv': argv, 'cwd': str(root), 'started': started,
    'completed': datetime.now(timezone.utc).isoformat(), 'exitCode': process.returncode,
    'noInstallation': True, 'ownedLocalOnly': True,
}, indent=2) + '\n', encoding='utf-8')
print(stdout_path.read_text(encoding='utf-8', errors='replace'))
print(stderr_path.read_text(encoding='utf-8', errors='replace'), file=sys.stderr)
sys.exit(process.returncode)
