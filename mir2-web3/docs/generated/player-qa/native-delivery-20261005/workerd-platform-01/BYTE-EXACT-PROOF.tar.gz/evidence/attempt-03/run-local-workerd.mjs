import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const require = createRequire(import.meta.url);
const deps = 'C:/Users/Administrator/AppData/Local/npm-cache/_npx/c7c463f4b2350a3b/node_modules';
const {Miniflare, convertV4MiniflareOptions} = require(`${deps}/miniflare`);
const undici = require(`${deps}/undici`);
const esbuild = require(`${deps}/esbuild`);
const root = path.dirname(fileURLToPath(import.meta.url));
const attempt = process.argv[2];
assert.match(attempt ?? '', /^attempt-[0-9]{2}$/);
const caseFilter = process.argv[3];
const evidence = path.join(root, 'evidence', attempt);
await mkdir(evidence, {recursive: false});
const runtimeRoot = path.join(root, 'local-runtime', attempt);
await mkdir(runtimeRoot, {recursive: false});
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const expectedSources = {
  'src/index.ts': '7aa43b7c6cffe6ff271fcd7199ed8be95bd30783dc5b72809d57688fadcd1f40',
  'src/native-r17-publication.mjs': '55a158a819feba4cb991682ef2dcc2c6aa7b4b1b6a22315e2d197cdcf1d9d400',
  'src/native-r17-publication-plan.json': '4a7eda51fd375b64a250faa8d1709f8b611af8d60172aabf7c1032b864e490fc',
  'test/native-r17-publication.test.mjs': 'cb0053d02cdf18b09bec3150678d46f41169cda8157e12016ce7691fc26a5a3d',
};
const sourceReceipt = [];
for (const [relative, expected] of Object.entries(expectedSources)) {
  const bytes = await readFile(path.join(root, relative));
  assert.equal(sha(bytes), expected, `Frozen source changed: ${relative}`);
  sourceReceipt.push({path: relative, bytes: bytes.byteLength, sha256: expected});
}
const plan = JSON.parse(await readFile(path.join(root, 'src/native-r17-publication-plan.json'), 'utf8'));
assert.equal(plan.objects.length, 36);
assert.equal(plan.objectsSha256, 'f38a692a4ba200177f4358c9f3d1566f97fadb32cf408c072cb1f8b8bb03d4f0');
const fixtures = new Map();
for (const [index, relative] of [[0, 'fixture/fixture-latest.json'], [1, 'fixture/fixture-latest.p7s']]) {
  const bytes = await readFile(path.join(root, relative));
  assert.equal(bytes.byteLength, plan.objects[index].size);
  assert.equal(sha(bytes), plan.objects[index].sha256);
  fixtures.set(index, bytes);
}
assert.equal(plan.originBase, 'https://165.154.65.136.sslip.io/client-updates/');
const origin = new URL(plan.originBase);
const prefix = '/upload/native-r17';
const pointerKey = `${plan.r2Prefix}channels/invited.json`;
const secret = 'LOCAL-ONLY-FAKE-SECRET-NOT-A-CLOUDFLARE-CREDENTIAL';
const versions = {node: process.version};
const dependencies = [];
for (const name of ['wrangler', 'miniflare', 'workerd', 'esbuild', 'undici']) {
  const filename = `${deps}/${name}/package.json`;
  const bytes = await readFile(filename);
  versions[name] = JSON.parse(bytes).version;
  dependencies.push({path: filename, bytes: bytes.byteLength, sha256: sha(bytes)});
}
const workerdExe = `${deps}/@cloudflare/workerd-windows-64/bin/workerd.exe`;
const workerdBytes = await readFile(workerdExe);
dependencies.push({path: workerdExe, bytes: workerdBytes.byteLength, sha256: sha(workerdBytes)});
const compiled = await esbuild.build({
  entryPoints: [path.join(root, 'local-worker-entry.mjs')], bundle: true,
  platform: 'browser', format: 'esm', target: 'es2022', write: false,
  logLevel: 'silent', sourcemap: false, metafile: true,
});
const script = compiled.outputFiles[0].text;
await writeFile(path.join(evidence, 'local-worker-bundle.mjs'), script, {flag: 'wx'});
await writeFile(path.join(evidence, 'esbuild-metafile.json'), JSON.stringify(compiled.metafile, null, 2) + '\n', {flag: 'wx'});

// Node-side SDK default dispatch is also closed except for loopback transport.
// Worker outbound uses a DIFFERENT MockAgent with all net connections disabled.
// No client/remote binding/proxy/auth configuration is loaded by this harness.
const sdkGuard = new undici.MockAgent();
sdkGuard.disableNetConnect();
sdkGuard.enableNetConnect(host => /^(?:127\.0\.0\.1|\[::1\])(?::[0-9]+)?$/.test(host));
undici.setGlobalDispatcher(sdkGuard);
globalThis.fetch = async () => { throw new Error('Node global fetch disabled in local platform harness'); };

const receipt = {
  schema: 'mir2.native-r17.local-workerd-check.v1', attempt, started: new Date().toISOString(),
  versions, dependencies, sourceReceipt, bundleSha256: sha(Buffer.from(script)),
  originalPlanCount: 36, closureSha256: plan.objectsSha256,
  compatibilityDate: '2026-05-18', unchangedNativeDefaults: true,
  network: {
    workerdOutbound: 'explicit outboundService -> MockAgent.disableNetConnect()',
    mockOrigins: [origin.origin], mockBodyIndexes: [0, 1],
    otherArtifactsHaveNoBody: true, sdkGlobalDispatcher: 'loopback only',
    nodeGlobalFetch: 'disabled', cf: false, telemetry: false, registerWorker: false,
    remoteBindings: false,
  },
  claims: {
    actualLocalWorkerd: true, actualLocalR2Binding: true,
    remoteR2: false, realHttpsTransport: false, cmsCryptographicReverification: false,
    deployment: false, native36BodiesAccepted: false, pointerPromotion: false,
  }, cases: [],
};
let serial = 0;

function checksumHex(value) {
  if (value instanceof ArrayBuffer) return Buffer.from(value).toString('hex');
  if (ArrayBuffer.isView(value)) return Buffer.from(value.buffer, value.byteOffset, value.byteLength).toString('hex');
  return null;
}
function metadata(record) {
  if (record === null) return null;
  return {key: record.key, size: record.size, httpEtag: record.httpEtag,
    httpMetadata: record.httpMetadata, customMetadata: record.customMetadata,
    sha256: checksumHex(record.checksums?.sha256),
    checksumConstructor: record.checksums?.sha256?.constructor?.name ?? null,
    checksumKeys: Object.keys(record.checksums ?? {})};
}
async function wireResponse(response) {
  const bytes = Buffer.from(await response.arrayBuffer());
  let body;
  try { body = JSON.parse(bytes.toString('utf8')); } catch { body = {bytes: bytes.byteLength, sha256: sha(bytes)}; }
  return {status: response.status, body, headers: Object.fromEntries(response.headers)};
}

async function withLocalR2(name, replies, action, options = {}) {
  const caseRecord = {name, started: new Date().toISOString(), outbound: [], r2: [], assertions: [], passed: false};
  receipt.cases.push(caseRecord);
  const check = (label, fn) => { fn(); caseRecord.assertions.push(label); };
  const instanceRoot = path.join(runtimeRoot, `${String(++serial).padStart(2, '0')}-${name}`);
  await mkdir(instanceRoot, {recursive: false});
  const mock = new undici.MockAgent();
  mock.disableNetConnect();
  const pool = mock.get(origin.origin);
  for (const reply of replies) {
    assert.ok(fixtures.has(reply.index), 'Only the exact two real frozen feed fixtures may be mocked');
    const entry = plan.objects[reply.index];
    const headers = {'content-type': entry.contentType, 'content-length': String(entry.size), ...(reply.headers ?? {})};
    for (const header of reply.removeHeaders ?? []) delete headers[header];
    const bytes = reply.body ?? fixtures.get(reply.index);
    pool.intercept({method: 'GET', path: origin.pathname + entry.originRelativePath})
      .reply(reply.status ?? 200, Buffer.from(bytes), {headers}).times(reply.times ?? 1);
  }
  let barrierCount = 0, releaseBarrier;
  const barrier = new Promise(resolve => { releaseBarrier = resolve; });
  let barrierTimeout;
  if (options.barrier) barrierTimeout = setTimeout(() => releaseBarrier(), 10000);
  const outboundService = async request => {
    const selected = {
      authorizationPresent: request.headers.has('authorization'),
      cookiePresent: request.headers.has('cookie'),
      acceptEncoding: request.headers.get('accept-encoding'),
      cacheControl: request.headers.get('cache-control'),
    };
    const event = {method: request.method, url: request.url, headers: selected};
    caseRecord.outbound.push(event);
    check('Bearer and cookies never reach origin mock', () => {
      assert.equal(selected.authorizationPresent, false); assert.equal(selected.cookiePresent, false);
    });
    try {
      const response = await undici.fetch(request.url, {
        method: request.method, headers: request.headers, dispatcher: mock, redirect: 'manual',
      });
      event.mockMatched = true; event.status = response.status;
      // Count the exact bytes yielded by the mock to the Miniflare HTTP bridge.
      // This does not buffer, clone, tee, or inject the Worker's fetch response.
      const counted = response.body?.pipeThrough(new TransformStream({
        transform(chunk, controller) {
          event.bytesYieldedToBridge = (event.bytesYieldedToBridge ?? 0) + chunk.byteLength;
          controller.enqueue(chunk);
        },
        flush() {event.mockBodyCompleted = true;},
      }));
      if (options.barrier) {
        event.barrierEntry = ++barrierCount;
        if (barrierCount === 2) releaseBarrier();
        await barrier;
      }
      return new undici.Response(counted, {status: response.status, headers: response.headers});
    } catch (error) {
      event.mockMatched = false; event.rejected = true;
      event.error = {name: error.name, code: error.cause?.code ?? error.code ?? null};
      throw error;
    }
  };
  let mf;
  try {
    const options = convertV4MiniflareOptions({
      host: '127.0.0.1', port: 0, cf: false, telemetry: {enabled: false},
      unsafeDevRegistryPath: path.join(instanceRoot, 'registry'),
      unsafeLocalExplorer: false, unsafeObservability: false,
      resourcePersistencePath: path.join(instanceRoot, 'persistence'),
      isolatedResourcePersistencePath: path.join(instanceRoot, 'isolated'),
      resourceTmpPath: path.join(instanceRoot, 'tmp'),
      workers: [{
        name: `native-r17-local-${serial}`, script, modules: true, rootPath: root,
        compatibilityDate: '2026-05-18', unsafeRegisterWorker: false,
        bindings: {MIR2_R2_UPLOAD_SECRET: secret, LOCAL_FEED_BASE64: fixtures.get(0).toString('base64')},
        r2Buckets: {MIR2_ASSETS: `native-r17-owned-${attempt}-${serial}`}, outboundService,
      }],
    });
    mf = new Miniflare(options);
    const ready = await mf.ready;
    check('Local runtime listener is loopback', () => assert.equal(ready.hostname, '127.0.0.1'));
    caseRecord.localUrl = ready.href;
    const bucket = await mf.getR2Bucket('MIR2_ASSETS');
    const request = async (suffix, init = {}) => mf.dispatchFetch(`https://native-local.invalid${suffix}`, {
      redirect: 'manual', ...init,
      headers: {authorization: `Bearer ${secret}`, ...(init.headers ?? {})},
    });
    const importEntry = async index => wireResponse(await request(`${prefix}/import`, {
      method: 'POST', headers: {'content-type': 'application/json'}, body: JSON.stringify({index}),
    }));
    await action({mf, bucket, request, importEntry, check, caseRecord});
    const pointer = await bucket.head(pointerKey);
    caseRecord.pointer = metadata(pointer);
    check('Channel pointer was never created', () => assert.equal(pointer, null));
    for (const entry of plan.objects) {
      const stored = await bucket.head(entry.r2Key);
      if (stored) caseRecord.r2.push(metadata(stored));
    }
    mock.assertNoPendingInterceptors();
    caseRecord.passed = true;
    console.log(`PASS ${name} (${caseRecord.assertions.length} assertions)`);
  } catch (error) {
    caseRecord.error = {name: error.name, message: error.message, stack: error.stack};
    console.error(`FAIL ${name}\n${error.stack}`);
  } finally {
    clearTimeout(barrierTimeout);
    if (mf) await mf.dispose();
    await mock.close();
    caseRecord.completed = new Date().toISOString();
    await writeFile(path.join(evidence, `${name}.json`), JSON.stringify(caseRecord, null, 2) + '\n', {flag: 'wx'});
  }
}

const cases = [
  ['native-platform', [], async ({request, check, caseRecord}) => {
    const result = await wireResponse(await request('/__local/platform'));
    caseRecord.response = result;
    check('Real FixedLengthStream and crypto.DigestStream consume exact real feed bytes', () => {
      assert.equal(result.status, 200); assert.equal(result.body.fixedLengthStream, 'function');
      assert.equal(result.body.digestStream, 'function'); assert.equal(result.body.bytes, plan.objects[0].size);
      assert.equal(result.body.sha256, plan.objects[0].sha256);
    });
  }],
  ['exact-feed-import-and-resume', [{index: 0}, {index: 1}], async ({bucket, request, importEntry, check, caseRecord}) => {
    for (const index of [0, 1]) {
      const entry = plan.objects[index];
      const created = await importEntry(index); (caseRecord.responses ??= []).push(created);
      check(`First immutable import ${index} returns 201`, () => assert.equal(created.status, 201));
      const head = await bucket.head(entry.r2Key); caseRecord[`head${index}`] = metadata(head);
      check(`Actual local R2 HEAD ${index} returns exact sha256 checksum and metadata`, () => {
        assert.equal(head.size, entry.size); assert.equal(checksumHex(head.checksums.sha256), entry.sha256);
        assert.equal(head.customMetadata.sha256, entry.sha256);
        assert.equal(head.httpMetadata.contentType, entry.contentType);
        assert.equal(head.httpMetadata.cacheControl, entry.cacheControl);
      });
      const record = await bucket.get(entry.r2Key); caseRecord[`get${index}`] = metadata(record);
      const storedBytes = Buffer.from(await record.arrayBuffer());
      check(`Actual local R2 GET ${index} checksum and full small body match`, () => {
        assert.equal(checksumHex(record.checksums.sha256), entry.sha256);
        assert.equal(storedBytes.byteLength, entry.size); assert.equal(sha(storedBytes), entry.sha256);
      });
      const servedHead = await request(`${prefix}/objects/${index}`, {method: 'HEAD'});
      check(`Admin HEAD ${index} preserves literal size and hash`, () => {
        assert.equal(servedHead.status, 200); assert.equal(servedHead.headers.get('content-length'), String(entry.size));
        assert.equal(servedHead.headers.get('x-mir2-stored-sha256'), entry.sha256);
      });
      const servedGet = await request(`${prefix}/objects/${index}`);
      const servedBytes = Buffer.from(await servedGet.arrayBuffer());
      check(`Admin GET ${index} returns exact fixture`, () => {
        assert.equal(servedGet.status, 200); assert.equal(sha(servedBytes), entry.sha256);
      });
      const sourceCount = caseRecord.outbound.length;
      const resumed = await importEntry(index); caseRecord.responses.push(resumed);
      check(`Exact resume ${index} returns 200 without fetching source`, () => {
        assert.equal(resumed.status, 200); assert.equal(resumed.body.resumed, true);
        assert.equal(caseRecord.outbound.length, sourceCount);
      });
    }
    check('Only exact feed and signature GETs occurred with identity encoding', () => {
      assert.equal(caseRecord.outbound.length, 2);
      assert.ok(caseRecord.outbound.every(event => event.headers.acceptEncoding === 'identity' && event.headers.cacheControl === 'no-store'));
    });
  }],
  ['concurrent-create-only', [{index: 0, times: 2}], async ({bucket, importEntry, check, caseRecord}) => {
    const results = await Promise.all([importEntry(0), importEntry(0)]); caseRecord.responses = results;
    check('Both null-before-fetch imports enter actual race barrier', () => {
      assert.equal(caseRecord.outbound.length, 2);
      assert.deepEqual(caseRecord.outbound.map(event => event.barrierEntry).sort(), [1, 2]);
    });
    check('Actual R2 onlyIf Headers create gives one 201 and one 412', () => {
      assert.deepEqual(results.map(result => result.status).sort(), [201, 412]);
    });
    const head = await bucket.head(plan.objects[0].r2Key);
    check('Race winner keeps exact original checksum', () => assert.equal(checksumHex(head.checksums.sha256), plan.objects[0].sha256));
  }, {barrier: true}],
  ['bad-checksum', [{index: 0, body: Buffer.from(fixtures.get(0)).map((byte, index) => index === 31 ? byte ^ 1 : byte)}], async ({bucket, importEntry, check, caseRecord}) => {
    const result = await importEntry(0); caseRecord.response = result;
    check('Actual R2 supplied sha256 rejects changed same-length bytes', () => assert.equal(result.status, 502));
    const head = await bucket.head(plan.objects[0].r2Key);
    check('Actual head after bad checksum remains null', () => assert.equal(head, null));
  }],
  ['origin-redirect', [{index: 0, status: 302, headers: {location: 'https://redirect-must-not-connect.invalid/no-fixture'}}], negative('origin_status_rejected')],
  ['origin-encoding', [{index: 0, headers: {'content-encoding': 'gzip'}}], negative('origin_encoding_rejected')],
  ['origin-wrong-length', [{index: 0, headers: {'content-length': String(plan.objects[0].size + 1)}}], negative('origin_size_rejected')],
  ['origin-missing-length', [{index: 0, removeHeaders: ['content-length']}], negative('origin_size_rejected')],
  ['source-short-stream', [{index: 0, body: fixtures.get(0).subarray(0, -1)}], negative('immutable_stream_or_checksum_failed')],
  ['source-extra-stream', [{index: 0, body: Buffer.concat([fixtures.get(0), Buffer.from([0])])}], negative('immutable_stream_or_checksum_failed')],
  ['outbound-denial-and-no-artifact-body', [], async ({bucket, request, importEntry, check, caseRecord}) => {
    const denied = await wireResponse(await request('/__local/deny')); caseRecord.denied = denied;
    check('Unmatched outbound is denied by actual MockAgent, never external connection', () => {
      assert.equal(caseRecord.outbound[0].mockMatched, false); assert.equal(caseRecord.outbound[0].error.code, 'UND_MOCK_ERR_MOCK_NOT_MATCHED');
      assert.ok(denied.body.status === 500 || denied.body.fetchRejected === true);
    });
    const result = await importEntry(2); caseRecord.response = result;
    check('Frozen large installer remains body unavailable and fails closed', () => {
      assert.equal(result.status, 502); assert.ok(['origin_fetch_failed', 'origin_status_rejected'].includes(result.body.error));
      assert.equal(caseRecord.outbound[1].mockMatched, false);
    });
    const head = await bucket.head(plan.objects[2].r2Key);
    check('No placeholder installer is stored', () => assert.equal(head, null));
  }],
  ['native-fixed-length-boundaries', [], async ({request, check, caseRecord}) => {
    caseRecord.responses = [];
    for (const kind of ['underflow', 'overflow']) {
      const result = await wireResponse(await request(`/__local/fixed-${kind}`));
      caseRecord.responses.push(result);
      check(`Actual native FixedLengthStream rejects ${kind} without HTTP framing`, () => {
        assert.equal(result.status, 200); assert.equal(result.body.expectedBytes, 1159);
        assert.equal(result.body.suppliedBytes, kind === 'underflow' ? 1158 : 1160);
        assert.ok(result.body.settled.every(outcome => outcome.status === 'rejected'));
        assert.ok(result.body.settled.some(outcome => /length|bytes|short|long|different/i.test(outcome.error)));
      });
    }
  }],
  ['http-framed-extra-observation', [{index: 0, body: Buffer.concat([fixtures.get(0), Buffer.from([0])])}], async ({bucket, importEntry, check, caseRecord}) => {
    const result = await importEntry(0); caseRecord.response = result;
    const entry = plan.objects[0];
    const head = await bucket.head(entry.r2Key); caseRecord.actualHead = metadata(head);
    const get = await bucket.get(entry.r2Key); caseRecord.actualGet = metadata(get);
    const bytes = Buffer.from(await get.arrayBuffer());
    caseRecord.actualBody = {size: bytes.byteLength, sha256: sha(bytes)};
    caseRecord.classification = 'HTTP bridge Content-Length frames the Worker-visible response body; this is not an overflow reaching FixedLengthStream';
    check('Mock offers full 1160 bytes to the HTTP bridge', () => assert.equal(caseRecord.outbound[0].bytesYieldedToBridge, 1160));
    check('Worker sees framed exact fixture and creates only exact 1159-byte object', () => {
      assert.equal(result.status, 201); assert.equal(head.size, entry.size);
      assert.equal(bytes.byteLength, entry.size); assert.equal(sha(bytes), entry.sha256);
      assert.equal(checksumHex(head.checksums.sha256), entry.sha256);
      assert.equal(checksumHex(get.checksums.sha256), entry.sha256);
    });
  }],
  ['auth-before-outbound', [], async ({mf, check, caseRecord}) => {
    const result = await wireResponse(await mf.dispatchFetch(`https://native-local.invalid${prefix}/import`, {
      method: 'POST', headers: {'content-type': 'application/json'}, body: '{"index":0}',
    }));
    caseRecord.response = result;
    check('Missing toy auth is rejected before any source request', () => {
      assert.equal(result.status, 401); assert.equal(result.body.error, 'unauthorized');
      assert.equal(caseRecord.outbound.length, 0);
    });
  }],
  ['all-other-artifact-bodies-unavailable', [], async ({bucket, importEntry, check, caseRecord}) => {
    caseRecord.responses = [];
    for (const entry of plan.objects.slice(2)) {
      const result = await importEntry(entry.index); caseRecord.responses.push({index: entry.index, ...result});
      const head = await bucket.head(entry.r2Key);
      check(`Literal original artifact ${entry.index} has no source body and no object`, () => {
        assert.equal(result.status, 502); assert.ok(['origin_fetch_failed', 'origin_status_rejected'].includes(result.body.error));
        assert.equal(head, null); assert.equal(caseRecord.outbound.at(-1).mockMatched, false);
      });
    }
    check('All 34 other literal artifact URLs were denied without body substitutes', () => {
      assert.equal(caseRecord.outbound.length, 34);
      assert.ok(caseRecord.outbound.every(event => event.rejected && !event.mockMatched));
    });
  }],
];
function negative(errorCode) {
  return async ({bucket, importEntry, check, caseRecord}) => {
    const result = await importEntry(0); caseRecord.response = result;
    check(`Frozen implementation rejects ${errorCode}`, () => {
      assert.equal(result.status, 502); assert.equal(result.body.error, errorCode);
    });
    const head = await bucket.head(plan.objects[0].r2Key);
    check('Rejected origin leaves no object in actual local R2', () => assert.equal(head, null));
    check('No redirect or alternate source was fetched', () => assert.equal(caseRecord.outbound.length, 1));
  };
}
try {
  console.log(JSON.stringify({versions, sourceReceipt, originalPlanCount: 36, network: receipt.network}));
  for (const [name, replies, action, options] of cases) {
    const followup = ['native-fixed-length-boundaries', 'http-framed-extra-observation',
      'auth-before-outbound', 'all-other-artifact-bodies-unavailable'];
    if (caseFilter && (caseFilter === 'followup' ? !followup.includes(name) : name !== caseFilter)) continue;
    await withLocalR2(name, replies, action, options);
  }
  receipt.completed = new Date().toISOString();
  receipt.passed = receipt.cases.length > 0 && receipt.cases.every(test => test.passed);
  receipt.summary = {cases: receipt.cases.length, passed: receipt.cases.filter(test => test.passed).length,
    failed: receipt.cases.filter(test => !test.passed).length,
    assertions: receipt.cases.reduce((sum, test) => sum + test.assertions.length, 0)};
  await writeFile(path.join(evidence, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n', {flag: 'wx'});
  console.log(JSON.stringify({passed: receipt.passed, ...receipt.summary}));
  process.exitCode = receipt.passed ? 0 : 1;
} finally {
  await sdkGuard.close();
}
