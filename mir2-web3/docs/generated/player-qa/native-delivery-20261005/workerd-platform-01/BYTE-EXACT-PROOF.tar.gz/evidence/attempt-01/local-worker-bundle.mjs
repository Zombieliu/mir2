// src/native-r17-publication-plan.json
var native_r17_publication_plan_default = {
  schema: "mir2.native.r17.fixed-origin-plan.v1",
  accountId: "85bf64d86ea9221e172d26feba9fd47e",
  bucket: "mir2-web3-assets",
  r2Prefix: "mir2/native/windows-invited/",
  originBase: "https://165.154.65.136.sslip.io/client-updates/",
  publicBase: "https://assets.mir2.obelisk.build/client-updates/",
  sourceRevision: "4c60c323aed11829abae6ee5ce6e13c675a3c1c3",
  sourcePlanSha256: "04bdb9d5f891bba38752e4ba4029db2d638dc7f4674d494ce0c6b5ab354f3b87",
  sourcePlanBase64: "ewogICJzY2hlbWEiOiAibWlyMi53aW5kb3dzLnIyLXB1YmxpY2F0aW9uLnYxIiwKICAiZXhwZWN0ZWRDdXJyZW50IjogbnVsbCwKICAiY2FuZGlkYXRlIjogewogICAgInNjaGVtYSI6ICJtaXIyLndpbmRvd3MucjItY2hhbm5lbC52MSIsCiAgICAiY2hhbm5lbCI6ICJpbnZpdGVkIiwKICAgICJwbGF0Zm9ybSI6ICJ3aW5kb3dzLXg2NCIsCiAgICAic2VxdWVuY2UiOiAxMiwKICAgICJzb3VyY2VSZXZpc2lvbiI6ICI0YzYwYzMyM2FlZDExODI5YWJhZTZlZTVjZTZlMTNjNjc1YTNjMWMzIiwKICAgICJmZWVkU2hhMjU2IjogIjdlZmRkZGYzNGZiZjU4ZmZhMGJmOGM0ZjdmY2IxYTlhZDJiYWM4NjljYjNmMDAzY2VhMGEwYzljNTMzNTZjODgiLAogICAgInNpZ25hdHVyZVNoYTI1NiI6ICI3ZGQxMzFkZGRjZWY5MTA3ZWEwYzgwMzYzY2M5Y2E0NDc0NjYwM2M1ODZhMWUyM2UwMGZmNmFhMTc4MDA2OTE2IgogIH0sCiAgInZlcmlmaWNhdGlvblJlY2VpcHQiOiB7CiAgICAicGF0aCI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxOFxccjE3LXIyLXB1YmxpY2F0aW9uLTAxXFxST09ULVZFUklGSUNBVElPTi5qc29uIiwKICAgICJzaGEyNTYiOiAiNmIzNjEzNDU5NzE4MGFkMmI0MjNjMjAxNWMwNWIzYzQ4NDQ3ZmJkNzY2ZTg1OGMyZmIwY2U2ZjQ1ZTI1NjViOSIKICB9LAogICJvYmplY3RzIjogWwogICAgewogICAgICAicGF0aCI6ICJmZWVkcy9zMTItN2VmZGRkZjM0ZmJmNThmZmEwYmY4YzRmN2ZjYjFhOWFkMmJhYzg2OWNiM2YwMDNjZWEwYTBjOWM1MzM1NmM4OC9sYXRlc3QuanNvbiIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMTdcXHVwZGF0ZXJcXGZlZWRcXGxhdGVzdC5qc29uIiwKICAgICAgInNpemUiOiAxMTU5LAogICAgICAic2hhMjU2IjogIjdlZmRkZGYzNGZiZjU4ZmZhMGJmOGM0ZjdmY2IxYTlhZDJiYWM4NjljYjNmMDAzY2VhMGEwYzljNTMzNTZjODgiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJmZWVkcy9zMTItN2VmZGRkZjM0ZmJmNThmZmEwYmY4YzRmN2ZjYjFhOWFkMmJhYzg2OWNiM2YwMDNjZWEwYTBjOWM1MzM1NmM4OC9sYXRlc3QucDdzIiwKICAgICAgInNvdXJjZSI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxN1xcdXBkYXRlclxcZmVlZFxcbGF0ZXN0LnA3cyIsCiAgICAgICJzaXplIjogMTYxNCwKICAgICAgInNoYTI1NiI6ICI3ZGQxMzFkZGRjZWY5MTA3ZWEwYzgwMzYzY2M5Y2E0NDc0NjYwM2M1ODZhMWUyM2UwMGZmNmFhMTc4MDA2OTE2IgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAiaW5zdGFsbGVycy9hY2VkNWU1M2E1N2MwZTk4MDgxZjg0MTVjNWViZmI5NTk0MmJlN2IzY2JiMTMwNDkwZGIyNGU1ZjhkYzE1NjIxL01pcjJTZXR1cC5leGUiLAogICAgICAic291cmNlIjogIkM6XFxtaXIyLXBsYXl0ZXN0LXJlbGVhc2VzXFwyMDI2MTAwNC1uYXRpdmUtcjE3XFxib290c3RyYXAtMDFcXGFydGlmYWN0c1xcTnVtZXJvbi1MZWdlbmQtb2YtUmViaXJ0aC0yMDI2MTAwNC1yMTctQm9vdHN0cmFwLmV4ZSIsCiAgICAgICJzaXplIjogMjc0ODIzODgsCiAgICAgICJzaGEyNTYiOiAiYWNlZDVlNTNhNTdjMGU5ODA4MWY4NDE1YzVlYmZiOTU5NDJiZTdiM2NiYjEzMDQ5MGRiMjRlNWY4ZGMxNTYyMSIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvQlVJTEQtQVRURVNUQVRJT04uanNvbiIsCiAgICAgICJzb3VyY2UiOiAiQzpcXFVzZXJzXFxBZG1pbmlzdHJhdG9yXFwuY29kZXhcXHdvcmt0cmVlc1xccjE3XFxtaXIyLXBsYXllci1qb3VybmV5XFxtaXIyLXdlYjNcXGRpc3RcXHIxN1xcQlVJTEQtQVRURVNUQVRJT04uanNvbiIsCiAgICAgICJzaXplIjogMTQ5MywKICAgICAgInNoYTI1NiI6ICI3YjM2MGZlZDFmYTZiMDZlOGNkZjJhMjkyNjU2ZTEzNjU3ZjhmYWUzYmI3NTc3YTYxNTkwZTYxNDllYzFkNmY1IgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9DT05UUk9MUy50eHQiLAogICAgICAic291cmNlIjogIkM6XFxVc2Vyc1xcQWRtaW5pc3RyYXRvclxcLmNvZGV4XFx3b3JrdHJlZXNcXHIxN1xcbWlyMi1wbGF5ZXItam91cm5leVxcbWlyMi13ZWIzXFxkaXN0XFxyMTdcXENPTlRST0xTLnR4dCIsCiAgICAgICJzaXplIjogMTA2MTIsCiAgICAgICJzaGEyNTYiOiAiYjlhZDJhNWEwMWIzZWNiZTY3M2EzZDM4YjE5NzRiMzg0OTJkM2E2MmEwZTI4OTMyZWI4MzY3Y2UxOWViZjdjNiIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvREVMSVZFUlkuanNvbiIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMThcXHIxNy1kb3dubG9hZC1hY2NlbGVyYXRpb24tMDJcXERFTElWRVJZLmpzb24iLAogICAgICAic2l6ZSI6IDcyNzIzMzcsCiAgICAgICJzaGEyNTYiOiAiYTcyYjYxNDQ4YjM0MjY1NmRkYTQzMTBjZWI3YmE1YWZmNjYwODQzOTAyNTc3NWZkZTJhODMwM2Y2YWQ2MmRlOCIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvREVMSVZFUlkucDdzIiwKICAgICAgInNvdXJjZSI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxOFxccjE3LWRvd25sb2FkLWFjY2VsZXJhdGlvbi0wMlxcREVMSVZFUlkucDdzIiwKICAgICAgInNpemUiOiAxNjE0LAogICAgICAic2hhMjU2IjogImMzZjI0NWNiZmY3YTJlNDU0NWQxNzIzY2Y1NmQwNDk4YjU4ZDdhZjYzNjAzMTJkNTMyNTNkMjU1ZDYwZWViOTMiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L0tOT1dOLUlTU1VFUy5tZCIsCiAgICAgICJzb3VyY2UiOiAiQzpcXFVzZXJzXFxBZG1pbmlzdHJhdG9yXFwuY29kZXhcXHdvcmt0cmVlc1xccjE3XFxtaXIyLXBsYXllci1qb3VybmV5XFxtaXIyLXdlYjNcXGRpc3RcXHIxN1xcS05PV04tSVNTVUVTLm1kIiwKICAgICAgInNpemUiOiAyMTUyLAogICAgICAic2hhMjU2IjogImQyYTJmZmNhMWQyMTcwZWUwYTBmMmUzZDNmZGYwZWZmNjQ0ZjJmZTQ0NzJjNWJhN2U2MTIwY2UxMmM0ZWFkYzkiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L01VTFRJTElOR1VBTC1TT1VSQ0VTLmpzb24iLAogICAgICAic291cmNlIjogIkM6XFxVc2Vyc1xcQWRtaW5pc3RyYXRvclxcLmNvZGV4XFx3b3JrdHJlZXNcXHIxN1xcbWlyMi1wbGF5ZXItam91cm5leVxcbWlyMi13ZWIzXFxkaXN0XFxyMTdcXE1VTFRJTElOR1VBTC1TT1VSQ0VTLmpzb24iLAogICAgICAic2l6ZSI6IDg2MTgsCiAgICAgICJzaGEyNTYiOiAiMTUyOGI2MTRkZWRiMDc4NjBlMjJhYzJlMWNmNjI1MjhiMGVkMTI2MjMwNjU3ZGMwMDhmYjg4ZDJmMDFmNmQxMSIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvTm90b1NhbnNUQy1PRkwudHh0IiwKICAgICAgInNvdXJjZSI6ICJDOlxcVXNlcnNcXEFkbWluaXN0cmF0b3JcXC5jb2RleFxcd29ya3RyZWVzXFxyMTdcXG1pcjItcGxheWVyLWpvdXJuZXlcXG1pcjItd2ViM1xcZGlzdFxccjE3XFxOb3RvU2Fuc1RDLU9GTC50eHQiLAogICAgICAic2l6ZSI6IDQ0ODEsCiAgICAgICJzaGEyNTYiOiAiZTM1ZmZkZWJiMjIyNWI0OTgxNGMzMTg4OWNiYjNjZTY5Y2IzNTA5ZTZhOWY0MzFlZGFiYTVlMWE2ZGU4Y2QxNSIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvT0ZMLU5vdG9TYW5zLnR4dCIsCiAgICAgICJzb3VyY2UiOiAiQzpcXFVzZXJzXFxBZG1pbmlzdHJhdG9yXFwuY29kZXhcXHdvcmt0cmVlc1xccjE3XFxtaXIyLXBsYXllci1qb3VybmV5XFxtaXIyLXdlYjNcXGRpc3RcXHIxN1xcT0ZMLU5vdG9TYW5zLnR4dCIsCiAgICAgICJzaXplIjogNDM5NiwKICAgICAgInNoYTI1NiI6ICJjZWU5ODkyZjlmMGNjOGZlODgyYzllOTUzN2VlNmE4OTYyMWQ4NmVlN2NlYWY3MGIwMmUyYjJiMWMyNWMwNjFhIgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9PRkwtTm90b1NhbnNBcmFiaWMudHh0IiwKICAgICAgInNvdXJjZSI6ICJDOlxcVXNlcnNcXEFkbWluaXN0cmF0b3JcXC5jb2RleFxcd29ya3RyZWVzXFxyMTdcXG1pcjItcGxheWVyLWpvdXJuZXlcXG1pcjItd2ViM1xcZGlzdFxccjE3XFxPRkwtTm90b1NhbnNBcmFiaWMudHh0IiwKICAgICAgInNpemUiOiA0MzgyLAogICAgICAic2hhMjU2IjogImE3YTVhMjVlYjE4OGJmMWNkOTY5ODIwMzBkNTNlMjNjMzM0ODVjNjliMTA0NGE1NjIyNTQyMjY4NTdlZTEzYWYiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L09GTC1Ob3RvU2Fuc0RldmFuYWdhcmkudHh0IiwKICAgICAgInNvdXJjZSI6ICJDOlxcVXNlcnNcXEFkbWluaXN0cmF0b3JcXC5jb2RleFxcd29ya3RyZWVzXFxyMTdcXG1pcjItcGxheWVyLWpvdXJuZXlcXG1pcjItd2ViM1xcZGlzdFxccjE3XFxPRkwtTm90b1NhbnNEZXZhbmFnYXJpLnR4dCIsCiAgICAgICJzaXplIjogNDM4NiwKICAgICAgInNoYTI1NiI6ICJhMjE2ZjZmOGQ4NWM3MjI4MDkzZTBlZTVlMjU4ZDlkMzc3ZTY2NzFmNjhhY2I0ZGIxOTMwYjI5NTgzZDBmMzMxIgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9PRkwtTm90b1NhbnNUaGFpLnR4dCIsCiAgICAgICJzb3VyY2UiOiAiQzpcXFVzZXJzXFxBZG1pbmlzdHJhdG9yXFwuY29kZXhcXHdvcmt0cmVlc1xccjE3XFxtaXIyLXBsYXllci1qb3VybmV5XFxtaXIyLXdlYjNcXGRpc3RcXHIxN1xcT0ZMLU5vdG9TYW5zVGhhaS50eHQiLAogICAgICAic2l6ZSI6IDQzODAsCiAgICAgICJzaGEyNTYiOiAiZGFkNmU2YWJjMmJmM2ZjMzdjYzY5OGFmNzYwN2MzZjRkNDIzNTAzOTY5NTcxM2IyMjJlNWEwMzRmYjViOWIxYyIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvUEFDS0FHRS1NQU5JRkVTVC5qc29uIiwKICAgICAgInNvdXJjZSI6ICJDOlxcVXNlcnNcXEFkbWluaXN0cmF0b3JcXC5jb2RleFxcd29ya3RyZWVzXFxyMTdcXG1pcjItcGxheWVyLWpvdXJuZXlcXG1pcjItd2ViM1xcZGlzdFxccjE3XFxQQUNLQUdFLU1BTklGRVNULmpzb24iLAogICAgICAic2l6ZSI6IDI0MzYwMTc0LAogICAgICAic2hhMjU2IjogImNlYWUzNjZiZWJjYTFjMTljM2Y1MjllYjIyZjAxNmNjYzgwZGZmNWI4NjU1Njk0ZTc2NjgyZTMxYWIxMmNiMTgiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L1JFQURNRS1TVEFSVC50eHQiLAogICAgICAic291cmNlIjogIkM6XFxVc2Vyc1xcQWRtaW5pc3RyYXRvclxcLmNvZGV4XFx3b3JrdHJlZXNcXHIxN1xcbWlyMi1wbGF5ZXItam91cm5leVxcbWlyMi13ZWIzXFxkaXN0XFxyMTdcXFJFQURNRS1TVEFSVC50eHQiLAogICAgICAic2l6ZSI6IDQ5MzI4LAogICAgICAic2hhMjU2IjogImJkZWM5NjNiZDM4ZDcwYTYwMmYzNDk1ZjE2MTFhOGYzYTIwM2U3OGVlNzc2OTBlYzc3YzYxNjFlYjBkN2QyYmYiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L1JFTEVBU0UtU1RBVEVNRU5ULmpzb24iLAogICAgICAic291cmNlIjogIkM6XFxVc2Vyc1xcQWRtaW5pc3RyYXRvclxcLmNvZGV4XFx3b3JrdHJlZXNcXHIxN1xcbWlyMi1wbGF5ZXItam91cm5leVxcbWlyMi13ZWIzXFxkaXN0XFxyMTdcXFJFTEVBU0UtU1RBVEVNRU5ULmpzb24iLAogICAgICAic2l6ZSI6IDcwNywKICAgICAgInNoYTI1NiI6ICJlNjRhOGVmNGZjNjJlNmU5ZjZmZTE2NjI1MzIxZmM4YTg4YTBjOGMyOWE2NjFhZWRhNDYwMjViMDgwMTVkYTgyIgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9SRUxFQVNFLVNUQVRFTUVOVC5wN3MiLAogICAgICAic291cmNlIjogIkM6XFxVc2Vyc1xcQWRtaW5pc3RyYXRvclxcLmNvZGV4XFx3b3JrdHJlZXNcXHIxN1xcbWlyMi1wbGF5ZXItam91cm5leVxcbWlyMi13ZWIzXFxkaXN0XFxyMTdcXFJFTEVBU0UtU1RBVEVNRU5ULnA3cyIsCiAgICAgICJzaXplIjogMTYxNCwKICAgICAgInNoYTI1NiI6ICJiZWU4NGI1NzRmNDNmNjQxMWViMWJjM2FiMjNhM2NlMGMzODliODUzZmIwZjhiNjNmNmFkOWJkYjEyODc4NTZlIgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9WRVJTSU9OLmpzb24iLAogICAgICAic291cmNlIjogIkM6XFxVc2Vyc1xcQWRtaW5pc3RyYXRvclxcLmNvZGV4XFx3b3JrdHJlZXNcXHIxN1xcbWlyMi1wbGF5ZXItam91cm5leVxcbWlyMi13ZWIzXFxkaXN0XFxyMTdcXFZFUlNJT04uanNvbiIsCiAgICAgICJzaXplIjogMTIyMSwKICAgICAgInNoYTI1NiI6ICIxNDA5ZTIxYzlmMWFlN2EwNGI3MTYwM2NlMTIyMGZlMzhjMzdmMjIyZDU0ODU5YWYyNTkyY2RkNzJjZTk5YjE2IgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9kZWxpdmVyeS8wYTY4NWFkOGQzOGU1YmI4NmRiNGFmZjA2MWE4ODQ0MDhlYTM5MGE3NDE3MDAzMGU3N2NhZDcwNTk1MDlkOGIwLm0yYi5neiIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMThcXHIxNy1kb3dubG9hZC1hY2NlbGVyYXRpb24tMDJcXGRlbGl2ZXJ5XFwwYTY4NWFkOGQzOGU1YmI4NmRiNGFmZjA2MWE4ODQ0MDhlYTM5MGE3NDE3MDAzMGU3N2NhZDcwNTk1MDlkOGIwLm0yYi5neiIsCiAgICAgICJzaXplIjogNjA2MjkxMjksCiAgICAgICJzaGEyNTYiOiAiMGE2ODVhZDhkMzhlNWJiODZkYjRhZmYwNjFhODg0NDA4ZWEzOTBhNzQxNzAwMzBlNzdjYWQ3MDU5NTA5ZDhiMCIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvZGVsaXZlcnkvMTEyZDFmNzdhMjBkMGRhNTFmNjJiY2JjNDg4ODI3NTMwZjViODU0ZjkxZjdkNDIzZDEwMWNhZWRiMDEwOWVjYy5tMmIuZ3oiLAogICAgICAic291cmNlIjogIkM6XFxtaXIyLXBsYXl0ZXN0LXJlbGVhc2VzXFwyMDI2MTAwNC1uYXRpdmUtcjE4XFxyMTctZG93bmxvYWQtYWNjZWxlcmF0aW9uLTAyXFxkZWxpdmVyeVxcMTEyZDFmNzdhMjBkMGRhNTFmNjJiY2JjNDg4ODI3NTMwZjViODU0ZjkxZjdkNDIzZDEwMWNhZWRiMDEwOWVjYy5tMmIuZ3oiLAogICAgICAic2l6ZSI6IDU4MDU0ODY0LAogICAgICAic2hhMjU2IjogIjExMmQxZjc3YTIwZDBkYTUxZjYyYmNiYzQ4ODgyNzUzMGY1Yjg1NGY5MWY3ZDQyM2QxMDFjYWVkYjAxMDllY2MiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L2RlbGl2ZXJ5LzFlNDA1MmFhM2YxNThhOThiOGQzMzMwNmRkYTM2ZTc4ODY2MmVhNThlNjI1YmI3YzFmN2E4ZTdjYTMxNTNiM2UubTJiLmd6IiwKICAgICAgInNvdXJjZSI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxOFxccjE3LWRvd25sb2FkLWFjY2VsZXJhdGlvbi0wMlxcZGVsaXZlcnlcXDFlNDA1MmFhM2YxNThhOThiOGQzMzMwNmRkYTM2ZTc4ODY2MmVhNThlNjI1YmI3YzFmN2E4ZTdjYTMxNTNiM2UubTJiLmd6IiwKICAgICAgInNpemUiOiA1ODA5NDU1OSwKICAgICAgInNoYTI1NiI6ICIxZTQwNTJhYTNmMTU4YTk4YjhkMzMzMDZkZGEzNmU3ODg2NjJlYTU4ZTYyNWJiN2MxZjdhOGU3Y2EzMTUzYjNlIgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9kZWxpdmVyeS8yNWZlZDZiZGI1YmJhMjRjNjUxYjkwZWJhYmUwODA1ZGNiZDE0MjkxNDlkNjEyNDFhNGQ3YTBjYTQ4YmI4MDU5Lm0yYi5neiIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMThcXHIxNy1kb3dubG9hZC1hY2NlbGVyYXRpb24tMDJcXGRlbGl2ZXJ5XFwyNWZlZDZiZGI1YmJhMjRjNjUxYjkwZWJhYmUwODA1ZGNiZDE0MjkxNDlkNjEyNDFhNGQ3YTBjYTQ4YmI4MDU5Lm0yYi5neiIsCiAgICAgICJzaXplIjogNDIwOTUyMjcsCiAgICAgICJzaGEyNTYiOiAiMjVmZWQ2YmRiNWJiYTI0YzY1MWI5MGViYWJlMDgwNWRjYmQxNDI5MTQ5ZDYxMjQxYTRkN2EwY2E0OGJiODA1OSIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvZGVsaXZlcnkvM2U4YjE5ZGZkMDhmOTRhYTdlYWM0NmVmODgwMDFkMTk5YjZlNmJlMWJhM2Y5MzgyYmUyZjlkMzliNWNmNmJiMy5tMmIuZ3oiLAogICAgICAic291cmNlIjogIkM6XFxtaXIyLXBsYXl0ZXN0LXJlbGVhc2VzXFwyMDI2MTAwNC1uYXRpdmUtcjE4XFxyMTctZG93bmxvYWQtYWNjZWxlcmF0aW9uLTAyXFxkZWxpdmVyeVxcM2U4YjE5ZGZkMDhmOTRhYTdlYWM0NmVmODgwMDFkMTk5YjZlNmJlMWJhM2Y5MzgyYmUyZjlkMzliNWNmNmJiMy5tMmIuZ3oiLAogICAgICAic2l6ZSI6IDYzMzUzODUxLAogICAgICAic2hhMjU2IjogIjNlOGIxOWRmZDA4Zjk0YWE3ZWFjNDZlZjg4MDAxZDE5OWI2ZTZiZTFiYTNmOTM4MmJlMmY5ZDM5YjVjZjZiYjMiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L2RlbGl2ZXJ5LzNmZjQxYTBlNjlhNThmYWFlYTViMTMyN2FjNTkwMDA3OWEwNDM2MDdkOTQ5OTlmZmMxOGVkMzEyYmQ3ZjY5NDUubTJiLmd6IiwKICAgICAgInNvdXJjZSI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxOFxccjE3LWRvd25sb2FkLWFjY2VsZXJhdGlvbi0wMlxcZGVsaXZlcnlcXDNmZjQxYTBlNjlhNThmYWFlYTViMTMyN2FjNTkwMDA3OWEwNDM2MDdkOTQ5OTlmZmMxOGVkMzEyYmQ3ZjY5NDUubTJiLmd6IiwKICAgICAgInNpemUiOiA2NTUxNTE5OCwKICAgICAgInNoYTI1NiI6ICIzZmY0MWEwZTY5YTU4ZmFhZWE1YjEzMjdhYzU5MDAwNzlhMDQzNjA3ZDk0OTk5ZmZjMThlZDMxMmJkN2Y2OTQ1IgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9kZWxpdmVyeS81NjdkZmFlODVjYzdlNzI2ZTk5ZGZlNzRmN2M5YjZhM2UxYWI4NjhmNmM2NzI3ZjUxNTNhMWQ1YWJlYWM5MmMxLm0yYi5neiIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMThcXHIxNy1kb3dubG9hZC1hY2NlbGVyYXRpb24tMDJcXGRlbGl2ZXJ5XFw1NjdkZmFlODVjYzdlNzI2ZTk5ZGZlNzRmN2M5YjZhM2UxYWI4NjhmNmM2NzI3ZjUxNTNhMWQ1YWJlYWM5MmMxLm0yYi5neiIsCiAgICAgICJzaXplIjogNjU5NDUzMTksCiAgICAgICJzaGEyNTYiOiAiNTY3ZGZhZTg1Y2M3ZTcyNmU5OWRmZTc0ZjdjOWI2YTNlMWFiODY4ZjZjNjcyN2Y1MTUzYTFkNWFiZWFjOTJjMSIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvZGVsaXZlcnkvNzkyZGI3NWUyMmU0ZDkwNjZmMjUyOWMzZjExNzY1NWMwZWM3OTRlYjQ3YjQzMWI0OWZiYTZjNzg3NjBmMDUyZS5tMmIuZ3oiLAogICAgICAic291cmNlIjogIkM6XFxtaXIyLXBsYXl0ZXN0LXJlbGVhc2VzXFwyMDI2MTAwNC1uYXRpdmUtcjE4XFxyMTctZG93bmxvYWQtYWNjZWxlcmF0aW9uLTAyXFxkZWxpdmVyeVxcNzkyZGI3NWUyMmU0ZDkwNjZmMjUyOWMzZjExNzY1NWMwZWM3OTRlYjQ3YjQzMWI0OWZiYTZjNzg3NjBmMDUyZS5tMmIuZ3oiLAogICAgICAic2l6ZSI6IDU5NDY5NTE0LAogICAgICAic2hhMjU2IjogIjc5MmRiNzVlMjJlNGQ5MDY2ZjI1MjljM2YxMTc2NTVjMGVjNzk0ZWI0N2I0MzFiNDlmYmE2Yzc4NzYwZjA1MmUiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L2RlbGl2ZXJ5L2FjNGQxNTg0Mjg4NmE0OTZmMDkzZDU4NWUwMmY5YWRjYzZjM2NmM2NjM2M3NjNhMzAyMWIwYzU2ZTAxNDMxZTMubTJiLmd6IiwKICAgICAgInNvdXJjZSI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxOFxccjE3LWRvd25sb2FkLWFjY2VsZXJhdGlvbi0wMlxcZGVsaXZlcnlcXGFjNGQxNTg0Mjg4NmE0OTZmMDkzZDU4NWUwMmY5YWRjYzZjM2NmM2NjM2M3NjNhMzAyMWIwYzU2ZTAxNDMxZTMubTJiLmd6IiwKICAgICAgInNpemUiOiA0OTkzNDgyMiwKICAgICAgInNoYTI1NiI6ICJhYzRkMTU4NDI4ODZhNDk2ZjA5M2Q1ODVlMDJmOWFkY2M2YzNjZjNjYzNjNzYzYTMwMjFiMGM1NmUwMTQzMWUzIgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9kZWxpdmVyeS9kNTI4YzcxNDk5NTM3NjhlZDI1Yjc3ZjVkYTVkODRhNGY1MTRlZTdhYjFlN2I4YzE2ODRjYWIyNWUxODIzYTYzLm0yZC5neiIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMThcXHIxNy1kb3dubG9hZC1hY2NlbGVyYXRpb24tMDJcXGRlbGl2ZXJ5XFxkNTI4YzcxNDk5NTM3NjhlZDI1Yjc3ZjVkYTVkODRhNGY1MTRlZTdhYjFlN2I4YzE2ODRjYWIyNWUxODIzYTYzLm0yZC5neiIsCiAgICAgICJzaXplIjogMjU0MjQxNjksCiAgICAgICJzaGEyNTYiOiAiZDUyOGM3MTQ5OTUzNzY4ZWQyNWI3N2Y1ZGE1ZDg0YTRmNTE0ZWU3YWIxZTdiOGMxNjg0Y2FiMjVlMTgyM2E2MyIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvZGVsaXZlcnkvZjE3NmQ1ZGJhNzEzZDhiZDliZTBkZTk0YjdhN2ZlMWZlYzQ4NDkzMDQ5YTAyMThjMmJhYTE0NGQzMzEyZDBiNS5tMmIuZ3oiLAogICAgICAic291cmNlIjogIkM6XFxtaXIyLXBsYXl0ZXN0LXJlbGVhc2VzXFwyMDI2MTAwNC1uYXRpdmUtcjE4XFxyMTctZG93bmxvYWQtYWNjZWxlcmF0aW9uLTAyXFxkZWxpdmVyeVxcZjE3NmQ1ZGJhNzEzZDhiZDliZTBkZTk0YjdhN2ZlMWZlYzQ4NDkzMDQ5YTAyMThjMmJhYTE0NGQzMzEyZDBiNS5tMmIuZ3oiLAogICAgICAic2l6ZSI6IDM2MjQzNzkzLAogICAgICAic2hhMjU2IjogImYxNzZkNWRiYTcxM2Q4YmQ5YmUwZGU5NGI3YTdmZTFmZWM0ODQ5MzA0OWEwMjE4YzJiYWExNDRkMzMxMmQwYjUiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy9nYW1lLVdOLUNBTkRJREFURS0yMDI2MTAwNC1pbnZpdGVkLTE3L2RlbGl2ZXJ5L2Y3ZDg5ZGU5OWUzYmMzZjU2NWM1OGU0NzEzODcwZDc4ZDliNDQ2YmZlZTk2NTFkMzBiYTlkN2M1NTlhNzNjZmUubTJiLmd6IiwKICAgICAgInNvdXJjZSI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxOFxccjE3LWRvd25sb2FkLWFjY2VsZXJhdGlvbi0wMlxcZGVsaXZlcnlcXGY3ZDg5ZGU5OWUzYmMzZjU2NWM1OGU0NzEzODcwZDc4ZDliNDQ2YmZlZTk2NTFkMzBiYTlkN2M1NTlhNzNjZmUubTJiLmd6IiwKICAgICAgInNpemUiOiA2MDg1MzI5NywKICAgICAgInNoYTI1NiI6ICJmN2Q4OWRlOTllM2JjM2Y1NjVjNThlNDcxMzg3MGQ3OGQ5YjQ0NmJmZWU5NjUxZDMwYmE5ZDdjNTU5YTczY2ZlIgogICAgfSwKICAgIHsKICAgICAgInBhdGgiOiAicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNy9taXIyLWNsaWVudC50b21sIiwKICAgICAgInNvdXJjZSI6ICJDOlxcVXNlcnNcXEFkbWluaXN0cmF0b3JcXC5jb2RleFxcd29ya3RyZWVzXFxyMTdcXG1pcjItcGxheWVyLWpvdXJuZXlcXG1pcjItd2ViM1xcZGlzdFxccjE3XFxtaXIyLWNsaWVudC50b21sIiwKICAgICAgInNpemUiOiAyMzEsCiAgICAgICJzaGEyNTYiOiAiNThhNWE3Y2YyZWQ2ZTg4MGE3YTdmMjU5MjQzZGQ5YWI5NjE1MGZjNDNlMWEzNDZlNmZjNzliOGRlNmVlMzY0MSIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL2dhbWUtV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTcvbWlyMi1wbGF0Zm9ybS13aW5kb3dzLmV4ZSIsCiAgICAgICJzb3VyY2UiOiAiQzpcXFVzZXJzXFxBZG1pbmlzdHJhdG9yXFwuY29kZXhcXHdvcmt0cmVlc1xccjE3XFxtaXIyLXBsYXllci1qb3VybmV5XFxtaXIyLXdlYjNcXGRpc3RcXHIxN1xcbWlyMi1wbGF0Zm9ybS13aW5kb3dzLmV4ZSIsCiAgICAgICJzaXplIjogMTExMDEzMzc2LAogICAgICAic2hhMjU2IjogImQwNzgwNDc1ZWZhOWY5YzFlY2Q3MzBkZmNmYzExZTM4YjliMDY1OWYwNWIzYjFmN2Q5M2I0ZjgwYzNkNzM0ZTAiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy91cGRhdGVyLUZCMzUwNUQ2RDg0RDk5N0MtczEyL0VOR0lORS5qc29uIiwKICAgICAgInNvdXJjZSI6ICJDOlxcbWlyMi1wbGF5dGVzdC1yZWxlYXNlc1xcMjAyNjEwMDQtbmF0aXZlLXIxN1xcdXBkYXRlclxcZW5naW5lLXJlbGVhc2VcXEVOR0lORS5qc29uIiwKICAgICAgInNpemUiOiA0MjEsCiAgICAgICJzaGEyNTYiOiAiMzE0NjE2OWZjNjE3NmE1ZWFlYTQyYmFhYTA0MzBlMzQ1ZjViN2U2MTQ3MDk5NzFhMDBiMGQ3ZDBjNDczMmJjZiIKICAgIH0sCiAgICB7CiAgICAgICJwYXRoIjogInJlbGVhc2VzL3VwZGF0ZXItRkIzNTA1RDZEODREOTk3Qy1zMTIvRU5HSU5FLnA3cyIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMTdcXHVwZGF0ZXJcXGVuZ2luZS1yZWxlYXNlXFxFTkdJTkUucDdzIiwKICAgICAgInNpemUiOiAxNjE0LAogICAgICAic2hhMjU2IjogIjcwZGMyZGMxMWMzMTA1ZmQ0ZGQyYjgwYmQ3ZjlmYjMwZjdhN2Y0YjNiYmJmZTJhYTEzOTdjMDM4YzliM2MxNGEiCiAgICB9LAogICAgewogICAgICAicGF0aCI6ICJyZWxlYXNlcy91cGRhdGVyLUZCMzUwNUQ2RDg0RDk5N0MtczEyL01pcjJVcGRhdGVyLmV4ZSIsCiAgICAgICJzb3VyY2UiOiAiQzpcXG1pcjItcGxheXRlc3QtcmVsZWFzZXNcXDIwMjYxMDA0LW5hdGl2ZS1yMTdcXHVwZGF0ZXJcXGVuZ2luZS1yZWxlYXNlXFxNaXIyVXBkYXRlci5leGUiLAogICAgICAic2l6ZSI6IDE4MTE0NTYsCiAgICAgICJzaGEyNTYiOiAiZmIzNTA1ZDZkODRkOTk3Y2RiY2VmMTdmOTg2YTM5YjkzMGMzZmNlNWQxMDhjYTk4MzFkOTBjNWY2OWIxNjczNCIKICAgIH0KICBdCn0K",
  rootVerificationSha256: "6b36134597180ad2b423c2015c05b3c48447fbd766e858c2fb0ce6f45e2565b9",
  rootVerificationBase64: "eyJzY2hlbWEiOiJtaXIyLndpbmRvd3MucjItdmVyaWZpY2F0aW9uLnYxIiwicGFzc2VkIjp0cnVlLCJjYW5kaWRhdGVWZXJpZmllZCI6dHJ1ZSwiY21zVmVyaWZpZWQiOnRydWUsInNvdXJjZVJldmlzaW9uIjoiNGM2MGMzMjNhZWQxMTgyOWFiYWU2ZWU1Y2U2ZTEzYzY3NWEzYzFjMyIsInNlcXVlbmNlIjoxMiwiZmVlZFNoYTI1NiI6IjdlZmRkZGYzNGZiZjU4ZmZhMGJmOGM0ZjdmY2IxYTlhZDJiYWM4NjljYjNmMDAzY2VhMGEwYzljNTMzNTZjODgiLCJzaWduYXR1cmVTaGEyNTYiOiI3ZGQxMzFkZGRjZWY5MTA3ZWEwYzgwMzYzY2M5Y2E0NDc0NjYwM2M1ODZhMWUyM2UwMGZmNmFhMTc4MDA2OTE2Iiwib2JqZWN0c1NoYTI1NiI6ImYzOGE2OTJhNGJhMjAwMTc3ZjQzNThjOWYzZDE1NjZmOTdmYWRiMzJjZjQwOGMwNzJjYjFmOGI4YmIwM2Q0ZjAifQ==",
  objectsSha256: "f38a692a4ba200177f4358c9f3d1566f97fadb32cf408c072cb1f8b8bb03d4f0",
  candidate: {
    schema: "mir2.windows.r2-channel.v1",
    channel: "invited",
    platform: "windows-x64",
    sequence: 12,
    sourceRevision: "4c60c323aed11829abae6ee5ce6e13c675a3c1c3",
    feedSha256: "7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88",
    signatureSha256: "7dd131dddcef9107ea0c80363cc9ca44746603c586a1e23e00ff6aa178006916"
  },
  expectedCurrent: null,
  installerOriginEvidence: {
    originalEvidencePath: "C:/mir2-playtest-releases/20261004-native-r18/origin-acceleration-implementation-01/post-publication-02.json",
    originalEvidenceSha256: "3073dde253de821c21c541655916e7f84903dc0c8a0eaa2a6219281251de8b36",
    selectedMapping: {
      device: 64769,
      inode: 1143484,
      mode: "0o644",
      mtimeNs: "1791083348967340952",
      nlink: 1,
      path: "/srv/mir2-client-updates/releases/bootstrap-WN-CANDIDATE-20261004-invited-17/Numeron-Legend-of-Rebirth-20261004-r17-Bootstrap.exe",
      sha256: "aced5e53a57c0e98081f8415c5ebfb95942be7b3cbb130490db24e5f8dc15621",
      size: 27482388,
      uid: 0
    },
    noLiveCheckThisWorker: true
  },
  objects: [
    {
      path: "feeds/s12-7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88/latest.json",
      size: 1159,
      sha256: "7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88",
      index: 0,
      r2Key: "mir2/native/windows-invited/feeds/s12-7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88/latest.json",
      originRelativePath: "latest.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "feeds/s12-7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88/latest.p7s",
      size: 1614,
      sha256: "7dd131dddcef9107ea0c80363cc9ca44746603c586a1e23e00ff6aa178006916",
      index: 1,
      r2Key: "mir2/native/windows-invited/feeds/s12-7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88/latest.p7s",
      originRelativePath: "latest.p7s",
      contentType: "application/pkcs7-signature",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "installers/aced5e53a57c0e98081f8415c5ebfb95942be7b3cbb130490db24e5f8dc15621/Mir2Setup.exe",
      size: 27482388,
      sha256: "aced5e53a57c0e98081f8415c5ebfb95942be7b3cbb130490db24e5f8dc15621",
      index: 2,
      r2Key: "mir2/native/windows-invited/installers/aced5e53a57c0e98081f8415c5ebfb95942be7b3cbb130490db24e5f8dc15621/Mir2Setup.exe",
      originRelativePath: "releases/bootstrap-WN-CANDIDATE-20261004-invited-17/Numeron-Legend-of-Rebirth-20261004-r17-Bootstrap.exe",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/BUILD-ATTESTATION.json",
      size: 1493,
      sha256: "7b360fed1fa6b06e8cdf2a292656e13657f8fae3bb7577a61590e6149ec1d6f5",
      index: 3,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/BUILD-ATTESTATION.json",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/BUILD-ATTESTATION.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/CONTROLS.txt",
      size: 10612,
      sha256: "b9ad2a5a01b3ecbe673a3d38b1974b38492d3a62a0e28932eb8367ce19ebf7c6",
      index: 4,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/CONTROLS.txt",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/CONTROLS.txt",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/DELIVERY.json",
      size: 7272337,
      sha256: "a72b61448b342656dda4310ceb7ba5aff6608439025775fde2a8303f6ad62de8",
      index: 5,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/DELIVERY.json",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/DELIVERY.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/DELIVERY.p7s",
      size: 1614,
      sha256: "c3f245cbff7a2e4545d1723cf56d0498b58d7af6360312d53253d255d60eeb93",
      index: 6,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/DELIVERY.p7s",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/DELIVERY.p7s",
      contentType: "application/pkcs7-signature",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/KNOWN-ISSUES.md",
      size: 2152,
      sha256: "d2a2ffca1d2170ee0a0f2e3d3fdf0eff644f2fe4472c5ba7e6120ce12c4eadc9",
      index: 7,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/KNOWN-ISSUES.md",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/KNOWN-ISSUES.md",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/MULTILINGUAL-SOURCES.json",
      size: 8618,
      sha256: "1528b614dedb07860e22ac2e1cf62528b0ed126230657dc008fb88d2f01f6d11",
      index: 8,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/MULTILINGUAL-SOURCES.json",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/MULTILINGUAL-SOURCES.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/NotoSansTC-OFL.txt",
      size: 4481,
      sha256: "e35ffdebb2225b49814c31889cbb3ce69cb3509e6a9f431edaba5e1a6de8cd15",
      index: 9,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/NotoSansTC-OFL.txt",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/NotoSansTC-OFL.txt",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSans.txt",
      size: 4396,
      sha256: "cee9892f9f0cc8fe882c9e9537ee6a89621d86ee7ceaf70b02e2b2b1c25c061a",
      index: 10,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSans.txt",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSans.txt",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansArabic.txt",
      size: 4382,
      sha256: "a7a5a25eb188bf1cd96982030d53e23c33485c69b1044a562254226857ee13af",
      index: 11,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansArabic.txt",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansArabic.txt",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansDevanagari.txt",
      size: 4386,
      sha256: "a216f6f8d85c7228093e0ee5e258d9d377e6671f68acb4db1930b29583d0f331",
      index: 12,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansDevanagari.txt",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansDevanagari.txt",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansThai.txt",
      size: 4380,
      sha256: "dad6e6abc2bf3fc37cc698af7607c3f4d4235039695713b222e5a034fb5b9b1c",
      index: 13,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansThai.txt",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/OFL-NotoSansThai.txt",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/PACKAGE-MANIFEST.json",
      size: 24360174,
      sha256: "ceae366bebca1c19c3f529eb22f016ccc80dff5b8655694e76682e31ab12cb18",
      index: 14,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/PACKAGE-MANIFEST.json",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/PACKAGE-MANIFEST.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/README-START.txt",
      size: 49328,
      sha256: "bdec963bd38d70a602f3495f1611a8f3a203e78ee77690ec77c6161eb0d7d2bf",
      index: 15,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/README-START.txt",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/README-START.txt",
      contentType: "text/plain; charset=utf-8",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/RELEASE-STATEMENT.json",
      size: 707,
      sha256: "e64a8ef4fc62e6e9f6fe16625321fc8a88a0c8c29a661aeda46025b08015da82",
      index: 16,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/RELEASE-STATEMENT.json",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/RELEASE-STATEMENT.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/RELEASE-STATEMENT.p7s",
      size: 1614,
      sha256: "bee84b574f43f6411eb1bc3ab23a3ce0c389b853fb0f8b63f6ad9bdb1287856e",
      index: 17,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/RELEASE-STATEMENT.p7s",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/RELEASE-STATEMENT.p7s",
      contentType: "application/pkcs7-signature",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/VERSION.json",
      size: 1221,
      sha256: "1409e21c9f1ae7a04b71603ce1220fe38c37f222d54859af2592cdd72ce99b16",
      index: 18,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/VERSION.json",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/VERSION.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/0a685ad8d38e5bb86db4aff061a884408ea390a74170030e77cad7059509d8b0.m2b.gz",
      size: 60629129,
      sha256: "0a685ad8d38e5bb86db4aff061a884408ea390a74170030e77cad7059509d8b0",
      index: 19,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/0a685ad8d38e5bb86db4aff061a884408ea390a74170030e77cad7059509d8b0.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/0a685ad8d38e5bb86db4aff061a884408ea390a74170030e77cad7059509d8b0.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/112d1f77a20d0da51f62bcbc488827530f5b854f91f7d423d101caedb0109ecc.m2b.gz",
      size: 58054864,
      sha256: "112d1f77a20d0da51f62bcbc488827530f5b854f91f7d423d101caedb0109ecc",
      index: 20,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/112d1f77a20d0da51f62bcbc488827530f5b854f91f7d423d101caedb0109ecc.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/112d1f77a20d0da51f62bcbc488827530f5b854f91f7d423d101caedb0109ecc.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/1e4052aa3f158a98b8d33306dda36e788662ea58e625bb7c1f7a8e7ca3153b3e.m2b.gz",
      size: 58094559,
      sha256: "1e4052aa3f158a98b8d33306dda36e788662ea58e625bb7c1f7a8e7ca3153b3e",
      index: 21,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/1e4052aa3f158a98b8d33306dda36e788662ea58e625bb7c1f7a8e7ca3153b3e.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/1e4052aa3f158a98b8d33306dda36e788662ea58e625bb7c1f7a8e7ca3153b3e.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/25fed6bdb5bba24c651b90ebabe0805dcbd1429149d61241a4d7a0ca48bb8059.m2b.gz",
      size: 42095227,
      sha256: "25fed6bdb5bba24c651b90ebabe0805dcbd1429149d61241a4d7a0ca48bb8059",
      index: 22,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/25fed6bdb5bba24c651b90ebabe0805dcbd1429149d61241a4d7a0ca48bb8059.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/25fed6bdb5bba24c651b90ebabe0805dcbd1429149d61241a4d7a0ca48bb8059.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/3e8b19dfd08f94aa7eac46ef88001d199b6e6be1ba3f9382be2f9d39b5cf6bb3.m2b.gz",
      size: 63353851,
      sha256: "3e8b19dfd08f94aa7eac46ef88001d199b6e6be1ba3f9382be2f9d39b5cf6bb3",
      index: 23,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/3e8b19dfd08f94aa7eac46ef88001d199b6e6be1ba3f9382be2f9d39b5cf6bb3.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/3e8b19dfd08f94aa7eac46ef88001d199b6e6be1ba3f9382be2f9d39b5cf6bb3.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/3ff41a0e69a58faaea5b1327ac5900079a043607d94999ffc18ed312bd7f6945.m2b.gz",
      size: 65515198,
      sha256: "3ff41a0e69a58faaea5b1327ac5900079a043607d94999ffc18ed312bd7f6945",
      index: 24,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/3ff41a0e69a58faaea5b1327ac5900079a043607d94999ffc18ed312bd7f6945.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/3ff41a0e69a58faaea5b1327ac5900079a043607d94999ffc18ed312bd7f6945.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/567dfae85cc7e726e99dfe74f7c9b6a3e1ab868f6c6727f5153a1d5abeac92c1.m2b.gz",
      size: 65945319,
      sha256: "567dfae85cc7e726e99dfe74f7c9b6a3e1ab868f6c6727f5153a1d5abeac92c1",
      index: 25,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/567dfae85cc7e726e99dfe74f7c9b6a3e1ab868f6c6727f5153a1d5abeac92c1.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/567dfae85cc7e726e99dfe74f7c9b6a3e1ab868f6c6727f5153a1d5abeac92c1.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/792db75e22e4d9066f2529c3f117655c0ec794eb47b431b49fba6c78760f052e.m2b.gz",
      size: 59469514,
      sha256: "792db75e22e4d9066f2529c3f117655c0ec794eb47b431b49fba6c78760f052e",
      index: 26,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/792db75e22e4d9066f2529c3f117655c0ec794eb47b431b49fba6c78760f052e.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/792db75e22e4d9066f2529c3f117655c0ec794eb47b431b49fba6c78760f052e.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/ac4d15842886a496f093d585e02f9adcc6c3cf3cc3c763a3021b0c56e01431e3.m2b.gz",
      size: 49934822,
      sha256: "ac4d15842886a496f093d585e02f9adcc6c3cf3cc3c763a3021b0c56e01431e3",
      index: 27,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/ac4d15842886a496f093d585e02f9adcc6c3cf3cc3c763a3021b0c56e01431e3.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/ac4d15842886a496f093d585e02f9adcc6c3cf3cc3c763a3021b0c56e01431e3.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/d528c7149953768ed25b77f5da5d84a4f514ee7ab1e7b8c1684cab25e1823a63.m2d.gz",
      size: 25424169,
      sha256: "d528c7149953768ed25b77f5da5d84a4f514ee7ab1e7b8c1684cab25e1823a63",
      index: 28,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/d528c7149953768ed25b77f5da5d84a4f514ee7ab1e7b8c1684cab25e1823a63.m2d.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/d528c7149953768ed25b77f5da5d84a4f514ee7ab1e7b8c1684cab25e1823a63.m2d.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/f176d5dba713d8bd9be0de94b7a7fe1fec48493049a0218c2baa144d3312d0b5.m2b.gz",
      size: 36243793,
      sha256: "f176d5dba713d8bd9be0de94b7a7fe1fec48493049a0218c2baa144d3312d0b5",
      index: 29,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/f176d5dba713d8bd9be0de94b7a7fe1fec48493049a0218c2baa144d3312d0b5.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/f176d5dba713d8bd9be0de94b7a7fe1fec48493049a0218c2baa144d3312d0b5.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/f7d89de99e3bc3f565c58e4713870d78d9b446bfee9651d30ba9d7c559a73cfe.m2b.gz",
      size: 60853297,
      sha256: "f7d89de99e3bc3f565c58e4713870d78d9b446bfee9651d30ba9d7c559a73cfe",
      index: 30,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/delivery/f7d89de99e3bc3f565c58e4713870d78d9b446bfee9651d30ba9d7c559a73cfe.m2b.gz",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/delivery/f7d89de99e3bc3f565c58e4713870d78d9b446bfee9651d30ba9d7c559a73cfe.m2b.gz",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/mir2-client.toml",
      size: 231,
      sha256: "58a5a7cf2ed6e880a7a7f259243dd9ab96150fc43e1a346e6fc79b8de6ee3641",
      index: 31,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/mir2-client.toml",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/mir2-client.toml",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/game-WN-CANDIDATE-20261004-invited-17/mir2-platform-windows.exe",
      size: 111013376,
      sha256: "d0780475efa9f9c1ecd730dfcfc11e38b9b0659f05b3b1f7d93b4f80c3d734e0",
      index: 32,
      r2Key: "mir2/native/windows-invited/releases/game-WN-CANDIDATE-20261004-invited-17/mir2-platform-windows.exe",
      originRelativePath: "releases/game-WN-CANDIDATE-20261004-invited-17/mir2-platform-windows.exe",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/updater-FB3505D6D84D997C-s12/ENGINE.json",
      size: 421,
      sha256: "3146169fc6176a5eaea42baaa0430e345f5b7e614709971a00b0d7d0c4732bcf",
      index: 33,
      r2Key: "mir2/native/windows-invited/releases/updater-FB3505D6D84D997C-s12/ENGINE.json",
      originRelativePath: "releases/updater-FB3505D6D84D997C-s12/ENGINE.json",
      contentType: "application/json",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/updater-FB3505D6D84D997C-s12/ENGINE.p7s",
      size: 1614,
      sha256: "70dc2dc11c3105fd4dd2b80bd7f9fb30f7a7f4b3bbbfe2aa1397c038c9b3c14a",
      index: 34,
      r2Key: "mir2/native/windows-invited/releases/updater-FB3505D6D84D997C-s12/ENGINE.p7s",
      originRelativePath: "releases/updater-FB3505D6D84D997C-s12/ENGINE.p7s",
      contentType: "application/pkcs7-signature",
      cacheControl: "public, max-age=31536000, immutable"
    },
    {
      path: "releases/updater-FB3505D6D84D997C-s12/Mir2Updater.exe",
      size: 1811456,
      sha256: "fb3505d6d84d997cdbcef17f986a39b930c3fce5d108ca9831d90c5f69b16734",
      index: 35,
      r2Key: "mir2/native/windows-invited/releases/updater-FB3505D6D84D997C-s12/Mir2Updater.exe",
      originRelativePath: "releases/updater-FB3505D6D84D997C-s12/Mir2Updater.exe",
      contentType: "application/octet-stream",
      cacheControl: "public, max-age=31536000, immutable"
    }
  ]
};

// src/native-r17-publication.mjs
var NATIVE_PLAN_SHA256 = "1786ca53c2ef03e142419feefa3184070bfacd570c1b3a9495f79e3c50eb3929";
var STAGE_SCHEMA = "mir2.windows.r2-native-stage.v1";
var PREFIX = "/upload/native-r17";
var POINTER = "channels/invited.json";
var MAX_POINTER = 4096;
var MAX_IMPORT_REQUEST = 1024;
var MAX_STAGE_REQUEST = 65536;
var ORIGIN_TIMEOUT_MS = 12e4;
var ENCODER = new TextEncoder();
var SHA_PATTERN = /^[0-9a-f]{64}$/;
var ETAG_PATTERN = /^"[^"\x00-\x20\x7f]+"$/;
function freeze(value) {
  if (value && typeof value === "object") {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
freeze(native_r17_publication_plan_default);
var Fault = class extends Error {
  constructor(code, status = 400) {
    super(code);
    this.code = code;
    this.status = status;
  }
};
function requireValue(condition, code, status = 400) {
  if (!condition) throw new Fault(code, status);
}
function canonical(value) {
  function sort(item) {
    if (Array.isArray(item)) return item.map(sort);
    if (item && typeof item === "object") {
      return Object.fromEntries(Object.keys(item).sort().map((key) => [key, sort(item[key])]));
    }
    return item;
  }
  return JSON.stringify(sort(value)) + "\n";
}
function same(a, b) {
  return canonical(a) === canonical(b);
}
function exactKeys(value, fields, code) {
  requireValue(value && typeof value === "object" && !Array.isArray(value) && same(Object.keys(value).sort(), [...fields].sort()), code);
}
function hex(buffer) {
  requireValue(buffer instanceof ArrayBuffer || ArrayBuffer.isView(buffer), "invalid_stored_checksum", 409);
  const bytes = buffer instanceof ArrayBuffer ? new Uint8Array(buffer) : new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
  return [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function digest(bytes, cryptoApi) {
  return hex(await cryptoApi.subtle.digest("SHA-256", bytes));
}
function checksumBytes(value) {
  requireValue(SHA_PATTERN.test(value), "invalid_literal_checksum", 503);
  return Uint8Array.from(value.match(/../g), (pair) => Number.parseInt(pair, 16)).buffer;
}
function decodeBase64(value) {
  requireValue(typeof value === "string" && /^[A-Za-z0-9+/]*={0,2}$/.test(value), "invalid_frozen_proof", 503);
  return Uint8Array.from(atob(value), (char) => char.charCodeAt(0));
}
function closure(objects = native_r17_publication_plan_default.objects) {
  return objects.map(({ path, size, sha256 }) => ({ path, size, sha256 }));
}
async function validateNativePlan(candidate = native_r17_publication_plan_default, cryptoApi = globalThis.crypto) {
  requireValue(
    await digest(ENCODER.encode(canonical(candidate)), cryptoApi) === NATIVE_PLAN_SHA256,
    "native_plan_hash_mismatch",
    503
  );
  const originalBytes = decodeBase64(candidate.sourcePlanBase64);
  const rootBytes = decodeBase64(candidate.rootVerificationBase64);
  requireValue(
    await digest(originalBytes, cryptoApi) === candidate.sourcePlanSha256 && await digest(rootBytes, cryptoApi) === candidate.rootVerificationSha256,
    "frozen_proof_hash_mismatch",
    503
  );
  const original = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(originalBytes));
  const root = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(rootBytes));
  requireValue(
    original.schema === "mir2.windows.r2-publication.v1" && original.expectedCurrent === null && candidate.expectedCurrent === null && same(original.candidate, candidate.candidate) && original.verificationReceipt.sha256 === candidate.rootVerificationSha256,
    "frozen_plan_binding_mismatch",
    503
  );
  const originalClosure = closure([...original.objects].sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
  requireValue(
    candidate.objects.length === 36 && same(originalClosure, closure(candidate.objects)) && await digest(ENCODER.encode(canonical(closure(candidate.objects))), cryptoApi) === candidate.objectsSha256 && root.schema === "mir2.windows.r2-verification.v1" && root.passed === true && root.candidateVerified === true && root.cmsVerified === true && root.objectsSha256 === candidate.objectsSha256 && ["sourceRevision", "sequence", "feedSha256", "signatureSha256"].every((field) => root[field] === candidate.candidate[field]),
    "root_attestation_binding_mismatch",
    503
  );
  for (const [index, entry] of candidate.objects.entries()) {
    requireValue(
      entry.index === index && Number.isSafeInteger(entry.size) && entry.size > 0 && entry.size <= 128 * 1024 * 1024 && SHA_PATTERN.test(entry.sha256) && entry.r2Key === candidate.r2Prefix + entry.path && /^[A-Za-z0-9._/-]+$/.test(entry.path) && !entry.path.includes("..") && /^[A-Za-z0-9._/-]+$/.test(entry.originRelativePath) && !entry.originRelativePath.includes("..") && !entry.originRelativePath.startsWith("/"),
      "invalid_literal_object",
      503
    );
  }
  return true;
}
function parseJson(bytes) {
  let text;
  try {
    text = new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes);
  } catch {
    throw new Fault("invalid_json");
  }
  let offset = 0, tokens = 0;
  const whitespace = () => {
    while (/^[\t\r\n ]$/.test(text[offset] ?? "")) offset++;
  };
  function string() {
    const match = /^"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/.exec(text.slice(offset));
    requireValue(match, "invalid_json");
    offset += match[0].length;
    return JSON.parse(match[0]);
  }
  function value(depth = 0) {
    requireValue(depth <= 12 && ++tokens <= 2048, "json_complexity_limit");
    whitespace();
    const character = text[offset];
    if (character === '"') return string();
    if (character === "{") {
      offset++;
      whitespace();
      const result2 = {}, keys = /* @__PURE__ */ new Set();
      if (text[offset] === "}") {
        offset++;
        return result2;
      }
      while (true) {
        whitespace();
        const key = string();
        requireValue(!keys.has(key), "duplicate_json_key");
        keys.add(key);
        whitespace();
        requireValue(text[offset++] === ":", "invalid_json");
        Object.defineProperty(result2, key, { value: value(depth + 1), enumerable: true });
        whitespace();
        const delimiter = text[offset++];
        if (delimiter === "}") return result2;
        requireValue(delimiter === ",", "invalid_json");
      }
    }
    if (character === "[") {
      offset++;
      whitespace();
      const result2 = [];
      if (text[offset] === "]") {
        offset++;
        return result2;
      }
      while (true) {
        result2.push(value(depth + 1));
        whitespace();
        const delimiter = text[offset++];
        if (delimiter === "]") return result2;
        requireValue(delimiter === ",", "invalid_json");
      }
    }
    const match = /^(?:true|false|null|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/.exec(text.slice(offset));
    requireValue(match, "invalid_json");
    offset += match[0].length;
    return JSON.parse(match[0]);
  }
  const result = value();
  whitespace();
  requireValue(offset === text.length, "invalid_json");
  return result;
}
async function cancelBody(body) {
  if (body) {
    try {
      await body.cancel();
    } catch {
    }
  }
}
async function boundedBytes(body, limit, expectedSize = void 0) {
  requireValue(body && typeof body.getReader === "function", "missing_body");
  const reader = body.getReader();
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      requireValue(value instanceof Uint8Array, "invalid_byte_stream");
      size += value.byteLength;
      requireValue(size <= limit, "body_size_limit", 413);
      chunks.push(value);
    }
    requireValue(expectedSize === void 0 || size === expectedSize, "body_size_mismatch");
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return bytes;
  } catch (error) {
    try {
      await reader.cancel();
    } catch {
    }
    throw error;
  } finally {
    reader.releaseLock();
  }
}
async function requestJson(request, limit) {
  requireValue(
    request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() === "application/json",
    "json_content_type_required",
    415
  );
  requireValue(!request.headers.has("content-encoding") || request.headers.get("content-encoding") === "identity", "request_encoding_rejected", 415);
  const declared = request.headers.get("content-length");
  if (declared !== null) requireValue(/^(?:0|[1-9][0-9]*)$/.test(declared) && Number(declared) <= limit, "request_size_limit", 413);
  return parseJson(await boundedBytes(
    request.body,
    limit,
    declared === null ? void 0 : Number(declared)
  ));
}
function verifyMetadata(record, entry, cacheControl = entry.cacheControl) {
  requireValue(record && record.key === entry.r2Key && record.size === entry.size && typeof record.httpEtag === "string" && ETAG_PATTERN.test(record.httpEtag) && record.httpMetadata?.contentType === entry.contentType && record.httpMetadata?.cacheControl === cacheControl && (!record.httpMetadata.contentEncoding || record.httpMetadata.contentEncoding === "identity") && record.customMetadata?.sha256 === entry.sha256 && hex(record.checksums?.sha256) === entry.sha256, "stored_object_mismatch", 409);
}
function selectedHeaders(record) {
  return {
    "content-length": String(record.size),
    "content-type": record.httpMetadata.contentType,
    "etag": record.httpEtag,
    "cache-control": "no-store",
    "x-mir2-stored-sha256": hex(record.checksums.sha256),
    "x-mir2-custom-sha256": record.customMetadata.sha256,
    "x-mir2-stored-cache-control": record.httpMetadata.cacheControl,
    "x-mir2-stored-content-encoding": record.httpMetadata.contentEncoding ?? "identity"
  };
}
function responseHeaders() {
  return {
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    "x-mir2-native-plan-sha256": NATIVE_PLAN_SHA256,
    "x-mir2-source-plan-sha256": native_r17_publication_plan_default.sourcePlanSha256,
    "x-mir2-root-verification-sha256": native_r17_publication_plan_default.rootVerificationSha256,
    "x-mir2-objects-sha256": native_r17_publication_plan_default.objectsSha256
  };
}
function json(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...responseHeaders(), "content-type": "application/json; charset=utf-8" }
  });
}
function pointerEntry(sha256, size) {
  return {
    r2Key: native_r17_publication_plan_default.r2Prefix + POINTER,
    size,
    sha256,
    contentType: "application/json",
    cacheControl: "no-store"
  };
}
function stageEnvelopeTemplate() {
  return {
    schema: STAGE_SCHEMA,
    mode: "stage",
    passed: true,
    planSha256: native_r17_publication_plan_default.sourcePlanSha256,
    rootVerificationSha256: native_r17_publication_plan_default.rootVerificationSha256,
    nativePlanSha256: NATIVE_PLAN_SHA256,
    objectsSha256: native_r17_publication_plan_default.objectsSha256,
    candidate: JSON.parse(JSON.stringify(native_r17_publication_plan_default.candidate)),
    expectedCurrent: null,
    pointerChanged: false,
    publicBase: native_r17_publication_plan_default.publicBase,
    publicVerified: true,
    verifiedObjects: closure()
  };
}
function validateStageEnvelope(envelope) {
  exactKeys(envelope, Object.keys(stageEnvelopeTemplate()), "invalid_stage_envelope");
  requireValue(same(envelope, stageEnvelopeTemplate()), "passed_bound_stage_envelope_required");
}
function createNativeR17Handler(dependencies = {}) {
  const cryptoApi = dependencies.crypto ?? globalThis.crypto;
  const fetchOrigin = dependencies.fetch ?? ((...args) => globalThis.fetch(...args));
  const makeFixedLength = dependencies.fixedLengthStream ?? ((size) => new globalThis.FixedLengthStream(size));
  const makeDigest = dependencies.digestStream ?? (() => new cryptoApi.DigestStream("SHA-256"));
  const now = dependencies.now ?? Date.now;
  let validated;
  const validate = () => validated ??= validateNativePlan(native_r17_publication_plan_default, cryptoApi);
  async function fetchSource(entry) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), ORIGIN_TIMEOUT_MS);
    let response;
    try {
      response = await fetchOrigin(native_r17_publication_plan_default.originBase + entry.originRelativePath, {
        method: "GET",
        redirect: "manual",
        signal: controller.signal,
        headers: { "accept-encoding": "identity", "cache-control": "no-store" }
      });
      const length = response.headers.get("content-length");
      requireValue(response.status === 200 && !response.redirected, "origin_status_rejected", 502);
      requireValue(!response.headers.get("content-encoding") || response.headers.get("content-encoding") === "identity", "origin_encoding_rejected", 502);
      requireValue(length !== null && /^[1-9][0-9]*$/.test(length) && Number(length) === entry.size && response.body, "origin_size_rejected", 502);
      return { response, clear: () => clearTimeout(timeout), abort: () => controller.abort() };
    } catch (error) {
      controller.abort();
      clearTimeout(timeout);
      await cancelBody(response?.body);
      if (error instanceof Fault) throw error;
      throw new Fault("origin_fetch_failed", 502);
    }
  }
  async function hashExisting(record, entry) {
    try {
      verifyMetadata(record, entry);
      requireValue(record.body && typeof makeDigest === "function", "digest_stream_unavailable", 503);
      const digestStream = makeDigest();
      let size = 0;
      const digestResult = digestStream.digest;
      digestResult.catch(() => {
      });
      const limiter = new TransformStream({
        transform(chunk, controller) {
          requireValue(chunk instanceof Uint8Array, "invalid_byte_stream");
          size += chunk.byteLength;
          requireValue(size <= entry.size, "existing_size_mismatch", 409);
          controller.enqueue(chunk);
        },
        flush() {
          requireValue(size === entry.size, "existing_size_mismatch", 409);
        }
      });
      await record.body.pipeThrough(limiter).pipeTo(digestStream);
      requireValue(hex(await digestResult) === entry.sha256, "existing_hash_mismatch", 409);
    } catch (error) {
      await cancelBody(record.body);
      throw error;
    }
  }
  async function importObject(bucket, entry) {
    const existing = await bucket.get(entry.r2Key);
    if (existing !== null) {
      await hashExisting(existing, entry);
      return json({
        ok: true,
        mode: "import",
        index: entry.index,
        path: entry.path,
        size: entry.size,
        sha256: entry.sha256,
        resumed: true,
        pointerChanged: false
      });
    }
    let fixed;
    try {
      fixed = makeFixedLength(entry.size);
    } catch {
      throw new Fault("fixed_length_stream_unavailable", 503);
    }
    requireValue(fixed?.readable && fixed?.writable, "fixed_length_stream_unavailable", 503);
    const origin = await fetchSource(entry);
    const controller = new AbortController();
    const pipe = origin.response.body.pipeTo(fixed.writable, { signal: controller.signal });
    const put = Promise.resolve().then(() => bucket.put(entry.r2Key, fixed.readable, {
      onlyIf: new Headers({ "if-none-match": "*" }),
      sha256: checksumBytes(entry.sha256),
      httpMetadata: { contentType: entry.contentType, cacheControl: entry.cacheControl },
      customMetadata: { sha256: entry.sha256 }
    })).then((record) => {
      requireValue(record !== null, "immutable_create_conflict", 412);
      return record;
    });
    try {
      const [, stored] = await Promise.all([pipe, put]);
      verifyMetadata(stored, entry);
      verifyMetadata(await bucket.head(entry.r2Key), entry);
      return json({
        ok: true,
        mode: "import",
        index: entry.index,
        path: entry.path,
        size: entry.size,
        sha256: entry.sha256,
        resumed: false,
        pointerChanged: false
      }, 201);
    } catch (error) {
      controller.abort();
      origin.abort();
      await cancelBody(fixed.readable);
      await Promise.allSettled([pipe, put]);
      await cancelBody(origin.response.body);
      if (error instanceof Fault) throw error;
      throw new Fault("immutable_stream_or_checksum_failed", 502);
    } finally {
      origin.clear();
    }
  }
  async function readPointer(bucket) {
    const record = await bucket.get(native_r17_publication_plan_default.r2Prefix + POINTER);
    if (record === null) return null;
    try {
      const expectedBytes = ENCODER.encode(canonical(native_r17_publication_plan_default.candidate));
      const expectedHash = await digest(expectedBytes, cryptoApi);
      verifyMetadata(record, pointerEntry(expectedHash, expectedBytes.byteLength));
      const bytes = await boundedBytes(record.body, MAX_POINTER, expectedBytes.byteLength);
      requireValue(await digest(bytes, cryptoApi) === expectedHash && same(parseJson(bytes), native_r17_publication_plan_default.candidate), "current_pointer_mismatch", 409);
      return { record, bytes };
    } catch (error) {
      await cancelBody(record.body);
      throw error;
    }
  }
  async function verifyOriginPair() {
    const pair = native_r17_publication_plan_default.objects.filter((entry) => entry.path.startsWith("feeds/"));
    let parsedFeed;
    for (const entry of pair) {
      const origin = await fetchSource(entry);
      try {
        const bytes = await boundedBytes(origin.response.body, MAX_POINTER, entry.size);
        requireValue(await digest(bytes, cryptoApi) === entry.sha256, "origin_feed_pair_changed", 409);
        if (entry.path.endsWith("/latest.json")) parsedFeed = parseJson(bytes);
      } finally {
        origin.clear();
      }
    }
    const seconds = Math.floor(now() / 1e3);
    requireValue(parsedFeed?.schema === "mir2.windows.update-feed.v1" && parsedFeed.channel === "invited" && parsedFeed.platform === "windows-x64" && parsedFeed.sequence === 12 && Number.isSafeInteger(parsedFeed.createdUnix) && Number.isSafeInteger(parsedFeed.expiresUnix) && seconds >= parsedFeed.createdUnix && seconds < parsedFeed.expiresUnix, "origin_feed_expired_or_invalid", 409);
  }
  async function promote(bucket, envelope, progress) {
    validateStageEnvelope(envelope);
    for (const entry of native_r17_publication_plan_default.objects) verifyMetadata(await bucket.head(entry.r2Key), entry);
    await verifyOriginPair();
    const current = await readPointer(bucket);
    if (current) {
      return json({
        ok: true,
        mode: "promote",
        candidate: native_r17_publication_plan_default.candidate,
        ...progress,
        alreadyPromoted: true,
        privatePointerVerified: true,
        aliasesVerified: false,
        publicVerificationRequired: true
      });
    }
    const bytes = ENCODER.encode(canonical(native_r17_publication_plan_default.candidate));
    const sha256 = await digest(bytes, cryptoApi);
    progress.pointerAttempted = true;
    progress.pointerOutcomeUnknown = true;
    let record;
    try {
      record = await bucket.put(native_r17_publication_plan_default.r2Prefix + POINTER, bytes, {
        onlyIf: new Headers({ "if-none-match": "*" }),
        sha256: checksumBytes(sha256),
        httpMetadata: { contentType: "application/json", cacheControl: "no-store" },
        customMetadata: { sha256 }
      });
    } catch {
      throw new Fault("pointer_write_outcome_unknown", 502);
    }
    if (record === null) {
      progress.pointerOutcomeUnknown = false;
      throw new Fault("pointer_compare_and_swap_failed", 412);
    }
    progress.pointerChanged = true;
    verifyMetadata(record, pointerEntry(sha256, bytes.byteLength));
    requireValue(await readPointer(bucket), "pointer_read_after_write_failed", 502);
    progress.pointerOutcomeUnknown = false;
    return json({
      ok: true,
      mode: "promote",
      candidate: native_r17_publication_plan_default.candidate,
      ...progress,
      alreadyPromoted: false,
      privatePointerVerified: true,
      aliasesVerified: false,
      publicVerificationRequired: true
    });
  }
  return async function handle(request, env) {
    const progress = { pointerAttempted: false, pointerChanged: false, pointerOutcomeUnknown: false };
    try {
      requireValue(typeof env.MIR2_R2_UPLOAD_SECRET === "string" && env.MIR2_R2_UPLOAD_SECRET.length > 0 && request.headers.get("authorization") === `Bearer ${env.MIR2_R2_UPLOAD_SECRET}`, "unauthorized", 401);
      const url = new URL(request.url);
      requireValue(url.protocol === "https:" && !url.username && !url.password && !url.search && !url.hash && !request.url.includes("?") && !/%|\\|\/\.\.?\//.test(url.pathname), "invalid_native_path");
      await validate();
      requireValue(
        env.MIR2_ASSETS && typeof env.MIR2_ASSETS.get === "function" && typeof env.MIR2_ASSETS.head === "function" && typeof env.MIR2_ASSETS.put === "function",
        "r2_binding_unavailable",
        503
      );
      if (url.pathname === PREFIX + "/import") {
        requireValue(request.method === "POST", "method_not_allowed", 405);
        const input = await requestJson(request, MAX_IMPORT_REQUEST);
        const keys = Object.keys(input ?? {});
        requireValue(keys.length === 1 && (keys[0] === "path" || keys[0] === "index"), "invalid_import_request");
        const entry = keys[0] === "index" ? Number.isSafeInteger(input.index) && input.index >= 0 ? native_r17_publication_plan_default.objects[input.index] : null : native_r17_publication_plan_default.objects.find((object) => object.path === input.path);
        requireValue(entry, "literal_object_required");
        return await importObject(env.MIR2_ASSETS, entry);
      }
      if (url.pathname === PREFIX + "/promote") {
        requireValue(request.method === "POST", "method_not_allowed", 405);
        return await promote(env.MIR2_ASSETS, await requestJson(request, MAX_STAGE_REQUEST), progress);
      }
      const match = new RegExp("^" + PREFIX + "/objects/(0|[1-9][0-9]?)$").exec(url.pathname);
      if (match) {
        requireValue(request.method === "GET" || request.method === "HEAD", "method_not_allowed", 405);
        const entry = native_r17_publication_plan_default.objects[Number(match[1])];
        requireValue(entry, "literal_object_required");
        const record = await env.MIR2_ASSETS[request.method === "HEAD" ? "head" : "get"](entry.r2Key);
        if (record === null) return new Response(null, { status: 404, headers: responseHeaders() });
        try {
          verifyMetadata(record, entry);
        } catch (error) {
          await cancelBody(record.body);
          throw error;
        }
        return new Response(request.method === "HEAD" ? null : record.body, {
          headers: { ...selectedHeaders(record), ...responseHeaders() }
        });
      }
      if (url.pathname === PREFIX + "/pointer") {
        requireValue(request.method === "GET" || request.method === "HEAD", "method_not_allowed", 405);
        const result = await readPointer(env.MIR2_ASSETS);
        if (!result) return new Response(null, { status: 404, headers: responseHeaders() });
        return new Response(request.method === "HEAD" ? null : result.bytes, {
          headers: { ...selectedHeaders(result.record), ...responseHeaders() }
        });
      }
      throw new Fault("not_found", 404);
    } catch (error) {
      return json({
        ok: false,
        error: error instanceof Fault ? error.code : "native_operation_failed",
        ...progress
      }, error instanceof Fault ? error.status : 502);
    }
  };
}
var nativeR17Fetch = createNativeR17Handler();

// src/index.ts
var MAX_OBJECT_BYTES = 300 * 1024 * 1024;
var src_default = {
  async fetch(request, env) {
    if (new URL(request.url).pathname.startsWith("/upload/native-r17")) {
      return nativeR17Fetch(request, env);
    }
    if (request.method !== "PUT") {
      return json2({ ok: false, error: "method_not_allowed" }, 405);
    }
    const auth = request.headers.get("authorization") ?? "";
    if (!env.MIR2_R2_UPLOAD_SECRET || auth !== `Bearer ${env.MIR2_R2_UPLOAD_SECRET}`) {
      return json2({ ok: false, error: "unauthorized" }, 401);
    }
    const url = new URL(request.url);
    if (url.pathname !== "/upload") {
      return json2({ ok: false, error: "not_found" }, 404);
    }
    const key = normalizeObjectKey(url.searchParams.get("key") ?? "");
    if (!key) {
      return json2({ ok: false, error: "invalid_key" }, 400);
    }
    if (key.startsWith("mir2/native/windows-invited/")) {
      return json2({ ok: false, error: "reserved_native_prefix" }, 403);
    }
    const contentLength = Number(request.headers.get("content-length") ?? 0);
    if (Number.isFinite(contentLength) && contentLength > MAX_OBJECT_BYTES) {
      return json2({ ok: false, error: "object_too_large" }, 413);
    }
    const contentEncoding = normalizeContentEncoding(
      request.headers.get("x-mir2-content-encoding") ?? request.headers.get("content-encoding")
    );
    if (contentEncoding.errorResponse) {
      return contentEncoding.errorResponse;
    }
    await env.MIR2_ASSETS.put(key, request.body, {
      httpMetadata: {
        contentType: request.headers.get("content-type") ?? void 0,
        contentEncoding: contentEncoding.value,
        cacheControl: request.headers.get("cache-control") ?? void 0
      },
      customMetadata: uploadMetadata(request)
    });
    return json2({ ok: true, key });
  }
};
function normalizeContentEncoding(value) {
  const normalized = value?.trim().toLowerCase();
  if (!normalized || normalized === "identity") {
    return { value: void 0 };
  }
  if (normalized === "gzip") {
    return { value: "gzip" };
  }
  return {
    value: void 0,
    errorResponse: json2({ ok: false, error: "unsupported_content_encoding" }, 400)
  };
}
function uploadMetadata(request) {
  const metadata = {};
  const sha256 = request.headers.get("x-mir2-sha256");
  const encodedSha256 = request.headers.get("x-mir2-encoded-sha256");
  if (sha256) metadata.sha256 = sha256;
  if (encodedSha256) metadata.encodedsha256 = encodedSha256;
  return metadata;
}
function normalizeObjectKey(value) {
  const key = value.trim().replace(/^\/+/, "");
  if (!key || key.includes("..") || key.includes("\\")) return "";
  if (!key.startsWith("mir2/")) return "";
  return key;
}
function json2(payload, status = 200) {
  return new Response(JSON.stringify(payload), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}

// local-worker-entry.mjs
function hex2(bytes) {
  return [...new Uint8Array(bytes)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
var local_worker_entry_default = {
  async fetch(request, env, ctx) {
    const path = new URL(request.url).pathname;
    if (path === "/__local/platform") {
      const bytes = Uint8Array.from(atob(env.LOCAL_FEED_BASE64), (character) => character.charCodeAt(0));
      const fixed = new FixedLengthStream(bytes.byteLength);
      const digest2 = new crypto.DigestStream("SHA-256");
      const digestResult = digest2.digest;
      const pipe = fixed.readable.pipeTo(digest2);
      const writer = fixed.writable.getWriter();
      await writer.write(bytes.subarray(0, 257));
      await writer.write(bytes.subarray(257));
      await writer.close();
      await pipe;
      return Response.json({
        runtime: "workerd-native",
        fixedLengthStream: typeof FixedLengthStream,
        digestStream: typeof crypto.DigestStream,
        bytes: bytes.byteLength,
        sha256: hex2(await digestResult)
      });
    }
    if (path === "/__local/deny") {
      try {
        const result = await fetch("https://unmatched-must-not-connect.invalid/no-fixture");
        await result.body?.cancel();
        return Response.json({ status: result.status });
      } catch {
        return Response.json({ fetchRejected: true });
      }
    }
    return src_default.fetch(request, env, ctx);
  }
};
export {
  local_worker_entry_default as default
};
