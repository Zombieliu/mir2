from pathlib import Path
import hashlib
import json
import subprocess
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
frozen = root.parent / 'r17-native-r2-importer-worker-01'

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def save_json(relative, data):
    with (root / relative).open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)
        handle.write('\n')

source = []
for relative in ['src/index.ts', 'src/native-r17-publication.mjs',
                 'src/native-r17-publication-plan.json', 'test/native-r17-publication.test.mjs']:
    local = root / relative
    previous = frozen / relative
    assert local.read_bytes() == previous.read_bytes(), relative
    source.append({'path': relative, 'bytes': local.stat().st_size, 'sha256': sha(local),
                   'originalFrozenPath': str(previous), 'originalFrozenBytesUnchanged': True})

attempts = []
selected = []
for attempt in ['attempt-01', 'attempt-02', 'attempt-03', 'attempt-04']:
    relative = f'evidence/{attempt}/receipt.json'
    receipt = json.loads((root / relative).read_text(encoding='utf-8'))
    attempts.append({'attempt': attempt, 'path': relative, 'sha256': sha(root / relative),
                     'overallPassed': receipt['passed'], 'summary': receipt['summary'],
                     'rawStdout': f'evidence/{attempt}.stdout.log',
                     'rawStderr': f'evidence/{attempt}.stderr.log'})
    if attempt in ['attempt-02', 'attempt-03', 'attempt-04']:
        for case in receipt['cases']:
            if case['passed']:
                selected.append({'name': case['name'], 'attempt': attempt,
                                 'path': f'evidence/{attempt}/{case["name"]}.json',
                                 'assertions': len(case['assertions'])})
assert len(selected) == 14
assert len({case['name'] for case in selected}) == 14
for case in selected:
    case['sha256'] = sha(root / case['path'])

extra = json.loads((root / 'evidence/attempt-03/http-framed-extra-observation.json').read_text(encoding='utf-8'))
assert extra['actualBody'] == {'size': 1159, 'sha256': '7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88'}
assert extra['outbound'][0]['bytesYieldedToBridge'] == 1160
versions = json.loads((root / 'evidence/attempt-04/receipt.json').read_text(encoding='utf-8'))
workerd = Path('C:/Users/Administrator/AppData/Local/npm-cache/_npx/c7c463f4b2350a3b/node_modules/@cloudflare/workerd-windows-64/bin/workerd.exe')
binary_version = subprocess.run([str(workerd), '--version'], check=True, capture_output=True)
for relative, data in [('evidence/workerd-version.stdout.log', binary_version.stdout),
                       ('evidence/workerd-version.stderr.log', binary_version.stderr)]:
    filename = root / relative
    if filename.exists():
        assert filename.read_bytes() == data
    else:
        with filename.open('xb') as handle:
            handle.write(data)

readme = '''# Frozen local workerd platform evidence

This directory tests the already frozen native R17 importer on actual local
workerd, with the Miniflare local R2 implementation. It is not remote Cloudflare
R2 acceptance, real HTTPS transport, a new CMS cryptographic verification,
publication, a CI dispatch, or a game build/deployment.

The original four delivery files are byte-identical. The literal 36-object plan,
candidate sequence 12, and f38a692a4ba200177f4358c9f3d1566f97fadb32cf408c072cb1f8b8bb03d4f0
closure stay unchanged. Only the real 1159-byte JSON and 1614-byte CMS signature
fixtures are available. All other 34 literal artifact paths were requested with
no matching body, rejected, and left absent. No toy candidate, substitute artifact,
real secret, remote binding, account login, or dependency installation was used.

Runtime: Node 22.18.0; installed Wrangler 4.147.0 (CLI not executed); Miniflare
5.20261001.0-alpha; workerd 1.20261001.1 / binary workerd 2026-10-01; esbuild
0.28.1; undici 7.29.1. Compatibility date 2026-05-18 matches the existing bulk
Worker configuration. Package files and binary hashes are in the raw receipts.
The wrapper bundle is a local runtime harness, not a change to the Worker source.

Worker outbound is completely routed through an explicit outboundService to an
undici MockAgent with disableNetConnect(). Only the exact two original source URLs
are mocked. Missing URLs fail with UND_MOCK_ERR_MOCK_NOT_MATCHED. SDK default
dispatch allows loopback only; Node global fetch is disabled. cf=false,
telemetry=false, worker registration=false, remote bindings=false. Listeners are
127.0.0.1 on ephemeral ports. R2, registry, and scratch paths are owned here.
Every instance was disposed; no workerd process remained in the final process
check. Local HTTPS-form request URLs select the module's path guard; no TLS
connection or certificate was tested.

Passing selected evidence consists of 14 distinct cases across attempts 02, 03,
and 04 (152 successful assertions). It does not erase the earlier failed runs:

| Attempt | Raw result | Meaning |
|---|---|---|
| 01 | 1/1, 3 assertions | Native FixedLengthStream and crypto.DigestStream available |
| 02 | 10/11, 71 successful assertions | Core default-fetch imports/R2 guards pass; extra-body expectation fails |
| 03 | 3/4, 80 successful assertions | Actual stored-body/framing proof, auth-before-fetch, all 34 unavailable bodies pass; primitive assertion too strong |
| 04 | 1/1, 4 assertions | Correct downstream native stream-boundary assertions pass |

Default fetch core path: both small original objects first import 201; local
R2 HEAD and GET expose checksums.sha256 as ArrayBuffer, exact size/MIME/cache/custom
metadata, and full GET bytes match SHA. Admin HEAD/GET return the same exact data.
Exact resume is 200 without another origin fetch. A barrier forces two absent-key
imports into the same native R2 race: one 201 and one 412 from onlyIf Headers;
stored bytes stay exact. Changed same-length content fails 502 and remains absent.
Redirect, content encoding, missing/wrong declared length fail 502 and store no
object. Missing auth is 401 before outbound. No bearer or cookie reaches the mock.
All passing cases read a null channel pointer; no promote route was called.

Preserved failure 02: the mock supplied 1160 bytes with Content-Length 1159.
The actual HTTP bridge frames the Worker-visible body at 1159, so import returned
201 rather than the harness's expected 502. Follow-up GET proves the stored body
is exactly 1159 bytes with the original SHA. This is not an immutable-content
validation bypass and is not a claim that an HTTP body larger than its framing
was rejected by the application. See attempt-03/http-framed-extra-observation.json.

Preserved failure 03: a direct native underflow's upstream pipe can fulfil while
the native readable and DigestStream reject. The initial assertion demanded all
three promises reject. After preserving it, the harness requires the downstream
consumer and digest to reject. Direct overflow rejects all three with 'Attempt
to write too many bytes through a FixedLengthStream.' Direct underflow rejects
the consumer and digest with 'FixedLengthStream did not see all expected bytes
before close().'. No test dependency injection is used in either proof.

The malformed HTTP short-body case waited for the unchanged original 120-second
source deadline, then returned 502, leaving the object and pointer absent. This
does not promise prompt upstream disconnect behavior or remote R2 cancellation.

Do not rerun full attempt 02 as a claim of 100% pass: its deliberate extra-body
expectation remains false and its failure is retained. If separately authorized,
run-captured.py accepts a new unique attempt-NN and a selected case; it never
overwrites older logs. Real remote R2 checksum/onlyIf behavior, all 36 complete
artifact imports, live authorization, full source TLS, stage envelope/promote CAS,
public aliases, CDN/range behavior, and download speed remain parent-owned gates.
'''
assert sum(case['assertions'] for case in selected) == 152
with (root / 'README.md').open('x', encoding='utf-8', newline='\n') as handle:
    handle.write(readme)

inventory = []
for filename in sorted(root.rglob('*')):
    if filename.is_file():
        relative = filename.relative_to(root).as_posix()
        inventory.append({'path': relative, 'bytes': filename.stat().st_size, 'sha256': sha(filename)})
save_json('ARTIFACT-INVENTORY.json', {'schema': 'mir2.native-r17.local-workerd-inventory.v1',
          'root': str(root), 'fileCount': len(inventory), 'files': inventory})

save_json('FROZEN-RECEIPT.json', {
    'schema': 'mir2.native-r17.local-workerd-freeze.v1', 'frozenUtc': datetime.now(timezone.utc).isoformat(),
    'root': str(root), 'sourceFiles': source, 'runtimeVersions': versions['versions'],
    'runtimeDependencies': versions['dependencies'],
    'workerdBinaryVersion': binary_version.stdout.decode('utf-8').strip(),
    'attempts': attempts, 'selectedPassingCases': selected,
    'localPlatformRequirementsSatisfied': True, 'selectedDistinctCases': 14,
    'selectedSuccessfulAssertions': 152, 'allRawAttemptsPassed': False,
    'originalFailuresPreserved': [
        {'path': 'evidence/attempt-02/source-extra-stream.json',
         'finding': '1160 mocked bytes framed at declared 1159 before Worker body; stored actual 1159 and full SHA exact'},
        {'path': 'evidence/attempt-03/native-fixed-length-boundaries.json',
         'finding': 'Native underflow upstream write may fulfil; readable and digest reject, demonstrated correctly in attempt04'},
    ],
    'claims': {'actualLocalWorkerd': True, 'localMiniflareR2Implementation': True,
               'nativeDefaultsUnchanged': True, 'noInternalTestDI': True,
               'realFrozenSmallObjects': 2, 'otherFrozenArtifactBodiesDenied': 34,
               'channelPointerNeverWritten': True, 'remoteR2Accepted': False,
               'actualSourceHttpsTestedHere': False, 'cmsReverifiedHere': False,
               'all36ArtifactBodiesAccepted': False, 'deployed': False,
               'ciDispatched': False, 'credentialsUsed': False, 'dependenciesInstalled': False,
               'repoOrGameFilesChanged': False},
    'openGates': ['Parent live auth probe', 'Remote R2 checksum and onlyIf acceptance',
                  'All 36 actual bytes import', 'Stage binding and promotion CAS',
                  'Public aliases/CDN/range/full download/speed'],
    'inventory': {'path': 'ARTIFACT-INVENTORY.json', 'sha256': sha(root / 'ARTIFACT-INVENTORY.json'),
                  'files': len(inventory)},
    'readme': {'path': 'README.md', 'sha256': sha(root / 'README.md')},
})
print(json.dumps({'root': str(root), 'inventoryFiles': len(inventory),
                  'receiptSha256': sha(root / 'FROZEN-RECEIPT.json'),
                  'inventorySha256': sha(root / 'ARTIFACT-INVENTORY.json'),
                  'readmeSha256': sha(root / 'README.md'),
                  'selectedCases': 14, 'selectedAssertions': 152}, indent=2))
