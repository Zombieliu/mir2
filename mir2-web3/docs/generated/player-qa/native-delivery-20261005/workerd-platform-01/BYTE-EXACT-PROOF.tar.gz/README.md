# Frozen local workerd platform evidence

This directory tests the already frozen native R17 importer on actual local
workerd, with the Miniflare local R2 implementation. It is not remote Cloudflare
R2 acceptance, real HTTPS transport, a new CMS cryptographic verification,
publication, a CI dispatch, or a game build/deployment.

The original four delivery files are byte-identical. The literal 36-object plan,
candidate sequence 12, and f38a692a4ba200177f4358c9f3d1566f97fadb32cf408c072cb1f8b8bb03d4f0
closure stay unchanged. Only the real 1159-byte JSON and 1614-byte CMS signature
fixtures are available. All other 34 literal artifact paths were requested with
no matching body, rejected, and left absent. No toy candidate, substitute artifact,
real secret, remote binding, account login, or dependency installation was used.

Runtime: Node 22.18.0; installed Wrangler 4.147.0 (CLI not executed); Miniflare
5.20261001.0-alpha; workerd 1.20261001.1 / binary workerd 2026-10-01; esbuild
0.28.1; undici 7.29.1. Compatibility date 2026-05-18 matches the existing bulk
Worker configuration. Package files and binary hashes are in the raw receipts.
The wrapper bundle is a local runtime harness, not a change to the Worker source.

Worker outbound is completely routed through an explicit outboundService to an
undici MockAgent with disableNetConnect(). Only the exact two original source URLs
are mocked. Missing URLs fail with UND_MOCK_ERR_MOCK_NOT_MATCHED. SDK default
dispatch allows loopback only; Node global fetch is disabled. cf=false,
telemetry=false, worker registration=false, remote bindings=false. Listeners are
127.0.0.1 on ephemeral ports. R2, registry, and scratch paths are owned here.
Every instance was disposed; no workerd process remained in the final process
check. Local HTTPS-form request URLs select the module's path guard; no TLS
connection or certificate was tested.

Passing selected evidence consists of 14 distinct cases across attempts 02, 03,
and 04 (152 successful assertions). It does not erase the earlier failed runs:

| Attempt | Raw result | Meaning |
|---|---|---|
| 01 | 1/1, 3 assertions | Native FixedLengthStream and crypto.DigestStream available |
| 02 | 10/11, 71 successful assertions | Core default-fetch imports/R2 guards pass; extra-body expectation fails |
| 03 | 3/4, 80 successful assertions | Actual stored-body/framing proof, auth-before-fetch, all 34 unavailable bodies pass; primitive assertion too strong |
| 04 | 1/1, 4 assertions | Correct downstream native stream-boundary assertions pass |

Default fetch core path: both small original objects first import 201; local
R2 HEAD and GET expose checksums.sha256 as ArrayBuffer, exact size/MIME/cache/custom
metadata, and full GET bytes match SHA. Admin HEAD/GET return the same exact data.
Exact resume is 200 without another origin fetch. A barrier forces two absent-key
imports into the same native R2 race: one 201 and one 412 from onlyIf Headers;
stored bytes stay exact. Changed same-length content fails 502 and remains absent.
Redirect, content encoding, missing/wrong declared length fail 502 and store no
object. Missing auth is 401 before outbound. No bearer or cookie reaches the mock.
All passing cases read a null channel pointer; no promote route was called.

Preserved failure 02: the mock supplied 1160 bytes with Content-Length 1159.
The actual HTTP bridge frames the Worker-visible body at 1159, so import returned
201 rather than the harness's expected 502. Follow-up GET proves the stored body
is exactly 1159 bytes with the original SHA. This is not an immutable-content
validation bypass and is not a claim that an HTTP body larger than its framing
was rejected by the application. See attempt-03/http-framed-extra-observation.json.

Preserved failure 03: a direct native underflow's upstream pipe can fulfil while
the native readable and DigestStream reject. The initial assertion demanded all
three promises reject. After preserving it, the harness requires the downstream
consumer and digest to reject. Direct overflow rejects all three with 'Attempt
to write too many bytes through a FixedLengthStream.' Direct underflow rejects
the consumer and digest with 'FixedLengthStream did not see all expected bytes
before close().'. No test dependency injection is used in either proof.

The malformed HTTP short-body case waited for the unchanged original 120-second
source deadline, then returned 502, leaving the object and pointer absent. This
does not promise prompt upstream disconnect behavior or remote R2 cancellation.

Do not rerun full attempt 02 as a claim of 100% pass: its deliberate extra-body
expectation remains false and its failure is retained. If separately authorized,
run-captured.py accepts a new unique attempt-NN and a selected case; it never
overwrites older logs. Real remote R2 checksum/onlyIf behavior, all 36 complete
artifact imports, live authorization, full source TLS, stage envelope/promote CAS,
public aliases, CDN/range behavior, and download speed remain parent-owned gates.
