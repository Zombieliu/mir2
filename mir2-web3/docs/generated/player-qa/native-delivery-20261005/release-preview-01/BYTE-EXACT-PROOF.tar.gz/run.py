from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, time

BASE = Path(__file__).resolve().parent
ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
CRATE = ROOT / 'mir2-web3/apps/game-client/windows-updater'
name, timeout, *argv = sys.argv[1:]
assert name.replace('-', '').isalnum() and argv
timeout = int(timeout)
assert 1 <= timeout <= 1800
assert shutil.disk_usage('C:/').free >= 50 * 1024**3
prefix = BASE / 'commands' / name
prefix.parent.mkdir(exist_ok=True)
owned_temp = BASE / 'owned-temp'
owned_temp.mkdir(exist_ok=True)
env = dict(os.environ, TEMP=str(owned_temp), TMP=str(owned_temp))

def hashes():
    files = sorted(CRATE.joinpath('src').rglob('*.rs'))
    files += [CRATE / 'Cargo.toml', CRATE / 'Cargo.lock', CRATE / 'scripts/build-updater-release.ps1', CRATE / 'scripts/verify-updater-bundle.ps1']
    return {p.relative_to(ROOT).as_posix(): {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}

def helper_hashes():
    names = ['run.py', 'run-integration.ps1', 'prepare-profile.py', 'PROFILE-INPUTS.json', 'SAMPLE-2048.tsv',
             'harness/Cargo.toml', 'harness/Cargo.lock', 'harness/src/main.rs', 'harness/src/bin/receipt_audit.rs']
    return {name: {'bytes': BASE.joinpath(name).stat().st_size,
                   'sha256': hashlib.sha256(BASE.joinpath(name).read_bytes()).hexdigest()}
            for name in names if BASE.joinpath(name).is_file()}

before = hashes()
helpers_before = helper_hashes()
revision = subprocess.check_output(['git', '-c', 'gc.auto=0', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
start = time.monotonic()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
minimum_free = shutil.disk_usage('C:/').free
guard = None
with prefix.with_suffix('.stdout.log').open('xb') as out, prefix.with_suffix('.stderr.log').open('xb') as err:
    child = subprocess.Popen(argv, cwd=CRATE, env=env, stdout=out, stderr=err)
    while child.poll() is None:
        minimum_free = min(minimum_free, shutil.disk_usage('C:/').free)
        if minimum_free < 50 * 1024**3 or time.monotonic() - start > timeout:
            guard = 'owned command resource/time limit'
            child.kill()
            break
        time.sleep(0.1)
    rc = child.wait()
after = hashes()
receipt = {'argv': argv, 'cwd': str(CRATE), 'sourceRevision': revision, 'startedUtc': started,
           'pid': child.pid, 'exitCode': rc, 'elapsedSeconds': time.monotonic() - start,
           'minimumCFreeBytes': minimum_free, 'guard': guard, 'timeoutSeconds': timeout,
           'ownedTemp': str(owned_temp), 'processExited': True, 'sourceBefore': before,
           'sourceAfter': after, 'compiledSourceUnchanged': before == after,
           'helperSourceBefore': helpers_before, 'helperSourceAfter': helper_hashes(),
           'publicationPerformed': False, 'userInstallationTouched': False}
for stream in ['stdout', 'stderr']:
    p = prefix.with_suffix('.' + stream + '.log')
    data = p.read_bytes()
    receipt[stream] = {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
with prefix.with_suffix('.command.json').open('x', encoding='utf-8', newline='\n') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps({'name': name, 'passed': rc == 0 and before == after, 'exitCode': rc,
                 'elapsedSeconds': receipt['elapsedSeconds'], 'receipt': str(prefix.with_suffix('.command.json'))}))
sys.exit(rc if rc else (0 if before == after else 1))
