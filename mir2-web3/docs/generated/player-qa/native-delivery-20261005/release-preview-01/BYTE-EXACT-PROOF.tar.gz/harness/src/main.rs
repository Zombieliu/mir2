//! Signed current-source prepared repair; real Windows files, no game/network.
use anyhow::{bail, ensure, Context, Result};
use mir2_windows_updater::{fs_safe as safe, model::{self, FileEntry, META, MAX_META},
    platform, transaction, update::{self, Source, Status}};
use serde_json::{json, Value};
use std::{cell::RefCell, collections::{BTreeMap, BTreeSet}, fs, path::{Path, PathBuf}, time::Instant};

const OWNED: &str = "C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01";
const REVISION: &str = "48454bba7623694ca7432613af52bee28e83970e";
const NEW_ENGINE: &str = "50F99917916F10E8E8F7E906DE1D6E1FA7EDB9A735F0CE95873BF5D196D426CF";
fn owned(path: &Path) -> Result<()> { ensure!(path.starts_with(OWNED), "outside owned fixture"); safe::ancestors(path) }
fn put_json(path: &Path, value: Value) -> Result<()> { owned(path)?; safe::write_new(path, &serde_json::to_vec_pretty(&value)?) }
fn copy_new(source: &Path, destination: &Path) -> Result<()> {
    owned(destination)?; safe::regular(source)?; ensure!(!destination.exists(), "fixture overwrite");
    fs::create_dir_all(destination.parent().context("fixture parent")?)?;
    fs::copy(source, destination)?; Ok(())
}
fn copy_tree(source: &Path, destination: &Path) -> Result<()> {
    safe::ancestors(source)?; owned(destination)?; fs::create_dir_all(destination)?;
    for item in fs::read_dir(source)? { let item=item?; let p=item.path(); safe::ancestors(&p)?;
        let next=destination.join(item.file_name());
        if item.file_type()?.is_dir() {copy_tree(&p,&next)?;} else {copy_new(&p,&next)?;}
    } Ok(())
}
fn metadata(path: &Path) -> Result<BTreeMap<String,Vec<u8>>> {
    META.into_iter().map(|name| Ok((name.into(),safe::read_bounded(&path.join(name),MAX_META)?))).collect()
}
struct MemoryStatus { events: RefCell<Vec<Value>>, last_phase: RefCell<String> }
impl MemoryStatus {fn new()->Self {Self{events:RefCell::new(vec![]),last_phase:RefCell::new(String::new())}}}
impl Status for MemoryStatus {
    fn set(&self,key:&str,percent:u32) {
        let mut events=self.events.borrow_mut();
        assert!(events.len()<10000,"bounded status trace");
        events.push(json!({"key":key,"percent":percent}));
        let phase=key.split(':').next().unwrap_or(key);
        if self.last_phase.borrow().as_str()!=phase {println!("phase {phase}"); *self.last_phase.borrow_mut()=phase.into();}
    }
    fn cancelled(&self)->bool {false}
}
struct Files { game:PathBuf, feed:PathBuf, engine:PathBuf, delivery:PathBuf,
    game_directory:String, engine_directory:String, requests:RefCell<Vec<Value>> }
impl Files {
    fn file(&self,path:&str)->Result<PathBuf> {
        model::relative(path)?;
        if ["latest.json","latest.p7s"].contains(&path) {return Ok(self.feed.join(path));}
        if let Some(rest)=path.strip_prefix(&format!("{}/",self.game_directory)) {
            return Ok(if rest.starts_with("delivery/") || ["DELIVERY.json","DELIVERY.p7s"].contains(&rest) {self.delivery.join(rest)} else {self.game.join(rest)});
        }
        if let Some(rest)=path.strip_prefix(&format!("{}/",self.engine_directory)) {
            ensure!(["ENGINE.json","ENGINE.p7s","Mir2Updater.exe"].contains(&rest),"unexpected engine object");
            return Ok(self.engine.join(rest));
        }
        bail!("unmapped signed object")
    }
}
impl Source for Files {
    fn get(&self,path:&str,limit:u64,progress:&mut dyn FnMut(u64)->Result<()>)->Result<Vec<u8>> {
        let bytes=safe::read_bounded(&self.file(path)?,limit)?;
        progress(bytes.len() as u64)?;
        self.requests.borrow_mut().push(json!({"kind":"metadata","path":path,"bytes":bytes.len(),"sha256":model::hash(&bytes)}));
        Ok(bytes)
    }
    fn download(&self,path:&str,entry:&FileEntry,destination:&Path,progress:&mut dyn FnMut(u64)->Result<()>)->Result<()> {
        let input=self.file(path)?; ensure!(safe::matches(&input,entry)?,"signed fixture payload mismatch");
        owned(destination)?; progress(entry.size)?; copy_new(&input,destination)?;
        self.requests.borrow_mut().push(json!({"kind":"payload","path":path,"bytes":entry.size,"sha256":entry.sha256}));
        Ok(())
    }
}
fn elapsed(step:&str,started:Instant,timings:&mut BTreeMap<String,f64>) {
    let seconds=started.elapsed().as_secs_f64(); timings.insert(step.into(),seconds); println!("step {step} {seconds:.3}s");
}
fn main()->Result<()> {
    let base=Path::new(OWNED); let root=base.join("prepared-repair-installation");
    ensure!(!root.exists(),"fresh owned repair root required");
    let mut timings=BTreeMap::new(); let started=Instant::now();
    let inputs:Value=serde_json::from_slice(&safe::read_bounded(&base.join("PROFILE-INPUTS.json"),32768)?)?;
    ensure!(inputs["updaterRevision"]==REVISION,"compiled input revision");
    let path=|key:&str| -> Result<PathBuf> {Ok(PathBuf::from(inputs[key].as_str().context("input path")?))};
    let game=path("package")?; let meta=metadata(&game)?;
    ensure!(model::hash(&meta["PACKAGE-MANIFEST.json"])==inputs["manifestSha256"],"frozen manifest changed");
    platform::verify_cms(&meta["RELEASE-STATEMENT.json"],&meta["RELEASE-STATEMENT.p7s"],mir2_windows_updater::SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let manifest=model::bind_game(&meta)?; ensure!(manifest.file_count==125965,"original signed manifest");
    let projection=safe::read_bounded(&base.join("SAMPLE-2048.tsv"),1024*1024)?;
    ensure!(model::hash(&projection)==inputs["sampleSha256"],"sample projection changed");
    let map=manifest.map(); let mut selected=BTreeSet::new();
    for line in std::str::from_utf8(&projection)?.lines() {
        let parts:Vec<_>=line.split('\t').collect(); ensure!(parts.len()==3,"sample row");
        let entry=map.get(parts[0]).context("sample not in signed manifest")?;
        ensure!(entry.size==parts[1].parse::<u64>()? && entry.sha256==parts[2] && selected.insert(parts[0].to_owned()),"sample identity");
    }
    ensure!(selected.len()==2048,"sample count");
    let feed_path=path("feed")?;
    let feed_bytes=safe::read_bounded(&feed_path.join("latest.json"),32768)?;
    let feed_signature=safe::read_bounded(&feed_path.join("latest.p7s"),32768)?;
    platform::verify_cms(&feed_bytes,&feed_signature,mir2_windows_updater::SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let feed=model::Feed::parse(&feed_bytes,update::now(),true)?;
    ensure!(feed.sequence==13 && feed.game.identity=="WN-CANDIDATE-20261004-invited-17","preview feed identity");
    elapsed("signed-input-validation",started,&mut timings);

    let started=Instant::now(); copy_tree(&path("oldBootstrap")?,&root)?;
    let old_metadata=metadata(&root.join("game"))?; ensure!(old_metadata==meta,"old bootstrap exact game metadata");
    let old_engine=update::active_engine(&root)?.0.exe_sha256;
    ensure!(old_engine!=NEW_ENGINE,"exercise real engine rollover");
    let witnesses=BTreeMap::from([
        ("game/logs/owned-witness.log","synthetic log"),("game/screenshots/owned-witness.txt","synthetic capture"),
        ("game/personal-file.txt","synthetic personal"),("game/client-preferences.json","synthetic language preference"),
        ("game/Configuration.ini","synthetic configuration"),("game/owned-player-progress.witness","synthetic progress witness")]);
    for (relative,bytes) in &witnesses {
        ensure!(!map.contains_key(relative.strip_prefix("game/").unwrap()),"witness collides with signed payload");
        safe::write_new(&root.join(relative),bytes.as_bytes())?;
    }
    let _lock=platform::InstallLock::acquire(&root).map_err(anyhow::Error::msg)?;
    elapsed("bootstrap-and-witness-setup",started,&mut timings);

    let started=Instant::now(); let mut preset=0;
    for entry in &manifest.files {
        if selected.contains(&entry.path) {continue;}
        let input=safe::target(&game,&entry.path)?;
        ensure!(safe::matches(&input,entry)?,"original preset payload changed");
        let target=safe::target(&root.join("game"),&entry.path)?;
        copy_new(&input,&target)?;
        ensure!(safe::matches(&target,entry)?,"preset physical copy invalid");
        preset+=1;
        if preset%20000==0 {println!("preset {preset}/123917");}
    }
    ensure!(preset==123917,"preset baseline count");
    elapsed("preset-and-full-baseline-verification",started,&mut timings);
    let started=Instant::now(); let mut cache_shas=BTreeSet::new(); let mut sample_bytes=0;
    for entry in &manifest.files {
        if !selected.contains(&entry.path) {continue;}
        sample_bytes+=entry.size;
        ensure!(!root.join("game").join(&entry.path).exists(),"sample must start missing");
        if cache_shas.insert(entry.sha256.clone()) {
            let input=safe::target(&game,&entry.path)?;
            ensure!(safe::matches(&input,entry)?,"sample original payload changed");
            let cache=safe::target(&root,&format!(".update/downloads/{}",entry.sha256))?;
            copy_new(&input,&cache)?;
            fs::OpenOptions::new().write(true).open(&cache)?.sync_all()?;
            ensure!(safe::matches(&cache,entry)?,"prepared hash cache invalid");
        }
    }
    ensure!(cache_shas.len()==1996 && sample_bytes==143571478,"actual signed sample coverage");
    elapsed("verified-warm-cache-setup",started,&mut timings);

    let source=Files{game,feed:feed_path,engine:path("engine")?,delivery:path("delivery")?,
        game_directory:feed.game.directory.clone(),engine_directory:feed.engine.directory.clone(),requests:RefCell::new(vec![])};
    let status=MemoryStatus::new(); let started=Instant::now();
    let outcome=update::check_update(&root,&source,&status)?;
    elapsed("current-release-profile-check-update",started,&mut timings);
    ensure!(outcome.changed_game_files==2048 && outcome.downloaded_files==1 && outcome.activated,"actual prepared repair and engine rollover");
    let initial_requests=source.requests.borrow().clone();
    let payloads:Vec<_>=initial_requests.iter().filter(|r|r["kind"]=="payload").collect();
    ensure!(payloads.len()==1 && payloads[0]["path"].as_str().is_some_and(|s|s.ends_with("/Mir2Updater.exe")) && payloads[0]["sha256"]==NEW_ENGINE,"only new engine payload requested");
    let started=Instant::now();
    for entry in &manifest.files {ensure!(safe::matches(&root.join("game").join(&entry.path),entry)?,"complete signed installed target mismatch");}
    ensure!(metadata(&root.join("game"))?==meta && update::active_engine(&root)?.0.exe_sha256==NEW_ENGINE,"real metadata and engine activation");
    ensure!(transaction::pending_activation(&root)?,"committed first-launch obligation");
    ensure!(update::verify_launch(&root)?==feed.game.identity,"launch validation, no launch");
    elapsed("full-125965-target-and-launch-verification",started,&mut timings);
    let started=Instant::now(); let count=source.requests.borrow().len();
    let pending=update::check_update(&root,&source,&status)?;
    ensure!(pending.activated && pending.downloaded_files==0 && pending.changed_game_files==0,"pending obligation retained");
    ensure!(source.requests.borrow()[count..].iter().all(|r|r["kind"]!="payload"),"pending recheck downloaded payload");
    elapsed("pending-first-launch-recheck",started,&mut timings);

    let started=Instant::now(); update::quarantine_and_rollback(&root)?;
    elapsed("real-quarantine-and-rollback",started,&mut timings);
    let started=Instant::now();
    for entry in &manifest.files {
        let target=root.join("game").join(&entry.path);
        if selected.contains(&entry.path) {ensure!(!target.exists(),"missing sample not restored");}
        else {ensure!(safe::matches(&target,entry)?,"preset baseline altered by rollback");}
    }
    ensure!(metadata(&root.join("game"))?==old_metadata && update::active_engine(&root)?.0.exe_sha256==old_engine,"old authenticated metadata/active engine not restored");
    for (relative,bytes) in &witnesses {ensure!(safe::read_bounded(&root.join(relative),32768)?==bytes.as_bytes(),"synthetic personal witness changed");}
    ensure!(safe::read_bounded(&root.join(".update/highest.txt"),64)?==b"13","rollback must retain sequence floor");
    ensure!(safe::read_bounded(&root.join(".update/failed-release.txt"),64)?==model::hash(&feed_bytes).as_bytes(),"exact feed quarantine");
    ensure!(!transaction::pending_activation(&root)? && update::verify_launch(&root).is_err(),"restored incomplete installation cannot launch");
    ensure!(update::check_update(&root,&source,&status).is_err(),"quarantined feed replay accepted");
    let old_feed_root=PathBuf::from("C:/mir2-playtest-releases/20261004-native-r17/updater/feed");
    let old_feed:Value=serde_json::from_slice(&safe::read_bounded(&old_feed_root.join("latest.json"),32768)?)?;
    let lower=Files{game:source.game.clone(),feed:old_feed_root,engine:source.engine.clone(),delivery:source.delivery.clone(),
        game_directory:old_feed["game"]["directory"].as_str().context("old game directory")?.into(),
        engine_directory:old_feed["engine"]["directory"].as_str().context("old engine directory")?.into(),requests:RefCell::new(vec![])};
    ensure!(update::check_update(&root,&lower,&status).is_err(),"lower authenticated sequence accepted");
    ensure!(lower.requests.borrow().iter().all(|r|r["kind"]!="payload"),"downgrade requested payload");
    elapsed("full-rollback-baseline-witness-replay-verification",started,&mut timings);

    let log=safe::read_bounded(&root.join(".update/last-run.jsonl"),1024*1024)?;
    let log_records=std::str::from_utf8(&log)?.lines().map(serde_json::from_str::<Value>).collect::<std::result::Result<Vec<_>,_>>()?;
    let phase_records:Vec<_>=log_records.iter().filter(|r|r["event"]=="local-phase-end").cloned().collect();
    for phase in ["checking-installed","staging","preparing","installing","recovering"] {
        ensure!(phase_records.iter().any(|r|r["detail"]["phase"]==phase && r["detail"]["outcome"]=="complete"),"missing actual complete local phase {phase}");
    }
    put_json(&base.join("PREPARED-REPAIR-RESULT-01.json"),json!({"schema":"mir2.current-updater.prepared-repair-result.v1","passed":true,
        "updaterRevision":REVISION,"gameCandidate":feed.game.identity,"manifestSha256":inputs["manifestSha256"],"sampleSha256":inputs["sampleSha256"],
        "profile":"official release settings","transport":"local file mapped signed artifacts","externalNetwork":false,"freshInstall":false,"publicThroughput":false,
        "warmContentCache":true,"sampleMissingBefore":2048,"presetFiles":preset,"selectedBytes":sample_bytes,"uniqueCachedPayloads":cache_shas.len(),
        "timingsSeconds":timings,"phaseTimingIncludedInCheckUpdate":true,"perFileMsAreIndividuallyRounded":true,"outcome":outcome,
        "actualPhaseRecords":phase_records,"initialRequests":initial_requests,"status":status.events.borrow().clone(),
        "fullInstalledSignedTargetsVerified":125965,"rollbackPresetTargetsVerified":123917,"missingSamplesRestored":2048,
        "syntheticPersonalWitnessesPreserved":6,"oldEngine":old_engine,"newEngine":NEW_ENGINE,"pendingRetained":true,
        "quarantinedFeedRejected":true,"lowerSequenceRejected":true,"restoredIncompleteLaunchRejected":true,
        "gameLaunched":false,"humanAccepted":false,"productionTouched":false} ))?;
    println!("signed current-source prepared repair, engine rollover and rollback passed");
    Ok(())
}
