from pathlib import Path
import gzip, hashlib, io, json, stat, subprocess, tarfile, tomllib

BASE = Path(__file__).resolve().parent
ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
CRATE = ROOT / 'mir2-web3/apps/game-client/windows-updater'
ISSUED = Path('C:/Users/Administrator/.codex/worktrees/r2-client-delivery/mir2-player-journey')
PROOF = ROOT / 'mir2-web3/docs/generated/player-qa/native-delivery-20261005/release-preview-01'
assert not PROOF.exists(), 'fresh proof directory required'
assert subprocess.check_output(['git','-c','gc.auto=0','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == '48454bba7623694ca7432613af52bee28e83970e'

def sha(data): return hashlib.sha256(data).hexdigest()
def read_regular(path):
    for parent in (path, *path.parents):
        if parent.exists():
            meta = parent.lstat()
            assert not stat.S_ISLNK(meta.st_mode) and not getattr(meta,'st_file_attributes',0) & 0x400
    meta = path.stat()
    assert stat.S_ISREG(meta.st_mode) and meta.st_nlink == 1
    return path.read_bytes()
def load(name): return json.loads(read_regular(BASE/name))
def put(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f: f.write(data)
def encoded(value): return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode('utf-8')

commands = {}
for path in sorted(BASE.joinpath('commands').glob('*.command.json')):
    receipt=json.loads(read_regular(path)); name=path.stem.removesuffix('.command')
    assert receipt['sourceRevision']=='48454bba7623694ca7432613af52bee28e83970e' and receipt['compiledSourceUnchanged'] is True
    assert receipt['sourceBefore']==receipt['sourceAfter']
    for relative, expected in receipt['sourceBefore'].items():
        data=read_regular(ROOT/relative)
        assert len(data)==expected['bytes'] and sha(data)==expected['sha256']
    for stream in ['stdout','stderr']:
        data=read_regular(Path(receipt[stream]['path']))
        assert len(data)==receipt[stream]['bytes'] and sha(data)==receipt[stream]['sha256']
    commands[name]={'exitCode':receipt['exitCode'],'elapsedSeconds':receipt['elapsedSeconds']}
assert commands['prepared-repair-01']['exitCode']==1
assert commands['authority-local-status-01']['exitCode']==1
assert all(value['exitCode']==0 for name,value in commands.items() if name not in ['prepared-repair-01','authority-local-status-01'])

# Reconstruct the byte-exact runner used by the failed profile; later additive
# code added only one helper path. Verify against its recorded pre-run SHA.
runner=read_regular(BASE/'run.py')
old_runner=runner.replace(b", 'harness/src/bin/receipt_audit.rs'",b'')
expected=load('commands/prepared-repair-01.command.json')['helperSourceBefore']['run.py']
assert len(old_runner)==expected['bytes'] and sha(old_runner)==expected['sha256']
put(BASE/'historical-helper/run.prepared-repair-01.py',old_runner)

root_lock=tomllib.loads(read_regular(CRATE/'Cargo.lock').decode())['package']
harness_lock=tomllib.loads(read_regular(BASE/'harness/Cargo.lock').decode())['package']
registry={ (p['name'],p['version'],p.get('source')):p.get('checksum') for p in root_lock if p.get('source') }
matches=[p for p in harness_lock if p.get('source')]
assert all(registry.get((p['name'],p['version'],p.get('source')))==p.get('checksum') for p in matches)

build=load('artifacts/BUILD-UPDATER.json'); bundle=load('BUNDLE-VERIFICATION-01.json'); bootstrap=load('bootstrap/BUILD-BOOTSTRAP.json')
inputs=load('bootstrap/installer/BOOTSTRAP-INPUTS.json'); audit=load('PREPARED-REPAIR-ADDITIVE-AUDIT-01.json')
assert build['sourceRevision']==bundle['sourceRevision']==inputs['updaterSourceRevision']=='48454bba7623694ca7432613af52bee28e83970e'
assert build['gameSourceRevision']==bootstrap['gameSourceRevision']==inputs['gameSourceRevision']=='6032ef8b3e27dd97bad0b20c8676ef9f185db64b'
assert build['sequence']==inputs['sequence']==13 and bootstrap['passed'] and bundle['passed']
assert all(inputs[key] is False for key in ['gamePayloadIncluded','gameAssetsIncluded','gameBuildAttestationIncluded'])
assert audit['passed'] and audit['originalCommandPassed'] is False

artifact_paths=[Path(bootstrap['installer']['path']),BASE/'artifacts/engine-release/Mir2Updater.exe',BASE/'artifacts/bundle/Mir2Launcher.exe']
artifacts={str(path):{'bytes':len(read_regular(path)),'sha256':sha(read_regular(path))} for path in artifact_paths}
assert artifacts[str(artifact_paths[0])]['bytes']==bootstrap['installer']['sizeBytes'] and artifacts[str(artifact_paths[0])]['sha256'].upper()==bootstrap['installer']['sha256']
assert artifacts[str(artifact_paths[1])]['sha256'].upper()==build['engineSha256']
assert artifacts[str(artifact_paths[2])]['sha256'].upper()==build['launcherSha256']

put(BASE/'ROOT-RELEASE-REVIEW-01.json',encoded({
    'schema':'mir2.updater.release-preview-root-review.v1','passed':True,
    'updaterRevision':build['sourceRevision'],'gameCandidate':build['gameCandidate'],'gameRevision':build['gameSourceRevision'],
    'previewSequence':13,'sourceBeforeAfterAndCurrentExact':True,'commands':commands,
    'matchedRegistryPackages':len(matches),'artifacts':artifacts,
    'originalRepairCommandPassed':False,'additiveAuditPassed':True,
    'publicFeedPublished':False,'publicFeedKnownSequence':12,'freshInstallVerified':False,
    'publicHttpsResumeVerified':False,'publicSpeedVerified':False,'cloudflareEffectiveAuthorization':False,
    'oldBootstrapFirstInstallUsesOldEngine':True,'newBootstrapEmbedsCurrentEngine':True,
    'previewMustNotBeGivenAsWorkingPublicInstaller':True,'productionGameOrGatewayChanged':False,
    'gameLaunched':False,'humanAccepted':False,
    'originalCanonicalCandidateScope':'historical immutable R17 verifier; not current broader map-scope acceptance',
    'signedFixtureTestsAdded':2,'remainingExistingSignedLibraryFixturesNotRun':2,
    'structuralBootstrapTests':39,'preparedRepairIsWarmCache':True,'artifactInstallerArchived':False,
    'additiveRejectionFingerprintScope':'2066 explicitly selected paths, not whole installation or AppData'}))

members={}
def add(name,path):
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    members[name]=read_regular(path)
for path in sorted(BASE.joinpath('commands').iterdir()):
    if path.is_file(): add('commands/'+path.name,path)
for name in ['run.py','run-integration.ps1','prepare-profile.py','store-proof.py','signed-fixtures.json',
             'SAMPLE-2048.tsv','PROFILE-INPUTS.json','BUNDLE-VERIFICATION-01.json',
             'ROOT-RELEASE-REVIEW-01.json','PREPARED-REPAIR-ADDITIVE-AUDIT-01.json']:
    add(name,BASE/name)
for directory in ['historical-helper','harness','crypto-fixtures','artifacts']:
    for path in sorted(BASE.joinpath(directory).rglob('*')):
        if path.is_file(): add(path.relative_to(BASE).as_posix(),path)
for name in ['BUILD-BOOTSTRAP.json','canonical-verifier-source-closure.json',
             'strict-game-verification.log','updater-bundle-verification.log','updater-bundle-verification.json',
             'literal-bootstrap-inputs.log','nine-language-validation.log','inno-bootstrap-compile.log',
             'installer/BOOTSTRAP-INPUTS.json','installer/Mir2-Invite.iss','installer/verified-bootstrap-files.iss',
             'installer/verified-updater-files.iss']:
    path=BASE/'bootstrap'/name
    if path.is_file(): add('bootstrap/'+name,path)
for path in sorted(BASE.joinpath('signed-fixture-results').rglob('*')):
    if path.is_file(): add(path.relative_to(BASE).as_posix(),path)
for name in ['.update/last-run.jsonl','.update/transaction.json','.update/highest.txt','.update/failed-release.txt',
             'updater/active.txt','updater/seed-feed.json','updater/seed-feed.p7s']:
    add('post-rollback-state/'+name,BASE/'prepared-repair-installation'/name)
digest=audit['highestDigest']
for name in ['FEED.json','FEED.p7s']:
    add('post-rollback-state/highest-receipt/'+name,BASE/'prepared-repair-installation/.update/receipts'/digest/name)
for path in sorted(CRATE.joinpath('src').rglob('*.rs')): add('root-source/'+path.relative_to(CRATE).as_posix(),path)
for name in ['Cargo.toml','Cargo.lock','scripts/build-updater-release.ps1','scripts/verify-updater-bundle.ps1']:
    add('root-source/'+name,CRATE/name)
issued_scripts=ISSUED/'mir2-web3/apps/game-client/windows-updater/scripts'
for name in ['build-bootstrap-installer.ps1','prepare-bootstrap-installer.py','test-bootstrap-installer.py']:
    add('issued-4c60-tools/'+name,issued_scripts/name)

inventory={name:{'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())}
PROOF.mkdir(parents=True)
archive_path=PROOF/'BYTE-EXACT-PROOF.tar.gz'
with archive_path.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                archive.addfile(info,io.BytesIO(data))
with tarfile.open(archive_path,'r:gz') as archive:
    actual=archive.getmembers();assert len(actual)==len(members)
    for info in actual:
        assert info.isfile()
        data=archive.extractfile(info).read()
        assert len(data)==inventory[info.name]['bytes'] and sha(data)==inventory[info.name]['sha256']
archive_bytes=read_regular(archive_path)
put(PROOF/'PROOF-INVENTORY.json',encoded({'schema':'mir2.byte-exact-proof-inventory.v1','archive':{'bytes':len(archive_bytes),'sha256':sha(archive_bytes)},
    'memberCount':len(members),'members':inventory,'archiveReadBackWithoutExtraction':True,
    'excludes':'game payloads/big manifest, installed baseline/backups/cache, installer EXE, VC/Inno binaries, fonts, private keys/configs and own temp/targets'}))
put(PROOF/'ROOT-RELEASE-REVIEW.json',read_regular(BASE/'ROOT-RELEASE-REVIEW-01.json'))
put(PROOF/'PREPARED-REPAIR-ADDITIVE-AUDIT.json',read_regular(BASE/'PREPARED-REPAIR-ADDITIVE-AUDIT-01.json'))
put(PROOF/'BUILD-BOOTSTRAP.json',read_regular(BASE/'bootstrap/BUILD-BOOTSTRAP.json'))
put(PROOF/'BUILD-UPDATER.json',read_regular(BASE/'artifacts/BUILD-UPDATER.json'))
put(PROOF/'.gitattributes',b'* -text -diff\nREADME.md text eol=lf diff\n')
print(json.dumps({'passed':True,'members':len(members),'archiveBytes':len(archive_bytes),'archiveSha256':sha(archive_bytes),'proof':str(PROOF)}))
