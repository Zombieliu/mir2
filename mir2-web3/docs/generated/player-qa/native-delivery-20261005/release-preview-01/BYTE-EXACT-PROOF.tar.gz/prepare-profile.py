from pathlib import Path
import hashlib, json

BASE = Path(__file__).resolve().parent
PACKAGE = Path('C:/Users/Administrator/.codex/worktrees/r17/mir2-player-journey/mir2-web3/dist/r17')
data = PACKAGE.joinpath('PACKAGE-MANIFEST.json').read_bytes()
assert hashlib.sha256(data).hexdigest().upper() == 'CEAE366BEBCA1C19C3F529EB22F016CCC80DFF5B8655694E76682E31AB12CB18'
manifest = json.loads(data)
entries = manifest['files']
assert len(entries) == 125965
forced = {
    'mir2-platform-windows.exe', 'BUILD-ATTESTATION.json', 'README-START.txt',
    'mir2-assets/original-ui/Sound/Login2.wav',
    'mir2-assets/original-ui/Sound/Select2.wav',
    'mir2-assets/generated/native-map-keyed/manifest.c4ef68a467951a78f484c4064e10f73e04a2df44bb244cf4ef240da809ab8c0f.json',
}
ordinal = lambda e: e['path'].encode('utf-16-be')
selected = []
bins = []
for lo, hi, quota in [(0,4096,1729),(4096,65536,302),(65536,1048576,13),(1048576,2**64,4)]:
    group = [e for e in entries if lo <= e['size'] < hi]
    fixed = [e for e in group if e['path'] in forced]
    remaining = sorted((e for e in group if e['path'] not in forced), key=ordinal)
    count = quota - len(fixed)
    indices = [(2*k+1)*len(remaining)//(2*count) for k in range(count)]
    assert len(set(indices)) == count
    selected += fixed + [remaining[k] for k in indices]
    bins.append({'lowerInclusive':lo,'upperExclusive':hi,'population':len(group),'sample':quota})
selected.sort(key=ordinal)
projection = ''.join(f"{e['path']}\t{e['size']}\t{e['sha256']}\n" for e in selected).encode('utf-8')
assert len(selected) == 2048 and len({e['path'] for e in selected}) == 2048
assert forced.issubset({e['path'] for e in selected})
assert sum(e['size'] for e in selected) == 143571478
assert len({e['sha256'] for e in selected}) == 1996
assert hashlib.sha256(projection).hexdigest().upper() == '4312041776199F6602263AB21BCE10DD25ED10459BB7432E0FF5BA424F2F6340'
with BASE.joinpath('SAMPLE-2048.tsv').open('xb') as f:
    f.write(projection)
with BASE.joinpath('PROFILE-INPUTS.json').open('x',encoding='utf-8',newline='\n') as f:
    json.dump({'schema':'mir2.updater.prepared-repair-profile.v1',
               'updaterRevision':'48454bba7623694ca7432613af52bee28e83970e',
               'gameCandidate':'WN-CANDIDATE-20261004-invited-17',
               'manifestSha256':hashlib.sha256(data).hexdigest().upper(),
               'sampleSha256':hashlib.sha256(projection).hexdigest().upper(),
               'sampleCount':2048,'sampleBytes':143571478,'sampleUniqueContent':1996,
               'presetCount':123917,'bins':bins,
               'package':str(PACKAGE),
               'oldBootstrap':'C:/mir2-playtest-releases/20261004-native-r17/bootstrap-01/installer/inputs',
               'feed':str(BASE/'artifacts/feed'),'engine':str(BASE/'artifacts/engine-release'),
               'delivery':'C:/mir2-playtest-releases/20261004-native-r18/r17-download-acceleration-02',
               'transport':'local file mapped signed artifacts; no external network',
               'preparedWarmCache':True,'freshInstall':False,'publicThroughput':False},f,indent=2)
    f.write('\n')
print(json.dumps({'passed':True,'sample':2048,'bytes':143571478,'uniqueContent':1996,'preset':123917}))
