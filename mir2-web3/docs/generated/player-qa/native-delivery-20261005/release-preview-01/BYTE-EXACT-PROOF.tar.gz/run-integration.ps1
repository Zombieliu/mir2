param([ValidateSet('cms','discovery')][string]$Mode)
$ErrorActionPreference='Stop'
$base='C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01'
if($Mode -eq 'cms') {
    $env:MIR2_UPDATER_CRYPTO_FIXTURES="$base/crypto-fixtures"
    $test='cms_math_key_pin_usage_detached_and_renewal_contract'
} else {
    $env:MIR2_UPDATER_DELIVERY_FIXTURES="$base/signed-fixtures.json"
    $test='signed_discovery_promotion_race_recovers_and_permanent_tampering_rejects'
}
& cargo +1.95.0 test --offline --locked --jobs 2 --manifest-path Cargo.toml --target-dir C:/mir2-build/native-updater-progress-root-20261005 --lib $test -- --ignored --test-threads=1
exit $LASTEXITCODE
