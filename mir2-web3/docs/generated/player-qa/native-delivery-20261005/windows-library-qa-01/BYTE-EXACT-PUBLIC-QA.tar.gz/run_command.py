"""Record one owned local command, preserving its unmodified stdout/stderr and exit."""
import argparse, datetime, hashlib, json, os, pathlib, subprocess, sys, time
ROOT=pathlib.Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
sys.stderr.reconfigure(encoding='utf-8',errors='replace')

def main():
    p=argparse.ArgumentParser(); p.add_argument('--name',required=True); p.add_argument('command',nargs=argparse.REMAINDER); a=p.parse_args()
    command=a.command[1:] if a.command[:1]==['--'] else a.command
    assert command and a.name.replace('-','').isalnum()
    logs=ROOT/'commands'; logs.mkdir(exist_ok=True)
    output=logs/(a.name+'.stdout.log'); error=logs/(a.name+'.stderr.log'); receipt=logs/(a.name+'.command.json')
    assert not any(p.exists() for p in [output,error,receipt]), 'never overwrite raw command results'
    env=dict(os.environ)
    tmp=ROOT/'owned-temp'; tmp.mkdir(exist_ok=True)
    env.update({'TEMP':str(tmp),'TMP':str(tmp),'CARGO_NET_OFFLINE':'true'})
    start=datetime.datetime.now(datetime.timezone.utc).isoformat(); clock=time.monotonic()
    record={'schema':'mir2.local-qa-command.v1','argv':command,'cwd':str(ROOT/'harness'),'startedUtc':start,
            'networkRequested':False,'ownedTemp':str(tmp),'stdout':str(output),'stderr':str(error)}
    with output.open('xb') as out, error.open('xb') as err:
        child=subprocess.Popen(command,cwd=ROOT/'harness',env=env,stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        record['pid']=child.pid
        while child.poll() is None:
            try: child.wait(timeout=30)
            except subprocess.TimeoutExpired: print(json.dumps({'name':a.name,'runningSeconds':round(time.monotonic()-clock,1),'stdoutBytes':output.stat().st_size,'stderrBytes':error.stat().st_size}),flush=True)
        record.update({'exitCode':child.returncode,'elapsedSeconds':round(time.monotonic()-clock,3),'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    for label,path in [('stdout',output),('stderr',error)]:
        data=path.read_bytes(); record[label+'Sha256']=hashlib.sha256(data).hexdigest(); record[label+'Bytes']=len(data)
    with receipt.open('x',encoding='utf-8') as f: json.dump(record,f,indent=2); f.write('\n')
    print(json.dumps(record,indent=2),flush=True)
    if child.returncode: print(error.read_text(errors='replace')[-9000:],flush=True)
    return child.returncode

if __name__=='__main__': sys.exit(main())
