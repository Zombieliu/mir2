import hashlib,json,pathlib,tomllib
ROOT=pathlib.Path(__file__).resolve().parent
OLD=pathlib.Path('C:/Users/Administrator/.codex/worktrees/r2-client-delivery/mir2-player-journey/mir2-web3/apps/game-client/windows-updater/Cargo.lock')
NEW=ROOT/'harness/Cargo.lock'
old=tomllib.loads(OLD.read_text()); new=tomllib.loads(NEW.read_text())
registry=lambda x:{(p['name'],p['version'],p.get('source'),p.get('checksum')) for p in x['package'] if 'source' in p}
assert registry(new)<=registry(old),'offline generation changed frozen dependency identities'
ours=[p for p in new['package'] if p['name']=='mir2-origin-updater-qa']
assert len(ours)==1 and ours[0]['version']=='0.1.0'
lib=[p for p in new['package'] if p['name']=='mir2-windows-updater']
assert len(lib)==1 and lib[0]['version']=='1.0.0' and 'source' not in lib[0]
print(json.dumps({'passed':True,'originalLockSha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),
                 'externalFrozenLockSha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),
                 'originalRegistryPackages':len(registry(old)),'externalRegistryPackages':len(registry(new)),
                 'everyRetainedRegistryVersionAndChecksumIdentical':True,'externalPathDependency':'mir2-windows-updater 1.0.0'},indent=2))
