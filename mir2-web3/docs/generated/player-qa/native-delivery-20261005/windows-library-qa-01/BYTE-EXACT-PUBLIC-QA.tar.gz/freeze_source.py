import argparse,datetime,hashlib,json,pathlib
from prepare_inputs import checked,verify
ROOT=pathlib.Path(__file__).resolve().parent
TARGET=pathlib.Path('C:/mir2-build/origin-updater-qa-20261005/debug/mir2-origin-updater-qa.exe')
NAMES=['README.md','prepare_inputs.py','run_command.py','verify_lock.py','freeze_source.py','INPUTS-01.json',
       'RAW-FAILURES-01.json','RAW-FAILURES-02.json','harness/Cargo.toml','harness/Cargo.lock','harness/src/main.rs','harness/bin/mir2-origin-updater-qa.exe']
def cargo_build_record():
    # Cargo itself hardlinks target/debug and deps. It is NOT an execution input;
    # the independent QA copy still requires checked(...).st_nlink == 1.
    assert TARGET.is_file() and not TARGET.is_symlink()
    for p in [TARGET,*TARGET.parents]: assert not getattr(p.lstat(),'st_file_attributes',0)&0x400
    s=TARGET.stat();data=TARGET.read_bytes()
    assert len(data)==s.st_size
    return {'path':TARGET.as_posix(),'size':s.st_size,'sha256':hashlib.sha256(data).hexdigest(),
            'linkCountObserved':s.st_nlink,'readOnlyBuildArtifact':True,'executedThisTargetCopyInActualInstallChain':False}
def relative_record(path):
    r=checked(path); r['path']=path.relative_to(ROOT).as_posix();return r
def main():
    p=argparse.ArgumentParser();p.add_argument('--create',action='store_true');a=p.parse_args()
    external=verify()
    path=ROOT/'FROZEN-SOURCE-01.json'
    if a.create:
        actual=cargo_build_record(); copied=checked(ROOT/'harness/bin/mir2-origin-updater-qa.exe')
        assert (actual['size'],actual['sha256'])==(copied['size'],copied['sha256'])
        value={'schema':'mir2.origin-updater-qa-source-freeze.v1','files':[relative_record(ROOT/n) for n in NAMES],
               'compiledExecutable':actual,'inputClosure':external,'rust':'1.95.0','cargoOffline':True,'cargoLocked':True,'jobs':2,
               'sourceWasReadOnly':True,'noShippedExeExecution':True,'noNetworkExecution':True,
               'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'generationOrdering':{'generatedAfterActualFreshHarnessStarted':True,
                  'frozenBeforeRunClaimed':False,'rawOrderingDefectPreserved':'RAW-FAILURES-02.json',
                  'actualRunCommandReceiptWillBindStartTime':'commands/fresh-coherent-01.command.json'}}
        with path.open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
    value=json.loads(path.read_text())
    for expected in value['files']: assert relative_record(ROOT/expected['path'])==expected
    assert cargo_build_record()==value['compiledExecutable']
    print(json.dumps({'passed':True,'sourceFiles':len(value['files']),'manifest':checked(path),'originalInputs':external},indent=2))
if __name__=='__main__':main()
