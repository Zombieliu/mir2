//! Actual signed full-size content, local file-mapped transport, no game/UI/network.
use anyhow::{bail, ensure, Context, Result};
use mir2_windows_updater::{
    fs_safe as safe,
    model::{self, FileEntry, Manifest, META, MAX_META},
    platform, transaction, update::{self, delivery::{self, Delivery}, Source, Status},
};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::{collections::{BTreeMap, BTreeSet}, fs::{self, File, OpenOptions}, io::{Read, Write},
    path::{Path, PathBuf}, sync::{Arc, Mutex, atomic::{AtomicBool, Ordering}}, time::Instant};

const OWNED: &str = "C:/mir2-playtest-releases/20261004-native-r18/origin-acceleration-client-qa-01";
const REVISION: &str = "4c60c323aed11829abae6ee5ce6e13c675a3c1c3";

#[derive(Deserialize)]
#[serde(rename_all="camelCase")]
struct Inputs {
    updater_source_revision: String, bootstrap: PathBuf, old_package: PathBuf, new_package: PathBuf,
    feed_root: PathBuf, engine_root: PathBuf, delivery_root: PathBuf,
    candidate_old: String, candidate_new: String, sequence_old: u64, sequence_new: u64,
    expected_payload_files: usize, expected_changed_old_payload: Vec<String>,
    cancel_bundle_index: usize, cancel_at_progress_bytes: u64, files: Vec<InputFile>,
}
#[derive(Deserialize)]
struct InputFile { path: PathBuf, size: u64, sha256: String }

fn write_json(path: &Path, value: impl Serialize) -> Result<()> {
    let bytes=serde_json::to_vec_pretty(&value)?;
    safe::write_new(path, &bytes)
}
fn owned(path: &Path) -> Result<()> {
    ensure!(path.starts_with(Path::new(OWNED)), "outside owned QA directory");
    safe::ancestors(path)
}
fn record(path: &Path, value: Value) -> Result<()> {
    owned(path)?;
    fs::create_dir_all(path.parent().context("report parent")?)?;
    let mut f=OpenOptions::new().create(true).append(true).open(path)?;
    serde_json::to_writer(&mut f,&value)?; f.write_all(b"\n")?; f.sync_all()?; Ok(())
}
fn entry(path: &str, bytes: &[u8]) -> FileEntry { FileEntry{path:path.into(),size:bytes.len() as u64,sha256:model::hash(bytes)} }
fn load_inputs() -> Result<Inputs> {
    let p=Path::new(OWNED).join("INPUTS-01.json");
    let i:Inputs=serde_json::from_slice(&safe::read_bounded(&p,MAX_META)?)?;
    ensure!(i.updater_source_revision==REVISION && i.expected_payload_files==125965 && i.sequence_old==11 && i.sequence_new==12,"input identity");
    for e in &i.files {
        let (size,hash)=safe::digest_file(&e.path)?;
        ensure!(size==e.size && hash.eq_ignore_ascii_case(&e.sha256),"changed input {}",e.path.display());
    }
    Ok(i)
}
fn metadata(root: &Path) -> Result<BTreeMap<String,Vec<u8>>> {
    META.into_iter().map(|n| Ok((n.into(),safe::read_bounded(&root.join(n),MAX_META)?))).collect()
}
fn signed_game(root: &Path) -> Result<Manifest> {
    let m=metadata(root)?;
    platform::verify_cms(&m["RELEASE-STATEMENT.json"],&m["RELEASE-STATEMENT.p7s"],mir2_windows_updater::SIGNING_KEY).map_err(anyhow::Error::msg)?;
    model::bind_game(&m)
}
fn signed_delivery(i: &Inputs, manifest: &Manifest) -> Result<Delivery> {
    let bytes=safe::read_bounded(&i.delivery_root.join("DELIVERY.json"),MAX_META)?;
    let sig=safe::read_bounded(&i.delivery_root.join("DELIVERY.p7s"),32768)?;
    let m=metadata(&i.new_package)?;
    let d=Delivery::parse(&bytes,&i.candidate_new,&m["PACKAGE-MANIFEST.json"],&m["VERSION.json"],manifest,update::now())?;
    platform::verify_cms_at(&bytes,&sig,mir2_windows_updater::SIGNING_KEY,d.built_unix).map_err(anyhow::Error::msg)?;
    ensure!(d.bundles.len()==11 && d.patches.len()==1 && d.patches[0].patch.size==25424169,"actual delivery topology");
    Ok(d)
}
fn copy_exact_file(src: &Path, dst: &Path) -> Result<()> {
    owned(dst)?; safe::regular(src)?; ensure!(!dst.exists(),"copy destination exists");
    fs::create_dir_all(dst.parent().context("copy parent")?)?; fs::copy(src,dst)?;
    Ok(())
}
fn copy_tree(src: &Path, dst: &Path) -> Result<()> {
    safe::ancestors(src)?; owned(dst)?;
    fs::create_dir_all(dst)?;
    for e in fs::read_dir(src)? {
        let e=e?; let p=e.path(); safe::ancestors(&p)?;
        if e.file_type()?.is_dir() {copy_tree(&p,&dst.join(e.file_name()))?;}
        else {copy_exact_file(&p,&dst.join(e.file_name()))?;}
    }
    Ok(())
}

struct RunStatus { cancel: AtomicBool, trace: PathBuf, last: Mutex<(String,u32)> }
impl RunStatus {
    fn new(trace: PathBuf) -> Self { Self{cancel:AtomicBool::new(false),trace,last:Mutex::new((String::new(),u32::MAX))} }
}
impl Status for RunStatus {
    fn set(&self,key: &str,percent:u32) {
        let mut last=self.last.lock().unwrap();
        if last.0!=key || last.1!=percent {
            if let Err(e)=record(&self.trace,json!({"kind":"status","stage":key,"percent":percent})) {eprintln!("status trace failure: {e:#}");}
            *last=(key.into(),percent);
            println!("status {key} {percent}");
        }
    }
    fn cancelled(&self)->bool {self.cancel.load(Ordering::SeqCst)}
}
#[derive(Clone,Serialize)]
#[serde(rename_all="camelCase")]
struct Request {method:String,path:String,size:u64,sha256:Option<String>,complete:bool,read_bytes:u64,written_bytes:u64,error:Option<String>,partial_before_cancel:Option<u64>}
struct Files<'a> {
    i:&'a Inputs, game_dir:String, engine_dir:String, status:Arc<RunStatus>, trace:PathBuf,
    requests:Mutex<Vec<Request>>, cancel_path:Option<String>, cancel_bytes:u64,
}
impl<'a> Files<'a> {
    fn new(i:&'a Inputs,status:Arc<RunStatus>,trace:PathBuf,cancel_path:Option<String>)->Result<Self> {
        let bytes=safe::read_bounded(&i.feed_root.join("latest.json"),32768)?;
        let sig=safe::read_bounded(&i.feed_root.join("latest.p7s"),32768)?;
        platform::verify_cms(&bytes,&sig,mir2_windows_updater::SIGNING_KEY).map_err(anyhow::Error::msg)?;
        let feed=model::Feed::parse(&bytes,update::now(),true)?;
        ensure!(feed.sequence==i.sequence_new && feed.game.identity==i.candidate_new,"feed identity");
        Ok(Self{i,game_dir:feed.game.directory,engine_dir:feed.engine.directory,status,trace,requests:Mutex::new(vec![]),cancel_path,cancel_bytes:i.cancel_at_progress_bytes})
    }
    fn file(&self,path:&str)->Result<PathBuf> {
        model::relative(path)?;
        if path=="latest.json" || path=="latest.p7s" {return Ok(self.i.feed_root.join(path));}
        if let Some(rest)=path.strip_prefix(&format!("{}/",self.game_dir)) {
            if rest=="DELIVERY.json" || rest=="DELIVERY.p7s" || rest.starts_with("delivery/") {return Ok(self.i.delivery_root.join(rest));}
            model::game_path(rest)?; return Ok(self.i.new_package.join(rest));
        }
        if let Some(rest)=path.strip_prefix(&format!("{}/",self.engine_dir)) {
            ensure!(["ENGINE.json","ENGINE.p7s","Mir2Updater.exe"].contains(&rest),"unexpected engine request");
            return Ok(self.i.engine_root.join(rest));
        }
        bail!("unmapped source path {path}")
    }
    fn keep(&self,r:Request)->Result<()> {
        record(&self.trace,json!({"kind":"sourceRequest","request":r}))?;
        self.requests.lock().unwrap().push(r); Ok(())
    }
    fn snapshot(&self)->Vec<Request> {self.requests.lock().unwrap().clone()}
}
impl Source for Files<'_> {
    fn get(&self,path:&str,limit:u64,progress:&mut dyn FnMut(u64)->Result<()>)->Result<Vec<u8>> {
        let mut r=Request{method:"metadata".into(),path:path.into(),size:0,sha256:None,complete:false,read_bytes:0,written_bytes:0,error:None,partial_before_cancel:None};
        let result=(||->Result<Vec<u8>> {
            let b=safe::read_bounded(&self.file(path)?,limit)?;
            r.size=b.len() as u64; r.sha256=Some(model::hash(&b)); r.read_bytes=r.size;
            progress(r.size)?; r.complete=true; Ok(b)
        })();
        if let Err(e)=&result {r.error=Some(format!("{e:#}"));}
        self.keep(r)?; result
    }
    fn download(&self,path:&str,e:&FileEntry,dest:&Path,progress:&mut dyn FnMut(u64)->Result<()>)->Result<()> {
        let mut r=Request{method:"payload".into(),path:path.into(),size:e.size,sha256:Some(e.sha256.clone()),complete:false,read_bytes:0,written_bytes:0,error:None,partial_before_cancel:None};
        let result=(||->Result<()> {
            owned(dest)?;
            ensure!(safe::matches(&self.file(path)?,e)?,"source file does not match signed entry");
            safe::ancestors(dest)?; fs::create_dir_all(dest.parent().context("download parent")?)?;
            let mut src=File::open(self.file(path)?)?;
            let mut out=OpenOptions::new().create_new(true).write(true).open(dest)?;
            let mut buf=[0u8;65536];
            loop {
                let n=src.read(&mut buf)?; if n==0 {break;}
                r.read_bytes+=n as u64; ensure!(r.read_bytes<=e.size,"source larger than signed entry");
                if self.cancel_path.as_deref()==Some(path) && r.read_bytes>=self.cancel_bytes {
                    out.flush()?; r.partial_before_cancel=Some(safe::regular(dest)?.len());
                    self.status.cancel.store(true,Ordering::SeqCst);
                }
                // Mirrors shipped HTTPS source: progress/cancel before writing this chunk.
                progress(r.read_bytes)?; out.write_all(&buf[..n])?; r.written_bytes+=n as u64;
            }
            out.sync_all()?; drop(out);
            ensure!(r.read_bytes==e.size && safe::matches(dest,e)?,"download exact size/hash");
            r.complete=true; Ok(())
        })();
        if let Err(err)=&result {r.error=Some(format!("{err:#}"));}
        self.keep(r)?; result
    }
}

fn personal_files(root:&Path, prefs:&Path)->Result<Vec<(PathBuf,FileEntry)>> {
    let data=[
        (root.join("game/logs/player.log"),b"synthetic player log retention witness\n".as_slice()),
        (root.join("game/personal-file.txt"),b"synthetic personal retention witness\n".as_slice()),
        (root.join("screenshots/local-user.txt"),b"synthetic screenshot retention witness\n".as_slice()),
        (prefs.join("roaming/mir2-web3/locale.json"),br#"{"schema":1,"locale":"zh-TW"}"#.as_slice()),
        (prefs.join("roaming/mir2-web3/window-preferences.json"),br#"{"schema":1,"width":1600,"height":900}"#.as_slice()),
        (prefs.join("local/mir2-web3/locale.json"),br#"{"schema":1,"locale":"pt-BR"}"#.as_slice()),
    ];
    let mut witnesses=vec![];
    for (p,b) in data {owned(&p)?; safe::write_new(&p,b)?; witnesses.push((p,entry("witness",b)));}
    std::env::set_var("APPDATA",prefs.join("roaming")); std::env::set_var("LOCALAPPDATA",prefs.join("local"));
    ensure!(mir2_windows_updater::locale()=="zh-TW","owned roaming preference must win");
    Ok(witnesses)
}
fn retained(witnesses:&[(PathBuf,FileEntry)])->Result<Value> {
    let mut files=vec![];
    for (p,e) in witnesses {ensure!(safe::matches(p,e)?,"personal file changed {}",p.display());files.push(json!({"path":p,"size":e.size,"sha256":e.sha256}));}
    ensure!(mir2_windows_updater::locale()=="zh-TW","owned locale changed");
    Ok(json!({"allPreserved":true,"syntheticOnly":true,"files":files}))
}
fn install_bootstrap(i:&Inputs,root:&Path)->Result<()> {
    ensure!(!root.exists(),"never reuse existing fixture"); owned(root)?;
    copy_tree(&i.bootstrap,root)?;
    for f in &i.files {
        if let Ok(rel)=f.path.strip_prefix(&i.bootstrap) {
            let (size,hash)=safe::digest_file(&root.join(rel))?;
            ensure!(size==f.size && hash.eq_ignore_ascii_case(&f.sha256),"bootstrap copied file identity");
        }
    }
    let bytes=safe::read_bounded(&root.join("UPDATER-BUNDLE.json"),MAX_META)?;
    let sig=safe::read_bounded(&root.join("UPDATER-BUNDLE.p7s"),32768)?;
    platform::verify_cms(&bytes,&sig,mir2_windows_updater::SIGNING_KEY).map_err(anyhow::Error::msg)?;
    ensure!(update::active_engine(root)?.0.exe_sha256=="FB3505D6D84D997CDBCEF17F986A39B930C3FCE5D108CA9831D90C5F69B16734","issued engine");
    signed_game(&root.join("game"))?;
    Ok(())
}
fn verify_all(root:&Path,m:&Manifest,trace:&Path)->Result<Value> {
    let clock=Instant::now(); let mut total=0u64;
    let out=trace.with_extension("authenticated-targets.jsonl");
    owned(&out)?; let mut f=OpenOptions::new().create_new(true).write(true).open(&out)?;
    for (ix,e) in m.files.iter().enumerate() {
        ensure!(safe::matches(&safe::target(&root.join("game"),&e.path)?,e)?,"installed target hash {}",e.path);
        serde_json::to_writer(&mut f,&json!({"path":e.path,"size":e.size,"sha256":e.sha256,"authenticated":true}))?; f.write_all(b"\n")?;
        total+=e.size;
        if ix%4096==0 {println!("authenticated {} / {}",ix,m.file_count);}
    }
    f.sync_all()?; drop(f);
    ensure!(m.file_count==125965 && total==m.total_bytes,"all target coverage");
    let (bytes,hash)=safe::digest_file(&out)?;
    Ok(json!({"passed":true,"fileCount":m.file_count,"bytes":total,"manifestAggregateSha256":m.aggregate_sha256,"evidencePath":out,"evidenceBytes":bytes,"evidenceSha256":hash,"elapsedSeconds":clock.elapsed().as_secs_f64()}))
}
fn payloads(source:&Files<'_>)->Vec<Request> {source.snapshot().into_iter().filter(|r|r.method=="payload").collect()}
fn update_once(root:&Path,source:&Files<'_>,phase:&str,reports:&Path)->Result<update::Outcome> {
    let clock=Instant::now();
    println!("phase {phase} begin");
    let result=update::check_update(root,source,source.status.as_ref());
    let detail=match &result {Ok(o)=>json!({"outcome":o}),Err(e)=>json!({"error":format!("{e:#}")})};
    write_json(&reports.join(format!("{phase}.json")),json!({"phase":phase,"elapsedSeconds":clock.elapsed().as_secs_f64(),"result":detail,"requests":source.snapshot(),"networkExecuted":false}))?;
    println!("phase {phase} end {:?}",clock.elapsed());
    result
}
fn no_parts(root:&Path)->Result<()> {
    let dir=root.join(".update/downloads");
    for e in fs::read_dir(dir)? {let p=e?.path(); safe::regular(&p)?; ensure!(p.extension().is_none(),"incomplete payload retained {}",p.display());}
    Ok(())
}
fn high_sequence(root:&Path)->Result<u64> {
    let pointer=safe::read_bounded(&root.join(".update/highest.txt"),64)?;
    let digest=std::str::from_utf8(&pointer)?;
    ensure!(model::valid_hash(digest),"highest pointer");
    let dir=safe::target(root,&format!(".update/receipts/{digest}"))?;
    let bytes=safe::read_bounded(&dir.join("FEED.json"),32768)?;
    let sig=safe::read_bounded(&dir.join("FEED.p7s"),32768)?;
    ensure!(model::hash(&bytes)==digest,"highest receipt digest");
    platform::verify_cms(&bytes,&sig,mir2_windows_updater::SIGNING_KEY).map_err(anyhow::Error::msg)?;
    Ok(model::Feed::parse(&bytes,update::now(),false)?.sequence)
}
fn fresh(i:&Inputs,reports:&Path)->Result<Value> {
    let all=Instant::now(); let root=Path::new(OWNED).join("fixtures/fresh-install");
    install_bootstrap(i,&root)?;
    let witnesses=personal_files(&root,&Path::new(OWNED).join("preferences/fresh"))?;
    let old_meta=metadata(&root.join("game"))?;
    ensure!(!root.join("game/mir2-platform-windows.exe").exists() && !root.join("game/BUILD-ATTESTATION.json").exists() && !root.join("game/mir2-assets").exists(),"Bootstrap must have no payload");
    let m=signed_game(&i.new_package)?; let d=signed_delivery(i,&m)?;
    let feed:Value=serde_json::from_slice(&safe::read_bounded(&i.feed_root.join("latest.json"),32768)?)?;
    let cancel_path=format!("{}/{}",feed["game"]["directory"].as_str().context("game directory")?,d.bundles[i.cancel_bundle_index].archive.path);
    let status=Arc::new(RunStatus::new(reports.join("fresh-cancel-status.jsonl")));
    let source=Files::new(i,status,reports.join("fresh-cancel-source.jsonl"),Some(cancel_path.clone()))?;
    let result=update_once(&root,&source,"fresh-cancel",reports);
    let error=result.err().context("expected normal cancellation error")?;
    ensure!(source.status.cancelled() && format!("{error:#}").contains("cancel"),"normal cancellation must propagate");
    let req=payloads(&source);
    ensure!(req.len()==3 && req.iter().take(2).all(|r|r.complete) && !req[2].complete && req[2].path==cancel_path && req[2].partial_before_cancel.is_some_and(|x|x>0),"real third-archive partial cancellation");
    for (b,r) in d.bundles.iter().take(2).zip(req.iter()) {
        ensure!(r.path.ends_with(&b.archive.path) && safe::matches(&delivery::payload_cache(&root,&b.archive)?,&b.archive)?,"completed archive cache lost");
    }
    let cancelled_cache=delivery::payload_cache(&root,&d.bundles[i.cancel_bundle_index].archive)?;
    ensure!(!cancelled_cache.exists() && !cancelled_cache.with_extension("part").exists(),"incomplete download must be discarded by native library");
    no_parts(&root)?;
    let by_path=m.map(); let mut retained_payloads=BTreeSet::new();
    for p in d.bundles.iter().take(2).flat_map(|b|b.files.iter()) {
        let e=by_path[p.as_str()]; ensure!(safe::matches(&delivery::payload_cache(&root,e)?,e)?,"completed payload cache lost"); retained_payloads.insert(e.sha256.clone());
    }
    ensure!(metadata(&root.join("game"))?==old_meta && !root.join("game/mir2-platform-windows.exe").exists() && !transaction::pending_activation(&root)?,"cancel must not activate partial game");
    let preserved=retained(&witnesses)?;
    write_json(&reports.join("fresh-cancel-gates.json"),json!({"passed":true,"partialDownloadObserved":req[2],"nativeRemovedIncomplete":true,"completedArchiveCaches":2,"completedTargetHashCaches":retained_payloads.len(),"gameActivationOccurred":false,"personal":preserved,"highestSeenSequence":high_sequence(&root)?}))?;
    let status=Arc::new(RunStatus::new(reports.join("fresh-retry-status.jsonl")));
    let retry=Files::new(i,status,reports.join("fresh-retry-source.jsonl"),None)?;
    let o=update_once(&root,&retry,"fresh-retry",reports)?;
    let retried=payloads(&retry);
    let expected=d.bundles.iter().skip(2).map(|b|format!("{}/{}",retry.game_dir,b.archive.path)).collect::<BTreeSet<_>>();
    ensure!(retried.len()==9 && retried.iter().all(|r|r.complete && expected.contains(&r.path)) && retried.iter().map(|r|&r.path).collect::<BTreeSet<_>>().len()==9,"retry must reuse completed cache and fetch remaining nine signed bundles only");
    ensure!(o.delivery.bundles==9 && o.delivery.patches==0 && o.delivery.fallbacks==0 && o.downloaded_files==9 && o.changed_game_files==m.file_count && o.candidate==i.candidate_new && o.sequence==12 && o.activated,"fresh actual outcome");
    ensure!(req.iter().take(2).chain(retried.iter()).map(|r|&r.path).collect::<BTreeSet<_>>().len()==11,"eleven unique complete bundle transfers");
    ensure!(update::verify_launch(&root)?==i.candidate_new && transaction::pending_activation(&root)?,"verified pending first launch");
    no_parts(&root)?; let targets=verify_all(&root,&m,&reports.join("fresh"))?;
    retained(&witnesses)?;
    let status=Arc::new(RunStatus::new(reports.join("fresh-pending-recheck-status.jsonl")));
    let second=Files::new(i,status,reports.join("fresh-pending-recheck-source.jsonl"),None)?;
    let recheck=update_once(&root,&second,"fresh-pending-recheck",reports)?;
    ensure!(recheck.activated && recheck.downloaded_files==0 && recheck.wire_bytes==0 && second.snapshot().is_empty() && transaction::pending_activation(&root)?,"pending recheck must keep rollback and do no downloads");
    let rollback_start=Instant::now(); update::quarantine_and_rollback(&root)?;
    ensure!(metadata(&root.join("game"))?==old_meta && !root.join("game/mir2-platform-windows.exe").exists() && !root.join("game/BUILD-ATTESTATION.json").exists() && !transaction::pending_activation(&root)? && update::verify_launch(&root).is_err(),"first-install rollback must restore Bootstrap, not invent an old game");
    let rollback_seconds=rollback_start.elapsed().as_secs_f64();
    let failed=safe::read_bounded(&root.join(".update/failed-release.txt"),64)?;
    ensure!(failed==model::hash(&safe::read_bounded(&i.feed_root.join("latest.json"),32768)?).as_bytes(),"failed feed hash quarantine");
    let status=Arc::new(RunStatus::new(reports.join("fresh-quarantine-check-status.jsonl")));
    let blocked=Files::new(i,status,reports.join("fresh-quarantine-check-source.jsonl"),None)?;
    let blocked_error=update_once(&root,&blocked,"fresh-quarantine-check",reports).err().context("quarantined feed must be rejected")?;
    ensure!(format!("{blocked_error:#}").contains("quarantined") && payloads(&blocked).is_empty() && high_sequence(&root)?==12,"quarantine/highest floor");
    for b in d.bundles.iter().take(2) {ensure!(safe::matches(&delivery::payload_cache(&root,&b.archive)?,&b.archive)?,"rollback discarded completed archive cache");}
    Ok(json!({"passed":true,"initialState":"issued-r16-bootstrap-without-game-payload","completedUniqueSignedBundles":11,"cancelledPartialBundle":cancel_path,"retryBundleDownloads":9,"rawPayloadDownloads":0,"targetHashes":targets,"pendingFirstLaunchRecheckNoDownloads":true,"gameHealthAccepted":false,"firstInstallRollback":{"passed":true,"oldPlayableGameExisted":false,"restoredBootstrapMetadata":true,"gameLaunchableAfterRollback":false,"elapsedSeconds":rollback_seconds,"sameFeedQuarantined":true,"highestSeenSequence":12},"personal":retained(&witnesses)?,"elapsedSeconds":all.elapsed().as_secs_f64()}))
}
fn delta(i:&Inputs,reports:&Path)->Result<Value> {
    let all=Instant::now(); let root=Path::new(OWNED).join("fixtures/old-full-install");
    install_bootstrap(i,&root)?;
    let old=signed_game(&i.old_package)?; let new=signed_game(&i.new_package)?; let d=signed_delivery(i,&new)?;
    let copy_clock=Instant::now();
    for (ix,e) in old.files.iter().enumerate() {
        let src=safe::target(&i.old_package,&e.path)?;
        ensure!(safe::matches(&src,e)?,"old full package source hash {}",e.path);
        copy_exact_file(&src,&safe::target(&root.join("game"),&e.path)?)?;
        if ix%4096==0 {println!("old copied {} / {}",ix,old.file_count);}
    }
    let copy_seconds=copy_clock.elapsed().as_secs_f64();
    ensure!(update::verify_launch(&root)?==i.candidate_old,"full R16 valid start");
    let witnesses=personal_files(&root,&Path::new(OWNED).join("preferences/old"))?;
    let old_by=old.map(); let expected_changes=new.files.iter().filter(|e|old_by.get(e.path.as_str()).is_none_or(|before|*before!=*e)).map(|e|e.path.clone()).collect::<BTreeSet<_>>();
    ensure!(expected_changes==i.expected_changed_old_payload.iter().cloned().collect(),"actual R16→R17 delta set");
    let status=Arc::new(RunStatus::new(reports.join("delta-update-status.jsonl")));
    let source=Files::new(i,status,reports.join("delta-update-source.jsonl"),None)?;
    let o=update_once(&root,&source,"delta-update",reports)?;
    let req=payloads(&source); let patch=&d.patches[0];
    ensure!(o.delivery.patches==1 && o.delivery.bundles==0 && o.delivery.fallbacks==0 && o.changed_game_files==3 && o.downloaded_files==3,"actual delta outcome");
    let patch_requests=req.iter().filter(|r|r.path.ends_with(&patch.patch.path)).collect::<Vec<_>>();
    ensure!(req.len()==3 && req.iter().all(|r|r.complete) && patch_requests.len()==1 && patch_requests[0].size==25424169 && !req.iter().any(|r|r.path.ends_with("/mir2-platform-windows.exe") || r.path.ends_with(".m2b.gz")),"one actual EXE patch plus two small raw targets, no full EXE/bundle");
    let expected_raw=i.expected_changed_old_payload.iter().filter(|p|p.as_str()!="mir2-platform-windows.exe").map(|p|format!("{}/{}",source.game_dir,p)).collect::<BTreeSet<_>>();
    ensure!(req.iter().filter(|r|!r.path.ends_with(".m2d.gz")).all(|r|expected_raw.contains(&r.path)),"unexpected raw payload");
    for e in new.files.iter().filter(|e|expected_changes.contains(&e.path)) {ensure!(safe::matches(&root.join("game").join(&e.path),e)?,"delta target validation");}
    ensure!(update::verify_launch(&root)?==i.candidate_new && transaction::pending_activation(&root)?,"delta pending first launch");
    retained(&witnesses)?;
    let status=Arc::new(RunStatus::new(reports.join("delta-pending-recheck-status.jsonl")));
    let second=Files::new(i,status,reports.join("delta-pending-recheck-source.jsonl"),None)?;
    let recheck=update_once(&root,&second,"delta-pending-recheck",reports)?;
    ensure!(recheck.activated && recheck.downloaded_files==0 && recheck.wire_bytes==0 && second.snapshot().is_empty(),"delta recheck no downloads");
    let rollback_clock=Instant::now(); update::quarantine_and_rollback(&root)?;
    ensure!(update::verify_launch(&root)?==i.candidate_old && !transaction::pending_activation(&root)? && high_sequence(&root)?==12,"old game rollback and sequence");
    for p in &i.expected_changed_old_payload {ensure!(safe::matches(&root.join("game").join(p),old_by[p.as_str()])?,"changed old file did not restore");}
    let rollback_seconds=rollback_clock.elapsed().as_secs_f64();
    let status=Arc::new(RunStatus::new(reports.join("delta-quarantine-check-status.jsonl")));
    let blocked=Files::new(i,status,reports.join("delta-quarantine-check-source.jsonl"),None)?;
    let err=update_once(&root,&blocked,"delta-quarantine-check",reports).err().context("delta quarantine must reject")?;
    ensure!(format!("{err:#}").contains("quarantined") && payloads(&blocked).is_empty(),"delta quarantine");
    Ok(json!({"passed":true,"initialState":"full-r16-installed","oldPayloadFilesCopiedAndVerified":old.file_count,"copyElapsedSeconds":copy_seconds,"changedGamePayloads":expected_changes,"unchangedPayloads":old.file_count-3,"patchRequests":patch_requests,"bundleRequests":0,"fullExeRequests":0,"pendingFirstLaunchRecheckNoDownloads":true,"gameHealthAccepted":false,"rollback":{"passed":true,"oldPlayableGameExisted":true,"oldCandidateVerified":i.candidate_old,"elapsedSeconds":rollback_seconds,"sameFeedQuarantined":true},"personal":retained(&witnesses)?,"elapsedSeconds":all.elapsed().as_secs_f64()}))
}
fn run(mode:&str,reports:&Path)->Result<Value> {
    let i=load_inputs()?;
    ensure!(cfg!(windows),"Windows CMS/guard implementation required");
    signed_game(&i.old_package)?; let m=signed_game(&i.new_package)?; let d=signed_delivery(&i,&m)?;
    match mode {
        "verify"=>{
            let signed=metadata(&i.new_package)?;
            let mut tampered=signed["RELEASE-STATEMENT.json"].clone();
            tampered[0]^=1;
            ensure!(platform::verify_cms(&tampered,&signed["RELEASE-STATEMENT.p7s"],mir2_windows_updater::SIGNING_KEY).is_err(),"tampered statement must not authenticate");
            ensure!(platform::verify_cms(&signed["RELEASE-STATEMENT.json"],&signed["RELEASE-STATEMENT.p7s"],&"0".repeat(64)).is_err(),"wrong signer must not authenticate");
            let descriptor=safe::read_bounded(&i.delivery_root.join("DELIVERY.json"),MAX_META)?;
            ensure!(Delivery::parse(&descriptor,&i.candidate_old,&signed["PACKAGE-MANIFEST.json"],&signed["VERSION.json"],&m,update::now()).is_err(),"signed delivery for other candidate must not bind");
            let clock=Instant::now(); let dummy=Path::new(OWNED).join("fixtures/never-launched/game/mir2-platform-windows.exe");
            owned(&dummy)?; fs::create_dir_all(dummy.parent().context("never-launched parent")?)?;
            for _ in 0..100 {ensure!(!platform::game_is_running(&dummy)?,"owned never-created game process");}
            Ok(json!({"passed":true,"sourceRevision":i.updater_source_revision,"signedCmsAuthenticated":true,"negativeSignatureAndBindingGuardsPassed":3,"bundles":d.bundles.len(),"patches":d.patches.len(),"targetPayloadFiles":m.file_count,"hundredReadOnlyProcessGuardsSeconds":clock.elapsed().as_secs_f64(),"allowActualRun":true}))
        },
        "fresh"=>fresh(&i,reports), "delta"=>delta(&i,reports), _=>bail!("expected verify|fresh|delta"),
    }
}
fn main() {
    let mode=std::env::args().nth(1).unwrap_or_default();
    let run_id=std::env::args().nth(2).unwrap_or_else(||"01".into());
    if !run_id.bytes().all(|b|b.is_ascii_digit()) || run_id.is_empty() {eprintln!("invalid receipt ID");std::process::exit(2);}
    let reports=Path::new(OWNED).join("reports");
    if let Err(e)=fs::create_dir_all(&reports) {eprintln!("{e}");std::process::exit(2);}
    let clock=Instant::now();
    let result=run(&mode,&reports);
    let receipt=json!({"schema":"mir2.origin-updater-library-qa.v1","mode":mode,"passed":result.is_ok(),"elapsedSeconds":clock.elapsed().as_secs_f64(),"evidence":result.as_ref().ok(),"error":result.as_ref().err().map(|e|format!("{e:#}")),"scope":{"libraryHarness":true,"localFileMappedSource":true,"signedFullSizeContent":true,"shippedExeExecuted":false,"gameLaunched":false,"networkExecuted":false,"actualHttpsSpeedMeasured":false,"r2Delivered":false,"nativeAcceptance":false,"humanAcceptance":false}});
    if let Err(e)=write_json(&reports.join(format!("{mode}-result-{run_id}.json")),&receipt) {eprintln!("receipt failure: {e:#}");std::process::exit(2);}
    println!("{}",serde_json::to_string_pretty(&receipt).unwrap());
    if let Err(e)=result {eprintln!("QA failure: {e:#}");std::process::exit(2);}
}
