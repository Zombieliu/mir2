"""Local read-only byte closure for the separately built Windows library harness."""
import argparse, hashlib, json, os, pathlib, subprocess, sys, time

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE = pathlib.Path('C:/Users/Administrator/.codex/worktrees/r2-client-delivery/mir2-player-journey')
LIB = SOURCE / 'mir2-web3/apps/game-client/windows-updater'
REVISION = '4c60c323aed11829abae6ee5ce6e13c675a3c1c3'
PLAN = pathlib.Path('C:/mir2-playtest-releases/20261004-native-r18/origin-download-compatibility-plan-01')
BOOT = pathlib.Path('C:/mir2-playtest-releases/20261003-native-r16/bootstrap-01/installer/inputs')
OLD = pathlib.Path('C:/Users/Administrator/.codex/worktrees/sabuk-siege/mir2-player-journey/mir2-web3/dist/r16')
NEW = pathlib.Path('C:/Users/Administrator/.codex/worktrees/r17/mir2-player-journey/mir2-web3/dist/r17')
R17 = pathlib.Path('C:/mir2-playtest-releases/20261004-native-r17')
DELIVERY = pathlib.Path('C:/mir2-playtest-releases/20261004-native-r18/r17-download-acceleration-02')

def checked(path):
    path = pathlib.Path(path)
    assert path.is_absolute()
    for parent in [path, *path.parents]:
        if parent.exists():
            s = parent.lstat()
            assert not parent.is_symlink() and not getattr(s, 'st_file_attributes', 0) & 0x400, f'linked/reparse {parent}'
    s = path.stat()
    assert path.is_file() and s.st_nlink == 1, f'not ordinary unique file {path}'
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    assert s.st_size == path.stat().st_size
    return {'path': path.as_posix(), 'size': s.st_size, 'sha256': h.hexdigest()}

def git_state():
    rev = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip()
    status = subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain=v1'], text=True)
    assert rev == REVISION and not status, f'wrong/dirty source {rev}: {status}'
    return {'revision': rev, 'clean': True}

def create():
    before = git_state()
    index = json.loads((PLAN / 'SOURCE-AND-RELEASE-INDEX.json').read_text())
    for expected in index['files']:
        actual = checked(expected['path'])
        assert actual['size'] == expected['size'] and actual['sha256'] == expected['sha256'], f'existing index mismatch: {actual["path"]}'
    identities = json.loads((PLAN / 'BOOTSTRAP-IDENTITIES.json').read_text())
    old_id = identities[0]['literalInputReceipt']
    boot_receipt = checked(BOOT.parent / 'BOOTSTRAP-INPUTS.json')
    assert boot_receipt['sha256'].upper() == identities[0]['buildReceipt']['bootstrapInputsSha256']
    bundle = json.loads((BOOT / 'UPDATER-BUNDLE.json').read_text())
    assert bundle['sourceRevision'] == REVISION and bundle['gameCandidate'] == old_id['candidate']
    for e in bundle['files']:
        a = checked(BOOT / e['path'])
        assert a['size'] == e['size'] and a['sha256'].upper() == e['sha256']
    manifest = json.loads((NEW / 'PACKAGE-MANIFEST.json').read_text())
    old_manifest = json.loads((OLD / 'PACKAGE-MANIFEST.json').read_text())
    assert manifest['fileCount'] == old_manifest['fileCount'] == 125965
    delivery = json.loads((DELIVERY / 'DELIVERY.json').read_text())
    assert delivery['candidate'] == 'WN-CANDIDATE-20261004-invited-17'
    assert len(delivery['bundles']) == 11 and len(delivery['patches']) == 1
    feed = json.loads((R17 / 'updater/feed/latest.json').read_text())
    assert feed['sequence'] == 12 and feed['game']['identity'] == delivery['candidate']
    assert checked(NEW / 'PACKAGE-MANIFEST.json')['sha256'].upper() == delivery['packageManifestSha256']
    assert checked(NEW / 'VERSION.json')['sha256'].upper() == delivery['versionSha256']
    assert delivery['patches'][0]['patch']['size'] == 25424169
    artifact_entries = [b['archive'] for b in delivery['bundles']] + [p['patch'] for p in delivery['patches']]
    assert sum(b['archive']['size'] for b in delivery['bundles']) == 620189573
    for e in artifact_entries:
        a = checked(DELIVERY / e['path'])
        assert a['size'] == e['size'] and a['sha256'].upper() == e['sha256'], f'artifact mismatch {e["path"]}'
    base = delivery['patches'][0]
    old_exe = checked(OLD / base['path'])
    assert old_exe['size'] == base['baseSize'] and old_exe['sha256'].upper() == base['baseSha256']
    target = next(e for e in manifest['files'] if e['path'] == base['path'])
    new_exe = checked(NEW / target['path'])
    assert new_exe['size'] == target['size'] and new_exe['sha256'].upper() == target['sha256']
    paths = {LIB/'Cargo.toml', LIB/'Cargo.lock', PLAN/'BOOTSTRAP-IDENTITIES.json', PLAN/'SOURCE-AND-RELEASE-INDEX.json', BOOT.parent/'BOOTSTRAP-INPUTS.json'}
    paths.update(p for p in (LIB/'src').rglob('*') if p.is_file())
    paths.update(p for p in BOOT.rglob('*') if p.is_file())
    for package in [OLD, NEW]:
        paths.update(package/n for n in ['VERSION.json', 'PACKAGE-MANIFEST.json', 'RELEASE-STATEMENT.json', 'RELEASE-STATEMENT.p7s', 'mir2-platform-windows.exe', 'BUILD-ATTESTATION.json'])
    paths.update(DELIVERY/e['path'] for e in artifact_entries)
    paths.update(DELIVERY/n for n in ['DELIVERY.json', 'DELIVERY.p7s', 'BUILD-DELIVERY.json', 'SIGN-DELIVERY.json', 'DELIVERY-VERIFICATION.json'])
    paths.update(R17/'updater/feed'/n for n in ['latest.json', 'latest.p7s'])
    paths.update(R17/'updater/engine-release'/n for n in ['ENGINE.json', 'ENGINE.p7s', 'Mir2Updater.exe'])
    files = [checked(p) for p in sorted(paths)]
    value = {'schema':'mir2.origin-updater-library-inputs.v1', 'updaterSourceRevision':REVISION,
             'sourcePackage':LIB.as_posix(), 'sourceRepo':SOURCE.as_posix(), 'bootstrap':BOOT.as_posix(),
             'oldPackage':OLD.as_posix(), 'newPackage':NEW.as_posix(), 'feedRoot':(R17/'updater/feed').as_posix(),
             'engineRoot':(R17/'updater/engine-release').as_posix(), 'deliveryRoot':DELIVERY.as_posix(),
             'candidateOld':old_id['candidate'], 'candidateNew':delivery['candidate'], 'sequenceOld':11, 'sequenceNew':12,
             'expectedPayloadFiles':125965, 'expectedChangedOldPayload':['BUILD-ATTESTATION.json','README-START.txt','mir2-platform-windows.exe'],
             'cancelBundleIndex':2, 'cancelAtProgressBytes':1048576, 'targetDir':'C:/mir2-build/origin-updater-qa-20261005',
             'oldInstaller':checked(identities[0]['actualInstaller']['path']), 'files':files,
             'gitBefore':before, 'gitAfter':git_state(),
             'claims':{'localFileMappedLibraryOnly':True,'networkExecuted':False,'shippedExeExecuted':False,'gameExecuted':False,'r2Delivered':False,'nativeAcceptance':False,'humanAcceptance':False}}
    out = ROOT/'INPUTS-01.json'
    with out.open('x', encoding='utf-8', newline='\n') as f: json.dump(value,f,ensure_ascii=False,indent=2); f.write('\n')
    return {'passed':True, 'files':len(files), 'input':checked(out), 'source':git_state()}

def verify():
    value = json.loads((ROOT/'INPUTS-01.json').read_text())
    assert value['updaterSourceRevision'] == REVISION
    before = git_state()
    for expected in [*value['files'], value['oldInstaller']]:
        assert checked(expected['path']) == expected, f'changed input {expected["path"]}'
    return {'passed':True,'files':len(value['files']),'gitBefore':before,'gitAfter':git_state(),'input':checked(ROOT/'INPUTS-01.json')}

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('--create',action='store_true'); a=p.parse_args()
    started=time.monotonic()
    result=create() if a.create else verify()
    result['elapsedSeconds']=round(time.monotonic()-started,3)
    print(json.dumps(result,indent=2))
