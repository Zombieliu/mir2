"""One final read-only evidence audit; never replays an install or changes old receipts."""
import datetime,hashlib,json,os,pathlib,time
from prepare_inputs import checked,verify
from freeze_source import cargo_build_record,relative_record
ROOT=pathlib.Path(__file__).resolve().parent

def read(name): return json.loads((ROOT/name).read_text(encoding='utf-8'))
def rows(name): return [json.loads(x) for x in (ROOT/name).read_text(encoding='utf-8').splitlines() if x]
def put(name,value):
    p=ROOT/name
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n')
    return checked(p)

def main():
    begin=time.monotonic()
    sources=read('FROZEN-SOURCE-01.json')
    for e in sources['files']: assert relative_record(ROOT/e['path'])==e
    assert cargo_build_record()==sources['compiledExecutable']
    external=verify()
    rustc=(ROOT/'commands/rustc-version-01.stdout.log').read_text()
    assert 'release: 1.95.0' in rustc and 'host: x86_64-pc-windows-msvc' in rustc
    fresh=read('reports/fresh-result-01.json'); delta=read('reports/delta-result-01.json')
    assert fresh['passed'] and delta['passed']
    for report in [fresh,delta]:
        assert report['scope']['libraryHarness'] and report['scope']['localFileMappedSource']
        assert not any(report['scope'][k] for k in ['shippedExeExecuted','gameLaunched','networkExecuted','actualHttpsSpeedMeasured','r2Delivered','nativeAcceptance','humanAcceptance'])
    cancel=read('reports/fresh-cancel.json'); retry=read('reports/fresh-retry.json')
    cancel_req=[r for r in cancel['requests'] if r['method']=='payload']
    retry_req=[r for r in retry['requests'] if r['method']=='payload']
    completed=[r for r in cancel_req+retry_req if r['complete']]
    assert len(cancel_req)==3 and len(retry_req)==9 and len(completed)==11
    assert len({r['path'] for r in completed})==11 and all(r['path'].endswith('.m2b.gz') for r in completed)
    assert sum(r['size'] for r in completed)==620189573
    assert not any('/mir2-assets/' in r['path'] for r in cancel_req+retry_req)
    assert cancel_req[-1]['readBytes']==1048576 and cancel_req[-1]['writtenBytes']==983040
    target=fresh['evidence']['targetHashes']
    assert target['fileCount']==125965 and target['passed']
    targets=pathlib.Path(target['evidencePath'])
    actual=checked(targets)
    assert actual['size']==target['evidenceBytes'] and actual['sha256'].upper()==target['evidenceSha256']
    records=rows(targets.relative_to(ROOT).as_posix())
    source_manifest=json.loads((pathlib.Path(read('INPUTS-01.json')['newPackage'])/'PACKAGE-MANIFEST.json').read_text())
    expected={e['path']:(e['size'],e['sha256']) for e in source_manifest['files']}
    assert len(records)==len({r['path'] for r in records})==len(expected)==125965
    h=hashlib.sha256(); n=0; total=0
    for r in sorted(records,key=lambda x:x['path']):
        assert r['authenticated'] and expected[r['path']]==(r['size'],r['sha256'])
        h.update(f'{r["path"]}\t{r["size"]}\t{r["sha256"]}\n'.encode('ascii'))
        n+=1;total+=r['size']
    assert n==125965 and total==target['bytes'] and h.hexdigest().upper()==target['manifestAggregateSha256']
    for name in ['fresh-pending-recheck','delta-pending-recheck']:
        r=read(f'reports/{name}.json')
        assert r['result']['outcome']['downloadedFiles']==r['result']['outcome']['wireBytes']==0 and not r['requests']
    for name in ['fresh-quarantine-check','delta-quarantine-check']:
        r=read(f'reports/{name}.json');assert 'quarantined' in r['result']['error']
        assert not any(x['method']=='payload' for x in r['requests'])
    commands=[]
    for p in sorted((ROOT/'commands').glob('*.command.json')):
        r=json.loads(p.read_text())
        for label in ['stdout','stderr']:
            a=checked(pathlib.Path(r[label]));assert a['sha256']==r[label+'Sha256'] and a['size']==r[label+'Bytes']
        commands.append({'path':p.relative_to(ROOT).as_posix(),'exitCode':r['exitCode'],'elapsedSeconds':r['elapsedSeconds']})
    first_start=read('commands/fresh-coherent-01.command.json')['startedUtc']
    assert sources['generationOrdering']['generatedAfterActualFreshHarnessStarted']
    assert datetime.datetime.fromisoformat(sources['createdUtc'])>datetime.datetime.fromisoformat(first_start)
    delta_req=[r for r in read('reports/delta-update.json')['requests'] if r['method']=='payload']
    assert len(delta_req)==3 and sum(r['path'].endswith('.m2d.gz') for r in delta_req)==1
    native_log=ROOT/'fixtures/fresh-install/.update/last-run.jsonl'
    log=rows(native_log.relative_to(ROOT).as_posix())
    events=[r for r in log if r['event']=='delivery-bundle'];assert len(events)==11
    native_public=ROOT/'reports/fresh-native-delivery-events-01.jsonl'
    with native_public.open('xb') as f:f.write(native_log.read_bytes())
    assert checked(native_public)['sha256']==checked(native_log)['sha256']
    delta_native=ROOT/'fixtures/old-full-install/.update/last-run.jsonl'
    delta_public=ROOT/'reports/delta-native-delivery-events-01.jsonl'
    with delta_public.open('xb') as f:f.write(delta_native.read_bytes())
    assert checked(delta_public)['sha256']==checked(delta_native)['sha256']
    narrative={'schema':'mir2.origin-updater-library-review.v1','passed':True,'updaterSourceRevision':external['gitAfter']['revision'],
       'sourceFreeze':checked(ROOT/'FROZEN-SOURCE-01.json'),'sourceFreezeAfterStart':True,
       'actualStartedUtc':first_start,'sourceFrozenUtc':sources['createdUtc'],
       'fresh':fresh['evidence'],'oldInstalledDelta':delta['evidence'],
       'signedArchiveTransfers':{'uniqueCompleted':11,'partialAttempts':1,'totalPayloadRequestAttempts':12,
           'completeArchiveBodyBytes':sum(r['size'] for r in completed),'cancelledBodyReadBytes':cancel_req[-1]['readBytes'],
           'retainedCompletedArchiveCaches':2,'retryArchiveDownloads':9,'rawGameAssetRequests':0,
           'notByteRangeResume':True,'firstTwoCompleteArchivesNeverRequestedAgain':True},
       'targetManifestAudit':{'fileCount':n,'totalBytes':total,'aggregateSha256':h.hexdigest().upper(),
           'receiptSize':actual['size'],'receiptSha256':actual['sha256']},
       'firstLaunch':{'pendingRecheckVerified':True,'bothRechecksZeroSourceRequests':True,
           'realGameHealthAcceptanceExecuted':False,'normalHealthyAcceptedRefreshExecuted':False,
           'quarantineDecisionInjectedByHarness':True,'actualFirstGameLaunchExecuted':False,
           'freshRollbackHasNoOldPlayableGame':True,'oldInstalledRollbackRestoresVerifiedOldCandidate':True},
       'syntheticPersonalWitnessCountPerFixture':6,'realUserPreferencesReadOrWritten':False,
       'nativeBundleEventSource':checked(native_public),'nativeDeltaEventSource':checked(delta_public),
       'rawCommands':commands,'originalInputsPostRun':external,'rustcVersionReceipt':checked(ROOT/'commands/rustc-version-01.stdout.log'),
       'limits':{'libraryProfile':'dev; debug=0; opt-level=0','localOperationTimeOnly':True,
           'shippedLauncherOrUpdaterExecuted':False,'nativeGameOrUIAcceptance':False,'humanAcceptance':False,
           'issuedInstallerExecuted':False,'msvcPrerequisiteInstallationTested':False,
           'actualHttpsOrLaptopSpeedMeasured':False,'r2Delivered':False,'liveFeedOrServerChanged':False},
       'preparationFailures':['RAW-FAILURES-01.json','RAW-FAILURES-02.json'],
       'elapsedAuditSeconds':round(time.monotonic()-begin,3)}
    put('FINAL-REVIEW-01.json',narrative)
    paths=[]
    for base,dirs,files in os.walk(ROOT):
        dirs[:]=[d for d in dirs if d not in ['fixtures','preferences','owned-temp','__pycache__','.git']]
        paths.extend(pathlib.Path(base)/n for n in files)
    inventory={'schema':'mir2.origin-updater-qa-public-freeze.v1','files':[relative_record(p) for p in sorted(paths)],
               'externalReadOnlyInputs':'INPUTS-01.json','originalInputCount':72,'fixturePayloadFilesExcluded':True,
               'allTargetHashesBoundByReport':checked(targets),'newSummary':checked(ROOT/'FINAL-REVIEW-01.json'),
               'oldReceiptsAndFrozenSourceUnmodified':True,'completedFinalExecutionNoFurtherWrites':True,
               'freezeCommandOutput':'Tool stdout only; no in-progress log included in its own inventory'}
    manifest=put('FROZEN-PUBLIC-01.json',inventory)
    print(json.dumps({'passed':True,'manifest':manifest,'publicFiles':len(paths),'review':checked(ROOT/'FINAL-REVIEW-01.json')},indent=2))

if __name__=='__main__':main()
