from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import io

ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
PROJECT = ROOT / 'mir2-web3'
OUT = Path(__file__).resolve().parent
QA = PROJECT / 'docs/generated/player-qa/native-delivery-20261005/preview-publication-01'
sha = lambda data: hashlib.sha256(data).hexdigest()
portable = json.loads((OUT / 'PORTABLE-INPUTS-02.json').read_bytes())
pins = portable['after']
fixtures = json.loads((OUT / 'INTEGRATION-01.json').read_bytes())['fixtureFiles']
records = []
for item in pins:
    rel = 'mir2-web3/' + item['path']
    blob = subprocess.check_output(['git', '-c', 'gc.auto=0', 'show', ':' + rel], cwd=ROOT)
    working = (ROOT / rel).read_bytes()
    assert sha(blob) == item['sha256'] and blob == working
    records.append({'path': rel, 'sha256': sha(blob), 'indexEqualsWorking': True})
for item in fixtures:
    rel = 'mir2-web3/scripts/fixtures/native-r17-13/' + item['path']
    blob = subprocess.check_output(['git', '-c', 'gc.auto=0', 'show', ':' + rel], cwd=ROOT)
    assert sha(blob) == item['sha256']
    records.append({'path': rel, 'sha256': sha(blob), 'fixtureByteExact': True})
for kind in ('node-03', 'python-03'):
    command = json.loads((OUT / (kind + '.command.json')).read_bytes())
    assert command['exitCode'] == 0 and command['before'] == command['after']
assert '# pass 138' in (OUT / 'node-03.stdout.log').read_text()
assert 'Ran 64 tests' in (OUT / 'python-03.stderr.log').read_text()
assert (OUT / 'python-03.stderr.log').read_text().rstrip().endswith('OK')
inputs = {}
for name in ('portable_fixture_paths.py', 'PORTABLE-INPUTS-02.json', 'run_checks.py',
    'freeze_portable_addendum.py', 'node-03.command.json', 'node-03.stdout.log', 'node-03.stderr.log',
    'python-03.command.json', 'python-03.stdout.log', 'python-03.stderr.log', 'FIXTURE-MOVE-01.json'):
    inputs[name] = (OUT / name).read_bytes()
inputs['root-inputs/.gitattributes'] = (ROOT / '.gitattributes').read_bytes()
for item in pins:
    inputs['root-inputs/' + item['path']] = (PROJECT / item['path']).read_bytes()
archive = QA / 'ROOT-PORTABLE-ADDENDUM.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for name, data in sorted(inputs.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode = len(data), 0o644
        tar.addfile(member, io.BytesIO(data))
result = {'schema': 'mir2.native.portable.root-review.v1', 'baseRootArchiveSha256':
    sha((QA / 'ROOT-BYTE-EXACT-PROOF.tar.gz').read_bytes()), 'originalRootArchiveUnchanged': True,
    'archive': {'members': len(inputs), 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())},
    'indexProof': records, 'rootNode': 138, 'rootPython': 64, 'skipped': 0,
    'assertionsChanged': False, 'productionGuardsChangedByPathAddendum': False,
    'firstForcedGitAddFailed': 'Windows managed path too long; no QA files indexed by that failed command.',
    'firstFixtureMoveFailed': 'PowerShell Split-Path LiteralPath/Parent parameter set, no move occurred; fixed using System.IO.Path.GetDirectoryName.',
    'nativePlanRawBytes': 64106, 'nativePlanRawSha256': '9fd816a5fdf26a937d3d94a5b031c9e992fbb104f49832ba31a703587a0385f8',
    'sourceWhitespaceCheckPassed': True, 'frozenEvidenceWhitespaceNotRewritten': True,
    'linuxAcceptance': False, 'publicSpeedAcceptance': False, 'remotePublication': False}
with (QA / 'ROOT-PORTABLE-REVIEW.json').open('x', encoding='utf-8') as out:
    json.dump(result, out, indent=2)
    out.write('\n')
print(json.dumps({'members': len(inputs), 'indexedPinsExact': len(records), 'archiveSha256': result['archive']['sha256']}))
