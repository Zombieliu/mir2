from pathlib import Path
import hashlib
import json

ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3')
OUT = Path(__file__).resolve().parent
original = json.loads((OUT / 'NORMALIZED-INPUTS-01.json').read_bytes())['after']
node_rel = 'infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs'
python_rel = 'scripts/test_native_r17_r2_delivery.py'
changes = []
for item in original:
    path = ROOT / item['path']
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == item['sha256']
    if item['path'] == node_rel:
        old = b'../../../../docs/generated/player-qa/native-delivery-20261005/preview-publication-01/fixtures/'
        assert data.count(old) == 4
        replacement = data.replace(old, b'../../../../scripts/fixtures/native-r17-13/')
    elif item['path'] == python_rel:
        old = b"FIXTURE_ROOT = BASE / 'docs/generated/player-qa/native-delivery-20261005/preview-publication-01/fixtures'"
        assert data.count(old) == 1
        replacement = data.replace(old, b"FIXTURE_ROOT = BASE / 'scripts/fixtures/native-r17-13'")
    else:
        continue
    path.write_bytes(replacement)
    changes.append({'path': item['path'], 'beforeSha256': item['sha256'], 'afterSha256': hashlib.sha256(replacement).hexdigest()})
fixtures = json.loads((OUT / 'INTEGRATION-01.json').read_bytes())['fixtureFiles']
for item in fixtures:
    actual = ROOT / 'scripts/fixtures/native-r17-13' / item['path']
    assert hashlib.sha256(actual.read_bytes()).hexdigest() == item['sha256']
after = []
for item in original:
    data = (ROOT / item['path']).read_bytes()
    after.append({'path': item['path'], 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with (OUT / 'PORTABLE-INPUTS-02.json').open('x', encoding='utf-8') as stream:
    json.dump({'schema': 'mir2.native.portable-fixtures.root-addendum.v1', 'after': after,
        'changes': changes, 'fixturesPreserved': 7, 'reason': 'Managed Windows Git path limit; seven unchanged input files moved to a shorter repository-relative fixture root.',
        'firstGitAddExit': 1, 'firstAddError': 'Filename too long; source staging succeeded separately, QA add failed.'}, stream, indent=2)
    stream.write('\n')
print(json.dumps({'testLocationEdits': len(changes), 'fixtureBytesExact': 7}))
