from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
PROJECT = ROOT / 'mir2-web3'
OUT = Path(__file__).resolve().parent
integration = json.loads((OUT / 'INTEGRATION-01.json').read_bytes())
normalization = OUT / 'NORMALIZED-INPUTS-01.json'
if normalization.exists():
    integration['after'] = json.loads(normalization.read_bytes())['after']
kind = sys.argv[1]
commands = {
    'node-01': ['C:/Program Files/nodejs/node.exe', '--experimental-strip-types', '--test',
                'infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs'],
    'python-01': ['C:/Python313/python.exe', '-B', 'scripts/test_native_r17_r2_delivery.py'],
    'node-02': ['C:/Program Files/nodejs/node.exe', '--experimental-strip-types', '--test',
                'infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs'],
    'python-02': ['C:/Python313/python.exe', '-B', 'scripts/test_native_r17_r2_delivery.py'],
    'interrupt-02': ['C:/Python313/python.exe', '-B', 'scripts/test_native_r17_interrupt.py'],
}
argv = commands[kind]

def pinned():
    records = []
    for entry in integration['after']:
        data = (PROJECT / entry['path']).read_bytes()
        value = hashlib.sha256(data).hexdigest()
        assert value == entry['sha256']
        records.append({'path': entry['path'], 'bytes': len(data), 'sha256': value})
    router = PROJECT / 'infra/cloudflare/mir2-r2-bulk-upload/src/index.ts'
    router_hash = hashlib.sha256(router.read_bytes()).hexdigest()
    assert router_hash == '7aa43b7c6cffe6ff271fcd7199ed8be95bd30783dc5b72809d57688fadcd1f40'
    return {'files': records, 'routerSha256': router_hash}

before = pinned()
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
with (OUT / (kind + '.stdout.log')).open('xb') as stdout, (OUT / (kind + '.stderr.log')).open('xb') as stderr:
    result = subprocess.run(argv, cwd=PROJECT, stdout=stdout, stderr=stderr, timeout=300, check=False)
elapsed = time.monotonic() - clock
after = pinned()
receipt = {'schema': 'mir2.native.preview.root-check.v1', 'kind': kind, 'argv': argv,
    'cwd': str(PROJECT), 'startedUtc': started, 'endedUtc': datetime.now(timezone.utc).isoformat(),
    'elapsedSeconds': elapsed, 'exitCode': result.returncode, 'before': before, 'after': after,
    'actualNetworkRequests': 0, 'productionRollout': False, 'boundary': 'fake R2/cache/HTTPSConnection; genuine tiny feed bytes, not public speed'}
with (OUT / (kind + '.command.json')).open('x', encoding='utf-8') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps({'kind': kind, 'exitCode': result.returncode, 'elapsedSeconds': elapsed, 'unchanged': before == after}))
raise SystemExit(result.returncode)
