from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3')
integration = json.loads((OUT / 'INTEGRATION-01.json').read_bytes())
selected = {
    'infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication.mjs',
    'infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs',
    'scripts/test_native_r17_r2_delivery.py',
}
prepared, changes = {}, []
for entry in integration['after']:
    data = (ROOT / entry['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    if entry['path'] in selected:
        assert data.endswith(b'\n\n')
        trimmed = data.rstrip(b'\n') + b'\n'
        assert data.startswith(trimmed) and data[len(trimmed):].strip(b'\n') == b''
        prepared[entry['path']] = trimmed
        changes.append({'path': entry['path'], 'beforeSha256': entry['sha256'],
            'afterSha256': hashlib.sha256(trimmed).hexdigest(), 'removedBytes': len(data) - len(trimmed)})
for rel, data in prepared.items():
    (ROOT / rel).write_bytes(data)
after = []
for entry in integration['after']:
    data = (ROOT / entry['path']).read_bytes()
    after.append({'path': entry['path'], 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with (OUT / 'NORMALIZED-INPUTS-01.json').open('x', encoding='utf-8') as stream:
    json.dump({'schema': 'mir2.native.root-terminal-newline-normalization.v1',
        'changes': changes, 'after': after, 'scope': 'extra final LF bytes only; every preceding source byte exact'}, stream, indent=2)
    stream.write('\n')
print(json.dumps({'files': len(changes), 'removedLF': sum(entry['removedBytes'] for entry in changes)}))
