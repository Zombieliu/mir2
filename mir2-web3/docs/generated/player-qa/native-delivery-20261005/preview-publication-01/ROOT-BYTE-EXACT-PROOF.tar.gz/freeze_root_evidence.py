from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import tarfile
import io

ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
PROJECT = ROOT / 'mir2-web3'
OUT = Path(__file__).resolve().parent
QA = PROJECT / 'docs/generated/player-qa/native-delivery-20261005/preview-publication-01'
sha = lambda data: hashlib.sha256(data).hexdigest()

def single_regular(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not getattr(info, 'st_file_attributes', 0) & 0x400, str(path)
    return path.read_bytes()

node = (OUT / 'node-02.stdout.log').read_text()
assert '# tests 138' in node and '# pass 138' in node and '# fail 0' in node and '# skipped 0' in node
python = (OUT / 'python-02.stderr.log').read_text()
assert 'Ran 64 tests' in python and python.rstrip().endswith('OK')
interrupt = (OUT / 'interrupt-02.stderr.log').read_text()
assert 'Ran 2 tests' in interrupt and 'OK (skipped=1)' in interrupt
for kind in ('node-02', 'python-02', 'interrupt-02'):
    command = json.loads((OUT / (kind + '.command.json')).read_bytes())
    assert command['exitCode'] == 0 and command['before'] == command['after']
normalized = json.loads((OUT / 'NORMALIZED-INPUTS-01.json').read_bytes())
for item in normalized['after']:
    assert sha(single_regular(PROJECT / item['path'])) == item['sha256']

fixtures_root = PROJECT / 'evidence'
fixture_inventory, regular_data = [], {}
for path in sorted(fixtures_root.rglob('*')):
    info = path.lstat()
    if stat.S_ISDIR(info.st_mode):
        assert not getattr(info, 'st_file_attributes', 0) & 0x400
        continue
    record = {'path': path.relative_to(PROJECT).as_posix(), 'size': info.st_size,
        'mode': info.st_mode, 'links': info.st_nlink, 'reparse': bool(getattr(info, 'st_file_attributes', 0) & 0x400)}
    if stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and not record['reparse']:
        data = single_regular(path)
        assert len(data) <= 300000, str(path)
        record['sha256'] = sha(data)
        regular_data[record['path']] = data
    else:
        record['bodyArchived'] = False
        record['linkText'] = os.readlink(path) if stat.S_ISLNK(info.st_mode) else None
    fixture_inventory.append(record)
with (OUT / 'MODEL-FIXTURE-INVENTORY-01.json').open('x', encoding='utf-8') as out:
    json.dump(fixture_inventory, out, indent=2)
    out.write('\n')

inputs = {str(path.relative_to(OUT)): single_regular(path) for path in OUT.iterdir() if path.is_file()}
inputs.update({'owned-model-fixtures/' + name: data for name, data in regular_data.items()})
for rel in ('.gitattributes', '.github/workflows/web-assets-r2-release.yml', 'mir2-web3/scripts/test_native_r17_interrupt.py'):
    inputs['root-inputs/' + rel] = single_regular(ROOT / rel)
archive = QA / 'ROOT-BYTE-EXACT-PROOF.tar.gz'
with tarfile.open(archive, 'x:gz') as tar:
    for rel, data in sorted(inputs.items()):
        entry = tarfile.TarInfo(rel)
        entry.size = len(data)
        entry.mode = 0o644
        tar.addfile(entry, io.BytesIO(data))
inventory = [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(inputs.items())]
with (QA / 'ROOT-INVENTORY.json').open('x', encoding='utf-8') as out:
    json.dump(inventory, out, indent=2)
    out.write('\n')
review = {'schema': 'mir2.native.preview.root-review.v1',
    'rootBase': 'b87aa8a8ac94d569893a1ee653be49d857d2b063',
    'workerNode': 138, 'workerPython': 64, 'rootNode': 138, 'rootPython': 64,
    'overlapNotAdditionalDistinct': True,
    'rootWindowsActualSigint': {'passed': 1, 'gnuTimeoutCaseSkipped': 1},
    'linuxCiNotRunYet': True, 'actualPublicSpeedTested': False, 'cloudflareAuthorizationUsed': False,
    'actualStage': False, 'actualPromote': False, 'publicFeedStillSequence': 12,
    'candidateSequence': 13, 'engineSource': '48454bba7623694ca7432613af52bee28e83970e',
    'gameSource': '6032ef8b3e27dd97bad0b20c8676ef9f185db64b',
    'integrationTestChanges': 'fixture locations and three extra terminal LF bytes only',
    'globalStageBudgetSeconds': 19800, 'globalBudgetGuaranteesAll36WorstCaseStreams': False,
    'hardKillAndPowerLossCompleteReceiptGuaranteed': False,
    'archives': {'worker': {'sha256': sha(single_regular(QA / 'WORKER-BYTE-EXACT-PROOF.tar.gz'))},
        'root': {'members': len(inventory), 'bytes': archive.stat().st_size, 'sha256': sha(single_regular(archive))}},
    'generatedModelFixtureFiles': len(fixture_inventory), 'modelRegularBodiesArchived': len(regular_data),
    'protectedGameUpdaterRuntimeFilesChangedInThisIntegration': False}
with (QA / 'ROOT-REVIEW.json').open('x', encoding='utf-8') as out:
    json.dump(review, out, indent=2)
    out.write('\n')
print(json.dumps({'rootArchive': review['archives']['root'], 'modelFixtures': len(fixture_inventory)}))
