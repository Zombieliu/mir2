from pathlib import Path
import hashlib
import json
import subprocess
import yaml

ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
OUT = Path(__file__).resolve().parent
BASE = 'b87aa8a8ac94d569893a1ee653be49d857d2b063'
REL = '.github/workflows/web-assets-r2-release.yml'
old_bytes = subprocess.check_output(['git', '-c', 'gc.auto=0', 'show', BASE + ':' + REL], cwd=ROOT)
new_bytes = (ROOT / REL).read_bytes()
old = yaml.load(old_bytes, Loader=yaml.BaseLoader)
new = yaml.load(new_bytes, Loader=yaml.BaseLoader)
assert {key: value for key, value in old.items() if key != 'jobs'} == {key: value for key, value in new.items() if key != 'jobs'}
selected = {'native-download-tooling-check', 'native-download-stage', 'native-download-promote'}
assert old['jobs'].keys() == new['jobs'].keys()
assert all(old['jobs'][key] == new['jobs'][key] for key in old['jobs'] if key not in selected)
for key in selected:
    for field in ('if', 'runs-on', 'needs', 'permissions'):
        assert old['jobs'][key].get(field) == new['jobs'][key].get(field), (key, field)
    assert old['jobs'][key]['steps'][-1] == new['jobs'][key]['steps'][-1]
    for step in new['jobs'][key]['steps']:
        if 'env' in step:
            prior = next(s for s in old['jobs'][key]['steps'] if s['name'] == step['name'])
            assert prior['env'] == step['env']
check = new['jobs']['native-download-tooling-check']
assert check['timeout-minutes'] == '10'
assert any(s.get('run', '').endswith('scripts/test_native_r17_interrupt.py') for s in check['steps'])
assert any(s.get('run', '').startswith('node --experimental-strip-types --test ') for s in check['steps'])
assert not any('env' in s for s in check['steps'])
stage = new['jobs']['native-download-stage']
assert stage['timeout-minutes'] == '360'
stage_step = next(s for s in stage['steps'] if 'Stage immutable objects' in s['name'])
assert stage_step['timeout-minutes'] == '345'
assert 'timeout --signal=INT --kill-after=30s 330m python3 -B scripts/native_r17_r2_delivery.py --mode stage ' in stage_step['run']
promote = new['jobs']['native-download-promote']
assert promote['timeout-minutes'] == '10'
promote_step = next(s for s in promote['steps'] if 'Promote the verified stage' in s['name'])
assert promote_step['timeout-minutes'] == '9'
assert 'timeout --signal=INT --kill-after=30s 8m python3 -B scripts/native_r17_r2_delivery.py --mode promote ' in promote_step['run']
attribute = subprocess.check_output(['git', '-c', 'gc.auto=0', 'check-attr', 'text', '--',
    'mir2-web3/infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json'], cwd=ROOT, text=True)
assert attribute.strip().endswith('text: unset')
receipt = {'schema': 'mir2.native.workflow.root-review.v1', 'baseline': BASE,
    'oldSha256': hashlib.sha256(old_bytes).hexdigest(), 'newSha256': hashlib.sha256(new_bytes).hexdigest(),
    'yamlParsed': True, 'unrelatedJobsAndTriggersExact': True, 'credentialBindingsUnchanged': True,
    'verifyJobHasNoSecrets': True, 'stageSeconds': 330 * 60, 'stageHardKillAfterSeconds': 30,
    'stageStepMinutes': 345, 'stageJobMinutes': 360, 'rawNativePlanPreservedByGit': True,
    'boundedGNUTimeoutActuallyExecuted': False, 'real36SlowStageWithinWholeBudgetProven': False,
    'actualNetworkRequests': 0}
with (OUT / 'WORKFLOW-REVIEW-01.json').open('x', encoding='utf-8') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps({'yamlParsed': True, 'unrelatedExact': True, 'nativeRawPlanTextUnset': True}))
