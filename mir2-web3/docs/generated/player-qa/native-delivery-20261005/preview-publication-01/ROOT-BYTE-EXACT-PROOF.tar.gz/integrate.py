"""Root-only exact frozen integration; no network, credentials or release writes."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import tarfile

ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
PROJECT = ROOT / 'mir2-web3'
WORKER = Path('C:/mir2-playtest-releases/20261004-native-r18/native-updater-preview-publication-01')
OUT = Path(__file__).resolve().parent
QA_REL = 'docs/generated/player-qa/native-delivery-20261005/preview-publication-01'
QA = PROJECT / QA_REL
SEAL_SHA = '2f174b553f19eee95f73025d70b80203da35fbe8aca814cc6275ad62e3808e61'
BASE_SHA = 'b87aa8a8ac94d569893a1ee653be49d857d2b063'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    path = Path(path)
    for item in (path, *path.parents):
        info = item.lstat()
        assert not stat.S_ISLNK(info.st_mode) and not getattr(info, 'st_file_attributes', 0) & 0x400, str(item)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1, str(path)
    return path.read_bytes()

def checked(path, record):
    data = read(path)
    assert sha(data) == record['sha256'], str(path)
    if 'bytes' in record:
        assert len(data) == record['bytes'], str(path)
    return data

def new_file(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), str(path)
    with path.open('xb') as stream:
        stream.write(data)

seal_bytes = read(WORKER / 'FREEZE-SEAL-01.json')
assert sha(seal_bytes) == SEAL_SHA
seal = json.loads(seal_bytes)
assert seal['state'] == 'frozen' and seal['patchCheckExit'] == 0
head = subprocess.check_output(['git', '-c', 'gc.auto=0', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == BASE_SHA
hashes = json.loads(read(WORKER / 'FINAL-HASHES-01.json'))
assert hashes['rootBaseline'] == head
assert not QA.exists()
for record in seal['artifacts'] + seal['attempts']:
    checked(WORKER / record['path'], record)
for record in hashes['actualRootIssuedProofCopies'] + hashes['publicFixtureInventory']:
    checked(Path(record['path']), record)
for record in hashes['unchangedRouterDependencies']:
    checked(Path(record['path']), record)

all_new = {}
before = []
for record in hashes['sourceFiles']:
    rel = record['path']
    baseline = read(PROJECT / rel)
    assert sha(baseline) == record['baselineSha256'], rel
    prepared = read(WORKER / 'prepared' / rel)
    assert sha(prepared) == record['finalSha256'] and len(prepared) == record['bytes'], rel
    all_new[rel] = prepared
    before.append({'path': rel, 'sha256': sha(baseline)})

node_rel = 'infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs'
node = all_new[node_rel]
node_edits = [
    (b'../../../../../prepared-snapshot-01/', ('../../../../' + QA_REL + '/fixtures/prepared-snapshot-01/').encode(), 2),
    (b'../../../../../fixtures/preview/', ('../../../../' + QA_REL + '/fixtures/preview/').encode(), 1),
    (b'../../../../../fixtures/predecessor12/', ('../../../../' + QA_REL + '/fixtures/predecessor12/').encode(), 1),
    (b'file:///C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3/infra/cloudflare/mir2-r2-bulk-upload/src/index.ts', b'../src/index.ts', 1),
]
for old, new, count in node_edits:
    assert node.count(old) == count, old
    node = node.replace(old, new)
all_new[node_rel] = node

python_rel = 'scripts/test_native_r17_r2_delivery.py'
python = all_new[python_rel]
python_edits = [
    (b"PREPARED_ROOT = BASE.parent / 'prepared-snapshot-01'", ("FIXTURE_ROOT = BASE / '" + QA_REL + "/fixtures'\nPREPARED_ROOT = FIXTURE_ROOT / 'prepared-snapshot-01'").encode(), 1),
    (b"FIXTURES = BASE.parent / 'fixtures/preview/artifacts/feed'", b"FIXTURES = FIXTURE_ROOT / 'preview/artifacts/feed'", 1),
    (b"INPUT_PLAN = P.PLAN_FILE if P.PLAN_FILE.exists() else Path(\n    'C:/mir2-playtest-releases/20261004-native-r18/r17-native-r2-importer-worker-01/src/native-r17-publication-plan.json')", b'INPUT_PLAN = P.PLAN_FILE', 1),
    (b"BASE.parent / 'fixtures/preview/artifacts/feed/latest.json'", b"FIXTURE_ROOT / 'preview/artifacts/feed/latest.json'", 1),
    (b"BASE.parent / 'fixtures/preview/artifacts/feed/latest.p7s'", b"FIXTURE_ROOT / 'preview/artifacts/feed/latest.p7s'", 1),
]
for old, new, count in python_edits:
    assert python.count(old) == count, old
    python = python.replace(old, new)
all_new[python_rel] = python

fixtures = {}
snapshot_paths = ['scripts/native_r17_r2_delivery.py', 'infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json', 'infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication.mjs']
for rel in snapshot_paths:
    data = read(WORKER / 'prepared-snapshot-01' / rel)
    expected = next(item['preparedSnapshotSha256'] for item in hashes['sourceFiles'] if item['path'] == rel)
    assert sha(data) == expected
    fixtures['prepared-snapshot-01/' + rel] = data
for rel in ['preview/artifacts/feed/latest.json', 'preview/artifacts/feed/latest.p7s', 'predecessor12/latest.json', 'predecessor12/latest.p7s']:
    fixtures[rel] = read(WORKER / 'fixtures' / rel)

# All validation, including replacement counts, precedes any repository writes.
QA.mkdir(parents=True)
new_file(QA / '.gitattributes', b'* -text\n')
for rel, data in fixtures.items():
    new_file(QA / 'fixtures' / rel, data)
archive_paths = set()
archive_paths.update('prepared/' + item['path'] for item in hashes['sourceFiles'])
archive_paths.update('baseline/' + item['path'] for item in hashes['sourceFiles'])
archive_paths.update('prepared-snapshot-01/' + item['path'] for item in hashes['sourceFiles'])
archive_paths.update(item['path'] for item in seal['artifacts'] + seal['attempts'])
archive_paths.update('fixtures/' + path for path in fixtures if not path.startswith('prepared-snapshot-01/'))
archive_paths.update('fixtures/actual-cms13/' + Path(item['path']).name for item in hashes['actualRootIssuedProofCopies'])
archive_paths.update(['FREEZE-SEAL-01.json', 'PROPOSED-FIVE-FILE.patch', 'PROPOSED-READY-01.json'])
archive = QA / 'WORKER-BYTE-EXACT-PROOF.tar.gz'
inventory = []
with tarfile.open(archive, 'x:gz') as tar:
    for rel in sorted(archive_paths):
        data = read(WORKER / rel)
        info = tar.gettarinfo(str(WORKER / rel), arcname=rel)
        assert info.isfile()
        with (WORKER / rel).open('rb') as stream:
            tar.addfile(info, stream)
        inventory.append({'path': rel, 'bytes': len(data), 'sha256': sha(data)})
for name in ['FREEZE-SEAL-01.json', 'FINAL-RECEIPT-01.json', 'FINAL-HASHES-01.json', 'FINAL-TEST-COVERAGE-01.json', 'FINAL-README-01.md']:
    new_file(QA / name, read(WORKER / name))
new_file(QA / 'WORKER-INVENTORY.json', (json.dumps(inventory, indent=2) + '\n').encode())

for rel, data in all_new.items():
    with (PROJECT / rel).open('wb') as stream:
        stream.write(data)
    assert read(PROJECT / rel) == data

receipt = {'schema': 'mir2.native.preview-root-integration.v1', 'baseHead': head,
    'workerSealSha256': SEAL_SHA, 'productionFilesByteExact': [rel for rel in all_new if rel not in (node_rel, python_rel)],
    'testOnlyFixtureRelocations': {'node': len(node_edits), 'python': len(python_edits)},
    'before': before, 'after': [{'path': rel, 'bytes': len(data), 'sha256': sha(data)} for rel, data in all_new.items()],
    'fixtureFiles': [{'path': path, 'bytes': len(data), 'sha256': sha(data)} for path, data in fixtures.items()],
    'archive': {'bytes': archive.stat().st_size, 'sha256': sha(read(archive)), 'members': len(inventory)},
    'actualNetworkRequests': 0, 'livePublication': False, 'credentialReads': False, 'workerOriginalsChanged': False}
new_file(OUT / 'INTEGRATION-01.json', (json.dumps(receipt, indent=2) + '\n').encode())
print(json.dumps({'integrated': 5, 'fixtures': len(fixtures), 'archiveMembers': len(inventory), 'archiveSha256': receipt['archive']['sha256']}))
