// Unit policy fixtures only. Real immutable preview13 feed/CMS bytes are read,
// but crypto.DigestStream, FixedLengthStream, R2 and fetch below are Node models.
// No CMS admission is injected. Positive handler tests explicitly skip until a
// genuine new receipt has been issued and reviewed anchors/literal are rebound.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash, webcrypto} from 'node:crypto';
import {readFileSync} from 'node:fs';
import definition from '../src/native-r17-publication-plan.json' with {type: 'json'};
import {NATIVE_PLAN_SHA256, OPERATION_POLICY, STAGE_SCHEMA, validatePreparedPlan,
  validateNativePlan, stageEnvelopeTemplate, createNativeR17Handler} from '../src/native-r17-publication.mjs';

globalThis.fetch = async () => {throw new Error('outbound network disabled in unit fixtures');};
const FIXTURES = new URL('../../../../../fixtures/preview/', import.meta.url);
const FEED_BYTES = new Uint8Array(readFileSync(new URL('artifacts/feed/latest.json', FIXTURES)));
const CMS_BYTES = new Uint8Array(readFileSync(new URL('artifacts/feed/latest.p7s', FIXTURES)));
const FEED = JSON.parse(new TextDecoder().decode(FEED_BYTES));
const NOW = (FEED.createdUnix + 100) * 1000;
const MOCK_SECRET = 'public-fake-unit-secret-only';
const SKIP_PENDING_PROOF = definition.admission !== 'admitted'
  ? 'prepared/unadmitted: actual CMS/root receipt and reviewed anchors required' : false;
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const buffer = hash => Uint8Array.from(Buffer.from(hash, 'hex')).buffer;
const clone = value => JSON.parse(JSON.stringify(value));
function canonical(value) {
  const sort = v => Array.isArray(v) ? v.map(sort) : v && typeof v === 'object'
    ? Object.fromEntries(Object.keys(v).sort().map(k => [k, sort(v[k])])) : v;
  return new TextEncoder().encode(JSON.stringify(sort(value)) + '\n');
}
function request(route, body = {index: 0}, method = 'POST', auth = true) {
  return new Request('https://assets.mir2.obelisk.build/upload/native-r17' + route, {
    method, headers: {authorization: auth ? 'Bearer ' + MOCK_SECRET : 'wrong',
      'content-type': 'application/json'},
    ...(method === 'GET' || method === 'HEAD' ? {} : {body: JSON.stringify(body)}),
  });
}
function metadata(entry, bytes) {
  return {key: entry.r2Key, size: entry.size, httpEtag: '"' + entry.sha256.slice(0, 24) + '"',
    httpMetadata: {contentType: entry.contentType, cacheControl: entry.cacheControl},
    customMetadata: {sha256: entry.sha256}, checksums: {sha256: buffer(entry.sha256)}, bytes};
}
function pointerEntry(value) {
  const bytes = canonical(value);
  return {entry: {r2Key: definition.r2Prefix + 'channels/invited.json',
    size: bytes.length, sha256: sha(bytes), contentType: 'application/json', cacheControl: 'no-store'}, bytes};
}
class BucketModel {
  records = new Map(); calls = []; mutateBeforePointerPut; losePointerAck = false;
  loseObjectAck = false; hangPut = false; consumedBytes = 0; maxChunk = 0;
  seed(entry, bytes) {this.records.set(entry.r2Key, metadata(entry, bytes));}
  seedClosure() {for (const entry of definition.objects) this.seed(entry,
    entry.index === 0 ? FEED_BYTES : entry.index === 1 ? CMS_BYTES : undefined);}
  pointer(value) {const {entry, bytes} = pointerEntry(value); this.seed(entry, bytes);}
  async head(key) {this.calls.push({op: 'head', key}); const r = this.records.get(key); return r ? {...r} : null;}
  async get(key) {
    this.calls.push({op: 'get', key}); const r = this.records.get(key);
    if (!r) return null;
    return {...r, body: new Response(r.bytes ?? new Uint8Array()).body};
  }
  async put(key, body, options) {
    this.calls.push({op: 'put', key, options});
    assert.ok(options.sha256 instanceof ArrayBuffer && options.sha256.byteLength === 32);
    if (key.endsWith('/channels/invited.json')) this.mutateBeforePointerPut?.();
    const existing = this.records.get(key);
    if (options.onlyIf.get('if-none-match') === '*') {if (existing) return null;}
    else {
      assert.ok(key.endsWith('/channels/invited.json'), 'immutable object must remain create-only');
      assert.equal(options.onlyIf.get('if-none-match'), null);
      assert.ok(options.onlyIf.get('if-match'));
      if (!existing || existing.httpEtag !== options.onlyIf.get('if-match')) return null;
    }
    if (this.hangPut) return new Promise(() => {});
    const hash = createHash('sha256'); let size = 0; const kept = [];
    const consume = chunk => {
      assert.ok(chunk instanceof Uint8Array); size += chunk.length;
      this.consumedBytes += chunk.length; this.maxChunk = Math.max(this.maxChunk, chunk.length);
      hash.update(chunk);
      if (size <= 4096) kept.push(chunk.slice());
    };
    if (body instanceof ReadableStream) {
      const reader = body.getReader();
      try {while (true) {const r = await reader.read(); if (r.done) break; consume(r.value);}}
      finally {reader.releaseLock();}
    } else consume(body);
    const actual = hash.digest('hex');
    if (actual !== Buffer.from(options.sha256).toString('hex')) throw new Error('modeled R2 checksum rejection');
    // Model backend conditional check at COMMIT as well as at invocation.
    const latest = this.records.get(key);
    if (options.onlyIf.get('if-none-match') === '*') {if (latest) return null;}
    else if (!latest || latest.httpEtag !== options.onlyIf.get('if-match')) return null;
    const bytes = size <= 4096 ? Buffer.concat(kept) : undefined;
    const record = {key, size, httpEtag: '"' + actual.slice(0, 24) + '"',
      httpMetadata: options.httpMetadata, customMetadata: options.customMetadata,
      checksums: {sha256: buffer(actual)}, bytes};
    this.records.set(key, record);
    if ((this.losePointerAck && key.endsWith('/channels/invited.json'))
      || (this.loseObjectAck && !key.endsWith('/channels/invited.json'))) {
      throw new Error('modeled committed write with lost acknowledgment');
    }
    return {...record};
  }
}
function streamModels(stats) {
  return {
    fixedLengthStream(size) {
      stats.fixedLengths.push(size); let count = 0;
      return new TransformStream({
        transform(chunk, controller) {count += chunk.length; if (count > size) throw new Error('overrun'); controller.enqueue(chunk);},
        flush() {if (count !== size) throw new Error('underrun');},
      });
    },
    digestStream() {
      const hash = createHash('sha256'); let resolve, reject;
      const digest = new Promise((ok, bad) => {resolve = ok; reject = bad;});
      const stream = new WritableStream({
        write(bytes) {hash.update(bytes);},
        close() {resolve(Uint8Array.from(hash.digest()).buffer);}, abort(error) {reject(error);},
      });
      stream.digest = digest; return stream;
    },
  };
}
function fixture({originOverride, policy, now = NOW} = {}) {
  const bucket = new BucketModel(), calls = [], stats = {fixedLengths: [], aborted: 0};
  const fetch = async (url, options) => {
    calls.push(url);
    assert.equal(options.method, 'GET'); assert.equal(options.redirect, 'manual');
    assert.deepEqual(options.headers, {'accept-encoding': 'identity', 'cache-control': 'no-store'});
    options.signal.addEventListener('abort', () => {stats.aborted++;}, {once: true});
    const immutable = definition.objects.find(e => definition.originBase + e.originRelativePath === url);
    const current = url === definition.originBase + 'latest.json' ? definition.objects[0]
      : url === definition.originBase + 'latest.p7s' ? definition.objects[1] : null;
    const entry = immutable ?? current;
    assert.ok(entry, 'fixed source URLs only');
    if (originOverride) return originOverride(entry, options, !!current);
    assert.ok(entry.index === 0 || entry.index === 1, 'no fabricated artifact source bodies');
    const response = new Response(entry.index === 0 ? FEED_BYTES : CMS_BYTES,
      {headers: {'content-length': String(entry.size)}});
    response.arrayBuffer = response.text = response.json = response.clone = () => {
      throw new Error('artifact buffering/cloning forbidden');
    };
    return response;
  };
  const handle = createNativeR17Handler({crypto: webcrypto, fetch, now: () => now,
    ...streamModels(stats), ...(policy ? {policy} : {})});
  return {bucket, calls, stats, handle, env: {MIR2_R2_UPLOAD_SECRET: MOCK_SECRET, MIR2_ASSETS: bucket}};
}
function policyTest(name, body) {test(name, {skip: SKIP_PENDING_PROOF}, body);}

test('fixed13 closure and previous proof bind30 original game objects plus6 new objects', async () => {
  assert.equal(await validatePreparedPlan(definition, webcrypto), true);
  assert.equal(sha(canonical(definition)), NATIVE_PLAN_SHA256);
  assert.equal(definition.objects.length, 36);
  assert.equal(definition.objects.filter(e => e.path.startsWith('releases/game-')).length, 30);
  assert.equal(definition.candidate.sequence, 13);
  assert.equal(sha(FEED_BYTES), definition.objects[0].sha256);
  assert.equal(sha(CMS_BYTES), definition.objects[1].sha256);
  assert.equal(definition.preparation.requiredGameSourceRevision, '6032ef8b3e27dd97bad0b20c8676ef9f185db64b');
  assert.equal(definition.objects.reduce((n, e) => n + e.size, 0), 817719767);
});
test('default admission is closed; no fake passed/CMS or old receipt can admit13', async () => {
  if (!SKIP_PENDING_PROOF) return;
  await assert.rejects(validateNativePlan(definition, webcrypto), /prepared_release_unadmitted/);
  for (const alteration of [
    p => {p.admission = 'admitted';},
    p => {p.rootVerificationBase64 = p.predecessorProof.rootVerificationBase64;
      p.rootVerificationSha256 = p.predecessorProof.rootVerificationSha256;},
    p => {p.objects[35].sha256 = '0'.repeat(64);},
  ]) {
    const other = clone(definition); alteration(other);
    await assert.rejects(validateNativePlan(other, webcrypto), /native_plan_hash_mismatch/);
  }
});
test('authentication precedes storage/fetch/admission and authorized prepared operation fails closed', async () => {
  const f = fixture();
  assert.equal((await f.handle(request('/import', {index: 0}, 'POST', false), f.env)).status, 401);
  assert.equal(f.calls.length, 0); assert.equal(f.bucket.calls.length, 0);
  if (SKIP_PENDING_PROOF) {
    const denied = await f.handle(request('/import'), f.env);
    assert.equal(denied.status, 503); assert.equal((await denied.json()).error, 'prepared_release_unadmitted');
    assert.equal(f.calls.length, 0); assert.equal(f.bucket.calls.length, 0);
  }
});
test('stage template permits only null/exact12/exact13; old and forged stage scope stay distinct', () => {
  for (const value of [null, definition.knownPrevious, definition.candidate]) {
    assert.equal(stageEnvelopeTemplate(value).schema, STAGE_SCHEMA);
    assert.deepEqual(stageEnvelopeTemplate(value).expectedCurrent, value);
  }
  assert.throws(() => stageEnvelopeTemplate({...definition.knownPrevious, feedSha256: '0'.repeat(64)}),
    /unknown_observed_current/);
});
test('fixed111MB deadline policy is finite and transport margin exceeds worker budget', () => {
  const largest = Math.max(...definition.objects.map(e => e.size));
  assert.equal(largest, 111013376);
  assert.ok(largest / OPERATION_POLICY.slowStreamPolicyBytesPerSecond * 1000
    + OPERATION_POLICY.originHeaderMs + OPERATION_POLICY.r2SettleAllowanceMs < OPERATION_POLICY.importMs);
  assert.ok(OPERATION_POLICY.importControlSeconds * 1000 > OPERATION_POLICY.importMs);
  assert.ok(OPERATION_POLICY.promoteControlSeconds * 1000 > OPERATION_POLICY.promoteMs);
  assert.equal(OPERATION_POLICY.measuredSpeed, false);
  assert.equal(definition.preparation.actualDeadlinePolicyAccepted, false);
});

policyTest('first object import201 is create-only; actual small full-hash resume200 does not refetch', async () => {
  const f = fixture(); let response = await f.handle(request('/import'), f.env);
  assert.equal(response.status, 201); assert.equal((await response.json()).resumed, false);
  const writes = f.bucket.calls.filter(c => c.op === 'put');
  assert.equal(writes.length, 1); assert.equal(writes[0].options.onlyIf.get('if-none-match'), '*');
  assert.equal(f.bucket.consumedBytes, FEED_BYTES.length);
  response = await f.handle(request('/import'), f.env);
  assert.equal(response.status, 200); assert.equal((await response.json()).resumed, true);
  assert.equal(f.calls.length, 1);
});
policyTest('bad existing body or wrong stored checksum cannot count as immutable resume', async () => {
  const f = fixture(); f.bucket.seed(definition.objects[0], new Uint8Array(FEED_BYTES.length));
  const response = await f.handle(request('/import'), f.env);
  assert.equal(response.status, 409); assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 0);
  assert.equal(f.calls.length, 0);
});
policyTest('lost object ACK retains unknown and never retries; independent later stage hashes existing bytes', async () => {
  const f = fixture(); f.bucket.loseObjectAck = true;
  const response = await f.handle(request('/import'), f.env), result = await response.json();
  assert.equal(response.status, 502); assert.equal(result.objectWriteAttempted, true);
  assert.equal(result.objectOutcomeUnknown, true);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 1);
  f.bucket.loseObjectAck = false;
  const reconciled = await f.handle(request('/import'), f.env);
  assert.equal(reconciled.status, 200); assert.equal((await reconciled.json()).resumed, true);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 1);
});
policyTest('source redirect/encoding/length fail before any immutable write', async () => {
  for (const headers of [{status: 302}, {encoding: 'gzip'}, {length: 1158}]) {
    const f = fixture({originOverride: () => new Response(FEED_BYTES, {
      status: headers.status ?? 200, headers: {'content-length': String(headers.length ?? FEED_BYTES.length),
        ...(headers.encoding ? {'content-encoding': headers.encoding} : {})}})});
    const response = await f.handle(request('/import'), f.env);
    assert.equal(response.status, 502); assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 0);
  }
});
policyTest('scaled header deadline cancels upstream and never changes pointer', async () => {
  const f = fixture({policy: {...OPERATION_POLICY, originHeaderMs: 20, noProgressMs: 80, importMs: 120},
    originOverride: () => new Promise(() => {})});
  const response = await f.handle(request('/import'), f.env), result = await response.json();
  assert.equal(response.status, 504); assert.equal(result.error, 'origin_header_deadline');
  assert.equal(result.objectWriteAttempted, false); assert.ok(f.stats.aborted > 0);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 0);
});
policyTest('scaled total timeout bounds a stalled R2 put; cancellation cannot claim it never committed', async () => {
  const f = fixture({policy: {...OPERATION_POLICY, importMs: 50, noProgressMs: 30,
    originHeaderMs: 20, r2SettleAllowanceMs: 30}});
  f.bucket.hangPut = true;
  const response = await f.handle(request('/import'), f.env), result = await response.json();
  assert.equal(response.status, 504); assert.equal(result.objectWriteAttempted, true);
  assert.equal(result.objectOutcomeUnknown, true); assert.ok(f.stats.aborted > 0);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 1);
});
policyTest('null pointer creation uses only If-None-Match and reads exact13 after commit', async () => {
  const f = fixture(); f.bucket.seedClosure();
  const response = await f.handle(request('/promote', stageEnvelopeTemplate(null)), f.env);
  assert.equal(response.status, 200); const result = await response.json();
  assert.equal(result.pointerChanged, true); assert.equal(result.pointerOutcomeUnknown, false);
  const write = f.bucket.calls.find(c => c.op === 'put');
  assert.equal(write.options.onlyIf.get('if-none-match'), '*');
  assert.equal(write.options.onlyIf.get('if-match'), null);
  assert.deepEqual(f.calls, [definition.originBase + 'latest.json', definition.originBase + 'latest.p7s']);
});
policyTest('observed exact12 upgrade uses that actual ETag If-Match;13 is idempotent', async () => {
  const f = fixture(); f.bucket.seedClosure(); f.bucket.pointer(definition.knownPrevious);
  const {entry} = pointerEntry(definition.knownPrevious);
  const oldEtag = f.bucket.records.get(entry.r2Key).httpEtag;
  let response = await f.handle(request('/promote', stageEnvelopeTemplate(definition.knownPrevious)), f.env);
  assert.equal(response.status, 200);
  const writes = f.bucket.calls.filter(c => c.op === 'put');
  assert.equal(writes[0].options.onlyIf.get('if-match'), oldEtag);
  assert.equal(writes[0].options.onlyIf.get('if-none-match'), null);
  response = await f.handle(request('/promote', stageEnvelopeTemplate(definition.knownPrevious)), f.env);
  assert.equal(response.status, 200); assert.equal((await response.json()).alreadyPromoted, true);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 1);
});
policyTest('unknown/conflicting pointer or changed actual stage state rejects before put', async () => {
  for (const actual of [{...definition.knownPrevious, sequence: 11}, definition.knownPrevious]) {
    const f = fixture(); f.bucket.seedClosure(); f.bucket.pointer(actual);
    const response = await f.handle(request('/promote', stageEnvelopeTemplate(null)), f.env);
    assert.equal(response.status, 409); assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 0);
  }
});
policyTest('pointer race gets412 and preserves raced pointer; no overwrite retry', async () => {
  const f = fixture(); f.bucket.seedClosure(); f.bucket.pointer(definition.knownPrevious);
  f.bucket.mutateBeforePointerPut = () => {
    f.bucket.mutateBeforePointerPut = undefined; f.bucket.pointer({...definition.knownPrevious, sequence: 99});
  };
  const response = await f.handle(request('/promote', stageEnvelopeTemplate(definition.knownPrevious)), f.env);
  assert.equal(response.status, 412); const result = await response.json();
  assert.equal(result.pointerAttempted, true); assert.equal(result.pointerOutcomeUnknown, false);
  const records = [...f.bucket.records.values()].find(r => r.key.endsWith('/channels/invited.json'));
  assert.equal(JSON.parse(new TextDecoder().decode(records.bytes)).sequence, 99);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 1);
});
policyTest('lost pointer ACK retains unknown; separate retry reconciles exact13 without second write', async () => {
  const f = fixture(); f.bucket.seedClosure(); f.bucket.pointer(definition.knownPrevious); f.bucket.losePointerAck = true;
  let response = await f.handle(request('/promote', stageEnvelopeTemplate(definition.knownPrevious)), f.env);
  assert.equal(response.status, 502); const uncertain = await response.json();
  assert.equal(uncertain.pointerAttempted, true); assert.equal(uncertain.pointerOutcomeUnknown, true);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 1);
  f.bucket.losePointerAck = false;
  response = await f.handle(request('/promote', stageEnvelopeTemplate(definition.knownPrevious)), f.env);
  assert.equal(response.status, 200); assert.equal((await response.json()).alreadyPromoted, true);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 1);
});
policyTest('immutable13 preview cannot promote when current origin latest pair is still12', async () => {
  const prior = JSON.parse(Buffer.from(definition.predecessorProof.sourcePlanBase64, 'base64'));
  const oldFeed = readFileSync(new URL('../../../../../fixtures/predecessor12/latest.json', import.meta.url));
  assert.equal(sha(oldFeed), definition.knownPrevious.feedSha256);
  const f = fixture({originOverride: (entry, _options, current) => new Response(current
    ? oldFeed : (entry.index === 0 ? FEED_BYTES : CMS_BYTES),
    {headers: {'content-length': String(entry.size)}})});
  f.bucket.seedClosure(); f.bucket.pointer(prior.candidate);
  const response = await f.handle(request('/promote', stageEnvelopeTemplate(definition.knownPrevious)), f.env);
  assert.equal(response.status, 409); assert.equal((await response.json()).error, 'origin_feed_pair_changed');
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 0);
  assert.deepEqual(f.calls, [definition.originBase + 'latest.json']);
});
policyTest('old v1 receipt/changed candidate is rejected before heads or source fetch', async () => {
  for (const change of [e => {e.schema = 'mir2.windows.r2-native-stage.v1';},
    e => {e.candidate.sequence = 12;}, e => {e.rootVerificationSha256 = definition.predecessorProof.rootVerificationSha256;}]) {
    const f = fixture(), envelope = clone(stageEnvelopeTemplate(null)); change(envelope);
    const response = await f.handle(request('/promote', envelope), f.env);
    assert.equal(response.status, 400); assert.equal(f.bucket.calls.length, 0); assert.equal(f.calls.length, 0);
  }
});
policyTest('caller cannot select arbitrary URL/body/hash/key or normalized/query escape', async () => {
  for (const [route, body] of [['/import', {index: 0, url: 'https://other.invalid'}],
    ['/import', {path: 'https://other.invalid'}], ['/import?arbitrary=1', {index: 0}]]) {
    const f = fixture(); const response = await f.handle(request(route, body), f.env);
    assert.equal(response.status, 400); assert.equal(f.bucket.calls.length, 0); assert.equal(f.calls.length, 0);
  }
});

policyTest('fresh wrong SHA body cannot publish even with correct declared length', async () => {
  const f = fixture({originOverride: entry => new Response(new Uint8Array(entry.size),
    {headers: {'content-length': String(entry.size)}})});
  const response = await f.handle(request('/import'), f.env);
  assert.equal(response.status, 502); assert.equal(f.bucket.records.has(definition.objects[0].r2Key), false);
  const result = await response.json(); assert.equal(result.pointerChanged, false);
  assert.equal(result.objectOutcomeUnknown, true); // Reconcile required, even for a modeled rejection.
});
policyTest('concurrent same immutable key creates exactly once and never overwrites', async () => {
  const f = fixture();
  const responses = await Promise.all([f.handle(request('/import'), f.env), f.handle(request('/import'), f.env)]);
  assert.deepEqual(responses.map(r => r.status).sort(), [201, 412]);
  assert.equal(f.bucket.records.size, 1);
  const stored = f.bucket.records.get(definition.objects[0].r2Key);
  assert.equal(sha(stored.bytes), definition.objects[0].sha256);
  assert.equal(f.bucket.calls.filter(c => c.op === 'put').length, 2);
  for (const call of f.bucket.calls.filter(c => c.op === 'put')) assert.equal(call.options.onlyIf.get('if-none-match'), '*');
});
policyTest('no-progress source cancels partial stream with unknown put and no pointer writes', async () => {
  let cancelled = false;
  const f = fixture({policy: {...OPERATION_POLICY, noProgressMs: 30, importMs: 120,
    originHeaderMs: 20, r2SettleAllowanceMs: 30},
    originOverride: entry => new Response(new ReadableStream({
      start(controller) {controller.enqueue(FEED_BYTES.slice(0, 16));},
      cancel() {cancelled = true;},
    }), {headers: {'content-length': String(entry.size)}})});
  const response = await f.handle(request('/import'), f.env), result = await response.json();
  assert.equal(response.status, 504); assert.equal(result.error, 'operation_no_progress');
  assert.equal(result.objectOutcomeUnknown, true); assert.equal(result.pointerAttempted, false);
  assert.ok(cancelled); assert.equal(f.bucket.records.size, 0);
});

