"""Owned external data-only freeze audit; never invokes network, game or Git."""
from pathlib import Path
import ast
import base64
import difflib
import hashlib
import json
import re
import stat

BASE = Path(r"C:/mir2-playtest-releases/20261004-native-r18/native-updater-preview-publication-01")
ROOT = Path(r"C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3")
ACTUAL = Path(r"C:/mir2-playtest-releases/20261004-native-r18/current-signed-release-qa-01/publication-proof-01/verified")
FILES = [
    "scripts/native_r17_r2_delivery.py",
    "scripts/test_native_r17_r2_delivery.py",
    "infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication.mjs",
    "infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json",
    "infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs",
]

def raw(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1
    assert not getattr(info, "st_file_attributes", 0) & 0x400
    return path.read_bytes()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def inventory(path):
    data = raw(path)
    return {"path": str(path), "bytes": len(data), "sha256": sha(data)}

def read_json(path):
    return json.loads(raw(path))

def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")) + "\n").encode()

def emit(name, value):
    data = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode() if not isinstance(value, bytes) else value
    path = BASE / name
    with path.open("xb") as target:
        target.write(data)
    return inventory(path)

baseline = read_json(BASE / "baseline/INPUTS.json")
proposal = read_json(BASE / "PROPOSED-READY-01.json")
proposal_by_path = {x["Path"]: x for x in proposal["files"]}
rows = []
patch = []
root_rows = []
for entry in baseline["files"]:
    relative = entry["path"]
    before = raw(BASE / "baseline" / relative)
    frozen = raw(BASE / "prepared-snapshot-01" / relative)
    after = raw(BASE / "prepared" / relative)
    root = raw(ROOT / relative)
    assert sha(before) == entry["sha256"]
    assert sha(frozen) == proposal_by_path[relative]["PreparedSha"], relative
    assert root == before, relative
    rows.append({"path": relative, "baselineSha256": sha(before),
        "preparedSnapshotSha256": sha(frozen), "finalSha256": sha(after), "bytes": len(after)})
    root_rows.append(inventory(ROOT / relative))
    # Each unified hunk preserves physical line endings; no receipt is rewritten.
    patch.append("".join(difflib.unified_diff(
        before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True),
        fromfile="a/" + relative, tofile="b/" + relative)))
assert [x["path"] for x in rows] == FILES
patch_record = emit("FINAL-FIVE-FILE.patch", "".join(patch).encode())

literal_path = BASE / "prepared" / FILES[3]
literal = raw(literal_path)
plan = json.loads(literal)
source_plan_raw = base64.b64decode(plan["sourcePlanBase64"], validate=True)
root_raw = base64.b64decode(plan["rootVerificationBase64"], validate=True)
source_plan = json.loads(source_plan_raw)
root_proof = json.loads(root_raw)
assert sha(literal) == "9fd816a5fdf26a937d3d94a5b031c9e992fbb104f49832ba31a703587a0385f8"
assert sha(canonical(plan)) == "aa29c7a79fc5196677228f7ed476a42db9eb4ce4ef9ad6e74292b72cde750f9e"
assert sha(source_plan_raw) == plan["sourcePlanSha256"] == "335e80d1692c105e9423fb53a54d000fe3bffc6bc24ef71bfeedbdbe9a6f8a16"
assert sha(root_raw) == plan["rootVerificationSha256"] == "00984e502e2bcbe3fd32d6f6cf14818f8f46b57a1ba6294f6c8c06621b1f8fff"
assert raw(ACTUAL / "PUBLICATION-PLAN.json") == source_plan_raw
assert raw(ACTUAL / "ROOT-VERIFICATION.json") == root_raw
assert plan["admission"] == "admitted" and plan["candidate"]["sequence"] == 13
assert root_proof["sequence"] == 13 and len(root_proof) == 9
assert root_proof["passed"] is True and root_proof["candidateVerified"] is True and root_proof["cmsVerified"] is True
assert root_proof["sourceRevision"] == "48454bba7623694ca7432613af52bee28e83970e"
assert root_proof["feedSha256"] == plan["candidate"]["feedSha256"]
assert root_proof["signatureSha256"] == plan["candidate"]["signatureSha256"]
assert root_proof["objectsSha256"] == plan["objectsSha256"]
object_identity = lambda x: sorted((v["path"], v["size"], v["sha256"]) for v in x)
assert object_identity(source_plan["objects"]) == object_identity(plan["objects"])
assert len(plan["objects"]) == 36 and sum(v["size"] for v in plan["objects"]) == 817719767
old_plan_raw = raw(BASE / "baseline/source-publication-plan-12.json")
old_root_raw = raw(BASE / "baseline/root-verification-12.json")
assert sha(old_plan_raw) == "04bdb9d5f891bba38752e4ba4029db2d638dc7f4674d494ce0c6b5ab354f3b87"
assert sha(old_root_raw) == "6b36134597180ad2b423c2015c05b3c48447fbd766e858c2fb0ce6f45e2565b9"
assert base64.b64decode(plan["predecessorProof"]["sourcePlanBase64"], validate=True) == old_plan_raw
assert base64.b64decode(plan["predecessorProof"]["rootVerificationBase64"], validate=True) == old_root_raw
old_plan = json.loads(old_plan_raw)
old_objects = {v["path"]: (v["size"], v["sha256"]) for v in old_plan["objects"]}
unchanged = [v for v in plan["objects"] if old_objects.get(v["path"]) == (v["size"], v["sha256"])]
changed = [v for v in plan["objects"] if old_objects.get(v["path"]) != (v["size"], v["sha256"])]
assert len(unchanged) == 30 and len(changed) == 6
assert plan["promotionOriginPair"] == {"json": "latest.json", "signature": "latest.p7s"}

actual_copies = []
for name in ["PUBLICATION-PLAN.json", "ROOT-VERIFICATION.json", "PREPARE-PUBLICATION.json"]:
    assert raw(BASE / "fixtures/actual-cms13" / name) == raw(ACTUAL / name)
    actual_copies.append(inventory(BASE / "fixtures/actual-cms13" / name))

router_paths = [
    ROOT / "infra/cloudflare/mir2-r2-bulk-upload/src/index.ts",
    ROOT / "infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication.mjs",
    ROOT / "infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json"]
router_dependencies = [inventory(v) for v in router_paths]
assert router_dependencies[0]["sha256"] == "7aa43b7c6cffe6ff271fcd7199ed8be95bd30783dc5b72809d57688fadcd1f40"

node_command = read_json(BASE / "evidence/full-node-03.command.json")
python_command = read_json(BASE / "evidence/full-python-02.command.json")
for command in [node_command, python_command]:
    assert command["exitCode"] == 0 and command["timedOut"] is False
    assert command["before"] == command["after"]
    assert command["before"][-1]["sha256"] == router_dependencies[0]["sha256"]
node_log = raw(BASE / "evidence/full-node-03.stdout.log").decode()
assert "# tests 138" in node_log and "# pass 138" in node_log and "# skipped 0" in node_log
assert "# fail 0" in node_log and "# cancelled 0" in node_log
node_titles = re.findall(r"^# Subtest: (.*)$", node_log, re.MULTILINE)
assert len(node_titles) == 138
python_log = raw(BASE / "evidence/full-python-02.stderr.log").decode()
assert "Ran 64 tests" in python_log and python_log.rstrip().endswith("OK")
original_python = ast.parse(raw(BASE / "baseline" / FILES[1]).decode())
final_python = ast.parse(raw(BASE / "prepared" / FILES[1]).decode())
def methods(tree, classname):
    cls = next(v for v in tree.body if isinstance(v, ast.ClassDef) and v.name == classname)
    return sorted(v.name for v in cls.body if isinstance(v, ast.FunctionDef) and v.name.startswith("test_"))
assert methods(original_python, "DeliveryTests") == methods(final_python, "DeliveryTests")
assert len(methods(final_python, "DeliveryTests")) == 46
assert len(methods(final_python, "PreviewPreparationTests")) == 15
assert len(methods(final_python, "NetworkIdlePolicyTests")) == 3
baseline_node = raw(BASE / "baseline" / FILES[4]).decode()
final_node = raw(BASE / "prepared" / FILES[4]).decode()
retained_block = final_node.split("// Retained original107 cases, adapted only fixed release/approved policy fixtures.\n", 1)[1]
retained_block = retained_block.split("for (const authority of ['wrong.invalid'", 1)[0]
def signatures(text):
    return re.findall(r"(?<![\w.])test\(\s*(['\x22\x60])((?:\\.|(?!\1).)*?)\1", text, re.DOTALL)
assert signatures(baseline_node) == signatures(retained_block), "Original static test registrations must remain"
coverage = {
    "schema": "mir2.native.preview-offline-regression-coverage.v1",
    "node": {"count":138,"passed":138,"skipped":0,
        "original107RegisteredTitles":node_titles[22:129],
        "new22Titles":node_titles[:22],"reviewer9Titles":node_titles[129:],
        "originalStaticRegistrationSignaturesExact":True},
    "python": {"count":64,"passed":64,"skipped":0,
        "original46MethodsExact":methods(final_python,"DeliveryTests"),
        "new15Methods":methods(final_python,"PreviewPreparationTests"),
        "idle3Methods":methods(final_python,"NetworkIdlePolicyTests")},
    "scope": "Node platform models and fake HTTPSConnection transport only; public tiny feed/CMS bytes are genuine. Remaining34 metadata/CI-body models do not establish actual R2 or public closure.",
    "specificOpenCoverage": [
        "No actual current13 workerd/R2 binding acceptance (prior12 local platform receipt remains separately frozen).",
        "No actual HTTPS loopback or public network for this phase; idle/header/connect tests use fake sockets.",
        "No real successful111MB source stream; synthetic111MB is fully streamed and must fail actual EXE SHA.",
        "No original Linux POSIX openat CI execution; current Windows path guards exercised."]
}
coverage_record = emit("FINAL-TEST-COVERAGE-01.json", coverage)

evidence = [inventory(v) for v in sorted((BASE / "evidence").iterdir()) if v.is_file()]
fixture_records = [inventory(v) for v in sorted((BASE / "fixtures").rglob("*")) if v.is_file()]
hash_record = emit("FINAL-HASHES-01.json", {
    "schema": "mir2.native.preview-five-file-freeze.v1", "rootBaseline":baseline["rootRevision"],
    "updaterSource":"48454bba7623694ca7432613af52bee28e83970e",
    "gameSource":"6032ef8b3e27dd97bad0b20c8676ef9f185db64b",
    "sourceFiles":rows,"rootFiveSourcesExactBaseline":True,"rootSources":root_rows,
    "unchangedRouterDependencies":router_dependencies, "actualRootIssuedProofCopies":actual_copies,
    "publicFixtureInventory":fixture_records,"rawTestAttempts":evidence,
    "patch":patch_record,"coverage":coverage_record})

attempts = [
    {"name":"red-authority-late-01","outcome":"interrupted; fixture/harness only, not terminal9 outcome","note":"Unexpected accepted GET body was not cancelled before assertion. Partial authority failures retained; only owned process interrupted."},
    {"name":"red-authority-late-02","exitCode":1,"count":9,"pass":0,"fail":9,"skipped":0,"note":"Real unchanged-production exacthost/port and lateGET failures."},
    {"name":"red-network-idle-01","exitCode":1,"count":3,"pass":1,"fail":2,"note":"Real pre-fix body/header finite deadline failures; private longheader control passed."},
    {"name":"green-authority-late-01","exitCode":0,"count":9,"pass":9,"fail":0},
    {"name":"green-network-idle-01","exitCode":1,"count":3,"pass":2,"error":1,"note":"Artificial20ms connect budget included real system CA setup. Preserved. Fixture subsequently builds actual verified SSLContext before measured header/body phase."},
    {"name":"green-network-idle-02","exitCode":0,"count":3,"pass":3,"fail":0},
    {"name":"full-node-01","exitCode":1,"count":138,"pass":137,"fail":1,"note":"Initially diagnosed immediate sourcecancel expectation as asynchronous fixture assumption. That diagnosis proved incomplete in the next bounded observation."},
    {"name":"full-python-01","exitCode":1,"count":64,"pass":61,"fail":3,"note":"Old total bytes; old general CONTROL_SECONDS versus new import-specific budget; immutable prepared CLI expects failure exit2."},
    {"name":"full-node-02","exitCode":1,"count":138,"pass":137,"fail":1,"note":"Meaningful 250ms sourcecancel observation still failed: actual intermediate pipeThrough had no AbortSignal. Earlier fixture-only assumption rejected."},
    {"name":"full-python-02","exitCode":0,"count":64,"pass":64,"fail":0},
    {"name":"green-early-create-01","exitCode":0,"count":1,"pass":1,"fail":0,"note":"After same budget.signal connected to intermediate limiter link; no delete/retry."},
    {"name":"full-node-03","exitCode":0,"count":138,"pass":138,"fail":0,"skipped":0},
]
receipt = {
    "schema":"mir2.native.preview-publication-handoff.v1",
    "state":"admitted-from-actual-root-proof; offline-tested; not-published",
    "writeScope":FILES,"hashes":hash_record,"patch":patch_record,"coverage":coverage_record,
    "genuineProofAuthority":{"rootReceiptSha256":sha(root_raw),"sourcePlanSha256":sha(source_plan_raw),
        "issuer":"Parent actual pinned detached CMS + closed36 verifier, terminal0/28.860s; this phase only validates exact raw copies and cryptographic bindings.",
        "rootReceiptFields":list(root_proof),"selfIssuedCmsAdmission":False},
    "nativeLiteralSha256":sha(literal),"nativeCanonicalSha256":sha(canonical(plan)),
    "candidate":plan["candidate"],"knownPrevious":plan["knownPrevious"],
    "objectCount":36,"totalBytes":817719767,"unchangedGameObjects":30,
    "sixPreparationOnlyNewObjects":[{k:v[k] for k in ["index","path","size","sha256","originRelativePath"]} for v in changed],
    "newOriginUploadedOrVerified":False,"stageExecuted":False,"promoteExecuted":False,
    "actualCloudflareAuthUsed":False,"actualR2Acceptance":False,"actualNetworkRequests":0,
    "measuredDownloadAcceleration":False,"updaterOrGameSourceChanged":False,
    "deadlines":plan["operationPolicy"],"rawAttempts":attempts,
    "narrowFixtureAdaptations":[
        {"name":"early create race cancels blocked source and never retries unconditionally","change":"Immediate bool assertion -> bounded250ms independent source cancellation observer. The observer produced a second RED and required a real signal propagation repair; no assertion removed."},
        {"name":"test_literal_plan_and_two_real_tiny_objects_bound","change":"Original12 total817657896 -> exact signed13 total817719767; real tiny SHA and literal proof guards preserved."},
        {"name":"test_cancelled_connect_never_sends_auth_after_deadline","change":"Patch IMPORT_CONTROL_SECONDS instead of now unrelated CONTROL_SECONDS; after-deadline zero authenticated requests and lateconnectclose preserved."},
        {"name":"test_cli_blocks_before_secret_lookup_transport_or_network","change":"Frozen prepared helper documented failure exit2; secret/transport tripwires and no-call refusal assertions preserved."}],
    "productRepairs":["Exact authenticated authority before fetch/storage.","Read-only late bucket.get body cancellation; never put/delete reconciliation.","Python connect/header/after-header body finite policies using progress read1; private import41min preheader allowed.","Same AbortSignal applied to both intermediate limiter and terminal pipe links for import/existing read."],
    "openGates":["Six new immutable origin objects and current origin13 feedpair must be appended/verified by parent before any promotion.",
        "Real opaque Cloudflare authorization/deployment and R2 native condition/checksum behavior remain parent gates.",
        "Full36 public stored byte verification, range/cache behavior and desktop throughput require real deployment; offline models do not establish them.",
        "40min import/41min client/90s bodyidle is declared finite slowstream policy, not measured rate. CI overall stage deadline must cover import plus public reads.",
        "External tests use the approved exact root router and external public fixture paths. Root must keep/provide fixture layout or adapt only test input locations when integrating; source hashes bind this run."],
    "status":"FROZEN; parent review/integration only"
}
receipt_record = emit("FINAL-RECEIPT-01.json", receipt)
emit("FINAL-HANDOFF-01.md", (
    "# Fixed R17 updater13 publication preparation\n\n"
    "The five external files are frozen for parent review. Node138/138 and Python64/64 passed with zero skips. Original107 Node registrations and original46 Python methods remain present; full raw failures and interrupted attempt are preserved. No origin/R2/CI/auth/service/repository writes occurred.\n\n"
    "Actual parent-issued ROOT-VERIFICATION.json and PUBLICATION-PLAN.json bind sequence13, engine48454 and original6032 game to exact36 objects (817719767bytes). Their raw bytes and nine-field schema are copied unchanged; this phase did not issue or re-run CMS admission. Thirty game objects are unchanged. Six feed/engine/Bootstrap objects remain preparation-only at origin.\n\n"
    "Guards retain conditional append and SHA/native storedchecksum, full public readback requirements, actual pointer null/exact12/exact13, observed ETag CAS and pointer-last promotion. Promotion rechecks current origin latest13 pair; immutable13 staging cannot bypass current12. Lost ACK and consumed-put uncertainty remain explicit and no blind retry/delete occurs.\n\n"
    "New fixes enforce exact assets host/default443, finite route-specific header and after-header body idle budgets using read1, late read-only get-body cleanup, and intermediate pipeThrough AbortSignal propagation. The early-create failure was initially thought to be only an asynchronous fixture expectation; a bounded250ms observer disproved that. The real same-signal limiter fix then passed the original cancellation/no-retry control.\n\n"
    "FINAL-FIVE-FILE.patch applies only the five listed paths. FINAL-HASHES-01.json, FINAL-TEST-COVERAGE-01.json and FINAL-RECEIPT-01.json contain raw proof/dependency hashes, original registrations, every outcome and remaining gates. Tests are fake platform/transport models with genuine tiny feed/CMS fixture bytes, not current13 workerd/actualR2/public-speed acceptance. Parent owns fixture-location integration, public reader, auth and rollout.\n").encode())
print(json.dumps({"receipt":receipt_record,"patch":patch_record,"hashes":hash_record,
    "coverage":coverage_record,"sourceFiles":rows},ensure_ascii=False))

