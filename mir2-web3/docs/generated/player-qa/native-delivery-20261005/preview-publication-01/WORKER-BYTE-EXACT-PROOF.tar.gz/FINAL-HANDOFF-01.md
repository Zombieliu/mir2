# Fixed R17 updater13 publication preparation

The five external files are frozen for parent review. Node138/138 and Python64/64 passed with zero skips. Original107 Node registrations and original46 Python methods remain present; full raw failures and interrupted attempt are preserved. No origin/R2/CI/auth/service/repository writes occurred.

Actual parent-issued ROOT-VERIFICATION.json and PUBLICATION-PLAN.json bind sequence13, engine48454 and original6032 game to exact36 objects (817719767bytes). Their raw bytes and nine-field schema are copied unchanged; this phase did not issue or re-run CMS admission. Thirty game objects are unchanged. Six feed/engine/Bootstrap objects remain preparation-only at origin.

Guards retain conditional append and SHA/native storedchecksum, full public readback requirements, actual pointer null/exact12/exact13, observed ETag CAS and pointer-last promotion. Promotion rechecks current origin latest13 pair; immutable13 staging cannot bypass current12. Lost ACK and consumed-put uncertainty remain explicit and no blind retry/delete occurs.

New fixes enforce exact assets host/default443, finite route-specific header and after-header body idle budgets using read1, late read-only get-body cleanup, and intermediate pipeThrough AbortSignal propagation. The early-create failure was initially thought to be only an asynchronous fixture expectation; a bounded250ms observer disproved that. The real same-signal limiter fix then passed the original cancellation/no-retry control.

FINAL-FIVE-FILE.patch applies only the five listed paths. FINAL-HASHES-01.json, FINAL-TEST-COVERAGE-01.json and FINAL-RECEIPT-01.json contain raw proof/dependency hashes, original registrations, every outcome and remaining gates. Tests are fake platform/transport models with genuine tiny feed/CMS fixture bytes, not current13 workerd/actualR2/public-speed acceptance. Parent owns fixture-location integration, public reader, auth and rollout.
