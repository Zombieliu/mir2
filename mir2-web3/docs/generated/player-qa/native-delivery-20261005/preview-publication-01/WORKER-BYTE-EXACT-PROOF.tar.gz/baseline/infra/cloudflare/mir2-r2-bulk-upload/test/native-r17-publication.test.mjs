import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash, webcrypto} from 'node:crypto';
import worker from '../src/index.ts';
import definition from '../src/native-r17-publication-plan.json' with {type: 'json'};
import {createNativeR17Handler, validateNativePlan, stageEnvelopeTemplate,
  NATIVE_PLAN_SHA256} from '../src/native-r17-publication.mjs';

// No test may reach real HTTP or a credential. These are platform behavior
// models; native Workers/R2/CMS/network acceptance is deliberately separate.
globalThis.fetch = async () => {throw new Error('network disabled in offline fixtures');};

const MOCK_SECRET = 'not-a-real-credential-test-fixture';

for (const key of [
  'mir2/native/windows-invited/releases/protected.exe',
  '  ///mir2/native/windows-invited/channels/invited.json  ',
]) {
  test(`legacy PUT rejects reserved native prefix: ${key}`, async () => {
    const writes = [];
    const response = await worker.fetch(new Request(
      `https://assets.mir2.obelisk.build/upload?key=${encodeURIComponent(key)}`, {
        method: 'PUT', headers: {authorization: `Bearer ${MOCK_SECRET}`}, body: 'bad',
      }), {MIR2_R2_UPLOAD_SECRET: MOCK_SECRET,
        MIR2_ASSETS: {put: async (...args) => {writes.push(args); return {};}}});
    assert.equal(response.status, 403);
    assert.deepEqual(writes, []);
  });
}

test('unrelated legacy Web PUT retains its existing behavior', async () => {
  const writes = [];
  const response = await worker.fetch(new Request(
    'https://assets.mir2.obelisk.build/upload?key=mir2/v/web-fixture/a.txt', {
      method: 'PUT', headers: {authorization: `Bearer ${MOCK_SECRET}`, 'content-type': 'text/plain'}, body: 'ok',
    }), {MIR2_R2_UPLOAD_SECRET: MOCK_SECRET,
      MIR2_ASSETS: {put: async (...args) => {writes.push(args); return {};}}});
  assert.equal(response.status, 200);
  assert.equal(writes.length, 1);
  assert.equal(writes[0][0], 'mir2/v/web-fixture/a.txt');
  assert.equal(writes[0][2].onlyIf, undefined);
});

const feedBytes = Uint8Array.from(Buffer.from('eyJzY2hlbWEiOiJtaXIyLndpbmRvd3MudXBkYXRlLWZlZWQudjEiLCJjaGFubmVsIjoiaW52aXRlZCIsInBsYXRmb3JtIjoid2luZG93cy14NjQiLCJzZXF1ZW5jZSI6MTIsImNyZWF0ZWRVbml4IjoxNzkxMDgwMzA1LCJleHBpcmVzVW5peCI6MTc5MzY3MjMwNSwibWluQm9vdHN0cmFwIjoxLCJwcm90b2NvbCI6ImNyeXN0YWwtbWlyMi12MSIsImNvbnRlbnQiOiJtaXIyLndpbmRvd3MucGFja2FnZS1tYW5pZmVzdC52NCIsImdhbWUiOnsiZGlyZWN0b3J5IjoicmVsZWFzZXMvZ2FtZS1XTi1DQU5ESURBVEUtMjAyNjEwMDQtaW52aXRlZC0xNyIsImlkZW50aXR5IjoiV04tQ0FORElEQVRFLTIwMjYxMDA0LWludml0ZWQtMTciLCJtZXRhZGF0YSI6W3sicGF0aCI6IlBBQ0tBR0UtTUFOSUZFU1QuanNvbiIsInNpemUiOjI0MzYwMTc0LCJzaGEyNTYiOiJDRUFFMzY2QkVCQ0ExQzE5QzNGNTI5RUIyMkYwMTZDQ0M4MERGRjVCODY1NTY5NEU3NjY4MkUzMUFCMTJDQjE4In0seyJwYXRoIjoiVkVSU0lPTi5qc29uIiwic2l6ZSI6MTIyMSwic2hhMjU2IjoiMTQwOUUyMUM5RjFBRTdBMDRCNzE2MDNDRTEyMjBGRTM4QzM3RjIyMkQ1NDg1OUFGMjU5MkNERDcyQ0U5OUIxNiJ9LHsicGF0aCI6IlJFTEVBU0UtU1RBVEVNRU5ULmpzb24iLCJzaXplIjo3MDcsInNoYTI1NiI6IkU2NEE4RUY0RkM2MkU2RTlGNkZFMTY2MjUzMjFGQzhBODhBMEM4QzI5QTY2MUFFREE0NjAyNUIwODAxNURBODIifSx7InBhdGgiOiJSRUxFQVNFLVNUQVRFTUVOVC5wN3MiLCJzaXplIjoxNjE0LCJzaGEyNTYiOiJCRUU4NEI1NzRGNDNGNjQxMUVCMUJDM0FCMjNBM0NFMEMzODlCODUzRkIwRjhCNjNGNkFEOUJEQjEyODc4NTZFIn1dfSwiZW5naW5lIjp7ImRpcmVjdG9yeSI6InJlbGVhc2VzL3VwZGF0ZXItRkIzNTA1RDZEODREOTk3Qy1zMTIiLCJpZGVudGl0eSI6IjEiLCJtZXRhZGF0YSI6W3sicGF0aCI6IkVOR0lORS5qc29uIiwic2l6ZSI6NDIxLCJzaGEyNTYiOiIzMTQ2MTY5RkM2MTc2QTVFQUVBNDJCQUFBMDQzMEUzNDVGNUI3RTYxNDcwOTk3MUEwMEIwRDdEMEM0NzMyQkNGIn0seyJwYXRoIjoiRU5HSU5FLnA3cyIsInNpemUiOjE2MTQsInNoYTI1NiI6IjcwREMyREMxMUMzMTA1RkQ0REQyQjgwQkQ3RjlGQjMwRjdBN0Y0QjNCQkJGRTJBQTEzOTdDMDM4QzlCM0MxNEEifV19fQ==', 'base64'));
const signatureBytes = Uint8Array.from(Buffer.from('MIIGSgYJKoZIhvcNAQcCoIIGOzCCBjcCAQExDTALBglghkgBZQMEAgEwCwYJKoZIhvcNAQcBoIIEKjCCBCYwggKOoAMCAQICEEGdQHONjWm2Su1HznxL72AwDQYJKoZIhvcNAQELBQAwKzEpMCcGA1UEAwwgTWlyMiBJbnZpdGVkIFBsYXl0ZXN0IDIwMjYtMDktMjkwHhcNMjYwOTI4MTYxOTQzWhcNMjYxMjI3MTYyOTQzWjArMSkwJwYDVQQDDCBNaXIyIEludml0ZWQgUGxheXRlc3QgMjAyNi0wOS0yOTCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBANwYe0Ie9mrIOpKGSqGZoxI+X4c1qpsASY8vWPETnCnhT6NWsu1jd2j14PCMX5XeXlK876K25JPEjkkR0xo18lSYfsdtQyGHzTUkdMsg4eNtq8Hrf7RxXummGbufBAGRnPtzZ+cOq1K/ykjqFAG5TxYYc08CWePiPz/7tEEsir/qZ84XLsAUjy/ff3QuoGy7rOhbziFLRIMnJ/DTrG97csxXzHZP8RHK9WS+LrpRWyjr96+6EEfDbQo3KlmrD0mjPoKVqhVHbVP2HjVfy5LLW8wREMLc2KjJNKxlLM/288z3//yU7W50SSbQW/Rb3dqzls0LcgTLuoooXfxqvy3+0HjV5Ceix+dt+RLboHCJJCBDzPXZ3QKSleUs0xUsMAFxPUjGBT0EwSSt5h9Hc9vWGa2UavLvNB8Dg6zOZI8nbf6w7Z2ksRYX/CoQPGjlECmmkopuuUPTkH0nsHVjJrQnd2AArkBpjyHKqGpFZOytFlTPBkZRVNsaxZ2rgIcB6R/E+QIDAQABo0YwRDAOBgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFP6W1p1O/6LNZvtKwPn+2cWW+ifMMA0GCSqGSIb3DQEBCwUAA4IBgQDHfTrA24HutGrDOo9pWeA6lX4g8vIccSaXz1ZFF9Xt99yQfDAzDYVB+vMd8Xxs/J59H+eGW4iWUt6IDgRf3/WkB7ShTrMFOQgeWCgZ0p6nUjR9BQE2EN/pdPhm0INK80Bf0kbBBocg6clnSOXrhAZZHWeXx9vXbGdtmAGLhrHV6fivlcX3a19qrOvcnX5vwAFkygOmBew0rM2BkY+1JeDKs3aIBpARlZcxzTtX6H+mbtXEh3vM+wOaWZA0nBb8PoMNNQFVjJlzyDcMfslglNm6af2uCY8DBSj1COxW7pPLopvR66VE5/FNK+REBEnai3EPNnqo23pAuH+5VZCqDtKqDKg518ebZg63otIkINlG4eLEoQ5vP+Ld4/D3lQaqTPIdWu7JHNoGQIjdveqtpYnc/k3nJnPsJMXV9CIz7Ur14/OpiOIicw1QWkYIC87jONq3oJUuW8gdpKou4nr63Bl0RGEVGJoz3aOf0pKfVXZ0StV55giDWuCGGVoF9nLYTWExggHmMIIB4gIBATA/MCsxKTAnBgNVBAMMIE1pcjIgSW52aXRlZCBQbGF5dGVzdCAyMDI2LTA5LTI5AhBBnUBzjY1ptkrtR858S+9gMAsGCWCGSAFlAwQCATALBgkqhkiG9w0BAQEEggGAOyPhjm/jCulXqCLdKZydmEDJLTKLw2rwlgM2l+YqtOStXfHgRJ1Ra6b3kzQU2b9nZCNfqJD+FP73T2hH9o3Z0vM26KliY4G33LSdX3iX4FnkhMqqIP2tOmKwHFj3gfG6aNogW1l2VOHSCU//r8jCBTJLeGd/ll5+m/F5qgdrZ/EPgKsmYuNnP4Expsc8m8E4wEBAULoD6swaj1JnHB1x0y3RHatSEYrxD6tDmgOup24pQ3vEnOKZK0asYnRmZYg1Pf8u66H2a/ga/qdYsdqccfWT7IIetiOCjy7bS2x5N8sPeikxX2nu3en/J5MGC6QCyLa+1kjJGIx8QRbsv/ryVWCRK3TnU3Q4J2LVZEg58hSAbzIufFi3ldj9tDh6iM4qjX8gqbq95E86XJ1G25s9q4xPa+yPGnBxjg+41XFHkbEjo4CsUmdGQadG7GPD05N6rJyrONHWypLY9LI6oK6IjlNsaUfdmKzAfQGhkf+uWfez+LZs4QkqrrMoLzmfAcLi', 'base64'));
const feed = JSON.parse(new TextDecoder().decode(feedBytes));
const NOW = (feed.createdUnix + 100) * 1000;
const bytesFor = entry => entry.index === 0 ? feedBytes : entry.index === 1 ? signatureBytes : undefined;
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const asBuffer = value => Uint8Array.from(Buffer.from(value, 'hex')).buffer;
const clone = value => JSON.parse(JSON.stringify(value));
const jsonHeaders = {authorization: `Bearer ${MOCK_SECRET}`, 'content-type': 'application/json'};
const request = (endpoint, method = 'POST', body = {index: 0}, headers = jsonHeaders) =>
  new Request('https://assets.mir2.obelisk.build/upload/native-r17' + endpoint, {
    method, headers, ...(method === 'GET' || method === 'HEAD' ? {} : {body: JSON.stringify(body)}),
  });

function metadata(entry, bytes = bytesFor(entry)) {
  return {key: entry.r2Key, size: entry.size, httpEtag: '"' + entry.sha256.slice(0, 24) + '"',
    httpMetadata: {contentType: entry.contentType, cacheControl: entry.cacheControl},
    customMetadata: {sha256: entry.sha256}, checksums: {sha256: asBuffer(entry.sha256)}, bytes};
}
class BucketModel {
  records = new Map(); calls = []; forcedConflict = new Set(); bytesRead = 0;
  maxChunk = 0; throwOnPut; throwAfterPointerCommit; throwPointerReadAfterWrite = false;
  seed(entry, bytes) {this.records.set(entry.r2Key, metadata(entry, bytes));}
  seedClosure() {for (const entry of definition.objects) this.seed(entry);}
  async head(key) {
    this.calls.push({operation: 'head', key});
    const record = this.records.get(key); return record ? {...record} : null;
  }
  async get(key) {
    this.calls.push({operation: 'get', key});
    if (this.throwPointerReadAfterWrite && key.endsWith('/channels/invited.json') && this.records.has(key)) {
      throw new Error('injected private storage failure ' + MOCK_SECRET);
    }
    const record = this.records.get(key);
    if (!record) return null;
    const result = {...record, body: new Response(record.bytes ?? new Uint8Array()).body};
    result.text = result.arrayBuffer = () => {throw new Error('artifact buffering forbidden');};
    return result;
  }
  async put(key, body, options) {
    this.calls.push({operation: 'put', key, options});
    assert.equal(options.onlyIf?.get('if-none-match'), '*', 'every native write is create-only');
    assert.ok(options.sha256 instanceof ArrayBuffer && options.sha256.byteLength === 32,
      'native backend checksum is the unambiguous 32-byte SHA256');
    if (this.forcedConflict.has(key) || this.records.has(key)) return null;
    if (this.throwOnPut) throw new Error('injected private put failure ' + MOCK_SECRET);
    const sha = createHash('sha256'); let size = 0; const chunks = [];
    const consume = chunk => {
      size += chunk.byteLength; this.bytesRead += chunk.byteLength;
      this.maxChunk = Math.max(this.maxChunk, chunk.byteLength); sha.update(chunk);
      if (size <= 65536) chunks.push(chunk.slice());
    };
    if (body instanceof ReadableStream) {
      const reader = body.getReader();
      try {while (true) {const result = await reader.read(); if (result.done) break; consume(result.value);}}
      finally {reader.releaseLock();}
    } else consume(body);
    const actual = sha.digest('hex');
    if (actual !== Buffer.from(options.sha256).toString('hex')) throw new Error('backend checksum mismatch');
    const bytes = size <= 65536 ? new Uint8Array(size) : undefined;
    if (bytes) {let offset = 0; for (const chunk of chunks) {bytes.set(chunk, offset); offset += chunk.length;}}
    const record = {key, size, httpEtag: '"' + actual.slice(0, 24) + '"',
      httpMetadata: {...options.httpMetadata}, customMetadata: {...options.customMetadata},
      checksums: {sha256: asBuffer(actual)}, bytes};
    this.records.set(key, record);
    if (this.throwAfterPointerCommit && key.endsWith('/channels/invited.json')) {
      throw new Error('injected uncertain commit ' + MOCK_SECRET);
    }
    return {...record};
  }
}
function platformModels(stats) {
  return {
    fixedLengthStream(size) {
      stats.fixedSizes.push(size); let count = 0;
      return new TransformStream({
        transform(chunk, controller) {
          count += chunk.byteLength;
          if (count > size) throw new Error('FixedLengthStream overrun');
          controller.enqueue(chunk);
        },
        flush() {if (count !== size) throw new Error('FixedLengthStream underrun');},
      });
    },
    digestStream() {
      const sha = createHash('sha256'); let resolve, reject;
      const digest = new Promise((ok, error) => {resolve = ok; reject = error;});
      const stream = new WritableStream({
        write(bytes) {stats.digestBytes += bytes.byteLength; sha.update(bytes);},
        close() {resolve(Uint8Array.from(sha.digest()).buffer);},
        abort(error) {reject(error);},
      });
      stream.digest = digest; return stream;
    },
  };
}
function fixture({originOverride, now = NOW, fixedLengthStream} = {}) {
  const bucket = new BucketModel(); const calls = [];
  const stats = {fixedSizes: [], digestBytes: 0};
  const fetch = async (url, options) => {
    calls.push({url, options});
    const entry = definition.objects.find(item => definition.originBase + item.originRelativePath === url);
    assert.ok(entry, 'only a literal fixed-origin object may be fetched');
    assert.equal(options.method, 'GET'); assert.equal(options.redirect, 'manual');
    assert.deepEqual(options.headers, {'accept-encoding': 'identity', 'cache-control': 'no-store'});
    assert.equal(options.headers.authorization, undefined); assert.equal(options.headers.cookie, undefined);
    if (originOverride) return originOverride(entry, options);
    assert.ok(bytesFor(entry), 'this offline fixture has actual small source bytes only');
    const response = new Response(bytesFor(entry), {headers: {'content-length': String(entry.size)}});
    response.arrayBuffer = response.text = response.json = response.clone = () => {
      throw new Error('buffering/cloning origin artifact forbidden');
    };
    return response;
  };
  const models = platformModels(stats);
  const handle = createNativeR17Handler({crypto: webcrypto, fetch, now: () => now,
    ...models, ...(fixedLengthStream ? {fixedLengthStream} : {})});
  return {bucket, calls, stats, handle,
    env: {MIR2_R2_UPLOAD_SECRET: MOCK_SECRET, MIR2_ASSETS: bucket}};
}

test('source proof and actual small feed/signature match literal closure', async () => {
  assert.equal(hash(feedBytes), definition.objects[0].sha256);
  assert.equal(hash(signatureBytes), definition.objects[1].sha256);
  assert.equal(await validateNativePlan(definition, webcrypto), true);
  assert.equal(definition.objects.length, 36);
  assert.equal(definition.objects.filter(entry => entry.path.startsWith('installers/'))[0].originRelativePath,
    'releases/bootstrap-WN-CANDIDATE-20261004-invited-17/Numeron-Legend-of-Rebirth-20261004-r17-Bootstrap.exe');
});

for (const change of ['candidate', 'object', 'root', 'origin', 'installer']) {
  test(`changed frozen plan cannot redefine authority: ${change}`, async () => {
    const changed = clone(definition);
    if (change === 'candidate') changed.candidate.sequence++;
    if (change === 'object') changed.objects[0].sha256 = '0'.repeat(64);
    if (change === 'root') changed.rootVerificationBase64 = Buffer.from('{"cmsVerified":true}').toString('base64');
    if (change === 'origin') changed.originBase = 'https://attacker.invalid/';
    if (change === 'installer') changed.objects[2].originRelativePath = 'latest.json';
    await assert.rejects(validateNativePlan(changed, webcrypto), /native_plan_hash_mismatch/);
  });
}

for (const endpoint of ['/import', '/promote', '/objects/0', '/pointer']) {
  test(`unauthorized request precedes every fetch/storage operation: ${endpoint}`, async () => {
    const f = fixture(); const method = endpoint.startsWith('/objects') || endpoint === '/pointer' ? 'GET' : 'POST';
    const response = await f.handle(request(endpoint, method, {}, {'content-type': 'application/json'}), f.env);
    assert.equal(response.status, 401); assert.equal(f.calls.length, 0); assert.equal(f.bucket.calls.length, 0);
  });
}
test('index dispatch reaches native authorization before old PUT-only gate', async () => {
  const response = await worker.fetch(request('/import', 'POST', {}, {'content-type': 'application/json'}), {});
  assert.equal(response.status, 401);
});

for (const input of [
  {index: 0, url: 'https://attacker.invalid/'}, {index: 0, sha256: '0'.repeat(64)},
  {index: 0, key: 'mir2/native/windows-invited/channels/invited.json'}, {index: 0, path: definition.objects[0].path},
  {index: -1}, {index: 36}, {index: 0.1}, {index: '0'}, {path: 'latest.json'},
  {path: '../channels/invited.json'}, {path: 'https://attacker.invalid/'}, [], null,
]) {
  test(`import rejects caller authority input: ${JSON.stringify(input)}`, async () => {
    const f = fixture(); const response = await f.handle(request('/import', 'POST', input), f.env);
    assert.equal(response.status, 400); assert.equal(f.calls.length, 0); assert.equal(f.bucket.calls.length, 0);
  });
}
for (const endpoint of ['/import?anything=1', '/import?', '/objects/00', '/objects/36',
  '/objects/%30', '/objects/0/', '/arbitrary', '/pointer/']) {
  test(`native path/query is literal only: ${endpoint}`, async () => {
    const f = fixture(); const response = await f.handle(request(endpoint, 'GET'), f.env);
    assert.ok([400, 404, 405].includes(response.status));
    assert.equal(f.calls.length, 0); assert.equal(f.bucket.calls.length, 0);
  });
}
for (const body of ['{"index":0,"index":1}', '{"index":0,"\\u0069ndex":1}',
  '{"index":0} trailing', '\ufeff{"index":0}', '{"index":' + '['.repeat(15) + '0' + ']'.repeat(15) + '}']) {
  test(`strict request JSON rejects ambiguity/complexity: ${body.slice(0, 45)}`, async () => {
    const f = fixture(); const response = await f.handle(new Request(
      'https://assets.mir2.obelisk.build/upload/native-r17/import', {method: 'POST', headers: jsonHeaders, body}), f.env);
    assert.equal(response.status, 400); assert.equal(f.bucket.calls.length, 0); assert.equal(f.calls.length, 0);
  });
}
test('actual request stream and declared length are independently bounded', async () => {
  for (const [body, headers] of [
    [' '.repeat(1025), jsonHeaders], ['{"index":0}', {...jsonHeaders, 'content-length': '1025'}],
    ['{"index":0}', {...jsonHeaders, 'content-length': '1'}],
    ['{"index":0}', {...jsonHeaders, 'content-encoding': 'gzip'}],
    ['{"index":0}', {authorization: `Bearer ${MOCK_SECRET}`, 'content-type': 'text/plain'}],
  ]) {
    const f = fixture(); const response = await f.handle(new Request(
      'https://assets.mir2.obelisk.build/upload/native-r17/import', {method: 'POST', headers, body}), f.env);
    assert.ok([400, 413, 415].includes(response.status)); assert.equal(f.bucket.calls.length, 0);
  }
});

for (const input of [{index: 0}, {path: definition.objects[0].path}, {index: 1}]) {
  test(`actual signed small object streams with checksum/create-only and read-after-write: ${JSON.stringify(input)}`, async () => {
    const f = fixture(); const response = await f.handle(request('/import', 'POST', input), f.env);
    assert.equal(response.status, 201); const body = await response.json();
    assert.equal(body.resumed, false); assert.equal(body.pointerChanged, false);
    const entry = definition.objects[body.index]; const write = f.bucket.calls.find(call => call.operation === 'put');
    assert.equal(write.key, entry.r2Key); assert.equal(Buffer.from(write.options.sha256).toString('hex'), entry.sha256);
    assert.equal(write.options.onlyIf.get('if-none-match'), '*');
    assert.deepEqual(write.options.httpMetadata, {contentType: entry.contentType, cacheControl: entry.cacheControl});
    assert.deepEqual(write.options.customMetadata, {sha256: entry.sha256});
    assert.equal(f.bucket.calls.at(-1).operation, 'head'); assert.equal(f.calls.length, 1);
    assert.deepEqual(f.stats.fixedSizes, [entry.size]); assert.equal(f.bucket.records.size, 1);
  });
}
test('exact existing object resumes only after full incremental hash and metadata', async () => {
  const f = fixture(); f.bucket.seed(definition.objects[0]);
  const response = await f.handle(request('/import'), f.env);
  assert.equal(response.status, 200); assert.equal((await response.json()).resumed, true);
  assert.equal(f.stats.digestBytes, feedBytes.length); assert.equal(f.calls.length, 0);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 0);
});
for (const change of ['body', 'short', 'extra', 'size', 'etag', 'weak-etag', 'custom-sha',
  'stored-sha', 'missing-checksum', 'mime', 'cache', 'encoding', 'key']) {
  test(`existing immutable mismatch cannot resume/overwrite: ${change}`, async () => {
    const f = fixture(); const entry = definition.objects[0]; f.bucket.seed(entry);
    const record = f.bucket.records.get(entry.r2Key);
    if (change === 'body') {record.bytes = feedBytes.slice(); record.bytes[0] ^= 1;}
    if (change === 'short') record.bytes = feedBytes.slice(1);
    if (change === 'extra') record.bytes = new Uint8Array([...feedBytes, 0]);
    if (change === 'size') record.size--;
    if (change === 'etag') record.httpEtag = 'unquoted';
    if (change === 'weak-etag') record.httpEtag = 'W/"weak"';
    if (change === 'custom-sha') record.customMetadata.sha256 = '0'.repeat(64);
    if (change === 'stored-sha') record.checksums.sha256 = asBuffer('0'.repeat(64));
    if (change === 'missing-checksum') delete record.checksums.sha256;
    if (change === 'mime') record.httpMetadata.contentType = 'text/html';
    if (change === 'cache') record.httpMetadata.cacheControl = 'no-store';
    if (change === 'encoding') record.httpMetadata.contentEncoding = 'gzip';
    if (change === 'key') record.key = 'mir2/other';
    const response = await f.handle(request('/import'), f.env);
    assert.equal(response.status, 409); assert.equal(f.calls.length, 0);
    assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 0);
  });
}

for (const failure of ['301', '302', '307', '206', '404', 'gzip', 'missing-length',
  'wrong-length', 'noncanonical-length', 'short-stream', 'extra-stream', 'wrong-sha']) {
  test(`origin contract fails closed: ${failure}`, async () => {
    const f = fixture({originOverride(entry) {
      let bytes = feedBytes.slice(); const headers = {'content-length': String(entry.size)};
      let status = 200;
      if (/^\d+$/.test(failure)) {status = Number(failure); headers.location = 'https://attacker.invalid/';}
      if (failure === 'gzip') headers['content-encoding'] = 'gzip';
      if (failure === 'missing-length') delete headers['content-length'];
      if (failure === 'wrong-length') headers['content-length'] = String(entry.size + 1);
      if (failure === 'noncanonical-length') headers['content-length'] = '0' + entry.size;
      if (failure === 'short-stream') bytes = bytes.slice(1);
      if (failure === 'extra-stream') bytes = new Uint8Array([...bytes, 0]);
      if (failure === 'wrong-sha') bytes[0] ^= 1;
      return new Response(bytes, {status, headers});
    }});
    const response = await f.handle(request('/import'), f.env);
    assert.equal(response.status, 502); assert.equal(f.bucket.records.size, 0);
    assert.equal((await response.json()).pointerChanged, false);
    assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length,
      ['short-stream', 'extra-stream', 'wrong-sha'].includes(failure) ? 1 : 0);
  });
}
test('early create race cancels blocked source and never retries unconditionally', {timeout: 3000}, async () => {
  let cancelled = false;
  const f = fixture({originOverride(entry) {
    let emitted = false;
    return new Response(new ReadableStream({
      pull(controller) {if (!emitted) {emitted = true; controller.enqueue(new Uint8Array([0]));}},
      cancel() {cancelled = true;},
    }), {headers: {'content-length': String(entry.size)}});
  }});
  f.bucket.forcedConflict.add(definition.objects[0].r2Key);
  const response = await f.handle(request('/import'), f.env);
  assert.equal(response.status, 412); assert.ok(cancelled);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 1);
  assert.equal(f.bucket.records.size, 0);
});
test('runtime without FixedLengthStream refuses before origin request', async () => {
  const f = fixture({fixedLengthStream() {throw new Error('not present');}});
  const response = await f.handle(request('/import'), f.env);
  assert.equal(response.status, 503); assert.equal(f.calls.length, 0);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 0);
});
test('111MB artifact is consumed in 64KiB chunks, checksum rejects synthetic bytes without commit', async () => {
  const entry = definition.objects.find(item => item.path.endsWith('/mir2-platform-windows.exe'));
  let largestSourceChunk = 0;
  const f = fixture({originOverride(actual) {
    assert.equal(actual.index, entry.index); let left = actual.size;
    const stream = new ReadableStream({pull(controller) {
      if (!left) return controller.close();
      const size = Math.min(65536, left); largestSourceChunk = Math.max(largestSourceChunk, size);
      left -= size; controller.enqueue(new Uint8Array(size));
    }});
    return new Response(stream, {headers: {'content-length': String(actual.size)}});
  }});
  const response = await f.handle(request('/import', 'POST', {index: entry.index}), f.env);
  assert.equal(response.status, 502); assert.equal(f.bucket.bytesRead, 111013376);
  assert.equal(f.bucket.maxChunk, 65536); assert.equal(largestSourceChunk, 65536);
  assert.deepEqual(f.stats.fixedSizes, [111013376]); assert.equal(f.bucket.records.size, 0);
});

test('authenticated native GET/HEAD are limited, byte exact and no-store', async () => {
  const f = fixture(); f.bucket.seed(definition.objects[0]);
  for (const method of ['GET', 'HEAD']) {
    const response = await f.handle(request('/objects/0', method), f.env);
    assert.equal(response.status, 200); assert.equal(response.headers.get('cache-control'), 'no-store');
    assert.equal(response.headers.get('x-mir2-native-plan-sha256'), NATIVE_PLAN_SHA256);
    assert.equal(response.headers.get('x-mir2-stored-sha256'), hash(feedBytes));
    if (method === 'GET') assert.equal(hash(new Uint8Array(await response.arrayBuffer())), hash(feedBytes));
    else assert.equal(response.body, null);
  }
  const missing = await f.handle(request('/objects/1', 'HEAD'), f.env);
  assert.equal(missing.status, 404); assert.equal(missing.headers.get('cache-control'), 'no-store');
});
test('GET never serves an object whose stored checksum was changed', async () => {
  const f = fixture(); f.bucket.seed(definition.objects[0]);
  f.bucket.records.get(definition.objects[0].r2Key).checksums.sha256 = asBuffer('0'.repeat(64));
  const response = await f.handle(request('/objects/0', 'GET'), f.env);
  assert.equal(response.status, 409); assert.equal(f.calls.length, 0);
});

for (const change of ['missing', 'not-passed', 'mode', 'plan', 'root', 'table', 'closure',
  'candidate', 'expected-current', 'pointer-changed', 'public-false', 'public-host',
  'missing-object', 'extra-object', 'altered-size', 'reordered', 'extra-field']) {
  test(`promote rejects incomplete/forged bound stage: ${change}`, async () => {
    const f = fixture(); f.bucket.seedClosure(); const stage = stageEnvelopeTemplate();
    if (change === 'missing') delete stage.verifiedObjects;
    if (change === 'not-passed') stage.passed = false;
    if (change === 'mode') stage.mode = 'promote';
    if (change === 'plan') stage.planSha256 = '0'.repeat(64);
    if (change === 'root') stage.rootVerificationSha256 = '0'.repeat(64);
    if (change === 'table') stage.nativePlanSha256 = '0'.repeat(64);
    if (change === 'closure') stage.objectsSha256 = '0'.repeat(64);
    if (change === 'candidate') stage.candidate.sequence = 13;
    if (change === 'expected-current') stage.expectedCurrent = clone(stage.candidate);
    if (change === 'pointer-changed') stage.pointerChanged = true;
    if (change === 'public-false') stage.publicVerified = false;
    if (change === 'public-host') stage.publicBase = 'https://attacker.invalid/';
    if (change === 'missing-object') stage.verifiedObjects.pop();
    if (change === 'extra-object') stage.verifiedObjects.push(stage.verifiedObjects[0]);
    if (change === 'altered-size') stage.verifiedObjects[0].size--;
    if (change === 'reordered') stage.verifiedObjects.reverse();
    if (change === 'extra-field') stage.secret = 'must not be reflected';
    const response = await f.handle(request('/promote', 'POST', stage), f.env);
    assert.equal(response.status, 400); assert.equal(f.bucket.calls.length, 0); assert.equal(f.calls.length, 0);
  });
}
for (const change of ['installer-missing', 'ordinary-missing', 'stored-sha', 'cache']) {
  test(`complete stage cannot bypass actual R2 metadata: ${change}`, async () => {
    const f = fixture(); f.bucket.seedClosure();
    const entry = change === 'installer-missing' ? definition.objects[2] : definition.objects.at(-1);
    if (change.endsWith('missing')) f.bucket.records.delete(entry.r2Key);
    if (change === 'stored-sha') f.bucket.records.get(entry.r2Key).checksums.sha256 = asBuffer('0'.repeat(64));
    if (change === 'cache') f.bucket.records.get(entry.r2Key).httpMetadata.cacheControl = 'no-store';
    const response = await f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env);
    assert.equal(response.status, 409); assert.equal(f.calls.length, 0);
    assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 0);
  });
}
for (const change of ['json', 'signature', 'expired', 'not-created']) {
  test(`promotion rereads exact unexpired origin pair: ${change}`, async () => {
    const f = fixture({now: change === 'expired' ? feed.expiresUnix * 1000
      : change === 'not-created' ? (feed.createdUnix - 1) * 1000 : NOW,
    originOverride(entry) {
      const bytes = bytesFor(entry).slice();
      if ((change === 'json' && entry.index === 0) || (change === 'signature' && entry.index === 1)) bytes[0] ^= 1;
      return new Response(bytes, {headers: {'content-length': String(entry.size)}});
    }});
    f.bucket.seedClosure();
    const response = await f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env);
    assert.equal(response.status, 409); assert.equal(f.bucket.calls.filter(call => call.operation === 'head').length, 36);
    assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 0);
  });
}
test('only after 36 checks and source pair does pointer create; exact retry never rewrites', async () => {
  const f = fixture(); f.bucket.seedClosure();
  const first = await f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env);
  assert.equal(first.status, 200); const result = await first.json();
  assert.equal(result.pointerAttempted, true); assert.equal(result.pointerChanged, true);
  assert.equal(result.pointerOutcomeUnknown, false); assert.equal(result.aliasesVerified, false);
  assert.equal(result.publicVerificationRequired, true);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'head').length, 36);
  assert.equal(f.calls.length, 2);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 1);
  const second = await f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env);
  assert.equal(second.status, 200); const repeated = await second.json();
  assert.equal(repeated.alreadyPromoted, true); assert.equal(repeated.pointerChanged, false);
  assert.equal(repeated.pointerAttempted, false);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 1);
  const pointer = await f.handle(request('/pointer', 'GET'), f.env);
  assert.equal(pointer.status, 200); assert.deepEqual(await pointer.json(), definition.candidate);
  const head = await f.handle(request('/pointer', 'HEAD'), f.env);
  assert.equal(head.status, 200); assert.equal(head.body, null);
  assert.equal(head.headers.get('cache-control'), 'no-store');
});
test('current unknown pointer is refused, never overwritten', async () => {
  const f = fixture(); f.bucket.seedClosure();
  const unknown = new TextEncoder().encode('{"unexpected":true}\n');
  const key = definition.r2Prefix + 'channels/invited.json';
  f.bucket.records.set(key, metadata({r2Key: key, size: unknown.length, sha256: hash(unknown),
    contentType: 'application/json', cacheControl: 'no-store'}, unknown));
  const response = await f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env);
  assert.equal(response.status, 409); assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 0);
});
test('pointer CAS race stops with 412 and a single conditional attempt', async () => {
  const f = fixture(); f.bucket.seedClosure();
  f.bucket.forcedConflict.add(definition.r2Prefix + 'channels/invited.json');
  const response = await f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env);
  assert.equal(response.status, 412); const body = await response.json();
  assert.equal(body.pointerAttempted, true); assert.equal(body.pointerChanged, false);
  assert.equal(body.pointerOutcomeUnknown, false);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 1);
});
for (const change of ['throw-before-put', 'throw-after-commit', 'read-after-write']) {
  test(`uncertain pointer outcome survives sanitized failure: ${change}`, async () => {
    const f = fixture(); f.bucket.seedClosure();
    f.bucket.throwOnPut = change === 'throw-before-put';
    f.bucket.throwAfterPointerCommit = change === 'throw-after-commit';
    f.bucket.throwPointerReadAfterWrite = change === 'read-after-write';
    const response = await f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env);
    assert.equal(response.status, 502); const text = await response.text(); assert.ok(!text.includes(MOCK_SECRET));
    const result = JSON.parse(text); assert.equal(result.pointerAttempted, true);
    assert.equal(result.pointerOutcomeUnknown, true);
    assert.equal(result.pointerChanged, change === 'read-after-write');
    assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 1);
    assert.equal(f.bucket.records.has(definition.r2Prefix + 'channels/invited.json'), change !== 'throw-before-put');
  });
}
test('concurrent prepared promotions have one winner and no unconditional overwrite', async () => {
  const f = fixture(); f.bucket.seedClosure();
  const responses = await Promise.all([f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env),
    f.handle(request('/promote', 'POST', stageEnvelopeTemplate()), f.env)]);
  assert.deepEqual(responses.map(response => response.status).sort(), [200, 412]);
  assert.equal(f.bucket.records.size, 37);
  assert.equal(f.bucket.calls.filter(call => call.operation === 'put').length, 2);
});
