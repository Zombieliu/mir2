# Issued-updater round 1: progress and local phase timing

This isolated source patch starts at issued updater `4c60c323aed11829abae6ee5ce6e13c675a3c1c3`. It is not the older updater subtree in root 25ec. Only copied `src/update.rs`, `src/delivery.rs`, `src/transaction.rs`, `src/ui.rs` and new adjacent `src/progress_trace_tests.rs` change. No original worktree, installed game, signed packages, old QA/proofs, keys, server, network, CI or Git changes.

The patch exposes real completed-file counts for installed-file verification, bundle extraction, verified cache staging, rollback preparation, installation and recovery. Cache hits advance staging without adding transfer bytes. Nine native languages distinguish local work from downloading. The existing Status method remains compatible; a default final/boundary method lets the wrapper force phase/end snapshots while ordinary snapshots are limited to one every 200 ms. Cancellation checks are not throttled.

Each local phase emits one `local-phase-end` row with measured `Instant` elapsed milliseconds, actual completed/total counts and complete/unfinished outcome. Staging additionally records actual cache hits, written bytes and payload resolution/copy-flush cumulative timings. Payload resolution can include an actual raw transfer, so it is deliberately not named pure cache-read time. It does not estimate bandwidth, user laptop speed or progress from a template. Failed phases retain partial counts. No per-file disk trace is added.

Legacy `prepare_and_apply`, `recover` and `rollback` stay available. New observed variants use an infallible display observer: there is no observer Result/cancellation branch in an applying transaction. Existing signed SHA, file/path guards, copy/flush, journal schema 1 and fresh exact-game checks for each record remain. Existing private abrupt-loss test seam is retained as cfg(test). Cancellation during commit keeps the existing completed/pending-first-launch contract; the later launch boundary still rejects cancellation. Observer panic/process-abort is not claimed to be impossible; the durable journal remains the authority for recovery before launch.

There is no rename, hash memoization, negative-process cache, guard interval change or fsync removal. This round improves feedback and produces phase data; it does not claim that 41-minute installation has become faster. Native GUI layout/human acceptance, shipped release-engine execution, full-size release-engine installation, real healthy first launch, HTTPS/CDN/R2 and publication remain unexecuted.

## Verification

`commands/red-01.*` records three successfully compiled assertions failing on the original behavior: missing translations, missing actual extraction counts, and absent legacy transaction timing trace. This is meaningful RED, not a build failure. The initial copied baseline is byte-bound in BASELINE-01; no assertion of a source freeze before that RED execution is made.

The final new ten tests check actual two-file gzip extraction/cache SHA, zero-wire cached staging counts, partial-failure retention, nine-language counts, deterministic 200 ms display cadence, pre-staging cancellation, commit-time cancellation without journal interruption, legacy public trace, and actual crash/recovery/schema/personal-file behavior. Four original transaction tests, two original hostile-bundle tests, bundle corrupt-fallback and delta fallback also pass (18 distinct checks total). `cargo +1.95.0 check --offline --locked --jobs 2 --all-targets` passes without warnings. Rust host is Windows MSVC; all test temp paths and the independent target belong to this QA. No native UI/game process is launched.

Raw intermediate failures are retained in RAW-FAILURES-01. None is relabeled as a product regression: one implementation borrow compile error was fixed; two newly added fixture assertions had an incorrect byte sum and missing game parent required by the unchanged guard. The earlier 3-test RED remains intact.

Preparation accidentally copied 1.50 GB of ignored existing `target` build files as part of the source subtree. They remain inert, are excluded from patch/proof inputs, and are never executed/reused: Cargo is forced to `C:/mir2-build/native-updater-progress-20261005`. Root allowed owned-only cleanup, but automatic tool approval rejected deletion before a child process started. The artifact is retained; no alternative delete method was attempted. This is preparation/storage overhead, not product test RED.

## Handoff

Read PATCH-01.diff and SOURCE-INVARIANTS-01.json first; FINAL-REVIEW-01 and FROZEN-WORKER-01 bind source, helper scripts and raw receipts. The source-original and old 84-file frozen inventory are independently rehashed after work. Original signed release/package inputs are never written. To adopt the patch, integrate against the issued baseline, then build/sign/publish a new immutable updater engine with correct provenance. No new engine EXE or manifest is claimed by this worker.
