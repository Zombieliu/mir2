from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
BASE=Path(__file__).resolve().parent
name=sys.argv[1]
argv=sys.argv[2:]
assert name.replace('-','').isalnum()
prefix=BASE/'commands'/name
assert not prefix.with_suffix('.command.json').exists()
env=dict(os.environ)
env['TEMP']=str(BASE/'owned-temp'); env['TMP']=env['TEMP']
started=time.monotonic(); start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with prefix.with_suffix('.stdout.log').open('wb') as out, prefix.with_suffix('.stderr.log').open('wb') as err:
    child=subprocess.Popen(argv,cwd=BASE/'updater',env=env,stdout=out,stderr=err)
    rc=child.wait()
value={'argv':argv,'cwd':str(BASE/'updater'),'startedUtc':start,'pid':child.pid,'exitCode':rc,'elapsedSeconds':time.monotonic()-started,'networkRequested':False,'ownedTemp':env['TEMP']}
for ext in ['stdout','stderr']:
    p=prefix.with_suffix('.'+ext+'.log'); b=p.read_bytes()
    value[ext]={'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
prefix.with_suffix('.command.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value))
sys.exit(rc)
