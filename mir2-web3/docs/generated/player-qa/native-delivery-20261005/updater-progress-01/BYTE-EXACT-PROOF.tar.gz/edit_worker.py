from pathlib import Path
BASE=Path(__file__).resolve().parent/'updater'/'src'
def edit(name,fn):
    path=BASE/name; raw=path.read_bytes(); text=raw.decode().replace('\r\n','\n'); changed=fn(text)
    assert changed!=text
    path.write_bytes(changed.replace('\n','\r\n').encode() if b'\r\n' in raw else changed.encode())
def replace(text,old,new,count=1):
    assert text.count(old)==count,(old[:80],text.count(old))
    return text.replace(old,new,count)

def update(text):
    text=replace(text,'    time::{Duration, SystemTime, UNIX_EPOCH},','    time::{Duration, Instant, SystemTime, UNIX_EPOCH},')
    text=replace(text,'    fn cancelled(&self) -> bool;\n}', '''    fn cancelled(&self) -> bool;
    /// Phase boundaries/final counts must be visible even inside the UI cadence.
    fn set_final(&self, key: &str, percent: u32) { self.set(key, percent); }
}

struct DisplayState { phase: String, last: Option<Instant> }
/// Throttle display only. Cancellation is always delegated immediately.
struct ThrottledStatus<'a, T: Status> {
    inner: &'a T,
    state: std::cell::RefCell<DisplayState>,
}
impl<'a, T: Status> ThrottledStatus<'a, T> {
    fn new(inner: &'a T) -> Self {
        Self { inner, state: std::cell::RefCell::new(DisplayState { phase: String::new(), last: None }) }
    }
    fn send_at(&self, key: &str, percent: u32, boundary: bool, now: Instant) {
        let phase = key.split(':').next().unwrap_or(key);
        let mut state = self.state.borrow_mut();
        if boundary || phase != state.phase || percent == 100
            || state.last.is_none_or(|last| now.duration_since(last) >= Duration::from_millis(200)) {
            self.inner.set(key, percent);
            state.phase = phase.into();
            state.last = Some(now);
        }
    }
}
impl<T: Status> Status for ThrottledStatus<'_, T> {
    fn set(&self, key: &str, percent: u32) { self.send_at(key, percent, false, Instant::now()); }
    fn set_final(&self, key: &str, percent: u32) { self.send_at(key, percent, true, Instant::now()); }
    fn cancelled(&self) -> bool { self.inner.cancelled() }
}

/// One bounded disk trace per phase, including an unfinished phase on error.
/// This observer never returns an error or reads cancellation during commit.
pub(super) struct LocalPhase<'a, T: Status> {
    root: &'a Path,
    status: &'a T,
    phase: &'static str,
    total: usize,
    completed: usize,
    range: (u32, u32),
    started: Instant,
    last: Instant,
    complete: bool,
    cache_hits: usize,
    written_bytes: u64,
    payload_resolve_ms: u128,
    copy_flush_ms: u128,
}
impl<'a, T: Status> LocalPhase<'a, T> {
    pub(super) fn new(root: &'a Path, status: &'a T, phase: &'static str, total: usize, range: (u32,u32)) -> Self {
        let now=Instant::now();
        status.set_final(&format!("{phase}:0/{total}"),range.0);
        Self { root,status,phase,total,completed:0,range,started:now,last:now,complete:false,
            cache_hits:0,written_bytes:0,payload_resolve_ms:0,copy_flush_ms:0 }
    }
    fn key(&self) -> String { format!("{}:{}/{}",self.phase,self.completed,self.total) }
    fn percent(&self) -> u32 { self.range.0 + ((self.completed as u64)*(self.range.1-self.range.0) as u64/self.total.max(1) as u64) as u32 }
    pub(super) fn advance(&mut self, completed: usize) {
        self.completed=completed.min(self.total);
        let now=Instant::now();
        if self.completed < self.total && now.duration_since(self.last)>=Duration::from_millis(200) {
            self.status.set(&self.key(),self.percent()); self.last=now;
        }
    }
    pub(super) fn finish(&mut self) { self.complete=true; }
}
impl<T: Status> Drop for LocalPhase<'_, T> {
    fn drop(&mut self) {
        self.status.set_final(&self.key(),self.percent());
        log(self.root,"local-phase-end",serde_json::json!({"phase":self.phase,"completed":self.completed,
            "total":self.total,"elapsedMs":self.started.elapsed().as_millis(),
            "outcome":if self.complete {"complete"} else {"unfinished"},
            "cacheHits":self.cache_hits,"writtenBytes":self.written_bytes,
            "payloadResolveMs":self.payload_resolve_ms,"copyFlushMs":self.copy_flush_ms}));
    }
}

struct TransactionStatus<'a, T: Status> { status: &'a T }
impl<T: Status> transaction::ProgressObserver for TransactionStatus<'_, T> {
    fn observe(&mut self, phase: &'static str, completed: usize, total: usize, boundary: bool) {
        let (start,end)=match phase { "preparing"=>(85,90), "installing"=>(90,98), _=>(5,19) };
        let percent=start+(completed as u64*(end-start) as u64/total.max(1) as u64) as u32;
        let key=format!("{phase}:{completed}/{total}");
        if boundary { self.status.set_final(&key,percent); }
        else if completed < total { self.status.set(&key,percent); }
    }
}''')
    text=replace(text,'pub fn check_update(root: &Path, source: &impl Source, status: &impl Status) -> Result<Outcome> {\n', '''pub fn check_update(root: &Path, source: &impl Source, status: &impl Status) -> Result<Outcome> {
    let throttled=ThrottledStatus::new(status);
    let status=&throttled;
''')
    text=replace(text,'if transaction::recover(root)? {','if transaction::recover_observed(root, &mut TransactionStatus { status })? {')
    text=replace(text,'    progress(status, "verifying", 20)?;\n    let old_files', '''    progress(status, "verifying", 20)?;
    let mut scan=LocalPhase::new(root,status,"checking-installed",new.file_count,(20,30));
    let old_files''')
    text=replace(text,'''            progress(
                status,
                "verifying",
                20 + (index * 10 / new.file_count.max(1)) as u32,
            )?;''','''            ensure!(!status.cancelled(), "update cancelled");''')
    text=replace(text,'''            pending.push(entry.clone());
        }
    }
    for (path, old_entry)''','''            pending.push(entry.clone());
        }
        scan.advance(index+1);
    }
    scan.finish();
    drop(scan);
    for (path, old_entry)''')
    start=text.index('    let mut changes = vec![];\n    let mut done = 0;\n    for entry in &pending {',text.index('pub fn check_update'))
    end=text.index('    outcome.changed_game_files',start)
    original=text[start:end]
    helper=original.replace('    let mut done = 0;','    let mut done = 0;\n    let mut phase=LocalPhase::new(root,status,"staging",pending.len(),(70,84));')
    helper=helper.replace('for entry in &pending {','for (index,entry) in pending.iter().enumerate() {\n        ensure!(!status.cancelled(), "update cancelled");\n        let resolve_started=Instant::now();')
    helper=helper.replace('let (cache, _) = cached_payload(', 'let (cache, downloaded) = cached_payload(')
    helper=helper.replace('&format!("{}/{}", feed.game.directory, entry.path)', '&format!("{directory}/{}", entry.path)')
    helper=helper.replace('        let target = safe::target(', '''        phase.payload_resolve_ms+=resolve_started.elapsed().as_millis();
        phase.cache_hits+=usize::from(!downloaded);
        let copy_started=Instant::now();
        let target = safe::target(''')
    helper=helper.replace('        done += entry.size;\n', '''        done += entry.size;
        phase.written_bytes+=entry.size;
        phase.copy_flush_ms+=copy_started.elapsed().as_millis();
        phase.advance(index+1);
''')
    helper+='    phase.finish();\n    Ok(changes)\n'
    helper='''fn stage_payloads(root: &Path, source: &impl Source, directory: &str, status: &impl Status,
    pending: &[FileEntry], total: u64, transfers: &mut Transfers) -> Result<Vec<Change>> {
'''+helper+'}\n'
    text=text[:start]+'''    let mut changes=stage_payloads(root,source,&feed.game.directory,status,&pending,total,&mut transfers)?;
    let done=pending.iter().map(|entry|entry.size).sum::<u64>();
'''+text[end:]
    text=replace(text,'pub fn check_update(root:',helper+'\npub fn check_update(root:')
    text=replace(text,'transaction::prepare_and_apply(root, &changes)', 'transaction::prepare_and_apply_observed(root, &changes, &mut TransactionStatus { status })')
    text=replace(text,'transaction::recover(root)\n            .context', 'transaction::recover_observed(root, &mut TransactionStatus { status })\n            .context')
    text=replace(text,'        transaction::rollback(root)?;\n        return Err(error);','        transaction::rollback_observed(root, &mut TransactionStatus { status })?;\n        return Err(error);')
    return text

def delivery(text):
    text=replace(text,'''                        status.set("verifying", 30);
                        apply_delta(''','''                        let mut phase=super::LocalPhase::new(root,status,"extracting",1,(30,65));
                        let result=apply_delta(''')
    text=replace(text,'''                            &mut check,
                        )
                    })();''','''                            &mut check,
                        );
                        if result.is_ok() { phase.advance(1); phase.finish(); }
                        result
                    })();''')
    text=replace(text,'''                status.set("verifying", 30);
                extract_bundle(root, &cache, &bundle.archive, &expected, &mut check)''','''                let mut phase=super::LocalPhase::new(root,status,"extracting",expected.len(),(30,65));
                let result=extract_bundle_observed(root,&cache,&bundle.archive,&expected,&mut check,
                    &mut |completed| phase.advance(completed));
                if result.is_ok() { phase.finish(); }
                result''')
    old='''    check: &mut dyn FnMut() -> Result<()>,
) -> Result<()> {
    ensure!(
        !expected.is_empty()'''
    new='''    check: &mut dyn FnMut() -> Result<()>,
) -> Result<()> {
    extract_bundle_observed(root,archive_path,archive,expected,check,&mut |_| {})
}
fn extract_bundle_observed(
    root: &Path, archive_path: &Path, archive: &FileEntry, expected: &[&FileEntry],
    check: &mut dyn FnMut() -> Result<()>, completed: &mut dyn FnMut(usize),
) -> Result<()> {
    ensure!(
        !expected.is_empty()'''
    text=replace(text,old,new)
    text=replace(text,'    for _ in 0..entries.len() {','    for index in 0..entries.len() {')
    text=replace(text,'        cache_entry(root, entry, &mut reader, check)?;','        cache_entry(root, entry, &mut reader, check)?;\n        completed(index+1);')
    return text

def transaction(text):
    text=replace(text,'use std::{fs, path::Path};','''use std::{fs, path::Path, time::Instant};

/// Display-only observer; no fallible/cancellation result can interrupt commit.
pub trait ProgressObserver {
    fn observe(&mut self, phase: &'static str, completed: usize, total: usize, boundary: bool);
}
struct NoProgress;
impl ProgressObserver for NoProgress {
    fn observe(&mut self, _: &'static str, _: usize, _: usize, _: bool) {}
}
struct Phase<'a, O: ProgressObserver> {
    root: &'a Path, observer: &'a mut O, phase: &'static str, total: usize,
    completed: usize, started: Instant, complete: bool,
}
impl<'a,O: ProgressObserver> Phase<'a,O> {
    fn new(root: &'a Path, observer: &'a mut O, phase: &'static str, total: usize) -> Self {
        let started=Instant::now();
        observer.observe(phase,0,total,true);
        Self { root,observer,phase,total,completed:0,started,complete:false }
    }
    fn advance(&mut self, completed: usize) {
        self.completed=completed;
        self.observer.observe(self.phase,self.completed,self.total,false);
    }
    fn finish(&mut self) { self.complete=true; }
}
impl<O: ProgressObserver> Drop for Phase<'_,O> {
    fn drop(&mut self) {
        self.observer.observe(self.phase,self.completed,self.total,true);
        crate::update::log(self.root,"local-phase-end",serde_json::json!({"phase":self.phase,
            "completed":self.completed,"total":self.total,"elapsedMs":self.started.elapsed().as_millis(),
            "outcome":if self.complete {"complete"} else {"unfinished"}}));
    }
}''')
    text=replace(text,'pub fn recover(root: &Path) -> Result<bool> {','''pub fn recover(root: &Path) -> Result<bool> { recover_observed(root,&mut NoProgress) }
pub fn recover_observed(root: &Path, observer: &mut impl ProgressObserver) -> Result<bool> {''')
    text=replace(text,'            rollback(root)?;','            rollback_observed(root,observer)?;')
    text=replace(text,'pub fn rollback(root: &Path) -> Result<()> {','''pub fn rollback(root: &Path) -> Result<()> { rollback_observed(root,&mut NoProgress) }
pub fn rollback_observed(root: &Path, observer: &mut impl ProgressObserver) -> Result<()> {''')
    text=replace(text,'    // Check every backup before changing anything; retained journal permits retry.','''    let mut phase=Phase::new(root,observer,"recovering",j.records.len());
    // Check every backup before changing anything; retained journal permits retry.''')
    text=replace(text,'    for r in j.records.iter().rev() {','    for (index,r) in j.records.iter().rev().enumerate() {')
    text=replace(text,'''            fs::remove_file(target)?;
        }
    }
    j.phase = "rolled-back"''','''            fs::remove_file(target)?;
        }
        phase.advance(index+1);
    }
    j.phase = "rolled-back"''')
    text=replace(text,'''    j.phase = "rolled-back".into();
    save(root, &j)?;
    Ok(())''','''    j.phase = "rolled-back".into();
    save(root, &j)?;
    phase.finish();
    Ok(())''')
    text=replace(text,'''pub fn prepare_and_apply(root: &Path, changes: &[Change]) -> Result<()> {
    apply_steps(root, changes, |_| Ok(()))
}''','''pub fn prepare_and_apply(root: &Path, changes: &[Change]) -> Result<()> {
    prepare_and_apply_observed(root,changes,&mut NoProgress)
}
pub fn prepare_and_apply_observed(root: &Path, changes: &[Change], observer: &mut impl ProgressObserver) -> Result<()> {
    apply_steps_observed(root,changes,|_| Ok(()),observer)
}''')
    text=replace(text,'''    mut after: impl FnMut(usize) -> Result<()>,
) -> Result<()> {
    ensure!(''','''    after: impl FnMut(usize) -> Result<()>,
) -> Result<()> {
    apply_steps_observed(root,changes,after,&mut NoProgress)
}
pub(crate) fn apply_steps_observed(
    root: &Path, changes: &[Change], mut after: impl FnMut(usize) -> Result<()>,
    observer: &mut impl ProgressObserver,
) -> Result<()> {
    ensure!(''')
    text=replace(text,'    safe::clear_scratch(root, "backup")?;','    let mut preparing=Phase::new(root,observer,"preparing",changes.len());\n    safe::clear_scratch(root, "backup")?;')
    text=replace(text,'    for r in &j.records {\n        if let Some(old) = &r.backup {\n            let dest', '    for (index,r) in j.records.iter().enumerate() {\n        if let Some(old) = &r.backup {\n            let dest')
    text=replace(text,'''                "missing staged file"
            );
        }
    }
    save(root, &j)?;
    after(0)?;''','''                "missing staged file"
            );
        }
        preparing.advance(index+1);
    }
    save(root, &j)?;
    preparing.finish();
    drop(preparing);
    let mut installing=Phase::new(root,observer,"installing",j.records.len());
    after(0)?;''')
    text=replace(text,'        after(index + 1)?;','        installing.advance(index+1);\n        after(index + 1)?;')
    text=replace(text,'''    j.phase = "committed".into();
    save(root, &j)?;
    Ok(())''','''    j.phase = "committed".into();
    save(root, &j)?;
    installing.finish();
    Ok(())''')
    return text

def ui(text):
    text=replace(text,'pub fn stage(locale: &str, key: &str) -> String {','''pub fn stage(locale: &str, key: &str) -> String {
    if let Some((phase,counts))=key.split_once(':') {
        if let Some((done,total))=counts.split_once('/') {
            if let (Ok(done),Ok(total))=(done.parse::<usize>(),total.parse::<usize>()) {
                if done<=total && total<=200010 && matches!(phase,"extracting"|"staging"|"preparing"|"installing"|"checking-installed"|"recovering") {
                    return format!("{}  ({} / {})",stage(locale,phase),done,total);
                }
            }
        }
    }''')
    strings={
      'extracting':['Unpacking and verifying files…','正在解壓並驗證檔案…','Descompactando e verificando arquivos…','Распаковка и проверка файлов…','फ़ाइलें खोलकर जाँची जा रही हैं…','Mengekstrak dan memverifikasi file…','Đang giải nén và xác minh tệp…','กำลังแตกไฟล์และตรวจสอบไฟล์…','جارٍ فك الملفات والتحقق منها…'],
      'staging':['Preparing verified files locally…','正在本機暫存已驗證的檔案…','Preparando arquivos verificados no computador…','Подготовка проверенных файлов на компьютере…','जाँची गई फ़ाइलें इस कंप्यूटर पर तैयार हो रही हैं…','Menyiapkan file terverifikasi di komputer…','Đang chuẩn bị tệp đã xác minh trên máy…','กำลังเตรียมไฟล์ที่ตรวจสอบแล้วในเครื่อง…','جارٍ تجهيز الملفات المتحقق منها على الجهاز…'],
      'preparing':['Preparing rollback and checking staged files…','正在準備還原備份並檢查暫存檔案…','Preparando restauração e verificando arquivos locais…','Подготовка резервных копий и проверка файлов…','बहाली की प्रतियाँ और स्थानीय फ़ाइलें तैयार हो रही हैं…','Menyiapkan pemulihan dan memeriksa file lokal…','Đang chuẩn bị khôi phục và kiểm tra tệp cục bộ…','กำลังเตรียมการย้อนกลับและตรวจสอบไฟล์ในเครื่อง…','جارٍ تجهيز الاستعادة وفحص الملفات المحلية…'],
      'installing':['Installing verified files locally…','正在本機安裝已驗證的檔案…','Instalando arquivos verificados no computador…','Установка проверенных файлов на компьютере…','जाँची गई फ़ाइलें इस कंप्यूटर पर इंस्टॉल हो रही हैं…','Menginstal file terverifikasi di komputer…','Đang cài đặt tệp đã xác minh trên máy…','กำลังติดตั้งไฟล์ที่ตรวจสอบแล้วในเครื่อง…','جارٍ تثبيت الملفات المتحقق منها على الجهاز…'],
      'checking-installed':['Checking installed files…','正在檢查已安裝的檔案…','Verificando arquivos instalados…','Проверка установленных файлов…','इंस्टॉल की गई फ़ाइलें जाँची जा रही हैं…','Memeriksa file yang terinstal…','Đang kiểm tra các tệp đã cài đặt…','กำลังตรวจสอบไฟล์ที่ติดตั้งแล้ว…','جارٍ فحص الملفات المثبتة…']}
    added=''
    for key,values in strings.items():
        added+='        "'+key+'" => [\n'+''.join('            "'+v+'",\n' for v in values)+'        ],\n'
    text=replace(text,'    let strings: [&str; 9] = match key {\n','    let strings: [&str; 9] = match key {\n'+added)
    return text

edit('update.rs',update)
edit('delivery.rs',delivery)
edit('transaction.rs',transaction)
edit('ui.rs',ui)
print('Changed only update.rs, delivery.rs, transaction.rs, ui.rs in owned copied source.')
