from pathlib import Path
import hashlib, json, shutil, subprocess
OUT = Path(__file__).resolve().parent
SRC = Path('C:/Users/Administrator/.codex/worktrees/r2-client-delivery/mir2-player-journey/mir2-web3/apps/game-client/windows-updater')
OLD_QA = Path('C:/mir2-playtest-releases/20261004-native-r18/origin-acceleration-client-qa-01')
TARGET = OUT / 'updater'
assert not TARGET.exists()
assert subprocess.check_output(['git', '-C', str(SRC), 'rev-parse', 'HEAD']).decode().strip() == '4c60c323aed11829abae6ee5ce6e13c675a3c1c3'
rows=[]
for p in sorted(SRC.rglob('*')):
    if p.is_file():
        assert not p.is_symlink()
        rel=p.relative_to(SRC)
        dst=TARGET/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(p,dst)
        data=p.read_bytes()
        assert dst.read_bytes()==data
        rows.append({'relative':rel.as_posix(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
frozen = json.loads((OLD_QA/'FROZEN-PUBLIC-01.json').read_text())
(OUT/'BASELINE-01.json').write_text(json.dumps({'sourceRevision':'4c60c323aed11829abae6ee5ce6e13c675a3c1c3','sourcePath':str(SRC),'files':rows,'oldQAFreezeSha256':hashlib.sha256((OLD_QA/'FROZEN-PUBLIC-01.json').read_bytes()).hexdigest(),'oldQAFrozenInventory':frozen},indent=2)+'\n')
(OUT/'commands').mkdir()
(OUT/'owned-temp').mkdir()
print(json.dumps({'copiedFiles':len(rows),'copiedByteEqual':True}))
