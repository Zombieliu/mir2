from pathlib import Path
import datetime,difflib,hashlib,json,re,subprocess
BASE=Path(__file__).resolve().parent
COPIED=BASE/'updater'
baseline=json.loads((BASE/'BASELINE-01.json').read_text())
ORIGINAL=Path(baseline['sourcePath'])
QA=Path('C:/mir2-playtest-releases/20261004-native-r18/origin-acceleration-client-qa-01')
ALLOWED={'src/update.rs','src/delivery.rs','src/transaction.rs','src/ui.rs'}
def record(p):
    data=p.read_bytes()
    return {'path':str(p).replace('\\','/'),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def write(name,value):
    p=BASE/name; assert not p.exists()
    p.write_text(json.dumps(value,indent=2)+'\n')
source_rows=[]; changes=[]; patch=[]
for row in baseline['files']:
    rel=row['relative']
    if rel.startswith('target/'): continue
    orig=ORIGINAL/rel; copied=COPIED/rel
    a=record(orig); b=record(copied)
    assert a['bytes']==row['bytes'] and a['sha256']==row['sha256'],('original changed',rel)
    changed=a['sha256']!=b['sha256']
    assert not changed or rel in ALLOWED,('outside allowed source patch',rel)
    source_rows.append({'relative':rel,'original':a,'copied':b,'changed':changed})
    if changed:
        changes.append(rel)
        patch.extend(difflib.unified_diff(orig.read_text(encoding='utf-8').splitlines(True),copied.read_text(encoding='utf-8').splitlines(True),
            fromfile='a/'+rel,tofile='b/'+rel))
assert set(changes)==ALLOWED
newfile=COPIED/'src/progress_trace_tests.rs'
patch.extend(difflib.unified_diff([],newfile.read_text(encoding='utf-8').splitlines(True),fromfile='/dev/null',tofile='b/src/progress_trace_tests.rs'))
(BASE/'PATCH-01.diff').write_text(''.join(patch),encoding='utf-8')

def fn(text,name):
    match=re.search(r'(?m)^(?:pub(?:\([^\n]*\))? )?fn '+re.escape(name)+r'\(',text)
    assert match,name
    start=text.index('{',match.start()); depth=0; quoted=False; escaped=False
    for i in range(start,len(text)):
        c=text[i]
        if quoted:
            if escaped: escaped=False
            elif c=='\\': escaped=True
            elif c=='"': quoted=False
            continue
        if c=='"': quoted=True; continue
        if c=='{':depth+=1
        elif c=='}':
            depth-=1
            if depth==0:return text[start:i+1]
    raise RuntimeError(name)

old=(ORIGINAL/'src/transaction.rs').read_text(encoding='utf-8'); new=(COPIED/'src/transaction.rs').read_text(encoding='utf-8')
functions=[]
for name in ['scope','journal_path','save','load','install_staged','pending_activation','accept','stage_bytes']:
    a=fn(old,name); b=fn(new,name); assert a==b,name
    functions.append({'function':name,'normalizedBodyByteEqual':True,'sha256':hashlib.sha256(a.encode()).hexdigest()})
guard=re.compile(r'ensure!\(\s*!crate::platform::game_is_running\([^;]*?\);',re.S)
og=guard.findall(old); ng=guard.findall(new); assert og==ng and len(og)==4
assert old.count('.sync_all()?')==new.count('.sync_all()?')==2
assert (ORIGINAL/'src/fs_safe.rs').read_bytes()==(COPIED/'src/fs_safe.rs').read_bytes()
assert (ORIGINAL/'src/platform.rs').read_bytes()==(COPIED/'src/platform.rs').read_bytes()
assert (ORIGINAL/'Cargo.lock').read_bytes()==(COPIED/'Cargo.lock').read_bytes()
assert (ORIGINAL/'Cargo.toml').read_bytes()==(COPIED/'Cargo.toml').read_bytes()
guard_rows=[{'sha256':hashlib.sha256(g.encode()).hexdigest(),'normalizedCodeEqual':True} for g in og]
old_ui=(ORIGINAL/'src/ui.rs').read_text(encoding='utf-8'); new_ui=(COPIED/'src/ui.rs').read_text(encoding='utf-8')
assert old_ui[old_ui.index('#[cfg(windows)]\nmod windows'):]==new_ui[new_ui.index('#[cfg(windows)]\nmod windows'):]
write('SOURCE-INVARIANTS-01.json',{'schema':'mir2.updater-progress-source-invariants.v1','passed':True,
    'changedProductionFiles':changes,'newAdjacentTest':record(newfile),'sourceFiles':source_rows,
    'transactionAuthoritativeFunctions':functions,'freshExactGameGuardBlocks':guard_rows,'guardBlocks':4,
    'transactionSyncCallsBefore':2,'transactionSyncCallsAfter':2,'fsSafeAndPlatformByteEqual':True,
    'cargoLockAndTomlByteEqual':True,'nativeWindowImplementationByteEqual':True,
    'stagedActivationStillCopyAndFlush':True,'directoryRenameOrNegativeProcessCacheAdded':False})

frozen=json.loads((QA/'FROZEN-PUBLIC-01.json').read_text())
for row in frozen['files']:
    value=record(QA/row['path']); assert value['bytes']==row['size'] and value['sha256']==row['sha256'],row['path']
assert record(QA/'FROZEN-PUBLIC-01.json')['sha256']==baseline['oldQAFreezeSha256']
plan=Path('C:/mir2-playtest-releases/20261004-native-r18/native-updater-performance-plan-01')
pf=json.loads((plan/'FROZEN-PLAN-02.json').read_text())
for row in pf['files']:
    value=record(plan/row['path']); assert value['bytes']==row['bytes'] and value['sha256']==row['sha256']
head=subprocess.check_output(['git','-C',str(ORIGINAL),'rev-parse','HEAD']).decode().strip()
status=subprocess.check_output(['git','-C',str(ORIGINAL),'status','--porcelain','--','.']).decode().strip()
assert head=='4c60c323aed11829abae6ee5ce6e13c675a3c1c3' and not status
commands=[]
for p in sorted((BASE/'commands').glob('*.command.json')):
    row=json.loads(p.read_text()); row['receipt']=record(p); commands.append(row)
for name in ['green-final-01','compatibility-transaction-final-01','compatibility-bundle-negative-01','compatibility-bundle-fallback-01','compatibility-delta-fallback-01','check-entrypoints-final-01']:
    assert json.loads((BASE/'commands'/f'{name}.command.json').read_text())['exitCode']==0,name
assert '3 failed' in (BASE/'commands/red-01.stdout.log').read_text()
assert '10 passed' in (BASE/'commands/green-final-01.stdout.log').read_text()
assert 'host: x86_64-pc-windows-msvc' in (BASE/'commands/rustc-version-01.stdout.log').read_text()
assert 'warning:' not in (BASE/'commands/check-entrypoints-final-01.stderr.log').read_text()
exe=Path('C:/mir2-build/native-updater-progress-20261005/debug/deps/mir2_windows_updater-4aa352f25a322883.exe')
assert exe.is_file()
write('FINAL-REVIEW-01.json',{'schema':'mir2.updater-progress-worker-review.v1','passed':True,
    'sourceRevision':head,'sourceTrackedPublicFilesRehashedUnchanged':len(source_rows),
    'originalSourceTrackedStatusClean':True,'originalIgnoredTargetExcludedFromSourceClaim':True,
    'oldQA84FileInventoryRehashedUnchanged':len(frozen['files']),'oldQAFreeze':record(QA/'FROZEN-PUBLIC-01.json'),
    'readOnlyPlanFrozenFilesRehashedUnchanged':len(pf['files']),
    'meaningfulRedAssertions':3,'newTestsPassed':10,'originalTransactionTestsPassed':4,
    'hostileBundleTestsPassed':2,'bundleFallbackPassed':1,'deltaFallbackPassed':1,'distinctPassedTests':18,
    'allTargetsCheckPassedWithoutWarnings':True,'rust':'1.95.0','host':'x86_64-pc-windows-msvc',
    'cargoOffline':True,'cargoLocked':True,'jobs':2,'compiledFinalUnitTestArtifact':record(exe),
    'commands':commands,'sourceInvariants':record(BASE/'SOURCE-INVARIANTS-01.json'),'patch':record(BASE/'PATCH-01.diff'),
    'rawFailures':record(BASE/'RAW-FAILURES-01.json'),
    'limits':{'shippedExeExecuted':False,'nativeUIOrGameLaunched':False,'fullSizeInstallRerun':False,
        'httpsSpeedMeasured':False,'laptopSpeedMeasured':False,'r2Delivered':False,'publishedNewUpdaterEngine':False,
        'sourceOrGitOrCiOrProductionMutated':False,'oldPlayerOrInstallationFilesWritten':False,
        'performanceSpeedupClaimed':False,'copiedIgnoredBuildTargetRetainedInert':True},
    'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
files=[]
for p in sorted(BASE.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(BASE).as_posix()
    if rel.startswith(('updater/target/','owned-temp/')):continue
    r=record(p); r['path']=rel;files.append(r)
write('FROZEN-WORKER-01.json',{'schema':'mir2.updater-progress-worker-freeze.v1','sourceRevision':head,
    'freezeGeneratedAfterTestsExplicit':True,'excludedInertCopiedTarget':True,'files':files})
for row in files:
    value=record(BASE/row['path']); assert value['bytes']==row['bytes'] and value['sha256']==row['sha256']
print(json.dumps({'passed':True,'files':len(files),'frozen':record(BASE/'FROZEN-WORKER-01.json'),
    'review':record(BASE/'FINAL-REVIEW-01.json'),'sourceUnchanged':len(source_rows),'oldQAUnchanged':len(frozen['files'])}))
