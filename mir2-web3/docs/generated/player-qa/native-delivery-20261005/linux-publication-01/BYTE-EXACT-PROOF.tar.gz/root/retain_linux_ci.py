"""Retain actual secretless GitHub verify run; inspect ZIP without extracting."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import time
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
DEST = HERE / 'ci-linux-01'
RUN = 37292261788
SOURCE = 'c8fea016881b24e58b5aff896e5236a703d9c9a4'
REPO = 'Zombieliu/mir2'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def command(name, argv):
    started = time.time()
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=180, check=False)
    (DEST / (name + '.stdout')).write_bytes(result.stdout)
    (DEST / (name + '.stderr')).write_bytes(result.stderr)
    write_json(DEST / (name + '.json'), {
        'argv': argv, 'startedUnix': started, 'elapsedSeconds': time.time() - started,
        'exitCode': result.returncode, 'stdoutSha256': digest(result.stdout),
        'stderrSha256': digest(result.stderr), 'environmentCaptured': False})
    assert result.returncode == 0, (name, result.returncode)
    return result.stdout


def blob(path):
    result = subprocess.run(['git', '-c', 'gc.auto=0', 'show', SOURCE + ':' + path],
        cwd=ROOT, capture_output=True, timeout=30, check=False)
    assert result.returncode == 0
    return result.stdout


def main():
    DEST.mkdir(exist_ok=False)
    snapshot_raw = (HERE / 'ci-snapshot-01.json').read_bytes()
    metadata_raw = (HERE / 'ci-artifact-metadata-01.json').read_bytes()
    (DEST / 'RUN.json').write_bytes(snapshot_raw)
    (DEST / 'ARTIFACT-METADATA.json').write_bytes(metadata_raw)
    snapshot = json.loads(snapshot_raw.decode('utf-8-sig'))
    metadata = json.loads(metadata_raw.decode('utf-8-sig'))
    assert snapshot['databaseId'] == RUN and snapshot['headSha'] == SOURCE
    assert snapshot['status'] == 'completed' and snapshot['conclusion'] == 'success'
    jobs = {job['name']: job for job in snapshot['jobs']}
    assert jobs['native-download-tooling-check']['conclusion'] == 'success'
    assert all(job['conclusion'] == 'skipped' for key, job in jobs.items()
        if key != 'native-download-tooling-check')
    assert metadata['total_count'] == 1
    artifact = metadata['artifacts'][0]
    assert artifact['workflow_run']['head_sha'] == SOURCE and not artifact['expired']

    logs = command('gh-run-log', ['gh', 'run', 'view', str(RUN), '--repo', REPO, '--log'])
    archive = command('gh-artifact-zip', ['gh', 'api',
        'repos/' + REPO + '/actions/artifacts/' + str(artifact['id']) + '/zip'])
    assert len(archive) == artifact['size_in_bytes']
    assert 'sha256:' + digest(archive) == artifact['digest']
    log_text = logs.decode('utf-8')
    assert re.search(r'# tests 138\b', log_text)
    assert re.search(r'# pass 138\b', log_text)
    assert re.search(r'# fail 0\b', log_text)
    assert 'Ran 64 tests in ' in log_text and 'Ran 2 tests in ' in log_text
    assert 'test_actual_sigint_keeps_unknown_import_without_retry_or_pointer' in log_text
    assert 'test_actual_gnu_timeout_interrupts_only_owned_child_and_writes_receipt' in log_text

    members = []
    test_receipts = []
    interruption_receipts = []
    total_size = 0
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        for info in z.infolist():
            path = PurePosixPath(info.filename)
            assert not path.is_absolute() and '..' not in path.parts
            assert '\\' not in info.filename and ':' not in info.filename
            total_size += info.file_size
            assert total_size < 8 * 1024 * 1024
            content = z.read(info)
            assert len(content) == info.file_size
            members.append({'path': info.filename, 'bytes': len(content), 'sha256': digest(content)})
            if path.name.startswith('TEST-RECEIPT-'):
                test_receipts.append((info.filename, content, json.loads(content)))
            if 'interrupt-fixtures' in path.parts and path.name == 'receipt.json':
                interruption_receipts.append((info.filename, json.loads(content)))
    assert len(test_receipts) == 1 and len(interruption_receipts) == 2
    receipt_path, receipt_raw, receipt = test_receipts[0]
    assert receipt['run'] == 64 and receipt['pass'] == 64 and receipt['passed'] is True
    assert receipt['fail'] == receipt['errors'] == receipt['skipped'] == 0
    assert receipt['platform'] == 'linux' and receipt['credentialsUsed'] is False
    assert receipt['actualNetworkRequests'] == 0
    assert not receipt['source36Accepted'] and not receipt['public36Accepted'] and not receipt['cmsReverified']
    pins = {
        'sourceSha256': 'mir2-web3/scripts/native_r17_r2_delivery.py',
        'testSha256': 'mir2-web3/scripts/test_native_r17_r2_delivery.py',
        'literalPlanSha256': 'mir2-web3/infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json',
    }
    for key, path in pins.items():
        assert digest(blob(path)) == receipt[key]
    assert receipt['literalPlanSha256'] == '9fd816a5fdf26a937d3d94a5b031c9e992fbb104f49832ba31a703587a0385f8'
    for path, interruption in interruption_receipts:
        assert not interruption['passed'] and interruption['receiptStatus'] == 'written'
        assert interruption['result'] == 'transport_failed'
        assert interruption['objectWriteAttempted'] and interruption['objectOutcomeUnknown']
        assert not interruption['pointerAttempted'] and not interruption['pointerChanged']
        assert len(interruption['calls']) == 3 and not interruption['calls'][-1]['complete']
    (DEST / 'TEST-RECEIPT.json').write_bytes(receipt_raw)
    write_json(DEST / 'ZIP-INVENTORY.json', members)
    review = {
        'schema': 'mir2.native.linux-ci.root-review.v1', 'runId': RUN, 'source': SOURCE,
        'url': snapshot['url'], 'actualConclusion': snapshot['conclusion'],
        'artifactId': artifact['id'], 'artifactBytes': len(archive),
        'artifactSha256': digest(archive), 'githubDigestMatches': True,
        'archiveExtracted': False, 'nodePass': 138, 'nodeFail': 0, 'nodeSkipped': 0,
        'pythonPass': 64, 'pythonFail': 0, 'pythonSkipped': 0,
        'actualInterruptPass': 2, 'actualInterruptSkipped': 0,
        'portablePlanRawSha256': receipt['literalPlanSha256'],
        'sourcePinsMatchCommit': True, 'testReceiptPath': receipt_path,
        'zipMemberCount': len(members), 'otherJobs': {k: v['conclusion'] for k, v in jobs.items()
            if k != 'native-download-tooling-check'},
        'cloudflareProbe': False, 'remoteStage': False, 'remotePromotion': False,
        'publicSpeedAccepted': False, 'cmsReverified': False, 'gameLaunched': False,
        'gameSource': '6032', 'publicDiscoverySequence': 12,
        'boundary': 'Actual Linux CI and owned SIGINT process; network/storage models only.'}
    write_json(DEST / 'REVIEW.json', review)
    print(json.dumps(review))


if __name__ == '__main__':
    main()
