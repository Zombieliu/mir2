"""Archive terminal Linux receipts additively; do not extract the fetched ZIP."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey')
DEST = ROOT / 'mir2-web3/docs/generated/player-qa/native-delivery-20261005/linux-publication-01'
CI = HERE / 'ci-linux-01'
SOURCE = 'c8fea016881b24e58b5aff896e5236a703d9c9a4'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    DEST.mkdir(exist_ok=True)
    assert not list(DEST.iterdir()), 'never overwrite an existing evidence archive'
    review = (CI / 'REVIEW.json').read_bytes()
    parsed = json.loads(review)
    assert parsed['source'] == SOURCE and parsed['actualConclusion'] == 'success'
    originals = {'ci/' + p.name: p.read_bytes() for p in sorted(CI.iterdir()) if p.is_file()}
    names = ['retain_linux_ci.py', 'freeze_linux_ci.py', 'git-commit-01.txt', 'git-commit-01.json',
        'git-push-01.txt', 'git-push-01.json', 'git-remote-01.txt', 'ci-dispatch-01.txt', 'ci-dispatch-01.json',
        'freeze-linux-first-attempt-01.py', 'freeze-linux-first-attempt-01.json']
    for name in names:
        originals['root/' + name] = (HERE / name).read_bytes()
    assert originals['root/git-remote-01.txt'].decode('utf-8-sig').split()[0] == SOURCE
    for rel in ['.gitattributes', '.github/workflows/web-assets-r2-release.yml',
        'mir2-web3/scripts/native_r17_r2_delivery.py',
        'mir2-web3/scripts/test_native_r17_r2_delivery.py',
        'mir2-web3/scripts/test_native_r17_interrupt.py',
        'mir2-web3/infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication.mjs',
        'mir2-web3/infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json',
        'mir2-web3/infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs']:
        command = subprocess.run(['git', '-c', 'gc.auto=0', 'show', SOURCE + ':' + rel],
            cwd=ROOT, capture_output=True, timeout=30, check=False)
        assert command.returncode == 0, rel
        working = (ROOT / rel).read_bytes()
        if rel in {'.gitattributes', '.github/workflows/web-assets-r2-release.yml',
                   'mir2-web3/scripts/test_native_r17_interrupt.py'}:
            filtered = subprocess.run(['git', '-c', 'gc.auto=0', 'hash-object', '--path', rel, '--stdin'],
                input=working, cwd=ROOT, capture_output=True, timeout=30, check=False)
            stored = subprocess.run(['git', '-c', 'gc.auto=0', 'rev-parse', SOURCE + ':' + rel],
                cwd=ROOT, capture_output=True, timeout=30, check=False)
            assert filtered.returncode == stored.returncode == 0, rel
            assert filtered.stdout.strip() == stored.stdout.strip(), rel
        else:
            assert command.stdout == working, rel
        originals['source/' + rel] = command.stdout
    inventory = [{'path': name, 'bytes': len(raw), 'sha256': digest(raw)}
        for name, raw in sorted(originals.items())]
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, raw in sorted(originals.items()):
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(raw))
    raw_archive = buffer.getvalue()
    (DEST / 'BYTE-EXACT-PROOF.tar.gz').write_bytes(raw_archive)
    (DEST / 'REVIEW.json').write_bytes(review)
    metadata = {'schema': 'mir2.native.linux-ci.archive.v1', 'source': SOURCE,
        'runId': parsed['runId'], 'members': len(inventory), 'bytes': len(raw_archive),
        'sha256': digest(raw_archive), 'originalsUnchanged': True,
        'rawZipExtracted': False, 'inventory': inventory}
    (DEST / 'ARCHIVE.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
    (DEST / '.gitattributes').write_text('* -text -whitespace\n', encoding='utf-8')
    for name, raw in originals.items():
        if name.startswith('ci/'):
            assert raw == (CI / name.removeprefix('ci/')).read_bytes()
    print(json.dumps({key: metadata[key] for key in ['members', 'bytes', 'sha256', 'source', 'runId']}))


if __name__ == '__main__':
    main()
