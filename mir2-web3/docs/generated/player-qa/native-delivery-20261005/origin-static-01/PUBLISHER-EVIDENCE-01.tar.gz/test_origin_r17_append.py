"""Offline tiny real-file fixtures; not CMS, Linux fsync/flock or live acceptance.

Every fixture is kept below this new proof directory, including failures. No
TemporaryDirectory cleanup or network; CLI never exposes fixture-root overrides.
"""
from __future__ import annotations

import dataclasses
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import sys
import tempfile
import time
import types
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('origin_append_fixture_target', HERE / 'origin-r17-append.py')
M = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = M
SPEC.loader.exec_module(M)
FIXTURE_RECORDS = []


def write(path, raw, mode=0o600):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('xb') as stream:
        stream.write(raw)
    os.chmod(path, mode)


def digest_entry(path, raw):
    return {'path': path, 'size': len(raw), 'sha256': M.sha(raw)}


def inventory(root):
    answer = {}
    for path in sorted(root.rglob('*')):
        info = path.lstat()
        if stat.S_ISREG(info.st_mode):
            answer[path.relative_to(root).as_posix()] = {
                'bytes': info.st_size, 'sha256': M.sha(path.read_bytes()),
                'identity': list(M.fingerprint(info)),
            }
        elif stat.S_ISLNK(info.st_mode):
            answer[path.relative_to(root).as_posix()] = {'symlink': os.readlink(path)}
        elif stat.S_ISDIR(info.st_mode):
            answer[path.relative_to(root).as_posix()] = {'directory': True}
        else:
            answer[path.relative_to(root).as_posix()] = {'wrongType': info.st_mode}
    return answer


class Fixture:
    def __init__(self, label, *, decoded_failure=None):
        M.FIXTURE_BASE.mkdir(exist_ok=True)
        self.root = Path(tempfile.mkdtemp(prefix=label + '-', dir=M.FIXTURE_BASE))
        self.stage = self.root / 'private'
        self.public = self.root / 'public'
        self.inputs, self.generated = self.stage / 'inputs', self.stage / 'generated'
        self.target, self.old_dir = self.public / M.GAME_DIRECTORY, self.public / M.OLD_DIRECTORY
        for path in (self.stage, self.inputs, self.generated, self.public, self.target,
                     self.old_dir, self.public / 'feed-current'):
            path.mkdir(parents=True, exist_ok=True, mode=0o700)
            os.chmod(path, 0o700)
        write(self.stage / 'publisher.lock', b'fixture existing publisher lock; never modified\n')
        self.old = b'prefix-oldbody-suffix'
        self.new = b'prefix-NEW-CONTENT-suffix'
        self.payload = {'mir2-platform-windows.exe': self.new, 'BUILD-ATTESTATION.json': b'{"fixtureOnly":true}\n'}
        for index in range(10):
            self.payload[f'assets/part-{index:02}.bin'] = (f'fixture-payload-{index}-'.encode() * (index + 1))
        entries = [digest_entry(name, raw) for name, raw in sorted(self.payload.items())]
        # Preserve the actual manifest digest spelling, rather than manufacture an
        # all-uppercase aggregate. This exercises both valid spellings faithfully.
        entries[0]['sha256'] = entries[0]['sha256'].upper()
        aggregate = ''.join(f"{e['path']}\t{e['size']}\t{e['sha256']}\n" for e in entries)
        manifest = {'schema': 'mir2.windows.package-manifest.v4',
            'coverage': {'excludes': list(M.META_NAMES), 'rule': 'fixture payload closure'},
            'fileCount': len(entries), 'totalBytes': sum(e['size'] for e in entries),
            'aggregateSha256': M.sha(aggregate.encode('ascii')), 'files': entries}
        self.exe = {'size': len(self.new), 'sha256': M.sha(self.new)}
        self.old_exe = {'size': len(self.old), 'sha256': M.sha(self.old)}
        version = {'candidate': M.CANDIDATE, 'gitRevision': M.GAME_SOURCE,
                   'exeSizeBytes': len(self.new), 'exeSha256': M.sha(self.new)}
        self.meta_raw = {'PACKAGE-MANIFEST.json': M.canonical(manifest),
            'VERSION.json': M.canonical(version), 'RELEASE-STATEMENT.json': b'{"fixtureStatement":true}\n',
            'RELEASE-STATEMENT.p7s': b'fixture-opaque-statement-signature-not-CMS'}
        for name, raw in self.meta_raw.items():
            write(self.target / name, raw)
        for name, raw in self.payload.items():
            write(self.target / name, raw)
        write(self.old_dir / 'mir2-platform-windows.exe', self.old)
        now = int(time.time())
        feed = {'sequence': 12, 'createdUnix': now - 60, 'expiresUnix': now + 86400,
                'game': {'identity': M.CANDIDATE, 'directory': M.GAME_DIRECTORY}}
        self.feed_raw = {'latest.json': M.canonical(feed), 'latest.p7s': b'fixture-feed-signature-not-CMS'}
        for name, raw in self.feed_raw.items():
            write(self.public / 'feed-current' / name, raw)
        self.feed = {name: {'size': len(raw), 'sha256': M.sha(raw)} for name, raw in self.feed_raw.items()}
        self.metadata = {name: {'size': len(raw), 'sha256': M.sha(raw)} for name, raw in self.meta_raw.items()}
        groups = [[entries[0]['path'], entries[1]['path']]] + [[e['path']] for e in entries[2:]]
        assert len(groups) == 11
        bundles = []
        for index, group in enumerate(groups):
            decoded = b'MIR2PK01' + struct.pack('<I', len(group))
            for name in group:
                raw = self.payload[name]
                if decoded_failure == 'bundle-target' and index == 0 and name == group[0]:
                    raw = b'X' + raw[1:]
                encoded = name.encode('ascii')
                decoded += struct.pack('<H', len(encoded)) + encoded + struct.pack('<Q', len(raw)) + raw
            if index == 0 and decoded_failure == 'decoded-trailing':
                decoded += b'forbidden trailing decoded data'
            packed = gzip.compress(decoded, compresslevel=6, mtime=0)
            if index == 0 and decoded_failure == 'gzip-second-member':
                packed += gzip.compress(b'forbidden second member', mtime=0)
            if index == 0 and decoded_failure == 'gzip-trailing':
                packed += b'extra-compressed-tail'
            relative = 'delivery/' + M.sha(packed) + '.m2b.gz'
            write(self.generated / relative, packed)
            bundles.append({'archive': digest_entry(relative, packed), 'files': group})
        # Real copy/literal/copy delta reconstruction, not a stubbed hash verdict.
        prefix, suffix = b'prefix-', b'-suffix'
        literal = b'NEW-CONTENT'
        if decoded_failure == 'delta-target':
            literal = b'BAD-CONTENT'
        copy_offset = len(self.old) - len(suffix)
        if decoded_failure == 'delta-offset':
            copy_offset = len(self.old)
        delta = (b'MIR2DP01' + struct.pack('<IQ', 3, len(self.new))
            + bytes([2 if decoded_failure == 'delta-tag' else 0]) + struct.pack('<QQ', 0, len(prefix))
            + b'\x01' + struct.pack('<Q', len(literal)) + literal
            + b'\x00' + struct.pack('<QQ', copy_offset, len(suffix)))
        packed = gzip.compress(delta, compresslevel=6, mtime=0)
        delta_path = 'delivery/' + M.sha(packed) + '.m2d.gz'
        write(self.generated / delta_path, packed)
        descriptor = {'schema': 'mir2.windows.delivery.v1', 'candidate': M.CANDIDATE,
            'packageManifestSha256': self.metadata['PACKAGE-MANIFEST.json']['sha256'],
            'versionSha256': self.metadata['VERSION.json']['sha256'], 'builtUnix': now - 30,
            'bundles': bundles, 'patches': [{'path': 'mir2-platform-windows.exe',
                'baseSize': len(self.old), 'baseSha256': M.sha(self.old), 'patch': digest_entry(delta_path, packed)}]}
        self.descriptor = descriptor
        descriptor_raw = M.canonical(descriptor)
        signature_raw = b'fixture-opaque-delivery-signature-not-CMS'
        write(self.inputs / 'DELIVERY.json', descriptor_raw)
        write(self.inputs / 'DELIVERY.p7s', signature_raw)
        objects = [digest_entry(M.GAME_DIRECTORY + '/DELIVERY.json', descriptor_raw),
                   digest_entry(M.GAME_DIRECTORY + '/DELIVERY.p7s', signature_raw)]
        objects += [{**b['archive'], 'path': M.GAME_DIRECTORY + '/' + b['archive']['path']} for b in bundles]
        objects.append({**descriptor['patches'][0]['patch'], 'path': M.GAME_DIRECTORY + '/' + delta_path})
        self.objects = sorted(objects, key=lambda o: o['path'])
        source_files = ([{'path': 'feed-current/' + name, **pin} for name, pin in self.feed.items()]
            + [{'path': M.GAME_DIRECTORY + '/' + name, **pin} for name, pin in self.metadata.items()]
            + [{'path': M.GAME_DIRECTORY + '/mir2-platform-windows.exe', **self.exe},
               {'path': M.OLD_DIRECTORY + '/mir2-platform-windows.exe', **self.old_exe}])
        # Extra unrelated publication object proves the subset check, not a 14-only plan.
        closure = self.objects + [digest_entry('unrelated/root-envelope-only.bin', b'inert')]
        plan_objects = [{**o, 'source': 'C:\\fixture-inert\\' + o['path']} for o in closure]
        origin_objects = [{**o, 'source': 'C:\\fixture-inert\\' + o['path']} for o in self.objects]
        approved = {'schema': 'mir2.windows.r2-verification.v1', 'passed': True,
            'candidateVerified': True, 'cmsVerified': True, 'sourceRevision': M.TOOL_SOURCE,
            'sequence': 12, 'feedSha256': self.feed['latest.json']['sha256'],
            'signatureSha256': self.feed['latest.p7s']['sha256'],
            'objectsSha256': M.sha(M.canonical(sorted(closure, key=lambda o: o['path'])))}
        signing = {'passed': True, 'cmsVerified': True, 'decodedPayloadVerified': True,
            'candidate': M.CANDIDATE, 'gameSourceRevision': M.GAME_SOURCE, 'sourceRevision': M.TOOL_SOURCE,
            'deliverySha256': M.sha(descriptor_raw), 'signatureSha256': M.sha(signature_raw)}
        documents = {'ORIGIN-ADDITIONS.json': {'targetRoot': M.PUBLIC_ROOT.as_posix(), 'published': False, 'objects': origin_objects},
            'PUBLICATION-PLAN.json': {'objects': plan_objects}, 'ROOT-VERIFICATION.json': approved,
            'SIGN-DELIVERY.json': signing, 'EXPECTED.json': {'candidateDirectory': M.GAME_DIRECTORY,
                'objects': self.objects, 'sourceFiles': source_files}}
        self.document_values = documents
        input_pins = {}
        for name, value in documents.items():
            raw = M.canonical(value)
            write(self.inputs / name, raw)
            input_pins[name] = M.sha(raw)
        self.pins = M.Pins(input_pins, self.feed, self.metadata, self.exe, self.old_exe,
                           len(entries), sum(e['size'] for e in entries))
        cms = {'schema': 'mir2.origin.public-cms-verification.v1', 'passed': True, 'cmsVerified': True,
            'createdUnix': now, 'candidate': M.CANDIDATE, 'gameSourceRevision': M.GAME_SOURCE,
            'manifestSha256': self.metadata['PACKAGE-MANIFEST.json']['sha256'],
            'versionSha256': self.metadata['VERSION.json']['sha256'], 'privateKeyUsed': False, 'published': False}
        for name, payload, signature in (
            ('feed', self.feed['latest.json'], self.feed['latest.p7s']),
            ('statement', self.metadata['RELEASE-STATEMENT.json'], self.metadata['RELEASE-STATEMENT.p7s']),
            ('delivery', {'sha256': M.sha(descriptor_raw)}, {'sha256': M.sha(signature_raw)})):
            cms[name] = {'payloadSha256': payload['sha256'], 'signatureSha256': signature['sha256'],
                'verifiedAtUnix': now - 30, 'pinnedPublicKeySha256': M.PUBLIC_KEY_SHA, 'privateKeyUsed': False}
        self.cms_value = cms
        cms_raw = M.canonical(cms)
        write(self.inputs / 'CMS-RECHECK.json', cms_raw)
        self.cms_sha = M.sha(cms_raw)
        self.runs = 0
        FIXTURE_RECORDS.append({'label': label, 'root': str(self.root), 'fixtureOnly': True,
            'inputHashes': {**input_pins, 'CMS-RECHECK.json': self.cms_sha},
            'objects': self.objects, 'decodedFailure': decoded_failure})

    def context(self, hook=None, ops=None):
        self.runs += 1
        run_dir = self.stage / f'run-{self.runs:02}'
        run_dir.mkdir(mode=0o700)
        return M.Context(self.inputs, self.generated, run_dir, fixture_root=self.root,
                         pins=self.pins, cms_receipt_sha=self.cms_sha, hook=hook, ops=ops)

    def public_object(self, value):
        return self.public / value['path']

    def mutate_input(self, name, value, repin=False):
        raw = M.canonical(value)
        (self.inputs / name).write_bytes(raw)
        if repin:
            updated = {**self.pins.inputs, name: M.sha(raw)}
            self.pins = dataclasses.replace(self.pins, inputs=updated)


class PublisherTests(unittest.TestCase):
    def assert_denied_without_public_mutation(self, fixture, expected, context=None, mode='apply'):
        before = inventory(fixture.public)
        context = context or fixture.context()
        with self.assertRaisesRegex(Exception, expected):
            context.execute(mode)
        self.assertEqual(before, inventory(fixture.public))
        self.assertFalse((fixture.target / 'DELIVERY.json').exists())
        result = json.loads((context.run_dir / 'RESULT.json').read_bytes())
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(result['createdObjects'], [])
        self.assertFalse(result['cmsVerifiedByPython'])

    def test_preflight_real_gzip_delta_no_public_input_or_generated_writes(self):
        fixture = Fixture('preflight')
        before = [inventory(path) for path in (fixture.public, fixture.inputs, fixture.generated)]
        context = fixture.context()
        result = context.execute('preflight')
        self.assertEqual(before, [inventory(path) for path in (fixture.public, fixture.inputs, fixture.generated)])
        self.assertEqual(result['status'], 'passed')
        self.assertEqual(len(result['validation']['decodedArtifacts']), 12)
        self.assertEqual(result['createdObjects'], [])
        self.assertTrue(result['rootCmsAttestationConsumed'])
        self.assertFalse(result['cmsVerifiedByPython'])

    def test_apply14_order_json_last_baseline_and_sources_unchanged(self):
        fixture = Fixture('apply')
        baseline = inventory(fixture.public)
        sources = [inventory(path) for path in (fixture.inputs, fixture.generated)]
        context = fixture.context()
        result = context.execute('apply')
        created = [o['path'] for o in result['createdObjects']]
        self.assertEqual(len(created), 14)
        self.assertTrue(all(name.startswith('delivery/') for name in created[:12]))
        self.assertEqual(created[-2:], ['DELIVERY.p7s', 'DELIVERY.json'])
        for value in fixture.objects:
            M.Guard(fixture.root).match(fixture.public_object(value), value)
        after = inventory(fixture.public)
        for name, value in baseline.items():
            self.assertEqual(value, after[name])
        self.assertEqual(sources, [inventory(path) for path in (fixture.inputs, fixture.generated)])
        descriptor_events = [e for e in result['events'] if e.get('descriptorVisible')]
        self.assertEqual(len(descriptor_events), 1)
        self.assertEqual(descriptor_events[0]['path'], 'DELIVERY.json')
        self.assertEqual((fixture.stage / 'publisher.lock').read_bytes(), b'fixture existing publisher lock; never modified\n')

    def test_existing_exact_is_idempotent_no_inode_rewrite(self):
        fixture = Fixture('idempotent')
        first = fixture.context()
        first.execute('apply')
        before = inventory(fixture.public)
        second = fixture.context()
        result = second.execute('apply')
        self.assertEqual(result['createdObjects'], [])
        self.assertEqual(len(result['existingExactObjects']), 14)
        self.assertEqual(before, inventory(fixture.public))
        third = fixture.context()
        receipt = second.run_dir / 'RESULT.json'
        with self.assertRaisesRegex(M.Refusal, 'descriptor-not-created-by-that-apply'):
            third.execute('retire-descriptor', receipt, M.sha(receipt.read_bytes()))
        self.assertEqual(before, inventory(fixture.public))

    def test_last_artifact_conflict_refuses_before_any_public_write(self):
        fixture = Fixture('artifact-conflict')
        last = sorted((o for o in fixture.objects if '/delivery/' in o['path']), key=lambda o: o['path'])[-1]
        write(fixture.public_object(last), b'conflicting artifact')
        self.assert_denied_without_public_mutation(fixture, 'pinned-file-(?:size|hash)')

    def test_signature_conflict_refuses_before_any_public_write(self):
        fixture = Fixture('signature-conflict')
        write(fixture.target / 'DELIVERY.p7s', b'conflicting original signature')
        self.assert_denied_without_public_mutation(fixture, 'pinned-file-(?:size|hash)')

    def test_changed_feed_both_json_and_signature(self):
        for name in ('latest.json', 'latest.p7s'):
            with self.subTest(name=name):
                fixture = Fixture('changed-feed-' + name)
                (fixture.public / 'feed-current' / name).write_bytes(b'changed signed feed pair')
                self.assert_denied_without_public_mutation(fixture, 'pinned-file-mismatch')

    def test_changed_candidate_metadata_or_exe(self):
        for name in (*M.META_NAMES, 'mir2-platform-windows.exe'):
            with self.subTest(name=name):
                fixture = Fixture('changed-candidate-' + name)
                (fixture.target / name).write_bytes(b'changed original Candidate')
                self.assert_denied_without_public_mutation(fixture, 'pinned-file')

    def test_original_descriptor_and_signature_bytes_must_match(self):
        for name in ('DELIVERY.json', 'DELIVERY.p7s'):
            with self.subTest(name=name):
                fixture = Fixture('changed-' + name)
                with (fixture.inputs / name).open('ab') as stream:
                    stream.write(b' ')
                self.assert_denied_without_public_mutation(fixture, 'pinned-file-mismatch')

    def test_compressed_artifact_corruption(self):
        fixture = Fixture('corrupt-compressed')
        path = fixture.generated / fixture.descriptor['bundles'][0]['archive']['path']
        raw = bytearray(path.read_bytes())
        raw[-8] ^= 1
        path.write_bytes(raw)
        self.assert_denied_without_public_mutation(fixture, 'invalid-gzip-or-crc|compressed-artifact-hash')

    def test_approved_compressed_hash_is_not_decoded_target_proof(self):
        for fault, error in (
            ('bundle-target', 'decoded-target-hash'), ('delta-target', 'delta-target-hash'),
            ('delta-offset', 'delta-copy-outside-base'), ('delta-tag', 'delta-operation-tag'),
            ('decoded-trailing', 'trailing-decoded-data'),
            ('gzip-second-member', 'extra-gzip-member-or-trailing-bytes'),
            ('gzip-trailing', 'extra-gzip-member-or-trailing-bytes')):
            with self.subTest(fault=fault):
                fixture = Fixture('decoded-' + fault, decoded_failure=fault)
                # Envelope pins agree with the compressed bytes but semantics fail.
                self.assert_denied_without_public_mutation(fixture,
                    error.replace('delta-copy-outside-base', 'delta-copy-outside-base|delta-copy-outside'))

    def test_wrong_old_base_exe_refuses(self):
        fixture = Fixture('wrong-old-base')
        (fixture.old_dir / 'mir2-platform-windows.exe').write_bytes(b'wrong prior EXE')
        self.assert_denied_without_public_mutation(fixture, 'pinned-file-(?:size|hash)')

    def test_root_envelope_and_fresh_cms_have_independent_pin_and_semantic_gates(self):
        for fault in ('old-root-hash', 'old-root-false', 'fresh-hash', 'fresh-false', 'fresh-pair', 'fresh-key'):
            with self.subTest(fault=fault):
                fixture = Fixture('root-' + fault)
                if fault.startswith('old'):
                    value = {**fixture.document_values['ROOT-VERIFICATION.json'], 'cmsVerified': False}
                    fixture.mutate_input('ROOT-VERIFICATION.json', value, repin=fault.endswith('false'))
                    expected = 'root-verification-binding' if fault.endswith('false') else 'root-envelope-input-hash'
                else:
                    value = json.loads(json.dumps(fixture.cms_value))
                    if fault == 'fresh-key':
                        value['delivery']['pinnedPublicKeySha256'] = 'a' * 64
                    elif fault == 'fresh-pair':
                        value['delivery']['signatureSha256'] = 'b' * 64
                    else:
                        value['cmsVerified'] = False
                    fixture.mutate_input('CMS-RECHECK.json', value)
                    if fault != 'fresh-hash':
                        fixture.cms_sha = M.sha((fixture.inputs / 'CMS-RECHECK.json').read_bytes())
                    expected = ('fresh-root-cms-envelope-hash' if fault == 'fresh-hash' else
                        'fresh-root-cms-envelope-binding' if fault == 'fresh-false' else 'fresh-root-cms-pair-binding')
                self.assert_denied_without_public_mutation(fixture, expected)

    def test_input_symlink_and_hardlink_refuse(self):
        for kind in ('symlink', 'hardlink'):
            with self.subTest(kind=kind):
                fixture = Fixture('input-' + kind)
                victim = fixture.inputs / 'DELIVERY.json'
                saved = victim.with_name('saved-DELIVERY.json')
                victim.rename(saved)
                if kind == 'symlink':
                    victim.symlink_to(saved)
                    expected = 'symlink-path|reparse-path'
                else:
                    os.link(saved, victim)
                    expected = 'hardlinked-file'
                self.assert_denied_without_public_mutation(fixture, expected)

    def test_generated_and_public_delivery_parent_symlink_refuse(self):
        for surface in ('generated', 'public'):
            with self.subTest(surface=surface):
                fixture = Fixture('parent-symlink-' + surface)
                if surface == 'generated':
                    victim = fixture.generated / 'delivery'
                    saved = fixture.generated / 'saved-delivery'
                    victim.rename(saved)
                else:
                    victim = fixture.target / 'delivery'
                    saved = fixture.root / 'outside-public-delivery'
                    saved.mkdir(mode=0o700)
                victim.symlink_to(saved, target_is_directory=True)
                self.assert_denied_without_public_mutation(fixture, 'symlink-path|reparse-path')

    def test_dangling_public_delivery_symlink_refuses(self):
        fixture = Fixture('dangling-delivery-link')
        (fixture.target / 'delivery').symlink_to(fixture.root / 'absent', target_is_directory=True)
        self.assert_denied_without_public_mutation(fixture, 'symlink-path|reparse-path')

    def test_existing_public_object_hardlink_refuses(self):
        fixture = Fixture('public-hardlink')
        value = next(o for o in fixture.objects if '/delivery/' in o['path'])
        public = fixture.public_object(value)
        public.parent.mkdir(mode=0o700)
        source = fixture.generated / public.relative_to(fixture.target)
        os.link(source, public)
        self.assert_denied_without_public_mutation(fixture, 'hardlinked-file')

    def test_feed_change_after_private_ready_but_before_first_write_refuses(self):
        fixture = Fixture('feed-before-first-write')
        def hook(event, _context):
            if event == 'ready-complete':
                (fixture.public / 'feed-current/latest.json').write_bytes(b'external feed advance')
        context = fixture.context(hook=hook)
        before = inventory(fixture.target)
        with self.assertRaisesRegex(M.Refusal, 'pinned-file-mismatch'):
            context.execute('apply')
        self.assertEqual(before, inventory(fixture.target))
        self.assertEqual(context.created, [])
        self.assertTrue((context.run_dir / 'ready').is_dir())

    def test_feed_advance_before_json_keeps_payloads_but_discovery_invisible(self):
        fixture = Fixture('feed-before-json')
        def hook(event, _context):
            if event == 'before-promote:DELIVERY.json':
                (fixture.public / 'feed-current/latest.p7s').write_bytes(b'external feed signature advance')
        context = fixture.context(hook=hook)
        with self.assertRaisesRegex(M.Refusal, 'pinned-file-mismatch'):
            context.execute('apply')
        self.assertFalse((fixture.target / 'DELIVERY.json').exists())
        self.assertEqual(len(context.created), 13)
        self.assertEqual(context.created[-1]['path'], 'DELIVERY.p7s')
        result = json.loads((context.run_dir / 'RESULT.json').read_bytes())
        self.assertEqual(result['status'], 'failed')
        self.assertEqual(len(result['createdObjects']), 13)

    def test_candidate_change_before_json_refuses_without_descriptor(self):
        fixture = Fixture('candidate-before-json')
        def hook(event, _context):
            if event == 'before-promote:DELIVERY.json':
                (fixture.target / 'VERSION.json').write_bytes(b'external Candidate replacement')
        context = fixture.context(hook=hook)
        with self.assertRaisesRegex(M.Refusal, 'pinned-file-mismatch'):
            context.execute('apply')
        self.assertFalse((fixture.target / 'DELIVERY.json').exists())
        self.assertEqual(len(context.created), 13)

    def test_late_conflict_never_overwrites_object(self):
        fixture = Fixture('late-conflict')
        def hook(event, _context):
            if event == 'before-promote:DELIVERY.p7s':
                write(fixture.target / 'DELIVERY.p7s', b'external conflicting signature')
        context = fixture.context(hook=hook)
        with self.assertRaisesRegex(M.Refusal, 'pinned-file'):
            context.execute('apply')
        self.assertEqual((fixture.target / 'DELIVERY.p7s').read_bytes(), b'external conflicting signature')
        self.assertFalse((fixture.target / 'DELIVERY.json').exists())
        self.assertEqual(len(context.created), 12)

    def test_create_only_promotion_handles_exact_race_and_refuses_bad_race(self):
        for exact in (True, False):
            with self.subTest(exact=exact):
                fixture = Fixture('rename-race-' + str(exact))
                class RaceOperations(M.Operations):
                    injected = False
                    def rename_new(self, guard, source, target):
                        if not self.injected:
                            self.injected = True
                            write(target, source.read_bytes() if exact else b'conflicting raced destination')
                        return super().rename_new(guard, source, target)
                context = fixture.context(ops=RaceOperations(fixture=True))
                if exact:
                    result = context.execute('apply')
                    self.assertEqual(len(result['existingExactObjects']), 1)
                    self.assertEqual(len(result['createdObjects']), 13)
                else:
                    with self.assertRaisesRegex(M.Refusal, 'pinned-file'):
                        context.execute('apply')
                    self.assertEqual(context.created, [])
                    self.assertFalse((fixture.target / 'DELIVERY.json').exists())

    def test_retirement_moves_only_new_exact_descriptor_to_recorded_private_backup(self):
        fixture = Fixture('retirement')
        apply = fixture.context()
        apply.execute('apply')
        before = inventory(fixture.public)
        receipt = apply.run_dir / 'RESULT.json'
        retire = fixture.context()
        result = retire.execute('retire-descriptor', receipt, M.sha(receipt.read_bytes()))
        self.assertEqual(result['status'], 'passed')
        self.assertFalse((fixture.target / 'DELIVERY.json').exists())
        self.assertTrue((retire.run_dir / 'retired-DELIVERY.json').is_file())
        after = inventory(fixture.public)
        descriptor_name = M.GAME_DIRECTORY + '/DELIVERY.json'
        self.assertEqual(after, {name: value for name, value in before.items() if name != descriptor_name})
        proof = next(o for o in fixture.objects if o['path'].endswith('/DELIVERY.json'))
        M.Guard(fixture.root).match(retire.run_dir / 'retired-DELIVERY.json', proof)

    def test_retirement_rejects_wrong_receipt_hash_or_replaced_descriptor(self):
        for fault in ('receipt-hash', 'same-bytes-new-inode', 'changed-bytes'):
            with self.subTest(fault=fault):
                fixture = Fixture('retire-deny-' + fault)
                apply = fixture.context()
                apply.execute('apply')
                receipt = apply.run_dir / 'RESULT.json'
                expected_hash = M.sha(receipt.read_bytes())
                target = fixture.target / 'DELIVERY.json'
                if fault == 'receipt-hash':
                    expected_hash = '0' * 64
                    error = 'retirement-receipt-hash'
                else:
                    raw = target.read_bytes()
                    target.rename(fixture.stage / 'replaced-original-descriptor.json')
                    write(target, raw if fault == 'same-bytes-new-inode' else b'changed descriptor')
                    error = 'descriptor-identity-changed|pinned-file'
                before = inventory(fixture.public)
                context = fixture.context()
                with self.assertRaisesRegex(M.Refusal, error):
                    context.execute('retire-descriptor', receipt, expected_hash)
                self.assertEqual(before, inventory(fixture.public))
                self.assertFalse((context.run_dir / 'retired-DELIVERY.json').exists())

    def test_retirement_second_identity_check_after_hook(self):
        fixture = Fixture('retire-late-replacement')
        apply = fixture.context()
        apply.execute('apply')
        receipt = apply.run_dir / 'RESULT.json'
        def hook(event, _context):
            if event == 'retirement-validated':
                target = fixture.target / 'DELIVERY.json'
                raw = target.read_bytes()
                target.rename(fixture.stage / 'late-old-descriptor.json')
                write(target, raw)
        context = fixture.context(hook=hook)
        with self.assertRaisesRegex(M.Refusal, 'descriptor-identity-changed-before-retirement'):
            context.execute('retire-descriptor', receipt, M.sha(receipt.read_bytes()))
        self.assertTrue((fixture.target / 'DELIVERY.json').exists())
        self.assertFalse((context.run_dir / 'retired-DELIVERY.json').exists())

    def test_missing_existing_lock_is_not_created(self):
        fixture = Fixture('lock-missing')
        lock = fixture.stage / 'publisher.lock'
        lock.rename(fixture.stage / 'preserved-original-lock')
        self.assert_denied_without_public_mutation(fixture, r'\[WinError 2\]|No such file|cannot find|system cannot')
        self.assertFalse(lock.exists())

    def test_lock_hardlink_refuses_without_content_change(self):
        fixture = Fixture('lock-hardlink')
        lock = fixture.stage / 'publisher.lock'
        before = lock.read_bytes()
        os.link(lock, fixture.stage / 'extra-lock-name')
        self.assert_denied_without_public_mutation(fixture, 'hardlinked-file')
        self.assertEqual(before, lock.read_bytes())

    def test_serialized_competing_fixture_writer_refuses(self):
        fixture = Fixture('lock-busy')
        operations = M.Operations(fixture=True)
        context = fixture.context(ops=operations)
        with operations.lock(context.guard, context.lock_path):
            self.assert_denied_without_public_mutation(fixture, 'publisher-busy', context=context)

    def test_rename_unavailable_retains_stage_without_descriptor_visibility(self):
        fixture = Fixture('rename-unavailable')
        class UnsupportedOperations(M.Operations):
            def rename_new(self, guard, source, target):
                raise M.Refusal('renameat2-unavailable')
        context = fixture.context(ops=UnsupportedOperations(fixture=True))
        with self.assertRaisesRegex(M.Refusal, 'renameat2-unavailable'):
            context.execute('apply')
        self.assertEqual(context.created, [])
        self.assertFalse((fixture.target / 'DELIVERY.json').exists())
        self.assertTrue((context.run_dir / 'ready/DELIVERY.json').is_file())

    def test_scope_guard_and_production_cli_cannot_accept_fixture_override(self):
        with self.assertRaisesRegex(M.Refusal, 'fixture-root-outside'):
            M.Guard(HERE / 'not-fixtures')
        for value in ('../x', '/root', 'delivery//x', 'delivery/../x', 'delivery/.hidden', 'delivery/x\\y', 'CON.bin'):
            with self.subTest(value=value), self.assertRaises(M.Refusal):
                M.relative(value)
        for value in ('C:/fixture', '/srv//evil', '/srv/../evil', '/srv/./evil', '/srv/evil\\x'):
            with self.subTest(value=value), self.assertRaises(M.Refusal):
                M.absolute_argument(value)
        fixture = Fixture('unbounded-path')
        context = fixture.context()
        with self.assertRaisesRegex(M.Refusal, 'fixture-path-escape'):
            context.guard.file_info(HERE / 'origin-r17-append.py')
        if os.name == 'nt':
            production = M.Context(fixture.inputs, fixture.generated, context.run_dir, cms_receipt_sha=fixture.cms_sha)
            with self.assertRaisesRegex(M.Refusal, 'production-linux-root-required'):
                production.validate_paths()

    def test_posix_metadata_root_owner_mode_regular_and_single_link(self):
        valid = types.SimpleNamespace(st_uid=0, st_mode=stat.S_IFREG | 0o600, st_nlink=1)
        M.posix_metadata(valid, False, private=True)
        valid_dir = types.SimpleNamespace(st_uid=0, st_mode=stat.S_IFDIR | 0o700, st_nlink=2)
        M.posix_metadata(valid_dir, True, private=True)
        for fields, error in (({'st_uid': 1000}, 'non-root'),
                              ({'st_mode': stat.S_IFREG | 0o622}, 'shared-writable'),
                              ({'st_mode': stat.S_IFREG | 0o644}, 'non-private'),
                              ({'st_nlink': 2}, 'hardlinked'),
                              ({'st_mode': stat.S_IFIFO | 0o600}, 'wrong-path-type')):
            with self.subTest(fields=fields):
                info = types.SimpleNamespace(**{**vars(valid), **fields})
                with self.assertRaisesRegex(M.Refusal, error):
                    M.posix_metadata(info, False, private=True)

    def test_frozen_real_root_envelope_pins_parse_without_download_or_cms_execution(self):
        # Only reads/copies small public binding receipts; no payload downloading.
        root = Path(tempfile.mkdtemp(prefix='real-envelope-', dir=M.FIXTURE_BASE))
        inputs = root / 'private/inputs'
        inputs.mkdir(parents=True, mode=0o700)
        plan = HERE.parent / 'origin-download-compatibility-plan-01'
        rollout = HERE.parent / 'origin-acceleration-implementation-01'
        source = {
            'ORIGIN-ADDITIONS.json': plan / 'ORIGIN-ADDITIONS.json',
            'ROOT-VERIFICATION.json': plan / 'existing-proof/r17-r2-publication-01/ROOT-VERIFICATION.json',
            'PUBLICATION-PLAN.json': plan / 'existing-proof/r17-r2-publication-01/PUBLICATION-PLAN.json',
            'SIGN-DELIVERY.json': plan / 'existing-proof/r17-download-acceleration-02/SIGN-DELIVERY.json',
            'EXPECTED.json': rollout / 'EXPECTED-02.json',
            'CMS-RECHECK.json': rollout / 'CMS-VERIFICATION-01.json',
        }
        if os.name == 'posix':
            # Root's separately validated upload/copy supplies these exact raw
            # receipts in the fixed private production stage. Still read-only.
            source = {name: M.PRIVATE_STAGE / 'inputs' / name for name in source}
        for name, path in source.items():
            write(inputs / name, path.read_bytes())
        cms_sha = M.sha((inputs / 'CMS-RECHECK.json').read_bytes())
        self.assertEqual(cms_sha, 'f88f248c69f3d4b9bf3624dec171fc23fd2640e093d339f07e4c65a465c158ec')
        context = M.Context(inputs, root / 'private/generated', root / 'private/run',
                            fixture_root=root, pins=M.PINS, cms_receipt_sha=cms_sha)
        objects = context.load_envelope()
        self.assertEqual(len(objects), 14)
        self.assertTrue(context.validation['freshRootCmsEnvelope'])
        self.assertEqual(sum(o['size'] for name, o in objects.items() if name.endswith('.m2b.gz')), 620189573)
        FIXTURE_RECORDS.append({'label': 'actual-frozen-root-envelope', 'root': str(root),
            'actualSourceBindingsOnly': True, 'notDecompressionOrCmsAcceptance': True,
            'inputHashes': {name: M.sha((inputs / name).read_bytes()) for name in source}})


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(PublisherTests)
    started = time.time()
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {'schema': 'mir2.origin.append.local-fixture-tests.v1', 'startedUnix': int(started),
        'finishedUnix': int(time.time()), 'platform': sys.platform, 'python': sys.version,
        'publisherSha256': M.sha((HERE / 'origin-r17-append.py').read_bytes()),
        'testSha256': M.sha(Path(__file__).read_bytes()), 'tests': result.testsRun,
        'passed': result.wasSuccessful(), 'failures': len(result.failures), 'errors': len(result.errors),
        'skipped': result.skipped, 'linuxSyscallAcceptance': False,
        'cmsAuthenticationByTests': False, 'networkOrServiceAction': False,
        'fixturesRetained': FIXTURE_RECORDS}
    output = HERE / ('TEST-RECEIPT-' + str(time.time_ns()) + '.json')
    write(output, M.canonical(receipt))
    print('RAW_RECEIPT=' + str(output))
    raise SystemExit(0 if result.wasSuccessful() else 1)
