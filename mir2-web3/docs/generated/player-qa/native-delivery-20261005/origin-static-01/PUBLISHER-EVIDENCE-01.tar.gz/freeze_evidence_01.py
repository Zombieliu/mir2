"""Create-only local proof indexes; does not edit sources or old evidence."""
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
PLAN = BASE.parent / 'origin-download-compatibility-plan-01'
ROLLOUT = BASE.parent / 'origin-acceleration-implementation-01'
TOOL = Path('C:/Users/Administrator/.codex/worktrees/r2-client-delivery/mir2-player-journey/mir2-web3')
SCRIPTS = TOOL / 'apps/game-client/windows-updater/scripts'


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(65536):
            result.update(block)
    return result.hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode('ascii')


def create(name, value):
    with (BASE / name).open('xb') as stream:
        stream.write(canonical(value))
        stream.flush()
        os.fsync(stream.fileno())


bindings = [
    (SCRIPTS / 'prepare-native-delivery.py', 'a21b98a6efbe7b78e178ffafa7520779e6246e71c44e9545a98224de31f21950'),
    (SCRIPTS / 'verify-native-delivery.py', None),
    (SCRIPTS / 'archive-update-release.py', '9d9803cf35462bb781e91088c385adec6af33d74244cebff162162df96d13bac'),
    (SCRIPTS / 'deploy-server-release.py', '8675d4ee025aeb33e2580a5367362a0e3e90933856c28f176b7915aebdc50b3d'),
    (PLAN / 'PLAN.md', '53f2e0d11e47af2767ad420d1b50ce8ed3c7b6edd07b8a7893b764d8032ae4bb'),
    (PLAN / 'ORIGIN-ADDITIONS.json', 'c47b91cc9ad01f57256a97bfb9ce56fe3475706fee50ce2c81a5b72a5827cd09'),
    (PLAN / 'existing-proof/r17-r2-publication-01/ROOT-VERIFICATION.json', '6b36134597180ad2b423c2015c05b3c48447fbd766e858c2fb0ce6f45e2565b9'),
    (PLAN / 'existing-proof/r17-r2-publication-01/PUBLICATION-PLAN.json', '04bdb9d5f891bba38752e4ba4029db2d638dc7f4674d494ce0c6b5ab354f3b87'),
    (PLAN / 'existing-proof/r17-download-acceleration-02/SIGN-DELIVERY.json', 'b733b8eca497d61a84db1c9bc0d3cce46ab19a291eea47f71e55692bee8588c1'),
    (ROLLOUT / 'EXPECTED-02.json', '0e68a80cb1f77118d239a908f5392daccf13f649810f1e311adf65988990e92b'),
    (ROLLOUT / 'CMS-VERIFICATION-01.json', 'f88f248c69f3d4b9bf3624dec171fc23fd2640e093d339f07e4c65a465c158ec'),
    (BASE.parent / 'r17-download-acceleration-02/DELIVERY.json', 'a72b61448b342656dda4310ceb7ba5aff6608439025775fde2a8303f6ad62de8'),
    (BASE.parent / 'r17-download-acceleration-02/DELIVERY.p7s', 'c3f245cbff7a2e4545d1723cf56d0498b58d7af6360312d53253d255d60eeb93'),
]
source_index = []
for path, expected in bindings:
    actual = digest(path)
    if expected is not None and actual != expected:
        raise RuntimeError('readonly source pin changed: ' + str(path))
    source_index.append({'path': str(path), 'size': path.stat().st_size, 'sha256': actual,
                         'readonlySource': True, 'knownExpectedMatched': expected is not None})
code_sha = digest(BASE / 'origin-r17-append.py')
test_sha = digest(BASE / 'test_origin_r17_append.py')
if code_sha != '10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811' or test_sha != '4ddffa5d88b603a653f5e3135cdba6ec66ce1264ae55b4a4aea4f8e755c8cb18':
    raise RuntimeError('frozen worker code changed')
raw_receipts = []
for path in sorted(BASE.glob('TEST-RECEIPT-*.json')):
    record = json.loads(path.read_bytes())
    raw_receipts.append({'path': path.name, 'sha256': digest(path), 'tests': record['tests'],
        'passed': record['passed'], 'failures': record['failures'], 'errors': record['errors'],
        'publisherSha256AtRun': record['publisherSha256'], 'testSha256AtRun': record['testSha256'],
        'fixturesRetained': len(record['fixturesRetained'])})
last = json.loads((BASE / 'TEST-RECEIPT-1791147477166389800.json').read_bytes())
assert last['passed'] is True and last['tests'] == 31 and last['failures'] == 0 and last['errors'] == 0
assert last['publisherSha256'] == code_sha and last['testSha256'] == test_sha
create('SOURCE-BINDINGS.json', {
    'schema': 'mir2.origin.append.source-bindings.v1', 'createdUnix': int(time.time()),
    'toolSourceRevision': '4c60c323aed11829abae6ee5ce6e13c675a3c1c3',
    'gameSourceRevision': '6032ef8b3e27dd97bad0b20c8676ef9f185db64b',
    'sources': source_index, 'repositoryEdited': False, 'oldEvidenceEdited': False,
    'networkOrServiceAction': False, 'credentialsAccessed': False,
})
create('COMMANDS.json', {
    'schema': 'mir2.origin.append.local-commands.v1', 'python': 'C:/Python313/python.exe',
    'publisherSha256': code_sha, 'testSha256': test_sha,
    'commands': [
        {'argv': ['C:/Python313/python.exe', '-B', str(BASE / 'test_origin_r17_append.py')],
         'stdoutStderrLog': f'local-tests-{index:02}.log'} for index in range(1, 6)
    ],
    'harnessProbes': [
        {'argv': ['C:/Python313/python.exe', '-B', str(BASE / 'probe_windows_stat.py')],
         'stdoutStderrLog': f'windows-stat-harness-{index:02}.log'} for index in range(1, 4)
    ],
    'rawReceipts': raw_receipts, 'networkOrServiceAction': False,
    'linuxActualExecutionByWorker': False,
})
files = []
for current, dirs, names in os.walk(BASE, followlinks=False):
    current = Path(current)
    for name in [*dirs, *names]:
        path = current / name
        info = path.lstat()
        relative = path.relative_to(BASE).as_posix()
        if stat.S_ISLNK(info.st_mode):
            files.append({'path': relative, 'type': 'symlink-fixture', 'target': os.readlink(path)})
        elif stat.S_ISREG(info.st_mode):
            files.append({'path': relative, 'type': 'regular', 'size': info.st_size,
                          'sha256': digest(path), 'nlink': info.st_nlink})
        elif not stat.S_ISDIR(info.st_mode):
            raise RuntimeError('unexpected proof object: ' + str(path))
files.sort(key=lambda o: o['path'])
create('FROZEN-RECEIPT.json', {
    'schema': 'mir2.origin.append.worker-frozen.v1', 'createdUnix': int(time.time()),
    'evidenceDirectory': str(BASE), 'publisherSha256': code_sha, 'testSha256': test_sha,
    'finalTests': {'passed': True, 'tests': 31, 'failures': 0, 'errors': 0, 'skips': 0,
        'rawLog': 'local-tests-05.log', 'rawReceipt': 'TEST-RECEIPT-1791147477166389800.json'},
    'fixtureOrHarnessFailuresPreserved': True, 'manifestSha256': hashlib.sha256(canonical(files)).hexdigest(),
    'evidenceFiles': files, 'runtimeOrRepositoryChange': False, 'oldEvidenceChange': False,
    'networkOrServiceAction': False, 'publicationExecuted': False, 'privateKeyAccess': False,
    'openGates': ['root Linux same-byte negative tests', 'real twelve-artifact decoded preflight',
                  'root approval and static append', 'public HTTPS object closure',
                  'actual old-r16 updater cancel/retry/install closure', 'user laptop download time'],
})
print(json.dumps({'passed': True, 'files': len(files), 'publisherSha256': code_sha,
                  'testSha256': test_sha, 'frozenReceiptSha256': digest(BASE / 'FROZEN-RECEIPT.json')}, sort_keys=True))
