"""Local fixture harness probe only; no network or production changes."""
import importlib.util
import os
from pathlib import Path
import sys
import tempfile

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('publisher_probe', root / 'origin-r17-append.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
module.FIXTURE_BASE.mkdir(exist_ok=True)
fixture = Path(tempfile.mkdtemp(prefix='windows-stat-', dir=module.FIXTURE_BASE))
for index in range(10):
    path = fixture / f'file-{index}.bin'
    path.write_bytes(b'test freshly closed NTFS file')
    os.chmod(path, 0o600)
    before = path.lstat()
    fd = os.open(path, os.O_RDONLY)
    opened = os.fstat(fd)
    after = path.lstat()
    os.close(fd)
    print({'index': index, 'before': module.fingerprint(before),
           'opened': module.fingerprint(opened), 'after': module.fingerprint(after)})
test_spec = importlib.util.spec_from_file_location('publisher_fixture_probe', root / 'test_origin_r17_append.py')
test_module = importlib.util.module_from_spec(test_spec)
sys.modules[test_spec.name] = test_module
test_spec.loader.exec_module(test_module)
case = test_module.Fixture('windows-case-stat')
context = case.context()
for path in [case.stage / 'publisher.lock', case.target / 'mir2-platform-windows.exe', *sorted(case.inputs.iterdir())]:
    before = path.lstat()
    fd = os.open(path, os.O_RDONLY)
    opened = os.fstat(fd)
    after = path.lstat()
    os.close(fd)
    print({'file': path.name, 'before': module.fingerprint(before),
           'opened': module.fingerprint(opened), 'after': module.fingerprint(after),
           'fixtureIdentityEqual': context.guard.identity(before) == context.guard.identity(opened)})
