# Frozen fixed-R17 static-origin append helper

Status: external implementation and offline fixture validation only. This worker
did not upload, access credentials, run SSH, mutate a server/service/player store,
change the feed/Caddy, or test an actual updater download. Root independently
owns the Linux verification, current health/PID/resource gates and any release.

`origin-r17-append.py` is a standalone Python 3.12+ stdlib Linux tool. It accepts
only the existing R17 Candidate directory and the existing exact sequence12
feed pair. Its CLI has no test-root, remote-host, signature, capacity or feed
override. The test-only API is confined to a `fixtures` child of the tool's
directory; production Linux keeps strict root ownership, complete mode/ctime,
single-link regular-file and safe-parent guards.

## Exact inputs and staging

Root prepares the fresh, root-owned0700 stage
`/srv/.mir2-origin-r17-acceleration-20261005-01` with `umask0077`. Its `inputs`,
`generated`, `tools` and a fresh empty `run` or `run-<label>` are separate
children outside public serving, on the Candidate's filesystem. The source of
truth remains the original signed bytes; never copy the generated unsigned
descriptor into `inputs/DELIVERY.json`.

| Exact input name | Original source / required SHA256 |
|---|---|
| `ORIGIN-ADDITIONS.json` | frozen compatibility plan, `c47b91cc9ad01f57256a97bfb9ce56fe3475706fee50ce2c81a5b72a5827cd09` |
| `ROOT-VERIFICATION.json` | frozen R2 publication proof, `6b36134597180ad2b423c2015c05b3c48447fbd766e858c2fb0ce6f45e2565b9` |
| `PUBLICATION-PLAN.json` | frozen R2 plan, `04bdb9d5f891bba38752e4ba4029db2d638dc7f4674d494ce0c6b5ab354f3b87` |
| `SIGN-DELIVERY.json` | original acceleration signing receipt, `b733b8eca497d61a84db1c9bc0d3cce46ab19a291eea47f71e55692bee8588c1` |
| `EXPECTED.json` | raw `EXPECTED-02.json`, `0e68a80cb1f77118d239a908f5392daccf13f649810f1e311adf65988990e92b` |
| `CMS-RECHECK.json` | raw fresh `CMS-VERIFICATION-01.json`, `f88f248c69f3d4b9bf3624dec171fc23fd2640e093d339f07e4c65a465c158ec` |
| `DELIVERY.json` | original signed7,272,337B descriptor, `a72b61448b342656dda4310ceb7ba5aff6608439025775fde2a8303f6ad62de8` |
| `DELIVERY.p7s` | original1,614B detached signature, `c3f245cbff7a2e4545d1723cf56d0498b58d7af6360312d53253d255d60eeb93` |

`generated/delivery/` must contain the original eleven `.m2b.gz` archives and
one `.m2d.gz` delta, under their exact hash names. Extra generator proof files
are retained and ignored; the tool only reads the twelve signed artifact paths.
`EXPECTED.json` pins the exact two current feed files, four original Candidate
metadata files, R17 EXE and old R16 EXE. The workstation `source` strings in the
original plans are inert evidence, never filesystem inputs on Linux.

The tool binds the separately verified CMS receipt by raw SHA and semantic
feed/statement/delivery pairs, pinned public-key digest, candidate/source and
manifest/version. Receipt creation must be within the last24hours, with at most
300seconds future clock skew. Python does not perform CMS authentication; a
correct hash alone is not a trusted signature-verification result. Root's
public-only verification is a separate prerequisite. No private key is read.

The existing `/var/backups/mir2-client-updates/.publisher.lock` must already be a
safe root-owned private single-link regular file. It is opened without create,
truncate or content writes and protected by nonblocking `flock`. A busy or
missing lock refuses. No new private lock bypasses the full-release publisher.

## Validation and visibility protocol

Every apply performs full preflight, even if a previous preflight passed:

1. Pin all input envelopes, authenticate their declared object subset through
   root's trusted raw receipt, and compare exact current feed and original
   Candidate metadata/EXE. Check feed sequence12, validity, candidate and source.
2. Bind the exact original descriptor/signature to the signed target manifest.
   Verify all125,965 file paths, aggregate and753,611,651 target bytes, exact
   eleven-bundle coverage, one known R16→R17 EXE delta and hash-named paths.
3. Actually stream-decompress every gzip archive, rejecting CRC errors, extra
   members, trailing compressed/decoded bytes, bounds violations, wrong file
   ordering/size/target SHA. Reconstruct the delta hash by real copy/literal
   operations from the pinned old R16 EXE; no target executable is executed.
4. Check all14 public targets absent or exact. A conflict, symlink, hardlink or
   unsafe parent refuses before any public write. Only then copy exact sources
   into private `run/ready`, hash them again, fsync and set read-only0444.
5. Recheck original baseline and all target conflicts before first promotion.
   Publish twelve content artifacts, signature, then original `DELIVERY.json`
   LAST using Linux `renameat2(RENAME_NOREPLACE)` on the same filesystem. No
   overwrite, hardlink or unsafe fallback is supported. Fsync source/target
   directories after each rename. Exact preexisting objects stay untouched.
6. Recheck the small exact current feed pair before each promotion. Before
   descriptor visibility, recheck the full original Candidate baseline and
   all thirteen prerequisite objects. Hash the complete public closure again
   at completion. A late change can leave harmless partial payload additions,
   but it stops descriptor discovery and records exactly what was created.

Original game files, four metadata files, feed, bootstrap and engine are never
written. Private numbered audit JSON files and `RESULT.json` are create-only,
fsynced and retained. A failed stage remains available for review; no cleanup
is attempted. The final receipt is written while holding the publisher lock.
No all-zero-online rule is invented for this purely static append. Root checks
health/PIDs/resources before and after; the receipt explicitly says this is
external and not evaluated by the helper.

## Reviewed command shapes (not run by this worker)

Root must first copy/verify these frozen tool bytes as root-owned safe regular
files and create each empty run directory0700. Each invocation uses a NEW run
directory; never reuse or delete a failed run. Replace only the fresh run label.

```sh
python3 -B /srv/.mir2-origin-r17-acceleration-20261005-01/tools/origin-r17-append.py preflight \
  --inputs /srv/.mir2-origin-r17-acceleration-20261005-01/inputs \
  --generated /srv/.mir2-origin-r17-acceleration-20261005-01/generated \
  --run-dir /srv/.mir2-origin-r17-acceleration-20261005-01/run-preflight-01 \
  --cms-receipt-sha256 f88f248c69f3d4b9bf3624dec171fc23fd2640e093d339f07e4c65a465c158ec

python3 -B /srv/.mir2-origin-r17-acceleration-20261005-01/tools/origin-r17-append.py apply \
  --inputs /srv/.mir2-origin-r17-acceleration-20261005-01/inputs \
  --generated /srv/.mir2-origin-r17-acceleration-20261005-01/generated \
  --run-dir /srv/.mir2-origin-r17-acceleration-20261005-01/run-apply-01 \
  --cms-receipt-sha256 f88f248c69f3d4b9bf3624dec171fc23fd2640e093d339f07e4c65a465c158ec
```

This proves local filesystem closure only. Root must separately validate public
TLS/status/encoding/size/hash/cache policy and an actual issued-r16 updater
flow, including failure/retry. This helper does not promise a live route, CDN,
Range support, concurrent download, user-laptop speed or completed publication.

## Descriptor-only reversible retirement

Root may choose `retire-descriptor` with a fresh run directory and a separately
approved exact SHA of a previous **passed apply** `RESULT.json` from the same
private stage. It must record that this invocation actually created the
descriptor; a preexisting/idempotent descriptor is never eligible. It checks
the full original feed/Candidate baseline and exact descriptor hash plus stored
device/inode/mode/uid/nlink/size/timestamps twice, then atomically moves only
`DELIVERY.json` into `run-retire-01/retired-DELIVERY.json` and fsyncs. It leaves
all payloads/signature/raw files and feed available for in-flight requests.

```sh
python3 -B /srv/.mir2-origin-r17-acceleration-20261005-01/tools/origin-r17-append.py retire-descriptor \
  --inputs /srv/.mir2-origin-r17-acceleration-20261005-01/inputs \
  --generated /srv/.mir2-origin-r17-acceleration-20261005-01/generated \
  --run-dir /srv/.mir2-origin-r17-acceleration-20261005-01/run-retire-01 \
  --cms-receipt-sha256 f88f248c69f3d4b9bf3624dec171fc23fd2640e093d339f07e4c65a465c158ec \
  --receipt /srv/.mir2-origin-r17-acceleration-20261005-01/run-apply-01/RESULT.json \
  --receipt-sha256 <root-approved-exact-apply-result-sha256>
```

If the feed/Candidate advanced, the CMS receipt expired, the descriptor's
identity changed or apply did not complete, this conservative retirement
refuses. It does not force a sequence rollback or reinterpret unknown results.
Any later broader recovery needs a separately reviewed, source-bound action.

## Offline tests and retained failures

Final local result:31/31 tests, no skips, Windows Python3.13.6/zlib1.3.1.
Real tiny gzip/delta fixtures exercise corruption, actual decoded target SHA,
late feed/Candidate change, near-last conflicts, symlink/dangling symlink,
hardlink, absent/busy lock, exact race/idempotence, create-only race denial,
signature/CMS-envelope pin and semantic gates, descriptor-only retirement,
identical-byte new-inode refusal, and no public writes on preflight failure.

All test fixtures, original failure receipts and logs are retained here. Fake
fixture signatures never authenticate a release; the separate real-envelope
test only consumes the actual frozen small public receipts with fixed hashes.

| Raw local log | Result and classification |
|---|---|
| `local-tests-01.log` |31 test functions;37 failed subtests/10 errors. Windows harness mismatch: NTFS path-stat vs fd-stat ctime and inferred `.exe` permission bits. Not a production RED acceptance. |
| `local-tests-02.log` |31 functions;27 failed subtests/10 errors. Remaining `.exe` mode discrepancy and localized missing-lock assertion text; original failures retained. |
| `local-tests-03.log` |30/31; one error because Windows `str(Path('/srv/...'))` produces backslashes in the actual frozen origin binding. Changed to explicit POSIX wire spelling, no Linux guard weakening. |
| `local-tests-04.log` |31/31 before final nonfinite JSON rejection, read-only public mode and receipt-under-lock changes. |
| `local-tests-05.log` |31/31 on the frozen final code and tests; final raw receipt is `TEST-RECEIPT-1791147477166389800.json`. |

`windows-stat-harness-01/02/03.log` preserve exact real stat comparisons. The
internal Windows fixture identity omits the inconsistent ctime and inferred
execute permission bits only; production Linux retains both. Windows uses real
create-only `os.rename`, a test-only in-process lock and no directory fsync.
Therefore Linux `flock`, directory fsync, root permissions and `renameat2` are
still explicit OPEN gates; pure metadata tests are not syscall acceptance.

Local command retained in the command receipt:

```powershell
& C:/Python313/python.exe -B C:/mir2-playtest-releases/20261004-native-r18/origin-acceleration-publisher-worker-01/test_origin_r17_append.py
```

Root's same-byte Linux test command, in the private tools directory:

```sh
python3 -B /srv/.mir2-origin-r17-acceleration-20261005-01/tools/test_origin_r17_append.py
```

That test never calls production apply. It retains all tiny fixtures under
`tools/fixtures`, uses real Linux rename/fsync/flock where available and reads
the exact raw envelopes from the fixed private `inputs` path for the binding
test. Root must retain its raw Linux result separately; this Windows receipt
does not claim it passed. Full decompression of the real12 production objects
is a later helper preflight gate, distinct from tiny fixture success.

Code is frozen for root review. All repository/global docs, prior plans and
evidence, source candidates, F installation and actual player saves remain
outside this worker's write set. `SOURCE-BINDINGS.json`, `COMMANDS.json` and
`FROZEN-RECEIPT.json` record exact byte identities and final proof closure.
