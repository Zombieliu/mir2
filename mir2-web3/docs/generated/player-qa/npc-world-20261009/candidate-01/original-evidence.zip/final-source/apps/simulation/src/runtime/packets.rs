use std::collections::{BTreeMap, BTreeSet};
use std::sync::OnceLock;
use std::time::{SystemTime, UNIX_EPOCH};

use bevy_ecs::entity::Entity;
use bevy_ecs::prelude::{Resource, World};
use mir2_game_data::{
    crystal_base_stats_info_packet_payload, crystal_game_shop_info_packet_payloads,
    crystal_guild_buff_list_packet_payload, crystal_item_by_index, crystal_magic_by_spell,
    crystal_map_respawns_by_file_name, crystal_monster_by_index, crystal_monster_by_name,
    crystal_npc_info_manifest, crystal_real_item_for_player, crystal_recipe_bootstrap_packets,
    format_localized_text, localized_text_or_fallback, CrystalItemTemplate, LanguageCode,
};
use mir2_protocol::{
    decode_server_packet, encode_frame, ChatItem, ChatType, ClientAuction, ClientBuff,
    ClientFriend, ClientGtMap, ClientHeroInformation, ClientIntelligentCreature, ClientMail,
    ClientPacket, GroupMember, GuildMember, GuildRank, GuildStorageItem, HeroUserInformation,
    MirClass, MirDirection, MirGender, MirGridType, MonsterInfo, NpcInfo, ObjectDiedInfo,
    ObjectGoldInfo, ObjectHealthInfo, ObjectItemInfo, ObjectManaInfo, ObjectMovement,
    ObjectPlayerInfo, ObjectRevivedInfo, ObjectSpellInfo, ObjectStruckInfo, Point,
    RankCharacterInfo, ServerPacket, ServerPacketId, Spell, StruckInfo, UserInformation, UserItem,
    UserItemStat,
};

use crate::config::{
    new_stage5_mail_delivery_nonce, CharacterRecord, CharacterSaveRecord, EquipmentSlot,
    GroundDropLootSnapshot, GroundDropSnapshot, ItemContainer, MapTransferSnapshot,
    MonsterSpawnSource, NpcScriptDiagnosticSnapshot, QuestStage, SimulationConfig,
    Stage5AuctionListing, Stage5HeroState, Stage5ItemRentalRecordSnapshot,
    Stage5ItemRentalSnapshot, Stage5MailMessage, Stage5SystemsState, Stage5TradeState,
    WorldEntityDisposition, WorldEntityKind, WorldEntitySnapshot, WorldEntitySpriteSnapshot,
    WorldItemTooltipSource, WorldSnapshot,
};

use super::big_map::{
    client_map_info, search as search_big_map, teleport_to_npc_cost, world_map_setup, SearchMapHit,
};
use super::combat::{
    crystal_player_attack_blocked_by_status, crystal_player_can_mount_attack,
    crystal_player_has_class_weapon, crystal_player_is_dazed,
    crystal_player_magic_blocked_by_status, crystal_player_movement_blocked_by_status,
    crystal_player_slowed_by_status, melee_target_is_authoritatively_attackable_in_direction,
};
use super::components::{
    current_hero_object_id, current_player_is_dead, current_player_object_id, entity_facing,
    entity_object_id, entity_player_vitals, entity_position, hero_entity, player_entity,
    CharacterBody, DisplayName, DropOwnership, Facing, GeneralMeowMeowState, GroundDrop,
    HarvestMonsterState, Hero, Monster, MonsterAgent, MonsterAiState, MonsterPoisonState,
    MonsterVitals, Npc, NpcAgent, ObjectId, PlayerVitals, Position, RemotePlayer, SelfPlayer,
    SummonedMonster,
};
use super::crystal_compat::{
    BASE_STORAGE_SLOTS, BUFF_GENERAL_MEOW_MEOW_SHIELD, CRYSTAL_BIND_DONT_STORE,
    CRYSTAL_BIND_NO_HERO, CRYSTAL_ITEM_TYPE_ARMOUR, CRYSTAL_ITEM_TYPE_BELT,
    CRYSTAL_ITEM_TYPE_BOOTS, CRYSTAL_ITEM_TYPE_BRACELET, CRYSTAL_ITEM_TYPE_HELMET,
    CRYSTAL_ITEM_TYPE_NECKLACE, CRYSTAL_ITEM_TYPE_POTION, CRYSTAL_ITEM_TYPE_RING,
    CRYSTAL_ITEM_TYPE_WEAPON, CRYSTAL_POTION_SHAPE_NORMAL, CRYSTAL_POTION_SHAPE_SUN_POTION,
    CRYSTAL_RED_NAME_PK_POINTS, CRYSTAL_STAT_HP, CRYSTAL_STAT_LUCK, CRYSTAL_STAT_MAX_DC,
    CRYSTAL_STAT_MAX_MC, CRYSTAL_STAT_MAX_SC, CRYSTAL_STAT_MIN_DC, CRYSTAL_STAT_MIN_MC,
    CRYSTAL_STAT_MIN_SC, CRYSTAL_STAT_MP, GUIDE_NPC_ID, GUIDE_QUEST_ID,
};
use super::drops::*;
use super::drops::{
    crystal_drop_name_colour_argb, crystal_item_grade_for_key,
    crystal_item_name_colour_argb_for_drop, DropLoot, DropPayload,
};
use super::equipment::*;
use super::equipment::{
    equipment_shape, equipment_slot_index, user_item_from_equipment_state, EquipmentState,
};
use super::fishing::{fishing_cast_impl, fishing_change_autocast_impl};
use super::hero_ai::{hero_inventory_crystal_stat_total, hero_inventory_equipment_slots};
use super::inventory::*;
use super::inventory::{
    current_weight, expand_storage_rental_impl, free_bag_slots, storage_password_required,
};
use super::item_custody;
use super::items::*;
use super::items::{
    crystal_item_template_for_item_key, item_info_from_crystal_template, user_item_from_item_state,
    ItemState,
};
use super::map::{
    active_scene_view, apply_current_player_position_map_transfer,
    crystal_movement_transfer_records_for_map, current_map_disallows_drug,
    current_map_disallows_hero, filter_decor_objects, filter_terrain_patches, is_safe_zone_point,
    normalize_map_file_name, rebuild_world, spawn_stage5_hero,
};
use super::map_events::{
    authorized_map_coordinate_transfers, map_coordinate_hint_packets_for_path,
};
use super::monster_ai::advance_world;
use super::monsters::{
    crystal_monster_effect_for_name, crystal_respawn_object_id,
    crystal_respawn_object_monster_packet, crystal_world_respawn_spawns, point_in_data_range,
    start_game_visible_respawn_spawns,
};
use super::movement::{current_location, town_revive_packets};
use super::npc::{
    buy_item_impl, crystal_npc_object_in_data_range, crystal_npc_object_visible_in_world,
    crystal_npc_visible_to_character_for_profile, crystal_quest_ids_by_npc, dismiss_dialog,
    sell_item_impl,
    CrystalNpcLocalTime, NpcFlagState,
};
use super::quests::{
    abandon_quest, begin_quest, can_accept_quest, complete_quest_with_selection,
    completed_quest_ids, crystal_npc_quest_icon, crystal_quest_finish_npc_matches,
    crystal_quest_info_by_id, crystal_quest_reward_selection_missing,
    crystal_quest_start_npc_matches, crystal_quest_task_list, effective_crystal_quest_info_by_id,
    effective_quest_ids_for_npc, ensure_runtime_quest, newcomer_daily_bonus_update_packet,
    quest_definition_exists, quest_log_snapshots, quest_template_by_id,
};
use super::quests::quest_recurrence::{
    quest_completion_is_permanent, refresh_quest_recurrence,
};
use super::rental::{
    cancel_item_rental_impl, confirm_item_rental_impl, deposit_rental_item_impl,
    get_rented_items_impl, item_rental_fee_impl, item_rental_lock_fee_impl,
    item_rental_lock_item_impl, item_rental_period_impl, item_rental_request_impl,
    retrieve_rental_item_impl,
};
use super::resources::{
    crystal_packet_action_ready, crystal_packet_attack_delay_ticks,
    crystal_packet_move_delay_ticks, crystal_packet_spell_delay_ticks,
    intelligent_creature_default_rules, is_in_world, mark_crystal_packet_action,
    queue_crystal_movement_retry, BuffResource, FishingResource, GmRuntimeResource,
    HeroInventoryResource, InventoryResource, ItemRentalResource, MapRuntimeResource,
    MountResource, NpcStateResource, PlayerActionKind, PlayerPermissionResource,
    PlayerRuntimeResource, PotionRecoveryResource, QuestResource, RuntimeConfigResource,
    RuntimeQueueResource, SessionResource, SkillResource, Stage5SystemsResource,
};
use super::save::*;
use super::session::SimulationSession;
use super::skills::{
    assign_magic_key, cast_skill_with_context, skill_key_for_crystal_spell, SkillCastContext,
};
use super::social_economy::{
    social_blocks_outgoing_mail, stage5_market_sale_price, stage5_market_settlement,
    stage5_trade_item_can_enter,
};
use super::stage5::{
    exact_mail_item_state_is_valid, game_shop_stock_level, push_unique, push_unique_u8,
    stage5_claim_mail_authoritative, stage5_item_name, stage5_player_name,
    validate_stage5_guild_storage_item_carriers, Stage5MailClaimOutcome,
};

const CRYSTAL_NPC_NAME_COLOUR_ARGB: i32 = 0xFF00_FF00u32 as i32;
const CRYSTAL_MAIL_CAPACITY: usize = 100;
pub(super) const MAX_MAIL_RECIPIENT_CHARS: usize = 20;
/// Crystal validates `string.Length`, which counts UTF-16 code units rather
/// than Unicode scalar values.
pub(super) const MAX_MAIL_MESSAGE_CHARS: usize = 500;
const MAIL_TARGET_DURABLE_IDENTITY_MISMATCH: &str = "mail target durable save identity mismatch";

#[derive(Resource, Debug, Default)]
struct BigMapConnectionState {
    world_map_setup_sent: bool,
    sent_map_indexes: BTreeSet<i32>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct ActiveGmAuthorizationIdentity {
    account_id: String,
    character_index: i32,
    character_name: String,
}

#[derive(Resource, Debug, Clone, Default)]
struct AccountGmAuthorizationState {
    password_authorized_identity: Option<ActiveGmAuthorizationIdentity>,
    login_pending_identity: Option<ActiveGmAuthorizationIdentity>,
}

pub(super) fn system_message(message: &str) -> ServerPacket {
    ServerPacket::Chat {
        message: message.to_string(),
        chat_type: mir2_protocol::ChatType::System,
    }
}

pub(super) fn system_message_key(world: &World, key: &str) -> ServerPacket {
    let message = localized_text_or_fallback(super::session::current_language(world), key, key);
    system_message(&message)
}

pub(super) fn hint_chat_key(world: &World, key: &str) -> ServerPacket {
    ServerPacket::Chat {
        message: localized_text_or_fallback(super::session::current_language(world), key, key),
        chat_type: mir2_protocol::ChatType::Hint,
    }
}

pub(super) fn system_message_key_args<I, S>(world: &World, key: &str, args: I) -> ServerPacket
where
    I: IntoIterator<Item = S>,
    S: ToString,
{
    let message = format_localized_text(super::session::current_language(world), key, args);
    system_message(&message)
}

pub(super) fn hint_chat_key_args<I, S>(world: &World, key: &str, args: I) -> ServerPacket
where
    I: IntoIterator<Item = S>,
    S: ToString,
{
    ServerPacket::Chat {
        message: format_localized_text(super::session::current_language(world), key, args),
        chat_type: mir2_protocol::ChatType::Hint,
    }
}

fn current_stage5_character_name(world: &World) -> String {
    world
        .resource::<SessionResource>()
        .selected_character
        .as_ref()
        .map(|character| character.name.clone())
        .unwrap_or_else(|| "Scout".to_string())
}

fn current_stage5_character_index(world: &World) -> i32 {
    world
        .resource::<SessionResource>()
        .selected_character
        .as_ref()
        .map(|character| character.index)
        .unwrap_or_default()
}

// Crystal MailSystem.ini defaults: FreeWithStamp=True, CostPer1k=100,
// InsurancePerItem=5. These are server policy, never supplied by the client.
const MAIL_GOLD_COST_PER_1K: u32 = 100;
const MAIL_INSURANCE_PERCENT: u32 = 5;
const MAIL_BIND_NO_MAIL: i16 = 16_384;

fn stage5_mail_item_allowed(item: &ItemState) -> bool {
    exact_mail_item_state_is_valid(item)
        && stage5_trade_item_can_enter(item)
        && !item_has_crystal_or_rental_bind_flag(item, MAIL_BIND_NO_MAIL)
}

fn stage5_mail_cost(gold: u32, items: &[ItemState], has_stamp: bool) -> Option<u32> {
    if has_stamp {
        return Some(0);
    }
    items.iter().try_fold((gold / 1_000).checked_mul(MAIL_GOLD_COST_PER_1K)?, |cost, item| {
        let template = crystal_item_template_for_item_key(&item.key)?;
        let price = crystal_item_current_price(item, &template, crystal_item_added_stat_weight(item));
        // Match PlayerObject.GetMailCost's double division and per-item floor.
        let insurance = ((f64::from(price) / 100.0) * f64::from(MAIL_INSURANCE_PERCENT)).floor() as u32;
        cost.checked_add(insurance)
    })
}

struct Stage5MailParcelPlan {
    cost: u32,
    stamp: Option<ItemState>,
    attachments: Vec<ItemState>,
}

fn stage5_mail_parcel_plan(
    inventory: &[ItemState], gold: u32, items_idx: &[u64; 5], stamped: bool,
) -> Option<Stage5MailParcelPlan> {
    let ids = stage5_mail_attachment_ids(items_idx)?;
    let stamp = stamped.then(|| inventory.iter().find(|item| {
        matches!(item.container, ItemContainer::Bag1 | ItemContainer::Bag2)
            && item.quantity > 0
            && exact_mail_item_state_is_valid(item)
            && crystal_item_template_for_item_key(&item.key)
                .is_some_and(|template| template.item_type == 0 && template.shape == 1)
    })).flatten().cloned();
    if let Some(stamp) = &stamp {
        let id = item_unique_id(stamp);
        // A stamp cannot pay postage and also be mailed; reject the ambiguous
        // request rather than relying on attachment ordering or stack counts.
        if ids.contains(&id) || inventory.iter().filter(|item| item_unique_id(item) == id).count() != 1 {
            return None;
        }
    } else if items_idx[1..].iter().any(|id| *id != 0) {
        return None;
    }
    let attachments = ids.iter().map(|id| {
        let matches = inventory.iter().filter(|item| item_matches_inventory_unique_id(item, *id)).collect::<Vec<_>>();
        let [item] = matches.as_slice() else { return None; };
        (matches!(item.container, ItemContainer::Bag1 | ItemContainer::Bag2)
            && stage5_mail_item_allowed(item)).then(|| (*item).clone())
    }).collect::<Option<Vec<_>>>()?;
    let cost = stage5_mail_cost(gold, &attachments, stamp.is_some())?;
    Some(Stage5MailParcelPlan { cost, stamp, attachments })
}

fn stage5_mail_quote(world: &World, gold: u32, items_idx: &[u64; 5], stamped: bool) -> Option<u32> {
    let sender = stage5_mail_sender(world)?;
    let config = &world.resource::<RuntimeConfigResource>().config;
    let store = config.account_store.lock().ok()?;
    let account = store.accounts.get(&sender.account_id)?;
    let character = account.characters.iter().find(|character| character.index == sender.character_index && character.name == sender.character_name)?;
    let save = account.saves.get(&character.index)?;
    if save.character.index != character.index || save.character.name != character.name {
        return None;
    }
    let inventory = save.inventory_items_json.iter().map(|state| serde_json::from_str::<ItemState>(state).ok()).collect::<Option<Vec<_>>>()?;
    stage5_mail_parcel_plan(&inventory, gold, items_idx, stamped).map(|plan| plan.cost)
}

#[cfg(test)]
#[path = "mail_parcel_tests.rs"]
mod mail_parcel_tests;

#[derive(Debug, Clone)]
struct Stage5MailSender {
    account_id: String,
    character_index: i32,
    character_name: String,
}

fn stage5_mail_sender(world: &World) -> Option<Stage5MailSender> {
    if !is_in_world(world) {
        return None;
    }
    let session = world.resource::<SessionResource>();
    let account_id = active_session_mutating_account_id(session)?;
    let character = session.selected_character.as_ref()?;
    let character_name = character.name.trim();
    if character_name.is_empty() {
        return None;
    }
    Some(Stage5MailSender {
        account_id,
        character_index: character.index,
        character_name: character_name.to_string(),
    })
}

fn stage5_mail_sender_exists(config: &SimulationConfig, sender: &Stage5MailSender) -> bool {
    config
        .account_store
        .lock()
        .ok()
        .and_then(|store| {
            store.accounts.get(&sender.account_id).map(|account| {
                account.characters.iter().any(|character| {
                    character.index == sender.character_index
                        && character.name == sender.character_name
                })
            })
        })
        .unwrap_or(false)
}

fn stage5_mail_recipient_is_valid(name: &str) -> bool {
    let trimmed = name.trim();
    !trimmed.is_empty()
        && trimmed == name
        && trimmed.chars().count() <= MAX_MAIL_RECIPIENT_CHARS
        && !trimmed.chars().any(char::is_control)
}

fn stage5_mail_message_is_valid(message: &str) -> bool {
    message.encode_utf16().count() <= MAX_MAIL_MESSAGE_CHARS
        && message
            .chars()
            .all(|character| matches!(character, '\r' | '\n') || !character.is_control())
}

#[cfg(test)]
#[path = "mail_body_validation_tests.rs"]
mod mail_body_validation_tests;

#[derive(Debug, Clone)]
struct Stage5MailTarget {
    account_id: String,
    character_index: i32,
    character_name: String,
}

fn stage5_mail_target_for_name(config: &SimulationConfig, name: &str) -> Option<Stage5MailTarget> {
    let name = name.trim();
    if name.is_empty() {
        return None;
    }
    let store = config.account_store.lock().ok()?;
    for (account_id, account) in &store.accounts {
        for character in &account.characters {
            if character.name.eq_ignore_ascii_case(name) {
                return Some(Stage5MailTarget {
                    account_id: account_id.clone(),
                    character_index: character.index,
                    character_name: character.name.clone(),
                });
            }
        }
    }
    None
}

pub(super) fn stage5_append_mail_to_save(
    save: &mut CharacterSaveRecord,
    recipient_name: &str,
    mut mail: Stage5MailMessage,
) -> Result<Stage5MailMessage, String> {
    if mail.delivery_nonce.is_empty() {
        mail.delivery_nonce = new_stage5_mail_delivery_nonce();
    }
    let mut systems = match save.stage5_systems_json.as_deref() {
        Some(state) => serde_json::from_str::<Stage5SystemsState>(state)
            .map_err(|error| format!("failed to decode stage5 mail: {error}"))?,
        None => Stage5SystemsState::default(),
    };
    if systems.mail.iter().filter(|mail| !mail.deleted).count() >= CRYSTAL_MAIL_CAPACITY {
        return Err("mailbox is full".to_string());
    }
    mail.id = systems
        .mail
        .iter()
        .map(|mail| mail.id)
        .max()
        .unwrap_or(0)
        .saturating_add(1);
    mail.to = recipient_name.to_string();
    systems.mail.push(mail.clone());
    save.stage5_systems_json = Some(
        serde_json::to_string(&systems)
            .map_err(|error| format!("failed to encode stage5 mail: {error}"))?,
    );
    Ok(mail)
}

fn stage5_take_mail_attachments_from_save(
    save: &mut CharacterSaveRecord,
    attachment_ids: &[u64],
    expected_states_json: &[String],
) -> Result<Vec<ItemState>, String> {
    if attachment_ids.is_empty() {
        return Ok(Vec::new());
    }
    if attachment_ids.len() != expected_states_json.len() {
        return Err("mail attachment snapshot length changed before commit".to_string());
    }
    let attachment_id_set = attachment_ids.iter().copied().collect::<BTreeSet<_>>();
    let mut removed = BTreeSet::new();
    let mut authoritative = Vec::with_capacity(attachment_ids.len());
    let mut retained = Vec::with_capacity(save.inventory_items_json.len());
    for state in save.inventory_items_json.drain(..) {
        let item = serde_json::from_str::<ItemState>(&state)
            .map_err(|error| format!("failed to decode sender inventory: {error}"))?;
        let unique_id = item_unique_id(&item);
        if attachment_id_set.contains(&unique_id) {
            if !removed.insert(unique_id)
                || !matches!(item.container, ItemContainer::Bag1 | ItemContainer::Bag2)
                || !stage5_mail_item_allowed(&item)
            {
                return Err("mail attachment changed before commit".to_string());
            }
            authoritative.push(item);
        } else {
            retained.push(state);
        }
    }
    if removed != attachment_id_set {
        return Err("mail attachment missing from sender save".to_string());
    }
    authoritative.sort_by_key(|item| {
        attachment_ids
            .iter()
            .position(|unique_id| *unique_id == item_unique_id(item))
            .unwrap_or(usize::MAX)
    });
    for (item, expected) in authoritative.iter().zip(expected_states_json) {
        let encoded = serde_json::to_string(item)
            .map_err(|error| format!("failed to encode authoritative attachment: {error}"))?;
        if &encoded != expected {
            return Err("mail attachment differs from authoritative persisted item".to_string());
        }
    }
    save.inventory_items_json = retained;
    Ok(authoritative)
}

struct Stage5MailCommit {
    sender_gold: u32,
    sender_inventory_items: Vec<ItemState>,
    sender_mail: Vec<Stage5MailMessage>,
    sender_baseline_revision: u64,
    sender_committed_revision: u64,
}

fn stage5_commit_mail_transaction(
    config: &SimulationConfig,
    sender: &Stage5MailSender,
    target: &Stage5MailTarget,
    mut mail: Stage5MailMessage,
    total: u32,
    attachment_ids: &[u64],
    expected_attachment_states_json: &[String],
    items_idx: &[u64; 5],
    stamped: bool,
    expected_stamp_state_json: Option<&str>,
) -> Result<Stage5MailCommit, String> {
    let self_mail =
        sender.account_id == target.account_id && sender.character_index == target.character_index;
    let touched_accounts = vec![sender.account_id.clone(), target.account_id.clone()];
    config.commit_account_store_transaction(&touched_accounts, move |store| {
        let sender_character = store
            .accounts
            .get(&sender.account_id)
            .and_then(|account| {
                account.characters.iter().find(|character| {
                    character.index == sender.character_index
                        && character.name == sender.character_name
                })
            })
            .ok_or_else(|| "mail sender changed before commit".to_string())?;
        let mut sender_save = store
            .accounts
            .get(&sender.account_id)
            .and_then(|account| account.saves.get(&sender.character_index))
            .cloned()
            .ok_or_else(|| "mail sender durable save changed before commit".to_string())?;
        if sender_save.character.index != sender_character.index
            || sender_save.character.name != sender_character.name
        {
            return Err("mail sender save identity mismatch".to_string());
        }
        let mut staged_target_save = if self_mail {
            None
        } else {
            let target_account = store
                .accounts
                .get(&target.account_id)
                .ok_or_else(|| format!("mail target account {} not found", target.account_id))?;
            let target_character = target_account
                .characters
                .iter()
                .find(|character| {
                    character.index == target.character_index
                        && character.name == target.character_name
                })
                .cloned()
                .ok_or_else(|| {
                    format!("mail target character {} not found", target.character_name)
                })?;
            let target_save = match target_account.saves.get(&target.character_index) {
                Some(target_save) => {
                    if target_save.character.index != target_character.index
                        || target_save.character.name != target_character.name
                    {
                        return Err(MAIL_TARGET_DURABLE_IDENTITY_MISMATCH.to_string());
                    }
                    target_save.clone()
                }
                None => CharacterSaveRecord::new(target_character),
            };
            Some(target_save)
        };
        let sender_baseline_revision = sender_save.revision;
        let durable_inventory = sender_save.inventory_items_json.iter()
            .map(|state| serde_json::from_str::<ItemState>(state))
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("invalid parcel inventory: {error}"))?;
        let durable_plan = stage5_mail_parcel_plan(&durable_inventory, mail.gold, items_idx, stamped)
            .ok_or_else(|| "parcel ownership or postage changed before commit".to_string())?;
        let durable_stamp_json = durable_plan.stamp.as_ref().map(serde_json::to_string).transpose()
            .map_err(|error| format!("invalid parcel stamp: {error}"))?;
        if durable_stamp_json.as_deref() != expected_stamp_state_json
            || mail.gold.checked_add(durable_plan.cost) != Some(total)
        {
            return Err("parcel stamp or fee changed before commit".to_string());
        }
        let removed_attachments = stage5_take_mail_attachments_from_save(
            &mut sender_save,
            attachment_ids,
            expected_attachment_states_json,
        )?;
        sender_save.gold = sender_save
            .gold
            .checked_sub(total)
            .ok_or_else(|| "sender gold changed before mail commit".to_string())?;
        if let Some(mut stamp) = durable_plan.stamp {
            let stamp_id = item_unique_id(&stamp);
            let index = sender_save.inventory_items_json.iter().position(|state| {
                serde_json::from_str::<ItemState>(state).is_ok_and(|item| item_unique_id(&item) == stamp_id)
            }).ok_or_else(|| "parcel stamp disappeared before commit".to_string())?;
            if stamp.quantity == 1 {
                sender_save.inventory_items_json.remove(index);
            } else {
                stamp.quantity -= 1;
                sender_save.inventory_items_json[index] = serde_json::to_string(&stamp)
                    .map_err(|error| format!("failed to encode consumed stamp: {error}"))?;
            }
        }
        mail.items = removed_attachments
            .iter()
            .map(|item| item.key.clone())
            .collect();
        mail.item_states_json = removed_attachments
            .iter()
            .map(serde_json::to_string)
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("failed to encode authoritative mail attachment: {error}"))?;

        let _committed_mail = if self_mail {
            stage5_append_mail_to_save(&mut sender_save, &target.character_name, mail)?
        } else {
            let mut target_save = staged_target_save
                .take()
                .expect("non-self mail target save should be staged");
            let committed =
                stage5_append_mail_to_save(&mut target_save, &target.character_name, mail)?;
            target_save.revision = target_save
                .revision
                .checked_add(1)
                .ok_or_else(|| "mail target revision exhausted".to_string())?;
            store
                .accounts
                .get_mut(&target.account_id)
                .expect("validated mail target account should exist")
                .saves
                .insert(target.character_index, target_save);
            committed
        };

        let sender_committed_revision = sender_baseline_revision
            .checked_add(1)
            .ok_or_else(|| "mail sender revision exhausted".to_string())?;
        sender_save.revision = sender_committed_revision;
        let sender_gold = sender_save.gold;
        let sender_inventory_items = sender_save
            .inventory_items_json
            .iter()
            .map(|state| serde_json::from_str::<ItemState>(state))
            .collect::<Result<Vec<_>, _>>()
            .map_err(|error| format!("failed to decode committed sender inventory: {error}"))?;
        let sender_mail = sender_save
            .stage5_systems_json
            .as_deref()
            .map(serde_json::from_str::<Stage5SystemsState>)
            .transpose()
            .map_err(|error| format!("failed to decode committed sender mailbox: {error}"))?
            .unwrap_or_default()
            .mail;
        store
            .accounts
            .get_mut(&sender.account_id)
            .expect("validated mail sender account should exist")
            .saves
            .insert(sender.character_index, sender_save);

        Ok(Stage5MailCommit {
            sender_gold,
            sender_inventory_items,
            sender_mail,
            sender_baseline_revision,
            sender_committed_revision,
        })
    })
}

fn stage5_mail_attachment_ids(items_idx: &[u64; 5]) -> Option<Vec<u64>> {
    let mut seen = BTreeSet::new();
    let mut ids = Vec::new();
    for unique_id in items_idx
        .iter()
        .copied()
        .filter(|unique_id| *unique_id != 0)
    {
        if !seen.insert(unique_id) {
            return None;
        }
        ids.push(unique_id);
    }
    Some(ids)
}

fn stage5_mail_attachment_user_items(mail: &Stage5MailMessage) -> Vec<UserItem> {
    if !mail.item_states_json.is_empty() {
        let Ok(items) = mail
            .item_states_json
            .iter()
            .map(|state| serde_json::from_str::<ItemState>(state))
            .collect::<Result<Vec<_>, _>>()
        else {
            return Vec::new();
        };
        return items.iter().map(user_item_from_item_state).collect();
    }
    mail.items
        .iter()
        .enumerate()
        .map(|(index, key)| {
            let unique_id = (u64::from(mail.id) << 32) | u64::try_from(index + 1).unwrap_or(1);
            stage5_guild_user_item_for_key(key, unique_id)
        })
        .collect()
}

fn stage5_mail_to_client_mail(mail: &Stage5MailMessage) -> ClientMail {
    let message = if mail.subject.is_empty() {
        mail.body.clone()
    } else if mail.body.is_empty() {
        mail.subject.clone()
    } else {
        format!("{}\n{}", mail.subject, mail.body)
    };
    ClientMail {
        mail_id: u64::from(mail.id),
        sender_name: mail.from.clone(),
        message,
        opened: mail.opened,
        locked: mail.locked,
        can_reply: true,
        collected: mail.claimed,
        // Legacy Stage5 mail has no persisted send timestamp. Re-projecting
        // the mailbox must not invent a new sent date on every refresh.
        // Zero is an unknown date until durable creation metadata is supplied.
        date_sent_binary_datetime: 0,
        gold: mail.gold,
        items: stage5_mail_attachment_user_items(mail),
    }
}

pub(super) fn stage5_receive_mail_packet(world: &World) -> ServerPacket {
    let mail = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .mail
        .iter()
        .filter(|mail| !mail.deleted)
        .map(stage5_mail_to_client_mail)
        .collect();
    ServerPacket::ReceiveMail { mail }
}

fn stage5_send_mail_packet(
    world: &mut World,
    name: String,
    message: String,
    gold: u32,
    items_idx: [u64; 5],
    stamped: bool,
) -> Vec<ServerPacket> {
    let Some(sender) = stage5_mail_sender(world) else {
        return vec![ServerPacket::MailSent { result: -1 }];
    };
    if !stage5_mail_recipient_is_valid(&name) || !stage5_mail_message_is_valid(&message) {
        return vec![ServerPacket::MailSent { result: -1 }];
    }
    let Some(attachment_ids) = stage5_mail_attachment_ids(&items_idx) else {
        return vec![ServerPacket::MailSent { result: -1 }];
    };
    if social_blocks_outgoing_mail(
        &world
            .resource::<Stage5SystemsResource>()
            .stage5_systems
            .social,
        &name,
    ) {
        return vec![ServerPacket::MailSent { result: -1 }];
    }
    let config = world.resource::<RuntimeConfigResource>().config.clone();
    if !stage5_mail_sender_exists(&config, &sender) {
        return vec![ServerPacket::MailSent { result: -1 }];
    }
    let Some(target) = stage5_mail_target_for_name(&config, &name) else {
        return vec![ServerPacket::MailSent { result: -1 }];
    };
    let Some(plan) = stage5_mail_parcel_plan(
        &world.resource::<InventoryResource>().inventory_items, gold, &items_idx, stamped,
    ) else {
        return vec![ServerPacket::MailSent { result: -1 }];
    };
    let Some(total) = gold.checked_add(plan.cost) else {
        return vec![ServerPacket::MailSent { result: -1 }];
    };
    if world.resource::<PlayerRuntimeResource>().gold < total {
        return vec![ServerPacket::MailSent { result: -1 }];
    }
    let Some(sender_save) = snapshot_active_character_save(world) else {
        return vec![ServerPacket::MailSent { result: -1 }];
    };

    let item_states_json = match plan.attachments
        .iter()
        .map(serde_json::to_string)
        .collect::<Result<Vec<_>, _>>()
    {
        Ok(states) => states,
        Err(_) => return vec![ServerPacket::MailSent { result: -1 }],
    };
    let stamp_state_json = match plan.stamp.as_ref().map(serde_json::to_string).transpose() {
        Ok(state) => state,
        Err(_) => return vec![ServerPacket::MailSent { result: -1 }],
    };
    let mail = Stage5MailMessage {
        id: 0,
        delivery_nonce: new_stage5_mail_delivery_nonce(),
        from: sender.character_name.clone(),
        to: target.character_name.clone(),
        subject: String::new(),
        body: message,
        gold,
        items: Vec::new(),
        item_states_json: Vec::new(),
        opened: false,
        locked: false,
        claimed: false,
        deleted: false,
    };
    let committed = match stage5_commit_mail_transaction(
        &config,
        &sender,
        &target,
        mail,
        total,
        &attachment_ids,
        &item_states_json,
        &items_idx,
        stamped,
        stamp_state_json.as_deref(),
    ) {
        Ok(committed) => committed,
        Err(error) => {
            if error == MAIL_TARGET_DURABLE_IDENTITY_MISMATCH {
                return Vec::new();
            }
            eprintln!("mail transaction failed: {error}");
            return vec![ServerPacket::MailSent { result: -1 }];
        }
    };

    if committed.sender_baseline_revision == sender_save.revision {
        world
            .resource::<SessionResource>()
            .advance_active_save_revision(
                sender_save.revision,
                committed.sender_committed_revision,
            );
    }

    // The durable sender image is authoritative. A stale same-account session
    // is fully synchronized for the fields this transaction can affect, so an
    // attachment removed by another session cannot remain in this World.
    let committed_quantities = committed
        .sender_inventory_items
        .iter()
        .map(|item| (item_unique_id(item), item.quantity))
        .collect::<BTreeMap<_, _>>();
    let removed_from_live = world
        .resource::<InventoryResource>()
        .inventory_items
        .iter()
        .filter_map(|item| {
            let remaining = committed_quantities.get(&item_unique_id(item)).copied().unwrap_or(0);
            let removed = item.quantity.saturating_sub(remaining);
            (removed > 0).then_some((item_unique_id(item), removed))
        })
        .collect::<Vec<_>>();
    world.resource_mut::<PlayerRuntimeResource>().gold = committed.sender_gold;
    world.resource_mut::<InventoryResource>().inventory_items = committed.sender_inventory_items;
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .mail = committed.sender_mail;

    let mut packets = Vec::new();
    if total > 0 {
        packets.push(ServerPacket::LoseGold { gold: total });
    }
    for (unique_id, count) in removed_from_live {
        packets.push(ServerPacket::DeleteItem {
            unique_id,
            count: count.min(u32::from(u16::MAX)) as u16,
        });
    }
    packets.push(ServerPacket::MailSent { result: 1 });
    packets.push(stage5_receive_mail_packet(world));
    packets
}

fn stage5_collect_mail_packet(world: &mut World, mail_id: u64) -> Vec<ServerPacket> {
    let Some(mail_id) = u32::try_from(mail_id).ok() else {
        return Vec::new();
    };
    let base_inventory = world.resource::<InventoryResource>().clone();
    let base_player = world.resource::<PlayerRuntimeResource>().clone();
    let base_mail = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .mail
        .clone();
    let committed = commit_active_character_save_transaction(world, move |save| {
        let mut staged_inventory = base_inventory;
        staged_inventory.inventory_items =
            decode_mail_claim_item_states(&save.inventory_items_json, "active inventory")?;
        staged_inventory.belt_items =
            decode_mail_claim_item_states(&save.belt_items_json, "active belt")?;
        staged_inventory.storage_items =
            decode_mail_claim_item_states(&save.storage_items_json, "active storage")?;

        let mut staged_player = base_player;
        staged_player.gold = save.gold;
        staged_player.credit = save.credit;
        let mut staged_systems = save
            .stage5_systems_json
            .as_deref()
            .map(serde_json::from_str::<Stage5SystemsState>)
            .transpose()
            .map_err(|error| format!("failed to decode staged claim mailbox: {error}"))?
            .unwrap_or_default();
        let mut visible_mail = base_mail;
        merge_external_stage5_mail(&mut visible_mail, std::mem::take(&mut staged_systems.mail))?;
        staged_systems.mail = visible_mail;

        let mut staged_world = World::new();
        staged_world.insert_resource(staged_inventory);
        staged_world.insert_resource(staged_player);
        staged_world.insert_resource(Stage5SystemsResource {
            stage5_systems: staged_systems,
        });
        let claim = stage5_claim_mail_authoritative(&mut staged_world, mail_id)
            .map_err(|error| format!("mail claim rejected: {error:?}"))?;

        let staged_inventory = staged_world.resource::<InventoryResource>().clone();
        let staged_player = staged_world.resource::<PlayerRuntimeResource>();
        let committed_gold = staged_player.gold;
        let committed_credit = staged_player.credit;
        let staged_systems = staged_world
            .resource::<Stage5SystemsResource>()
            .stage5_systems
            .clone();
        save.gold = committed_gold;
        save.credit = committed_credit;
        save.inventory_items_json = encode_state_vec(&staged_inventory.inventory_items);
        save.belt_items_json = encode_state_vec(&staged_inventory.belt_items);
        save.stage5_systems_json = Some(
            serde_json::to_string(&staged_systems)
                .map_err(|error| format!("failed to encode staged claim mailbox: {error}"))?,
        );

        Ok(Stage5MailClaimCommit {
            claim,
            gold: committed_gold,
            inventory_items: staged_inventory.inventory_items,
            belt_items: staged_inventory.belt_items,
            stage5_systems: staged_systems,
        })
    });
    let Ok(committed) = committed else {
        if let Err(error) = committed {
            eprintln!("mail claim transaction failed: {error}");
        }
        // Crystal PlayerObject.CollectMail silently returns when the addressed
        // mail is absent or cannot be collected. ParcelCollected(-1) belongs to
        // the NPCScript bulk [@COLLECTPARCEL] path, not this single-mail command.
        return Vec::new();
    };

    // The durable account-store transaction is authoritative. Only after it
    // succeeds do we mirror the exact staged result into the active World and
    // emit currency/item/success packets.
    world.resource_mut::<PlayerRuntimeResource>().gold = committed.gold;
    {
        let mut inventory = world.resource_mut::<InventoryResource>();
        inventory.inventory_items = committed.inventory_items;
        inventory.belt_items = committed.belt_items;
    }
    world.resource_mut::<Stage5SystemsResource>().stage5_systems = committed.stage5_systems;

    let mut packets = Vec::new();
    if committed.claim.gold > 0 {
        packets.push(ServerPacket::GainedGold {
            gold: committed.claim.gold,
        });
    }
    for item in committed.claim.items {
        packets.push(ServerPacket::GainedItem {
            item: user_item_from_item_state(&item),
        });
    }
    packets.push(ServerPacket::ParcelCollected { result: 1 });
    packets.push(stage5_receive_mail_packet(world));
    packets
}

#[derive(Debug, Clone)]
struct Stage5MailClaimCommit {
    claim: Stage5MailClaimOutcome,
    gold: u32,
    inventory_items: Vec<ItemState>,
    belt_items: Vec<ItemState>,
    stage5_systems: Stage5SystemsState,
}

fn decode_mail_claim_item_states(states: &[String], label: &str) -> Result<Vec<ItemState>, String> {
    states
        .iter()
        .map(|state| {
            serde_json::from_str::<ItemState>(state)
                .map_err(|error| format!("failed to decode {label} for mail claim: {error}"))
        })
        .collect()
}

#[derive(Debug, Clone, Copy)]
enum Stage5MailStatusMutation {
    Read,
    Lock { locked: bool },
    Delete,
}

/// Mutate mailbox status from the lock-held, latest durable character save.
///
/// The live ECS mailbox is deliberately not touched by the transaction
/// closure.  That makes malformed/missing/deleted/locked requests and any
/// persistence failure observationally atomic: the account store, file and
/// World all remain unchanged unless the durable commit succeeds.
fn stage5_commit_mail_status_transaction(
    world: &World,
    mail_id: u64,
    mutation: Stage5MailStatusMutation,
) -> Result<Stage5SystemsState, String> {
    let exact_mail_id = u32::try_from(mail_id)
        .map_err(|_| "mail status request has an invalid mail identity".to_string())?;

    commit_active_character_save_transaction(world, move |save| {
        let mut systems = save
            .stage5_systems_json
            .as_deref()
            .map(serde_json::from_str::<Stage5SystemsState>)
            .transpose()
            .map_err(|error| format!("failed to decode durable mailbox: {error}"))?
            .unwrap_or_default();
        let mail = systems
            .mail
            .iter_mut()
            .find(|mail| mail.id == exact_mail_id && u64::from(mail.id) == mail_id)
            .ok_or_else(|| "mail identity not found in durable mailbox".to_string())?;
        if mail.deleted {
            return Err("mail status request targets deleted mail".to_string());
        }
        match mutation {
            Stage5MailStatusMutation::Read => mail.opened = true,
            Stage5MailStatusMutation::Lock { locked } => mail.locked = locked,
            Stage5MailStatusMutation::Delete => {
                if mail.locked {
                    return Err("locked mail cannot be deleted".to_string());
                }
                mail.deleted = true;
            }
        }
        save.stage5_systems_json = Some(
            serde_json::to_string(&systems)
                .map_err(|error| format!("failed to encode durable mailbox: {error}"))?,
        );
        Ok(systems)
    })
}

fn stage5_mail_status_packet(
    world: &mut World,
    mail_id: u64,
    mutation: Stage5MailStatusMutation,
) -> Vec<ServerPacket> {
    match stage5_commit_mail_status_transaction(world, mail_id, mutation) {
        Ok(committed_mailbox) => {
            world.resource_mut::<Stage5SystemsResource>().stage5_systems = committed_mailbox;
            vec![stage5_receive_mail_packet(world)]
        }
        Err(error) => {
            eprintln!("mail status transaction rejected: {error}");
            // Crystal MirConnection/PlayerObject silently returns when the
            // request is out of Game stage or the addressed mail is absent.
            // Never project the stale live mailbox on an identity/persistence
            // rejection because it may belong to a previously bound account.
            Vec::new()
        }
    }
}

fn stage5_read_mail_packet(world: &mut World, mail_id: u64) -> Vec<ServerPacket> {
    stage5_mail_status_packet(world, mail_id, Stage5MailStatusMutation::Read)
}

fn stage5_lock_mail_packet(world: &mut World, mail_id: u64, lock: bool) -> Vec<ServerPacket> {
    stage5_mail_status_packet(
        world,
        mail_id,
        Stage5MailStatusMutation::Lock { locked: lock },
    )
}

fn stage5_delete_mail_packet(world: &mut World, mail_id: u64) -> Vec<ServerPacket> {
    stage5_mail_status_packet(world, mail_id, Stage5MailStatusMutation::Delete)
}

fn stage5_refresh_friend_identities(world: &mut World) {
    let social = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .social
        .clone();
    let config = world.resource::<RuntimeConfigResource>().config.clone();
    let resolved = {
        let Ok(store) = config.account_store.lock() else {
            return;
        };
        social
            .friends
            .iter()
            .map(|name| (name, false))
            .chain(social.blocked.iter().map(|name| (name, true)))
            .filter_map(|(old_name, blocked)| {
                let found = if let Some(identity) = social.friend_identities.get(old_name) {
                    store
                        .accounts
                        .get(&identity.account_id)
                        .and_then(|account| {
                            account
                                .characters
                                .iter()
                                .find(|character| character.index == identity.character_index)
                                .map(|character| (identity.account_id.clone(), character))
                        })
                } else {
                    store.accounts.iter().find_map(|(account_id, account)| {
                        account
                            .characters
                            .iter()
                            .find(|character| character.name.eq_ignore_ascii_case(old_name))
                            .map(|character| (account_id.clone(), character))
                    })
                }?;
                Some((
                    found.1.name.clone(),
                    blocked,
                    crate::config::Stage5FriendIdentity {
                        account_id: found.0,
                        character_index: found.1.index,
                    },
                    social.memos.get(old_name).cloned().unwrap_or_default(),
                ))
            })
            .collect::<Vec<_>>()
    };
    let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
    let social = &mut stage5.stage5_systems.social;
    social.friends.clear();
    social.blocked.clear();
    social.friend_identities.clear();
    social.memos.clear();
    for (name, blocked, identity, memo) in resolved {
        if social
            .friend_identities
            .values()
            .any(|existing| existing == &identity)
        {
            continue;
        }
        if blocked {
            social.blocked.push(name.clone());
        } else {
            social.friends.push(name.clone());
        }
        social.friend_identities.insert(name.clone(), identity);
        if !memo.is_empty() {
            social.memos.insert(name, memo);
        }
    }
}

fn stage5_friend_entries(world: &World) -> Vec<ClientFriend> {
    let social = &world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .social;
    social
        .friends
        .iter()
        .map(|name| (name, false))
        .chain(social.blocked.iter().map(|name| (name, true)))
        .filter_map(|(name, blocked)| {
            let index = social.friend_identities.get(name)?.character_index;
            // The ordinary protocol only carries the index, so ambiguous legacy
            // identities must not be displayed or addressed by index-only mutations.
            if social
                .friend_identities
                .values()
                .filter(|id| id.character_index == index)
                .count()
                != 1
            {
                return None;
            }
            Some(ClientFriend {
                index,
                name: name.clone(),
                memo: social.memos.get(name).cloned().unwrap_or_default(),
                blocked,
                online: false,
            })
        })
        .collect()
}

fn stage5_friend_update_packet(world: &World) -> ServerPacket {
    ServerPacket::FriendUpdate {
        friends: stage5_friend_entries(world),
    }
}

fn stage5_add_friend_packet(world: &mut World, name: String, blocked: bool) -> Vec<ServerPacket> {
    let Some((self_identity, _)) = strict_active_account_authorization(world) else {
        return Vec::new();
    };
    stage5_refresh_friend_identities(world);
    let config = world.resource::<RuntimeConfigResource>().config.clone();
    let target = {
        let Ok(store) = config.account_store.lock() else {
            return Vec::new();
        };
        store.accounts.iter().find_map(|(account_id, account)| {
            account
                .characters
                .iter()
                .find(|character| character.name.eq_ignore_ascii_case(&name))
                .map(|character| {
                    (
                        character.name.clone(),
                        crate::config::Stage5FriendIdentity {
                            account_id: account_id.clone(),
                            character_index: character.index,
                        },
                    )
                })
        })
    };
    let Some((name, identity)) = target else {
        return vec![system_message_key(world, "server.PlayerDoesNotExist")];
    };
    if identity.account_id == self_identity.account_id
        && identity.character_index == self_identity.character_index
    {
        return vec![system_message_key(world, "server.CannotAddYourself")];
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .social
        .friend_identities
        .values()
        .any(|existing| {
            existing == &identity || existing.character_index == identity.character_index
        })
    {
        return vec![system_message_key(world, "server.PlayerAlreadyAdded")];
    }
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let social = &mut stage5.stage5_systems.social;
        if blocked {
            social.blocked.push(name.clone());
        } else {
            social.friends.push(name.clone());
        }
        social.friend_identities.insert(name, identity);
    }
    vec![stage5_friend_update_packet(world)]
}

fn stage5_remove_friend_packet(world: &mut World, character_index: i32) -> Vec<ServerPacket> {
    if strict_active_account_authorization(world).is_none() {
        return Vec::new();
    }
    stage5_refresh_friend_identities(world);
    let Some(name) = stage5_friend_entries(world)
        .into_iter()
        .find(|friend| friend.index == character_index)
        .map(|friend| friend.name)
    else {
        return Vec::new();
    };
    let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
    let social = &mut stage5.stage5_systems.social;
    social.friends.retain(|friend| friend != &name);
    social.blocked.retain(|friend| friend != &name);
    social.memos.remove(&name);
    social.friend_identities.remove(&name);
    drop(stage5);
    vec![stage5_friend_update_packet(world)]
}

fn stage5_add_memo_packet(
    world: &mut World,
    character_index: i32,
    memo: String,
) -> Vec<ServerPacket> {
    if strict_active_account_authorization(world).is_none()
        || memo.is_empty()
        || memo.encode_utf16().count() > 200
    {
        return Vec::new();
    }
    stage5_refresh_friend_identities(world);
    let Some(name) = stage5_friend_entries(world)
        .into_iter()
        .find(|friend| friend.index == character_index)
        .map(|friend| friend.name)
    else {
        return Vec::new();
    };
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .social
        .memos
        .insert(name, memo);
    vec![stage5_friend_update_packet(world)]
}
fn stage5_hero_info(index: i32, hero: &Stage5HeroState) -> ClientHeroInformation {
    ClientHeroInformation {
        index,
        name: hero.name.clone(),
        level: hero.level,
        class: hero.class,
        gender: hero.gender,
    }
}

fn stage5_hero_inventory_items(world: &World) -> Vec<Option<UserItem>> {
    let hero_inventory = world.resource::<HeroInventoryResource>();
    let mut items = vec![None; usize::from(hero_inventory.capacity)];
    for item in &hero_inventory.items {
        let Some(slot) = items.get_mut(usize::from(item.slot)) else {
            continue;
        };
        *slot = Some(user_item_from_item_state(item));
    }
    items
}

fn stage5_hero_information_packet(world: &World) -> Option<ServerPacket> {
    let hero = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .hero
        .as_ref()?;
    let object_id = current_hero_object_id(world).unwrap_or_else(|| {
        world
            .resource::<RuntimeConfigResource>()
            .config
            .object_id
            .saturating_add(1)
    });
    let max_hp = super::hero_ai::hero_authoritative_stat(world, CRYSTAL_STAT_HP).max(0);
    let max_mp = super::hero_ai::hero_authoritative_stat(world, CRYSTAL_STAT_MP).max(0);
    let live = hero_entity(world).and_then(|entity| entity_player_vitals(world, entity));
    let saved = world.resource::<HeroInventoryResource>().saved_vitals;
    let hp = live.map(|v|v.hp).or_else(||saved.map(|v|v.hp)).unwrap_or(max_hp);
    let mp = live.map(|v|v.mp).or_else(||saved.map(|v|v.mp)).unwrap_or(max_mp);
    let magics = world.resource::<Stage5SystemsResource>().stage5_systems.hero_learned_magics.iter().filter_map(|learned| {
        let template = crystal_magic_by_spell(&format!("{:?}", learned.spell))?;
        Some(mir2_protocol::ClientMagic {
            name:template.name.clone(),spell:learned.spell,base_cost:template.base_cost,level_cost:template.level_cost,icon:template.icon,
            level1:template.level1,level2:template.level2,level3:template.level3,need1:template.need1,need2:template.need2,need3:template.need3,
            level:learned.level,key:learned.key,experience:learned.experience,
            delay:i64::from(template.delay_base.saturating_sub(template.delay_reduction.saturating_mul(u32::from(learned.level))).max(1)),range:template.range,cast_time:super::hero_ai::hero_cast::cast_offset(world,learned.spell,i64::from(template.delay_base.saturating_sub(template.delay_reduction.saturating_mul(u32::from(learned.level))).max(1))),
        })
    }).collect();
    Some(ServerPacket::HeroInformation {
        info: HeroUserInformation {
            object_id,
            name: hero.name.clone(),
            class: hero.class,
            gender: hero.gender,
            level: hero.level,
            hair: 0,
            hp,
            mp,
            experience: i64::from(hero.experience),
            max_experience: mir2_game_data::crystal_hero_settings().max_experience(hero.level),
            inventory: Some(stage5_hero_inventory_items(world)),
            equipment: Some(hero_inventory_equipment_slots(world)),
            magics,
            auto_pot: hero.auto_pot,
            auto_hp_percent: hero.auto_hp_percent,
            auto_mp_percent: hero.auto_mp_percent,
            hp_item_index: hero.hp_item_index,
            mp_item_index: hero.mp_item_index,
        },
    })
}

pub(super) fn hero_bootstrap_packets(world: &World) -> Vec<ServerPacket> {
    let Some(info)=stage5_hero_information_packet(world) else {return Vec::new();};
    let class=world.resource::<Stage5SystemsResource>().stage5_systems.hero.as_ref().unwrap().class;
    vec![ServerPacket::HeroBaseStatsInfo {stats:mir2_game_data::crystal_hero_settings().base_stats(class).clone()},info]
}

fn stage5_current_hero_info(world: &World) -> Option<ClientHeroInformation> {
    world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .hero
        .as_ref()
        .map(|hero| stage5_hero_info(0, hero))
}

fn stage5_manage_heroes_packet(world: &World) -> ServerPacket {
    let current_hero = stage5_current_hero_info(world);
    ServerPacket::ManageHeroes {
        maximum_count: 1,
        current_hero: current_hero.clone(),
        heroes: Some(vec![current_hero]),
    }
}

fn stage5_hero_ready_for_inventory(world: &World) -> bool {
    world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .hero
        .as_ref()
        .is_some_and(|hero| hero.spawned)
        && current_hero_object_id(world).is_some()
}

fn transfer_hero_item_packet(world:&mut World,from:i32,to:i32)->Vec<ServerPacket> {
    let failure=ServerPacket::TransferHeroItem {from,to,success:false};
    if !stage5_hero_ready_for_inventory(world) {return vec![failure];}
    let mut hero=world.resource::<HeroInventoryResource>().clone();
    let Ok(hero_ids)=super::hero_inventory::validate_hero_custody(&hero) else {return vec![failure];};
    let Some(from_slot)=u8::try_from(from).ok() else {return vec![failure];};
    let Some(to_slot)=u8::try_from(to).ok().filter(|slot|*slot<hero.capacity) else {return vec![failure];};
    let mut inventory=world.resource::<InventoryResource>().clone();
    if !is_valid_inventory_slot(from_slot,inventory.inventory_capacity) || hero.items.iter().any(|item|item.slot==to_slot) {return vec![failure];}
    let Some(index)=inventory.inventory_items.iter().position(|item|inventory_item_matches_index(item,from_slot)) else {return vec![failure];};
    let mut item=inventory.inventory_items[index].clone();
    if stage5_trade_reserves_item(world,&item) || item_has_crystal_or_rental_bind_flag(&item,CRYSTAL_BIND_NO_HERO) {return vec![failure];}
    if item_unique_id(&item)==0 && item.user_item_metadata.is_none() && item.socketed.is_empty() {
        // Legacy slot-zero roots have no global identity. Promote only this
        // staged root before crossing custody; an exact sidecar UID is never
        // rewritten, and failure leaves the old personal carrier untouched.
        inventory.reserved_item_unique_ids.extend(hero_ids.iter().copied());
        inventory.reserved_item_unique_ids.insert(0);
        item.unique_id=super::inventory::allocate_item_unique_id(&inventory,item.container,item.slot);
        let Ok(wire)=super::items::try_user_item_from_item_state(&item) else{return vec![failure];};
        let Ok(promoted)=super::items::try_item_state_from_user_item(item,&wire) else{return vec![failure];};
        item=promoted;inventory.inventory_items[index]=item.clone();
    }
    if !super::item_custody::can_take(&inventory,&item) || super::hero_inventory::reject_cross_custody_ids(&item,&hero_ids).is_err() {return vec![failure];}
    let weight=hero.items.iter().map(super::hero_inventory::item_weight).fold(0u32,u32::saturating_add).saturating_add(super::hero_inventory::item_weight(&item));
    if weight>super::hero_ai::hero_authoritative_stat(world,super::crystal_compat::CRYSTAL_STAT_BAG_WEIGHT).max(0) as u32 {
        return vec![system_message_key(world,"server.TooHeavyToTransfer"),failure];
    }
    inventory.inventory_items.remove(index);
    item.slot=to_slot;item.container=ItemContainer::Bag1;
    hero.items.push(item);
    let Ok(ids)=super::hero_inventory::validate_hero_custody(&hero) else {return vec![failure];};
    inventory.reserved_item_unique_ids.extend(ids);
    *world.resource_mut::<InventoryResource>()=inventory;
    *world.resource_mut::<HeroInventoryResource>()=hero;
    let mut packets=vec![ServerPacket::TransferHeroItem {from,to,success:true}];
    packets.extend(hero_bootstrap_packets(world));packets
}
fn take_back_hero_item_packet(world:&mut World,from:i32,to:i32)->Vec<ServerPacket> {
    let failure=ServerPacket::TakeBackHeroItem {from,to,success:false};
    if !stage5_hero_ready_for_inventory(world) {return vec![failure];}
    let mut hero=world.resource::<HeroInventoryResource>().clone();
    if super::hero_inventory::validate_hero_custody(&hero).is_err() {return vec![failure];}
    let Some(from_slot)=u8::try_from(from).ok().filter(|slot|*slot<hero.capacity) else {return vec![failure];};
    let Some(to_slot)=u8::try_from(to).ok() else {return vec![failure];};
    let Some(index)=hero.items.iter().position(|item|item.slot==from_slot) else {return vec![failure];};
    let item=hero.items.remove(index);
    let Ok(held)=super::item_custody::reserved_ids(&world.resource::<Stage5SystemsResource>().stage5_systems) else {return vec![failure];};
    if super::hero_inventory::reject_cross_custody_ids(&item,&held).is_err() {return vec![failure];}
    let Some((mut inventory,_))=super::item_custody::plan_return(world.resource::<InventoryResource>(),&item,Some(to_slot),false) else {return vec![failure];};
    let Ok(hero_ids)=super::hero_inventory::validate_hero_custody(&hero) else {return vec![failure];};
    inventory.reserved_item_unique_ids=held;inventory.reserved_item_unique_ids.extend(hero_ids);
    *world.resource_mut::<InventoryResource>()=inventory;
    *world.resource_mut::<HeroInventoryResource>()=hero;
    let mut packets=vec![ServerPacket::TakeBackHeroItem {from,to,success:true}];
    packets.extend(hero_bootstrap_packets(world));packets
}

fn consume_hero_inventory_item_at_index(world:&mut World,item_index:usize) {
    let removed={
        let mut hero=world.resource_mut::<HeroInventoryResource>();
        let Some(item)=hero.items.get_mut(item_index) else {return;};
        if item.quantity>1 {item.quantity-=1;None} else {Some(hero.items.remove(item_index))}
    };
    if let Some(item)=removed {
        if let Ok(carrier)=super::items::try_user_item_from_item_state(&item) {
            let mut ids=BTreeSet::new();
            if super::hero_inventory::collect_item_ids(&carrier,&mut ids).is_ok() {
                let mut inventory=world.resource_mut::<InventoryResource>();
                for id in ids {inventory.reserved_item_unique_ids.remove(&id);}
            }
        }
    }
}
fn hero_use_success(world:&World,unique_id:u64,mut packets:Vec<ServerPacket>)->Vec<ServerPacket> {
    if let Some(vitals)=hero_entity(world).and_then(|entity|entity_player_vitals(world,entity)) {
        packets.push(ServerPacket::HeroHealthChanged {hp:vitals.hp,mp:vitals.mp});
    }
    packets.extend(hero_bootstrap_packets(world));
    prepend_optional_packet(use_item_ack(Some((unique_id,MirGridType::HeroInventory)),true),packets)
}

fn hero_use_item_failed(unique_id: u64) -> Vec<ServerPacket> {
    vec![ServerPacket::UseItem {
        unique_id,
        success: false,
        grid: MirGridType::HeroInventory,
    }]
}

fn use_hero_inventory_item_packet(world: &mut World, unique_id: u64) -> Vec<ServerPacket> {
    if !stage5_hero_ready_for_inventory(world) {
        return hero_use_item_failed(unique_id);
    }
    if hero_entity(world)
        .and_then(|entity| world.entity(entity).get::<PlayerVitals>().copied())
        .is_some_and(|vitals| vitals.hp <= 0)
    {
        return hero_use_item_failed(unique_id);
    }
    let Some(hero_item_index) = world
        .resource::<HeroInventoryResource>()
        .items
        .iter()
        .position(|item| item_unique_id(item) == unique_id)
    else {
        return hero_use_item_failed(unique_id);
    };
    if super::item_custody::refresh(world).is_err() {return hero_use_item_failed(unique_id);}
    let item = world.resource::<HeroInventoryResource>().items[hero_item_index].clone();
    let ack = Some((unique_id, MirGridType::HeroInventory));
    let item_template = crystal_item_template_for_item_key(&item.key);
    let mut packets = Vec::new();

    if let Some(template) = item_template.as_ref() {
        let hero=world.resource::<Stage5SystemsResource>().stage5_systems.hero.as_ref().unwrap();
        if super::items::crystal_hero_item_requirement_rejected(world,hero.level,hero.class,hero.gender,template) || item.quantity==0 || super::items::validate_committed_item_state_carrier(&item).is_err() {
            return hero_use_item_failed(unique_id);
        }
        if template.item_type==super::crystal_compat::CRYSTAL_ITEM_TYPE_SCROLL && template.shape==15 {
            let capacity=world.resource::<HeroInventoryResource>().capacity;
            if capacity>=42 {return vec![use_item_ack(ack,false).unwrap(),system_message_key(world,"server.HeroInventoryMax")];}
            {
                let mut hero=world.resource_mut::<HeroInventoryResource>();
                super::hero_inventory::expand_capacity(&mut hero);
            }
            consume_hero_inventory_item_at_index(world,hero_item_index);
            packets.push(system_message_key(world,"server.HeroInventoryIncreased"));
            // Hero.Enqueue drops ResizeInventory and the client routes that packet
            // to the player. Refresh this Hero's exact array instead.
            return hero_use_success(world,unique_id,packets);
        }

        if template.item_type == CRYSTAL_ITEM_TYPE_POTION && current_map_disallows_drug(world) {
            packets.push(system_message_key(world, "server.YouCannotUsePotionsHere"));
            return prepend_optional_packet(use_item_ack(ack, false), packets);
        }

        if template.item_type == CRYSTAL_ITEM_TYPE_POTION
            && template.shape == CRYSTAL_POTION_SHAPE_NORMAL
        {
            let hp = crystal_item_stat_value(template, CRYSTAL_STAT_HP).max(0);
            let mp = crystal_item_stat_value(template, CRYSTAL_STAT_MP).max(0);
            if !super::buffs::queue_crystal_normal_hero_potion_restore_amounts(world, hp, mp) {
                return prepend_optional_packet(use_item_ack(ack, false), packets);
            }
            consume_hero_inventory_item_at_index(world, hero_item_index);
            return hero_use_success(world,unique_id,packets);
        }

        if template.item_type == CRYSTAL_ITEM_TYPE_POTION
            && template.shape == CRYSTAL_POTION_SHAPE_SUN_POTION
        {
            let hp = crystal_item_stat_value(template, CRYSTAL_STAT_HP).max(0);
            let mp = crystal_item_stat_value(template, CRYSTAL_STAT_MP).max(0);
            if !super::buffs::restore_current_hero_vitals(world, hp, mp) {
                return prepend_optional_packet(use_item_ack(ack, false), packets);
            }
            consume_hero_inventory_item_at_index(world, hero_item_index);
            if let Some(hero) = hero_entity(world) {
                if let Some(info) = object_health_info_for_entity(world, hero, 0) {
                    packets.push(ServerPacket::ObjectHealth { info });
                }
                if mp > 0 {
                    if let Some(info) = object_mana_info_for_entity(world, hero) {
                        packets.push(ServerPacket::ObjectMana { info });
                    }
                }
            }
            return hero_use_success(world,unique_id,packets);
        }

        if let Some(magic) = crystal_learn_hero_book_magic(world, template) {
            packets.push(ServerPacket::NewMagic { magic, hero: true });
            consume_hero_inventory_item_at_index(world, hero_item_index);
            return hero_use_success(world,unique_id,packets);
        }
    }

    if item.heal_hp > 0 || item.heal_mp > 0 {
        if current_map_disallows_drug(world) {
            packets.push(system_message_key(world, "server.YouCannotUsePotionsHere"));
            return prepend_optional_packet(use_item_ack(ack, false), packets);
        }
        if !super::buffs::queue_crystal_normal_hero_potion_restore_amounts(
            world,
            item.heal_hp.max(0),
            item.heal_mp.max(0),
        ) {
            return prepend_optional_packet(use_item_ack(ack, false), packets);
        }
        consume_hero_inventory_item_at_index(world, hero_item_index);
        return hero_use_success(world,unique_id,packets);
    }

    prepend_optional_packet(use_item_ack(ack, false), packets)
}

fn stage5_hero_auto_pot_item_unique_id(world: &World, item_index: i32) -> Option<u64> {
    if item_index <= 0 {
        return None;
    }
    world
        .resource::<HeroInventoryResource>()
        .items
        .iter()
        .find(|item| crystal_item_index_for_item_state(item) == item_index)
        .map(item_unique_id)
}

fn stage5_hero_auto_pot_needs(current: i32, max: i32, threshold_percent: u8) -> bool {
    threshold_percent > 0
        && max > 0
        && i64::from(current.max(0)) * 100 < i64::from(max) * i64::from(threshold_percent)
}

pub(super) fn tick_stage5_hero_auto_pot(
    world: &mut World,
    _tick: u64,
    packets: &mut Vec<ServerPacket>,
) {
    if !stage5_hero_ready_for_inventory(world) {
        return;
    }
    let Some(vitals) =
        hero_entity(world).and_then(|entity| world.entity(entity).get::<PlayerVitals>().copied())
    else {
        return;
    };
    if vitals.hp <= 0 {
        return;
    }
    let (auto_pot, auto_hp_percent, auto_mp_percent, hp_item_index, mp_item_index) = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        let Some(hero) = stage5.stage5_systems.hero.as_ref() else {
            return;
        };
        (
            hero.auto_pot,
            hero.auto_hp_percent,
            hero.auto_mp_percent,
            hero.hp_item_index,
            hero.mp_item_index,
        )
    };
    if !auto_pot {
        return;
    }
    let (pending_hp, pending_mp) = {
        let recovery = world.resource::<PotionRecoveryResource>();
        (
            recovery.hero_pending_pot_health_amount,
            recovery.hero_pending_pot_mana_amount,
        )
    };

    if pending_hp <= 0 && stage5_hero_auto_pot_needs(vitals.hp, vitals.max_hp, auto_hp_percent) {
        if let Some(unique_id) = stage5_hero_auto_pot_item_unique_id(world, hp_item_index) {
            packets.extend(use_hero_inventory_item_packet(world, unique_id));
        }
    }
    if pending_mp <= 0 && stage5_hero_auto_pot_needs(vitals.mp, vitals.max_mp, auto_mp_percent) {
        if let Some(unique_id) = stage5_hero_auto_pot_item_unique_id(world, mp_item_index) {
            packets.extend(use_hero_inventory_item_packet(world, unique_id));
        }
    }
}

const HERO_SPAWN_STATE_NONE: u8 = 0;
const HERO_SPAWN_STATE_UNSUMMONED: u8 = 1;
const HERO_SPAWN_STATE_SUMMONED: u8 = 2;

fn stage5_hero_spawn_state(hero: Option<&Stage5HeroState>) -> u8 {
    match hero {
        Some(hero) if hero.spawned => HERO_SPAWN_STATE_SUMMONED,
        Some(_) => HERO_SPAWN_STATE_UNSUMMONED,
        None => HERO_SPAWN_STATE_NONE,
    }
}

fn stage5_new_hero_packet(
    world: &mut World,
    name: String,
    gender: MirGender,
    class: MirClass,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .hero
        .is_some()
    {
        return vec![ServerPacket::NewHero { result: 1 }];
    }
    let hero_can_spawn = !current_map_disallows_hero(world);
    let hero = Stage5HeroState {
        name,
        level: 1,
        class,
        gender,
        behaviour: 0,
        experience: 0,
        spawned: hero_can_spawn,
        auto_pot: true,
        auto_hp_percent: 0,
        auto_mp_percent: 0,
        hp_item_index: 0,
        mp_item_index: 0,
    };
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .hero = Some(hero.clone());
    if hero_can_spawn {
        let _ = spawn_stage5_hero(world);
    }
    let info = stage5_hero_info(0, &hero);
    let mut packets = vec![
        ServerPacket::NewHero { result: 0 },
        ServerPacket::NewHeroInfo {
            info,
            storage_index: -1,
        },
        stage5_hero_information_packet(world).expect("new hero should have information"),
        stage5_manage_heroes_packet(world),
        ServerPacket::UpdateHeroSpawnState {
            state: stage5_hero_spawn_state(Some(&hero)),
        },
    ];
    if !hero_can_spawn {
        packets.push(system_message_key(world, "server.CannotSummonHeroOnMap"));
    }
    packets
}

fn learned_spell_level(world: &World, spell: Spell) -> Option<u8> {
    let skill_key = skill_key_for_crystal_spell(spell)?;
    world
        .resource::<SkillResource>()
        .skills
        .iter()
        .find(|skill| skill.key == skill_key)
        .map(|skill| skill.level)
}

fn skill_toggle_state(world: &World, spell: Spell) -> bool {
    world
        .resource::<SkillResource>()
        .spell_toggles
        .iter()
        .find(|(candidate, _)| *candidate == spell)
        .map(|(_, enabled)| *enabled)
        .unwrap_or(false)
}

fn set_skill_toggle_state(world: &mut World, spell: Spell, enabled: bool) {
    let mut skills = world.resource_mut::<SkillResource>();
    if let Some((_, existing)) = skills
        .spell_toggles
        .iter_mut()
        .find(|(candidate, _)| *candidate == spell)
    {
        *existing = enabled;
    } else {
        skills.spell_toggles.push((spell, enabled));
    }
}

fn crystal_toggle_spell_is_stateful(spell: Spell) -> bool {
    matches!(
        spell,
        Spell::Slaying
            | Spell::Thrusting
            | Spell::HalfMoon
            | Spell::CrossHalfMoon
            | Spell::DoubleSlash
            | Spell::TwinDrakeBlade
    )
}

fn stage5_spell_toggle_packet(
    world: &mut World,
    spell: Spell,
    toggle_state: i8,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if toggle_state < 0 {
        let Some(hero_object_id) = current_hero_object_id(world) else {
            return Vec::new();
        };
        return vec![ServerPacket::SpellToggle {
            object_id: hero_object_id,
            spell,
            can_use: true,
        }];
    }
    if current_player_is_dead(world) || learned_spell_level(world, spell).is_none() {
        return Vec::new();
    }
    let Some(object_id) = current_player_object_id(world) else {
        return Vec::new();
    };
    let can_use = toggle_state != 0;

    if spell == Spell::TwinDrakeBlade {
        return super::skills::prepare_twin_drake_blade(world);
    }

    if crystal_toggle_spell_is_stateful(spell) {
        set_skill_toggle_state(world, spell, can_use);
        return vec![ServerPacket::SpellToggle {
            object_id,
            spell,
            can_use,
        }];
    }

    if spell == Spell::CounterAttack {
        if !can_use
            || world
                .resource::<BuffResource>()
                .buffs
                .iter()
                .any(|buff| buff.key == "counter-attack")
        {
            return Vec::new();
        }
        let level = learned_spell_level(world, spell).unwrap_or_default();
        let Some(magic) = crystal_magic_by_spell("CounterAttack") else {
            return Vec::new();
        };
        let mana_cost = i32::from(magic.base_cost) + i32::from(magic.level_cost) * i32::from(level);
        let Some(player) = player_entity(world) else {
            return Vec::new();
        };
        let current_mp = entity_player_vitals(world, player)
            .map(|vitals| vitals.mp)
            .unwrap_or_default();
        if current_mp <= mana_cost {
            return Vec::new();
        }
        {
            let mut entity = world.entity_mut(player);
            let mut vitals = entity.get_mut::<PlayerVitals>().expect("player vitals");
            vitals.mp = (vitals.mp - mana_cost).max(0);
        }
        let stat_value = 11 + i32::from(level) * 3;
        let buff = super::buffs::BuffState {
            real_time_duration: None,
            key: "counter-attack".to_string(),
            name: "Counter Attack".to_string(),
            description: "Crystal counter-attack stance is active.".to_string(),
            expires_at_tick: super::session::runtime_tick(world).saturating_add(7),
            attack_bonus: 0,
            defence_bonus: stat_value,
            stats: vec![
                UserItemStat {
                    stat: super::crystal_compat::CRYSTAL_STAT_MIN_AC,
                    value: stat_value,
                },
                UserItemStat {
                    stat: super::crystal_compat::CRYSTAL_STAT_MAX_AC,
                    value: stat_value,
                },
                UserItemStat {
                    stat: super::crystal_compat::CRYSTAL_STAT_MIN_MAC,
                    value: stat_value,
                },
                UserItemStat {
                    stat: super::crystal_compat::CRYSTAL_STAT_MAX_MAC,
                    value: stat_value,
                },
            ],
        };
        super::buffs::apply_or_refresh_buff(world, buff.clone());
        set_skill_toggle_state(world, spell, true);
        let mut packets = Vec::new();
        if let Some(packet) = super::buffs::client_buff_packet_for_state(world, &buff) {
            packets.push(packet);
        }
        if let Some(info) = object_mana_info_for_entity(world, player) {
            packets.push(ServerPacket::ObjectMana { info });
        }
        return packets;
    }

    if spell == Spell::MentalState {
        if !can_use {
            return Vec::new();
        }
        let next_state = {
            let mut skills = world.resource_mut::<SkillResource>();
            skills.mental_state = (skills.mental_state + 1) % 3;
            skills.mental_state
        };
        let buff = super::buffs::BuffState {
            real_time_duration: None,
            key: "mental-state".to_string(),
            name: "Mental State".to_string(),
            description: "Crystal mental state is active.".to_string(),
            expires_at_tick: u64::MAX,
            attack_bonus: 0,
            defence_bonus: 0,
            stats: Vec::new(),
        };
        super::buffs::apply_or_refresh_buff(world, buff);
        return vec![ServerPacket::AddBuff {
            buff: ClientBuff {
                buff_type: super::buffs::crystal_buff_type_for_key("mental-state").unwrap_or(19),
                visible: false,
                object_id,
                expire_time: 0,
                infinite: true,
                paused: false,
                stats: Vec::new(),
                values: vec![i32::from(next_state)],
            },
        }];
    }

    if spell == Spell::FlamingSword {
        if skill_toggle_state(world, spell) || !can_use {
            return Vec::new();
        }
        let level = learned_spell_level(world, spell).unwrap_or_default();
        let Some(magic) = crystal_magic_by_spell("FlamingSword") else {
            return Vec::new();
        };
        let mana_cost = i32::from(magic.base_cost) + i32::from(magic.level_cost) * i32::from(level);
        let Some(player) = player_entity(world) else {
            return Vec::new();
        };
        let current_mp = entity_player_vitals(world, player)
            .map(|vitals| vitals.mp)
            .unwrap_or_default();
        if current_mp <= mana_cost {
            return Vec::new();
        }
        {
            let mut entity = world.entity_mut(player);
            let mut vitals = entity.get_mut::<PlayerVitals>().expect("player vitals");
            vitals.mp = (vitals.mp - mana_cost).max(0);
        }
        set_skill_toggle_state(world, spell, true);
        let mut packets = vec![ServerPacket::SpellToggle {
            object_id,
            spell,
            can_use: true,
        }];
        if let Some(info) = object_mana_info_for_entity(world, player) {
            packets.push(ServerPacket::ObjectMana { info });
        }
        return packets;
    }

    Vec::new()
}

const STAGE5_TRADE_SLOT_COUNT: usize = 10;

fn stage5_trade_items(world: &World) -> Vec<Option<UserItem>> {
    let stage5 = world.resource::<Stage5SystemsResource>();
    let Some(trade) = stage5.stage5_systems.trade.as_ref() else {
        return vec![None; STAGE5_TRADE_SLOT_COUNT];
    };
    let inventory = world.resource::<InventoryResource>();
    let mut trade_items = vec![None; STAGE5_TRADE_SLOT_COUNT];
    for (trade_slot, inventory_index) in &trade.offered_slots {
        let Some(slot) = trade_items.get_mut(usize::from(*trade_slot)) else {
            continue;
        };
        *slot = inventory
            .inventory_items
            .iter()
            .find(|item| inventory_item_matches_index(item, *inventory_index))
            .map(user_item_from_item_state);
    }
    trade_items
}

fn stage5_trade_item_keys_for_slots(world: &World, slots: &BTreeMap<u8, u8>) -> Vec<String> {
    let inventory = world.resource::<InventoryResource>();
    let mut offered_items = Vec::new();
    for inventory_index in slots.values() {
        if let Some(item) = inventory
            .inventory_items
            .iter()
            .find(|item| inventory_item_matches_index(item, *inventory_index))
        {
            push_unique(&mut offered_items, item.key.clone());
        }
    }
    offered_items
}

fn current_group_map_name(world: &World) -> String {
    world
        .resource::<MapRuntimeResource>()
        .current_map
        .title
        .clone()
}

fn ensure_stage5_group_self_member(world: &mut World) -> String {
    let player_name = stage5_player_name(world);
    let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
    push_unique(
        &mut stage5.stage5_systems.group.members,
        player_name.clone(),
    );
    player_name
}

/// Looks up a party member's live attributes (level / class / HP / online) from
/// the world's player objects by name. Crystal reads these from the
/// `ObjectPlayer` it already sent the client; we resolve them server-side
/// because the web gateway serialises each packet without world context.
///
/// `online` mirrors Crystal's `CharacterInfo.CreateClientFriend` semantics
/// (`Crystal/Server/MirDatabase/CharacterInfo.cs:767`): a member is online iff a
/// live player object with that name exists in the world. HP is only known for
/// objects the simulation tracks vitals for (self / hero); a remote player's HP
/// is left `None` (Crystal likewise only ships exact HP for visible objects).
#[allow(deprecated)]
fn stage5_group_member_attributes(world: &World, name: &str) -> GroupMember {
    let language = world.resource::<SessionResource>().language;
    for entity in world.iter_entities() {
        // Only player-type objects are valid group members (self, hero, remote).
        let is_player = entity.contains::<SelfPlayer>()
            || entity.contains::<Hero>()
            || entity.contains::<RemotePlayer>();
        if !is_player {
            continue;
        }
        let Some(display) = entity.get::<DisplayName>() else {
            continue;
        };
        if !display.resolve(language).eq_ignore_ascii_case(name) {
            continue;
        }
        let body = entity.get::<CharacterBody>();
        let vitals = entity.get::<PlayerVitals>();
        return GroupMember {
            name: name.to_string(),
            level: body.map(|body| body.level),
            class: body.map(|body| body.class as u8),
            hp: vitals.map(|vitals| vitals.hp),
            max_hp: vitals.map(|vitals| vitals.max_hp),
            online: Some(true),
        };
    }
    // No live object for this name: list it (Crystal keeps offline members in the
    // roster) but mark it offline with no live stats.
    GroupMember {
        name: name.to_string(),
        level: None,
        class: None,
        hp: None,
        max_hp: None,
        online: Some(false),
    }
}

/// Builds the enriched roster from the authoritative `group.members` name list.
fn stage5_group_members_enriched(world: &World) -> Vec<GroupMember> {
    world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .group
        .members
        .clone()
        .iter()
        .map(|name| stage5_group_member_attributes(world, name))
        .collect()
}

/// Emits the custom `GroupMemberInfo` roster packet, or `None` when the player
/// is not currently grouped (so we never push an empty roster).
fn stage5_group_member_info_packet(world: &World) -> Option<ServerPacket> {
    let members = stage5_group_members_enriched(world);
    if members.is_empty() {
        return None;
    }
    // Crystal's group leader is `GroupMembers[0]` (the creator); the stage5 model
    // seeds the self/creator first via `ensure_stage5_group_self_member`.
    let leader_name = members
        .first()
        .map(|member| member.name.clone())
        .unwrap_or_default();
    Some(ServerPacket::GroupMemberInfo {
        members,
        leader_name,
    })
}

fn stage5_group_switch_packet(world: &mut World, allow_group: bool) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let had_group = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let had_group = !stage5.stage5_systems.group.members.is_empty();
        stage5.stage5_systems.group.allow_group = allow_group;
        if !allow_group {
            stage5.stage5_systems.group.members.clear();
        }
        had_group
    };
    let mut packets = vec![ServerPacket::SwitchGroup { allow_group }];
    if !allow_group && had_group {
        packets.push(ServerPacket::DeleteGroup);
    }
    packets
}

fn stage5_group_add_member_packet(world: &mut World, name: String) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let target_name = name.trim().to_string();
    if target_name.is_empty() {
        return Vec::new();
    }
    let allow_group = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .group
        .allow_group;
    if !allow_group {
        return vec![ServerPacket::SwitchGroup { allow_group: false }];
    }
    let player_name = ensure_stage5_group_self_member(world);
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        push_unique(
            &mut stage5.stage5_systems.group.members,
            target_name.clone(),
        );
    }
    let member_map = current_group_map_name(world);
    let member_location = current_location(world).position;
    let mut packets = vec![
        ServerPacket::SwitchGroup { allow_group: true },
        ServerPacket::AddMember { name: player_name },
        ServerPacket::AddMember {
            name: target_name.clone(),
        },
        ServerPacket::GroupMembersMap {
            player_name: target_name.clone(),
            player_map: member_map,
        },
        ServerPacket::SendMemberLocation {
            member_name: target_name,
            member_location,
        },
    ];
    // Custom roster snapshot (beyond Crystal) carrying enriched member detail for
    // the web group window. Follows the incremental AddMember packets above.
    packets.extend(stage5_group_member_info_packet(world));
    packets
}

fn stage5_group_del_member_packet(world: &mut World, name: String) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let target_name = name.trim().to_string();
    if target_name.is_empty() {
        return Vec::new();
    }
    let (changed, dissolved) = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let members = &mut stage5.stage5_systems.group.members;
        let before = members.len();
        members.retain(|member| !member.eq_ignore_ascii_case(&target_name));
        if members.len() == before {
            (false, false)
        } else if members.len() <= 1 {
            members.clear();
            (true, true)
        } else {
            (true, false)
        }
    };
    if !changed {
        return Vec::new();
    }
    if dissolved {
        return vec![ServerPacket::DeleteGroup];
    }
    let mut packets = vec![ServerPacket::DeleteMember { name: target_name }];
    // Refresh the enriched roster for the web group window after the removal.
    packets.extend(stage5_group_member_info_packet(world));
    packets
}

fn stage5_group_invite_reply_packet(world: &mut World, accept_invite: bool) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if !accept_invite {
        return vec![ServerPacket::DeleteGroup];
    }
    let player_name = ensure_stage5_group_self_member(world);
    let mut packets = vec![
        ServerPacket::SwitchGroup { allow_group: true },
        ServerPacket::AddMember { name: player_name },
    ];
    packets.extend(stage5_group_member_info_packet(world));
    packets
}

fn stage5_guild_not_in_guild_chat(world: &World) -> ServerPacket {
    system_message(&localized_text_or_fallback(
        super::session::current_language(world),
        "server.NotPartOfGuild",
        "server.NotPartOfGuild",
    ))
}

const GUILD_STORAGE_SLOT_COUNT: usize = 112;
const GUILD_OPTION_CAN_CHANGE_RANK: u8 = 1;
const GUILD_OPTION_CAN_RECRUIT: u8 = 2;
const GUILD_OPTION_CAN_KICK: u8 = 4;
const GUILD_OPTION_CAN_STORE_ITEM: u8 = 8;
const GUILD_OPTION_CAN_RETRIEVE_ITEM: u8 = 16;
const GUILD_OPTION_CAN_ALTER_ALLIANCE: u8 = 32;
const GUILD_OPTION_CAN_CHANGE_NOTICE: u8 = 64;
const GUILD_OPTION_CAN_ACTIVATE_BUFF: u8 = 128;
const GUILD_OPTION_ALL: u8 = u8::MAX;
const STAGE5_GUILD_WAR_COST: u32 = 3_000;
const STAGE5_GUILD_WAR_TICK_INTERVAL: u64 = 60;
const STAGE5_GUILD_WAR_DURATION_TICKS: u64 = 180 * STAGE5_GUILD_WAR_TICK_INTERVAL;
const STAGE5_GUILD_WAR_SELF_COLOUR_ARGB: i32 = 0xFF00_00FFu32 as i32;
const STAGE5_GUILD_NORMAL_COLOUR_ARGB: i32 = -1;
const PLAYER_BROWN_NAME_COLOUR_ARGB: i32 = 0xFFFF_8000u32 as i32;
const PLAYER_RED_NAME_COLOUR_ARGB: i32 = 0xFFFF_0000u32 as i32;
const STAGE5_GUILD_TERRITORY_PAGE_SIZE: usize = 7;

fn stage5_guild_rank_is_leader(rank: &str) -> bool {
    let rank = rank.trim();
    rank.is_empty()
        || rank.eq_ignore_ascii_case("Guild Chief")
        || rank.eq_ignore_ascii_case("Leader")
}

fn stage5_current_guild_name(world: &World) -> String {
    world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .name
        .trim()
        .to_string()
}

fn stage5_guild_permission_key(permission: &str) -> String {
    permission
        .chars()
        .filter(|ch| ch.is_ascii_alphanumeric())
        .flat_map(char::to_lowercase)
        .collect()
}

fn stage5_guild_permissions_contain(permissions: &[String], candidates: &[&str]) -> bool {
    permissions.iter().any(|permission| {
        let permission = stage5_guild_permission_key(permission);
        candidates.iter().any(|candidate| permission == *candidate)
    })
}

fn stage5_guild_options_from_rank_and_permissions(rank: &str, permissions: &[String]) -> u8 {
    if stage5_guild_rank_is_leader(rank) {
        return GUILD_OPTION_ALL;
    }

    let mut options = 0;
    if stage5_guild_permissions_contain(permissions, &["changerank", "rank"]) {
        options |= GUILD_OPTION_CAN_CHANGE_RANK;
    }
    if stage5_guild_permissions_contain(permissions, &["recruit", "invite"]) {
        options |= GUILD_OPTION_CAN_RECRUIT;
    }
    if stage5_guild_permissions_contain(permissions, &["kick"]) {
        options |= GUILD_OPTION_CAN_KICK;
    }
    if stage5_guild_permissions_contain(permissions, &["storeitem", "store", "storage"]) {
        options |= GUILD_OPTION_CAN_STORE_ITEM;
    }
    if stage5_guild_permissions_contain(permissions, &["retrieveitem", "retrieve", "storage"]) {
        options |= GUILD_OPTION_CAN_RETRIEVE_ITEM;
    }
    if stage5_guild_permissions_contain(permissions, &["alteralliance", "alliance", "conquest"]) {
        options |= GUILD_OPTION_CAN_ALTER_ALLIANCE;
    }
    if stage5_guild_permissions_contain(permissions, &["changenotice", "notice"]) {
        options |= GUILD_OPTION_CAN_CHANGE_NOTICE;
    }
    if stage5_guild_permissions_contain(permissions, &["activatebuff", "buff"]) {
        options |= GUILD_OPTION_CAN_ACTIVATE_BUFF;
    }
    options
}

fn stage5_current_guild_rank_name(world: &World) -> String {
    let rank = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .rank
        .trim()
        .to_string();
    if rank.is_empty() {
        "Guild Chief".to_string()
    } else {
        rank
    }
}

fn stage5_current_guild_rank_index(world: &World) -> i32 {
    if stage5_guild_rank_is_leader(&stage5_current_guild_rank_name(world)) {
        0
    } else {
        1
    }
}

fn stage5_current_guild_options(world: &World) -> u8 {
    let stage5 = world.resource::<Stage5SystemsResource>();
    let guild = &stage5.stage5_systems.guild;
    stage5_guild_options_from_rank_and_permissions(&guild.rank, &guild.permissions)
}

fn stage5_current_guild_has_option(world: &World, option: u8) -> bool {
    stage5_current_guild_options(world) & option != 0
}

fn stage5_guild_canonical_known_name(world: &World, name: &str) -> Option<String> {
    let target = name.trim();
    if target.is_empty() {
        return None;
    }
    let stage5 = world.resource::<Stage5SystemsResource>();
    let guild = &stage5.stage5_systems.guild;
    if guild.name.eq_ignore_ascii_case(target) {
        return Some(guild.name.clone());
    }
    if target.eq_ignore_ascii_case("NewbieGuild") {
        return Some("NewbieGuild".to_string());
    }
    guild
        .known_guilds
        .iter()
        .find(|known| known.eq_ignore_ascii_case(target))
        .cloned()
        .or_else(|| {
            let owner = stage5.stage5_systems.guild_territory.owner.trim();
            if owner.eq_ignore_ascii_case(target) {
                Some(stage5.stage5_systems.guild_territory.owner.clone())
            } else {
                None
            }
        })
}

fn stage5_guild_has_active_war(world: &World, name: &str) -> bool {
    world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .active_wars
        .iter()
        .any(|war| war.eq_ignore_ascii_case(name))
}

pub(super) fn stage5_guild_is_at_war_with(world: &World, name: &str) -> bool {
    let name = name.trim();
    if name.is_empty() {
        return false;
    }
    stage5_guild_has_active_war(world, name)
}

fn stage5_current_guild_is_at_war(world: &World) -> bool {
    !world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .active_wars
        .is_empty()
}

pub(super) fn current_player_name_colour_argb(world: &World) -> i32 {
    let pk_points = world.resource::<PlayerRuntimeResource>().pk_points;
    if pk_points >= CRYSTAL_RED_NAME_PK_POINTS {
        PLAYER_RED_NAME_COLOUR_ARGB
    } else if pk_points >= 100 {
        PLAYER_BROWN_NAME_COLOUR_ARGB
    } else if stage5_current_guild_is_at_war(world) {
        STAGE5_GUILD_WAR_SELF_COLOUR_ARGB
    } else {
        STAGE5_GUILD_NORMAL_COLOUR_ARGB
    }
}

fn stage5_guild_end_war_packet(
    world: &mut World,
    enemy_name: String,
    packets: &mut Vec<ServerPacket>,
) {
    let guild_name = stage5_current_guild_name(world);
    let language = super::session::current_language(world);
    let current_message =
        format_localized_text(language, "server.WarEndedWithGuild", [enemy_name.clone()]);
    let enemy_message = format_localized_text(language, "server.WarEndedWithGuild", [guild_name]);
    let ended = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let guild = &mut stage5.stage5_systems.guild;
        let before = guild.active_wars.len();
        guild
            .active_wars
            .retain(|war| !war.eq_ignore_ascii_case(&enemy_name));
        guild
            .active_war_ticks_remaining
            .retain(|war, _| !war.eq_ignore_ascii_case(&enemy_name));
        let ended = guild.active_wars.len() != before;
        if ended {
            guild.war_broadcasts.push(current_message.clone());
            guild.war_broadcasts.push(enemy_message);
        }
        ended
    };
    if !ended {
        return;
    }
    packets.push(ServerPacket::Chat {
        message: current_message,
        chat_type: ChatType::Guild,
    });
    packets.push(ServerPacket::ColourChanged {
        name_colour_argb: current_player_name_colour_argb(world),
    });
}

fn tick_stage5_guild_wars(world: &mut World, tick: u64, packets: &mut Vec<ServerPacket>) {
    if super::shared_guilds::enabled(world) { return; }
    if tick == 0 || tick % STAGE5_GUILD_WAR_TICK_INTERVAL != 0 {
        return;
    }
    let expired_wars = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let guild = &mut stage5.stage5_systems.guild;
        let mut expired = Vec::new();
        for enemy_name in guild.active_wars.clone() {
            let remaining = guild
                .active_war_ticks_remaining
                .entry(enemy_name.clone())
                .or_insert(STAGE5_GUILD_WAR_DURATION_TICKS);
            *remaining = remaining.saturating_sub(STAGE5_GUILD_WAR_TICK_INTERVAL);
            if *remaining == 0 {
                expired.push(enemy_name);
            }
        }
        expired
    };
    for enemy_name in expired_wars {
        stage5_guild_end_war_packet(world, enemy_name, packets);
    }
}

pub(super) fn stage5_guild_request_war_packet(world: &World) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if stage5_current_guild_name(world).is_empty() {
        return vec![system_message_key(world, "server.NotInGuild")];
    }
    if stage5_current_guild_rank_index(world) != 0 {
        return vec![system_message_key(
            world,
            "server.YouMustBeLeaderToRequestWar",
        )];
    }
    vec![ServerPacket::GuildRequestWar]
}

fn stage5_guild_war_return_packet(world: &mut World, name: String) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }

    let target_name = name.trim().to_string();
    let guild_name = stage5_current_guild_name(world);
    if guild_name.is_empty() || stage5_current_guild_rank_index(world) != 0 {
        return Vec::new();
    }

    let Some(enemy_name) = stage5_guild_canonical_known_name(world, &target_name) else {
        return vec![system_message_key_args(
            world,
            "server.GuildNotFound",
            [target_name],
        )];
    };
    if guild_name.eq_ignore_ascii_case(&enemy_name) {
        return vec![system_message_key(world, "server.CannotWarOwnGuild")];
    }
    if enemy_name.eq_ignore_ascii_case("NewbieGuild") {
        return vec![system_message_key(world, "server.CannotWarNewPlayersGuild")];
    }
    if stage5_guild_is_at_war_with(world, &enemy_name) {
        return vec![system_message_key(world, "server.AlreadyAtWarWithGuild")];
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .storage_gold
        < STAGE5_GUILD_WAR_COST
    {
        return vec![system_message_key(
            world,
            "server.GuildBankFundsInsufficient",
        )];
    }

    let player_name = current_stage5_character_name(world);
    let language = super::session::current_language(world);
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let guild = &mut stage5.stage5_systems.guild;
        guild.storage_gold = guild.storage_gold.saturating_sub(STAGE5_GUILD_WAR_COST);
        push_unique(&mut guild.active_wars, enemy_name.clone());
        guild
            .active_war_ticks_remaining
            .insert(enemy_name.clone(), STAGE5_GUILD_WAR_DURATION_TICKS);
        guild.war_broadcasts.push(format_localized_text(
            language,
            "server.HasStartedWar",
            [guild_name.clone()],
        ));
    }

    vec![
        system_message_key_args(world, "server.YouStartedWarWith", [enemy_name]),
        ServerPacket::GuildStorageGoldChange {
            amount: STAGE5_GUILD_WAR_COST,
            change_type: 2,
            name: player_name,
        },
        ServerPacket::ColourChanged {
            name_colour_argb: current_player_name_colour_argb(world),
        },
    ]
}

fn stage5_guild_territory_listing(world: &World) -> Option<ClientGtMap> {
    let stage5 = world.resource::<Stage5SystemsResource>();
    let territory = &stage5.stage5_systems.guild_territory;
    if territory.map_file_name.trim().is_empty() {
        return None;
    }
    Some(ClientGtMap {
        index: 0,
        name: territory.map_file_name.clone(),
        owner: territory.owner.clone(),
        leader: territory.leader.clone(),
        leader2: territory.leader2.clone(),
        price: territory.price,
        days: i32::try_from(territory.rental_days_left).unwrap_or(i32::MAX),
        begin: territory.begin,
    })
}

fn stage5_guild_territory_page_packet(world: &World, page: i32) -> Vec<ServerPacket> {
    if !is_in_world(world) || page < 0 {
        return Vec::new();
    }
    let listings = stage5_guild_territory_listing(world)
        .into_iter()
        .collect::<Vec<_>>();
    let start = usize::try_from(page)
        .unwrap_or_default()
        .saturating_mul(STAGE5_GUILD_TERRITORY_PAGE_SIZE);
    let page_listings = listings
        .iter()
        .skip(start)
        .take(STAGE5_GUILD_TERRITORY_PAGE_SIZE)
        .cloned()
        .collect::<Vec<_>>();
    vec![ServerPacket::GuildTerritoryPage {
        length: i32::try_from(listings.len()).unwrap_or(i32::MAX),
        listings: page_listings,
    }]
}

fn stage5_purchase_guild_territory_packet(world: &mut World, owner: String) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let requested_owner = owner.trim().to_string();
    let Some(listing) = stage5_guild_territory_listing(world).filter(|listing| {
        !listing.owner.trim().is_empty() && listing.owner.eq_ignore_ascii_case(&requested_owner)
    }) else {
        return vec![system_message_key(world, "server.OwnerGuildNotFound")];
    };
    if listing.price == 0 {
        return vec![system_message_key(world, "server.TerritoryNoLongerForSale")];
    }

    let guild_name = stage5_current_guild_name(world);
    if guild_name.is_empty() || stage5_current_guild_rank_index(world) != 0 {
        return vec![system_message_key(
            world,
            "server.GuildLeaderToPurchaseTerritory",
        )];
    }
    if listing.owner.eq_ignore_ascii_case(&guild_name) {
        return vec![system_message_key(world, "server.AlreadyOwnTerritory")];
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild_territory
        .owned
    {
        return vec![system_message_key(world, "server.AlreadyOwnATerritory")];
    }
    let Ok(price) = u32::try_from(listing.price) else {
        return vec![system_message_key(world, "server.TerritoryNoLongerForSale")];
    };
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .storage_gold
        < price
    {
        return vec![system_message_key(world, "server.InsufficientFunds")];
    }

    let player_name = current_stage5_character_name(world);
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        stage5.stage5_systems.guild.storage_gold -= price;
        let territory = &mut stage5.stage5_systems.guild_territory;
        territory.owned = true;
        territory.owner = guild_name;
        territory.leader = player_name;
        territory.price = 0;
    }

    vec![
        ServerPacket::GuildStorageGoldChange {
            amount: price,
            change_type: 2,
            name: String::new(),
        },
        system_message_key(world, "server.GuildTerritoryPurchaseProcess24Hrs"),
    ]
}

fn stage5_guild_player_in_safe_zone(world: &World) -> bool {
    let Some(player) = player_entity(world) else {
        return false;
    };
    let Some(position) = entity_position(world, player) else {
        return false;
    };
    let config = &world.resource::<RuntimeConfigResource>().config;
    let map = world.resource::<MapRuntimeResource>();
    is_safe_zone_point(config, map, &position)
}

fn stage5_guild_storage_failure(change_type: u8, from: i32, to: i32) -> ServerPacket {
    ServerPacket::GuildStorageItemChange {
        change_type: 3u8.saturating_add(change_type),
        to,
        from,
        user: 0,
        item: None,
    }
}

fn stage5_guild_user_item_for_key(key: &str, unique_id: u64) -> UserItem {
    let item_index = crystal_item_template_for_item_key(key)
        .map(|template| template.item_index)
        .unwrap_or_else(|| i32::from(item_icon_for_key(key)));

    UserItem {
        unique_id,
        item_index,
        current_dura: 0,
        max_dura: 0,
        count: 1,
        soul_bound_id: -1,
        identified: true,
        cursed: false,
        slots: Vec::new(),
        gem_count: 0,
        added_stats: Vec::new(),
        awake_type: 0,
        awake_values: Vec::new(),
        refined_value: 0,
        refine_added: 0,
        refine_success_chance: 0,
        wedding_ring: -1,
        expire_info: None,
        rental_information: None,
        is_shop_item: false,
        sealed_info: None,
        gm_made: false,
    }
}

#[derive(Debug, Clone)]
struct ValidatedStage5GuildStorageItem {
    state: ItemState,
    packet: GuildStorageItem,
}

fn validate_stage5_guild_storage_packet_snapshot(
    systems: &Stage5SystemsState,
) -> Result<BTreeMap<u8, ValidatedStage5GuildStorageItem>, String> {
    validate_stage5_guild_storage_item_carriers(&systems.guild)?;
    let guild = &systems.guild;
    if guild.storage_items.len() != guild.storage_item_users.len() {
        return Err(format!(
            "stage5 guild storage key/owner length mismatch: {} keys, {} owners",
            guild.storage_items.len(),
            guild.storage_item_users.len()
        ));
    }

    let mut validated = BTreeMap::new();
    for (slot, key) in &guild.storage_items {
        let encoded = guild.storage_item_states.get(slot).ok_or_else(|| {
            format!("stage5 guild storage slot {slot} is missing exact item state")
        })?;
        let owner = guild.storage_item_users.get(slot).copied().ok_or_else(|| {
            format!("stage5 guild storage slot {slot} is missing exact item owner")
        })?;
        let state = serde_json::from_str::<ItemState>(encoded).map_err(|error| {
            format!("failed to decode stage5 guild storage slot {slot}: {error}")
        })?;
        if state.key != *key {
            return Err(format!(
                "stage5 guild storage slot {slot} key/state mismatch: {key} != {}",
                state.key
            ));
        }
        validate_committed_item_state_carrier(&state).map_err(|error| {
            format!("invalid stage5 guild storage slot {slot} carrier: {error}")
        })?;
        let item = try_user_item_from_item_state(&state).map_err(|error| {
            format!("failed to convert stage5 guild storage slot {slot}: {error}")
        })?;
        validated.insert(
            *slot,
            ValidatedStage5GuildStorageItem {
                state,
                packet: GuildStorageItem {
                    item,
                    user_id: i64::from(owner),
                },
            },
        );
    }

    if validated.len() != guild.storage_item_states.len()
        || validated.len() != guild.storage_item_users.len()
    {
        return Err("stage5 guild storage maps do not have exact slot correspondence".to_string());
    }
    Ok(validated)
}
fn stage5_swap_guild_storage_map<T>(map: &mut BTreeMap<u8, T>, from: u8, to: u8) {
    if from == to {
        return;
    }
    let from_value = map.remove(&from);
    let to_value = map.remove(&to);
    if let Some(value) = from_value {
        map.insert(to, value);
    }
    if let Some(value) = to_value {
        map.insert(from, value);
    }
}

fn stage5_guild_rank_snapshot(world: &World) -> Vec<GuildRank> {
    let stage5 = world.resource::<Stage5SystemsResource>();
    let guild = &stage5.stage5_systems.guild;
    if guild.name.is_empty() {
        return Vec::new();
    }
    let rank_name = stage5_current_guild_rank_name(world);
    let current_name = current_stage5_character_name(world);
    let current_index = current_stage5_character_index(world);
    let mut members: Vec<GuildMember> = guild
        .members
        .iter()
        .enumerate()
        .map(|(index, name)| GuildMember {
            name: name.clone(),
            id: if name.eq_ignore_ascii_case(&current_name) {
                current_index
            } else {
                i32::try_from(index).unwrap_or_default()
            },
            last_login_binary_datetime: 0,
            has_voted: false,
            online: name.eq_ignore_ascii_case(&current_name),
        })
        .collect();
    if members.is_empty() {
        members.push(GuildMember {
            name: current_name,
            id: current_index,
            last_login_binary_datetime: 0,
            has_voted: false,
            online: true,
        });
    }
    vec![GuildRank {
        name: rank_name,
        options: stage5_current_guild_options(world),
        index: stage5_current_guild_rank_index(world),
        members,
    }]
}

fn stage5_guild_alliance_info_packets(world: &World) -> Vec<ServerPacket> {
    let (ally_count, allied_guilds, recent_broadcasts) = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        let guild = &stage5.stage5_systems.guild;
        if guild.name.trim().is_empty() {
            return Vec::new();
        }
        let allied_guilds = guild
            .allied_guilds
            .iter()
            .filter(|name| !name.trim().is_empty())
            .cloned()
            .collect::<Vec<_>>();
        let ally_count = u32::try_from(allied_guilds.len()).unwrap_or(u32::MAX);
        let recent_broadcasts = guild
            .alliance_broadcasts
            .iter()
            .rev()
            .filter(|message| !message.trim().is_empty())
            .take(3)
            .cloned()
            .collect::<Vec<_>>();
        (ally_count, allied_guilds, recent_broadcasts)
    };

    if ally_count == 0 && recent_broadcasts.is_empty() {
        return Vec::new();
    }

    let mut packets = vec![
        ServerPacket::Chat {
            message: format!("AllyCount: {ally_count}"),
            chat_type: ChatType::Guild,
        },
        ServerPacket::Chat {
            message: if allied_guilds.is_empty() {
                "AllyGuilds: None".to_string()
            } else {
                format!("AllyGuilds: {}", allied_guilds.join(", "))
            },
            chat_type: ChatType::Guild,
        },
    ];
    packets.extend(
        recent_broadcasts
            .into_iter()
            .rev()
            .map(|message| ServerPacket::Chat {
                message: format!("AllianceBroadcast: {message}"),
                chat_type: ChatType::Guild,
            }),
    );
    packets
}

fn stage5_request_guild_info_packet(world: &mut World, info_type: u8) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let guild_exists = !world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .name
        .is_empty();
    if !guild_exists {
        return Vec::new();
    }
    match info_type {
        0 => {
            let notice = world
                .resource::<Stage5SystemsResource>()
                .stage5_systems
                .guild
                .notice
                .clone();
            let mut packets = vec![ServerPacket::GuildNoticeChange {
                update: i32::try_from(notice.len()).unwrap_or(i32::MAX),
                notice,
            }];
            packets.extend(stage5_guild_alliance_info_packets(world));
            packets
        }
        1 => {
            let mut packets = vec![ServerPacket::GuildMemberChange {
                name: String::new(),
                rank_index: 0,
                status: u8::MAX,
                ranks: stage5_guild_rank_snapshot(world),
            }];
            packets.extend(stage5_guild_alliance_info_packets(world));
            packets
        }
        _ => Vec::new(),
    }
}

fn stage5_edit_guild_notice_packet(world: &mut World, notice: Vec<String>) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .name
        .is_empty()
    {
        return vec![stage5_guild_not_in_guild_chat(world)];
    }
    if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_CHANGE_NOTICE) {
        return vec![system_message_key(
            world,
            "server.GuildNoticeChangeNotAllowed",
        )];
    }
    if notice.len() > 200 {
        return vec![system_message_key(world, "server.GuildNoticeMaxLines")];
    }
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .notice = notice;
    vec![ServerPacket::GuildNoticeChange {
        update: -1,
        notice: Vec::new(),
    }]
}

fn stage5_edit_guild_member_packet(
    world: &mut World,
    change_type: u8,
    rank_index: u8,
    name: String,
    rank_name: String,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let name = name.trim().to_string();
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .name
        .is_empty()
    {
        return vec![stage5_guild_not_in_guild_chat(world)];
    }
    match change_type {
        0 if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_RECRUIT) => {
            return vec![system_message_key(world, "server.NotAllowedRecruitMembers")];
        }
        1 if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_KICK) => {
            return vec![system_message_key(world, "server.CannotRemoveMembers")];
        }
        2 if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_CHANGE_RANK) => {
            return vec![system_message_key(
                world,
                "server.NotAllowedChangeOtherRank",
            )];
        }
        3..=5 if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_CHANGE_RANK) => {
            return vec![system_message_key(world, "server.NotAllowedChangeRank")];
        }
        _ => {}
    }
    let mut emit_member_change = false;
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let guild = &mut stage5.stage5_systems.guild;
        match change_type {
            0 => {
                if !name.is_empty() {
                    push_unique(&mut guild.members, name.clone());
                    emit_member_change = true;
                }
            }
            1 => {
                let before = guild.members.len();
                guild
                    .members
                    .retain(|member| !member.eq_ignore_ascii_case(&name));
                emit_member_change = guild.members.len() != before;
            }
            2 | 3 => {
                if !rank_name.trim().is_empty() {
                    guild.rank = rank_name.trim().to_string();
                    emit_member_change = true;
                }
            }
            4 => {
                emit_member_change = true;
            }
            5 => {
                if let Ok(option) = rank_name.parse::<u8>() {
                    if option <= 7 {
                        let permission = match option {
                            0 => "changeRank",
                            1 => "recruit",
                            2 => "kick",
                            3 => "storeItem",
                            4 => "retrieveItem",
                            5 => "alterAlliance",
                            6 => "changeNotice",
                            7 => "activateBuff",
                            _ => unreachable!("option is already bounded"),
                        }
                        .to_string();
                        if name.eq_ignore_ascii_case("true") {
                            push_unique(&mut guild.permissions, permission);
                        } else if name.eq_ignore_ascii_case("false") {
                            guild.permissions.retain(|existing| {
                                stage5_guild_permission_key(existing)
                                    != stage5_guild_permission_key(&permission)
                            });
                        }
                        emit_member_change = true;
                    }
                }
            }
            _ => {}
        }
    }
    if emit_member_change {
        vec![ServerPacket::GuildMemberChange {
            name,
            rank_index,
            status: change_type,
            ranks: stage5_guild_rank_snapshot(world),
        }]
    } else {
        Vec::new()
    }
}

fn stage5_guild_invite_reply_packet(world: &mut World, accept_invite: bool) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if !accept_invite {
        return Vec::new();
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .name
        .is_empty()
    {
        return vec![system_message_key(world, "server.GuildNotInvited")];
    }
    let player_name = current_stage5_character_name(world);
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        push_unique(
            &mut stage5.stage5_systems.guild.members,
            player_name.clone(),
        );
    }
    vec![ServerPacket::GuildMemberChange {
        name: player_name,
        rank_index: 0,
        status: 0,
        ranks: stage5_guild_rank_snapshot(world),
    }]
}

fn stage5_guild_storage_gold_packet(
    world: &mut World,
    change_type: u8,
    amount: u32,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let player_name = current_stage5_character_name(world);
    let failure_receipt = || ServerPacket::GuildStorageGoldChange {
        amount,
        change_type: change_type.saturating_add(3),
        name: player_name.clone(),
    };
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .name
        .is_empty()
    {
        return vec![stage5_guild_not_in_guild_chat(world), failure_receipt()];
    }
    if !stage5_guild_player_in_safe_zone(world) {
        return vec![
            system_message_key(world, "server.CannotUseGuildStorageOutsideSafezones"),
            failure_receipt(),
        ];
    }
    match change_type {
        0 => {
            if world.resource::<PlayerRuntimeResource>().gold < amount {
                return vec![
                    system_message_key(world, "server.InsufficientGold"),
                    failure_receipt(),
                ];
            }
            if world
                .resource::<Stage5SystemsResource>()
                .stage5_systems
                .guild
                .storage_gold
                > u32::MAX.saturating_sub(amount)
            {
                return vec![
                    system_message_key(world, "server.GuildGoldLimitReached"),
                    failure_receipt(),
                ];
            }
            world.resource_mut::<PlayerRuntimeResource>().gold -= amount;
            {
                let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
                stage5.stage5_systems.guild.storage_gold = stage5
                    .stage5_systems
                    .guild
                    .storage_gold
                    .saturating_add(amount);
            }
            vec![
                ServerPacket::LoseGold { gold: amount },
                ServerPacket::GuildStorageGoldChange {
                    amount,
                    change_type: 0,
                    name: player_name,
                },
            ]
        }
        1 => {
            let guild_gold = world
                .resource::<Stage5SystemsResource>()
                .stage5_systems
                .guild
                .storage_gold;
            if guild_gold < amount {
                return vec![
                    system_message_key(world, "server.InsufficientGold"),
                    failure_receipt(),
                ];
            }
            if !can_gain_gold(world.resource::<PlayerRuntimeResource>(), amount) {
                return vec![
                    system_message_key(world, "server.GoldLimitReached"),
                    failure_receipt(),
                ];
            }
            if stage5_current_guild_rank_index(world) != 0 {
                return vec![
                    system_message_key(world, "server.InsufficientRank"),
                    failure_receipt(),
                ];
            }
            world.resource_mut::<PlayerRuntimeResource>().gold += amount;
            world
                .resource_mut::<Stage5SystemsResource>()
                .stage5_systems
                .guild
                .storage_gold = guild_gold - amount;
            vec![
                ServerPacket::GainedGold { gold: amount },
                ServerPacket::GuildStorageGoldChange {
                    amount,
                    change_type: 1,
                    name: player_name,
                },
            ]
        }
        _ => Vec::new(),
    }
}

fn stage5_guild_storage_list_packet(
    validated: &BTreeMap<u8, ValidatedStage5GuildStorageItem>,
) -> ServerPacket {
    let mut items = vec![None; GUILD_STORAGE_SLOT_COUNT];
    for (slot, stored) in validated {
        if let Some(target) = items.get_mut(usize::from(*slot)) {
            *target = Some(stored.packet.clone());
        }
    }
    ServerPacket::GuildStorageList { items }
}

fn stage5_guild_storage_item_packet(
    world: &mut World,
    change_type: u8,
    from: i32,
    to: i32,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .guild
        .name
        .is_empty()
    {
        return vec![
            stage5_guild_storage_failure(change_type, from, to),
            stage5_guild_not_in_guild_chat(world),
        ];
    }
    if !stage5_guild_player_in_safe_zone(world) && change_type != 3 {
        return vec![
            stage5_guild_storage_failure(change_type, from, to),
            system_message_key(world, "server.GuildStorageOutsideSafezone"),
        ];
    }

    let validated_storage = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        match validate_stage5_guild_storage_packet_snapshot(&stage5.stage5_systems) {
            Ok(validated) => validated,
            Err(_) => return vec![stage5_guild_storage_failure(change_type, from, to)],
        }
    };
    let user = current_stage5_character_index(world);
    match change_type {
        0 => {
            if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_STORE_ITEM) {
                return vec![
                    stage5_guild_storage_failure(change_type, from, to),
                    system_message_key(world, "server.NoPermissionGuildStorage"),
                ];
            }
            let Ok(to_slot) = u8::try_from(to) else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            if usize::from(to_slot) >= GUILD_STORAGE_SLOT_COUNT {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }
            let Some(from_slot) = u8::try_from(from).ok() else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            let item_index = {
                let inventory = world.resource::<InventoryResource>();
                inventory
                    .inventory_items
                    .iter()
                    .position(|item| inventory_item_matches_index(item, from_slot))
            };
            let Some(item_index) = item_index else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            let item = world.resource::<InventoryResource>().inventory_items[item_index].clone();
            if item_has_crystal_or_rental_bind_flag(&item, CRYSTAL_BIND_DONT_STORE)
                || validate_committed_item_state_carrier(&item).is_err()
            {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }
            if validated_storage.contains_key(&to_slot) {
                return vec![
                    stage5_guild_storage_failure(change_type, from, to),
                    system_message_key(world, "server.TargetSlotNotEmpty"),
                ];
            }
            let Ok(encoded) = serde_json::to_string(&item) else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };

            let mut next_systems = world
                .resource::<Stage5SystemsResource>()
                .stage5_systems
                .clone();
            next_systems
                .guild
                .storage_items
                .insert(to_slot, item.key.clone());
            next_systems
                .guild
                .storage_item_states
                .insert(to_slot, encoded);
            next_systems.guild.storage_item_users.insert(to_slot, user);
            let Ok(next_storage) = validate_stage5_guild_storage_packet_snapshot(&next_systems)
            else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            let Some(stored_packet) = next_storage
                .get(&to_slot)
                .map(|stored| stored.packet.clone())
            else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };

            let mut next_inventory = world.resource::<InventoryResource>().clone();
            if item_index >= next_inventory.inventory_items.len() {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }
            next_inventory.inventory_items.remove(item_index);
            *world.resource_mut::<InventoryResource>() = next_inventory;
            world.resource_mut::<Stage5SystemsResource>().stage5_systems = next_systems;
            vec![ServerPacket::GuildStorageItemChange {
                change_type: 0,
                to,
                from,
                user,
                item: Some(stored_packet),
            }]
        }
        1 => {
            if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_RETRIEVE_ITEM) {
                return vec![system_message_key(
                    world,
                    "server.NoPermissionGuildStorageRetrieve",
                )];
            }
            let Ok(from_slot) = u8::try_from(from) else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            let Some(to_slot) = u8::try_from(to).ok() else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            if !is_valid_inventory_slot(
                to_slot,
                world.resource::<InventoryResource>().inventory_capacity,
            ) {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }
            let occupied = world
                .resource::<InventoryResource>()
                .inventory_items
                .iter()
                .any(|item| inventory_item_matches_index(item, to_slot));
            if occupied {
                return vec![
                    stage5_guild_storage_failure(change_type, from, to),
                    system_message_key(world, "server.TargetSlotNotEmpty"),
                ];
            }
            let Some(stored) = validated_storage.get(&from_slot) else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            let Some((container, slot)) = inventory_container_and_slot_for_index(to_slot) else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            let mut prepared_item = stored.state.clone();
            prepared_item.container = container;
            prepared_item.slot = slot;
            normalize_incoming_item_tree_unique_ids(
                world.resource::<InventoryResource>(),
                &mut prepared_item,
                &[],
            );
            if validate_committed_item_state_carrier(&prepared_item).is_err()
                || try_user_item_from_item_state(&prepared_item).is_err()
            {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }

            let mut next_inventory = world.resource::<InventoryResource>().clone();
            next_inventory.inventory_items.push(prepared_item);
            let mut next_systems = world
                .resource::<Stage5SystemsResource>()
                .stage5_systems
                .clone();
            next_systems.guild.storage_items.remove(&from_slot);
            next_systems.guild.storage_item_states.remove(&from_slot);
            next_systems.guild.storage_item_users.remove(&from_slot);
            if validate_stage5_guild_storage_packet_snapshot(&next_systems).is_err() {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }

            *world.resource_mut::<InventoryResource>() = next_inventory;
            world.resource_mut::<Stage5SystemsResource>().stage5_systems = next_systems;
            vec![ServerPacket::GuildStorageItemChange {
                change_type: 1,
                to,
                from,
                user,
                item: None,
            }]
        }
        2 => {
            if !stage5_current_guild_has_option(world, GUILD_OPTION_CAN_STORE_ITEM) {
                return vec![
                    stage5_guild_storage_failure(change_type, from, to),
                    system_message_key(world, "server.NoGuildStorageMovePermission"),
                ];
            }
            let (Ok(from_slot), Ok(to_slot)) = (u8::try_from(from), u8::try_from(to)) else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };
            if usize::from(from_slot) >= GUILD_STORAGE_SLOT_COUNT
                || usize::from(to_slot) >= GUILD_STORAGE_SLOT_COUNT
            {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }
            let Some(moved_item) = validated_storage
                .get(&from_slot)
                .map(|stored| stored.packet.clone())
            else {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            };

            let mut next_systems = world
                .resource::<Stage5SystemsResource>()
                .stage5_systems
                .clone();
            let guild = &mut next_systems.guild;
            stage5_swap_guild_storage_map(&mut guild.storage_items, from_slot, to_slot);
            stage5_swap_guild_storage_map(&mut guild.storage_item_states, from_slot, to_slot);
            stage5_swap_guild_storage_map(&mut guild.storage_item_users, from_slot, to_slot);
            if validate_stage5_guild_storage_packet_snapshot(&next_systems).is_err() {
                return vec![stage5_guild_storage_failure(change_type, from, to)];
            }

            world.resource_mut::<Stage5SystemsResource>().stage5_systems = next_systems;
            vec![ServerPacket::GuildStorageItemChange {
                change_type: 2,
                to,
                from,
                user,
                item: Some(moved_item),
            }]
        }
        3 => vec![stage5_guild_storage_list_packet(&validated_storage)],
        _ => vec![stage5_guild_storage_failure(change_type, from, to)],
    }
}
const CRYSTAL_QUEST_STATE_ADD: u8 = 0;
const CRYSTAL_QUEST_STATE_UPDATE: u8 = 1;
const CRYSTAL_QUEST_STATE_REMOVE: u8 = 2;

fn stage5_quest_task_list(world: &World, quest_id: i32) -> Vec<String> {
    if let Some(tasks) = crystal_quest_task_list(world, quest_id) {
        return tasks;
    }
    let language = world.resource::<SessionResource>().language;
    let Some(snapshot) = world
        .resource::<QuestResource>()
        .quests
        .iter()
        .find(|quest| quest.quest_id == quest_id)
        .map(|quest| quest.snapshot(language))
    else {
        return Vec::new();
    };
    let mut tasks = Vec::new();
    for task in [
        snapshot.objective,
        snapshot.progress_label,
        snapshot.tracker,
    ] {
        if !task.trim().is_empty() {
            push_unique(&mut tasks, task);
        }
    }
    tasks
}

fn stage5_quest_stage(world: &World, quest_id: i32) -> Option<QuestStage> {
    world
        .resource::<QuestResource>()
        .quests
        .iter()
        .find(|quest| quest.quest_id == quest_id)
        .map(|quest| quest.stage)
}

fn stage5_quest_change_packet(
    world: &World,
    quest_id: i32,
    quest_state: u8,
    track_quest: bool,
    is_new: bool,
) -> ServerPacket {
    let stage = stage5_quest_stage(world, quest_id).unwrap_or(QuestStage::Available);
    ServerPacket::ChangeQuest {
        quest_id,
        task_list: stage5_quest_task_list(world, quest_id),
        taken: matches!(stage, QuestStage::InProgress | QuestStage::ReadyToTurnIn),
        completed: matches!(stage, QuestStage::ReadyToTurnIn | QuestStage::Completed),
        new: is_new,
        quest_state,
        track_quest,
    }
}

fn stage5_quest_remove_packet(quest_id: i32, completed: bool) -> ServerPacket {
    ServerPacket::ChangeQuest {
        quest_id,
        task_list: Vec::new(),
        taken: false,
        completed,
        new: false,
        quest_state: CRYSTAL_QUEST_STATE_REMOVE,
        track_quest: false,
    }
}

fn active_npc_allows_quest_request(
    world: &World,
    quest_id: i32,
    requested_npc_index: Option<u32>,
    finish: bool,
    selected_item_index: Option<i32>,
) -> bool {
    if newcomer_diary_allows_quest_request_without_npc(
        world,
        quest_id,
        requested_npc_index,
        finish,
    ) {
        return true;
    }

    let Some(active_dialog) = world
        .resource::<NpcStateResource>()
        .active_npc_dialog
        .as_ref()
    else {
        return false;
    };
    let npc_object_id = active_dialog.npc_object_id;
    if !active_dialog.links.iter().any(|link| {
        quest_dialog_link_allows_operation(&link.target, quest_id, finish, selected_item_index)
    }) {
        return false;
    }

    if !quest_npc_matches_request(
        world,
        quest_id,
        requested_npc_index,
        finish,
        npc_object_id,
    ) {
        return false;
    }

    crystal_npc_object_in_data_range(world, npc_object_id)
}

fn newcomer_diary_allows_quest_request_without_npc(
    world: &World,
    quest_id: i32,
    requested_npc_index: Option<u32>,
    finish: bool,
) -> bool {
    if !world
        .get_resource::<QuestResource>()
        .is_some_and(|quests| quests.newcomer_v1_cadence || quests.newcomer_v2_cadence)
    {
        return false;
    }
    let Some(info) = effective_crystal_quest_info_by_id(world, quest_id) else {
        return false;
    };
    newcomer_diary_template_allows_quest_request(
        info.npc_index,
        info.finish_npc_index,
        requested_npc_index,
        finish,
    )
}

fn newcomer_diary_template_allows_quest_request(
    start_npc_index: u32,
    finish_npc_index: u32,
    requested_npc_index: Option<u32>,
    finish: bool,
) -> bool {
    if finish {
        start_npc_index == 0 && finish_npc_index == 0
    } else {
        start_npc_index == 0 && requested_npc_index == Some(0)
    }
}

fn quest_npc_matches_request(
    world: &World,
    quest_id: i32,
    requested_npc_index: Option<u32>,
    finish: bool,
    npc_object_id: u32,
) -> bool {
    if quest_id == GUIDE_QUEST_ID {
        npc_object_id == GUIDE_NPC_ID
            && requested_npc_index.is_none_or(|index| index == GUIDE_NPC_ID)
    } else if let Some(info) = effective_crystal_quest_info_by_id(world, quest_id) {
        let requested_matches = requested_npc_index
            .is_none_or(|index| index == npc_object_id || index == info.npc_index);
        requested_matches
            && if finish {
                crystal_quest_finish_npc_matches(&info, npc_object_id)
            } else {
                crystal_quest_start_npc_matches(&info, npc_object_id)
            }
    } else {
        false
    }
}

fn quest_dialog_link_allows_operation(
    target: &str,
    quest_id: i32,
    finish: bool,
    selected_item_index: Option<i32>,
) -> bool {
    let target = target.trim();
    let explicit = if finish {
        format!("@FinishQuest:{quest_id}")
    } else {
        format!("@AcceptQuest:{quest_id}")
    };
    let crystal = if finish {
        format!("@quest:finish:{quest_id}")
    } else {
        format!("@quest:accept:{quest_id}")
    };
    target.eq_ignore_ascii_case(&explicit)
        || target.eq_ignore_ascii_case(&crystal)
        || (finish
            && selected_item_index.is_some_and(|selected| {
                target.eq_ignore_ascii_case(&format!("@quest:finish:{quest_id}:{selected}"))
            }))
}

#[cfg(test)]
mod quest_dialog_operation_link_tests {
    use bevy_ecs::prelude::World;
    use mir2_protocol::Point;

    use super::super::components::{Npc, ObjectId, Position, SelfPlayer};
    use super::super::npc::{ActiveNpcDialogState, NpcDialogLinkState};
    use super::super::resources::{NpcStateResource, SessionResource};
    use super::{
        active_npc_allows_quest_request, quest_dialog_link_allows_operation, GUIDE_NPC_ID,
        GUIDE_QUEST_ID,
    };

    #[test]
    fn starter_and_crystal_dialog_links_preserve_web_and_native_quest_actions() {
        assert!(quest_dialog_link_allows_operation(
            "@AcceptQuest:1001",
            1001,
            false,
            None,
        ));
        assert!(quest_dialog_link_allows_operation(
            "@quest:accept:42",
            42,
            false,
            None,
        ));
        assert!(quest_dialog_link_allows_operation(
            "@FinishQuest:1001",
            1001,
            true,
            None,
        ));
        assert!(quest_dialog_link_allows_operation(
            "@quest:finish:42",
            42,
            true,
            None,
        ));
        assert!(quest_dialog_link_allows_operation(
            "@quest:finish:42:2",
            42,
            true,
            Some(2),
        ));
        assert!(!quest_dialog_link_allows_operation(
            "@quest:finish:42:1",
            42,
            true,
            Some(2),
        ));
        assert!(!quest_dialog_link_allows_operation(
            "@quest:accept:43",
            42,
            false,
            None,
        ));
    }

    #[test]
    fn quest_packets_require_the_exact_active_dialog_inside_crystal_data_range() {
        let mut world = World::new();
        world.insert_resource(NpcStateResource::new());
        let config = crate::config::SimulationConfig::default();
        let mut session = SessionResource::new(&config);
        session.selected_character = Some(config.default_character.clone());
        world.insert_resource(session);
        let player = world
            .spawn((SelfPlayer, ObjectId(1), Position(Point { x: 10, y: 10 })))
            .id();
        world.spawn((
            Npc,
            ObjectId(GUIDE_NPC_ID),
            Position(Point { x: 11, y: 10 }),
        ));

        assert!(!active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            Some(0),
            false,
            None,
        ));
        assert!(!active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            None,
            true,
            None,
        ));
        assert!(!active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            Some(GUIDE_NPC_ID),
            false,
            None,
        ));

        world.resource_mut::<NpcStateResource>().active_npc_dialog = Some(ActiveNpcDialogState {
            npc_object_id: GUIDE_NPC_ID,
            npc_name: "Village Guide".to_string(),
            npc_name_key: None,
            stage: None,
            current: 0,
            required: 1,
            title: "Quest".to_string(),
            body: Vec::new(),
            footer: String::new(),
            links: vec![NpcDialogLinkState {
                text: "Accept".to_string(),
                target: format!("@AcceptQuest:{GUIDE_QUEST_ID}"),
            }],
            input: None,
        });
        assert!(
            !active_npc_allows_quest_request(&world, GUIDE_QUEST_ID, Some(0), false, None,),
            "the removed Web sentinel must not impersonate a concrete NPC"
        );
        assert!(active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            Some(GUIDE_NPC_ID),
            false,
            None,
        ));

        world
            .resource_mut::<NpcStateResource>()
            .active_npc_dialog
            .as_mut()
            .expect("active quest dialog")
            .links = vec![NpcDialogLinkState {
            text: "Complete".to_string(),
            target: format!("@FinishQuest:{GUIDE_QUEST_ID}"),
        }];
        assert!(active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            None,
            true,
            None,
        ));

        world
            .entity_mut(player)
            .get_mut::<Position>()
            .expect("player position")
            .0 = Point { x: 27, y: 10 };
        assert!(active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            None,
            true,
            None,
        ));

        world
            .entity_mut(player)
            .get_mut::<Position>()
            .expect("player position")
            .0 = Point { x: 28, y: 10 };
        assert!(!active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            Some(GUIDE_NPC_ID),
            false,
            None,
        ));
        assert!(!active_npc_allows_quest_request(
            &world,
            GUIDE_QUEST_ID,
            None,
            true,
            None,
        ));
    }
}

#[cfg(test)]
#[path = "packets_diary_quest_tests.rs"]
mod diary_quest_tests;

pub(super) fn stage5_accept_quest_packet(world: &mut World, quest_id: i32) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if !quest_definition_exists(world, quest_id) {
        return vec![system_message_key(world, "server.CouldNotAcceptQuest")];
    }
    if !can_accept_quest(world, quest_id)
        && !matches!(
            stage5_quest_stage(world, quest_id),
            Some(QuestStage::InProgress | QuestStage::ReadyToTurnIn | QuestStage::Completed)
        )
    {
        return vec![system_message_key(world, "server.CouldNotAcceptQuest")];
    }
    match ensure_runtime_quest(world, quest_id) {
        QuestStage::Available => {
            begin_quest(world, quest_id);
            let mut packets=vec![stage5_quest_change_packet(
                world,
                quest_id,
                CRYSTAL_QUEST_STATE_ADD,
                true,
                true,
            )];
            if mir2_game_data::periodic_quests::is_periodic(quest_id) {
                if let Some(packet)=super::quests::periodic_quests::info_packet(world,quest_id) {packets.push(packet);}
                packets.push(ServerPacket::CompleteQuest{completed_quests:completed_quest_ids(world)});
            }
            packets
        }
        QuestStage::InProgress | QuestStage::ReadyToTurnIn => vec![stage5_quest_change_packet(
            world,
            quest_id,
            CRYSTAL_QUEST_STATE_UPDATE,
            true,
            false,
        )],
        QuestStage::Completed => vec![system_message_key(world, "server.QuestAlreadyCompleted")],
    }
}

pub(super) fn stage5_finish_quest_packet(
    world: &mut World,
    quest_id: i32,
    selected_item_index: Option<i32>,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if ensure_runtime_quest(world, quest_id) != QuestStage::ReadyToTurnIn {
        return Vec::new();
    }
    if let Some(quest) = quest_template_by_id(quest_id) {
        let proof_quantity = world
            .resource::<InventoryResource>()
            .inventory_items
            .iter()
            .filter(|item| {
                item.container == ItemContainer::Quest && item.key == quest.quest_item.key
            })
            .map(|item| item.quantity)
            .sum::<u32>();
        if proof_quantity < quest.quest_item.quantity {
            return Vec::new();
        }
    }
    if crystal_quest_reward_selection_missing(quest_id, selected_item_index) {
        return vec![system_message_key(world, "client.YouMustSelectRewardItem")];
    }
    complete_quest_with_selection(world, quest_id, selected_item_index);
    if stage5_quest_stage(world, quest_id) != Some(QuestStage::Completed) {
        return vec![system_message_key(world, "server.CannotHandInQuestBagFull")];
    }
    let mut packets = vec![
        stage5_quest_remove_packet(
            quest_id,
            quest_completion_is_permanent(world, quest_id),
        ),
        ServerPacket::CompleteQuest {
            completed_quests: completed_quest_ids(world),
        },
    ];
    if let Some(packet) = newcomer_daily_bonus_update_packet(world, quest_id) {
        packets.push(packet);
    }
    packets
}

fn stage5_abandon_quest_packet(world: &mut World, quest_id: i32) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if !abandon_quest(world, quest_id) {
        return Vec::new();
    }
    vec![stage5_quest_remove_packet(quest_id, false)]
}

fn stage5_share_quest_packet(world: &mut World, quest_id: i32) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if !quest_definition_exists(world, quest_id) {
        return vec![system_message_key(world, "server.CouldNotAcceptQuest")];
    }
    let sharer_name = stage5_player_name(world);
    let has_target = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .group
        .members
        .iter()
        .any(|member| !member.eq_ignore_ascii_case(&sharer_name));
    if !has_target {
        return vec![system_message_key(world, "server.QuestNotShared")];
    }
    vec![ServerPacket::ShareQuest {
        quest_index: quest_id,
        sharer_name,
    }]
}

fn stage5_market_success_key_args<I, S>(world: &World, key: &str, args: I) -> ServerPacket
where
    I: IntoIterator<Item = S>,
    S: ToString,
{
    ServerPacket::MarketSuccess {
        message: format_localized_text(super::session::current_language(world), key, args),
    }
}

/// Crystal market page size (`Crystal/Server/MirObjects/PlayerObject.cs:8356,
/// 8405` iterate up to 10 listings per page).
const STAGE5_MARKET_PAGE_SIZE: usize = 10;

/// Whether a listing matches the search text, mirroring Crystal `Match`
/// (`Crystal/Server/MirObjects/PlayerObject.cs:8318-8324`) name filter — an
/// empty query matches everything; otherwise the (space-stripped) item name must
/// contain the query. Sold / cancelled / expired listings are excluded so the
/// public market only shows live listings (Crystal `Match`'s
/// `!info.Expired && !info.Sold` guard).
fn stage5_market_listing_matches(listing: &Stage5AuctionListing, normalized_query: &str) -> bool {
    if listing.sold || listing.cancelled || listing.expired {
        return false;
    }
    normalized_query.is_empty()
        || listing
            .item_key
            .replace('-', "")
            .to_ascii_lowercase()
            .contains(normalized_query)
        || stage5_item_name(&listing.item_key)
            .replace(' ', "")
            .to_ascii_lowercase()
            .contains(normalized_query)
}

/// Builds a wire `ClientAuction` from a stored `Stage5AuctionListing`, resolving
/// the `item_key` to a `UserItem` (so the browser can show the item name / grade
/// / required level). Mirrors `Crystal/Server/MirDatabase/AuctionInfo.cs:104-115`
/// (`CreateClientAuction`): `AuctionID`, `Item`, `Seller`, `Price`, the
/// consignment date and `ItemType`. The simulation only models fixed-price
/// consignments, so `ItemType` is `Consign` (1) and the consignment date is left
/// at `0` (Crystal `DateTime.MinValue.ToBinary()`), which the gateway omits.
fn stage5_client_auction(listing: &Stage5AuctionListing) -> ClientAuction {
    let item = listing
        .item_state_json
        .as_deref()
        .and_then(|encoded| item_custody::decode(&listing.item_key, encoded).ok())
        .and_then(|item| try_user_item_from_item_state(&item).ok())
        .unwrap_or_else(|| stage5_market_user_item(&listing.item_key));
    ClientAuction {
        auction_id: u64::from(listing.id),
        item,
        seller: listing.seller.clone(),
        price: listing.price,
        consignment_date_binary_datetime: 0,
        // Crystal `MarketItemType.Consign = 1` — the simulation lists items as
        // fixed-price consignments rather than live auctions.
        item_type: 1,
    }
}

/// Legacy key-only listings remain displayable. This template preview is never
/// used to return or sell an item: delivery requires the exact custody carrier.
fn stage5_market_user_item(item_key: &str) -> UserItem {
    let template = crystal_item_template_for_item_key(item_key);
    let item_index = template
        .as_ref()
        .map(|template| template.item_index)
        .unwrap_or(0);
    let (current_dura, max_dura) = template
        .as_ref()
        .map(|template| (template.durability, template.durability))
        .unwrap_or((0, 0));
    UserItem {
        unique_id: u64::from(item_index.max(0) as u32),
        item_index,
        current_dura,
        max_dura,
        count: 1,
        soul_bound_id: -1,
        identified: true,
        cursed: false,
        slots: Vec::new(),
        gem_count: 0,
        added_stats: Vec::new(),
        awake_type: 0,
        awake_values: Vec::new(),
        refined_value: 0,
        refine_added: 0,
        refine_success_chance: 0,
        wedding_ring: -1,
        expire_info: None,
        rental_information: None,
        is_shop_item: false,
        sealed_info: None,
        gm_made: false,
    }
}

/// Mirrors Crystal `GetMarket` (`Crystal/Server/MirObjects/PlayerObject.cs:8376-
/// 8421`): filters the auction list by the search text, builds up to one page of
/// `ClientAuction`s, and enqueues `S.NPCMarket { Listings, Pages, UserMode }`.
/// `page` selects the slice (`page * 10 .. +10`), as in Crystal `MarketPage`
/// (`:8327-8373`). The `MarketSuccess` count line is retained alongside the
/// `NPCMarket` packet for backward compatibility with the existing web client.
fn stage5_market_listing_packets(
    world: &World,
    match_text: &str,
    user_mode: bool,
    page: usize,
) -> Vec<ServerPacket> {
    let normalized = match_text.replace(' ', "").to_ascii_lowercase();
    let matched: Vec<&Stage5AuctionListing> = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .auction
        .iter()
        .filter(|listing| stage5_market_listing_matches(listing, &normalized))
        .collect();
    let count = matched.len();
    let pages = if count == 0 {
        0
    } else {
        i32::try_from((count - 1) / STAGE5_MARKET_PAGE_SIZE + 1).unwrap_or(i32::MAX)
    };
    let listings: Vec<ClientAuction> = matched
        .iter()
        .skip(page * STAGE5_MARKET_PAGE_SIZE)
        .take(STAGE5_MARKET_PAGE_SIZE)
        .map(|listing| stage5_client_auction(listing))
        .collect();
    vec![
        ServerPacket::NPCMarket {
            listings,
            pages,
            user_mode,
        },
        ServerPacket::MarketSuccess {
            message: format!("{count} market listings matched."),
        },
    ]
}

fn stage5_consign_item_packet(
    world: &mut World,
    unique_id: u64,
    price: u32,
    _market_type: u8,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if price == 0 {
        return vec![
            ServerPacket::ConsignItem {
                unique_id,
                success: false,
            },
            ServerPacket::MarketFail { reason: 1 },
        ];
    }
    let Some(item) = world
        .resource::<InventoryResource>()
        .inventory_items
        .iter()
        .find(|item| item_matches_inventory_unique_id(item, unique_id))
        .cloned()
    else {
        return vec![
            ServerPacket::ConsignItem {
                unique_id,
                success: false,
            },
            ServerPacket::MarketFail { reason: 1 },
        ];
    };
    if item_custody::refresh(world).is_err() {
        return vec![ServerPacket::ConsignItem {
            unique_id,
            success: false,
        }];
    }
    let pending_refine_uid = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .refine
        .pending_unique_id;
    if pending_refine_uid != 0 && pending_refine_uid == unique_id {
        return vec![ServerPacket::ConsignItem {
            unique_id,
            success: false,
        }];
    }
    let Some(encoded) = item_custody::encode(&item) else {
        return vec![ServerPacket::ConsignItem {
            unique_id,
            success: false,
        }];
    };
    if !item_custody::can_take(world.resource::<InventoryResource>(), &item) {
        return vec![ServerPacket::ConsignItem {
            unique_id,
            success: false,
        }];
    }
    let seller = stage5_player_name(world);
    let id = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        stage5
            .stage5_systems
            .auction
            .iter()
            .map(|listing| listing.id)
            .max()
            .unwrap_or(0)
            .checked_add(1)
    };
    let Some(id) = id else {
        return vec![ServerPacket::ConsignItem {
            unique_id,
            success: false,
        }];
    };
    world
        .resource_mut::<InventoryResource>()
        .inventory_items
        .retain(|candidate| !item_matches_inventory_unique_id(candidate, unique_id));
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .auction
        .push(Stage5AuctionListing {
            item_state_json: Some(encoded),
            id,
            seller,
            item_key: item.key.clone(),
            price,
            currency: crate::config::CurrencyKind::Gold,
            sold: false,
            cancelled: false,
            expired: false,
        });
    item_custody::refresh(world).expect("validated custody transfer");
    vec![
        ServerPacket::ConsignItem {
            unique_id,
            success: true,
        },
        ServerPacket::MarketSuccess {
            message: format!("Listed {} for {price} Gold.", item.name),
        },
    ]
}

pub(super) fn stage5_market_buy_packet(
    world: &mut World,
    auction_id: u64,
    bid_price: u32,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let Ok(listing_id) = u32::try_from(auction_id) else {
        return vec![ServerPacket::MarketFail { reason: 7 }];
    };
    let buyer = stage5_player_name(world);
    let Some(index) = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .auction
        .iter()
        .position(|listing| listing.id == listing_id && !listing.cancelled)
    else {
        return vec![ServerPacket::MarketFail { reason: 7 }];
    };
    let listing = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .auction[index]
        .clone();
    if listing.sold {
        return vec![ServerPacket::MarketFail { reason: 2 }];
    }
    if listing.expired {
        return vec![ServerPacket::MarketFail { reason: 3 }];
    }
    if listing.seller.eq_ignore_ascii_case(&buyer) {
        return vec![ServerPacket::MarketFail { reason: 6 }];
    }
    let Some(price) = stage5_market_sale_price(listing.price, bid_price) else {
        return vec![ServerPacket::MarketFail { reason: 9 }];
    };
    if world.resource::<PlayerRuntimeResource>().gold < price {
        return vec![ServerPacket::MarketFail { reason: 4 }];
    }
    if listing.currency != crate::config::CurrencyKind::Gold
        || item_custody::refresh(world).is_err()
    {
        return vec![ServerPacket::MarketFail { reason: 7 }];
    }
    let Some(item) = listing
        .item_state_json
        .as_deref()
        .and_then(|encoded| item_custody::decode(&listing.item_key, encoded).ok())
    else {
        return vec![ServerPacket::MarketFail { reason: 7 }];
    };
    let Some((inventory, changed)) =
        item_custody::plan_return(world.resource::<InventoryResource>(), &item, None, true)
    else {
        return vec![ServerPacket::MarketFail { reason: 5 }];
    };
    let updates = item_custody::returned_packets(world.resource::<InventoryResource>(), &changed);
    world.resource_mut::<PlayerRuntimeResource>().gold -= price;
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let listing = &mut stage5.stage5_systems.auction[index];
        listing.price = price;
        listing.sold = true;
    }
    *world.resource_mut::<InventoryResource>() = inventory;
    item_custody::refresh(world).expect("validated custody transfer");
    let mut packets = vec![ServerPacket::LoseGold { gold: price }];
    packets.extend(updates);
    packets.extend(vec![stage5_market_success_key_args(
        world,
        "server.BoughtItemForGold",
        [stage5_item_name(&listing.item_key), price.to_string()],
    )]);
    packets
}

pub(super) fn stage5_market_get_back_packet(
    world: &mut World,
    _mode: u8,
    auction_id: u64,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let seller = stage5_player_name(world);
    let Some(index) = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .auction
        .iter()
        .position(|l| {
            (auction_id == 0 || u64::from(l.id) == auction_id)
                && l.seller.eq_ignore_ascii_case(&seller)
        })
    else {
        return vec![ServerPacket::MarketFail { reason: 7 }];
    };
    let listing = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .auction[index]
        .clone();
    if listing.currency != crate::config::CurrencyKind::Gold
        || item_custody::refresh(world).is_err()
    {
        return vec![ServerPacket::MarketFail { reason: 7 }];
    }
    let packets = if listing.sold {
        let settlement = stage5_market_settlement(listing.price);
        let Some(gold) = world
            .resource::<PlayerRuntimeResource>()
            .gold
            .checked_add(settlement.earnings)
        else {
            return vec![ServerPacket::MarketFail { reason: 4 }];
        };
        world.resource_mut::<PlayerRuntimeResource>().gold = gold;
        vec![
            ServerPacket::GainedGold {
                gold: settlement.earnings,
            },
            stage5_market_success_key_args(
                world,
                "server.SoldItemEarningsCommission",
                [
                    stage5_item_name(&listing.item_key),
                    settlement.gross.to_string(),
                    settlement.earnings.to_string(),
                    settlement.commission.to_string(),
                ],
            ),
        ]
    } else {
        let Some(item) = listing
            .item_state_json
            .as_deref()
            .and_then(|encoded| item_custody::decode(&listing.item_key, encoded).ok())
        else {
            return vec![ServerPacket::MarketFail { reason: 7 }];
        };
        let Some((inventory, changed)) =
            item_custody::plan_return(world.resource::<InventoryResource>(), &item, None, true)
        else {
            return vec![ServerPacket::MarketFail { reason: 5 }];
        };
        let mut packets =
            item_custody::returned_packets(world.resource::<InventoryResource>(), &changed);
        *world.resource_mut::<InventoryResource>() = inventory;
        packets.push(ServerPacket::MarketSuccess {
            message: format!("Returned {} from market.", item.name),
        });
        packets
    };
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .auction
        .remove(index);
    item_custody::refresh(world).expect("validated custody transfer");
    packets
}

fn stage5_market_sell_now_packet(world: &mut World, auction_id: u64) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let Ok(listing_id) = u32::try_from(auction_id) else {
        return vec![ServerPacket::MarketFail { reason: 7 }];
    };
    let seller = stage5_player_name(world);
    let has_listing = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .auction
        .iter()
        .any(|listing| listing.id == listing_id && listing.seller.eq_ignore_ascii_case(&seller));
    vec![ServerPacket::MarketFail {
        reason: if has_listing { 9 } else { 7 },
    }]
}

fn stage5_refine_slot(value: i32) -> Option<u8> {
    u8::try_from(value).ok().filter(|slot| *slot < 16)
}

fn stage5_deposit_refine_item_packet(world: &mut World, from: i32, to: i32) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let failure = || {
        vec![ServerPacket::DepositRefineItem {
            from,
            to,
            success: false,
        }]
    };
    if !super::refine_oven::service(world, "REFINE") {
        return failure();
    }
    let (Ok(from_slot), Some(to_slot)) = (u8::try_from(from), stage5_refine_slot(to)) else {
        return failure();
    };
    let refine = &world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .refine;
    if refine.pending_unique_id != 0 || refine.refining || refine.slots.contains_key(&to_slot) {
        return failure();
    }
    if item_custody::refresh(world).is_err() {
        return failure();
    }
    let inventory = world.resource::<InventoryResource>();
    if u16::from(from_slot) >= inventory.inventory_capacity || from_slot >= 86 {
        return failure();
    }
    let collection = if from_slot < 6 { &inventory.belt_items } else { &inventory.inventory_items };
    let Some(index) = collection.iter().position(|item|
        if from_slot < 6 { item.container == ItemContainer::Belt && item.slot == from_slot }
        else { inventory_item_matches_index(item, from_slot - 6) })
    else {
        return failure();
    };
    let item = collection[index].clone();
    let Some(encoded) = item_custody::encode(&item) else {
        return failure();
    };
    if !item_custody::can_take(inventory, &item) {
        return failure();
    }
    if from_slot < 6 { world.resource_mut::<InventoryResource>().belt_items.remove(index); }
    else { world.resource_mut::<InventoryResource>().inventory_items.remove(index); }
    let mut state = world.resource_mut::<Stage5SystemsResource>();
    state.stage5_systems.refine.slots.insert(to_slot, item.key);
    state
        .stage5_systems
        .refine
        .item_states
        .insert(to_slot, encoded);
    drop(state);
    item_custody::refresh(world).expect("validated custody transfer");
    vec![ServerPacket::DepositRefineItem {
        from,
        to,
        success: true,
    }]
}

fn stage5_retrieve_refine_item_packet(world: &mut World, from: i32, to: i32) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let failure = || {
        vec![ServerPacket::RetrieveRefineItem {
            from,
            to,
            success: false,
        }]
    };
    let (Some(from_slot), Ok(to_slot)) = (stage5_refine_slot(from), u8::try_from(to)) else {
        return failure();
    };
    if item_custody::refresh(world).is_err() {
        return failure();
    }
    let refine = &world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .refine;
    let Some(item) = refine
        .slots
        .get(&from_slot)
        .zip(refine.item_states.get(&from_slot))
        .and_then(|(key, encoded)| item_custody::decode(key, encoded).ok())
    else {
        return failure();
    };
    let Some((inventory, _)) = item_custody::plan_return_crystal_array(
        world.resource::<InventoryResource>(),
        &item,
        Some(to_slot),
    ) else {
        return failure();
    };
    *world.resource_mut::<InventoryResource>() = inventory;
    let mut state = world.resource_mut::<Stage5SystemsResource>();
    state.stage5_systems.refine.slots.remove(&from_slot);
    state.stage5_systems.refine.item_states.remove(&from_slot);
    drop(state);
    item_custody::refresh(world).expect("validated custody transfer");
    vec![ServerPacket::RetrieveRefineItem {
        from,
        to,
        success: true,
    }]
}

fn stage5_refine_cancel_packet(world: &mut World) -> Vec<ServerPacket> {
    if !is_in_world(world) || item_custody::refresh(world).is_err() {
        return Vec::new();
    }
    let slots = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .refine
        .slots
        .clone();
    let mut packets = Vec::new();
    for (slot, key) in slots {
        let encoded = world
            .resource::<Stage5SystemsResource>()
            .stage5_systems
            .refine
            .item_states
            .get(&slot)
            .cloned();
        let Some(item) = encoded
            .as_deref()
            .and_then(|v| item_custody::decode(&key, v).ok())
        else {
            continue;
        };
        let Some((inventory, changed)) =
            item_custody::plan_return_crystal_array(world.resource::<InventoryResource>(), &item, None)
        else {
            continue;
        };
        let destination = if changed[0].container == ItemContainer::Belt { changed[0].slot }
            else { inventory_index_for_item(&changed[0]).expect("bag destination") + 6 };
        *world.resource_mut::<InventoryResource>() = inventory;
        let mut state = world.resource_mut::<Stage5SystemsResource>();
        state.stage5_systems.refine.slots.remove(&slot);
        state.stage5_systems.refine.item_states.remove(&slot);
        packets.push(ServerPacket::RetrieveRefineItem {
            from: i32::from(slot),
            to: i32::from(destination),
            success: true,
        });
    }
    item_custody::refresh(world).expect("validated custody transfer");
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .refine
        .slots
        .is_empty()
    {
        packets.push(ServerPacket::RefineCancel);
    } else {
        packets.push(system_message_key(world, "server.BagNoRoomForItem"));
        packets.push(ServerPacket::NPCCollectRefine { success: false });
    }
    packets
}

// --- Crystal-style weapon refine tuning ---------------------------------
// Best-effort model: the deposited ingredients set a success chance and bias
// the refined stat (DC/MC/SC); CheckRefine rolls against it. Exact ingredient
// weights/thresholds are Crystal `Settings` values to be re-validated against
// the C# reference; these are sane defaults that make refine real (success/
// fail/material cost/soft cap) instead of an unconditional +1.
// --- Crystal weapon refine (Server/Settings.cs + PlayerObject.RefineItem/CheckRefine) ---
// Ingredients retain actual durability and added stats; refine_oven owns the
// target lifecycle. The deterministic RNG remains a documented source deviation.
const REFINE_BASE_CHANCE: i32 = 20;
const REFINE_WEP_STAT_REDUCE: i32 = 6;
const REFINE_ITEM_STAT_REDUCE: i32 = 15;
const REFINE_ORE_NAME: &str = "BlackIronOre";

fn refine_template_for_key(key: &str) -> Option<CrystalItemTemplate> {
    crystal_item_template_for_item_key(key)
}

/// Aggregated ingredient contributions, mirroring the loop in Crystal
/// `PlayerObject.RefineItem`.
#[derive(Default, Clone, Copy)]
pub(super) struct RefineComponents {
    pub total_dc: i32,
    pub total_mc: i32,
    pub total_sc: i32,
    pub required_level: i32,
    pub item_amount: i32,
    pub durability: i32,
    pub current_dura: i32,
    pub ore_amount: i32,
    pub ore_purity: i32,
}

pub(super) fn refine_components(items: &[ItemState]) -> RefineComponents {
    let mut c = RefineComponents::default();
    for item in items {
        let Some(template) = refine_template_for_key(&item.key) else {
            continue;
        };
        if template.item_type == CRYSTAL_ITEM_TYPE_WEAPON {
            continue;
        }
        let wire = try_user_item_from_item_state(item).expect("validated ingredient");
        let max_dc = crystal_item_stat_value(&template, CRYSTAL_STAT_MAX_DC);
        let max_mc = crystal_item_stat_value(&template, CRYSTAL_STAT_MAX_MC);
        let max_sc = crystal_item_stat_value(&template, CRYSTAL_STAT_MAX_SC);
        if max_dc > 0 || max_mc > 0 || max_sc > 0 {
            c.total_dc += crystal_item_stat_value(&template, CRYSTAL_STAT_MIN_DC)
                + max_dc
                + user_item_stat_total(&wire.added_stats, CRYSTAL_STAT_MAX_DC);
            c.total_mc += crystal_item_stat_value(&template, CRYSTAL_STAT_MIN_MC)
                + max_mc
                + user_item_stat_total(&wire.added_stats, CRYSTAL_STAT_MAX_MC);
            c.total_sc += crystal_item_stat_value(&template, CRYSTAL_STAT_MIN_SC)
                + max_sc
                + user_item_stat_total(&wire.added_stats, CRYSTAL_STAT_MAX_SC);
            c.required_level += i32::from(template.required_amount);
            c.durability += i32::from(wire.max_dura / 1000 == template.durability / 1000);
            c.current_dura += i32::from(wire.current_dura / 1000 == wire.max_dura / 1000);
            c.item_amount += 1;
        }
        if template.name == REFINE_ORE_NAME {
            c.ore_purity += i32::from(wire.current_dura) / 1000;
            c.ore_amount += 1;
        }
    }
    c
}

pub(super) fn refine_target_stat(c: &RefineComponents) -> (Option<u8>, i32) {
    if c.total_dc > c.total_mc && c.total_dc > c.total_sc {
        (Some(CRYSTAL_STAT_MAX_DC), c.total_dc)
    } else if c.total_mc > c.total_dc && c.total_mc > c.total_sc {
        (Some(CRYSTAL_STAT_MAX_MC), c.total_mc)
    } else if c.total_sc > c.total_dc && c.total_sc > c.total_mc {
        (Some(CRYSTAL_STAT_MAX_SC), c.total_sc)
    } else {
        (None, 0)
    }
}

/// The exact Crystal refine success-chance formula (`PlayerObject.RefineItem`).
/// Returns the raw chance (may be <0 or >100; the roll clamps behaviourally).
pub(super) fn refine_success_chance_crystal(
    c: &RefineComponents,
    refine_stat: i32,
    weapon_required: i32,
    weapon_added_stat_sum: i32,
    weapon_luck: i32,
    is_weapon: bool,
) -> i32 {
    if (c.total_dc == 0 && c.total_mc == 0 && c.total_sc == 0) || c.ore_amount == 0 {
        return 0; // no stat ingredients or no ore -> guaranteed smash
    }
    let mut item_success = ((refine_stat * 5) - weapon_required + 5).clamp(0, 10);
    if c.item_amount > 0 && (c.required_level / c.item_amount) > (weapon_required - 5) {
        item_success += 10;
    }
    if c.durability == c.item_amount {
        item_success += 10;
    }
    if c.current_dura == c.item_amount {
        item_success += 5;
    }
    let mut ore_success = 0;
    if c.ore_amount >= c.item_amount {
        ore_success += 15;
    }
    if c.ore_amount > 0
        && c.item_amount > 0
        && (c.ore_purity / c.ore_amount) >= (refine_stat / c.item_amount)
    {
        ore_success += 15;
    }
    if c.ore_purity == refine_stat {
        ore_success += 5;
    }
    let luck_success = (weapon_luck + 5).clamp(0, 10);
    let reduce = if is_weapon {
        REFINE_WEP_STAT_REDUCE
    } else {
        REFINE_ITEM_STAT_REDUCE
    };
    let added_penalty = (weapon_added_stat_sum.max(0) * reduce).min(50);
    item_success + ore_success + luck_success + REFINE_BASE_CHANCE - added_penalty
}

/// Deterministic stand-in for Crystal's `Envir.Random.Next(1, 100)` (1..=99).
pub(super) fn refine_deterministic_1_99(tick: u64, unique_id: u64, salt: u64) -> i32 {
    let value = tick
        .wrapping_mul(0x9E37_79B9_7F4A_7C15)
        .wrapping_add(unique_id.wrapping_mul(0xBF58_476D_1CE4_E5B9))
        .wrapping_add(salt.wrapping_mul(0x94D0_49BB_1331_11EB));
    (value % 99) as i32 + 1
}

pub(super) fn refine_weapon_required(item: &ItemState) -> i32 {
    refine_template_for_key(&item.key)
        .map(|template| i32::from(template.required_amount))
        .unwrap_or(0)
}

pub(super) fn refine_weapon_added_stat_sum(item: &ItemState) -> i32 {
    let added = |stat: u8| -> i32 {
        item.added_stats
            .iter()
            .filter(|entry| entry.stat == stat)
            .map(|entry| entry.value)
            .sum()
    };
    item.added_attack
        + added(CRYSTAL_STAT_MAX_DC)
        + added(CRYSTAL_STAT_MAX_MC)
        + added(CRYSTAL_STAT_MAX_SC)
}

pub(super) fn refine_weapon_luck(item: &ItemState) -> i32 {
    item.added_stats
        .iter()
        .filter(|entry| entry.stat == CRYSTAL_STAT_LUCK)
        .map(|entry| entry.value)
        .sum()
}

pub(super) fn refine_is_weapon(item: &ItemState) -> bool {
    refine_template_for_key(&item.key)
        .map(|template| template.item_type == CRYSTAL_ITEM_TYPE_WEAPON)
        .unwrap_or(item.attack > 0 || item.added_attack > 0)
}

pub(super) fn apply_refine_success(item: &mut ItemState, stat: u8, amount: i32) {
    if stat == CRYSTAL_STAT_MAX_DC {
        item.added_attack = item.added_attack.saturating_add(amount);
    } else if let Some(existing) = item.added_stats.iter_mut().find(|entry| entry.stat == stat) {
        existing.value = existing.value.saturating_add(amount);
    } else {
        item.added_stats.push(UserItemStat {
            stat,
            value: amount,
        });
    }
}

fn stage5_refine_item_packet(world: &mut World, unique_id: u64) -> Vec<ServerPacket> {
    super::refine_oven::start(world, unique_id)
}
fn stage5_check_refine_packet(world: &mut World, unique_id: u64) -> Vec<ServerPacket> {
    super::refine_oven::check(world, unique_id)
}

fn stage5_open_door_packet(world: &mut World, door_index: u8) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    // Conquest gate bookkeeping — siege gates a guild can toggle during war.
    push_unique_u8(
        &mut world
            .resource_mut::<Stage5SystemsResource>()
            .stage5_systems
            .conquest
            .open_gates,
        door_index,
    );
    // Drive the real door state machine: open the physical door, schedule its
    // 5s auto-close and unblock its cells (Crystal `Map.OpenDoor`).
    let mut packets = super::door::open_door(world, door_index);
    if packets.is_empty() {
        // No physical door with this index on the current map (e.g. a conquest
        // gate placeholder, or a map whose doors are not parsed here). Still
        // acknowledge the open so conquest gate handling matches Crystal.
        packets.push(ServerPacket::OpenDoor {
            door_index,
            close: false,
        });
    }
    packets
}

fn request_map_info_packet(world: &mut World, map_index: i32) -> Vec<ServerPacket> {
    if !is_in_world(world) || map_index <= 0 {
        return Vec::new();
    }

    let Some(info) = client_map_info(map_index) else {
        return Vec::new();
    };

    if !world.contains_resource::<BigMapConnectionState>() {
        world.insert_resource(BigMapConnectionState::default());
    }

    let (send_setup, send_map_info) = {
        let mut state = world.resource_mut::<BigMapConnectionState>();
        let send_setup = !state.world_map_setup_sent;
        state.world_map_setup_sent = true;
        let send_map_info = state.sent_map_indexes.insert(map_index);
        (send_setup, send_map_info)
    };

    let mut packets = Vec::with_capacity(2);
    if send_setup {
        packets.push(ServerPacket::WorldMapSetup {
            setup: world_map_setup(),
            teleport_to_npc_cost: teleport_to_npc_cost(),
        });
    }
    if send_map_info {
        packets.push(ServerPacket::NewMapInfo { map_index, info });
    }
    packets
}

fn search_map_packets(world: &mut World, text: &str) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }

    let Ok(hit) = search_big_map(text) else {
        return Vec::new();
    };

    let Some(hit) = hit else {
        return vec![ServerPacket::SearchMapResult {
            map_index: -1,
            npc_index: 0,
        }];
    };

    let (map_index, npc_index) = match hit {
        SearchMapHit::Map { map_index } => (map_index, 0),
        SearchMapHit::Npc {
            map_index,
            object_id,
        } => (map_index, object_id),
    };
    let mut packets = request_map_info_packet(world, map_index);
    packets.push(ServerPacket::SearchMapResult {
        map_index,
        npc_index,
    });
    packets
}

fn teleport_to_npc_packets(world: &World, object_id: u32) -> Vec<ServerPacket> {
    if !is_in_world(world) || object_id == 0 {
        return Vec::new();
    }

    // Crystal silently rejects an unknown/ineligible NPC, insufficient gold,
    // or an invalid destination. The imported WorldMap.ini is disabled and the
    // authoritative NPC catalog has zero CanTeleportTo entries. BM-BE-01 must
    // therefore preserve transform and currency and emit no fabricated success.
    Vec::new()
}

fn request_monster_info_packet(monster_index: i32) -> Vec<ServerPacket> {
    let Some(monster) = crystal_monster_by_index(monster_index) else {
        return Vec::new();
    };
    vec![ServerPacket::NewMonsterInfo {
        info: MonsterInfo {
            object_id: 0,
            name: monster.name,
            name_colour_argb: -1,
            location: Point { x: 0, y: 0 },
            image: monster.image,
            direction: MirDirection::Down,
            effect: monster.effect,
            ai: monster.ai,
            light: monster.light,
            dead: false,
            skeleton: false,
            poison: 0,
            hidden: false,
            shock_time: 0,
            binding_shot_center: false,
            extra: false,
            extra_byte: 0,
            master_object_id: 0,
            rarity: if monster.is_boss { 1 } else { 0 },
            buffs: Vec::new(),
        },
    }]
}

fn request_npc_info_packet(world: &World, npc_index: i32) -> Vec<ServerPacket> {
    let Some(npc) = crystal_npc_info_manifest()
        .npcs
        .into_iter()
        .chain(mir2_game_data::periodic_quests::npc_templates())
        .find(|npc| npc.npc_index == npc_index)
    else {
        return Vec::new();
    };
    let mut quest_ids = npc.collect_quest_indexes;
    for quest_id in npc.finish_quest_indexes {
        if !quest_ids.contains(&quest_id) {
            quest_ids.push(quest_id);
        }
    }
    quest_ids = effective_quest_ids_for_npc(
        world,
        npc.loaded_object_id.unwrap_or(npc.npc_index.max(0) as u32),
        &quest_ids,
    );
    vec![ServerPacket::NewNpcInfo {
        info: NpcInfo {
            object_id: npc.loaded_object_id.unwrap_or(npc.npc_index.max(0) as u32),
            name: npc.name,
            name_colour_argb: -1,
            image: npc.image,
            colour_argb: -1,
            location: npc.location,
            direction: MirDirection::Down,
            quest_ids,
        },
    }]
}

fn stage5_lover_update_packet(world: &World) -> ServerPacket {
    let relationship = &world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .relationship;
    ServerPacket::LoverUpdate {
        name: relationship.partner_name.clone(),
        date_binary_datetime: relationship.married_date_binary_datetime,
        map_name: relationship.map_name.clone(),
        married_days: relationship.married_days,
    }
}

fn stage5_mentor_update_packet(world: &World) -> ServerPacket {
    let mentor = &world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .mentor;
    ServerPacket::MentorUpdate {
        name: mentor.name.clone(),
        level: mentor.level,
        online: mentor.online,
        mentee_exp: mentor.mentee_exp,
    }
}

fn stage5_marriage_request_packet(world: &mut World) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if !world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .relationship
        .partner_name
        .is_empty()
    {
        return vec![system_message_key(world, "server.YouAlreadyMarried")];
    }
    vec![system_message_key(
        world,
        "server.FacePlayerForMarriageRequest",
    )]
}

fn stage5_marriage_reply_packet(world: &mut World, accept_invite: bool) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let pending = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .relationship
        .pending_request_from
        .clone();
    let Some(partner_name) = pending else {
        return Vec::new();
    };
    if !accept_invite {
        world
            .resource_mut::<Stage5SystemsResource>()
            .stage5_systems
            .relationship
            .pending_request_from = None;
        return Vec::new();
    }
    let map_name = world
        .resource::<MapRuntimeResource>()
        .current_map
        .title
        .clone();
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let relationship = &mut stage5.stage5_systems.relationship;
        relationship.partner_name = partner_name;
        relationship.map_name = map_name;
        relationship.married_date_binary_datetime = storage_password_binary_datetime();
        relationship.married_days = 0;
        relationship.pending_request_from = None;
    }
    vec![stage5_lover_update_packet(world)]
}

fn stage5_change_marriage_packet(world: &mut World) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let allow = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let relationship = &mut stage5.stage5_systems.relationship;
        relationship.allow_marriage = !relationship.allow_marriage;
        relationship.allow_marriage
    };
    vec![system_message_key(
        world,
        if allow {
            "server.YouAllowMarriageRequests"
        } else {
            "server.YouBlockMarriageRequests"
        },
    )]
}

fn stage5_divorce_request_packet(world: &mut World) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let partner_name = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .relationship
        .partner_name
        .clone();
    if partner_name.is_empty() {
        return vec![system_message_key(world, "server.YouNotMarried")];
    }
    vec![ServerPacket::DivorceRequest { name: partner_name }]
}

fn stage5_divorce_reply_packet(world: &mut World, accept_invite: bool) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if !accept_invite {
        return Vec::new();
    }
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let relationship = &mut stage5.stage5_systems.relationship;
        relationship.partner_name.clear();
        relationship.map_name.clear();
        relationship.married_days = 0;
        relationship.married_date_binary_datetime = storage_password_binary_datetime();
        relationship.pending_request_from = None;
        relationship.pending_divorce_from = None;
    }
    vec![stage5_lover_update_packet(world)]
}

fn stage5_add_mentor_packet(world: &mut World, name: String) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let player_name = stage5_player_name(world);
    if name.eq_ignore_ascii_case(&player_name) {
        return vec![system_message_key(world, "server.YouCantMentorYourself")];
    }
    if name.trim().is_empty() {
        return vec![system_message_key_args(
            world,
            "server.CannotFindPlayerByName",
            [name],
        )];
    }
    let current_mentor = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .mentor
        .name
        .clone();
    if !current_mentor.is_empty() {
        return vec![system_message_key(world, "server.YouAlreadyHaveMentor")];
    }
    vec![system_message_key_args(
        world,
        "server.CannotFindPlayerByName",
        [name],
    )]
}

fn stage5_mentor_reply_packet(world: &mut World, accept_invite: bool) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let pending = {
        let mentor = &world
            .resource::<Stage5SystemsResource>()
            .stage5_systems
            .mentor;
        mentor
            .pending_request_from
            .clone()
            .map(|name| (name, mentor.pending_request_level))
    };
    let Some((name, level)) = pending else {
        return Vec::new();
    };
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let mentor = &mut stage5.stage5_systems.mentor;
        if accept_invite {
            mentor.name = name;
            mentor.level = level;
            mentor.online = true;
            mentor.mentee_exp = 0;
        }
        mentor.pending_request_from = None;
        mentor.pending_request_level = 0;
    }
    if accept_invite {
        vec![stage5_mentor_update_packet(world)]
    } else {
        Vec::new()
    }
}

fn stage5_allow_mentor_packet(world: &mut World) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let allow = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let mentor = &mut stage5.stage5_systems.mentor;
        mentor.allow_mentor = !mentor.allow_mentor;
        mentor.allow_mentor
    };
    vec![hint_chat_key(
        world,
        if allow {
            "server.AllowingMentorRequests"
        } else {
            "server.BlockingMentorRequests"
        },
    )]
}

fn stage5_cancel_mentor_packet(world: &mut World) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    let had_mentor = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let mentor = &mut stage5.stage5_systems.mentor;
        let had_mentor = !mentor.name.is_empty();
        mentor.name.clear();
        mentor.level = 0;
        mentor.online = false;
        mentor.mentee_exp = 0;
        mentor.pending_request_from = None;
        mentor.pending_request_level = 0;
        had_mentor
    };
    if had_mentor {
        vec![
            system_message_key_args(world, "server.YouHaveMentorshipCooldown", ["7"]),
            stage5_mentor_update_packet(world),
        ]
    } else {
        vec![system_message_key(world, "server.NoMentorship")]
    }
}

pub(super) fn stage5_trade_request_packet(
    world: &mut World,
    partner_name: Option<String>,
) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .trade
        .is_some()
    {
        return Vec::new();
    }
    let partner = partner_name.unwrap_or_else(|| "Trader".to_string());
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .trade = Some(Stage5TradeState {
        settlement_nonce: new_stage5_mail_delivery_nonce(),
        partner: partner.clone(),
        offered_items: Vec::new(),
        offered_slots: BTreeMap::new(),
        offered_unique_ids: BTreeMap::new(),
        offered_gold: 0,
        held_gold: Some(0),
        offered_currency: crate::config::CurrencyKind::Gold,
        accepted: false,
        locked: false,
        escrow_prepared: false,
        completed: false,
    });
    vec![ServerPacket::TradeRequest { name: partner }]
}

fn stage5_trade_reply_packet(world: &mut World, accept_invite: bool) -> Vec<ServerPacket> {
    if !is_in_world(world) {
        return Vec::new();
    }
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .trade
        .as_ref()
        .is_some_and(Stage5TradeState::outgoing_escrow_debited)
    {
        // Only the shared settlement/rollback owner may release held assets.
        return Vec::new();
    }
    if !accept_invite {
        return stage5_trade_cancel_packet(world);
    }
    let partner = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let trade = stage5
            .stage5_systems
            .trade
            .get_or_insert_with(|| Stage5TradeState {
                settlement_nonce: new_stage5_mail_delivery_nonce(),
                partner: "Trader".to_string(),
                offered_items: Vec::new(),
                offered_slots: BTreeMap::new(),
                offered_unique_ids: BTreeMap::new(),
                offered_gold: 0,
                held_gold: Some(0),
                offered_currency: crate::config::CurrencyKind::Gold,
                accepted: false,
                locked: false,
                escrow_prepared: false,
                completed: false,
            });
        trade.partner.clone()
    };
    vec![ServerPacket::TradeAccept { name: partner }]
}

fn stage5_trade_gold_packet(world: &mut World, amount: u32) -> Vec<ServerPacket> {
    let available = world.resource::<PlayerRuntimeResource>().gold;
    let next = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let Some(trade) = stage5.stage5_systems.trade.as_mut() else {
            return Vec::new();
        };
        if trade.outgoing_escrow_debited() {
            return Vec::new();
        }
        // Crystal unlocks before validating even an invalid amount. Shared
        // coordination clears the partner's confirmation separately.
        trade.accepted = false;
        trade.locked = false;
        let Some(held) = trade.validated_held_gold() else {
            return Vec::new();
        };
        if trade.offered_currency != crate::config::CurrencyKind::Gold
            || amount == 0
            || available < amount
        {
            return Vec::new();
        }
        let (Some(offered), Some(held)) = (
            trade.offered_gold.checked_add(amount),
            held.checked_add(amount),
        ) else {
            return Vec::new();
        };
        trade.offered_gold = offered;
        trade.held_gold = Some(held);
        offered
    };
    world.resource_mut::<PlayerRuntimeResource>().gold = available - amount;
    vec![
        ServerPacket::LoseGold { gold: amount },
        ServerPacket::TradeGold { amount: next },
    ]
}

fn stage5_deposit_trade_item_packet(world: &mut World, from: i32, to: i32) -> Vec<ServerPacket> {
    let (Some(from_slot), Some(to_slot)) = (u8::try_from(from).ok(), u8::try_from(to).ok()) else {
        return vec![ServerPacket::DepositTradeItem {
            from,
            to,
            success: false,
        }];
    };
    let (item_key, item_unique) = {
        let inventory = world.resource::<InventoryResource>();
        let Some(item) = inventory
            .inventory_items
            .iter()
            .find(|item| inventory_item_matches_index(item, from_slot))
        else {
            return vec![ServerPacket::DepositTradeItem {
                from,
                to,
                success: false,
            }];
        };
        if !stage5_trade_item_can_enter(item) {
            return vec![ServerPacket::DepositTradeItem {
                from,
                to,
                success: false,
            }];
        }
        (item.key.clone(), item_unique_id(item))
    };
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let Some(trade) = stage5.stage5_systems.trade.as_mut() else {
            return vec![ServerPacket::DepositTradeItem {
                from,
                to,
                success: false,
            }];
        };
        if trade.outgoing_escrow_debited()
            || trade.locked
            || usize::from(to_slot) >= STAGE5_TRADE_SLOT_COUNT
            || trade.offered_slots.contains_key(&to_slot)
            || trade.offered_slots.values().any(|slot| *slot == from_slot)
        {
            return vec![ServerPacket::DepositTradeItem {
                from,
                to,
                success: false,
            }];
        }
        trade.offered_slots.insert(to_slot, from_slot);
        trade.offered_unique_ids.insert(to_slot, item_unique);
        push_unique(&mut trade.offered_items, item_key);
        trade.accepted = false;
    }
    vec![
        ServerPacket::DepositTradeItem {
            from,
            to,
            success: true,
        },
        ServerPacket::TradeItem {
            trade_items: stage5_trade_items(world),
        },
    ]
}

/// Retained bag offers must never be addressable as ordinary inventory edits.
pub(super) fn stage5_trade_reserves_item(world: &World, item: &ItemState) -> bool {
    world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .trade
        .as_ref()
        .is_some_and(|trade| {
            trade
                .offered_slots
                .values()
                .any(|slot| inventory_item_matches_index(item, *slot))
                || trade
                    .offered_unique_ids
                    .values()
                    .any(|id| *id == item_unique_id(item))
        })
}

fn stage5_valid_editable_trade(world: &World) -> Option<Stage5TradeState> {
    let trade = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .trade
        .as_ref()?;
    if trade.locked
        || trade.outgoing_escrow_debited()
        || trade.offered_slots.len() != trade.offered_unique_ids.len()
    {
        return None;
    }
    let inventory = world.resource::<InventoryResource>();
    let mut seen_slots = BTreeSet::new();
    let mut seen_ids = BTreeSet::new();
    for (trade_slot, bag_slot) in &trade.offered_slots {
        let id = *trade.offered_unique_ids.get(trade_slot)?;
        if usize::from(*trade_slot) >= STAGE5_TRADE_SLOT_COUNT
            || !is_valid_inventory_slot(*bag_slot, inventory.inventory_capacity)
            || !seen_slots.insert(*bag_slot)
            || !seen_ids.insert(id)
        {
            return None;
        }
        let mut matches = inventory
            .inventory_items
            .iter()
            .filter(|item| item_unique_id(item) == id);
        let item = matches.next()?;
        if matches.next().is_some() || !inventory_item_matches_index(item, *bag_slot) {
            return None;
        }
    }
    Some(trade.clone())
}

pub(super) fn stage5_move_trade_item_packet(
    world: &mut World,
    from: i32,
    to: i32,
) -> Vec<ServerPacket> {
    let failed = ServerPacket::MoveItem {
        grid: MirGridType::Trade,
        from,
        to,
        success: false,
    };
    let (Ok(from_slot), Ok(to_slot)) = (u8::try_from(from), u8::try_from(to)) else {
        return vec![failed];
    };
    if usize::from(from_slot) >= STAGE5_TRADE_SLOT_COUNT
        || usize::from(to_slot) >= STAGE5_TRADE_SLOT_COUNT
    {
        return vec![failed];
    }
    let Some(mut trade) = stage5_valid_editable_trade(world) else {
        return vec![failed];
    };
    let Some(source) = trade.offered_slots.get(&from_slot).copied() else {
        return vec![failed];
    };
    let source_id = trade.offered_unique_ids[&from_slot];
    if from_slot != to_slot {
        let target = trade.offered_slots.remove(&to_slot);
        let target_id = trade.offered_unique_ids.remove(&to_slot);
        trade.offered_slots.remove(&from_slot);
        trade.offered_unique_ids.remove(&from_slot);
        trade.offered_slots.insert(to_slot, source);
        trade.offered_unique_ids.insert(to_slot, source_id);
        if let (Some(target), Some(target_id)) = (target, target_id) {
            trade.offered_slots.insert(from_slot, target);
            trade.offered_unique_ids.insert(from_slot, target_id);
        }
    }
    trade.accepted = false;
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .trade = Some(trade);
    vec![
        ServerPacket::MoveItem {
            grid: MirGridType::Trade,
            from,
            to,
            success: true,
        },
        ServerPacket::TradeItem {
            trade_items: stage5_trade_items(world),
        },
    ]
}

/// Trade stack merging is an explicit extension: Crystal's client exposes the
/// intent, while its original server rejects Trade grids in MergeItem.
pub(super) fn stage5_merge_trade_item_packet(
    world: &mut World,
    grid_from: MirGridType,
    grid_to: MirGridType,
    id_from: u64,
    id_to: u64,
) -> Vec<ServerPacket> {
    let failed = ServerPacket::MergeItem {
        grid_from,
        grid_to,
        id_from,
        id_to,
        success: false,
    };
    if id_from == id_to
        || !matches!(grid_from, MirGridType::Inventory | MirGridType::Trade)
        || !matches!(grid_to, MirGridType::Inventory | MirGridType::Trade)
    {
        return vec![failed];
    }
    let Some(mut trade) = stage5_valid_editable_trade(world) else {
        return vec![failed];
    };
    let inventory = world.resource::<InventoryResource>();
    let resolve = |id, grid| {
        let mut matching = inventory
            .inventory_items
            .iter()
            .enumerate()
            .filter(|(_, item)| item_unique_id(item) == id);
        let (index, item) = matching.next()?;
        if matching.next().is_some() {
            return None;
        }
        let bag_slot = inventory_index_for_item(item)?;
        if !is_valid_inventory_slot(bag_slot, inventory.inventory_capacity) {
            return None;
        }
        let offered = trade
            .offered_unique_ids
            .iter()
            .find_map(|(slot, offered)| (*offered == id).then_some(*slot));
        if (grid == MirGridType::Trade) != offered.is_some() {
            return None;
        }
        Some((index, offered))
    };
    let (Some((from_index, source_offer)), Some((to_index, _))) =
        (resolve(id_from, grid_from), resolve(id_to, grid_to))
    else {
        return vec![failed];
    };
    let source = &inventory.inventory_items[from_index];
    let target = &inventory.inventory_items[to_index];
    if !stage5_trade_item_can_enter(source)
        || !stage5_trade_item_can_enter(target)
        || !item_stack_identity_compatible(source, target)
    {
        return vec![failed];
    }
    let max = crystal_stack_size_for_item_key(&target.key);
    if max <= 1 || target.quantity >= max || source.quantity == 0 {
        return vec![failed];
    }
    let moved = source.quantity.min(max - target.quantity);
    let consumed = moved == source.quantity;
    let mut items = inventory.inventory_items.clone();
    items[to_index].quantity += moved;
    if consumed {
        items.remove(from_index);
    } else {
        items[from_index].quantity -= moved;
    }
    if consumed {
        if let Some(slot) = source_offer {
            trade.offered_slots.remove(&slot);
            trade.offered_unique_ids.remove(&slot);
        }
    }
    trade.accepted = false;
    trade.offered_items = trade
        .offered_slots
        .values()
        .filter_map(|slot| {
            items
                .iter()
                .find(|item| inventory_item_matches_index(item, *slot))
                .map(|item| item.key.clone())
        })
        .collect::<BTreeSet<_>>()
        .into_iter()
        .collect();
    world.resource_mut::<InventoryResource>().inventory_items = items;
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .trade = Some(trade);
    vec![
        ServerPacket::MergeItem {
            grid_from,
            grid_to,
            id_from,
            id_to,
            success: true,
        },
        ServerPacket::TradeItem {
            trade_items: stage5_trade_items(world),
        },
    ]
}

fn stage5_retrieve_trade_item_packet(world: &mut World, from: i32, to: i32) -> Vec<ServerPacket> {
    let failed = ServerPacket::RetrieveTradeItem {
        from,
        to,
        success: false,
    };
    let (Ok(from_slot), Ok(to_slot)) = (u8::try_from(from), u8::try_from(to)) else {
        return vec![failed];
    };
    let (source_slot, source_unique_id) = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        let Some(trade) = stage5.stage5_systems.trade.as_ref() else {
            return vec![failed];
        };
        if trade.outgoing_escrow_debited()
            || trade.locked
            || usize::from(from_slot) >= STAGE5_TRADE_SLOT_COUNT
        {
            return vec![failed];
        }
        let (Some(source_slot), Some(source_unique_id)) = (
            trade.offered_slots.get(&from_slot),
            trade.offered_unique_ids.get(&from_slot),
        ) else {
            return vec![failed];
        };
        (*source_slot, *source_unique_id)
    };
    // Offers retain their inventory instance until preparation. Validate both
    // its identity and the normalized bag destination before releasing it.
    let source_index = {
        let inventory = world.resource::<InventoryResource>();
        if !is_valid_inventory_slot(to_slot, inventory.inventory_capacity) {
            return vec![failed];
        }
        let Some(source_index) = inventory.inventory_items.iter().position(|item| {
            inventory_item_matches_index(item, source_slot)
                && item_unique_id(item) == source_unique_id
        }) else {
            return vec![failed];
        };
        if inventory
            .inventory_items
            .iter()
            .enumerate()
            .any(|(index, item)| {
                index != source_index && inventory_item_matches_index(item, to_slot)
            })
        {
            return vec![failed];
        }
        source_index
    };
    let (container, slot) = inventory_container_and_slot_for_index(to_slot)
        .expect("validated normalized bag destination");
    let mut item = world.resource::<InventoryResource>().inventory_items[source_index].clone();
    // Legacy zero IDs fall back to the current slot. Capture the existing wire
    // identity before moving, including a real zero ID from bag slot zero.
    if item.unique_id == 0 && item.user_item_metadata.is_none() {
        let Ok(wire) = try_user_item_from_item_state(&item) else {
            return vec![failed];
        };
        let Ok(captured) = super::items::try_item_state_from_user_item(item.clone(), &wire) else {
            return vec![failed];
        };
        item.unique_id = source_unique_id;
        item.user_item_metadata = captured.user_item_metadata;
    }
    item.container = container;
    item.slot = slot;
    world.resource_mut::<InventoryResource>().inventory_items[source_index] = item;
    let offered_slots = {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let trade = stage5
            .stage5_systems
            .trade
            .as_mut()
            .expect("validated trade");
        trade.offered_slots.remove(&from_slot);
        trade.offered_unique_ids.remove(&from_slot);
        trade.accepted = false;
        trade.offered_slots.clone()
    };
    let offered_items = stage5_trade_item_keys_for_slots(world, &offered_slots);
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .trade
        .as_mut()
        .expect("validated trade")
        .offered_items = offered_items;
    vec![
        ServerPacket::RetrieveTradeItem {
            from,
            to,
            success: true,
        },
        ServerPacket::TradeItem {
            trade_items: stage5_trade_items(world),
        },
    ]
}

pub(super) fn stage5_trade_confirm_packet(world: &mut World, locked: bool) -> Vec<ServerPacket> {
    if world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .trade
        .as_ref()
        .is_some_and(Stage5TradeState::outgoing_escrow_debited)
    {
        return Vec::new();
    }
    if !locked {
        if let Some(trade) = world
            .resource_mut::<Stage5SystemsResource>()
            .stage5_systems
            .trade
            .as_mut()
        {
            trade.accepted = false;
            trade.locked = false;
        }
        return vec![ServerPacket::TradeCancel { unlock: true }];
    }

    if let Err(packets) = validate_trade_confirmation(world) {
        return packets;
    }
    let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
    if let Some(trade) = stage5.stage5_systems.trade.as_mut() {
        trade.accepted = true;
        trade.locked = true;
    }
    // Crystal PlayerObject.TradeConfirm: one participant's lock is not a
    // completed exchange. Only the shared settlement owner can finish it.
    Vec::new()
}

pub(super) enum SharedTradePreparation {
    Prepared(Vec<ServerPacket>),
    Rejected(Vec<ServerPacket>),
}

/// Reserve an already identified offer for the shared settlement coordinator.
/// The typed outcome is internal; S.TradeConfirm is never a preparation ACK.
pub(super) fn prepare_shared_trade_escrow(world: &mut World) -> SharedTradePreparation {
    if let Err(packets) = validate_trade_confirmation(world) {
        return SharedTradePreparation::Rejected(packets);
    }
    let (offered_gold, offered_indices) = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        let trade = stage5
            .stage5_systems
            .trade
            .as_ref()
            .expect("validated trade");
        (
            trade.offered_gold - trade.validated_held_gold().expect("validated gold custody"),
            trade
                .offered_slots
                .values()
                .copied()
                .collect::<BTreeSet<_>>(),
        )
    };
    if offered_gold > 0 {
        world.resource_mut::<PlayerRuntimeResource>().gold -= offered_gold;
    }
    world
        .resource_mut::<InventoryResource>()
        .inventory_items
        .retain(|item| {
            inventory_index_for_item(item).is_none_or(|index| !offered_indices.contains(&index))
        });
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let trade = stage5
            .stage5_systems
            .trade
            .as_mut()
            .expect("validated trade");
        trade.accepted = true;
        trade.locked = true;
        trade.held_gold = Some(trade.offered_gold);
        trade.escrow_prepared = true;
        trade.completed = false;
    }
    let packets = if offered_gold > 0 {
        vec![ServerPacket::LoseGold { gold: offered_gold }]
    } else {
        Vec::new()
    };
    SharedTradePreparation::Prepared(packets)
}

pub(super) fn validate_trade_confirmation(world: &mut World) -> Result<(), Vec<ServerPacket>> {
    let (offered_gold, offered_slots, offered_unique_ids) = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        let Some(trade) = stage5.stage5_systems.trade.as_ref() else {
            return Err(Vec::new());
        };
        if trade.outgoing_escrow_debited()
            || trade.offered_currency != crate::config::CurrencyKind::Gold
            || trade.offered_slots.len() > STAGE5_TRADE_SLOT_COUNT
            || trade.offered_unique_ids.len() != trade.offered_slots.len()
            || trade
                .offered_slots
                .keys()
                .any(|slot| usize::from(*slot) >= STAGE5_TRADE_SLOT_COUNT)
            || trade
                .offered_slots
                .values()
                .copied()
                .collect::<BTreeSet<_>>()
                .len()
                != trade.offered_slots.len()
        {
            return Err(Vec::new());
        }
        (
            match trade.validated_held_gold() {
                Some(held) => trade.offered_gold - held,
                None => return Err(Vec::new()),
            },
            trade.offered_slots.clone(),
            trade.offered_unique_ids.clone(),
        )
    };
    if world.resource::<PlayerRuntimeResource>().gold < offered_gold {
        return Err(Vec::new());
    }
    let offer_tampered = {
        let inventory = world.resource::<InventoryResource>();
        let mut tampered = false;
        for (trade_slot, inventory_index) in offered_slots.iter() {
            let Some(item) = inventory
                .inventory_items
                .iter()
                .find(|item| inventory_item_matches_index(item, *inventory_index))
            else {
                return Err(Vec::new());
            };
            if !stage5_trade_item_can_enter(item) {
                return Err(Vec::new());
            }
            // Integrity check (F-07): the item still occupying the offered slot's
            // inventory index must be the exact item deposited there. If a
            // different item was swapped in afterwards, the offer no longer
            // matches what the partner agreed to.
            if offered_unique_ids.get(trade_slot).copied() != Some(item_unique_id(item)) {
                tampered = true;
                break;
            }
        }
        tampered
    };
    if offer_tampered {
        return Err(stage5_trade_abort_on_tampered_offer(world));
    }
    Ok(())
}

/// Abort a trade whose offered items were tampered with after deposit (F-07).
/// No items or gold change hands: the trade is unlocked/cancelled so the partner
/// is never delivered an item that was swapped in behind the agreed offer.
fn stage5_trade_abort_on_tampered_offer(world: &mut World) -> Vec<ServerPacket> {
    let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
    if let Some(trade) = stage5.stage5_systems.trade.as_mut() {
        trade.accepted = false;
        trade.locked = false;
    }
    vec![ServerPacket::TradeCancel { unlock: true }]
}

pub(super) fn stage5_trade_cancel_packet(world: &mut World) -> Vec<ServerPacket> {
    let held = {
        let stage5 = world.resource::<Stage5SystemsResource>();
        let Some(trade) = stage5.stage5_systems.trade.as_ref() else {
            return Vec::new();
        };
        if trade.outgoing_escrow_debited() {
            return Vec::new();
        }
        let Some(held) = trade.validated_held_gold() else {
            return Vec::new();
        };
        held
    };
    let Some(refunded) = world
        .resource::<PlayerRuntimeResource>()
        .gold
        .checked_add(held)
    else {
        return Vec::new();
    };
    world.resource_mut::<PlayerRuntimeResource>().gold = refunded;
    world
        .resource_mut::<Stage5SystemsResource>()
        .stage5_systems
        .trade = None;
    let mut packets = Vec::new();
    if held > 0 {
        packets.push(ServerPacket::GainedGold { gold: held });
    }
    packets.push(ServerPacket::TradeCancel { unlock: false });
    packets
}

pub(super) fn stage5_intelligent_creature_list_packet(world: &World) -> ServerPacket {
    let creatures = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .intelligent_creatures
        .clone();
    let summoned_creature_type = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .active_intelligent_creature()
        .map(|creature| creature.pet_type)
        .unwrap_or(99);
    ServerPacket::UpdateIntelligentCreatureList {
        creature_list: creatures,
        creature_summoned: summoned_creature_type != 99,
        summoned_creature_type,
        pearl_count: world
            .resource::<Stage5SystemsResource>()
            .stage5_systems
            .intelligent_creature_pearls,
    }
}

fn stage5_update_intelligent_creature_packet(
    world: &mut World,
    creature: ClientIntelligentCreature,
    summon_me: bool,
    unsummon_me: bool,
    release_me: bool,
) -> Vec<ServerPacket> {
    if strict_active_account_authorization(world).is_none() {
        return Vec::new();
    }
    let dead = current_player_is_dead(world);
    let summon_prohibited = super::map::current_map_disallows_intelligent_creatures(world);
    {
        let mut stage5 = world.resource_mut::<Stage5SystemsResource>();
        let systems = &mut stage5.stage5_systems;
        // PetType identifies ownership in Crystal; SlotIndex is an editable
        // position in the client's ten-slot creature panel, never identity.
        let Some(index) = systems
            .intelligent_creatures
            .iter()
            .position(|owned| owned.pet_type <= 14 && owned.pet_type == creature.pet_type)
        else {
            drop(stage5);
            return vec![stage5_intelligent_creature_list_packet(world)];
        };
        if !(0..10).contains(&creature.slot_index) {
            drop(stage5);
            return vec![stage5_intelligent_creature_list_packet(world)];
        }
        systems.migrate_legacy_intelligent_creature_state();
        // Crystal's action flags have precedence over preference edits.
        if release_me {
            systems.intelligent_creatures.remove(index);
            if systems.summoned_intelligent_creature_type == Some(creature.pet_type) {
                systems.summoned_intelligent_creature_type = Some(99);
            }
            for (slot, owned) in systems.intelligent_creatures.iter_mut().enumerate() {
                owned.slot_index = slot as i32;
            }
        } else if summon_me {
            if !dead && !summon_prohibited && systems.active_intelligent_creature().is_none() {
                systems.summoned_intelligent_creature_type = Some(creature.pet_type);
            }
        } else if unsummon_me {
            if systems.summoned_intelligent_creature_type == Some(creature.pet_type) {
                systems.summoned_intelligent_creature_type = Some(99);
            }
        } else {
            // Crystal updates only the addressed PetType. Do not implicitly
            // swap another pet: paired layout packets may have a shared-slot
            // intermediate state before the second update arrives.
            let owned = &mut systems.intelligent_creatures[index];
            owned.slot_index = creature.slot_index;
            if (3..=15).contains(&creature.custom_name.len())
                && creature
                    .custom_name
                    .bytes()
                    .all(|byte| byte.is_ascii_alphanumeric())
            {
                owned.custom_name = creature.custom_name;
            }
            owned.filter = creature.filter;
            if creature.pet_mode <= 1 {
                owned.pet_mode = creature.pet_mode;
            }
            if creature.pickup_grade <= 5 {
                owned.pickup_grade = creature.pickup_grade;
            }
            // Type/icon, fullness, expiry, production/food timers and rules
            // remain exclusively server-owned.
        }
    }
    vec![stage5_intelligent_creature_list_packet(world)]
}
#[allow(deprecated)]
pub(super) fn stage5_intelligent_creature_pickup_packet(
    world: &mut World,
    location: Point,
    mouse_mode: Option<bool>,
) -> Vec<ServerPacket> {
    let Some(active_creature) = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .active_intelligent_creature()
    else {
        return Vec::new();
    };
    if active_creature.fullness < active_creature.creature_rules.minimal_fullness.max(0) {
        return Vec::new();
    }
    let Some(player) = player_entity(world) else {
        return Vec::new();
    };
    let picker_object_id = entity_object_id(world, player).expect("player object id");
    let player_position = entity_position(world, player).unwrap_or(location.clone());
    let target_location = match mouse_mode {
        Some(true) => {
            if !active_creature.creature_rules.mouse_pickup_enabled {
                return Vec::new();
            }
            let max_range = active_creature
                .creature_rules
                .mouse_pickup_range
                .clamp(0, 16) as u32;
            if player_position
                .x
                .abs_diff(location.x)
                .max(player_position.y.abs_diff(location.y))
                > max_range
            {
                return Vec::new();
            }
            location
        }
        Some(false) => {
            if !active_creature.creature_rules.semi_auto_pickup_enabled
                || active_creature.pet_mode != 1
            {
                return Vec::new();
            }
            player_position
        }
        None => location,
    };
    let Some((object_id, drop_entity)) = world
        .iter_entities()
        .filter_map(|entity| {
            if entity.get::<GroundDrop>().is_none() {
                return None;
            }
            let object_id = entity.get::<ObjectId>()?.0;
            let position = entity.get::<Position>()?.0.clone();
            (position == target_location).then_some((object_id, entity.id()))
        })
        .min_by_key(|(object_id, _)| *object_id)
    else {
        return Vec::new();
    };
    if !drop_ownership_allows_pickup(world, drop_entity, picker_object_id) {
        return vec![system_message_key(world, "server.CannotPickupNotOwner")];
    }
    let payload = {
        let entity = world.entity(drop_entity);
        entity.get::<DropPayload>().expect("drop payload").clone()
    };
    if !stage5_intelligent_creature_filter_allows_drop(active_creature, &payload) {
        return Vec::new();
    }
    let mut packets = vec![ServerPacket::IntelligentCreaturePickup { object_id }];
    match payload.loot {
        DropLoot::Gold(amount) => {
            if !can_gain_gold(world.resource::<PlayerRuntimeResource>(), amount) {
                return Vec::new();
            }
            world.resource_mut::<PlayerRuntimeResource>().gold += amount;
            let _ = world.despawn(drop_entity);
            packets.push(ServerPacket::GainedGold { gold: amount });
        }
        DropLoot::InventoryItem {
            key,
            name,
            description,
            weight,
            durability_current,
            durability_max,
            added_attack,
            added_defence,
            added_stats,
            cursed,
            socket_slots,
            ..
        } => {
            {
                let resources = world.resource::<InventoryResource>();
                if !can_gain_item_quantity(&resources, ItemContainer::Bag1, &key, payload.quantity)
                {
                    return Vec::new();
                }
            }
            let gained_item = add_or_increment_item_with_random_metadata(
                world,
                ItemContainer::Bag1,
                &key,
                &name,
                &description,
                8,
                payload.quantity,
                weight,
                durability_current,
                durability_max,
                added_attack,
                added_defence,
                added_stats,
                cursed,
                socket_slots,
            );
            let _ = world.despawn(drop_entity);
            packets.push(ServerPacket::GainedItem {
                item: user_item_from_item_state(&gained_item),
            });
        }
    }
    packets
}

pub(super) fn tick_stage5_intelligent_creature_maintenance(
    world: &mut World,
    tick: u64,
    packets: &mut Vec<ServerPacket>,
) {
    if !is_in_world(world) {
        return;
    }
    tick_stage5_guild_wars(world, tick, packets);
    super::intelligent_creatures::maintenance(world, packets);
}

pub(super) fn tick_stage5_intelligent_creatures(
    world: &mut World,
    tick: u64,
    packets: &mut Vec<ServerPacket>,
) {
    tick_stage5_intelligent_creature_maintenance(world, tick, packets);
    if let Some(location) = stage5_intelligent_creature_auto_pickup_location(world) {
        packets.extend(stage5_intelligent_creature_pickup_packet(
            world, location, None,
        ));
    }
}

#[allow(deprecated)]
fn stage5_intelligent_creature_auto_pickup_location(world: &World) -> Option<Point> {
    let creature = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .active_intelligent_creature()
        .filter(|creature| {
            creature.pet_mode == 0
                && creature.creature_rules.auto_pickup_enabled
                && creature.fullness >= creature.creature_rules.minimal_fullness.max(0)
                && creature.creature_rules.auto_pickup_range > 0
        })?
        .clone();
    let player = player_entity(world)?;
    let picker_object_id = entity_object_id(world, player)?;
    let player_position = entity_position(world, player)?;
    let range = creature.creature_rules.auto_pickup_range;

    world
        .iter_entities()
        .filter_map(|entity| {
            if entity.get::<GroundDrop>().is_none() {
                return None;
            }
            let object_id = entity.get::<ObjectId>()?.0;
            let position = entity.get::<Position>()?.0.clone();
            let distance = (position.x - player_position.x)
                .abs()
                .max((position.y - player_position.y).abs());
            if distance > range {
                return None;
            }
            let payload = entity.get::<DropPayload>()?;
            if !stage5_intelligent_creature_filter_allows_drop(&creature, payload) {
                return None;
            }
            if !drop_ownership_allows_pickup(world, entity.id(), picker_object_id) {
                return None;
            }
            Some((distance, object_id, position))
        })
        .min_by_key(|(distance, object_id, _)| (*distance, *object_id))
        .map(|(_, _, position)| position)
}

fn stage5_intelligent_creature_filter_allows_drop(
    creature: &ClientIntelligentCreature,
    payload: &DropPayload,
) -> bool {
    match &payload.loot {
        DropLoot::Gold(_) => creature.filter.pet_pickup_all || creature.filter.pet_pickup_gold,
        DropLoot::InventoryItem { key, .. } => {
            if creature.pickup_grade > 0 {
                let drop_grade = crystal_item_grade_for_key(key);
                if drop_grade < creature.pickup_grade {
                    return false;
                }
            }
            if creature.filter.pet_pickup_all {
                return true;
            }
            let Some(template) = crystal_item_template_for_item_key(key) else {
                return creature.filter.pet_pickup_others;
            };
            match template.item_type {
                CRYSTAL_ITEM_TYPE_WEAPON => creature.filter.pet_pickup_weapons,
                CRYSTAL_ITEM_TYPE_ARMOUR => creature.filter.pet_pickup_armours,
                CRYSTAL_ITEM_TYPE_HELMET => creature.filter.pet_pickup_helmets,
                CRYSTAL_ITEM_TYPE_BOOTS => creature.filter.pet_pickup_boots,
                CRYSTAL_ITEM_TYPE_BELT => creature.filter.pet_pickup_belts,
                CRYSTAL_ITEM_TYPE_NECKLACE
                | CRYSTAL_ITEM_TYPE_BRACELET
                | CRYSTAL_ITEM_TYPE_RING => creature.filter.pet_pickup_accessories,
                _ => creature.filter.pet_pickup_others,
            }
        }
    }
}

pub(super) fn localized_map_title(language: LanguageCode, fallback: &str) -> String {
    match fallback {
        "Starter Field" | "Starter Zone" => {
            localized_text_or_fallback(language, "content.scene.starterField.title", fallback)
        }
        _ => fallback.to_string(),
    }
}

pub(super) fn localized_visible_player_name_key(object_id: u32) -> Option<&'static str> {
    match object_id {
        2001 => Some("content.visiblePlayer.mentor.name"),
        _ => None,
    }
}

pub(super) fn localized_monster_name_key(object_id: u32) -> Option<&'static str> {
    match object_id {
        3001 => Some("content.monster.trainingDummy.name"),
        3002 => Some("content.monster.fieldWasp.name"),
        _ => None,
    }
}

pub(super) fn localized_npc_name_key(object_id: u32) -> Option<&'static str> {
    match object_id {
        super::crystal_compat::GUIDE_NPC_ID => Some("content.npc.villageGuide.name"),
        _ => None,
    }
}

const CRYSTAL_CHAT_INTERVAL_MS: u64 = 2_000;
const CRYSTAL_CHAT_SPAM_TICKS_BEFORE_BAN: u8 = 5;
const CRYSTAL_CHAT_SPAM_BAN_MS: u64 = 5 * 60 * 1_000;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PreparedChatPacket {
    pub message: String,
    pub linked_items: Vec<ChatItem>,
    pub linked_user_items: Vec<UserItem>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum ChatPacketPreparation {
    Dispatch(PreparedChatPacket),
    Immediate(Vec<ServerPacket>),
}

pub(super) fn prepare_chat_packet(
    world: &mut World,
    message: String,
    linked_items: Vec<ChatItem>,
) -> ChatPacketPreparation {
    if !super::session::is_in_world(world) {
        return ChatPacketPreparation::Immediate(Vec::new());
    }

    if let Some(remaining_seconds) = active_chat_ban_remaining_seconds(world) {
        return ChatPacketPreparation::Immediate(vec![chat_ban_remaining_message(
            world,
            remaining_seconds,
        )]);
    }

    if message.is_empty() {
        return ChatPacketPreparation::Immediate(Vec::new());
    }

    if let Some(packet) = apply_crystal_chat_spam_guard(world) {
        return ChatPacketPreparation::Immediate(vec![packet]);
    }

    if message.trim().eq_ignore_ascii_case("@ADDSTORAGE") {
        return ChatPacketPreparation::Immediate(expand_storage_rental_impl(world));
    }

    ChatPacketPreparation::Dispatch(PreparedChatPacket {
        linked_user_items: chat_linked_user_items(world, &linked_items),
        message,
        linked_items,
    })
}

fn strict_active_account_authorization(
    world: &World,
) -> Option<(ActiveGmAuthorizationIdentity, u8)> {
    let session = world.resource::<SessionResource>();
    let account_id = active_session_mutating_account_id(session)?;
    let character = session.selected_character.as_ref()?;
    let identity = ActiveGmAuthorizationIdentity {
        account_id: account_id.clone(),
        character_index: character.index,
        character_name: character.name.clone(),
    };
    let config = world.resource::<RuntimeConfigResource>().config.clone();
    let stored_level =
        {
            let store = config.account_store.lock().ok()?;
            let account = store.accounts.get(&account_id)?;
            if !account.characters.iter().any(|candidate| {
                candidate.index == character.index && candidate.name == character.name
            }) {
                return None;
            }
            account.gm_level
        };
    let env_level = if crate::config::account_is_env_gm(&account_id) {
        1
    } else {
        0
    };
    Some((identity, stored_level.max(env_level)))
}

fn reset_account_derived_gm_runtime(gm: &mut GmRuntimeResource) {
    gm.login_pending = false;
    gm.gm_never_die = false;
    gm.game_master = false;
    gm.observer = false;
    gm.allow_guild_invite = true;
    gm.enable_group_recall = false;
    gm.allow_trade = true;
    gm.allow_observe = false;
    gm.pearls = 0;
    gm.light = 0;
    gm.transform_paused = false;
}

fn clear_account_derived_gm_permissions(world: &mut World) {
    world.resource_mut::<PlayerPermissionResource>().gm_level = 0;
    world.remove_resource::<AccountGmAuthorizationState>();
    reset_account_derived_gm_runtime(&mut world.resource_mut::<GmRuntimeResource>());
}

fn revalidate_cached_gm_authorization(world: &mut World) -> Option<ActiveGmAuthorizationIdentity> {
    let Some((identity, account_level)) = strict_active_account_authorization(world) else {
        clear_account_derived_gm_permissions(world);
        return None;
    };
    let identity_mismatch = world
        .get_resource::<AccountGmAuthorizationState>()
        .is_some_and(|state| {
            state
                .password_authorized_identity
                .as_ref()
                .is_some_and(|bound| bound != &identity)
                || state
                    .login_pending_identity
                    .as_ref()
                    .is_some_and(|bound| bound != &identity)
        });
    if identity_mismatch {
        clear_account_derived_gm_permissions(world);
        world.resource_mut::<PlayerPermissionResource>().gm_level = account_level;
        return Some(identity);
    }
    let password_level = world
        .get_resource::<AccountGmAuthorizationState>()
        .and_then(|state| state.password_authorized_identity.as_ref())
        .is_some_and(|bound| bound == &identity) as u8;
    let authorized_level = account_level.max(password_level);
    let cached_level = world.resource::<PlayerPermissionResource>().gm_level;
    if cached_level > authorized_level {
        reset_account_derived_gm_runtime(&mut world.resource_mut::<GmRuntimeResource>());
        if let Some(mut state) = world.get_resource_mut::<AccountGmAuthorizationState>() {
            state.login_pending_identity = None;
        }
    }
    world.resource_mut::<PlayerPermissionResource>().gm_level = authorized_level;
    Some(identity)
}

pub(super) fn trusted_npc_is_gm(world: &World) -> bool {
    let Some((identity,account_level))=strict_active_account_authorization(world) else { return false; };
    let bound_password=world.get_resource::<AccountGmAuthorizationState>()
        .and_then(|state| state.password_authorized_identity.as_ref()).is_some_and(|bound| bound == &identity);
    let cached=world.resource::<PlayerPermissionResource>().gm_level;
    // Require the already enabled, identity-bound command permission. An
    // account role, a pending password prompt, or a test-server flag alone
    // cannot turn an NPC condition into an administrator capability.
    cached > 0 && cached <= account_level.max(u8::from(bound_password))
}

fn gm_command_keyword(message: &str) -> Option<&str> {
    message
        .trim_start()
        .strip_prefix('@')?
        .split_whitespace()
        .next()
}

fn bind_gm_login_prompt(world: &mut World, identity: ActiveGmAuthorizationIdentity) {
    if let Some(mut state) = world.get_resource_mut::<AccountGmAuthorizationState>() {
        state.login_pending_identity = Some(identity);
    } else {
        world.insert_resource(AccountGmAuthorizationState {
            password_authorized_identity: None,
            login_pending_identity: Some(identity),
        });
    }
}

fn gm_login_prompt_matches(world: &World, identity: &ActiveGmAuthorizationIdentity) -> bool {
    world
        .get_resource::<AccountGmAuthorizationState>()
        .and_then(|state| state.login_pending_identity.as_ref())
        == Some(identity)
}

fn finish_gm_login_attempt(
    world: &mut World,
    identity: ActiveGmAuthorizationIdentity,
    granted: bool,
) {
    let mut state = world
        .get_resource_mut::<AccountGmAuthorizationState>()
        .expect("a validated GM login prompt should have an authorization binding");
    state.login_pending_identity = None;
    if granted {
        state.password_authorized_identity = Some(identity);
    }
}

pub(super) fn handle_chat_packet(
    world: &mut World,
    message: String,
    linked_items: Vec<ChatItem>,
) -> Vec<ServerPacket> {
    // `@LOGIN` arms a GM-password prompt; the very next chat line is the password
    // candidate (Crystal `PlayerObject.Chat`, GMLogin branch). It is checked
    // before everything else and consumed regardless of outcome.
    if super::gm_commands::gm_login_pending(world) {
        let Some((identity, _)) = strict_active_account_authorization(world) else {
            clear_account_derived_gm_permissions(world);
            return Vec::new();
        };
        if !gm_login_prompt_matches(world, &identity) {
            clear_account_derived_gm_permissions(world);
            return Vec::new();
        }
        let password_granted =
            world.resource::<GmRuntimeResource>().password.as_deref() == Some(message.as_str());
        let packets = super::gm_commands::resolve_gm_login_password(world, &message);
        finish_gm_login_attempt(world, identity, password_granted);
        let _ = revalidate_cached_gm_authorization(world);
        return packets;
    }

    // Crystal consumes EVERY `@`-prefixed line as a command attempt — it is never
    // echoed to normal chat — and gates each command individually (many, like
    // `@TIME`/`@MAP`/`@DIE`, run for any player). The dispatcher therefore always
    // claims `@` lines; a non-GM issuing a GM-gated command gets Crystal's silent
    // `return;`, so command existence still never leaks to ordinary players.
    if super::gm_commands::is_gm_command(&message) {
        let Some(identity) = revalidate_cached_gm_authorization(world) else {
            return Vec::new();
        };
        if gm_command_keyword(&message).is_some_and(|command| command.eq_ignore_ascii_case("LOGIN"))
        {
            bind_gm_login_prompt(world, identity);
        }
        if let Some(packets) = super::gm_commands::dispatch_gm_command(world, &message) {
            if let Some(name) = gm_command_keyword(&message).filter(|name| super::default_npc_events::is_custom_command(name)) {
                let _ = super::default_npc_events::enqueue(world,super::default_npc_events::DefaultNpcEvent::CustomCommand { name:name.to_string() });
            }
            return packets;
        }
    }

    let prepared = match prepare_chat_packet(world, message, linked_items) {
        ChatPacketPreparation::Dispatch(prepared) => prepared,
        ChatPacketPreparation::Immediate(packets) => return packets,
    };

    let player_name = world
        .resource::<SessionResource>()
        .selected_character
        .as_ref()
        .map(|character| character.name.clone())
        .unwrap_or_else(|| "?????".to_string());
    let message = chat_text_with_linked_items(&prepared.message, &prepared.linked_items);

    vec![ServerPacket::ObjectChat {
        object_id: current_player_object_id(world).unwrap_or(0),
        text: format!("{player_name}: {message}"),
        chat_type: mir2_protocol::ChatType::Normal,
    }]
}

fn apply_crystal_chat_spam_guard(world: &mut World) -> Option<ServerPacket> {
    let now = unix_now_ms();
    let mut player_runtime = world.resource_mut::<PlayerRuntimeResource>();
    if now < player_runtime.chat_next_allowed_at_ms {
        player_runtime.chat_spam_tick = player_runtime.chat_spam_tick.saturating_add(1);
        if player_runtime.chat_spam_tick >= CRYSTAL_CHAT_SPAM_TICKS_BEFORE_BAN {
            player_runtime.chat_banned = true;
            player_runtime.chat_ban_until_ms = Some(now.saturating_add(CRYSTAL_CHAT_SPAM_BAN_MS));
            player_runtime.chat_spam_tick = 0;
            player_runtime.chat_next_allowed_at_ms = 0;
            drop(player_runtime);
            return Some(system_message_key(world, "server.ChatBanDuration5Minutes"));
        }
    } else {
        player_runtime.chat_spam_tick = 0;
    }
    player_runtime.chat_next_allowed_at_ms = now.saturating_add(CRYSTAL_CHAT_INTERVAL_MS);
    None
}

pub(super) fn chat_text_with_linked_items(message: &str, linked_items: &[ChatItem]) -> String {
    let mut text = message.to_string();
    for item in linked_items {
        let needle = format!("<{}>", item.title);
        if let Some((start, end)) = find_chat_link(&text, &needle) {
            text.replace_range(start..end, &item.internal_name());
        }
    }
    text
}

fn find_chat_link(text: &str, needle: &str) -> Option<(usize, usize)> {
    for (start, _) in text.char_indices() {
        let end = start.saturating_add(needle.len());
        if end <= text.len()
            && text.is_char_boundary(end)
            && text[start..end].eq_ignore_ascii_case(needle)
        {
            return Some((start, end));
        }
    }
    None
}

fn chat_linked_user_items(world: &World, linked_items: &[ChatItem]) -> Vec<UserItem> {
    if linked_items.is_empty() {
        return Vec::new();
    }
    let inventory = world.resource::<InventoryResource>();
    let hero_inventory = world.resource::<HeroInventoryResource>();
    let mut items = Vec::new();
    for linked_item in linked_items {
        let item = match linked_item.grid {
            MirGridType::Equipment => inventory
                .equipment_items
                .iter()
                .filter_map(user_item_from_equipment_state)
                .find(|item| item.unique_id == linked_item.unique_id),
            MirGridType::HeroInventory => hero_inventory
                .items
                .iter()
                .find(|item| item_unique_id(item) == linked_item.unique_id)
                .map(user_item_from_item_state),
            _ => inventory
                .inventory_items
                .iter()
                .chain(inventory.belt_items.iter())
                .chain(inventory.storage_items.iter())
                .find(|item| {
                    item_matches_client_reference(item, linked_item.grid, linked_item.unique_id)
                })
                .map(user_item_from_item_state),
        };
        if let Some(item) = item {
            items.push(item);
        }
    }
    items
}

fn active_chat_ban_remaining_seconds(world: &mut World) -> Option<u64> {
    let now = unix_now_ms();
    let mut player_runtime = world.resource_mut::<PlayerRuntimeResource>();
    if !player_runtime.chat_banned {
        return None;
    }
    match player_runtime.chat_ban_until_ms {
        Some(until_ms) if until_ms > now => Some((until_ms - now).div_ceil(1_000).max(1)),
        Some(_) => {
            player_runtime.chat_banned = false;
            player_runtime.chat_ban_until_ms = None;
            None
        }
        None => Some(1),
    }
}

fn chat_ban_remaining_message(world: &World, remaining_seconds: u64) -> ServerPacket {
    let days = remaining_seconds / 86_400;
    let hours = (remaining_seconds % 86_400) / 3_600;
    let minutes = (remaining_seconds % 3_600) / 60;
    let seconds = remaining_seconds % 60;
    if days > 0 {
        system_message_key_args(
            world,
            "server.ChatBanRemainingTimeByDay",
            [days, hours, minutes, seconds],
        )
    } else if hours > 0 {
        system_message_key_args(
            world,
            "server.ChatBanRemainingTimeByHour",
            [hours, minutes, seconds],
        )
    } else if minutes > 0 {
        system_message_key_args(
            world,
            "server.ChatBanRemainingTimeByMinutes",
            [minutes, seconds],
        )
    } else {
        system_message_key_args(world, "server.ChatBanRemainingTimeBySecond", [seconds])
    }
}

#[derive(Debug, Clone)]
pub(super) struct VisibleObjectBundle {
    pub(super) spawn_packet: ServerPacket,
    pub(super) health_packet: Option<ServerPacket>,
}

pub(super) fn player_struck_packet(attacker_id: u32) -> ServerPacket {
    ServerPacket::Struck {
        info: StruckInfo { attacker_id },
    }
}

pub(super) fn object_struck_packet(
    world: &World,
    target_entity: Entity,
    attacker_id: u32,
) -> Option<ServerPacket> {
    Some(ServerPacket::ObjectStruck {
        info: ObjectStruckInfo {
            object_id: entity_object_id(world, target_entity)?,
            attacker_id,
            location: entity_position(world, target_entity)?,
            direction: entity_facing(world, target_entity)?,
        },
    })
}

fn resolve_item_tooltip_source_for_viewer(
    source: &mut Option<WorldItemTooltipSource>,
    viewer: Option<(u16, MirClass)>,
) {
    let (Some(source), Some((level, class))) = (source.as_mut(), viewer) else {
        return;
    };
    source.real_info = Some(crystal_real_item_for_player(&source.info, level, class));
    source.real_socket_infos = source
        .socket_infos
        .iter()
        .map(|info| {
            info.as_ref()
                .map(|info| crystal_real_item_for_player(info, level, class))
        })
        .collect();
}

#[cfg(test)]
mod item_tooltip_source_tests {
    use super::*;

    #[test]
    fn tooltip_source_resolves_item_and_socket_rows_for_the_active_viewer() {
        let origin = crystal_item_by_index(1).expect("class-based SpiritBlade origin");
        let mut source = Some(WorldItemTooltipSource {
            info: origin.clone(),
            real_info: None,
            user_item: None,
            socket_infos: vec![None, Some(origin)],
            real_socket_infos: Vec::new(),
        });

        resolve_item_tooltip_source_for_viewer(&mut source, Some((20, MirClass::Wizard)));

        let source = source.expect("tooltip source remains present");
        assert_eq!(
            source.real_info.as_ref().map(|info| info.item_index),
            Some(3)
        );
        assert_eq!(source.real_socket_infos.len(), 2);
        assert_eq!(source.real_socket_infos[0], None);
        assert_eq!(
            source.real_socket_infos[1]
                .as_ref()
                .map(|info| info.item_index),
            Some(3)
        );
    }

    #[test]
    fn tooltip_source_without_viewer_never_manufactures_real_rows() {
        let mut source = Some(WorldItemTooltipSource {
            info: crystal_item_by_index(1).expect("class-based SpiritBlade origin"),
            real_info: None,
            user_item: None,
            socket_infos: Vec::new(),
            real_socket_infos: Vec::new(),
        });

        resolve_item_tooltip_source_for_viewer(&mut source, None);

        let source = source.expect("tooltip source remains present");
        assert_eq!(source.real_info, None);
        assert!(source.real_socket_infos.is_empty());
    }
}

pub(super) fn build_world_snapshot(world: &World) -> WorldSnapshot {
    let resources = world.resource::<InventoryResource>();
    let hero_inventory = world.resource::<HeroInventoryResource>();
    let player_runtime = world.resource::<PlayerRuntimeResource>();
    let map = world.resource::<MapRuntimeResource>();
    let config = &world.resource::<RuntimeConfigResource>().config;
    let session = world.resource::<SessionResource>();
    let skills = world.resource::<SkillResource>();
    let buffs = world.resource::<BuffResource>();
    let npc_state = world.resource::<NpcStateResource>();
    let stage5 = world.resource::<Stage5SystemsResource>();
    let language = session.language;
    let tooltip_viewer = session
        .selected_character
        .as_ref()
        .map(|character| (character.level, character.class));
    let hero_viewer=stage5.stage5_systems.hero.as_ref().map(|hero|(hero.level,hero.class));
    let hero_stats=super::hero_stats::compute(world);
    let hero_vitals=stage5.stage5_systems.hero.as_ref().map(|_| {
        let live=hero_entity(world).and_then(|entity|entity_player_vitals(world,entity));
        let saved=hero_inventory.saved_vitals;
        crate::config::HeroVitalsSnapshot {
            hp:live.map(|v|v.hp).or_else(||saved.map(|v|v.hp)).unwrap_or(hero_stats.get(12)),
            mp:live.map(|v|v.mp).or_else(||saved.map(|v|v.mp)).unwrap_or(hero_stats.get(13)),
            max_hp:hero_stats.get(12),max_mp:hero_stats.get(13),
        }
    });
    let tick = super::session::runtime_tick(world);
    let scene_view = active_scene_view(world);
    let mut entities = collect_world_entities(
        world,
        scene_view.as_ref(),
        language,
        &resources.equipment_items,
    );
    entities.sort_by_key(|entity| entity.object_id);

    let player_object_id = current_player_object_id(world);
    let player_vitals = player_entity(world).and_then(|entity| entity_player_vitals(world, entity));
    let mut stage5_systems = stage5.stage5_systems.clone();
    if let Some(guild) = super::shared_guilds::project_legacy_shape(world) {
        stage5_systems.guild = guild;
    }
    stage5_systems.item_rental = item_rental_snapshot(world);
    super::refine_oven::snapshot_timer(&mut stage5_systems.refine, false);

    // Seed every known city to 0 so the HUD renders a stable row set, then
    // overlay the player's actual balances.
    let mut city_currencies: BTreeMap<String, u32> = crate::config::CITY_CURRENCY_KEYS
        .iter()
        .map(|key| ((*key).to_string(), 0))
        .collect();
    for (key, amount) in &player_runtime.city_currencies {
        city_currencies.insert(key.clone(), *amount);
    }
    let player_stats = super::stats::player_stats(world);
    let max_weight = u16::try_from(player_stats.bag_weight().max(0)).unwrap_or(u16::MAX);

    WorldSnapshot {
        tick,
        map_title: session
            .selected_character
            .as_ref()
            .map(|_| super::session::localized_map_title(language, &map.current_map.title)),
        map_file_name: session
            .selected_character
            .as_ref()
            .map(|_| map.current_map.file_name.clone()),
        in_safe_zone: player_entity(world)
            .and_then(|entity| entity_position(world, entity))
            .map(|position| is_safe_zone_point(config, map, &position))
            .unwrap_or(false),
        light_setting: current_crystal_time_of_day_lights(),
        player_object_id,
        player_hp: player_vitals.map(|vitals| vitals.hp),
        player_max_hp: player_vitals.map(|vitals| vitals.max_hp),
        player_mp: player_vitals.map(|vitals| vitals.mp),
        player_max_mp: player_vitals.map(|vitals| vitals.max_mp),
        player_crystal_stats: player_stats.snapshot_entries(),
        player_pk_points: player_runtime.pk_points,
        player_experience: player_runtime.experience,
        player_max_experience: player_runtime.max_experience,
        gold: player_runtime.gold,
        credit: player_runtime.credit,
        city_currencies,
        current_weight: current_weight(resources),
        player_weights: tooltip_viewer.and_then(|(level,class)| super::player_weights::compute(resources,level,class,world.resource::<MountResource>().riding_mount)),
        max_weight,
        free_bag_slots: free_bag_slots(resources),
        max_bag_slots: crate::config::crystal_bag_slot_capacity(resources.inventory_capacity),
        inventory_capacity: resources.inventory_capacity,
        storage_size: resources.storage_size,
        has_expanded_storage: resources.has_expanded_storage,
        has_storage_password: resources.storage_has_password,
        require_storage_password: storage_password_required(
            config,
            resources.storage_has_password,
            resources.storage_unlocked,
        ),
        storage_password_last_set_binary_datetime: resources
            .storage_password_last_set_binary_datetime,
        expanded_storage_expiry_time_binary_datetime: resources
            .expanded_storage_expiry_time_binary_datetime,
        scene_view: scene_view.clone(),
        terrain_patches: filter_terrain_patches(world, scene_view.as_ref()),
        decor_objects: filter_decor_objects(world, scene_view.as_ref()),
        entities,
        ground_drops: collect_ground_drops(world, scene_view.as_ref(), language),
        belt_items: resources
            .belt_items
            .iter()
            .map(|item| {
                let mut snapshot = item.snapshot(language);
                resolve_item_tooltip_source_for_viewer(
                    &mut snapshot.tooltip_source,
                    tooltip_viewer,
                );
                snapshot
            })
            .collect(),
        inventory_items: resources
            .inventory_items
            .iter()
            .map(|item| {
                let mut snapshot = item.snapshot(language);
                resolve_item_tooltip_source_for_viewer(
                    &mut snapshot.tooltip_source,
                    tooltip_viewer,
                );
                snapshot
            })
            .collect(),
        hero_inventory_items: hero_inventory
            .items
            .iter()
            .map(|item| {
                let mut snapshot = item.snapshot(language);
                resolve_item_tooltip_source_for_viewer(
                    &mut snapshot.tooltip_source,
                    hero_viewer,
                );
                snapshot
            })
            .collect(),
        hero_equipment_items:hero_inventory.equipment.iter().map(|item| {
            let mut snapshot=item.snapshot(language);
            resolve_item_tooltip_source_for_viewer(&mut snapshot.tooltip_source,hero_viewer);
            snapshot
        }).collect(),
        hero_inventory_capacity:hero_inventory.capacity,
        hero_stats:hero_stats.snapshot(),
        hero_vitals,
        hero_weights:crate::config::HeroWeightsSnapshot {bag:hero_stats.bag,wear:hero_stats.wear,hand:hero_stats.hand},
        storage_items: resources
            .storage_items
            .iter()
            .map(|item| {
                let mut snapshot = item.snapshot(language);
                resolve_item_tooltip_source_for_viewer(
                    &mut snapshot.tooltip_source,
                    tooltip_viewer,
                );
                snapshot
            })
            .collect(),
        equipment_items: resources
            .equipment_items
            .iter()
            .map(|item| {
                let mut snapshot = item.snapshot(language);
                resolve_item_tooltip_source_for_viewer(
                    &mut snapshot.tooltip_source,
                    tooltip_viewer,
                );
                snapshot
            })
            .collect(),
        quest_log: quest_log_snapshots(world, language),
        active_npc_dialog: npc_state
            .active_npc_dialog
            .as_ref()
            .map(|dialog| dialog.snapshot(language)),
        npc_script_diagnostics: npc_state
            .npc_script_diagnostics
            .iter()
            .map(|diagnostic| NpcScriptDiagnosticSnapshot {
                script_key: diagnostic.script_key.clone(),
                label: diagnostic.label.clone(),
                line_number: diagnostic.line_number,
                command: diagnostic.command.clone(),
                message: diagnostic.message.clone(),
            })
            .collect(),
        known_skills: skills
            .skills
            .iter()
            .map(|skill| skill.snapshot(tick, language))
            .collect(),
        active_buffs: buffs
            .buffs
            .iter()
            .filter(|buff| !buff.expired(tick))
            .map(|buff| buff.snapshot(tick, language))
            .collect(),
        stage5_systems,
        map_transfers: collect_map_transfer_snapshots(world),
        interaction_hints: build_interaction_hints(world, resources),
    }
}

fn item_rental_snapshot(world: &World) -> Stage5ItemRentalSnapshot {
    let rental = world.resource::<ItemRentalResource>();
    let active = rental.active.as_ref();
    Stage5ItemRentalSnapshot {
        partner_name: active.map(|active| active.partner_name.clone()),
        fee: active.map(|active| active.fee).unwrap_or(0),
        days: active.map(|active| active.days).unwrap_or(0),
        has_deposited_item: active
            .and_then(|active| active.deposited_item.as_ref())
            .is_some(),
        deposited_item_name: active
            .and_then(|active| active.deposited_item.as_ref())
            .map(|item| item.name.clone()),
        gold_locked: active.map(|active| active.gold_locked).unwrap_or(false),
        item_locked: active.map(|active| active.item_locked).unwrap_or(false),
        record_count: rental.rented_items.len(),
        rented_items: rental
            .rented_items
            .iter()
            .map(|item| Stage5ItemRentalRecordSnapshot {
                item_id: item.item_id,
                item_name: item.item_name.clone(),
                renting_player_name: item.renting_player_name.clone(),
                item_return_date_binary_datetime: item.item_return_date_binary_datetime,
            })
            .collect(),
    }
}

pub(super) fn build_interaction_hints(
    world: &World,
    _resources: &InventoryResource,
) -> Vec<String> {
    let language = world.resource::<SessionResource>().language;
    let mut hints = vec![
        localized_text_or_fallback(
            language,
            "custom.interaction.primaryControls",
            "Left click walks, right click runs, and clicking a target focuses it.",
        ),
        localized_text_or_fallback(
            language,
            "custom.interaction.targetHelp",
            "Target monsters or NPCs in-scene, then attack or talk from range 1.",
        ),
    ];

    if let Some(quest) = world.resource::<QuestResource>().quests.first() {
        hints.push(format_localized_text(
            language,
            "custom.interaction.questHint",
            [quest.tracker(language)],
        ));
    }

    if world
        .resource::<NpcStateResource>()
        .active_npc_dialog
        .is_some()
    {
        hints.push(localized_text_or_fallback(
            language,
            "custom.interaction.npcDialogLive",
            "NPC dialog is live; review it, then continue field progression.",
        ));
    }

    hints
}

pub(super) fn object_movement(world: &World, entity: Entity) -> Option<ObjectMovement> {
    let entry = world.entity(entity);
    Some(ObjectMovement {
        object_id: entry.get::<ObjectId>()?.0,
        position: entry.get::<Position>()?.0.clone(),
        direction: entry.get::<Facing>()?.0,
    })
}

pub(super) fn object_health_info_for_entity(
    world: &World,
    entity: Entity,
    expire: u8,
) -> Option<ObjectHealthInfo> {
    let entry = world.entity(entity);
    let object_id = entry.get::<ObjectId>()?.0;
    let (hp, max_hp) = if let Some(vitals) = entry.get::<MonsterVitals>() {
        (vitals.hp, vitals.max_hp)
    } else if let Some(vitals) = entry.get::<PlayerVitals>() {
        (vitals.hp, vitals.max_hp)
    } else {
        return None;
    };

    Some(ObjectHealthInfo {
        object_id,
        percent: health_percent(hp, max_hp),
        expire,
    })
}

pub(super) fn object_mana_info_for_entity(world: &World, entity: Entity) -> Option<ObjectManaInfo> {
    let entry = world.entity(entity);
    let object_id = entry.get::<ObjectId>()?.0;
    let vitals = entry.get::<PlayerVitals>()?;

    Some(ObjectManaInfo {
        object_id,
        percent: mana_percent(vitals.mp, vitals.max_mp),
    })
}

pub(super) fn health_percent(hp: i32, max_hp: i32) -> u8 {
    let max_hp = max_hp.max(1);
    let percent = ((hp.max(0) * 100) / max_hp).clamp(0, 100);
    u8::try_from(percent).expect("health percent should fit")
}

pub(super) fn mana_percent(mp: i32, max_mp: i32) -> u8 {
    let max_mp = max_mp.max(1);
    let percent = ((mp.max(0) * 100) / max_mp).clamp(0, 100);
    u8::try_from(percent).expect("mana percent should fit")
}

pub(super) fn object_died_info_for_entity(
    world: &World,
    entity: Entity,
    kind: u8,
) -> Option<ObjectDiedInfo> {
    let movement = object_movement(world, entity)?;
    Some(ObjectDiedInfo {
        object_id: movement.object_id,
        location: movement.position,
        direction: movement.direction,
        kind,
    })
}

/// Crystal `PlayerObject.Die` enqueues `S.Death { Direction, Location }` to the
/// dying player (PlayerObject.cs:649) — the self-only death signal that drives
/// the client's revive prompt, sent alongside the `S.ObjectDied` broadcast other
/// players receive. Derives location/facing exactly like `object_died_info_for_entity`.
pub(super) fn self_death_packet(world: &World, entity: Entity) -> Option<ServerPacket> {
    let movement = object_movement(world, entity)?;
    Some(ServerPacket::Death {
        location: movement.position,
        direction: movement.direction,
    })
}

pub(super) fn object_revived_info_for_entity(
    world: &World,
    entity: Entity,
    effect: bool,
) -> Option<ObjectRevivedInfo> {
    Some(ObjectRevivedInfo {
        object_id: world.entity(entity).get::<ObjectId>()?.0,
        effect,
    })
}

pub(super) fn should_emit_object_packet(
    packet: &ServerPacket,
    previous_visible: &BTreeSet<u32>,
    next_visible: &BTreeSet<u32>,
    self_object_id: Option<u32>,
) -> bool {
    match packet {
        ServerPacket::ObjectPlayer { .. }
        | ServerPacket::ObjectHero { .. }
        | ServerPacket::ObjectRemove { .. }
        | ServerPacket::ObjectItem { .. }
        | ServerPacket::ObjectGold { .. }
        | ServerPacket::ObjectNpc { .. } => false,
        ServerPacket::ObjectMonster { info } => previous_visible.contains(&info.object_id),
        ServerPacket::ObjectTeleportOut { object_id, .. }
        | ServerPacket::ObjectTeleportIn { object_id, .. } => {
            should_emit_tracked_object(*object_id, previous_visible, next_visible, self_object_id)
        }
        ServerPacket::ObjectTurn { movement }
        | ServerPacket::ObjectWalk { movement }
        | ServerPacket::ObjectRun { movement }
        | ServerPacket::ObjectBackStep { movement, .. }
        | ServerPacket::ObjectSitDown { movement, .. }
        | ServerPacket::ObjectHarvest { movement }
        | ServerPacket::ObjectHarvested { movement } => should_emit_tracked_object(
            movement.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectAttack { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectStruck { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectRangeAttack { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectSpell { .. } => true,
        ServerPacket::ObjectEffect { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectChat { object_id, .. }
        | ServerPacket::ObjectHide { object_id }
        | ServerPacket::ObjectShow { object_id } => {
            should_emit_tracked_object(*object_id, previous_visible, next_visible, self_object_id)
        }
        ServerPacket::ObjectDied { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectRevived { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectHealth { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::ObjectMana { info } => should_emit_tracked_object(
            info.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::AddBuff { buff } => should_emit_tracked_object(
            buff.object_id,
            previous_visible,
            next_visible,
            self_object_id,
        ),
        ServerPacket::RemoveBuff { object_id, .. } => {
            should_emit_tracked_object(*object_id, previous_visible, next_visible, self_object_id)
        }
        _ => true,
    }
}

pub(super) fn should_emit_tracked_object(
    object_id: u32,
    previous_visible: &BTreeSet<u32>,
    next_visible: &BTreeSet<u32>,
    self_object_id: Option<u32>,
) -> bool {
    Some(object_id) == self_object_id
        || previous_visible.contains(&object_id)
        || next_visible.contains(&object_id)
}

pub(super) fn request_item_info_impl(item_index: i32) -> Vec<ServerPacket> {
    match crystal_item_by_index(item_index) {
        Some(template) => vec![ServerPacket::NewItemInfo {
            info: item_info_from_crystal_template(template),
        }],
        None => vec![super::session::system_message(&localized_text_or_fallback(
            LanguageCode::English,
            "server.NotFound",
            "server.NotFound",
        ))],
    }
}

pub(super) fn start_game_item_info_packets(
    resources: &InventoryResource,
    sent_item_info_indices: &mut BTreeSet<i32>,
) -> Vec<ServerPacket> {
    let mut packets = Vec::new();
    for item_key in resources
        .inventory_items
        .iter()
        .map(|item| item.key.as_str())
        .chain(
            resources
                .equipment_items
                .iter()
                .map(|item| item.key.as_str()),
        )
    {
        let Some(template) = crystal_item_template_for_item_key(item_key) else {
            continue;
        };
        if sent_item_info_indices.insert(template.item_index) {
            packets.push(ServerPacket::NewItemInfo {
                info: item_info_from_crystal_template(template),
            });
        }
    }
    packets
}

pub(super) fn start_game_recipe_info_packets(
    sent_item_info_indices: &mut BTreeSet<i32>,
) -> Vec<ServerPacket> {
    let mut packets = Vec::new();
    for recipe in crystal_recipe_bootstrap_packets() {
        for item_index in recipe.item_info_indices {
            if !sent_item_info_indices.insert(item_index) {
                continue;
            }
            let Some(template) = crystal_item_by_index(item_index) else {
                continue;
            };
            packets.push(ServerPacket::NewItemInfo {
                info: item_info_from_crystal_template(template),
            });
        }
        packets.push(decode_crystal_payload(
            ServerPacketId::NewRecipeInfo,
            recipe.payload,
        ));
    }
    packets
}

pub(super) fn start_game_account_social_and_shop_packets() -> Vec<ServerPacket> {
    let mut packets = vec![
        ServerPacket::CompleteQuest {
            completed_quests: Vec::new(),
        },
        ServerPacket::ReceiveMail { mail: Vec::new() },
        ServerPacket::FriendUpdate {
            friends: Vec::new(),
        },
        ServerPacket::LoverUpdate {
            name: String::new(),
            date_binary_datetime: 0,
            map_name: String::new(),
            married_days: 0,
        },
        ServerPacket::MentorUpdate {
            name: String::new(),
            level: 0,
            online: false,
            mentee_exp: 0,
        },
    ];
    packets.extend(
        crystal_game_shop_info_packet_payloads()
            .into_iter()
            .map(|payload| decode_crystal_payload(ServerPacketId::GameShopInfo, payload)),
    );
    packets
}

pub(super) fn apply_start_game_dynamic_game_shop_stock(world: &World, packets: &mut [ServerPacket]) {
    let individual_purchases = world
        .resource::<Stage5SystemsResource>()
        .stage5_systems
        .game_shop_individual_purchases
        .clone();
    let config = world.resource::<RuntimeConfigResource>().config.clone();
    let global_purchases = config
        .account_store
        .lock()
        .map(|store| store.game_shop_global_purchases.clone())
        .ok();

    for packet in packets {
        let ServerPacket::GameShopInfo { item, stock_level } = packet else {
            continue;
        };
        // Preserve the checked-in unlimited catalog byte-for-byte. Only a
        // future finite row is projected from durable counters.
        if item.stock == 0 {
            continue;
        }
        let purchases = if item.i_stock {
            individual_purchases
                .get(&item.g_index)
                .copied()
                .unwrap_or_default()
        } else {
            global_purchases
                .as_ref()
                .and_then(|purchases| purchases.get(&item.g_index))
                .copied()
                // A poisoned shared store must not expose finite stock as
                // available. Purchase remains authoritative in the commit.
                .unwrap_or_else(|| {
                    if global_purchases.is_some() {
                        0
                    } else {
                        u64::MAX
                    }
                })
        };
        *stock_level = game_shop_stock_level(item.stock, purchases);
    }
}

pub(super) fn start_game_base_stats_packet(class: MirClass) -> Vec<ServerPacket> {
    let mut packets = Vec::new();
    if let Some(payload) = crystal_base_stats_info_packet_payload(class) {
        packets.push(decode_crystal_payload(
            ServerPacketId::BaseStatsInfo,
            payload,
        ));
    }
    packets
}

pub(super) fn start_game_post_visible_crystal_bootstrap_packets() -> Vec<ServerPacket> {
    vec![
        ServerPacket::TimeOfDay {
            lights: current_crystal_time_of_day_lights(),
        },
        ServerPacket::ChangeAMode { mode: 0 },
        ServerPacket::ChangePMode { mode: 0 },
        ServerPacket::SwitchGroup { allow_group: false },
        ServerPacket::DefaultNPC { object_id: 0 },
        decode_crystal_payload(
            ServerPacketId::GuildBuffList,
            crystal_guild_buff_list_packet_payload(),
        ),
        ServerPacket::NPCUpdate { npc_id: 0 },
        ServerPacket::NPCUpdate { npc_id: 0 },
        ServerPacket::NPCUpdate { npc_id: 0 },
        ServerPacket::NPCResponse { page: Vec::new() },
        ServerPacket::NPCResponse { page: Vec::new() },
        ServerPacket::NPCResponse { page: Vec::new() },
    ]
}

pub(super) fn crystal_time_of_day_lights_for_utc_hour(hour: u32) -> u8 {
    // Crystal Envir.Now is seeded from DateTime.UtcNow, then AdjustLights uses
    // `Now.Hour * 2 % 24` before broadcasting S.TimeOfDay.
    let crystal_hour = (hour % 24) * 2 % 24;
    if crystal_hour == 6 || crystal_hour == 7 {
        1
    } else if (8..=15).contains(&crystal_hour) {
        2
    } else if crystal_hour == 16 || crystal_hour == 17 {
        3
    } else {
        4
    }
}

pub(super) fn parse_fixed_crystal_light_setting(raw: &str) -> Option<u8> {
    match raw.trim().to_ascii_lowercase().as_str() {
        "dawn" => Some(1),
        "day" => Some(2),
        "evening" => Some(3),
        "night" => Some(4),
        value => value
            .parse::<u8>()
            .ok()
            .filter(|setting| (1..=4).contains(setting)),
    }
}

pub(super) fn crystal_time_of_day_lights_with_override(
    fixed_setting: Option<&str>,
    utc_hour: u32,
) -> u8 {
    fixed_setting
        .and_then(parse_fixed_crystal_light_setting)
        .unwrap_or_else(|| crystal_time_of_day_lights_for_utc_hour(utc_hour))
}

pub(super) fn current_crystal_time_of_day_lights() -> u8 {
    static FIXED_LIGHT_SETTING: OnceLock<Option<String>> = OnceLock::new();
    let fixed_setting = FIXED_LIGHT_SETTING
        .get_or_init(|| std::env::var("MIR2_SIMULATION_FIXED_LIGHT_SETTING").ok());
    let utc_hour = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| ((duration.as_secs() / 3600) % 24) as u32)
        .unwrap_or(0);
    match fixed_setting.as_deref().map(str::trim) {
        Some(value) if value.eq_ignore_ascii_case("dynamic") => {
            crystal_time_of_day_lights_for_utc_hour(utc_hour)
        }
        Some(value) => crystal_time_of_day_lights_with_override(Some(value), utc_hour),
        // Crystal uses the same UTC-driven cycle in local and production
        // servers. QA that needs a stable daytime capture must opt in with the
        // explicit `day` override instead of silently changing debug visuals.
        None => crystal_time_of_day_lights_for_utc_hour(utc_hour),
    }
}

pub(super) fn decode_crystal_payload(packet_id: ServerPacketId, payload: Vec<u8>) -> ServerPacket {
    let frame = encode_frame(packet_id as i16, &payload)
        .expect("generated Crystal packet payload should fit into a protocol frame");
    decode_server_packet(&frame).expect("generated Crystal packet payload should decode")
}

pub(super) fn start_game_static_visible_object_packets(
    map_file_name: &str,
    player_position: &Point,
    character: &CharacterRecord,
    config: &SimulationConfig,
    npc_flags: &[NpcFlagState],
    local_time: CrystalNpcLocalTime,
) -> Vec<ServerPacket> {
    let normalized_map = normalize_map_file_name(map_file_name);
    let quest_ids_by_npc = crystal_quest_ids_by_npc();
    let mut objects = Vec::<(i32, i32, u32, ServerPacket)>::new();

    for npc in crystal_npc_info_manifest().npcs.into_iter().chain(mir2_game_data::periodic_quests::npc_templates()) {
        if npc
            .map_file_name
            .as_deref()
            .map(normalize_map_file_name)
            .as_deref()
            != Some(normalized_map.as_str())
        {
            continue;
        }
        if !point_in_data_range(&npc.location, player_position) {
            continue;
        }
        if !crystal_npc_visible_to_character_for_profile(
            &npc,
            character,
            npc_flags,
            local_time,
            super::quests::quest_recurrence::server_newcomer_v1_enabled(),
        ) {
            continue;
        }
        let Some(object_id) = npc.loaded_object_id else {
            continue;
        };
        let mut quest_ids: Vec<i32> = quest_ids_by_npc
            .get(&object_id)
            .map(|ids| ids.iter().copied().collect())
            .unwrap_or_default();
        for quest_id in super::quests::newcomer_progression::configured_quest_ids_for_npc(object_id).into_iter()
            .chain(super::quests::newcomer_v2::configured_quest_ids_for_npc(object_id))
            .chain(super::quests::periodic_quests::ids_for_npc(object_id))
        {
            if !quest_ids.contains(&quest_id) {
                quest_ids.push(quest_id);
            }
        }
        objects.push((
            npc.location.y,
            npc.location.x,
            object_id,
            ServerPacket::ObjectNpc {
                info: NpcInfo {
                    object_id,
                    name: npc.name,
                    name_colour_argb: CRYSTAL_NPC_NAME_COLOUR_ARGB,
                    image: npc.image,
                    colour_argb: 0,
                    location: npc.location,
                    direction: MirDirection::Up,
                    quest_ids,
                },
            },
        ));
    }

    if let Some(map) = crystal_map_respawns_by_file_name(map_file_name) {
        for respawn in &config.crystal_respawns_for_map(map_file_name) {
            // In the fully-activated world the whole map is alive, so the
            // on-screen subset is the canonical full placement filtered to the
            // data range — same positions/object-ids the ECS world spawned.
            let visible_spawns = if config.monster_spawn_source == MonsterSpawnSource::CrystalWorld
            {
                crystal_world_respawn_spawns(map_file_name, respawn)
                    .into_iter()
                    .filter(|(_, location, _)| point_in_data_range(location, player_position))
                    .collect::<Vec<_>>()
            } else {
                start_game_visible_respawn_spawns(map_file_name, respawn, player_position)
            };
            for (slot_index, location, direction) in visible_spawns {
                let object_id = crystal_respawn_object_id(respawn, slot_index);
                objects.push((
                    location.y,
                    location.x,
                    object_id,
                    crystal_respawn_object_monster_packet(respawn, object_id, location, direction),
                ));
            }
        }
        if config.safe_zone_border_effects {
            for spell in map.safe_zone_spells {
                if !point_in_data_range(&spell.location, player_position) {
                    continue;
                }
                let spell_kind = match spell.spell.as_str() {
                    "TrapHexagon" => Spell::TrapHexagon,
                    "Healing" => Spell::Healing,
                    _ => Spell::None,
                };
                objects.push((
                    spell.location.y,
                    spell.location.x,
                    spell.object_id,
                    ServerPacket::ObjectSpell {
                        info: ObjectSpellInfo {
                            object_id: spell.object_id,
                            location: spell.location,
                            spell: spell_kind,
                            direction: MirDirection::Up,
                            param: false,
                        },
                    },
                ));
            }
        }
    }

    objects.sort_by_key(|(y, x, object_id, _)| (*y, *x, *object_id));
    objects
        .into_iter()
        .map(|(_, _, _, packet)| packet)
        .collect()
}

pub(super) fn build_user_information(
    config: &SimulationConfig,
    character: &CharacterRecord,
    position: &Point,
    direction: MirDirection,
    vitals: PlayerVitals,
    experience: i64,
    max_experience: i64,
    gold: u32,
    credit: u32,
    storage_size: u16,
    has_expanded_storage: bool,
    storage_has_password: bool,
    require_storage_password: bool,
    storage_password_last_set_binary_datetime: i64,
    expanded_storage_expiry_time_binary_datetime: i64,
    hair: u8,
    inventory_capacity: u16,
    belt_items: &[ItemState],
    inventory_items: &[ItemState],
    equipment_items: &[EquipmentState],
    hero: Option<&Stage5HeroState>,
) -> UserInformation {
    UserInformation {
        object_id: config.object_id,
        real_id: u32::try_from(character.index).unwrap_or(config.real_id),
        name: character.name.clone(),
        guild_name: String::new(),
        guild_rank: String::new(),
        name_colour_argb: -1,
        class: character.class,
        gender: character.gender,
        level: character.level,
        location: position.clone(),
        direction,
        hair,
        hp: vitals.hp,
        mp: vitals.mp,
        // Crystal's client derives the HP/MP caps from `Stats[Stat.HP/MP]` via
        // `RefreshStats`; the web client has no such recompute, so push the caps
        // the simulation already tracks (`PlayerVitals::max_hp`/`max_mp`).
        max_hp: Some(vitals.max_hp),
        max_mp: Some(vitals.max_mp),
        experience,
        max_experience,
        level_effects: 0,
        has_hero: hero.is_some(),
        hero_behaviour: hero.map(|hero| hero.behaviour).unwrap_or(0),
        inventory_section_present: true,
        inventory: Some(user_inventory_slots(
            inventory_capacity,
            belt_items,
            inventory_items,
        )),
        equipment_section_present: true,
        equipment: Some(user_equipment_slots(equipment_items)),
        quest_inventory_section_present: true,
        quest_inventory: Some(user_quest_inventory_slots(inventory_items)),
        gold,
        credit,
        has_expanded_storage,
        has_storage_password: storage_has_password,
        require_storage_password,
        storage_password_last_set_binary_datetime,
        expanded_storage_expiry_time_binary_datetime: if has_expanded_storage
            || expanded_storage_expiry_time_binary_datetime != 0
            || storage_size != BASE_STORAGE_SLOTS
        {
            expanded_storage_expiry_time_binary_datetime
        } else {
            0
        },
        magic_count: 0,
        intelligent_creature_count: 0,
        summoned_creature_type: 99,
        creature_summoned: false,
        allow_observe: false,
        observer: false,
    }
}

pub(super) fn user_inventory_slots(
    inventory_capacity: u16,
    belt_items: &[ItemState],
    items: &[ItemState],
) -> Vec<Option<UserItem>> {
    let mut slots = vec![None; usize::from(inventory_capacity)];
    for item in belt_items
        .iter()
        .filter(|item| item.container == ItemContainer::Belt)
    {
        if let Some(slot) = slots.get_mut(usize::from(item.slot)) {
            *slot = Some(user_item_from_item_state(item));
        }
    }
    for item in items {
        let index = match item.container {
            ItemContainer::Bag1 => 6 + usize::from(item.slot),
            ItemContainer::Bag2 => 46 + usize::from(item.slot),
            _ => continue,
        };
        if let Some(slot) = slots.get_mut(index) {
            *slot = Some(user_item_from_item_state(item));
        }
    }
    slots
}

pub(super) fn user_equipment_slots(items: &[EquipmentState]) -> Vec<Option<UserItem>> {
    let mut slots = vec![None; 14];
    for item in items {
        let Some(index) = equipment_slot_index(item.slot) else {
            continue;
        };
        if let Some(slot) = slots.get_mut(index) {
            *slot = user_item_from_equipment_state(item);
        }
    }
    slots
}

pub(super) fn user_quest_inventory_slots(items: &[ItemState]) -> Vec<Option<UserItem>> {
    let mut slots = vec![None; 40];
    for item in items
        .iter()
        .filter(|item| item.container == ItemContainer::Quest)
    {
        if let Some(slot) = slots.get_mut(usize::from(item.slot)) {
            *slot = Some(user_item_from_item_state(item));
        }
    }
    slots
}

pub(super) fn collect_map_transfer_snapshots(world: &World) -> Vec<MapTransferSnapshot> {
    let config = &world.resource::<RuntimeConfigResource>().config;
    let map = world.resource::<MapRuntimeResource>();
    let current_map = normalize_map_file_name(&map.current_map.file_name);
    let mut transfers: Vec<MapTransferSnapshot> = config
        .map_transfers
        .iter()
        .filter(|transfer| normalize_map_file_name(&transfer.from_map_file_name) == current_map)
        .map(|transfer| MapTransferSnapshot {
            key: transfer.key.clone(),
            map_file_name: transfer.from_map_file_name.clone(),
            bounds: transfer.from_bounds,
            to_map_file_name: transfer.to_map_file_name.clone(),
            to_map_title: transfer.to_map_title.clone(),
            to_position: transfer.to_position.clone(),
            to_direction: transfer.to_direction,
        })
        .collect();

    transfers.extend(
        crystal_movement_transfer_records_for_map(&map.current_map.file_name)
            .into_iter()
            .map(|transfer| MapTransferSnapshot {
                key: transfer.key,
                map_file_name: transfer.from_map_file_name,
                bounds: transfer.from_bounds,
                to_map_file_name: transfer.to_map_file_name,
                to_map_title: transfer.to_map_title,
                to_position: transfer.to_position,
                to_direction: transfer.to_direction,
            }),
    );
    transfers.extend(
        authorized_map_coordinate_transfers(world)
            .into_iter()
            .map(|transfer| MapTransferSnapshot {
                key: transfer.key,
                map_file_name: transfer.from_map_file_name,
                bounds: transfer.from_bounds,
                to_map_file_name: transfer.to_map_file_name,
                to_map_title: transfer.to_map_title,
                to_position: transfer.to_position,
                to_direction: transfer.to_direction,
            }),
    );

    transfers
}

/// Crystal `HumanObject.RefreshEquipmentStats`: reset Looks_Wings, select
/// GetRealItem for the wearer's class/level, skip broken base ItemInfo, and
/// take Effect only from armour. An instance MaxDura of zero does not make
/// a normally durable item unbreakable.
fn crystal_player_wing_effect(body: &CharacterBody, items: &[EquipmentState]) -> u8 {
    let mut effect = 0;
    for item in items {
        let info = match item
            .user_item_metadata
            .as_ref()
            .and_then(|metadata| metadata.item_index)
        {
            Some(index) => crystal_item_by_index(index),
            None => crystal_item_template_for_item_key(&item.key),
        };
        let Some(info) = info else {
            continue;
        };
        if item.durability_current == 0 && info.durability > 0 {
            continue;
        }
        let real_info = crystal_real_item_for_player(&info, body.level, body.class);
        if real_info.item_type == CRYSTAL_ITEM_TYPE_ARMOUR {
            effect = real_info.effect;
        }
    }
    effect
}

#[allow(deprecated)]
/// Crystal `GetUpdateInfo()` for `@SETLIGHT`: the self player's `S.PlayerUpdate`
/// carrying the new personal light alongside the real weapon/armour shapes, so the
/// client refreshes the light radius without blanking the rendered gear.
pub(super) fn self_player_update_packet(world: &World, light: u8) -> Option<ServerPacket> {
    let object_id = current_player_object_id(world)?;
    let body = player_entity(world)
        .and_then(|player| world.entity(player).get::<CharacterBody>().copied());
    let equipment_items = world
        .resource::<InventoryResource>()
        .equipment_items
        .clone();
    let shape_to_i16 = |shape: Option<u16>| shape.and_then(|s| i16::try_from(s).ok()).unwrap_or(0);
    let weapon = shape_to_i16(
        equipment_shape(Some(&equipment_items), EquipmentSlot::Weapon)
            .or_else(|| body.and_then(|b| b.weapon_shape)),
    );
    let armour = shape_to_i16(
        equipment_shape(Some(&equipment_items), EquipmentSlot::Armour)
            .or_else(|| body.and_then(|b| b.armour_shape)),
    );
    Some(ServerPacket::PlayerUpdate {
        object_id,
        light,
        weapon,
        weapon_effect: 0,
        armour,
        wing_effect: body.map_or(0, |body| {
            crystal_player_wing_effect(&body, &equipment_items)
        }),
    })
}

/// Use the same authoritative shape selection as the owner's sprite snapshot.
/// An empty weapon stays -1 instead of synthesizing CWeapon/00.
pub(super) fn self_zone_player_appearance(world: &World) -> Option<crate::ZonePlayerAppearance> {
    let player = player_entity(world)?;
    let body = world.entity(player).get::<CharacterBody>()?;
    let equipment = &world.resource::<InventoryResource>().equipment_items;
    let shape = |slot, fallback| {
        equipment_shape(Some(equipment), slot)
            .or(fallback)
            .and_then(|shape| i16::try_from(shape).ok())
            .unwrap_or(-1)
    };
    let mount = world.resource::<MountResource>();
    Some(crate::ZonePlayerAppearance {
        hair: world.resource::<Stage5SystemsResource>().stage5_systems.appearance.hair,
        light: crystal_self_player_light(world, equipment),
        weapon: shape(EquipmentSlot::Weapon, body.weapon_shape),
        weapon_effect: 0,
        armour: shape(EquipmentSlot::Armour, body.armour_shape),
        wing_effect: crystal_player_wing_effect(body, equipment),
        mount_type: mount.mount_type,
        riding_mount: mount.riding_mount,
        fishing: world.resource::<FishingResource>().fishing,
    })
}

pub(super) fn collect_world_entities(
    world: &World,
    scene_view: Option<&mir2_game_data::SceneView>,
    language: LanguageCode,
    self_equipment_items: &[EquipmentState],
) -> Vec<WorldEntitySnapshot> {
    let mut result = Vec::new();
    let self_light = crystal_self_player_light(world, self_equipment_items);
    let self_wing_effect = player_entity(world)
        .and_then(|player| world.entity(player).get::<CharacterBody>())
        .map(|body| crystal_player_wing_effect(body, self_equipment_items));
    // The local player's mount state lives in `MountResource` (Crystal sends
    // `MountType`/`RidingMount` per player object); carry it only while riding so the
    // self-entity sprite renders the mount and hides weapons, matching `entity_sprite_snapshot`.
    let self_mount = world
        .get_resource::<MountResource>()
        .filter(|mount| mount.riding_mount)
        .map(|mount| mount.mount_type);
    // These predicates are emitted only for the local player because their
    // authoritative sources live in this personal SimulationSession. Shared
    // remote players remain `None` until Zone state models the same fields.
    let self_riding_mount = world
        .get_resource::<MountResource>()
        .map(|mount| mount.riding_mount);
    let self_can_mount_attack = world
        .get_resource::<MountResource>()
        .map(|_| crystal_player_can_mount_attack(world));
    let self_has_class_weapon = player_entity(world).and_then(|player| {
        (world.entity(player).contains::<CharacterBody>()
            && world.get_resource::<InventoryResource>().is_some())
        .then(|| crystal_player_has_class_weapon(world))
    });
    let self_dazed = player_entity(world).and_then(|_| {
        world
            .get_resource::<BuffResource>()
            .map(|_| crystal_player_is_dazed(world))
    });
    let self_fishing = player_entity(world).and_then(|_| {
        world
            .get_resource::<FishingResource>()
            .map(|fishing| fishing.fishing)
    });
    for entity in world.iter_entities() {
        let Some(object_id) = entity.get::<ObjectId>() else {
            continue;
        };
        let Some(name) = entity.get::<DisplayName>() else {
            continue;
        };
        let Some(position) = entity.get::<Position>() else {
            continue;
        };
        let Some(facing) = entity.get::<Facing>() else {
            continue;
        };

        let body = entity.get::<CharacterBody>();
        let player_vitals = entity.get::<PlayerVitals>();
        let monster_agent = entity.get::<MonsterAgent>();
        let monster_vitals = entity.get::<MonsterVitals>();
        let self_marker = entity.get::<SelfPlayer>();
        let hero_marker = entity.get::<Hero>();
        let remote_marker = entity.get::<RemotePlayer>();
        let npc_marker = entity.get::<Npc>();
        let npc_agent = entity.get::<NpcAgent>();
        if npc_marker.is_some() && !crystal_npc_object_visible_in_world(world, object_id.0) {
            continue;
        }

        if self_marker.is_none() && !point_in_scene_data_range(scene_view, &position.0) {
            continue;
        }

        let (kind, disposition, dead, hp, max_hp, level) = if self_marker.is_some() {
            (
                WorldEntityKind::SelfPlayer,
                WorldEntityDisposition::Friendly,
                current_player_is_dead(world),
                player_vitals.map(|v| v.hp),
                player_vitals.map(|v| v.max_hp),
                body.map(|v| v.level),
            )
        } else if hero_marker.is_some() {
            (
                WorldEntityKind::Player,
                WorldEntityDisposition::Friendly,
                player_vitals.map(|v| v.hp <= 0).unwrap_or(false),
                player_vitals.map(|v| v.hp),
                player_vitals.map(|v| v.max_hp),
                body.map(|v| v.level),
            )
        } else if remote_marker.is_some() {
            (
                WorldEntityKind::Player,
                WorldEntityDisposition::Friendly,
                false,
                None,
                None,
                body.map(|v| v.level),
            )
        } else if let Some(agent) = monster_agent {
            (
                WorldEntityKind::Monster,
                agent.disposition,
                agent.dead,
                monster_vitals.map(|v| v.hp),
                monster_vitals.map(|v| v.max_hp),
                None,
            )
        } else if npc_marker.is_some() {
            (
                WorldEntityKind::Npc,
                WorldEntityDisposition::Neutral,
                false,
                None,
                None,
                None,
            )
        } else {
            continue;
        };

        let sprite = entity_sprite_snapshot(
            body,
            monster_agent,
            npc_agent,
            if self_marker.is_some() {
                Some(self_equipment_items)
            } else {
                None
            },
            // Only the self player's hair is modelled (`@HAIR`); remote players fall
            // back to 0.
            if self_marker.is_some() {
                world
                    .resource::<Stage5SystemsResource>()
                    .stage5_systems
                    .appearance
                    .hair
            } else {
                0
            },
            if self_marker.is_some() {
                self_mount
            } else {
                None
            },
        );
        let source_quest_ids = npc_agent
            .map(|agent| agent.quest_ids.clone())
            .unwrap_or_default();
        let quest_ids = effective_quest_ids_for_npc(world, object_id.0, &source_quest_ids);
        let quest_icon =
            npc_agent.and_then(|_| crystal_npc_quest_icon(world, object_id.0, &quest_ids));
        let name_colour_argb = match kind {
            WorldEntityKind::Npc => CRYSTAL_NPC_NAME_COLOUR_ARGB,
            _ => -1,
        };
        let light = match kind {
            WorldEntityKind::SelfPlayer => self_light,
            // Crystal's NPCObject is a Merchant and assigns Light = 10.
            WorldEntityKind::Npc => 10,
            WorldEntityKind::Monster => crystal_monster_by_name(&name.value)
                .map(|monster| monster.light)
                .unwrap_or(0),
            WorldEntityKind::Player => 0,
        };

        result.push(WorldEntitySnapshot {
            object_id: object_id.0,
            kind,
            name: name.resolve(language),
            owner_name: hero_marker.map(|hero| hero.owner_name.clone()),
            ai: match kind {
                WorldEntityKind::Monster => {
                    crystal_monster_by_name(&name.value).map(|monster| monster.ai)
                }
                _ => None,
            },
            x: position.0.x,
            y: position.0.y,
            direction: facing.0,
            class: body.map(|body| body.class),
            gender: body.map(|body| body.gender),
            level,
            hp,
            max_hp,
            light,
            wing_effect: self_marker.is_some().then_some(self_wing_effect).flatten(),
            name_colour_argb,
            dead,
            riding_mount: self_marker.is_some().then_some(self_riding_mount).flatten(),
            can_mount_attack: self_marker
                .is_some()
                .then_some(self_can_mount_attack)
                .flatten(),
            has_class_weapon: self_marker
                .is_some()
                .then_some(self_has_class_weapon)
                .flatten(),
            dazed: self_marker.is_some().then_some(self_dazed).flatten(),
            fishing: self_marker.is_some().then_some(self_fishing).flatten(),
            disposition,
            sprite,
            quest_ids,
            quest_icon,
        });
    }

    result
}

pub(super) fn collect_current_map_shared_entity_snapshots(
    world: &World,
) -> Vec<WorldEntitySnapshot> {
    let inventory = world.resource::<InventoryResource>();
    let language = world.resource::<SessionResource>().language;
    let mut entities = collect_world_entities(world, None, language, &inventory.equipment_items)
        .into_iter()
        .filter(|entity| matches!(entity.kind, WorldEntityKind::Monster | WorldEntityKind::Npc))
        .collect::<Vec<_>>();
    // Quest icons are character-specific presentation state. Shared Zone map
    // entities must remain player-agnostic; Gateway overlays each session's
    // personal authoritative icon after composing the shared map snapshot.
    for entity in &mut entities {
        entity.quest_icon = None;
    }
    entities.sort_by_key(|entity| entity.object_id);
    entities
}

fn crystal_self_player_light(world: &World, equipment: &[EquipmentState]) -> u8 {
    let explicit_light = world.resource::<GmRuntimeResource>().light;
    if explicit_light > 0 {
        return explicit_light;
    }

    equipment
        .iter()
        .filter(|item| !item.is_broken())
        .filter_map(|item| crystal_item_template_for_item_key(&item.key))
        .map(|template| template.light)
        .max()
        // Crystal UserObject.RefreshStats clamps the local user to at least 3.
        .unwrap_or(0)
        .max(3)
}

pub(super) fn entity_sprite_snapshot(
    body: Option<&CharacterBody>,
    monster_agent: Option<&MonsterAgent>,
    npc_agent: Option<&NpcAgent>,
    equipment_items: Option<&[EquipmentState]>,
    hair: u8,
    // Crystal `MountType` of the rider, present only while actually riding
    // (`RidingMount`). Other entities / dismounted players pass `None`.
    self_mount: Option<i16>,
) -> Option<WorldEntitySpriteSnapshot> {
    if let Some(body) = body {
        let armour_shape = equipment_shape(equipment_items, EquipmentSlot::Armour)
            .or(body.armour_shape)
            .unwrap_or(0);
        let hair_shape = u16::from(hair);
        let weapon_shape =
            equipment_shape(equipment_items, EquipmentSlot::Weapon).or(body.weapon_shape);
        let uses_assassin_weapon =
            matches!(weapon_shape, Some(shape) if (100..200).contains(&shape));
        let uses_archer_weapon = matches!(weapon_shape, Some(shape) if shape >= 200);
        let body_library = format!("CArmour/{armour_shape:02}");
        let hair_library = Some(format!("CHair/{hair_shape:02}"));
        let (alt_body_library, alt_hair_library) = match body.class {
            MirClass::Assassin if uses_assassin_weapon => (
                Some(format!("AArmour/{armour_shape:02}")),
                Some(format!("AHair/{hair_shape:02}")),
            ),
            MirClass::Archer if uses_archer_weapon => (
                Some(format!("ARArmour/{armour_shape:02}")),
                Some(format!("ARHair/{hair_shape:02}")),
            ),
            _ => (None, None),
        };
        let (
            mut weapon_library,
            mut weapon_library_secondary,
            mut alt_weapon_library,
            mut alt_weapon_library_secondary,
        ) = match weapon_shape {
            Some(shape) if (100..200).contains(&shape) => {
                let index = shape - 100;
                (
                    None,
                    None,
                    Some(format!("AWeapon/{index:02} R")),
                    Some(format!("AWeapon/{index:02} L")),
                )
            }
            Some(shape) if shape >= 200 => {
                let index = shape - 200;
                (
                    Some(format!("ARWeapon/{index:02}")),
                    None,
                    Some(format!("ARWeapon/{index:02} S")),
                    None,
                )
            }
            Some(shape) => (Some(format!("CWeapon/{shape:02}")), None, None, None),
            None => (None, None, None, None),
        };
        let frame_base_offset = match body.gender {
            MirGender::Male => 0,
            MirGender::Female => 808,
        };
        let mut weapon_frame_offset = weapon_library.as_ref().map(|_| match body.gender {
            MirGender::Male => 0,
            MirGender::Female => 416,
        });
        let alt_frame_base_offset = match body.class {
            MirClass::Archer if uses_archer_weapon => Some(match body.gender {
                MirGender::Male => 0,
                MirGender::Female => 352,
            }),
            MirClass::Assassin if uses_assassin_weapon => Some(match body.gender {
                MirGender::Male => 0,
                MirGender::Female => 512,
            }),
            _ => None,
        };
        let alt_weapon_frame_offset = alt_frame_base_offset;

        // Crystal draws the mount as the bottom layer and skips every weapon layer
        // while `RidingMount` (`PlayerObject.cs` Draw() lines 4884-4923). The mount
        // library is `Libraries.Mounts[MountType]` (`Data\Mount\NN`, line 604-606).
        let (mount_library, mount_frame_offset) = match self_mount {
            Some(mount_type) if mount_type >= 0 => {
                weapon_library = None;
                weapon_library_secondary = None;
                alt_weapon_library = None;
                alt_weapon_library_secondary = None;
                weapon_frame_offset = None;
                (
                    Some(format!("Mount/{mount_type:02}")),
                    Some(frame_base_offset),
                )
            }
            _ => (None, None),
        };

        return Some(WorldEntitySpriteSnapshot {
            body_library,
            hair_library,
            weapon_library,
            weapon_library_secondary,
            frame_base_offset,
            weapon_frame_offset,
            alt_body_library,
            alt_hair_library,
            alt_weapon_library,
            alt_weapon_library_secondary,
            alt_frame_base_offset,
            alt_weapon_frame_offset,
            frame_count: 4,
            direction_stride: 4,
            mount_library,
            mount_frame_offset,
        });
    }

    if let Some(monster) = monster_agent {
        return Some(WorldEntitySpriteSnapshot {
            body_library: monster_body_library(monster.image),
            hair_library: None,
            weapon_library: None,
            weapon_library_secondary: None,
            frame_base_offset: 0,
            weapon_frame_offset: None,
            alt_body_library: None,
            alt_hair_library: None,
            alt_weapon_library: None,
            alt_weapon_library_secondary: None,
            alt_frame_base_offset: None,
            alt_weapon_frame_offset: None,
            frame_count: 4,
            direction_stride: 4,
            mount_library: None,
            mount_frame_offset: None,
        });
    }

    npc_agent.map(|npc| WorldEntitySpriteSnapshot {
        body_library: format!("NPC/{:02}", npc.image),
        hair_library: None,
        weapon_library: None,
        weapon_library_secondary: None,
        frame_base_offset: 0,
        weapon_frame_offset: None,
        alt_body_library: None,
        alt_hair_library: None,
        alt_weapon_library: None,
        alt_weapon_library_secondary: None,
        alt_frame_base_offset: None,
        alt_weapon_frame_offset: None,
        frame_count: 4,
        direction_stride: 4,
        mount_library: None,
        mount_frame_offset: None,
    })
}

// Crystal MonsterObject.Load selects Libraries.Gates[BaseImage - 950];
// MLibrary.Initialize uses Settings.GatePath and the two-digit "00" format.
// Keep this correction bounded to the four gates in platinum_176. Their
// animation descriptors come from each Gate library, with no extra base offset.
fn monster_body_library(image: u16) -> String {
    match image {
        950..=953 => format!("Gate/{:02}", image - 950),
        _ => format!("Monster/{image:03}"),
    }
}

#[cfg(test)]
#[path = "special_monster_sprite_tests.rs"]
mod special_monster_sprite_tests;

#[allow(deprecated)]
pub(super) fn collect_ground_drops(
    world: &World,
    scene_view: Option<&mir2_game_data::SceneView>,
    language: LanguageCode,
) -> Vec<GroundDropSnapshot> {
    let mut drops = Vec::new();
    let tick = super::session::runtime_tick(world);

    for entity in world.iter_entities() {
        if entity.get::<GroundDrop>().is_none() {
            continue;
        }

        let object_id = entity.get::<ObjectId>().expect("drop object id").0;
        let name = entity
            .get::<DisplayName>()
            .expect("drop name")
            .resolve(language);
        let position = entity.get::<Position>().expect("drop position").0.clone();
        let payload = entity.get::<DropPayload>().expect("drop payload");
        if !point_in_scene_data_range(scene_view, &position) {
            continue;
        }
        let ownership = entity.get::<DropOwnership>().and_then(|ownership| {
            (tick <= ownership.expires_at_tick).then(|| {
                (
                    ownership.owner_object_id,
                    ownership.expires_at_tick.saturating_sub(tick),
                )
            })
        });

        drops.push(GroundDropSnapshot {
            object_id,
            name,
            name_colour_argb: crystal_drop_name_colour_argb(&payload.loot),
            icon: ground_drop_loot_icon(&payload.loot),
            x: position.x,
            y: position.y,
            quantity: payload.quantity,
            source_monster: match payload.source_monster_key.as_deref() {
                Some(key) => localized_text_or_fallback(language, key, &payload.source_monster),
                None => payload.source_monster.clone(),
            },
            owner_object_id: ownership.map(|(owner_object_id, _)| owner_object_id),
            ownership_remaining_ticks: ownership.map(|(_, remaining_ticks)| remaining_ticks),
            loot: ground_drop_loot_snapshot(&payload.loot),
        });
    }

    drops.sort_by_key(|drop| drop.object_id);
    drops
}

/// Crystal item `Image` index for a ground drop, used to render the floor sprite.
/// Gold piles carry no item image (0); the client falls back to the generic marker.
fn ground_drop_loot_icon(loot: &DropLoot) -> u16 {
    match loot {
        DropLoot::Gold(_) => 0,
        DropLoot::InventoryItem { key, .. } => item_icon_for_key(key),
    }
}

fn ground_drop_loot_snapshot(loot: &DropLoot) -> GroundDropLootSnapshot {
    match loot {
        DropLoot::Gold(amount) => GroundDropLootSnapshot::Gold { amount: *amount },
        DropLoot::InventoryItem {
            key,
            name,
            description,
            weight,
            durability_current,
            durability_max,
            added_attack,
            added_defence,
            added_stats,
            cursed,
            socket_slots,
            show_group_pickup,
            exact_item,
        } => GroundDropLootSnapshot::InventoryItem {
            key: key.clone(),
            name: name.clone(),
            description: description.clone(),
            weight: *weight,
            durability_current: *durability_current,
            durability_max: *durability_max,
            added_attack: *added_attack,
            added_defence: *added_defence,
            added_stats: added_stats.clone(),
            cursed: *cursed,
            socket_slots: *socket_slots,
            show_group_pickup: *show_group_pickup,
            exact_item: exact_item.clone(),
        },
    }
}

#[allow(deprecated)]
pub(super) fn collect_visible_objects(world: &World) -> BTreeMap<u32, VisibleObjectBundle> {
    let mut objects = BTreeMap::new();
    let scene_view = active_scene_view(world);
    let language = super::session::current_language(world);

    for entity in world.iter_entities() {
        let position = entity.get::<Position>().map(|value| value.0.clone());
        if let Some(position) = position.as_ref() {
            if !point_in_scene_data_range(scene_view.as_ref(), position) {
                continue;
            }
        }

        if entity.get::<SelfPlayer>().is_some() {
            continue;
        }

        if let Some((object_id, bundle)) =
            visible_object_bundle_for_entity(world, entity.id(), language)
        {
            objects.insert(object_id, bundle);
        }
    }

    objects
}

fn point_in_scene_data_range(
    scene_view: Option<&mir2_game_data::SceneView>,
    point: &Point,
) -> bool {
    scene_view
        .map(|view| point_in_data_range(point, &view.center))
        .unwrap_or(true)
}

pub(super) fn visible_object_bundle_for_entity(
    world: &World,
    entity: Entity,
    language: LanguageCode,
) -> Option<(u32, VisibleObjectBundle)> {
    let entry = world.entity(entity);
    let object_id = entry.get::<ObjectId>()?.0;

    if entry.get::<RemotePlayer>().is_some() {
        let name = entry.get::<DisplayName>()?.resolve(language);
        let position = entry.get::<Position>()?.0.clone();
        let facing = entry.get::<Facing>()?.0;
        let body = entry.get::<CharacterBody>()?;
        return Some((
            object_id,
            VisibleObjectBundle {
                spawn_packet: ServerPacket::ObjectPlayer {
                    info: ObjectPlayerInfo {
                        object_id,
                        name,
                        guild_name: String::new(),
                        guild_rank_name: String::new(),
                        name_colour_argb: -1,
                        class: body.class,
                        gender: body.gender,
                        level: body.level,
                        location: position,
                        direction: facing,
                        hair: 0,
                        light: 0,
                        weapon: 0,
                        weapon_effect: 0,
                        armour: 0,
                        poison: 0,
                        dead: false,
                        hidden: false,
                        effect: 0,
                        wing_effect: 0,
                        extra: false,
                        mount_type: 0,
                        riding_mount: false,
                        fishing: false,
                        transform_type: 0,
                        element_orb_effect: 0,
                        element_orb_level: 0,
                        element_orb_max: 0,
                        buffs: Vec::new(),
                        level_effects: 0,
                    },
                },
                health_packet: None,
            },
        ));
    }

    if let Some(hero) = entry.get::<Hero>() {
        let name = entry.get::<DisplayName>()?.resolve(language);
        let position = entry.get::<Position>()?.0.clone();
        let facing = entry.get::<Facing>()?.0;
        let body = entry.get::<CharacterBody>()?;
        let looks=super::hero_inventory::appearance(world);
        return Some((
            object_id,
            VisibleObjectBundle {
                spawn_packet: ServerPacket::ObjectHero {
                    info: ObjectPlayerInfo {
                        object_id,
                        name,
                        guild_name: String::new(),
                        guild_rank_name: String::new(),
                        name_colour_argb: -1,
                        class: body.class,
                        gender: body.gender,
                        level: body.level,
                        location: position,
                        direction: facing,
                        hair: 0,
                        light: looks.light,
                        weapon: looks.weapon,
                        weapon_effect: looks.weapon_effect,
                        armour: looks.armour,
                        poison: 0,
                        dead: entry.get::<PlayerVitals>().is_some_and(|v|v.hp<=0),
                        hidden: false,
                        effect: 0,
                        wing_effect: looks.wing_effect,
                        extra: false,
                        mount_type: looks.mount_type,
                        riding_mount: super::hero_ai::hero_mount::riding(world),
                        fishing: false,
                        transform_type: 0,
                        element_orb_effect: 0,
                        element_orb_level: 0,
                        element_orb_max: 0,
                        buffs: Vec::new(),
                        level_effects: 0,
                    },
                    owner_name: hero.owner_name.clone(),
                },
                health_packet: object_health_info_for_entity(world, entity, 0)
                    .map(|info| ServerPacket::ObjectHealth { info }),
            },
        ));
    }

    if entry.get::<Monster>().is_some() {
        let name = entry.get::<DisplayName>()?.resolve(language);
        let effect = crystal_monster_effect_for_name(&name);
        let position = entry.get::<Position>()?.0.clone();
        let facing = entry.get::<Facing>()?.0;
        let monster = entry.get::<MonsterAgent>()?;
        let ai_state = entry.get::<MonsterAiState>().copied().unwrap_or_default();
        let harvested = entry
            .get::<HarvestMonsterState>()
            .map(|state| state.harvested)
            .unwrap_or(false);
        if ai_state.hidden {
            return None;
        }
        let summoned = entry.get::<SummonedMonster>().copied();
        let tick = super::session::runtime_tick(world);
        let buffs = if monster.ai == 123
            && entry
                .get::<GeneralMeowMeowState>()
                .map(|state| state.shield_until_tick > tick)
                .unwrap_or(false)
        {
            vec![BUFF_GENERAL_MEOW_MEOW_SHIELD]
        } else {
            Vec::new()
        };
        let spawn_packet = ServerPacket::ObjectMonster {
            info: MonsterInfo {
                object_id,
                name,
                name_colour_argb: -1,
                location: position,
                image: monster.image,
                direction: facing,
                effect,
                ai: monster.ai,
                light: 0,
                dead: monster.dead,
                skeleton: harvested,
                poison: entry
                    .get::<MonsterPoisonState>()
                    .map(|state| state.poison)
                    .unwrap_or(0),
                hidden: false,
                shock_time: 0,
                binding_shot_center: false,
                extra: ai_state.extra || summoned.map(|value| value.visible_extra).unwrap_or(false),
                extra_byte: ai_state.extra_byte,
                master_object_id: summoned
                    .map(|summoned| summoned.summoner_object_id)
                    .unwrap_or(0),
                rarity: 0,
                buffs,
            },
        };

        return Some((
            object_id,
            VisibleObjectBundle {
                spawn_packet,
                health_packet: object_health_info_for_entity(world, entity, 0)
                    .map(|info| ServerPacket::ObjectHealth { info }),
            },
        ));
    }

    if entry.get::<Npc>().is_some() {
        if !crystal_npc_object_visible_in_world(world, object_id) {
            return None;
        }
        let name = entry.get::<DisplayName>()?.resolve(language);
        let position = entry.get::<Position>()?.0.clone();
        let facing = entry.get::<Facing>()?.0;
        let npc = entry.get::<NpcAgent>()?;
        return Some((
            object_id,
            VisibleObjectBundle {
                spawn_packet: ServerPacket::ObjectNpc {
                    info: NpcInfo {
                        object_id,
                        name,
                        name_colour_argb: CRYSTAL_NPC_NAME_COLOUR_ARGB,
                        image: npc.image,
                        colour_argb: npc.colour_argb,
                        location: position,
                        direction: facing,
                        quest_ids: effective_quest_ids_for_npc(world, object_id, &npc.quest_ids),
                    },
                },
                health_packet: None,
            },
        ));
    }

    if entry.get::<GroundDrop>().is_some() {
        let position = entry.get::<Position>()?.0.clone();
        let payload = entry.get::<DropPayload>()?;
        let spawn_packet = match &payload.loot {
            DropLoot::Gold(amount) => ServerPacket::ObjectGold {
                info: ObjectGoldInfo {
                    object_id,
                    gold: *amount,
                    location: position,
                },
            },
            DropLoot::InventoryItem {
                key,
                added_attack,
                added_defence,
                added_stats,
                socket_slots,
                ..
            } => ServerPacket::ObjectItem {
                info: ObjectItemInfo {
                    object_id,
                    name: entry.get::<DisplayName>()?.resolve(language),
                    name_colour_argb: crystal_item_name_colour_argb_for_drop(
                        key,
                        *added_attack,
                        *added_defence,
                        added_stats,
                        *socket_slots,
                    ),
                    location: position,
                    image: super::items::item_icon_for_key(key),
                    grade: crystal_item_grade_for_key(key),
                },
            },
        };

        return Some((
            object_id,
            VisibleObjectBundle {
                spawn_packet,
                health_packet: None,
            },
        ));
    }

    None
}

pub(super) fn prepend_packet(
    packet: ServerPacket,
    mut packets: Vec<ServerPacket>,
) -> Vec<ServerPacket> {
    let mut result = Vec::with_capacity(packets.len() + 1);
    result.push(packet);
    result.append(&mut packets);
    result
}

pub(super) fn prepend_optional_packet(
    packet: Option<ServerPacket>,
    packets: Vec<ServerPacket>,
) -> Vec<ServerPacket> {
    match packet {
        Some(packet) => prepend_packet(packet, packets),
        None => packets,
    }
}

pub(super) fn use_item_ack(
    packet_ack: Option<(u64, MirGridType)>,
    success: bool,
) -> Option<ServerPacket> {
    packet_ack.map(|(unique_id, grid)| ServerPacket::UseItem {
        unique_id,
        success,
        grid,
    })
}

// ItemType.Script is consumed by the ordinary inventory packet, then dispatches
// the trusted DefaultNPC shape hook inside the enclosing source checkpoint.
fn use_original_script_item_packet(
    world: &mut World,
    unique_id: u64,
    grid: MirGridType,
) -> Option<Vec<ServerPacket>> {
    if !matches!(grid, MirGridType::Inventory | MirGridType::Belt) {
        return None;
    }
    let key = item_key_for_client_reference(world, unique_id, grid)?;
    let location = find_use_item_location(world.resource::<InventoryResource>(), &key, Some((unique_id, grid)))?;
    let item = item_at_use_location(world.resource::<InventoryResource>(), location)?;
    let template = crystal_item_template_for_item_key(&item.key)
        .or_else(|| crystal_item_template_for_dynamic_key(&item.key))?;
    if template.item_type != 21 {
        return None;
    }
    let ack = Some((unique_id, grid));
    if !is_in_world(world)
        || world.resource::<SessionResource>().account_id.is_none()
        || current_player_is_dead(world)
        || item.quantity == 0
        || item_unique_id(&item) != unique_id
        || validate_committed_item_state_carrier(&item).is_err()
    {
        return Some(prepend_optional_packet(use_item_ack(ack, false), vec![]));
    }
    if let CrystalUseItemEligibility::Rejected(packet) = crystal_use_item_eligibility(world, &template) {
        return Some(prepend_optional_packet(use_item_ack(ack, false), packet.into_iter().collect()));
    }
    let Ok(shape) = u16::try_from(template.shape) else {
        return Some(prepend_optional_packet(use_item_ack(ack, false), vec![]));
    };
    if super::default_npc_events::enqueue(world, super::default_npc_events::DefaultNpcEvent::UseItem { shape }).is_err() {
        return Some(prepend_optional_packet(use_item_ack(ack, false), vec![]));
    }
    consume_item_at_use_location(world, location);
    Some(prepend_optional_packet(use_item_ack(ack, true), vec![]))
}

#[derive(Debug, Clone)]
struct RankingCandidate {
    account_id: String,
    character_index: i32,
    player_id: i64,
    name: String,
    level: i32,
    class: MirClass,
    experience: i64,
    online: bool,
}

fn ranking_class_filter(rank_type: u8) -> Option<Option<MirClass>> {
    match rank_type {
        0 => Some(None),
        1 => Some(Some(MirClass::Warrior)),
        2 => Some(Some(MirClass::Wizard)),
        3 => Some(Some(MirClass::Taoist)),
        4 => Some(Some(MirClass::Assassin)),
        5 => Some(Some(MirClass::Archer)),
        _ => None,
    }
}

fn ranking_candidate_from_character(
    account_id: &str,
    character: &CharacterRecord,
    save: Option<&CharacterSaveRecord>,
    online: bool,
) -> RankingCandidate {
    let character = save.map(|save| &save.character).unwrap_or(character);
    RankingCandidate {
        account_id: account_id.to_string(),
        character_index: character.index,
        player_id: i64::from(character.index),
        name: character.name.clone(),
        level: i32::from(character.level),
        class: character.class,
        experience: save.map(|save| save.experience).unwrap_or_default(),
        online,
    }
}

fn stage5_get_ranking_packet(
    world: &World,
    rank_type: u8,
    rank_index: i32,
    online_only: bool,
    online_characters: Option<&BTreeSet<(String, i32)>>,
) -> Vec<ServerPacket> {
    let Some(class_filter) = ranking_class_filter(rank_type) else {
        return Vec::new();
    };
    if rank_index < 0 {
        return Vec::new();
    }

    // Crystal only serves rankings in Game/Observer
    // (`MirConnection.cs:2182-2185`). For the Simulation Game state, also prove
    // that the exact bound account still owns the selected character before
    // enumerating any cross-account ranking payload.
    let Some((active_identity, _)) = strict_active_account_authorization(world) else {
        return Vec::new();
    };
    let active_key = Some((
        active_identity.account_id.clone(),
        active_identity.character_index,
    ));
    let active_save = snapshot_active_character_save(world);
    let config = world.resource::<RuntimeConfigResource>().config.clone();

    let mut candidates = Vec::new();
    let mut active_seen = false;
    {
        let Ok(store) = config.account_store.lock() else {
            return Vec::new();
        };
        for (account_id, account) in &store.accounts {
            for character in &account.characters {
                let is_active =
                    active_key
                        .as_ref()
                        .is_some_and(|(active_account, active_index)| {
                            active_account == account_id && *active_index == character.index
                        });
                let online = online_characters
                    .map(|characters| characters.contains(&(account_id.clone(), character.index)))
                    .unwrap_or(is_active);
                let save = if is_active {
                    active_seen = true;
                    active_save
                        .as_ref()
                        .or_else(|| account.saves.get(&character.index))
                } else {
                    account.saves.get(&character.index)
                };
                candidates.push(ranking_candidate_from_character(
                    account_id, character, save, online,
                ));
            }
        }
    }

    if !active_seen {
        if let (Some((account_id, character_index)), Some(save)) =
            (active_key.as_ref(), active_save.as_ref())
        {
            candidates.push(RankingCandidate {
                account_id: account_id.clone(),
                character_index: *character_index,
                player_id: i64::from(*character_index),
                name: save.character.name.clone(),
                level: i32::from(save.character.level),
                class: save.character.class,
                experience: save.experience,
                online: online_characters
                    .map(|characters| characters.contains(&(account_id.clone(), *character_index)))
                    .unwrap_or(true),
            });
        }
    }

    candidates.retain(|candidate| {
        class_filter
            .map(|class| candidate.class == class)
            .unwrap_or(true)
    });
    candidates.sort_by(|left, right| {
        right
            .level
            .cmp(&left.level)
            .then_with(|| right.experience.cmp(&left.experience))
            .then_with(|| left.name.cmp(&right.name))
            .then_with(|| left.player_id.cmp(&right.player_id))
    });

    let my_rank = active_key
        .as_ref()
        .and_then(|(account_id, character_index)| {
            candidates
                .iter()
                .position(|candidate| {
                    &candidate.account_id == account_id
                        && candidate.character_index == *character_index
                })
                .map(|index| index as i32 + 1)
        })
        .unwrap_or_default();

    let visible_candidates: Vec<&RankingCandidate> = candidates
        .iter()
        .filter(|candidate| !online_only || candidate.online)
        .collect();
    let count = visible_candidates.len() as i32;
    let start = rank_index as usize;
    if start >= visible_candidates.len() && !visible_candidates.is_empty() {
        return Vec::new();
    }
    let page: Vec<&RankingCandidate> = visible_candidates
        .into_iter()
        .skip(start)
        .take(20)
        .collect();
    let listing_details = page
        .iter()
        .map(|candidate| RankCharacterInfo {
            player_id: candidate.player_id,
            name: candidate.name.clone(),
            level: candidate.level,
            class: candidate.class,
        })
        .collect();
    let listings = page.iter().map(|candidate| candidate.player_id).collect();

    vec![ServerPacket::Rankings {
        rank_type,
        my_rank,
        listing_details,
        listings,
        count,
    }]
}

impl SimulationSession {
    pub(crate) fn dispatch_default_npc_source_packets(&mut self, packets: &mut Vec<ServerPacket>) {
        super::default_npc_events::dispatch_source_packets(self.app.world_mut(),packets);
    }

    pub(crate) fn use_item_from_source_command(&mut self,key:&str)->Vec<ServerPacket> {
        let reference = {
            let inventory=self.app.world().resource::<InventoryResource>();
            inventory.inventory_items.iter().find(|item| item.key == key)
                .map(|item| (item_unique_id(item),MirGridType::Inventory))
                .or_else(|| inventory.belt_items.iter().find(|item| item.key == key)
                    .map(|item| (item_unique_id(item),MirGridType::Belt)))
        };
        if let Some((unique_id,grid))=reference {
            if let Some(packets)=use_original_script_item_packet(self.app.world_mut(),unique_id,grid) { return packets; }
        }
        self.use_item(key)
    }

    pub(crate) fn select_npc_dialog_from_source_command(&mut self,target:&str)->Vec<ServerPacket> {
        if self.app.world().resource::<NpcStateResource>().active_npc_dialog.as_ref()
            .is_some_and(|dialog| dialog.npc_object_id == 0) {
            return match super::default_npc_events::follow_up(self.app.world_mut(),target) {
                Ok(Some(packets))=>packets,Ok(None)=>vec![],
                Err(error)=>{super::shared_guild_experience::reject_source(self.app.world(),error);vec![]}
            };
        }
        self.select_npc_dialog_target(target)
    }

    pub fn friends_with_online_characters(
        &mut self,
        online_characters: &BTreeSet<(String, i32)>,
    ) -> Option<ServerPacket> {
        strict_active_account_authorization(self.app.world())?;
        stage5_refresh_friend_identities(self.app.world_mut());
        let mut friends = stage5_friend_entries(self.app.world());
        let social = &self
            .app
            .world()
            .resource::<Stage5SystemsResource>()
            .stage5_systems
            .social;
        for friend in &mut friends {
            if let Some(identity) = social.friend_identities.get(&friend.name) {
                friend.online = online_characters
                    .contains(&(identity.account_id.clone(), identity.character_index));
            }
        }
        Some(ServerPacket::FriendUpdate { friends })
    }

    /// Server-owned presence supplied by the shared world. This is not a client
    /// packet field and does not alter persisted character state.
    pub fn ranking_with_online_characters(
        &self,
        rank_type: u8,
        rank_index: i32,
        online_only: bool,
        online_characters: &BTreeSet<(String, i32)>,
    ) -> Vec<ServerPacket> {
        stage5_get_ranking_packet(
            self.app.world(),
            rank_type,
            rank_index,
            online_only,
            Some(online_characters),
        )
    }

    pub fn handle_packet(&mut self, packet: ClientPacket) -> Vec<ServerPacket> {
        match self.try_handle_packet(packet) {
            Ok(packets) => packets,
            Err(_error) => {
                eprintln!("simulation packet execution rejected; details suppressed");
                Vec::new()
            }
        }
    }

    pub fn try_handle_packet(&mut self, packet: ClientPacket) -> Result<Vec<ServerPacket>, String> {
        // Journal capabilities must never survive into a client packet flow.
        super::recovery::clear_binding(self.app.world_mut());
        if matches!(
            packet,
            ClientPacket::Disconnect | ClientPacket::LogOut | ClientPacket::StartGame { .. }
        ) {
            self.clear_shared_guild_grant();
        }
        if super::shared_guilds::enabled(self.app.world()) {
            if let ClientPacket::GuildNameReturn { ref name } = packet {
                return self.submit_shared_guild_name(name);
            }
        }
        let mut recurrence_packets = if matches!(packet, ClientPacket::StartGame { .. }) {
            Vec::new()
        } else {
            refresh_quest_recurrence(self.app.world_mut())
        };
        if matches!(packet, ClientPacket::Disconnect | ClientPacket::LogOut) {
            if let Err(error) = persist_active_character_save_for_logout(self.app.world()) {
                clear_account_derived_gm_permissions(self.app.world_mut());
                return Err(error);
            }
        }
        if let ClientPacket::StartGame { character_index } = packet {
            let mut packets = self.start_game(character_index);
            let started = packets.iter().any(|packet| matches!(packet,ServerPacket::StartGame { result:4,.. }));
            if started { super::default_npc_events::reset_transient(self.app.world_mut()); }
            let before = if started { self.begin_guild_experience_command(true)? } else { None };
            if started {
                let _ = super::default_npc_events::enqueue(self.app.world_mut(),super::default_npc_events::DefaultNpcEvent::Login);
                super::default_npc_events::dispatch_source_packets(self.app.world_mut(),&mut packets);
            }
            let _ = refresh_quest_recurrence(self.app.world_mut());
            let completed_quests = completed_quest_ids(self.app.world());
            for packet in &mut packets {
                if let ServerPacket::CompleteQuest {
                    completed_quests: packet_ids,
                } = packet
                {
                    *packet_ids = completed_quests.clone();
                }
            }
            apply_start_game_dynamic_game_shop_stock(self.app.world(), &mut packets);
            if let Some(friends) = self.friends_with_online_characters(&BTreeSet::new()) {
                for packet in &mut packets {
                    if matches!(packet, ServerPacket::FriendUpdate { .. }) {
                        *packet = friends.clone();
                    }
                }
            }
            return self.finish_guild_experience_command(before,packets);
        }

        let xp_source = matches!(&packet,
            ClientPacket::Attack{..}|ClientPacket::RangeAttack{..}|ClientPacket::Magic{..}
            |ClientPacket::CallNpc{..}|ClientPacket::NpcConfirmInput{..}|ClientPacket::FinishQuest{..});
        let default_source = is_in_world(self.app.world())
            && !matches!(&packet,ClientPacket::Disconnect|ClientPacket::LogOut)
            && (super::default_npc_events::has_pending(self.app.world())
                || super::default_npc_events::daily_due(self.app.world()) || xp_source
                || matches!(&packet, ClientPacket::UseItem{..}|ClientPacket::Walk{..}|ClientPacket::Run{..}
                    |ClientPacket::AcceptQuest{..}|ClientPacket::Chat{..}));
        let force_periodic=super::quests::periodic_quests::packet_requires_checkpoint(&packet)
            || matches!(&packet, ClientPacket::DepositRefineItem{..}
                |ClientPacket::RetrieveRefineItem{..}|ClientPacket::RefineCancel
                |ClientPacket::RefineItem{..}|ClientPacket::CheckRefine{..})
            || matches!(&packet, ClientPacket::CallNpc{key,..}
                if key.trim_start_matches('@').eq_ignore_ascii_case("REFINECOLLECT"));
        let before = if matches!(&packet, ClientPacket::CallNpc{..}|ClientPacket::NpcConfirmInput{..}) {
                self.begin_npc_dialog_source_command(force_periodic)?
            } else if force_periodic { self.begin_guild_experience_command(true)? }
            else if default_source { self.begin_default_npc_source_command()? }
            else if xp_source { self.begin_guild_experience_command(false)? } else { None };
        let journey_context = super::quests::newcomer_v2_events::command_context(&packet);
        let mut packets = self.handle_packet_impl(packet);
        let mut journey_packets = super::quests::newcomer_v2_events::observe_committed_command(
            self.app.world_mut(), journey_context, &packets);
        packets.append(&mut journey_packets);
        super::default_npc_events::dispatch_source_packets(self.app.world_mut(),&mut packets);
        recurrence_packets.append(&mut packets);
        let packets = self.finalize_packets(recurrence_packets);
        self.finish_guild_experience_command(before,packets)
    }

    fn handle_packet_impl(&mut self, packet: ClientPacket) -> Vec<ServerPacket> {
        match packet {
            ClientPacket::ClientVersion { .. } => {
                self.app
                    .world_mut()
                    .resource_mut::<SessionResource>()
                    .version_verified = true;
                vec![ServerPacket::ClientVersion { result: 1 }]
            }
            ClientPacket::Disconnect => {
                clear_account_derived_gm_permissions(self.app.world_mut());
                vec![ServerPacket::Disconnect { reason: 0 }]
            }
            ClientPacket::KeepAlive { time } => vec![ServerPacket::KeepAlive { time }],
            ClientPacket::NewAccount {
                account_id,
                password,
                ..
            } => {
                let config = self
                    .app
                    .world()
                    .resource::<RuntimeConfigResource>()
                    .config
                    .clone();
                let result = create_account_with_password(&config, &account_id, &password);
                self.app
                    .world_mut()
                    .resource_mut::<SessionResource>()
                    .characters
                    .clear();
                vec![ServerPacket::NewAccount { result }]
            }
            ClientPacket::ChangePassword {
                account_id,
                current_password,
                new_password,
            } => {
                let result = change_account_password(
                    self.app
                        .world()
                        .resource::<RuntimeConfigResource>()
                        .config
                        .clone(),
                    &account_id,
                    &current_password,
                    &new_password,
                );
                vec![ServerPacket::ChangePassword { result }]
            }
            ClientPacket::UnlockStorage { password } => {
                unlock_storage_impl(self.app.world_mut(), &password)
            }
            ClientPacket::SetStoragePassword {
                current_password,
                new_password,
            } => set_storage_password_impl(self.app.world_mut(), &current_password, &new_password),
            ClientPacket::RemoveStoragePassword { current_password } => {
                remove_storage_password_impl(self.app.world_mut(), &current_password)
            }
            ClientPacket::GetRentedItems => get_rented_items_impl(self.app.world()),
            ClientPacket::DepositRefineItem { from, to } => {
                stage5_deposit_refine_item_packet(self.app.world_mut(), from, to)
            }
            ClientPacket::RetrieveRefineItem { from, to } => {
                stage5_retrieve_refine_item_packet(self.app.world_mut(), from, to)
            }
            ClientPacket::RefineCancel => stage5_refine_cancel_packet(self.app.world_mut()),
            ClientPacket::RefineItem { unique_id } => {
                stage5_refine_item_packet(self.app.world_mut(), unique_id)
            }
            ClientPacket::CheckRefine { unique_id } => {
                stage5_check_refine_packet(self.app.world_mut(), unique_id)
            }
            ClientPacket::SetAutoPotValue { stat, value } => {
                if !matches!(stat, 12 | 13) { return Vec::new(); }
                let mut resources = self.app.world_mut().resource_mut::<Stage5SystemsResource>();
                let Some(hero) = resources.stage5_systems.hero.as_mut() else {
                    return Vec::new();
                };
                if !hero.spawned || !hero.auto_pot {
                    return Vec::new();
                }
                let percent = value.min(99) as u8;
                if stat == 12 {
                    hero.auto_hp_percent = percent;
                } else {
                    hero.auto_mp_percent = percent;
                }
                vec![ServerPacket::SetAutoPotValue { stat, value }]
            }
            ClientPacket::SetAutoPotItem { grid, item_index } => {
                if !matches!(grid, MirGridType::HeroHpItem | MirGridType::HeroMpItem) {
                    return Vec::new();
                }
                // The Crystal dialog admits only normal/sun potions. Enforce
                // that same restriction at the authoritative packet boundary.
                if item_index != 0 && !crystal_item_by_index(item_index).is_some_and(|item|
                    item.item_type == CRYSTAL_ITEM_TYPE_POTION && item.shape <= 1
                ) { return Vec::new(); }
                let mut resources = self.app.world_mut().resource_mut::<Stage5SystemsResource>();
                let Some(hero) = resources.stage5_systems.hero.as_mut() else {
                    return Vec::new();
                };
                if !hero.spawned || !hero.auto_pot {
                    return Vec::new();
                }
                let item_index = if item_index > 0 && crystal_item_by_index(item_index).is_some() {
                    item_index
                } else {
                    0
                };
                if grid == MirGridType::HeroHpItem {
                    hero.hp_item_index = item_index;
                } else {
                    hero.mp_item_index = item_index;
                }
                vec![ServerPacket::SetAutoPotItem {
                    grid: grid as u8,
                    item_index,
                }]
            }
            // Crystal `MirConnection.ChangeAMode` (MirConnection.cs:1432): store
            // `Player.AMode` and echo `S.ChangeAMode` so the client HUD updates.
            ClientPacket::ChangeAMode { mode } => {
                self.app
                    .world_mut()
                    .resource_mut::<Stage5SystemsResource>()
                    .stage5_systems
                    .attack_mode = mode;
                vec![ServerPacket::ChangeAMode { mode }]
            }
            // Crystal `MirConnection.ChangePMode` (MirConnection.cs:1440): store
            // `Player.PMode` and echo `S.ChangePMode` so the client HUD updates.
            ClientPacket::ChangePMode { mode } => {
                self.app
                    .world_mut()
                    .resource_mut::<Stage5SystemsResource>()
                    .stage5_systems
                    .pet_mode = mode;
                vec![ServerPacket::ChangePMode { mode }]
            }
            // Crystal `MirConnection.TownRevive` (MirConnection.cs:505 -> 1643):
            // `Player.TownRevive()` respawns a dead player at their bind/town point
            // and replies with `S.Revived` + broadcast `S.ObjectRevived`.
            ClientPacket::TownRevive => town_revive_packets(self.app.world_mut()),
            ClientPacket::ReplaceWedRing { .. }
            | ClientPacket::Inspect { .. }
            | ClientPacket::Observe { .. }
            | ClientPacket::ChangeTrade { .. }
            | ClientPacket::BuyItemBack { .. }
            | ClientPacket::RequestUserName { .. }
            | ClientPacket::RequestChatItem { .. }
            | ClientPacket::AcceptReincarnation
            | ClientPacket::CancelReincarnation
            | ClientPacket::AwakeningNeedMaterials { .. }
            | ClientPacket::AwakeningLockedItem { .. }
            | ClientPacket::Awakening { .. }
            | ClientPacket::DisassembleItem { .. }
            | ClientPacket::DowngradeAwakening { .. }
            | ClientPacket::ResetAddedItem { .. }
            | ClientPacket::GuildBuffUpdate { .. }
            | ClientPacket::ReportIssue { .. } => Vec::new(),
            ClientPacket::GameShopBuy {
                g_index,
                quantity,
                price_type,
            } => self.game_shop_buy_packet(g_index, quantity, price_type),
            ClientPacket::GetRanking {
                rank_type,
                rank_index,
                online_only,
            } => stage5_get_ranking_packet(
                self.app.world(),
                rank_type,
                rank_index,
                online_only,
                None,
            ),
            ClientPacket::GuildWarReturn { name } => {
                stage5_guild_war_return_packet(self.app.world_mut(), name)
            }
            ClientPacket::GuildTerritoryPage { page } => {
                stage5_guild_territory_page_packet(self.app.world(), page)
            }
            ClientPacket::PurchaseGuildTerritory { owner } => {
                stage5_purchase_guild_territory_packet(self.app.world_mut(), owner)
            }
            ClientPacket::EditGuildMember {
                change_type,
                rank_index,
                name,
                rank_name,
            } => stage5_edit_guild_member_packet(
                self.app.world_mut(),
                change_type,
                rank_index,
                name,
                rank_name,
            ),
            ClientPacket::EditGuildNotice { notice } => {
                stage5_edit_guild_notice_packet(self.app.world_mut(), notice)
            }
            ClientPacket::GuildInvite { accept_invite } => {
                stage5_guild_invite_reply_packet(self.app.world_mut(), accept_invite)
            }
            ClientPacket::GuildNameReturn { name } => {
                self.stage5_command("guild.create", vec![name])
            }
            ClientPacket::RequestGuildInfo { info_type } => {
                stage5_request_guild_info_packet(self.app.world_mut(), info_type)
            }
            ClientPacket::GuildStorageGoldChange {
                change_type,
                amount,
            } => stage5_guild_storage_gold_packet(self.app.world_mut(), change_type, amount),
            ClientPacket::GuildStorageItemChange {
                change_type,
                from,
                to,
            } => stage5_guild_storage_item_packet(self.app.world_mut(), change_type, from, to),
            ClientPacket::CraftItem {
                unique_id,
                count,
                slots,
            } => craft_item_impl(self.app.world_mut(), unique_id, count, slots),
            ClientPacket::DepositTradeItem { from, to } => {
                stage5_deposit_trade_item_packet(self.app.world_mut(), from, to)
            }
            ClientPacket::RetrieveTradeItem { from, to } => {
                stage5_retrieve_trade_item_packet(self.app.world_mut(), from, to)
            }
            ClientPacket::TakeBackHeroItem { from, to } => {
                take_back_hero_item_packet(self.app.world_mut(), from, to)
            }
            ClientPacket::TransferHeroItem { from, to } => {
                transfer_hero_item_packet(self.app.world_mut(), from, to)
            }
            ClientPacket::ConsignItem {
                unique_id,
                price,
                market_type,
            } => stage5_consign_item_packet(self.app.world_mut(), unique_id, price, market_type),
            ClientPacket::MarketSearch {
                match_text,
                user_mode,
                ..
            } => stage5_market_listing_packets(self.app.world(), &match_text, user_mode, 0),
            ClientPacket::MarketRefresh => {
                stage5_market_listing_packets(self.app.world(), "", false, 0)
            }
            ClientPacket::MarketPage { page } => stage5_market_listing_packets(
                self.app.world(),
                "",
                false,
                usize::try_from(page.max(0)).unwrap_or(0),
            ),
            ClientPacket::MarketBuy {
                auction_id,
                bid_price,
            } => stage5_market_buy_packet(self.app.world_mut(), auction_id, bid_price),
            ClientPacket::MarketGetBack { mode, auction_id } => {
                stage5_market_get_back_packet(self.app.world_mut(), mode, auction_id)
            }
            ClientPacket::MarketSellNow { auction_id } => {
                stage5_market_sell_now_packet(self.app.world_mut(), auction_id)
            }
            ClientPacket::OpenDoor { door_index } => {
                stage5_open_door_packet(self.app.world_mut(), door_index)
            }
            ClientPacket::RequestMapInfo { map_index } => {
                request_map_info_packet(self.app.world_mut(), map_index)
            }
            ClientPacket::SearchMap { text } => search_map_packets(self.app.world_mut(), &text),
            ClientPacket::TeleportToNpc { object_id } => {
                teleport_to_npc_packets(self.app.world(), object_id)
            }
            ClientPacket::RequestMonsterInfo { monster_index } => {
                request_monster_info_packet(monster_index)
            }
            ClientPacket::RequestNpcInfo { npc_index } => {
                request_npc_info_packet(self.app.world(), npc_index)
            }
            ClientPacket::MarriageRequest => stage5_marriage_request_packet(self.app.world_mut()),
            ClientPacket::MarriageReply { accept_invite } => {
                stage5_marriage_reply_packet(self.app.world_mut(), accept_invite)
            }
            ClientPacket::ChangeMarriage => stage5_change_marriage_packet(self.app.world_mut()),
            ClientPacket::DivorceRequest => stage5_divorce_request_packet(self.app.world_mut()),
            ClientPacket::DivorceReply { accept_invite } => {
                stage5_divorce_reply_packet(self.app.world_mut(), accept_invite)
            }
            ClientPacket::AddMentor { name } => {
                stage5_add_mentor_packet(self.app.world_mut(), name)
            }
            ClientPacket::MentorReply { accept_invite } => {
                stage5_mentor_reply_packet(self.app.world_mut(), accept_invite)
            }
            ClientPacket::AllowMentor => stage5_allow_mentor_packet(self.app.world_mut()),
            ClientPacket::CancelMentor => stage5_cancel_mentor_packet(self.app.world_mut()),
            ClientPacket::TradeRequest => stage5_trade_request_packet(self.app.world_mut(), None),
            ClientPacket::TradeReply { accept_invite } => {
                stage5_trade_reply_packet(self.app.world_mut(), accept_invite)
            }
            ClientPacket::TradeGold { amount } => {
                stage5_trade_gold_packet(self.app.world_mut(), amount)
            }
            ClientPacket::TradeConfirm { locked } => {
                stage5_trade_confirm_packet(self.app.world_mut(), locked)
            }
            ClientPacket::TradeCancel => stage5_trade_cancel_packet(self.app.world_mut()),
            ClientPacket::SwitchGroup { allow_group } => {
                stage5_group_switch_packet(self.app.world_mut(), allow_group)
            }
            ClientPacket::AddMember { name } => {
                stage5_group_add_member_packet(self.app.world_mut(), name)
            }
            ClientPacket::DelMember { name } => {
                stage5_group_del_member_packet(self.app.world_mut(), name)
            }
            ClientPacket::GroupInvite { accept_invite } => {
                stage5_group_invite_reply_packet(self.app.world_mut(), accept_invite)
            }
            ClientPacket::AcceptQuest {
                npc_index,
                quest_index,
            } => {
                if !active_npc_allows_quest_request(
                    self.app.world(),
                    quest_index,
                    Some(npc_index),
                    false,
                    None,
                ) {
                    Vec::new()
                } else {
                    let packets = stage5_accept_quest_packet(self.app.world_mut(), quest_index);
                    if packets.iter().any(|packet| {
                        matches!(
                            packet,
                            ServerPacket::ChangeQuest {
                                quest_id,
                                taken: true,
                                ..
                            } if *quest_id == quest_index
                        )
                    }) {
                        dismiss_dialog(self.app.world_mut());
                    }
                    packets
                }
            }
            ClientPacket::FinishQuest {
                quest_index,
                selected_item_index,
            } => {
                if !active_npc_allows_quest_request(
                    self.app.world(),
                    quest_index,
                    None,
                    true,
                    (selected_item_index >= 0).then_some(selected_item_index),
                ) {
                    Vec::new()
                } else {
                    let packets = stage5_finish_quest_packet(
                        self.app.world_mut(),
                        quest_index,
                        (selected_item_index >= 0).then_some(selected_item_index),
                    );
                    if packets.iter().any(|packet| {
                        matches!(
                            packet,
                            ServerPacket::ChangeQuest {
                                quest_id,
                                taken: false,
                                quest_state: CRYSTAL_QUEST_STATE_REMOVE,
                                ..
                            } if *quest_id == quest_index
                        )
                    }) {
                        dismiss_dialog(self.app.world_mut());
                    }
                    packets
                }
            }
            ClientPacket::AbandonQuest { quest_index } => {
                stage5_abandon_quest_packet(self.app.world_mut(), quest_index)
            }
            ClientPacket::ShareQuest { quest_index } => {
                stage5_share_quest_packet(self.app.world_mut(), quest_index)
            }
            ClientPacket::FishingCast { cast_out } => {
                fishing_cast_impl(self.app.world_mut(), cast_out)
            }
            ClientPacket::FishingChangeAutocast { auto_cast } => {
                fishing_change_autocast_impl(self.app.world_mut(), auto_cast)
            }
            ClientPacket::SendMail {
                name,
                message,
                gold,
                items_idx,
                stamped,
            } => stage5_send_mail_packet(
                self.app.world_mut(),
                name,
                message,
                gold,
                items_idx,
                stamped,
            ),
            ClientPacket::ReadMail { mail_id } => {
                stage5_read_mail_packet(self.app.world_mut(), mail_id)
            }
            ClientPacket::CollectParcel { mail_id } => {
                stage5_collect_mail_packet(self.app.world_mut(), mail_id)
            }
            ClientPacket::DeleteMail { mail_id } => {
                stage5_delete_mail_packet(self.app.world_mut(), mail_id)
            }
            ClientPacket::LockMail { mail_id, lock } => {
                stage5_lock_mail_packet(self.app.world_mut(), mail_id, lock)
            }
            ClientPacket::MailLockedItem { unique_id, locked } => {
                vec![ServerPacket::MailLockedItem { unique_id, locked }]
            }
            ClientPacket::MailCost { gold, stamped, items_idx } => {
                vec![ServerPacket::MailCost {
                    // This packet has no error field. An invalid quote must
                    // clear any old cheap/free quote, never authorize delivery.
                    cost: stage5_mail_quote(self.app.world(), gold, &items_idx, stamped).unwrap_or(u32::MAX),
                }]
            }
            ClientPacket::RequestIntelligentCreatureUpdates { update } => {
                super::intelligent_creatures::request_updates(self.app.world_mut(), update)
            }
            ClientPacket::UpdateIntelligentCreature {
                creature,
                summon_me,
                unsummon_me,
                release_me,
            } => stage5_update_intelligent_creature_packet(
                self.app.world_mut(),
                creature,
                summon_me,
                unsummon_me,
                release_me,
            ),
            ClientPacket::IntelligentCreaturePickup {
                mouse_mode,
                location,
            } => stage5_intelligent_creature_pickup_packet(
                self.app.world_mut(),
                location,
                Some(mouse_mode),
            ),
            ClientPacket::AddFriend { name, blocked } => {
                stage5_add_friend_packet(self.app.world_mut(), name, blocked)
            }
            ClientPacket::RemoveFriend { character_index } => {
                stage5_remove_friend_packet(self.app.world_mut(), character_index)
            }
            ClientPacket::RefreshFriends => self
                .friends_with_online_characters(&BTreeSet::new())
                .into_iter()
                .collect(),
            ClientPacket::AddMemo {
                character_index,
                memo,
            } => stage5_add_memo_packet(self.app.world_mut(), character_index, memo),
            ClientPacket::ItemRentalRequest => {
                item_rental_request_impl(self.app.world_mut(), None, false)
            }
            ClientPacket::ItemRentalFee { amount } => {
                item_rental_fee_impl(self.app.world_mut(), amount)
            }
            ClientPacket::ItemRentalPeriod { days } => {
                item_rental_period_impl(self.app.world_mut(), days)
            }
            ClientPacket::DepositRentalItem { from, to } => {
                deposit_rental_item_impl(self.app.world_mut(), from, to)
            }
            ClientPacket::RetrieveRentalItem { from, to } => {
                retrieve_rental_item_impl(self.app.world_mut(), from, to)
            }
            ClientPacket::CancelItemRental => cancel_item_rental_impl(self.app.world_mut()),
            ClientPacket::ItemRentalLockFee => item_rental_lock_fee_impl(self.app.world_mut()),
            ClientPacket::ItemRentalLockItem => item_rental_lock_item_impl(self.app.world_mut()),
            ClientPacket::ConfirmItemRental => confirm_item_rental_impl(self.app.world_mut()),
            ClientPacket::Login {
                account_id,
                password,
            } => {
                let config = self
                    .app
                    .world()
                    .resource::<RuntimeConfigResource>()
                    .config
                    .clone();
                let characters = match login_account(&config, &account_id, &password) {
                    AccountLoginResult::Success(characters) => characters,
                    AccountLoginResult::Banned(ban) => {
                        return vec![ServerPacket::LoginBanned {
                            reason: ban.reason,
                            expiry_binary_datetime: ban.ban_until_ms.unwrap_or_default() as i64,
                        }];
                    }
                    AccountLoginResult::InvalidCredentials => {
                        return vec![ServerPacket::Login { result: 4 }];
                    }
                };
                let select_infos = account_select_infos(&config, &account_id);
                clear_account_derived_gm_permissions(self.app.world_mut());
                let mut session = self.app.world_mut().resource_mut::<SessionResource>();
                session.account_id = Some(account_id);
                session.characters = characters;
                session.selected_character = None;
                session.clear_active_save_revision();
                vec![ServerPacket::LoginSuccess {
                    characters: select_infos,
                }]
            }
            ClientPacket::NewCharacter {
                name,
                gender,
                class,
            } => {
                let account_id = match crystal_character_select_state(
                    self.app.world().resource::<SessionResource>(),
                ) {
                    CrystalCharacterSelectState::Authenticated { account_id } => account_id,
                    CrystalCharacterSelectState::Unauthenticated
                    | CrystalCharacterSelectState::InGame => return Vec::new(),
                };
                let config = self
                    .app
                    .world()
                    .resource::<RuntimeConfigResource>()
                    .config
                    .clone();
                if !config.class_is_allowed(class) {
                    return vec![ServerPacket::NewCharacter { result: 1 }];
                }
                let character = match add_character_to_account(
                    &config,
                    &account_id,
                    CharacterRecord {
                        index: 0,
                        name,
                        level: 1,
                        class,
                        gender,
                    },
                ) {
                    Ok(character) => character,
                    Err(_) => return vec![ServerPacket::NewCharacter { result: 1 }],
                };
                self.app
                    .world_mut()
                    .resource_mut::<SessionResource>()
                    .characters = account_characters(&config, &account_id);
                vec![ServerPacket::NewCharacterSuccess {
                    char_info: character.to_new_character_select_info(),
                }]
            }
            ClientPacket::NewHero {
                name,
                gender,
                class,
            } => {
                let hero_is_allowed = self
                    .app
                    .world()
                    .resource::<RuntimeConfigResource>()
                    .config
                    .stage5_action_is_allowed("hero.create");
                if hero_is_allowed {
                    stage5_new_hero_packet(self.app.world_mut(), name, gender, class)
                } else {
                    vec![ServerPacket::NewHero { result: 1 }]
                }
            }
            ClientPacket::DeleteCharacter { character_index } => {
                self.delete_character_impl(character_index)
            }
            ClientPacket::StartGame { character_index } => self.start_game(character_index),
            ClientPacket::LogOut => {
                let (account_id, in_game) = {
                    let session = self.app.world().resource::<SessionResource>();
                    (
                        active_session_mutating_account_id(session),
                        session.selected_character.is_some(),
                    )
                };
                if !in_game {
                    clear_account_derived_gm_permissions(self.app.world_mut());
                    if account_id.is_none() {
                        self.app
                            .world_mut()
                            .resource_mut::<SessionResource>()
                            .characters
                            .clear();
                    }
                    return Vec::new();
                }
                let Some(account_id) = account_id else {
                    clear_account_derived_gm_permissions(self.app.world_mut());
                    self.app
                        .world_mut()
                        .resource_mut::<SessionResource>()
                        .characters
                        .clear();
                    return Vec::new();
                };
                // Map metadata de-duplication is scoped to one in-world
                // connection. A later StartGame must receive setup/map info
                // again even when the SimulationSession object is reused.
                self.app
                    .world_mut()
                    .remove_resource::<BigMapConnectionState>();
                let config = self
                    .app
                    .world()
                    .resource::<RuntimeConfigResource>()
                    .config
                    .clone();
                {
                    {
                        let mut session = self.app.world_mut().resource_mut::<SessionResource>();
                        session.selected_character = None;
                        session.clear_active_save_revision();
                        session.characters = account_characters(&config, &account_id);
                    }
                    self.app
                        .world_mut()
                        .resource_mut::<PlayerPermissionResource>()
                        .unlock_curse = false;
                    self.app
                        .world_mut()
                        .resource_mut::<NpcStateResource>()
                        .active_npc_dialog = None;
                    self.app
                        .world_mut()
                        .resource_mut::<ItemRentalResource>()
                        .active = None;
                    let mut queue = self.app.world_mut().resource_mut::<RuntimeQueueResource>();
                    queue.pending_combat_actions = Vec::new();
                    queue.pending_monster_spawns = Vec::new();
                    queue.pending_ground_spell_actions = Vec::new();
                    drop(queue);
                    let mut inventory = self.app.world_mut().resource_mut::<InventoryResource>();
                    inventory.storage_unlocked =
                        !inventory.storage_has_password || !config.require_storage_password;
                }
                clear_account_derived_gm_permissions(self.app.world_mut());
                rebuild_world(self.app.world_mut());
                vec![ServerPacket::LogOutSuccess {
                    characters: account_select_infos(&config, &account_id),
                }]
            }
            ClientPacket::Turn { direction } => {
                dismiss_dialog(self.app.world_mut());
                if let Some(player) = player_entity(self.app.world()) {
                    self.app
                        .world_mut()
                        .entity_mut(player)
                        .insert(Facing(direction));
                    self.app
                        .world_mut()
                        .resource_mut::<PlayerRuntimeResource>()
                        .player_direction = direction;
                    let location = current_location(self.app.world());
                    let mut packets =
                        apply_current_player_position_map_transfer(self.app.world_mut());
                    if packets.is_empty() {
                        packets.push(ServerPacket::UserLocation {
                            location: location.clone(),
                        });
                        packets.extend(map_coordinate_hint_packets_for_path(
                            self.app.world(),
                            std::slice::from_ref(&location.position),
                        ));
                    }
                    packets.extend(advance_world(self.app.world_mut()));
                    packets
                } else {
                    Vec::new()
                }
            }
            ClientPacket::Walk { direction } => {
                dismiss_dialog(self.app.world_mut());
                if current_player_is_dead(self.app.world())
                    || crystal_player_movement_blocked_by_status(self.app.world())
                {
                    if is_in_world(self.app.world()) {
                        self.app
                            .world_mut()
                            .resource_mut::<RuntimeQueueResource>()
                            .pending_movement_command = None;
                    }
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if is_in_world(self.app.world())
                    && !crystal_packet_action_ready(self.app.world(), PlayerActionKind::Move)
                {
                    queue_crystal_movement_retry(self.app.world_mut(), direction, false);
                    return Vec::new();
                }
                if is_in_world(self.app.world()) {
                    let delay_ticks = crystal_packet_move_delay_ticks(false)
                        + if crystal_player_slowed_by_status(self.app.world()) {
                            1
                        } else {
                            0
                        };
                    mark_crystal_packet_action(
                        self.app.world_mut(),
                        PlayerActionKind::Move,
                        delay_ticks,
                    );
                }
                self.move_player_by_direction(direction, false)
            }
            ClientPacket::Run { direction } => {
                dismiss_dialog(self.app.world_mut());
                if current_player_is_dead(self.app.world())
                    || crystal_player_movement_blocked_by_status(self.app.world())
                {
                    if is_in_world(self.app.world()) {
                        self.app
                            .world_mut()
                            .resource_mut::<RuntimeQueueResource>()
                            .pending_movement_command = None;
                    }
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if is_in_world(self.app.world())
                    && !crystal_packet_action_ready(self.app.world(), PlayerActionKind::Move)
                {
                    queue_crystal_movement_retry(self.app.world_mut(), direction, true);
                    return Vec::new();
                }
                if is_in_world(self.app.world()) {
                    let delay_ticks = crystal_packet_move_delay_ticks(true)
                        + if crystal_player_slowed_by_status(self.app.world()) {
                            1
                        } else {
                            0
                        };
                    mark_crystal_packet_action(
                        self.app.world_mut(),
                        PlayerActionKind::Move,
                        delay_ticks,
                    );
                }
                self.move_player_by_direction(direction, true)
            }
            ClientPacket::Chat {
                message,
                linked_items,
            } => handle_chat_packet(self.app.world_mut(), message, linked_items),
            ClientPacket::MoveItem { grid, from, to } => {
                move_item_impl(self.app.world_mut(), grid, from, to)
            }
            ClientPacket::StoreItem { from, to } => store_item_impl(self.app.world_mut(), from, to),
            ClientPacket::TakeBackItem { from, to } => {
                take_back_item_impl(self.app.world_mut(), from, to)
            }
            ClientPacket::StoreItemV2 {
                request_id,
                from,
                to,
            } => {
                if !mir2_protocol::is_valid_request_id(&request_id) {
                    Vec::new()
                } else {
                    store_item_impl(self.app.world_mut(), from, to)
                        .into_iter()
                        .map(|packet| match packet {
                            ServerPacket::StoreItem { from, to, success } => {
                                ServerPacket::StoreItemV2 {
                                    request_id: request_id.clone(),
                                    from,
                                    to,
                                    success,
                                }
                            }
                            other => other,
                        })
                        .collect()
                }
            }
            ClientPacket::TakeBackItemV2 {
                request_id,
                from,
                to,
            } => {
                if !mir2_protocol::is_valid_request_id(&request_id) {
                    Vec::new()
                } else {
                    take_back_item_impl(self.app.world_mut(), from, to)
                        .into_iter()
                        .map(|packet| match packet {
                            ServerPacket::TakeBackItem { from, to, success } => {
                                ServerPacket::TakeBackItemV2 {
                                    request_id: request_id.clone(),
                                    from,
                                    to,
                                    success,
                                }
                            }
                            other => other,
                        })
                        .collect()
                }
            }
            ClientPacket::MergeItem {
                grid_from,
                grid_to,
                id_from,
                id_to,
            } => merge_item_impl(self.app.world_mut(), grid_from, grid_to, id_from, id_to),
            ClientPacket::EquipItem {
                grid,
                unique_id,
                to,
            } => self.equip_item_packet_impl(grid, unique_id, to),
            ClientPacket::RemoveItem {
                grid,
                unique_id,
                to,
            } => remove_equipped_item_impl(self.app.world_mut(), grid, unique_id, to),
            ClientPacket::RemoveSlotItem {
                grid,
                grid_to,
                unique_id,
                to,
                from_unique_id,
            } => remove_equipped_slot_item_impl(
                self.app.world_mut(),
                grid,
                grid_to,
                unique_id,
                to,
                from_unique_id,
            ),
            ClientPacket::EquipSlotItem {
                grid,
                unique_id,
                to,
                grid_to,
                to_unique_id,
            } => equip_slot_item_impl(
                self.app.world_mut(),
                grid,
                unique_id,
                to,
                grid_to,
                to_unique_id,
            ),
            ClientPacket::SplitItem {
                grid,
                unique_id,
                count,
            } => split_item_impl(self.app.world_mut(), grid, unique_id, count),
            ClientPacket::UseItem { unique_id, grid } => {
                if grid == MirGridType::HeroInventory {
                    return use_hero_inventory_item_packet(self.app.world_mut(), unique_id);
                }
                if grid == MirGridType::Equipment {
                    return use_item(self.app.world_mut(), "", Some((unique_id, grid)));
                }
                if let Some(packets) = use_original_script_item_packet(self.app.world_mut(),unique_id,grid) {
                    return packets;
                }
                let key = item_key_for_client_reference(self.app.world(), unique_id, grid);
                match key {
                    Some(key) => use_item(self.app.world_mut(), &key, Some((unique_id, grid))),
                    None => vec![ServerPacket::UseItem {
                        unique_id,
                        success: false,
                        grid,
                    }],
                }
            }
            ClientPacket::DropItem {
                unique_id,
                count,
                hero_inventory,
            } => drop_item_packet(self.app.world_mut(), unique_id, count, hero_inventory),
            ClientPacket::DeleteItem {
                unique_id,
                count,
                hero_inventory,
            } => delete_item_impl(self.app.world_mut(), unique_id, count, hero_inventory),
            ClientPacket::DropGold { amount } => drop_gold_impl(self.app.world_mut(), amount),
            ClientPacket::PickUp => pick_up_current_cell_ground_drop(self.app.world_mut()),
            ClientPacket::RequestItemInfo { item_index } => request_item_info_impl(item_index),
            ClientPacket::Attack { direction, spell } => {
                if current_player_is_dead(self.app.world())
                    || crystal_player_attack_blocked_by_status(self.app.world())
                {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if is_in_world(self.app.world())
                    && melee_target_is_authoritatively_attackable_in_direction(
                        self.app.world(),
                        direction,
                        spell,
                    ) == Some(false)
                {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if is_in_world(self.app.world())
                    && !crystal_packet_action_ready(self.app.world(), PlayerActionKind::Attack)
                {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if is_in_world(self.app.world()) {
                    let delay_ticks = crystal_packet_attack_delay_ticks()
                        + if crystal_player_slowed_by_status(self.app.world()) {
                            1
                        } else {
                            0
                        };
                    mark_crystal_packet_action(
                        self.app.world_mut(),
                        PlayerActionKind::Attack,
                        delay_ticks,
                    );
                }
                self.attack_in_direction_with_spell(direction, spell)
            }
            ClientPacket::RangeAttack {
                direction,
                target_id,
                target_location,
                ..
            } => {
                if current_player_is_dead(self.app.world())
                    || crystal_player_attack_blocked_by_status(self.app.world())
                {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if is_in_world(self.app.world())
                    && !crystal_packet_action_ready(self.app.world(), PlayerActionKind::Attack)
                {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if is_in_world(self.app.world()) {
                    let delay_ticks = crystal_packet_attack_delay_ticks()
                        + if crystal_player_slowed_by_status(self.app.world()) {
                            1
                        } else {
                            0
                        };
                    mark_crystal_packet_action(
                        self.app.world_mut(),
                        PlayerActionKind::Attack,
                        delay_ticks,
                    );
                }
                self.range_attack_impl(direction, target_id, target_location)
            }
            ClientPacket::Harvest { direction } => self.harvest_impl(direction),
            ClientPacket::CallNpc { object_id, key } => {
                if object_id == u32::MAX {
                    if is_in_world(self.app.world()) && strict_active_account_authorization(self.app.world()).is_some() && key.len() <= 30 {
                        let _ = super::default_npc_events::enqueue(self.app.world_mut(),super::default_npc_events::DefaultNpcEvent::Client);
                    }
                    return Vec::new();
                }
                if object_id == 0 {
                    return match super::default_npc_events::follow_up(self.app.world_mut(),&key) {
                        Ok(Some(packets)) => packets,
                        Ok(None) => Vec::new(),
                        Err(error) => { super::shared_guild_experience::reject_source(self.app.world(),error); Vec::new() }
                    };
                }
                self.call_npc_impl(object_id, &key)
            }
            ClientPacket::NpcConfirmInput {
                npc_id,
                page_name,
                value,
            } => self.confirm_npc_input_impl(npc_id, &page_name, &value),
            ClientPacket::BuyItem {
                item_index,
                count,
                panel_type,
            } => self.try_shared_conquest_buy(item_index, count, panel_type)
                .unwrap_or_else(|| buy_item_impl(self.app.world_mut(), item_index, count, panel_type)),
            ClientPacket::SellItem { unique_id, count } => {
                self.try_shared_conquest_sell(unique_id, count)
                    .unwrap_or_else(|| sell_item_impl(self.app.world_mut(), unique_id, count))
            }
            ClientPacket::RepairItem { unique_id } => prepend_packet(
                ServerPacket::RepairItem { unique_id },
                repair_item_impl(self.app.world_mut(), unique_id, false),
            ),
            ClientPacket::SRepairItem { unique_id } => prepend_packet(
                ServerPacket::RepairItem { unique_id },
                repair_item_impl(self.app.world_mut(), unique_id, true),
            ),
            ClientPacket::MagicKey {
                spell,
                key,
                old_key,
            } => {
                if is_in_world(self.app.world()) {
                    assign_magic_key(self.app.world_mut(), spell, key, old_key);
                }
                Vec::new()
            }
            ClientPacket::Magic {
                object_id,
                spell,
                direction,
                target_id,
                location,
                ..
            } => {
                if !is_in_world(self.app.world()) {
                    return Vec::new();
                }
                if Some(object_id) == current_hero_object_id(self.app.world()) {
                    return super::hero_ai::hero_cast::manual_magic(self.app.world_mut(),object_id,spell,direction,target_id,location);
                }
                if object_id != 0 && Some(object_id) != current_player_object_id(self.app.world()) {
                    return Vec::new();
                }
                if current_player_is_dead(self.app.world())
                    || crystal_player_magic_blocked_by_status(self.app.world())
                {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                let Some(skill_key) = skill_key_for_crystal_spell(spell) else {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                };
                if !crystal_packet_action_ready(self.app.world(), PlayerActionKind::Spell) {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                if let Some(player) = player_entity(self.app.world()) {
                    self.app
                        .world_mut()
                        .entity_mut(player)
                        .insert(Facing(direction));
                }
                let packets = cast_skill_with_context(
                    self.app.world_mut(),
                    &skill_key,
                    Some(SkillCastContext {
                        direction,
                        target_id,
                        target: location,
                    }),
                );
                if packets.is_empty() {
                    return vec![ServerPacket::UserLocation {
                        location: current_location(self.app.world()),
                    }];
                }
                mark_crystal_packet_action(
                    self.app.world_mut(),
                    PlayerActionKind::Spell,
                    crystal_packet_spell_delay_ticks(),
                );
                let mut response = vec![ServerPacket::UserLocation {
                    location: current_location(self.app.world()),
                }];
                response.extend(packets);
                response
            }
            ClientPacket::SpellToggle {
                spell,
                toggle_state,
            } => stage5_spell_toggle_packet(self.app.world_mut(), spell, toggle_state),
            ClientPacket::SetHeroBehaviour { behaviour } => {
                let mut resources = self.app.world_mut().resource_mut::<Stage5SystemsResource>();
                let Some(hero) = resources.stage5_systems.hero.as_mut() else {
                    return Vec::new();
                };
                if hero.behaviour == behaviour {
                    return Vec::new();
                }
                hero.behaviour = behaviour;
                vec![ServerPacket::SetHeroBehaviour { behaviour }]
            }
            ClientPacket::ChangeHero { list_index } => {
                if self
                    .app
                    .world()
                    .resource::<Stage5SystemsResource>()
                    .stage5_systems
                    .hero
                    .is_none()
                {
                    return Vec::new();
                }
                let hero_can_spawn = !current_map_disallows_hero(self.app.world());
                if let Some(hero) = self
                    .app
                    .world_mut()
                    .resource_mut::<Stage5SystemsResource>()
                    .stage5_systems
                    .hero
                    .as_mut()
                {
                    hero.spawned = hero_can_spawn;
                }
                if hero_can_spawn {
                    let _ = spawn_stage5_hero(self.app.world_mut());
                }
                let state = stage5_hero_spawn_state(
                    self.app
                        .world()
                        .resource::<Stage5SystemsResource>()
                        .stage5_systems
                        .hero
                        .as_ref(),
                );
                let mut packets = vec![
                    ServerPacket::ChangeHero {
                        from_index: list_index,
                    },
                    stage5_manage_heroes_packet(self.app.world()),
                    ServerPacket::UpdateHeroSpawnState { state },
                ];
                if let Some(info) = stage5_hero_information_packet(self.app.world()) {
                    packets.push(info);
                }
                if !hero_can_spawn {
                    packets.push(system_message_key(
                        self.app.world(),
                        "server.CannotSummonHeroOnMap",
                    ));
                }
                packets
            }
            ClientPacket::CombineItem {
                grid,
                id_from,
                id_to,
            } => combine_item_impl(self.app.world_mut(), grid, id_from, id_to),
        }
    }

    pub(super) fn finalize_packets(&mut self, packets: Vec<ServerPacket>) -> Vec<ServerPacket> {
        if !is_in_world(self.app.world()) {
            self.visible_objects.clear();
            return packets;
        }

        let next_visible = collect_visible_objects(self.app.world());
        let next_object_ids = next_visible.keys().copied().collect::<BTreeSet<_>>();
        let previous_visible = self.visible_objects.clone();
        let self_object_id = current_player_object_id(self.app.world());
        let mut final_packets = Vec::new();

        for object_id in next_object_ids.difference(&previous_visible) {
            let bundle = next_visible
                .get(object_id)
                .expect("visible object bundle should exist");
            final_packets.push(bundle.spawn_packet.clone());
            if let Some(health_packet) = &bundle.health_packet {
                final_packets.push(health_packet.clone());
            }
        }

        final_packets.extend(packets.into_iter().filter(|packet| {
            should_emit_object_packet(packet, &previous_visible, &next_object_ids, self_object_id)
        }));

        for object_id in previous_visible.difference(&next_object_ids) {
            final_packets.push(ServerPacket::ObjectRemove {
                object_id: *object_id,
            });
        }

        self.visible_objects = next_object_ids;
        final_packets
    }
}

#[cfg(test)]
mod game_shop_start_stock_tests {
    use super::*;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_store_path() -> std::path::PathBuf {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|duration| duration.as_nanos())
            .unwrap_or_default();
        std::env::temp_dir()
            .join(format!(
                "mir2-game-shop-start-stock-{}-{unique}",
                std::process::id()
            ))
            .join("accounts.json")
    }

    fn product(game_shop_index: i32) -> mir2_protocol::GameShopItem {
        crystal_game_shop_info_packet_payloads()
            .into_iter()
            .find_map(|payload| {
                match decode_crystal_payload(ServerPacketId::GameShopInfo, payload) {
                    ServerPacket::GameShopInfo { item, .. } if item.g_index == game_shop_index => {
                        Some(item)
                    }
                    _ => None,
                }
            })
            .expect("game-shop fixture product should exist")
    }

    #[test]
    fn reloaded_start_world_projects_individual_and_global_finite_stock() {
        let path = temp_store_path();
        let config = SimulationConfig::default().with_account_store_path(path.clone());
        {
            let mut store = config
                .account_store
                .lock()
                .expect("account store mutex should not be poisoned");
            store.game_shop_global_purchases.insert(2, 7);
            let save = store
                .accounts
                .get_mut("demo")
                .and_then(|account| account.saves.get_mut(&0))
                .expect("demo save should exist");
            let mut systems = Stage5SystemsState::default();
            systems.game_shop_individual_purchases.insert(1, 4);
            save.stage5_systems_json =
                Some(serde_json::to_string(&systems).expect("stage5 systems should encode"));
        }
        config
            .save_account_store()
            .expect("stock fixture should persist");

        let reloaded = SimulationConfig::default().with_account_store_path(path.clone());
        let mut session = SimulationSession::new(reloaded);
        session.handle_packet(ClientPacket::Login {
            account_id: "demo".to_string(),
            password: "demo".to_string(),
        });
        session.handle_packet(ClientPacket::StartGame { character_index: 0 });

        let mut individual = product(1);
        individual.stock = 10;
        individual.i_stock = true;
        let mut global = product(2);
        global.stock = 10;
        global.i_stock = false;
        let mut packets = vec![
            ServerPacket::GameShopInfo {
                item: individual,
                stock_level: 10,
            },
            ServerPacket::GameShopInfo {
                item: global,
                stock_level: 10,
            },
        ];
        apply_start_game_dynamic_game_shop_stock(session.app.world(), &mut packets);
        assert!(matches!(
            &packets[0],
            ServerPacket::GameShopInfo { stock_level: 6, .. }
        ));
        assert!(matches!(
            &packets[1],
            ServerPacket::GameShopInfo { stock_level: 3, .. }
        ));

        if let Some(parent) = path.parent() {
            let _ = std::fs::remove_dir_all(parent);
        }
    }

    #[test]
    fn checked_in_unlimited_start_packets_remain_byte_identical() {
        let session = SimulationSession::new(SimulationConfig::default());
        let mut packets = start_game_account_social_and_shop_packets();
        let before = packets
            .iter()
            .map(mir2_protocol::encode_server_packet)
            .collect::<Result<Vec<_>, _>>()
            .expect("start packets should encode");
        apply_start_game_dynamic_game_shop_stock(session.app.world(), &mut packets);
        let after = packets
            .iter()
            .map(mir2_protocol::encode_server_packet)
            .collect::<Result<Vec<_>, _>>()
            .expect("start packets should encode");
        assert_eq!(after, before);
        assert!(packets.iter().all(|packet| match packet {
            ServerPacket::GameShopInfo { item, stock_level } => {
                item.stock == 0 && *stock_level == 0
            }
            _ => true,
        }));
    }
}

#[cfg(test)]
mod mail_status_transaction_tests {
    use super::*;
    #[test]
    fn legacy_mail_projection_does_not_invent_a_send_timestamp() {
        let mail: Stage5MailMessage = serde_json::from_value(serde_json::json!({
            "id": 42, "from": "System", "to": "Scout", "subject": "Old mail",
            "body": "No persisted date", "gold": 0, "claimed": false, "deleted": false
        })).unwrap();
        let first = stage5_mail_to_client_mail(&mail);
        let again = stage5_mail_to_client_mail(&mail);
        assert_eq!(first.date_sent_binary_datetime, 0);
        assert_eq!(again.date_sent_binary_datetime, first.date_sent_binary_datetime);
        assert_eq!(again.mail_id, 42);
    }
    use crate::config::{
        deliver_stage5_system_mail, AccountStoreTransactionFault, Stage5MailDelivery,
        Stage5MailTargetKind,
    };
    use std::time::{SystemTime, UNIX_EPOCH};

    fn test_config(label: &str) -> (SimulationConfig, u32) {
        let suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock should be after unix epoch")
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "mir2-mail-status-unit-{label}-{}-{suffix}.json",
            std::process::id()
        ));
        let config = SimulationConfig::default().with_account_store_path(path);
        let receipt = deliver_stage5_system_mail(
            &config,
            Stage5MailDelivery {
                target_kind: Stage5MailTargetKind::Character,
                target_id: "Scout".to_string(),
                from: "System".to_string(),
                subject: "Failure test".to_string(),
                body: "Must remain unchanged".to_string(),
                gold: 0,
                items: Vec::new(),
            },
        )
        .expect("mail fixture should persist");
        (config, receipt.mail_ids[0])
    }

    fn start_test_session(config: SimulationConfig) -> SimulationSession {
        let mut session = SimulationSession::new(config);
        assert!(session
            .handle_packet(ClientPacket::Login {
                account_id: "demo".to_string(),
                password: "demo".to_string(),
            })
            .iter()
            .any(|packet| matches!(packet, ServerPacket::LoginSuccess { .. })));
        assert!(session
            .handle_packet(ClientPacket::StartGame { character_index: 0 })
            .iter()
            .any(|packet| matches!(packet, ServerPacket::StartGame { result: 4, .. })));
        session
    }

    #[test]
    fn ordinary_multiline_mail_is_durable_and_preserves_the_body_verbatim() {
        let suffix = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system clock should be after unix epoch")
            .as_nanos();
        let dir = std::env::temp_dir().join(format!(
            "mir2-mail-multiline-unit-{}-{suffix}",
            std::process::id()
        ));
        let path = dir.join("accounts.json");
        let config = SimulationConfig::default().with_account_store_path(path.clone());
        deliver_stage5_system_mail(
            &config,
            Stage5MailDelivery {
                target_kind: Stage5MailTargetKind::Character,
                target_id: "Scout".to_string(),
                from: "System".to_string(),
                subject: "Fixture".to_string(),
                body: "fixture".to_string(),
                gold: 0,
                items: Vec::new(),
            },
        )
        .expect("temporary mail fixture should persist");

        let message = "first line\r\nsecond line\nthird line".to_string();
        let mut session = start_test_session(config);
        let packets = session.handle_packet(ClientPacket::SendMail {
            name: "Scout".to_string(),
            message: message.clone(),
            gold: 0,
            items_idx: [0; 5],
            stamped: false,
        });
        assert!(packets.iter().any(
            |packet| matches!(packet, ServerPacket::MailSent { result: 1 })
        ));
        assert!(packets.iter().any(|packet| {
            matches!(packet, ServerPacket::ReceiveMail { mail }
                if mail.iter().any(|entry| entry.sender_name == "Scout" && entry.message == message))
        }));
        drop(session);

        let reloaded = start_test_session(SimulationConfig::default().with_account_store_path(path));
        assert!(reloaded
            .world_snapshot()
            .stage5_systems
            .mail
            .iter()
            .any(|mail| mail.from == "Scout" && mail.body == message));
        drop(reloaded);
        let _ = std::fs::remove_dir_all(dir);
    }

    #[test]
    fn status_persist_failure_does_not_mutate_world_store_or_file() {
        for mutation in ["read", "lock", "delete"] {
            let (config, mail_id) = test_config(&format!("persist-failure-{mutation}"));
            let mut session = start_test_session(config.clone());
            let before_world = session.world_snapshot();
            let before_store = {
                let store = config
                    .account_store
                    .lock()
                    .expect("account store should not be poisoned");
                serde_json::to_value(&*store).expect("account store snapshot should serialize")
            };
            let account_store_path = config
                .account_store_path
                .as_deref()
                .expect("test config should have a file store");
            let before_file =
                std::fs::read(account_store_path).expect("account-store file should exist");

            config.inject_account_store_transaction_fault(AccountStoreTransactionFault::Persist);
            let command = match mutation {
                "read" => ClientPacket::ReadMail {
                    mail_id: u64::from(mail_id),
                },
                "lock" => ClientPacket::LockMail {
                    mail_id: u64::from(mail_id),
                    lock: true,
                },
                "delete" => ClientPacket::DeleteMail {
                    mail_id: u64::from(mail_id),
                },
                _ => unreachable!("fixed mail mutation fixture"),
            };
            let after = session.handle_packet(command);

            assert!(
                after.is_empty(),
                "Crystal-compatible persistence rejection must be silent for {mutation}: {after:?}"
            );
            assert_eq!(session.world_snapshot(), before_world);
            let after_store = {
                let store = config
                    .account_store
                    .lock()
                    .expect("account store should not be poisoned");
                serde_json::to_value(&*store).expect("account store snapshot should serialize")
            };
            assert_eq!(after_store, before_store);
            let after_file =
                std::fs::read(account_store_path).expect("account-store file should still exist");
            assert_eq!(after_file, before_file);
        }
    }
}
