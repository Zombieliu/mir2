param([Parameter(Mandatory=$true)][string]$LogStem,[Parameter(Mandatory=$true)][string[]]$CargoArgs)
$ErrorActionPreference='Stop'
$taskRoot='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p7-npc-world-20261009-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
New-Item -ItemType Directory -Path $taskEvidence -Force | Out-Null
Set-Location -LiteralPath $taskRoot
$taskPaths=@('apps/simulation/src/runtime/mod.rs','apps/simulation/src/runtime/zone/mod.rs','apps/simulation/src/runtime/npc_world_plan.rs','apps/simulation/src/runtime/npc_script.rs','apps/simulation/src/runtime/shared_guild_experience.rs','apps/simulation/src/runtime/prepared_kill_experience.rs','apps/simulation/src/runtime/default_npc_events_tests.rs','apps/simulation/src/runtime/npc_source_guard_tests.rs','apps/simulation/src/config.rs','apps/simulation/src/runtime/save.rs','apps/simulation/src/runtime/packets.rs','apps/simulation/src/world_runtime.rs','apps/gateway/src/routing.rs')
if (Test-Path -LiteralPath "$taskEvidence/$LogStem.log") { throw 'Evidence stem already exists' }
function Write-SourceHashes([string]$phase) {
 $taskHashes=@($taskPaths | Where-Object { Test-Path -LiteralPath $_ } | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
 [ordered]@{declaredBaseSource='c70436f34eabb432d769e0082c0afa23303294b0';utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=@('cargo','+1.95.0')+$CargoArgs;source=$taskHashes} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding UTF8
}
Write-SourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& cargo +1.95.0 @CargoArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Write-SourceHashes 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;log="$taskEvidence/$LogStem.log"} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 38
exit $taskExit
