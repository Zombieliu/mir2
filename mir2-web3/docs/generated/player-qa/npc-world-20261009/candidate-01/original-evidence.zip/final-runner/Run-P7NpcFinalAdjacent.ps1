$ErrorActionPreference='Stop'
$taskRunner='E:/mir2-player-journey/tmp/Run-P7NpcWorldRoot.ps1'
& $taskRunner -LogStem '15-root-final-source-guard' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--lib','npc_source_guard_tests::','--','--test-threads=1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskRunner -LogStem '16-root-final-default-source-events' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--lib','default_npc_events_tests::','--','--test-threads=1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskRunner -LogStem '17-root-final-refine-durable' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--lib','refine_durable_tests::','--','--test-threads=1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskRunner -LogStem '18-root-final-security-source-entry' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--test','security_lifecycle','--','--test-threads=1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $taskRunner -LogStem '19-root-final-ordered-pet-plan' -CargoArgs @('test','--offline','--locked','-p','mir2-simulation','--lib','npc_world_plan::tests','--','--test-threads=1')
exit $LASTEXITCODE
