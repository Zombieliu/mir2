//! Windows-only authoritative entity animation presentation.
//!
//! Gateway packets remain authoritative for object state. This resource owns
//! only the client-side Crystal frame clock, keeping stable action state between
//! network snapshots and producing updated atlas rects only when a visual frame
//! or authoritative payload actually changes.

use std::collections::{HashMap, HashSet};
use std::time::{SystemTime, UNIX_EPOCH};

use bevy::prelude::{Query, Res, ResMut, Resource, Time, Window, With};
use bevy::window::PrimaryWindow;
use mir2_bevy_runtime::entity_animation::{
    AnimationAction, AnimationCatalog, AnimationEvent, AnimationWorld, Direction, EntityKind,
    QueueDisposition, TransitionReason,
};
use serde_json::Value;

#[cfg(test)]
#[path = "mining_visual_tests.rs"]
mod mining_visual_tests;

#[cfg(test)]
#[path = "buried_monster_replay_tests.rs"]
mod buried_monster_replay_tests;

const NATIVE_ANIMATION_WORLD_SEED: u64 = 0x4d49_5232_5749_4e44;
const CRYSTAL_MOVE_PHASE_COUNT: u16 = 6;
const CRYSTAL_MOVE_PHASE_MS: u64 = 100;
const MAX_SMOOTH_TILE_DISTANCE: u32 = 3;
const MAX_NATIVE_MOVE_PHASE_COUNT: u16 = 8;

const SABUK_GATE_BLOCKING_OFFSETS: &[(i32, i32)] = &[
    (0, 0),
    (0, -1),
    (0, -2),
    (1, -1),
    (1, -2),
    (-1, 0),
    (-2, 0),
    (-1, -1),
    (-1, 1),
];

// Collision checks and failed-route invalidation must use the same footprint.
// In particular AI81's open gate has no occupied cells, even at its center.
fn entity_movement_footprint(
    entity: &Value,
    map: Option<&str>,
    self_object_id: &str,
    point: Option<(i32, i32)>,
) -> Option<((i32, i32), &'static [(i32, i32)])> {
    let kind = entity.get("kind").and_then(Value::as_str);
    let is_sabuk_gate = kind == Some("monster")
        && map.is_some_and(|map| map.trim_end_matches(".map").eq_ignore_ascii_case("3"))
        && entity.get("ai").and_then(Value::as_u64) == Some(81)
        && entity.get("image").and_then(Value::as_u64) == Some(950)
        && entity.get("name").and_then(Value::as_str) == Some("SabukGate")
        && entity.get("x").and_then(Value::as_i64) == Some(672)
        && entity.get("y").and_then(Value::as_i64) == Some(330);
    if is_sabuk_gate {
        if entity.get("dead").and_then(Value::as_bool) == Some(true)
            || entity
                .get("direction")
                .and_then(Value::as_str)
                .is_some_and(|direction| direction.eq_ignore_ascii_case("left"))
        {
            return None;
        }
        return Some(((672, 330), SABUK_GATE_BLOCKING_OFFSETS));
    }
    // A* asks about one tile at a time. Reject other ordinary coordinates
    // before allocating an object ID string or constructing a footprint.
    // The signature caller passes None and collects every occupied cell once.
    if point.is_some_and(|point| {
        entity.get("x").and_then(Value::as_i64) != Some(i64::from(point.0))
            || entity.get("y").and_then(Value::as_i64) != Some(i64::from(point.1))
    }) || !matches!(kind, Some("selfPlayer" | "player" | "monster" | "npc"))
        || entity.get("dead").and_then(Value::as_bool) == Some(true)
        || entity.get("objectId").and_then(value_object_id).as_deref() == Some(self_object_id)
    {
        return None;
    }
    Some((
        (
            i32::try_from(entity.get("x")?.as_i64()?).ok()?,
            i32::try_from(entity.get("y")?.as_i64()?).ok()?,
        ),
        &[(0, 0)],
    ))
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct NativeMotionWindow {
    from_x: f32,
    from_y: f32,
    to_x: f32,
    to_y: f32,
    /// Crystal keeps `MapLocation` at the source cell until the movement
    /// action completes even though `CurrentLocation` already contains the
    /// destination. Use the same integer anchor for y-sort depth while the
    /// visual position advances through the movement phases.
    sort_x: i32,
    sort_y: i32,
    started_ms: u64,
    expires_ms: u64,
    phase_count: u16,
    animation_sequence: u64,
    action: AnimationAction,
    direction: Direction,
    locally_predicted: bool,
    locally_settled: bool,
}

#[derive(Debug)]
struct ObservedEntity {
    object_id: String,
    kind: EntityKind,
    body_library: String,
    mounted: bool,
    direction: Direction,
    action: Option<(u64, AnimationAction)>,
    initially_dead: bool,
    initially_skeleton: bool,
}

#[derive(Resource, Debug)]
pub struct NativeEntityPresentation {
    world: AnimationWorld,
    latest_payload: Option<Value>,
    pending_payload: Option<Value>,
    /// Packet-adapter numbers are independent of locally predicted actions.
    last_source_sequence: HashMap<String, u64>,
    /// Monotonic AnimationWorld numbers include both packets and predictions.
    last_applied_sequence: HashMap<String, u64>,
    last_libraries: HashMap<String, String>,
    last_frames: HashMap<String, (i64, AnimationAction)>,
    hidden_after_hide: HashSet<String>,
    last_effect_visible: Option<bool>,
    hover_cursor_stage: Option<(f32, f32)>,
    highlight_target: bool,
    local_selected_object_id: Option<String>,
    hovered_object_id: Option<String>,
    self_hovered: bool,
    self_object_id: Option<String>,
    last_positions: HashMap<String, (i32, i32)>,
    motion_windows: HashMap<String, NativeMotionWindow>,
    last_attack_motion_overlap: Option<(u64, u64)>,
    local_mining_request: Option<LocalMiningRequest>,
    payload_dirty: bool,
}

#[derive(Debug)]
struct LocalMiningRequest {
    object_id: String,
    map_file: String,
    origin: (i32, i32),
    direction: String,
    source_sequence_floor: u64,
    expires_ms: u64,
}

impl Default for NativeEntityPresentation {
    fn default() -> Self {
        Self {
            world: AnimationWorld::new(NATIVE_ANIMATION_WORLD_SEED),
            latest_payload: None,
            pending_payload: None,
            last_source_sequence: HashMap::new(),
            last_applied_sequence: HashMap::new(),
            last_libraries: HashMap::new(),
            last_frames: HashMap::new(),
            hidden_after_hide: HashSet::new(),
            last_effect_visible: None,
            hover_cursor_stage: None,
            highlight_target: true,
            local_selected_object_id: None,
            hovered_object_id: None,
            self_hovered: false,
            self_object_id: None,
            last_positions: HashMap::new(),
            motion_windows: HashMap::new(),
            last_attack_motion_overlap: None,
            local_mining_request: None,
            payload_dirty: false,
        }
    }
}

impl NativeEntityPresentation {
    pub fn reset_session(&mut self) {
        mir2_bevy_runtime::clear_mir2_self_camera_motion();
        *self = Self::default();
    }

    pub fn replace_payload(&mut self, payload: Value) {
        self.pending_payload = Some(payload);
    }

    /// Admit packet actions in arrival order, even when several projections
    /// arrive before the next render. Rendering still publishes only the final
    /// scene, while the existing per-actor ActionFeed retains combat actions.
    pub(crate) fn observe_packet_payload(&mut self, payload: Value, now_ms: u64) {
        self.replace_payload(payload);
        self.sync_pending_payload(now_ms, native_motion_clock_ms());
    }

    pub(crate) fn hovered_object_id(&self) -> Option<&str> {
        self.hovered_object_id.as_deref()
    }

    pub(crate) fn self_hovered(&self) -> bool {
        self.self_hovered
    }

    pub(crate) fn hovered_grid_position(&self) -> Option<(i32, i32)> {
        self.grid_position_for_stage(self.hover_cursor_stage?)
    }

    pub(crate) fn grid_position_for_stage(
        &self,
        (cursor_x, cursor_y): (f32, f32),
    ) -> Option<(i32, i32)> {
        if !(0.0..1024.0).contains(&cursor_x) || !(0.0..768.0).contains(&cursor_y) {
            return None;
        }
        let center = self
            .latest_payload
            .as_ref()?
            .get("sceneView")?
            .get("center")?;
        let center_x = center
            .get("x")
            .and_then(Value::as_i64)
            .and_then(|value| i32::try_from(value).ok())?;
        let center_y = center
            .get("y")
            .and_then(Value::as_i64)
            .and_then(|value| i32::try_from(value).ok())?;
        Some((
            center_x + (cursor_x / 48.0).floor() as i32 - 10,
            center_y + (cursor_y / 32.0).floor() as i32 - 11,
        ))
    }

    pub(crate) fn magic_target_flags(&self, object_id: &str) -> (bool, u32, u8) {
        let entity = self
            .latest_payload
            .as_ref()
            .and_then(|p| p.get("entities"))
            .and_then(Value::as_array)
            .and_then(|all| {
                all.iter().find(|e| {
                    e.get("objectId").and_then(value_object_id).as_deref() == Some(object_id)
                })
            });
        entity
            .map(|e| {
                (
                    e.get("dead").and_then(Value::as_bool) == Some(true),
                    e.get("masterObjectId").and_then(Value::as_u64).unwrap_or(0) as u32,
                    e.get("ai").and_then(Value::as_u64).unwrap_or(0) as u8,
                )
            })
            .unwrap_or_default()
    }

    pub(crate) fn hover_cursor_stage(&self) -> Option<(f32, f32)> {
        self.hover_cursor_stage
    }

    pub(crate) fn current_map_file_name(&self) -> Option<&str> {
        self.latest_payload.as_ref()?.get("mapFileName")?.as_str()
    }

    pub(crate) fn mark_local_mining_request(
        &mut self,
        object_id: &str,
        origin: (i32, i32),
        direction: &str,
        now_ms: u64,
    ) {
        let Some(map_file) = self.current_map_file_name().map(str::to_owned) else {
            return;
        };
        self.local_mining_request = Some(LocalMiningRequest {
            object_id: object_id.to_owned(),
            map_file,
            origin,
            direction: direction.to_owned(),
            source_sequence_floor: self
                .last_source_sequence
                .get(object_id)
                .copied()
                .unwrap_or(0),
            expires_ms: now_ms.saturating_add(3_000),
        });
    }

    pub(crate) fn clear_local_mining_request(&mut self) {
        self.local_mining_request = None;
    }

    fn map_confirmed_local_mine(&mut self, payload: &mut Value, now_ms: u64) {
        let Some(request) = self.local_mining_request.as_ref() else {
            return;
        };
        if now_ms >= request.expires_ms
            || payload.get("mapFileName").and_then(Value::as_str) != Some(request.map_file.as_str())
        {
            self.local_mining_request = None;
            return;
        }
        let Some(owner) = payload
            .get_mut("entities")
            .and_then(Value::as_array_mut)
            .and_then(|entities| {
                entities.iter_mut().find(|entity| {
                    entity.get("kind").and_then(Value::as_str) == Some("selfPlayer")
                        && entity.get("objectId").and_then(value_object_id).as_deref()
                            == Some(request.object_id.as_str())
                })
            })
        else {
            return;
        };
        let position = owner
            .get("x")
            .and_then(Value::as_i64)
            .zip(owner.get("y").and_then(Value::as_i64));
        if position != Some((i64::from(request.origin.0), i64::from(request.origin.1)))
            || owner.get("dead").and_then(Value::as_bool) == Some(true)
        {
            self.local_mining_request = None;
            return;
        }
        if owner.get("_nativeAnimationAction").and_then(Value::as_str) == Some("attack1")
            && owner.get("direction").and_then(Value::as_str) == Some(request.direction.as_str())
            && owner
                .get("_nativeAnimationSequence")
                .and_then(Value::as_u64)
                .is_some_and(|sequence| sequence > request.source_sequence_floor)
        {
            // Crystal's own Mine action uses the exact Attack2 body/weapon
            // frames. Observers still consume ordinary ObjectAttack(None).
            owner["_nativeAnimationAction"] = Value::String("mine".into());
            self.local_mining_request = None;
        }
    }

    /// Packet payload after native movement reconciliation.
    ///
    /// The Windows overlay layer must read the same corrected entity/grid
    /// coordinates that produced the retained sprite scene. Reading the raw
    /// gameplay clone can leave the self name and health bar on a stale source
    /// tile while the body has already accepted the next run segment.
    pub(crate) fn overlay_payload(&self) -> Option<&Value> {
        self.latest_payload.as_ref()
    }

    /// Crystal runs three cells while mounted or while Swift Feet is active;
    /// ordinary running remains two cells. This mirrors authoritative packet
    /// state strictly for presentation prediction—the Zone still validates the
    /// actual distance and corrects stale client state.
    pub(crate) fn self_equipment_pose(&self, object_id: &str) -> Option<(bool, i16)> {
        let standing = self
            .world
            .active_states()
            .find(|(id, _)| *id == object_id)
            .map(|(_, state)| state.pose().action == AnimationAction::Standing)?;
        let entity = self
            .latest_payload
            .as_ref()?
            .get("entities")?
            .as_array()?
            .iter()
            .find(|e| e.get("objectId").and_then(value_object_id).as_deref() == Some(object_id))?;
        Some((
            standing,
            entity
                .get("transformType")
                .and_then(Value::as_i64)
                .and_then(|n| i16::try_from(n).ok())
                .unwrap_or(-1),
        ))
    }

    pub(crate) fn self_run_distance(&self, object_id: &str) -> i32 {
        let Some(entity) = self
            .latest_payload
            .as_ref()
            .and_then(|payload| payload.get("entities"))
            .and_then(Value::as_array)
            .and_then(|entities| {
                entities.iter().find(|entity| {
                    entity.get("objectId").and_then(value_object_id).as_deref() == Some(object_id)
                        && entity.get("kind").and_then(Value::as_str) == Some("selfPlayer")
                })
            })
        else {
            return 2;
        };
        let mounted = entity.get("ridingMount").and_then(Value::as_bool) == Some(true);
        let sneaking = entity
            .get("sneakingActive")
            .or_else(|| entity.get("sneaking"))
            .and_then(Value::as_bool)
            == Some(true);
        let swift_feet = !sneaking
            && entity
                .get("buffs")
                .and_then(Value::as_array)
                .is_some_and(|buffs| buffs.iter().any(|buff| buff.as_i64() == Some(102)));
        if mounted || swift_feet {
            3
        } else {
            2
        }
    }

    pub(crate) fn self_motion_duration_ms(&self, object_id: &str, running: bool) -> Option<u64> {
        let entity = self
            .latest_payload
            .as_ref()?
            .get("entities")?
            .as_array()?
            .iter()
            .find(|entity| {
                entity.get("objectId").and_then(value_object_id).as_deref() == Some(object_id)
                    && entity.get("kind").and_then(Value::as_str) == Some("selfPlayer")
            })?;
        let action = if running {
            AnimationAction::Running
        } else {
            AnimationAction::Walking
        };
        Some(u64::from(native_motion_phase_count(entity, action)) * CRYSTAL_MOVE_PHASE_MS)
    }

    pub(crate) fn tile_has_blocking_entity(
        &self,
        self_object_id: &str,
        point: (i32, i32),
    ) -> Option<bool> {
        let entities = self.latest_payload.as_ref()?.get("entities")?.as_array()?;
        Some(entities.iter().any(|entity| {
            entity_movement_footprint(
                entity,
                self.current_map_file_name(),
                self_object_id,
                Some(point),
            )
            .is_some_and(|((x, y), offsets)| {
                offsets.iter().any(|(dx, dy)| point == (x + dx, y + dy))
            })
        }))
    }

    /// Exact occupied cells, independent of animation, health and packet order.
    /// Constructed once per failed-route comparison rather than per A* node.
    pub(crate) fn movement_blocking_cells(&self, self_object_id: &str) -> Option<Vec<(i32, i32)>> {
        let entities = self.latest_payload.as_ref()?.get("entities")?.as_array()?;
        let mut cells = Vec::with_capacity(entities.len());
        for entity in entities {
            if let Some(((x, y), offsets)) = entity_movement_footprint(
                entity,
                self.current_map_file_name(),
                self_object_id,
                None,
            ) {
                cells.extend(offsets.iter().map(|(dx, dy)| (x + dx, y + dy)));
            }
        }
        cells.sort_unstable();
        cells.dedup();
        Some(cells)
    }

    pub(crate) fn has_active_motion(&self, now_ms: u64) -> bool {
        self.motion_windows
            .values()
            .any(|window| now_ms < window.expires_ms)
    }

    pub(crate) fn self_motion_remaining_ms(&self, now_ms: u64) -> u64 {
        self.self_object_id
            .as_deref()
            .and_then(|object_id| self.motion_windows.get(object_id))
            .map_or(0, |window| window.expires_ms.saturating_sub(now_ms))
    }

    /// Read the existing action clock without advancing or changing its feed.
    /// A new movement prediction must wait for admitted combat/life actions,
    /// including those still behind a movement or hit reaction. Struck alone
    /// remains replaceable by the existing latest-locomotion reducer.
    pub(crate) fn self_combat_action_blocks_movement(&self, object_id: &str) -> bool {
        self.world.active_state(object_id).is_some_and(|state| {
            std::iter::once(state.current_action)
                .chain(state.queued_actions().map(|event| event.action))
                .any(|action| {
                    is_attack_action(action)
                        || matches!(
                            action,
                            AnimationAction::Spell
                                | AnimationAction::Die
                                | AnimationAction::Dead
                                | AnimationAction::Skeleton
                                | AnimationAction::Revive
                        )
                })
        })
    }

    pub(crate) fn has_active_non_self_motion(&self, now_ms: u64) -> bool {
        self.motion_windows.iter().any(|(object_id, window)| {
            self.self_object_id.as_deref() != Some(object_id.as_str()) && now_ms < window.expires_ms
        })
    }

    pub(crate) fn camera_screen_offset(&self, now_ms: u64) -> (f32, f32) {
        self.self_object_id
            .as_deref()
            .and_then(|object_id| self.motion_windows.get(object_id))
            .map(|window| native_motion_offset(window, now_ms))
            .map(|(x, y)| (-x, -y))
            .unwrap_or((0.0, 0.0))
    }

    pub(crate) fn entity_screen_offset(&self, object_id: &str, now_ms: u64) -> (f32, f32) {
        let (camera_x, camera_y) = self.camera_screen_offset(now_ms);
        let (entity_x, entity_y) = self
            .motion_windows
            .get(object_id)
            .map(|window| native_motion_offset(window, now_ms))
            .unwrap_or((0.0, 0.0));
        (entity_x + camera_x, entity_y + camera_y)
    }

    /// Start a bounded self-only presentation window as soon as Windows has
    /// successfully queued a movement intent. This changes animation pixels
    /// and sub-cell presentation only; the authoritative entity/read-model
    /// tile remains untouched until `UserLocation` arrives.
    pub(crate) fn begin_local_self_motion(
        &mut self,
        object_id: &str,
        from: (i32, i32),
        to: (i32, i32),
        direction: &str,
        running: bool,
        animation_now_ms: u64,
        motion_now_ms: u64,
    ) -> bool {
        if from == to {
            return false;
        }
        let action = if running {
            AnimationAction::Running
        } else {
            AnimationAction::Walking
        };
        let direction = parse_direction(direction);
        let Some(entity) = self
            .latest_payload
            .as_ref()
            .and_then(|payload| payload.get("entities"))
            .and_then(Value::as_array)
            .and_then(|entities| {
                entities.iter().find(|entity| {
                    entity.get("objectId").and_then(value_object_id).as_deref() == Some(object_id)
                        && entity.get("kind").and_then(Value::as_str) == Some("selfPlayer")
                })
            })
        else {
            return false;
        };
        let phase_count = native_motion_phase_count(entity, action);
        let Some((key, previous_pose)) = self
            .world
            .active_state(object_id)
            .map(|state| (state.key.clone(), state.pose()))
        else {
            return false;
        };
        let animation_sequence = self
            .last_applied_sequence
            .get(object_id)
            .copied()
            .unwrap_or(0)
            .saturating_add(1);
        let Ok(update) = self.world.apply_latest_locomotion_event(
            &key,
            AnimationEvent::new(animation_sequence, action, direction),
            animation_now_ms,
        ) else {
            return false;
        };
        if update.disposition == QueueDisposition::Started
            && (previous_pose.action == AnimationAction::Struck || previous_pose.queue_depth > 0)
        {
            crate::movement_trace::record(serde_json::json!({
                "type": "selfEscapePresentationStarted",
                "objectId": object_id,
                "previousAction": format!("{:?}", previous_pose.action),
                "previousQueueDepth": previous_pose.queue_depth,
                "movementSequence": animation_sequence,
                "animationAtMs": animation_now_ms,
                "motionAtUnixMs": motion_now_ms,
            }));
        }
        self.last_applied_sequence
            .insert(object_id.to_owned(), animation_sequence);
        let expires_ms =
            motion_now_ms.saturating_add(u64::from(phase_count) * CRYSTAL_MOVE_PHASE_MS);
        self.motion_windows.insert(
            object_id.to_owned(),
            NativeMotionWindow {
                from_x: from.0 as f32,
                from_y: from.1 as f32,
                to_x: to.0 as f32,
                to_y: to.1 as f32,
                sort_x: from.0,
                sort_y: from.1,
                started_ms: motion_now_ms,
                expires_ms,
                phase_count,
                animation_sequence,
                action,
                direction,
                locally_predicted: true,
                locally_settled: false,
            },
        );
        self.self_object_id = Some(object_id.to_owned());
        // Publish the same command-time window to the shared runtime before
        // the authoritative ACK arrives. Windows previously relied on the
        // separate LocalCommand shadow for this interval, then switched to the
        // self window on ACK; that ownership hand-off made the whole scene
        // visibly flash during sustained running. One time window now owns
        // both the camera and the self sprite for the complete step.
        mir2_bevy_runtime::set_mir2_self_camera_motion(
            from.0 as f32,
            from.1 as f32,
            to.0 as f32,
            to.1 as f32,
            motion_now_ms as f64,
            expires_ms as f64,
        );
        if let Some(entity) = self
            .latest_payload
            .as_mut()
            .and_then(|payload| payload.get_mut("entities"))
            .and_then(Value::as_array_mut)
            .and_then(|entities| {
                entities.iter_mut().find(|entity| {
                    entity.get("objectId").and_then(value_object_id).as_deref() == Some(object_id)
                })
            })
        {
            entity["direction"] = Value::from(direction_name(direction));
        }
        self.payload_dirty = true;
        true
    }

    /// A correction may acknowledge the unchanged source tile. Remove only a
    /// still-local window; an authoritative window already built from the ACK
    /// must remain intact.
    pub(crate) fn cancel_local_self_prediction(
        &mut self,
        object_id: &str,
        authoritative_position: (i32, i32),
        authoritative_direction: &str,
    ) {
        if self
            .motion_windows
            .get(object_id)
            .is_some_and(|window| window.locally_predicted)
        {
            mir2_bevy_runtime::clear_mir2_self_camera_motion();
            self.motion_windows.remove(object_id);
            self.last_positions
                .insert(object_id.to_owned(), authoritative_position);
            if let Some(payload) = self.latest_payload.as_mut() {
                if let Some(entity) = payload
                    .get_mut("entities")
                    .and_then(Value::as_array_mut)
                    .and_then(|entities| {
                        entities.iter_mut().find(|entity| {
                            entity.get("objectId").and_then(value_object_id).as_deref()
                                == Some(object_id)
                        })
                    })
                {
                    entity["x"] = Value::from(authoritative_position.0);
                    entity["y"] = Value::from(authoritative_position.1);
                    entity["direction"] = Value::from(authoritative_direction);
                }
                if self.self_object_id.as_deref() == Some(object_id) {
                    if let Some(center) = payload
                        .get_mut("sceneView")
                        .and_then(|view| view.get_mut("center"))
                    {
                        center["x"] = Value::from(authoritative_position.0);
                        center["y"] = Value::from(authoritative_position.1);
                    }
                }
            }
            self.payload_dirty = true;
        }
    }

    #[cfg(test)]
    pub(crate) fn set_hovered_object_id_for_test(&mut self, object_id: Option<&str>) {
        self.hovered_object_id = object_id.map(ToOwned::to_owned);
    }

    #[cfg(test)]
    pub(crate) fn advance_animation_for_test(&mut self, now_ms: u64) {
        self.world
            .tick(now_ms)
            .expect("advance the unchanged Crystal animation clock");
    }

    #[cfg(test)]
    pub(crate) fn set_hover_grid_context_for_test(
        &mut self,
        center: (i32, i32),
        cursor_stage: (f32, f32),
    ) {
        self.latest_payload = Some(serde_json::json!({
            "sceneView": {"center": {"x": center.0, "y": center.1}}
        }));
        self.hover_cursor_stage = Some(cursor_stage);
    }

    /// Object ids whose client-side Crystal action clock has reached the
    /// terminal corpse pose. `dead=true` and the `Die` action are deliberately
    /// excluded: Crystal projectile completion callbacks suppress their impact
    /// only when `CurrentAction == MirAction.Dead`.
    pub(crate) fn dead_action_object_ids(&self) -> HashSet<u32> {
        self.world
            .active_states()
            .filter_map(|(object_id, state)| {
                (state.pose().action == AnimationAction::Dead)
                    .then(|| object_id.parse::<u32>().ok())
                    .flatten()
            })
            .collect()
    }

    fn set_hover_presentation(
        &mut self,
        hover_cursor_stage: Option<(f32, f32)>,
        highlight_target: bool,
    ) {
        if self.hover_cursor_stage != hover_cursor_stage
            || self.highlight_target != highlight_target
        {
            self.hover_cursor_stage = hover_cursor_stage;
            self.highlight_target = highlight_target;
            self.payload_dirty = true;
        }
    }

    fn set_local_selected_object_id(&mut self, object_id: Option<String>) {
        if self.local_selected_object_id != object_id {
            self.local_selected_object_id = object_id;
            self.payload_dirty = true;
        }
    }

    fn sync_pending_payload(&mut self, animation_now_ms: u64, motion_now_ms: u64) {
        self.sync_pending_payload_with_clocks(
            animation_now_ms,
            motion_now_ms,
            crate::frame_sets::animation_catalog_for,
        );
    }

    fn sync_pending_payload_with<F>(&mut self, now_ms: u64, catalog_for: F)
    where
        F: Fn(EntityKind, &str, bool) -> AnimationCatalog,
    {
        self.sync_pending_payload_with_clocks(now_ms, now_ms, catalog_for);
    }

    fn sync_pending_payload_with_clocks<F>(
        &mut self,
        animation_now_ms: u64,
        motion_now_ms: u64,
        catalog_for: F,
    ) where
        F: Fn(EntityKind, &str, bool) -> AnimationCatalog,
    {
        let Some(mut payload) = self.pending_payload.take() else {
            return;
        };
        self.map_confirmed_local_mine(&mut payload, motion_now_ms);
        // Source echoes can be normalized to the active predicted action by
        // motion reconciliation. Capture their adapter numbers beforehand so
        // a local animation number can never retire a later real packet.
        let source_sequences = payload
            .get("entities")
            .and_then(Value::as_array)
            .into_iter()
            .flatten()
            .filter_map(|entity| {
                entity
                    .get("_nativeAnimationAction")
                    .and_then(Value::as_str)
                    .and_then(parse_action)?;
                Some((
                    entity.get("objectId").and_then(value_object_id)?,
                    entity
                        .get("_nativeAnimationSequence")
                        .and_then(Value::as_u64)?,
                ))
            })
            .collect::<HashMap<_, _>>();
        let stale_source_echoes = self.attach_native_motion_windows(&mut payload, motion_now_ms);
        let observed = payload
            .get("entities")
            .and_then(Value::as_array)
            .into_iter()
            .flatten()
            .filter_map(parse_observed_entity)
            .collect::<Vec<_>>();
        let observed_ids = observed
            .iter()
            .map(|entity| entity.object_id.clone())
            .collect::<HashSet<_>>();
        self.hidden_after_hide
            .retain(|object_id| observed_ids.contains(object_id));
        for entity in &observed {
            if entity
                .action
                .is_some_and(|(_, action)| action == AnimationAction::Show)
            {
                self.hidden_after_hide.remove(&entity.object_id);
            }
        }
        let visible = observed
            .iter()
            .filter(|entity| !self.hidden_after_hide.contains(&entity.object_id))
            .map(|entity| entity.object_id.clone())
            .collect::<HashSet<_>>();

        let removed = self
            .world
            .active_states()
            .filter_map(|(object_id, state)| {
                (!visible.contains(object_id)).then_some(state.key.clone())
            })
            .collect::<Vec<_>>();
        for key in removed {
            let _ = self.world.remove(&key);
            self.last_source_sequence.remove(&key.object_id);
            self.last_applied_sequence.remove(&key.object_id);
            self.last_libraries.remove(&key.object_id);
            self.last_frames.remove(&key.object_id);
        }

        for entity in observed {
            if self.hidden_after_hide.contains(&entity.object_id) {
                continue;
            }
            let catalog_key = format!("{}#mounted={}", entity.body_library, entity.mounted);
            if self
                .last_libraries
                .get(&entity.object_id)
                .is_some_and(|library| library != &catalog_key)
            {
                if let Some(key) = self
                    .world
                    .active_state(&entity.object_id)
                    .map(|state| state.key.clone())
                {
                    let _ = self.world.remove(&key);
                }
                self.last_source_sequence.remove(&entity.object_id);
                self.last_applied_sequence.remove(&entity.object_id);
                self.last_frames.remove(&entity.object_id);
            }
            let update = self.world.observe_snapshot(
                entity.object_id.clone(),
                entity.kind,
                entity.direction,
                catalog_for(entity.kind, &entity.body_library, entity.mounted),
                animation_now_ms,
            );
            let Ok(update) = update else {
                continue;
            };
            self.last_libraries
                .insert(entity.object_id.clone(), catalog_key);

            let action = entity
                .action
                .or_else(|| {
                    (update.spawned && entity.initially_skeleton)
                        .then_some((0, AnimationAction::Skeleton))
                })
                .or_else(|| {
                    (update.spawned && entity.initially_dead).then_some((0, AnimationAction::Dead))
                });
            let Some((normalized_sequence, action)) = action else {
                continue;
            };
            let source_sequence = source_sequences
                .get(&entity.object_id)
                .copied()
                .unwrap_or(normalized_sequence);
            if self
                .last_source_sequence
                .get(&entity.object_id)
                .is_some_and(|previous| source_sequence <= *previous)
            {
                continue;
            }
            let Some(action) = normalize_action(entity.kind, action) else {
                continue;
            };
            if stale_source_echoes.contains(&entity.object_id) && !update.spawned {
                self.last_source_sequence
                    .insert(entity.object_id, source_sequence);
                continue;
            }
            let sequence_floor = source_sequence.max(normalized_sequence);
            let sequence = self
                .last_applied_sequence
                .get(&entity.object_id)
                .map_or(sequence_floor, |previous| {
                    sequence_floor.max(previous.saturating_add(1))
                });
            let revival_barrier = action == AnimationAction::Revive
                || (entity.kind == EntityKind::Player
                    && action == AnimationAction::Standing
                    && self.world.state(&update.key).is_ok_and(|state| {
                        matches!(
                            state.pose().action,
                            AnimationAction::Die
                                | AnimationAction::Dead
                                | AnimationAction::Skeleton
                        )
                    }));
            if revival_barrier {
                if self
                    .world
                    .apply_revival_event(
                        &update.key,
                        AnimationEvent::new(sequence, action, entity.direction),
                        animation_now_ms,
                    )
                    .is_ok()
                {
                    self.retire_source_action(&entity.object_id, source_sequence, sequence, action);
                }
                continue;
            }
            let coalesces_active_player_motion = entity.kind == EntityKind::Player
                && matches!(action, AnimationAction::Walking | AnimationAction::Running)
                && self
                    .motion_windows
                    .get(&entity.object_id)
                    .is_some_and(|window| motion_now_ms < window.expires_ms)
                && self.world.state(&update.key).is_ok_and(|state| {
                    matches!(
                        state.pose().action,
                        AnimationAction::Walking
                            | AnimationAction::Running
                            | AnimationAction::Struck
                    )
                });
            if coalesces_active_player_motion {
                // Crystal starts the next movement tile from frame zero, while
                // its generic ActionFeed remains FIFO for combat actions. The
                // native bridge publishes a fresh sequence and authoritative
                // target for every tile, so queuing another walk/run here would
                // replay stale locomotion after the new motion window already
                // began. The active window below owns the visible movement
                // phase. Obsolete flinches may not postpone this displacement;
                // real attack/cast/life barriers still retain FIFO semantics.
                if self
                    .world
                    .apply_latest_locomotion_event(
                        &update.key,
                        AnimationEvent::new(sequence, action, entity.direction),
                        animation_now_ms,
                    )
                    .is_ok()
                {
                    self.retire_source_action(&entity.object_id, source_sequence, sequence, action);
                }
                continue;
            }
            if let Ok(update) = self.world.apply_event(
                &update.key,
                AnimationEvent::new(sequence, action, entity.direction),
                animation_now_ms,
            ) {
                if update.disposition == QueueDisposition::Coalesced
                    && self.self_object_id.as_deref() == Some(entity.object_id.as_str())
                {
                    crate::movement_trace::record(serde_json::json!({
                        "type": "ownerFlinchCoalesced",
                        "objectId": entity.object_id,
                        "actionSequence": sequence,
                        "sourceActionSequence": source_sequence,
                        "animationAtMs": animation_now_ms,
                    }));
                }
                self.retire_source_action(&entity.object_id, source_sequence, sequence, action);
            }
        }

        self.latest_payload = Some(payload);
        self.payload_dirty = true;
    }

    fn retire_source_action(
        &mut self,
        object_id: &str,
        source_sequence: u64,
        animation_sequence: u64,
        action: AnimationAction,
    ) {
        self.last_source_sequence
            .insert(object_id.to_owned(), source_sequence);
        self.last_applied_sequence
            .insert(object_id.to_owned(), animation_sequence);
        if matches!(action, AnimationAction::Walking | AnimationAction::Running) {
            if let Some(window) = self.motion_windows.get_mut(object_id) {
                // The packet's raw number is not an AnimationWorld number
                // once a prediction has occupied that number in the feed.
                window.animation_sequence = animation_sequence;
            }
        }
    }

    fn attach_native_motion_windows(
        &mut self,
        payload: &mut Value,
        now_ms: u64,
    ) -> HashSet<String> {
        let mut stale_source_echoes = HashSet::new();
        let Some(entities) = payload.get_mut("entities").and_then(Value::as_array_mut) else {
            mir2_bevy_runtime::clear_mir2_self_camera_motion();
            self.self_object_id = None;
            self.last_positions.clear();
            self.motion_windows.clear();
            return stale_source_echoes;
        };
        let mut observed_ids = HashSet::new();
        let mut self_center_correction = None;
        for entity in entities {
            let Some(object_id) = entity.get("objectId").and_then(value_object_id) else {
                continue;
            };
            let (Some(mut x), Some(mut y)) = (
                entity
                    .get("x")
                    .and_then(Value::as_i64)
                    .and_then(|value| i32::try_from(value).ok()),
                entity
                    .get("y")
                    .and_then(Value::as_i64)
                    .and_then(|value| i32::try_from(value).ok()),
            ) else {
                continue;
            };
            observed_ids.insert(object_id.clone());
            let is_self = entity.get("kind").and_then(Value::as_str) == Some("selfPlayer");
            let mut stale_self_source_echo_applied = false;
            if is_self {
                self.self_object_id = Some(object_id.clone());
                if let Some(window) =
                    self.motion_windows
                        .get(&object_id)
                        .copied()
                        .filter(|window| {
                            (now_ms < window.expires_ms || window.locally_predicted)
                                && is_stale_self_source_echo(entity, x, y, *window)
                        })
                {
                    // Unacknowledged pixels belong to the camera/self offset,
                    // not a new render center: the map is still source-centred.
                    if !window.locally_predicted {
                        x = window.to_x as i32;
                        y = window.to_y as i32;
                        entity["x"] = Value::from(x);
                        entity["y"] = Value::from(y);
                        self_center_correction = Some((x, y));
                    }
                    entity["_nativeAnimationSequence"] = Value::from(window.animation_sequence);
                    entity["_nativeAnimationAction"] =
                        Value::from(movement_action_name(window.action));
                    stale_self_source_echo_applied = true;
                    stale_source_echoes.insert(object_id.clone());
                }
            }

            let preserved_local_prediction = self
                .motion_windows
                .get_mut(&object_id)
                .filter(|window| {
                    window.locally_predicted
                        && (stale_self_source_echo_applied
                            || (window.to_x == x as f32 && window.to_y == y as f32))
                })
                .map(|window| {
                    if !stale_self_source_echo_applied {
                        if let Some((action, animation_sequence, direction)) =
                            native_packet_movement(entity)
                        {
                            window.action = action;
                            window.animation_sequence = animation_sequence;
                            window.direction = direction;
                        }
                        window.locally_predicted = false;
                        if now_ms >= window.expires_ms {
                            // This movement was already displayed to completion.
                            // Consume its ACK sequence without replaying locomotion.
                            entity["_nativeAnimationAction"] = Value::from("standing");
                        }
                    }
                })
                .is_some();
            let previous = if stale_self_source_echo_applied
                && self
                    .motion_windows
                    .get(&object_id)
                    .is_some_and(|window| window.locally_settled)
            {
                self.last_positions.get(&object_id).copied()
            } else {
                self.last_positions.insert(object_id.clone(), (x, y))
            };
            if !preserved_local_prediction {
                if let Some((from_x, from_y)) = previous.filter(|previous| *previous != (x, y)) {
                    let active_previous =
                        self.motion_windows
                            .get(&object_id)
                            .copied()
                            .filter(|window| {
                                now_ms < window.expires_ms
                                    && window.to_x == from_x as f32
                                    && window.to_y == from_y as f32
                            });
                    let (motion_from_x, motion_from_y) =
                        active_previous.map_or((from_x as f32, from_y as f32), |window| {
                            (
                                native_motion_coordinate(
                                    window.from_x,
                                    window.to_x,
                                    &window,
                                    now_ms,
                                ),
                                native_motion_coordinate(
                                    window.from_y,
                                    window.to_y,
                                    &window,
                                    now_ms,
                                ),
                            )
                        });
                    let distance = (motion_from_x - x as f32)
                        .abs()
                        .max((motion_from_y - y as f32).abs());
                    let movement = native_packet_movement(entity);
                    if let Some((action, animation_sequence, direction)) =
                        movement.filter(|_| distance <= MAX_SMOOTH_TILE_DISTANCE as f32)
                    {
                        let phase_count = native_motion_phase_count(entity, action);
                        let fallback_duration_ms = u64::from(phase_count) * CRYSTAL_MOVE_PHASE_MS;
                        let (started_ms, expires_ms) = native_packet_motion_window(entity, now_ms)
                            .unwrap_or((now_ms, now_ms.saturating_add(fallback_duration_ms)));
                        let window = NativeMotionWindow {
                            from_x: motion_from_x,
                            from_y: motion_from_y,
                            to_x: x as f32,
                            to_y: y as f32,
                            sort_x: from_x,
                            sort_y: from_y,
                            started_ms,
                            expires_ms,
                            phase_count,
                            animation_sequence,
                            action,
                            direction,
                            locally_predicted: false,
                            locally_settled: false,
                        };
                        self.motion_windows.insert(object_id.clone(), window);
                        if is_self {
                            mir2_bevy_runtime::set_mir2_self_camera_motion(
                                window.from_x,
                                window.from_y,
                                window.to_x,
                                window.to_y,
                                window.started_ms as f64,
                                window.expires_ms as f64,
                            );
                        }
                    } else {
                        self.motion_windows.remove(&object_id);
                    }
                }
            }

            let active_window = self
                .motion_windows
                .get(&object_id)
                .copied()
                .filter(|window| {
                    now_ms < window.expires_ms && window.to_x == x as f32 && window.to_y == y as f32
                });
            if let Some(window) = active_window {
                entity["motionFromX"] = Value::from(window.from_x);
                entity["motionFromY"] = Value::from(window.from_y);
                entity["motionToX"] = Value::from(window.to_x);
                entity["motionToY"] = Value::from(window.to_y);
                entity["motionSortX"] = Value::from(window.sort_x);
                entity["motionSortY"] = Value::from(window.sort_y);
                entity["motionStartedMs"] = Value::from(window.started_ms);
                entity["motionDurationMs"] =
                    Value::from(window.expires_ms.saturating_sub(window.started_ms));
            }
        }
        self.last_positions
            .retain(|object_id, _| observed_ids.contains(object_id));
        self.motion_windows.retain(|object_id, window| {
            observed_ids.contains(object_id)
                && (now_ms < window.expires_ms || window.locally_predicted)
        });
        if let Some((x, y)) = self_center_correction {
            if let Some(center) = payload
                .get_mut("sceneView")
                .and_then(Value::as_object_mut)
                .and_then(|scene_view| scene_view.get_mut("center"))
                .and_then(Value::as_object_mut)
            {
                center.insert("x".to_owned(), Value::from(x));
                center.insert("y".to_owned(), Value::from(y));
            }
        }
        if self
            .self_object_id
            .as_ref()
            .is_some_and(|object_id| !observed_ids.contains(object_id))
        {
            mir2_bevy_runtime::clear_mir2_self_camera_motion();
            self.self_object_id = None;
        }
        stale_source_echoes
    }

    fn expire_native_motion_windows(&mut self, now_ms: u64) {
        let expired = self
            .motion_windows
            .iter()
            .filter(|(_, window)| now_ms >= window.expires_ms && !window.locally_settled)
            .map(|(object_id, _)| object_id.clone())
            .collect::<HashSet<_>>();
        if expired.is_empty() {
            return;
        }

        // An animation deadline is not an authoritative ACK. Retain one local
        // receipt until confirmation/correction, while settling its pixels once.
        self.motion_windows
            .retain(|object_id, window| !expired.contains(object_id) || window.locally_predicted);
        if let Some(entities) = self
            .latest_payload
            .as_mut()
            .and_then(|payload| payload.get_mut("entities"))
            .and_then(Value::as_array_mut)
        {
            for entity in entities {
                let Some(object_id) = entity.get("objectId").and_then(value_object_id) else {
                    continue;
                };
                if !expired.contains(&object_id) {
                    continue;
                }
                if let Some(window) = self.motion_windows.get_mut(&object_id) {
                    if window.locally_predicted {
                        let destination = (window.to_x as i32, window.to_y as i32);
                        // Remember the already-presented endpoint without
                        // publishing a center the authoritative map has not
                        // committed. Runtime holds the camera/self offset.
                        self.last_positions.insert(object_id.clone(), destination);
                        window.locally_settled = true;
                    }
                }
                if let Some(object) = entity.as_object_mut() {
                    for field in [
                        "motionFromX",
                        "motionFromY",
                        "motionToX",
                        "motionToY",
                        "motionSortX",
                        "motionSortY",
                        "motionStartedMs",
                        "motionDurationMs",
                    ] {
                        object.remove(field);
                    }
                }
            }
        }
        if self.self_object_id.as_ref().is_some_and(|object_id| {
            expired.contains(object_id)
                && !self
                    .motion_windows
                    .get(object_id)
                    .is_some_and(|window| window.locally_predicted)
        }) {
            mir2_bevy_runtime::clear_mir2_self_camera_motion();
        }
        self.payload_dirty = true;
    }

    fn render_state_if_changed(&mut self, now_ms: u64, effect_visible: bool) -> Option<Value> {
        self.render_state_if_changed_with(
            now_ms,
            effect_visible,
            crate::atlas::build_entity_render_state_with_poses_and_effect_visibility,
        )
    }

    fn render_state_if_changed_at_clocks(
        &mut self,
        animation_now_ms: u64,
        motion_now_ms: u64,
        effect_visible: bool,
    ) -> Option<Value> {
        self.render_state_if_changed_with_clocks(
            animation_now_ms,
            motion_now_ms,
            effect_visible,
            crate::atlas::build_entity_render_state_with_poses_and_effect_visibility,
        )
    }

    fn render_state_if_changed_with<F>(
        &mut self,
        now_ms: u64,
        effect_visible: bool,
        render: F,
    ) -> Option<Value>
    where
        F: FnOnce(&Value, &HashMap<String, (i64, AnimationAction)>, bool) -> Option<Value>,
    {
        self.render_state_if_changed_with_clocks(now_ms, now_ms, effect_visible, render)
    }

    fn render_state_if_changed_with_clocks<F>(
        &mut self,
        animation_now_ms: u64,
        motion_now_ms: u64,
        effect_visible: bool,
        render: F,
    ) -> Option<Value>
    where
        F: FnOnce(&Value, &HashMap<String, (i64, AnimationAction)>, bool) -> Option<Value>,
    {
        self.sync_pending_payload(animation_now_ms, motion_now_ms);
        // A quiet connection may not deliver another snapshot exactly when a
        // movement action ends. Remove its MapLocation-style sort anchor from
        // the retained payload on the local clock so depth always settles on
        // the destination without waiting for another packet.
        self.expire_native_motion_windows(motion_now_ms);
        let payload = self.latest_payload.as_ref()?;
        let effect_visibility_changed =
            self.last_effect_visible.replace(effect_visible) != Some(effect_visible);
        let transitions = self.world.tick(animation_now_ms).ok()?;
        for transition in transitions {
            if transition.reason == TransitionReason::HideCompleted
                && self
                    .last_libraries
                    .get(&transition.key.object_id)
                    .is_some_and(|library| hide_removes_rendered_entity(library))
            {
                self.hidden_after_hide
                    .insert(transition.key.object_id.clone());
            }
        }
        let frames = self
            .world
            .active_states()
            .map(|(object_id, state)| {
                let pose = state.pose();
                let movement_pose = if state.kind == EntityKind::Player
                    && matches!(
                        pose.action,
                        AnimationAction::Walking | AnimationAction::Running
                    ) {
                    self.motion_windows
                        .get(object_id)
                        .filter(|window| motion_now_ms < window.expires_ms)
                        .and_then(|window| {
                            if pose.last_started_event_sequence != Some(window.animation_sequence) {
                                return None;
                            }
                            let descriptor = state.catalog().descriptor(window.action)?;
                            let phase = native_motion_phase_index(window, motion_now_ms)
                                .min(descriptor.frame_count.saturating_sub(1));
                            Some((
                                i64::from(descriptor.draw_frame(window.direction, phase)),
                                window.action,
                            ))
                        })
                } else {
                    None
                };
                (
                    object_id.to_owned(),
                    movement_pose.unwrap_or((i64::from(pose.draw_frame_index), pose.action)),
                )
            })
            .collect::<HashMap<_, _>>();
        // Combat and locomotion use separate clocks. Capture only a real
        // rendered overlap, once per attack/window pair, rather than emitting
        // one movement trace row on every frame of an ordinary run.
        let overlap = self.self_object_id.as_deref().and_then(|object_id| {
            let window = self.motion_windows.get(object_id)?;
            let action = frames.get(object_id)?.1;
            (motion_now_ms < window.expires_ms && is_attack_action(action))
                .then_some((object_id, *window, action))
        });
        if let Some((object_id, window, action)) = overlap {
            let action_sequence = self
                .world
                .active_state(object_id)
                .and_then(|state| state.pose().last_started_event_sequence)
                .unwrap_or(0);
            let overlap_key = (window.started_ms, action_sequence);
            if self.last_attack_motion_overlap != Some(overlap_key) {
                crate::movement_trace::record(serde_json::json!({
                    "type": "attackMotionOverlapRendered",
                    "action": format!("{action:?}"),
                    "objectId": object_id,
                    "actionSequence": action_sequence,
                    "movementSequence": window.animation_sequence,
                    "movementRemainingMs": window.expires_ms.saturating_sub(motion_now_ms),
                    "locallyPredicted": window.locally_predicted,
                    "animationAtMs": animation_now_ms,
                    "motionAtUnixMs": motion_now_ms,
                }));
                self.last_attack_motion_overlap = Some(overlap_key);
            }
        } else {
            self.last_attack_motion_overlap = None;
        }
        if !self.payload_dirty && frames == self.last_frames && !effect_visibility_changed {
            return None;
        }

        let mut visible_payload = payload.clone();
        if let Some(object) = visible_payload.as_object_mut() {
            object.insert(
                "_nativeHighlightTarget".to_owned(),
                Value::Bool(self.highlight_target),
            );
            // The browser owns selectedObjectId in its local world store. The
            // native client keeps the same selection in its pointer movement
            // controller, so project it into the render-only payload. Without
            // this bridge the ordinary body pass is correctly hidden by a
            // tree, but Crystal's selected-object redraw never appears.
            if let Some(object_id) = &self.local_selected_object_id {
                object.insert(
                    "selectedObjectId".to_owned(),
                    Value::String(object_id.clone()),
                );
            }
            if let Some((x, y)) = self.hover_cursor_stage {
                object.insert(
                    "_nativeHoverCursor".to_owned(),
                    serde_json::json!({"x": x, "y": y}),
                );
            } else {
                object.remove("_nativeHoverCursor");
            }
        }
        if let Some(entities) = visible_payload
            .get_mut("entities")
            .and_then(Value::as_array_mut)
        {
            entities.retain(|entity| {
                entity
                    .get("objectId")
                    .and_then(value_object_id)
                    .is_none_or(|object_id| !self.hidden_after_hide.contains(&object_id))
            });
        }
        let Some(state) = render(&visible_payload, &frames, effect_visible) else {
            self.hovered_object_id = None;
            self.self_hovered = false;
            return None;
        };
        self.hovered_object_id = state.get("hoveredObjectId").and_then(value_object_id);
        self.self_hovered = state
            .get("selfHovered")
            .and_then(Value::as_bool)
            .unwrap_or(false);
        self.last_frames = frames;
        self.payload_dirty = false;
        Some(state)
    }
}

fn is_attack_action(action: AnimationAction) -> bool {
    matches!(
        action,
        AnimationAction::Attack1
            | AnimationAction::Attack2
            | AnimationAction::Attack3
            | AnimationAction::Attack4
            | AnimationAction::AttackRange1
            | AnimationAction::AttackRange2
            | AnimationAction::DashAttack
    )
}

pub fn tick_native_entity_presentation(
    mut presentation: ResMut<NativeEntityPresentation>,
    movement: Option<Res<crate::input::WorldPointerMovementState>>,
    player_ui: Option<Res<mir2_client_bevy::crystal_ui::overlays::NativePlayerUiState>>,
    shell: Option<Res<mir2_client_bevy::native_shell::NativeShellModel>>,
    quest: Option<Res<mir2_client_bevy::quest_ui::QuestUiState>>,
    windows: Query<&Window, With<PrimaryWindow>>,
) {
    let motion_now_ms = native_motion_clock_ms();
    let animation_now_ms = motion_now_ms;
    let effect_visible = player_ui
        .as_deref()
        .map(|state| state.core.options.effect)
        .unwrap_or(true);
    let highlight_target = player_ui
        .as_deref()
        .map(|state| state.core.options.highlight_target)
        .unwrap_or(true);
    presentation.set_local_selected_object_id(
        movement
            .as_deref()
            .and_then(crate::input::WorldPointerMovementState::attack_target)
            .map(|object_id| object_id.to_string()),
    );
    // Hit-testing is an input contract, not a highlight preference. Always
    // publish the cursor while world input is allowed; `highlight_target`
    // controls only the extra redraw band; name visibility is handled by the
    // overlay layer and must not make monsters unclickable.
    let hover_cursor_stage = native_hover_cursor(
        windows.iter().next(),
        shell.as_deref(),
        player_ui.as_deref(),
        quest.as_deref(),
    );
    presentation.set_hover_presentation(hover_cursor_stage, highlight_target);
    let Some(state) = presentation.render_state_if_changed_at_clocks(
        animation_now_ms,
        motion_now_ms,
        effect_visible,
    ) else {
        return;
    };
    if let Ok(json) = serde_json::to_string(&state) {
        let _ = mir2_bevy_runtime::native_ingest::push_native_entity_render_state(json);
    }
}

pub(crate) fn native_motion_clock_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| u64::try_from(duration.as_millis()).unwrap_or(u64::MAX))
        .unwrap_or(0)
}

fn native_hover_cursor(
    window: Option<&Window>,
    shell: Option<&mir2_client_bevy::native_shell::NativeShellModel>,
    player_ui: Option<&mir2_client_bevy::crystal_ui::overlays::NativePlayerUiState>,
    quest: Option<&mir2_client_bevy::quest_ui::QuestUiState>,
) -> Option<(f32, f32)> {
    use mir2_client_bevy::native_shell::NativeShellScreen;

    if shell.is_none_or(|shell| shell.screen != NativeShellScreen::InGame) {
        return None;
    }
    let window = window?;
    if !window.focused {
        return None;
    }
    let cursor = window.cursor_position()?;
    let transform = mir2_client_bevy::crystal_ui::CrystalStageTransform::fit_native(
        window.resolution.width(),
        window.resolution.height(),
    );
    if !transform.contains_physical_point(cursor.x, cursor.y) {
        return None;
    }
    let point = transform.physical_to_logical(cursor.x, cursor.y);
    if player_ui.is_some_and(|ui| ui.blocks_world_pointer_at(point.0, point.1))
        || quest.is_some_and(|quest| {
            quest.captures_world_pointer_at(
                point.0,
                point.1,
                player_ui.is_some_and(|ui| ui.quest_open()),
            )
        })
    {
        return None;
    }
    Some(point)
}

fn parse_observed_entity(entity: &Value) -> Option<ObservedEntity> {
    let object_id = entity.get("objectId").and_then(|value| match value {
        Value::Number(number) => Some(number.to_string()),
        Value::String(value) => Some(value.clone()),
        _ => None,
    })?;
    let kind = match entity.get("kind").and_then(Value::as_str) {
        Some("selfPlayer" | "player" | "hero") => EntityKind::Player,
        Some("npc") => EntityKind::Npc,
        _ => EntityKind::Monster,
    };
    let direction = parse_direction(
        entity
            .get("direction")
            .and_then(Value::as_str)
            .unwrap_or("down"),
    );
    let action = entity
        .get("_nativeAnimationAction")
        .and_then(Value::as_str)
        .and_then(parse_action)
        .zip(
            entity
                .get("_nativeAnimationSequence")
                .and_then(Value::as_u64),
        )
        .map(|(action, sequence)| (sequence, action));
    let resolved_sprite = crate::atlas::resolved_native_sprite(
        entity,
        action
            .map(|(_, action)| action)
            .unwrap_or(AnimationAction::Standing),
    );
    let mounted = resolved_sprite.mounted();
    Some(ObservedEntity {
        object_id,
        kind,
        body_library: resolved_sprite.body_library,
        mounted,
        direction,
        action,
        initially_dead: entity.get("dead").and_then(Value::as_bool) == Some(true),
        initially_skeleton: entity.get("skeleton").and_then(Value::as_bool) == Some(true),
    })
}

fn parse_direction(direction: &str) -> Direction {
    match direction.to_ascii_lowercase().as_str() {
        "up" => Direction::Up,
        "upright" => Direction::UpRight,
        "right" => Direction::Right,
        "downright" => Direction::DownRight,
        "downleft" => Direction::DownLeft,
        "left" => Direction::Left,
        "upleft" => Direction::UpLeft,
        _ => Direction::Down,
    }
}

fn direction_name(direction: Direction) -> &'static str {
    match direction {
        Direction::Up => "up",
        Direction::UpRight => "upright",
        Direction::Right => "right",
        Direction::DownRight => "downright",
        Direction::Down => "down",
        Direction::DownLeft => "downleft",
        Direction::Left => "left",
        Direction::UpLeft => "upleft",
    }
}

fn parse_action(action: &str) -> Option<AnimationAction> {
    match action {
        "standing" => Some(AnimationAction::Standing),
        "harvest" => Some(AnimationAction::Harvest),
        "show" => Some(AnimationAction::Show),
        "hide" => Some(AnimationAction::Hide),
        "walking" => Some(AnimationAction::Walking),
        "running" => Some(AnimationAction::Running),
        "attack1" => Some(AnimationAction::Attack1),
        "attack2" => Some(AnimationAction::Attack2),
        "mine" => Some(AnimationAction::Attack2),
        "attack3" => Some(AnimationAction::Attack3),
        "attack4" => Some(AnimationAction::Attack4),
        "attackRange1" => Some(AnimationAction::AttackRange1),
        "attackRange2" => Some(AnimationAction::AttackRange2),
        "dashAttack" => Some(AnimationAction::DashAttack),
        "spell" => Some(AnimationAction::Spell),
        "struck" => Some(AnimationAction::Struck),
        "die" => Some(AnimationAction::Die),
        "dead" => Some(AnimationAction::Dead),
        "skeleton" => Some(AnimationAction::Skeleton),
        "revive" => Some(AnimationAction::Revive),
        _ => None,
    }
}

fn movement_action_name(action: AnimationAction) -> &'static str {
    match action {
        AnimationAction::Walking => "walking",
        AnimationAction::Running => "running",
        _ => "standing",
    }
}

fn native_packet_movement(entity: &Value) -> Option<(AnimationAction, u64, Direction)> {
    let action = entity
        .get("_nativeAnimationAction")
        .and_then(Value::as_str)
        .and_then(parse_action)
        .filter(|action| matches!(action, AnimationAction::Walking | AnimationAction::Running))?;
    let sequence = entity
        .get("_nativeAnimationSequence")
        .and_then(Value::as_u64)?;
    let direction = parse_direction(
        entity
            .get("direction")
            .and_then(Value::as_str)
            .unwrap_or("down"),
    );
    Some((action, sequence, direction))
}

fn native_motion_phase_count(entity: &Value, action: AnimationAction) -> u16 {
    if let Some(explicit) = entity
        .get("movementFrameCount")
        .and_then(json_millis)
        .and_then(|value| u16::try_from(value).ok())
        .filter(|value| (1..=MAX_NATIVE_MOVE_PHASE_COUNT).contains(value))
    {
        return explicit;
    }

    let kind = match entity.get("kind").and_then(Value::as_str) {
        Some("selfPlayer" | "player" | "hero") => EntityKind::Player,
        _ => return CRYSTAL_MOVE_PHASE_COUNT,
    };
    let sprite = crate::atlas::resolved_native_sprite(entity, action);
    crate::frame_sets::animation_catalog_for(kind, &sprite.body_library, sprite.mounted())
        .descriptor(action)
        .map(|descriptor| descriptor.frame_count)
        .filter(|value| (1..=MAX_NATIVE_MOVE_PHASE_COUNT).contains(value))
        .unwrap_or(CRYSTAL_MOVE_PHASE_COUNT)
}

fn native_packet_motion_window(entity: &Value, now_ms: u64) -> Option<(u64, u64)> {
    let started_ms = entity
        .get("movementStartedAt")
        .or_else(|| entity.get("movementStartedMs"))
        .and_then(json_millis)?;
    let expires_ms = entity
        .get("movementUntil")
        .and_then(json_millis)
        .or_else(|| {
            entity
                .get("movementDurationMs")
                .and_then(json_millis)
                .and_then(|duration_ms| started_ms.checked_add(duration_ms))
        })?;
    (started_ms <= now_ms && expires_ms > now_ms && expires_ms > started_ms)
        .then_some((started_ms, expires_ms))
}

fn json_millis(value: &Value) -> Option<u64> {
    if let Some(value) = value.as_u64() {
        return Some(value);
    }
    let value = value.as_f64()?;
    (value.is_finite() && value >= 0.0 && value <= u64::MAX as f64).then(|| value.round() as u64)
}

fn is_stale_self_source_echo(entity: &Value, x: i32, y: i32, window: NativeMotionWindow) -> bool {
    // An attack/struck packet at the predicted source tile is a real action,
    // not a delayed movement echo. Keep it available to the ActionFeed.
    if entity
        .get("_nativeAnimationAction")
        .and_then(Value::as_str)
        .is_some_and(|action| !matches!(action, "standing" | "walking" | "running"))
    {
        return false;
    }
    let source_distance = (x as f32 - window.from_x)
        .abs()
        .max((y as f32 - window.from_y).abs());
    let target_distance = (x as f32 - window.to_x)
        .abs()
        .max((y as f32 - window.to_y).abs());
    if source_distance >= 0.125 || target_distance < 0.125 {
        return false;
    }

    entity
        .get("direction")
        .and_then(Value::as_str)
        .map(parse_direction)
        == native_motion_direction(window)
}

fn native_motion_direction(window: NativeMotionWindow) -> Option<Direction> {
    let horizontal = motion_axis_sign(window.to_x - window.from_x);
    let vertical = motion_axis_sign(window.to_y - window.from_y);
    match (horizontal, vertical) {
        (0, -1) => Some(Direction::Up),
        (1, -1) => Some(Direction::UpRight),
        (1, 0) => Some(Direction::Right),
        (1, 1) => Some(Direction::DownRight),
        (0, 1) => Some(Direction::Down),
        (-1, 1) => Some(Direction::DownLeft),
        (-1, 0) => Some(Direction::Left),
        (-1, -1) => Some(Direction::UpLeft),
        _ => None,
    }
}

fn motion_axis_sign(value: f32) -> i8 {
    if value > 0.001 {
        1
    } else if value < -0.001 {
        -1
    } else {
        0
    }
}

fn value_object_id(value: &Value) -> Option<String> {
    match value {
        Value::Number(number) => Some(number.to_string()),
        Value::String(value) => Some(value.clone()),
        _ => None,
    }
}

fn native_motion_offset(window: &NativeMotionWindow, now_ms: u64) -> (f32, f32) {
    let remaining = native_motion_remaining_ratio(window, now_ms);
    (
        crystal_even_pixel((window.from_x - window.to_x) * 48.0 * remaining),
        crystal_even_pixel((window.from_y - window.to_y) * 32.0 * remaining),
    )
}

fn native_motion_coordinate(from: f32, to: f32, window: &NativeMotionWindow, now_ms: u64) -> f32 {
    to + (from - to) * native_motion_remaining_ratio(window, now_ms)
}

fn native_motion_phase_index(window: &NativeMotionWindow, now_ms: u64) -> u16 {
    let phase_count = window.phase_count.max(1);
    if window.expires_ms <= window.started_ms || now_ms >= window.expires_ms {
        return phase_count.saturating_sub(1);
    }
    u16::try_from(
        (now_ms.saturating_sub(window.started_ms) / CRYSTAL_MOVE_PHASE_MS)
            .min(u64::from(phase_count.saturating_sub(1))),
    )
    .unwrap_or(u16::MAX)
}

fn native_motion_remaining_ratio(window: &NativeMotionWindow, now_ms: u64) -> f32 {
    if window.expires_ms <= window.started_ms || now_ms >= window.expires_ms {
        return 0.0;
    }
    // Crystal applies the first displacement increment while frame zero is
    // drawn, then advances the descriptor-owned movement phases every 100 ms.
    let progress = f32::from(native_motion_phase_index(window, now_ms) + 1)
        / f32::from(window.phase_count.max(1));
    (1.0 - progress).clamp(0.0, 1.0)
}

fn crystal_even_pixel(value: f32) -> f32 {
    if !value.is_finite() || value.abs() < 0.001 {
        return 0.0;
    }
    let pixel = value.trunc() as i32;
    (pixel + pixel % 2) as f32
}

fn hide_removes_rendered_entity(catalog_key: &str) -> bool {
    let library = catalog_key
        .split_once("#mounted=")
        .map_or(catalog_key, |(library, _)| library)
        .trim()
        .replace('\\', "/");
    let library = library
        .trim_matches('/')
        .strip_prefix("original-ui/")
        .unwrap_or_else(|| library.trim_matches('/'));
    library == "Monster/010"
}

fn normalize_action(kind: EntityKind, action: AnimationAction) -> Option<AnimationAction> {
    match (kind, action) {
        (EntityKind::Npc, AnimationAction::Standing | AnimationAction::Harvest) => Some(action),
        (EntityKind::Npc, _) => None,
        (EntityKind::Monster, AnimationAction::Running) => Some(AnimationAction::Walking),
        (EntityKind::Monster, AnimationAction::AttackRange1 | AnimationAction::Spell) => {
            Some(AnimationAction::Attack1)
        }
        _ => Some(action),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gameplay_bridge::NativeGameplayAdapter;
    use crate::native_protocol::PacketEvent;
    use mir2_bevy_runtime::entity_animation::FrameDescriptor;
    use serde_json::json;
    use std::io::Read;

    fn player_payload(sequence: u64) -> Value {
        json!({
            "sceneView": {"center": {"x": 10, "y": 10}},
            "entities": [{
                "objectId": 1,
                "kind": "selfPlayer",
                "x": 10,
                "y": 10,
                "direction": "down",
                "dead": false,
                "_nativeAnimationAction": "walking",
                "_nativeAnimationSequence": sequence,
                "sprite": {
                    "bodyLibrary": "AArmour/00",
                    "directionStride": 4,
                    "frameBaseOffset": 0
                }
            }]
        })
    }

    #[test]
    fn self_combat_movement_gate_uses_each_real_crystal_action_length() {
        for (name, action) in [
            ("attack1", AnimationAction::Attack1),
            ("attack2", AnimationAction::Attack2),
            ("attack3", AnimationAction::Attack3),
            ("attack4", AnimationAction::Attack4),
            ("attackRange1", AnimationAction::AttackRange1),
            ("attackRange2", AnimationAction::AttackRange2),
            ("dashAttack", AnimationAction::DashAttack),
            ("spell", AnimationAction::Spell),
        ] {
            let catalog = AnimationCatalog::crystal_player();
            let descriptor = catalog.descriptor(action).unwrap();
            let duration = u64::from(descriptor.frame_count) * descriptor.frame_interval_ms;
            let mut presentation = NativeEntityPresentation::default();
            let mut payload = player_payload(1);
            payload["entities"][0]["_nativeAnimationAction"] = json!(name);
            presentation.replace_payload(payload);
            presentation.sync_pending_payload_with(0, |_, _, _| catalog.clone());
            assert_eq!(presentation.world.active_state("1").unwrap().current_action, action);
            assert!(presentation.self_combat_action_blocks_movement("1"), "{name}");

            presentation.world.tick(duration - 1).unwrap();
            assert!(presentation.self_combat_action_blocks_movement("1"), "{name} before last frame");
            presentation.world.tick(duration).unwrap();
            assert_eq!(presentation.world.active_state("1").unwrap().current_action, AnimationAction::Standing);
            assert!(!presentation.self_combat_action_blocks_movement("1"), "{name} completed");
            assert_eq!(presentation.overlay_payload().unwrap()["entities"][0]["_nativeAnimationAction"], name,
                "the retained packet action is deliberately stale after the real frame clock ends");
        }
    }

    #[test]
    fn self_combat_movement_gate_reads_queued_barriers_without_mutating_feed() {
        let mut presentation = NativeEntityPresentation::default();
        let mut struck = player_payload(1);
        struck["entities"][0]["_nativeAnimationAction"] = json!("struck");
        presentation.replace_payload(struck);
        presentation.sync_pending_payload_with(0, |_, _, _| AnimationCatalog::crystal_player());
        assert!(!presentation.self_combat_action_blocks_movement("1"));

        let mut attack = player_payload(2);
        attack["entities"][0]["_nativeAnimationAction"] = json!("attack1");
        presentation.replace_payload(attack);
        presentation.sync_pending_payload_with(1, |_, _, _| AnimationCatalog::crystal_player());
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(state.current_action, AnimationAction::Struck);
        let before = (state.frame_index, state.last_update_at_ms,
            state.queued_actions().copied().collect::<Vec<_>>());
        assert!(presentation.self_combat_action_blocks_movement("1"));
        assert!(presentation.self_combat_action_blocks_movement("1"));
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!((state.frame_index, state.last_update_at_ms,
            state.queued_actions().copied().collect::<Vec<_>>()), before);

        presentation.world.tick(300).unwrap();
        assert_eq!(presentation.world.active_state("1").unwrap().current_action, AnimationAction::Attack1);
        assert!(presentation.self_combat_action_blocks_movement("1"));
        presentation.world.tick(900).unwrap();
        assert!(!presentation.self_combat_action_blocks_movement("1"));
    }

    #[test]
    fn self_combat_movement_gate_keeps_death_and_revival_barriers() {
        let mut presentation = NativeEntityPresentation::default();
        let mut dying = player_payload(1);
        dying["entities"][0]["dead"] = json!(true);
        dying["entities"][0]["_nativeAnimationAction"] = json!("die");
        presentation.replace_payload(dying);
        presentation.sync_pending_payload_with(0, |_, _, _| AnimationCatalog::crystal_player());
        assert!(presentation.self_combat_action_blocks_movement("1"));
        presentation.world.tick(400).unwrap();
        assert_eq!(presentation.world.active_state("1").unwrap().current_action, AnimationAction::Dead);
        assert!(presentation.self_combat_action_blocks_movement("1"));

        let key = presentation.world.active_state("1").unwrap().key.clone();
        presentation.world.apply_revival_event(&key,
            AnimationEvent::new(2, AnimationAction::Revive, Direction::Down), 500).unwrap();
        assert!(presentation.self_combat_action_blocks_movement("1"));
        presentation.world.tick(900).unwrap();
        assert!(!presentation.self_combat_action_blocks_movement("1"));
    }

    #[test]
    fn self_combat_movement_gate_does_not_add_struck_or_locomotion_locks() {
        for name in ["standing", "walking", "running", "struck"] {
            let mut presentation = NativeEntityPresentation::default();
            let mut payload = player_payload(1);
            payload["entities"][0]["_nativeAnimationAction"] = json!(name);
            let mut observer = payload["entities"][0].clone();
            observer["objectId"] = json!(2);
            observer["kind"] = json!("player");
            observer["_nativeAnimationAction"] = json!("spell");
            payload["entities"].as_array_mut().unwrap().push(observer);
            presentation.replace_payload(payload);
            presentation.sync_pending_payload_with(0, |_, _, _| AnimationCatalog::crystal_player());
            assert!(!presentation.self_combat_action_blocks_movement("1"), "{name}");
            assert!(presentation.self_combat_action_blocks_movement("2"));
            assert!(!presentation.self_combat_action_blocks_movement("missing"));
        }
    }

    #[test]
    fn mining_owner_confirmation_uses_crystal_attack2_but_observer_stays_attack1() {
        let mut presentation = NativeEntityPresentation::default();
        let mut initial = player_payload(1);
        initial["mapFileName"] = json!("D401");
        initial["entities"][0]["_nativeAnimationAction"] = json!("standing");
        presentation.replace_payload(initial.clone());
        presentation.sync_pending_payload_with(900, |_, _, _| AnimationCatalog::crystal_player());
        presentation.mark_local_mining_request("1", (10, 10), "down", 1_000);
        let mut attack = initial.clone();
        attack["entities"][0]["_nativeAnimationAction"] = json!("attack1");
        attack["entities"][0]["_nativeAnimationSequence"] = json!(2);
        let mut observer = attack["entities"][0].clone();
        observer["kind"] = json!("player");
        observer["objectId"] = json!(2);
        attack["entities"].as_array_mut().unwrap().push(observer);
        presentation.replace_payload(attack);
        presentation.sync_pending_payload_with(1_001, |_, _, _| AnimationCatalog::crystal_player());
        assert_eq!(
            presentation.world.active_state("1").unwrap().pose().action,
            AnimationAction::Attack2
        );
        assert_eq!(
            presentation
                .world
                .active_state("1")
                .unwrap()
                .pose()
                .draw_frame_index,
            208,
            "Crystal Mine = 184 + direction(Down) * 6"
        );
        assert_eq!(
            presentation.world.active_state("2").unwrap().pose().action,
            AnimationAction::Attack1
        );
        assert_eq!(
            presentation.latest_payload.as_ref().unwrap()["entities"][1]["_nativeAnimationAction"],
            "attack1"
        );
        assert!(presentation.local_mining_request.is_none());
        let mut next = initial;
        next["entities"][0]["_nativeAnimationAction"] = json!("attack1");
        next["entities"][0]["_nativeAnimationSequence"] = json!(3);
        presentation.map_confirmed_local_mine(&mut next, 1_002);
        assert_eq!(
            next["entities"][0]["_nativeAnimationAction"], "attack1",
            "only one matching confirmation consumes the marker"
        );
    }

    #[test]
    fn mining_animation_marker_cannot_reuse_stale_or_moved_or_canceled_attack() {
        for case in ["stale", "move", "map", "cancel", "timeout"] {
            let mut presentation = NativeEntityPresentation::default();
            let mut initial = player_payload(1);
            initial["mapFileName"] = json!("D401");
            initial["entities"][0]["_nativeAnimationAction"] = json!("standing");
            presentation.replace_payload(initial.clone());
            presentation
                .sync_pending_payload_with(900, |_, _, _| AnimationCatalog::crystal_player());
            presentation.mark_local_mining_request("1", (10, 10), "down", 1_000);
            let mut attack = initial;
            attack["entities"][0]["_nativeAnimationAction"] = json!("attack1");
            attack["entities"][0]["_nativeAnimationSequence"] = json!(2);
            match case {
                "stale" => attack["entities"][0]["_nativeAnimationSequence"] = json!(1),
                "move" => attack["entities"][0]["x"] = json!(11),
                "map" => attack["mapFileName"] = json!("D402"),
                "cancel" => presentation.clear_local_mining_request(),
                "timeout" => (),
                _ => unreachable!(),
            }
            presentation.map_confirmed_local_mine(
                &mut attack,
                if case == "timeout" { 4_000 } else { 1_001 },
            );
            assert_eq!(
                attack["entities"][0]["_nativeAnimationAction"], "attack1",
                "{case}"
            );
        }
    }

    #[test]
    fn local_revived_standing_interrupts_dead_with_stale_locomotion_queued() {
        let mut presentation = NativeEntityPresentation::default();
        let mut dying = player_payload(1);
        dying["entities"][0]["dead"] = json!(true);
        dying["entities"][0]["_nativeAnimationAction"] = json!("die");
        presentation.replace_payload(dying);
        presentation.sync_pending_payload_with(0, |_, _, _| AnimationCatalog::crystal_player());
        presentation.world.tick(400).unwrap();

        let mut stale_move = player_payload(2);
        stale_move["entities"][0]["dead"] = json!(true);
        stale_move["entities"][0]["_nativeAnimationAction"] = json!("running");
        presentation.replace_payload(stale_move);
        presentation.sync_pending_payload_with(450, |_, _, _| AnimationCatalog::crystal_player());
        assert_eq!(
            presentation.world.active_state("1").unwrap().queue_depth(),
            1
        );

        let mut revived = player_payload(3);
        revived["entities"][0]["_nativeAnimationAction"] = json!("standing");
        presentation.replace_payload(revived);
        presentation.sync_pending_payload_with(500, |_, _, _| AnimationCatalog::crystal_player());
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(state.current_action, AnimationAction::Standing);
        assert_eq!(state.queue_depth(), 0);
        assert_eq!(state.last_started_event_sequence(), Some(3));
    }

    fn mounted_player_payload(sequence: u64, action: &str) -> Value {
        let mut payload = player_payload(sequence);
        payload["entities"][0]["_nativeAnimationAction"] = json!(action);
        payload["entities"][0]["ridingMount"] = json!(true);
        payload["entities"][0]["mountType"] = json!(0);
        payload["entities"][0]["sprite"]["mountLibrary"] = json!("Mount/00");
        payload["entities"][0]["sprite"]["mountFrameOffset"] = json!(0);
        payload
    }

    fn rendered_path(state: &Value) -> &str {
        state["entities"][0]["layers"][0]["path"]
            .as_str()
            .expect("rendered frame path")
    }

    fn has_additive_layer(state: &Value) -> bool {
        state["entities"][0]["layers"]
            .as_array()
            .expect("entity layers")
            .iter()
            .any(|layer| layer["additive"].as_bool() == Some(true))
    }

    #[test]
    fn movement_prediction_uses_crystal_run_distance_and_real_motion_window() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.latest_payload = Some(player_payload(1));
        assert_eq!(presentation.self_run_distance("1"), 2);
        assert_eq!(presentation.self_motion_duration_ms("1", false), Some(600));
        assert_eq!(presentation.self_motion_duration_ms("1", true), Some(600));

        presentation.latest_payload = Some(mounted_player_payload(2, "walking"));
        assert_eq!(presentation.self_run_distance("1"), 3);
        assert_eq!(presentation.self_motion_duration_ms("1", false), Some(800));
        assert_eq!(presentation.self_motion_duration_ms("1", true), Some(600));

        let mut swift_feet = player_payload(3);
        swift_feet["entities"][0]["buffs"] = json!([102]);
        presentation.latest_payload = Some(swift_feet.clone());
        assert_eq!(presentation.self_run_distance("1"), 3);

        swift_feet["entities"][0]["sneakingActive"] = json!(true);
        presentation.latest_payload = Some(swift_feet);
        assert_eq!(presentation.self_run_distance("1"), 2);
    }

    #[test]
    fn movement_collision_uses_live_payload_and_does_not_block_on_corpses() {
        let mut payload = player_payload(1);
        payload["mapFileName"] = json!("0.map");
        payload["entities"]
            .as_array_mut()
            .expect("entities")
            .extend([
                json!({
                    "objectId": 2,
                    "kind": "monster",
                    "x": 11,
                    "y": 10,
                    "dead": true
                }),
                json!({
                    "objectId": 3,
                    "kind": "npc",
                    "x": 12,
                    "y": 10,
                    "dead": false
                }),
            ]);
        let mut presentation = NativeEntityPresentation::default();
        presentation.latest_payload = Some(payload);

        assert_eq!(presentation.current_map_file_name(), Some("0.map"));
        assert_eq!(
            presentation.tile_has_blocking_entity("1", (11, 10)),
            Some(false)
        );
        assert_eq!(
            presentation.tile_has_blocking_entity("1", (12, 10)),
            Some(true)
        );
        assert_eq!(
            presentation.tile_has_blocking_entity("1", (10, 10)),
            Some(false),
            "self never blocks its own route"
        );
        assert_eq!(
            presentation.movement_blocking_cells("1"),
            Some(vec![(12, 10)])
        );
    }

    #[test]
    fn sabuk_gate_prediction_matches_closed_open_destroyed_source_footprint() {
        let mut payload = player_payload(1);
        payload["mapFileName"] = json!("3.map");
        payload["entities"].as_array_mut().unwrap().push(json!({"objectId":2,"kind":"monster","name":"SabukGate","ai":81,"image":950,"x":672,"y":330,"direction":"up","dead":false}));
        let cells = [
            (672, 330),
            (672, 329),
            (672, 328),
            (673, 329),
            (673, 328),
            (671, 330),
            (670, 330),
            (671, 329),
            (671, 331),
        ];
        let mut presentation = NativeEntityPresentation::default();
        presentation.latest_payload = Some(payload.clone());
        for cell in cells {
            assert_eq!(presentation.tile_has_blocking_entity("1", cell), Some(true));
        }
        let mut sorted_cells = cells.to_vec();
        sorted_cells.sort_unstable();
        assert_eq!(
            presentation.movement_blocking_cells("1"),
            Some(sorted_cells)
        );
        assert_eq!(
            presentation.tile_has_blocking_entity("1", (674, 330)),
            Some(false)
        );
        for direction in ["Left", "left"] {
            payload["entities"][1]["direction"] = json!(direction);
            presentation.latest_payload = Some(payload.clone());
            for cell in cells {
                assert_eq!(
                    presentation.tile_has_blocking_entity("1", cell),
                    Some(false)
                );
            }
            assert_eq!(presentation.movement_blocking_cells("1"), Some(Vec::new()));
        }
        payload["entities"][1]["direction"] = json!("up");
        payload["entities"][1]["dead"] = json!(true);
        presentation.latest_payload = Some(payload.clone());
        for cell in cells {
            assert_eq!(
                presentation.tile_has_blocking_entity("1", cell),
                Some(false)
            );
        }
        assert_eq!(presentation.movement_blocking_cells("1"), Some(Vec::new()));
        payload["entities"][1]["dead"] = json!(false);
        payload["entities"][1]["direction"] = json!("left");
        payload["entities"]
            .as_array_mut()
            .unwrap()
            .push(json!({"objectId":3,"kind":"npc","x":672,"y":330,"dead":false}));
        presentation.latest_payload = Some(payload.clone());
        assert_eq!(
            presentation.tile_has_blocking_entity("1", (672, 330)),
            Some(true)
        );
        payload["entities"].as_array_mut().unwrap().pop();
        payload["mapFileName"] = json!("0.map");
        presentation.latest_payload = Some(payload);
        assert_eq!(
            presentation.tile_has_blocking_entity("1", (672, 330)),
            Some(true),
            "ordinary actors on other maps retain collision"
        );
    }

    #[test]
    fn animation_advances_without_another_gateway_payload() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        let first = presentation
            .render_state_if_changed(0, true)
            .expect("initial walking frame");
        assert!(rendered_path(&first).ends_with("/56.png"));
        assert!(presentation.render_state_if_changed(99, true).is_none());
        let second = presentation
            .render_state_if_changed(100, true)
            .expect("next timed walking frame");
        assert!(rendered_path(&second).ends_with("/57.png"));
    }

    #[test]
    fn authoritative_turn_selects_all_eight_real_player_directions_for_every_actor_layer() {
        let payload = |direction: &str| {
            json!({
                "sceneView": {"center": {"x": 10, "y": 10}},
                "entities": [{
                    "objectId": 1,
                    "kind": "selfPlayer",
                    "classKey": "warrior",
                    "genderKey": "male",
                    "x": 10,
                    "y": 10,
                    "direction": direction,
                    "dead": false,
                    "sprite": {
                        "bodyLibrary": "CArmour/01",
                        "hairLibrary": "CHair/00",
                        "weaponLibrary": "CWeapon/00",
                        "frameBaseOffset": 0,
                        "weaponFrameOffset": 0,
                        "directionStride": 4
                    }
                }]
            })
        };
        let mut presentation = NativeEntityPresentation::default();
        let mut body_paths = HashSet::new();

        for (direction, direction_index) in [
            ("Up", 0_i64),
            ("UpRight", 1),
            ("Right", 2),
            ("DownRight", 3),
            ("Down", 4),
            ("DownLeft", 5),
            ("Left", 6),
            ("UpLeft", 7),
        ] {
            presentation.replace_payload(payload(direction));
            let state = presentation
                .render_state_if_changed(0, true)
                .unwrap_or_else(|| panic!("{direction} must republish a changed standing pose"));
            let layers = state["entities"][0]["layers"]
                .as_array()
                .expect("player actor layers");
            let expected_frame = direction_index * 4;
            for (role, library) in [
                ("body", "CArmour/01"),
                ("hair", "CHair/00"),
                ("weapon-primary", "CWeapon/00"),
            ] {
                let key = format!("1:{role}");
                let layer = layers
                    .iter()
                    .find(|layer| layer["key"].as_str() == Some(key.as_str()))
                    .unwrap_or_else(|| panic!("{direction} missing {role}"));
                assert_eq!(
                    layer["path"],
                    json!(format!("/original-ui/{library}/{expected_frame}.png")),
                    "{direction} must select the same real direction band for {role}"
                );
                if role == "body" {
                    body_paths.insert(layer["path"].as_str().unwrap().to_owned());
                }
            }
        }

        assert_eq!(
            body_paths.len(),
            8,
            "Crystal player standing uses eight real direction bands, not one diagonal or mirrored fallback"
        );
    }

    #[test]
    fn attack_range_two_parser_uses_the_crystal_player_action() {
        assert_eq!(
            parse_action("attackRange2"),
            Some(AnimationAction::AttackRange2)
        );
    }

    #[test]
    fn duplicate_action_sequence_does_not_restart_animation() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(7));
        let _ = presentation.render_state_if_changed(0, true);
        let second = presentation
            .render_state_if_changed(100, true)
            .expect("second frame");
        assert!(rendered_path(&second).ends_with("/57.png"));

        presentation.replace_payload(player_payload(7));
        let repeated = presentation
            .render_state_if_changed(100, true)
            .expect("authoritative payload refresh");
        assert!(rendered_path(&repeated).ends_with("/57.png"));
        let third = presentation
            .render_state_if_changed(200, true)
            .expect("continued frame");
        assert!(rendered_path(&third).ends_with("/58.png"));
    }

    #[test]
    fn crowded_owner_hits_keep_one_waiting_flinch_behind_attack() {
        let mut presentation = NativeEntityPresentation::default();
        let mut payload = player_payload(1);
        payload["entities"][0]["_nativeAnimationAction"] = json!("attack1");
        presentation.observe_packet_payload(payload.clone(), 0);
        for sequence in 2..=49 {
            payload["entities"][0]["_nativeAnimationAction"] = json!("struck");
            payload["entities"][0]["_nativeAnimationSequence"] = json!(sequence);
            presentation.observe_packet_payload(payload.clone(), 50);
        }
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(state.pose().action, AnimationAction::Attack1);
        assert_eq!(
            state.queue_depth(),
            1,
            "48 real hit packets must not become 48 flinches"
        );
        assert_eq!(
            state.queued_actions().next().unwrap().action,
            AnimationAction::Struck
        );
    }

    #[test]
    fn crowded_owner_escape_starts_fresh_motion_instead_of_replaying_old_flinches() {
        let mut presentation = NativeEntityPresentation::default();
        let mut payload = player_payload(1);
        payload["entities"][0]["_nativeAnimationAction"] = json!("standing");
        presentation.observe_packet_payload(payload.clone(), 0);
        for sequence in 2..=49 {
            payload["entities"][0]["_nativeAnimationAction"] = json!("struck");
            payload["entities"][0]["_nativeAnimationSequence"] = json!(sequence);
            presentation.observe_packet_payload(payload.clone(), 50);
        }
        assert!(presentation.begin_local_self_motion(
            "1",
            (10, 10),
            (11, 10),
            "right",
            false,
            100,
            1_100
        ));
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(
            state.pose().action,
            AnimationAction::Walking,
            "fresh escape was queued behind stale hits"
        );
        assert_eq!(state.queue_depth(), 0);
        assert_eq!(
            presentation.overlay_payload().unwrap()["entities"][0]["x"],
            json!(10),
            "pixels cannot forge tile authority"
        );
        let before_ack = presentation.motion_windows["1"];
        assert!(before_ack.locally_predicted);
        let mut acknowledged = player_payload(51);
        acknowledged["sceneView"]["center"]["x"] = json!(11);
        acknowledged["entities"][0]["x"] = json!(11);
        acknowledged["entities"][0]["direction"] = json!("right");
        presentation.replace_payload(acknowledged);
        presentation.sync_pending_payload(200, 1_200);
        let after_ack = presentation.motion_windows["1"];
        assert!(!after_ack.locally_predicted);
        assert_eq!(after_ack.started_ms, before_ack.started_ms);
        assert_eq!(after_ack.expires_ms, before_ack.expires_ms);
        assert_eq!(
            presentation.world.active_state("1").unwrap().queue_depth(),
            0
        );
    }

    #[test]
    fn crowded_authoritative_move_does_not_wait_for_old_hit_reactions() {
        let mut presentation = NativeEntityPresentation::default();
        let mut payload = player_payload(1);
        payload["entities"][0]["_nativeAnimationAction"] = json!("struck");
        presentation.replace_payload(payload.clone());
        presentation.sync_pending_payload(0, 1_000);
        payload["entities"][0]["_nativeAnimationSequence"] = json!(2);
        presentation.replace_payload(payload.clone());
        presentation.sync_pending_payload(50, 1_050);
        payload["entities"][0]["_nativeAnimationSequence"] = json!(3);
        payload["entities"][0]["_nativeAnimationAction"] = json!("walking");
        payload["entities"][0]["direction"] = json!("right");
        payload["entities"][0]["x"] = json!(11);
        payload["sceneView"]["center"]["x"] = json!(11);
        presentation.replace_payload(payload);
        presentation.sync_pending_payload(100, 1_100);
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(state.pose().action, AnimationAction::Walking);
        assert_eq!(state.queue_depth(), 0);
        assert_eq!(presentation.motion_windows["1"].started_ms, 1_100);
    }

    #[test]
    fn crowded_sixty_escape_steps_with_continuing_hits_have_no_historical_animation_backlog() {
        let mut presentation = NativeEntityPresentation::default();
        let mut payload = player_payload(1);
        payload["entities"][0]["_nativeAnimationAction"] = json!("standing");
        presentation.replace_payload(payload.clone());
        presentation.sync_pending_payload(0, 1_000);
        let mut sequence = 1;
        for step in 0..60 {
            let animation_ms = step as u64 * 600;
            let motion_ms = 1_000 + animation_ms;
            let x = 10 + step;
            for _ in 0..8 {
                sequence += 1;
                payload["entities"][0]["_nativeAnimationAction"] = json!("struck");
                payload["entities"][0]["_nativeAnimationSequence"] = json!(sequence);
                presentation.replace_payload(payload.clone());
                presentation.sync_pending_payload(animation_ms, motion_ms);
            }
            assert!(presentation.begin_local_self_motion(
                "1",
                (x, 10),
                (x + 1, 10),
                "right",
                false,
                animation_ms,
                motion_ms
            ));
            let state = presentation.world.active_state("1").unwrap();
            assert_eq!(
                state.pose().action,
                AnimationAction::Walking,
                "escape step {step}"
            );
            assert_eq!(state.queue_depth(), 0, "escape step {step}");
            sequence += 1; // The real packet adapter does not count local predictions.
            payload["entities"][0]["_nativeAnimationAction"] = json!("walking");
            payload["entities"][0]["_nativeAnimationSequence"] = json!(sequence);
            payload["entities"][0]["direction"] = json!("right");
            payload["entities"][0]["x"] = json!(x + 1);
            payload["sceneView"]["center"]["x"] = json!(x + 1);
            presentation.replace_payload(payload.clone());
            presentation.sync_pending_payload(animation_ms + 100, motion_ms + 100);
            assert_eq!(presentation.motion_windows["1"].started_ms, motion_ms);
            for _ in 0..8 {
                sequence += 1;
                payload["entities"][0]["_nativeAnimationAction"] = json!("struck");
                payload["entities"][0]["_nativeAnimationSequence"] = json!(sequence);
                presentation.replace_payload(payload.clone());
                presentation.sync_pending_payload(animation_ms + 200, motion_ms + 200);
            }
            assert!(presentation.world.active_state("1").unwrap().queue_depth() <= 1);
        }
    }

    #[test]
    fn same_frame_packet_payloads_retain_attack_then_struck_in_action_feed() {
        for kind in ["selfPlayer", "monster"] {
            let mut presentation = NativeEntityPresentation::default();
            let mut payload = player_payload(1);
            payload["entities"][0]["kind"] = json!(kind);
            if kind == "monster" {
                payload["entities"][0]["sprite"]["bodyLibrary"] = json!("Monster/005");
            }
            payload["entities"][0]["_nativeAnimationAction"] = json!("attack1");
            presentation.observe_packet_payload(payload.clone(), 0);
            payload["entities"][0]["_nativeAnimationAction"] = json!("struck");
            payload["entities"][0]["_nativeAnimationSequence"] = json!(2);
            presentation.observe_packet_payload(payload.clone(), 0);
            // Repeated UI/health projections must not replay the same action.
            presentation.observe_packet_payload(payload, 0);
            let state = presentation.world.active_state("1").unwrap();
            let actions = std::iter::once(state.pose().action)
                .chain(state.queued_actions().map(|event| event.action))
                .collect::<Vec<_>>();
            assert!(
                actions.contains(&AnimationAction::Attack1),
                "{kind}: {actions:?}"
            );
            assert_eq!(
                actions
                    .iter()
                    .filter(|action| **action == AnimationAction::Struck)
                    .count(),
                1
            );
            assert_eq!(state.last_enqueued_event_sequence(), Some(2));
            let mut attack_frames = HashSet::new();
            let mut struck_frames = HashSet::new();
            let mut played_actions = Vec::new();
            // Drive the real presentation tick and inspect the frame/action
            // pair passed to the renderer, not merely queued event presence.
            for now_ms in (0..=5_000).step_by(25) {
                presentation.render_state_if_changed_with_clocks(
                    now_ms,
                    now_ms,
                    true,
                    |_, frames, _| {
                        let (frame, action) = frames["1"];
                        if matches!(action, AnimationAction::Attack1 | AnimationAction::Struck) {
                            if played_actions.last() != Some(&action) {
                                played_actions.push(action);
                            }
                            match action {
                                AnimationAction::Attack1 => {
                                    attack_frames.insert(frame);
                                }
                                AnimationAction::Struck => {
                                    struck_frames.insert(frame);
                                }
                                _ => unreachable!(),
                            }
                        }
                        Some(Value::Null)
                    },
                );
            }
            assert_eq!(
                played_actions,
                vec![AnimationAction::Attack1, AnimationAction::Struck],
                "{kind}: actions were skipped, reordered or replayed"
            );
            assert!(
                attack_frames.len() >= 2,
                "{kind}: attack did not advance: {attack_frames:?}"
            );
            assert!(
                struck_frames.len() >= 2,
                "{kind}: struck did not advance: {struck_frames:?}"
            );
            presentation.reset_session();
            assert!(presentation.world.active_state("1").is_none());
        }
    }

    #[test]
    fn native_motion_offset_matches_crystal_phase_boundaries_and_even_pixels() {
        let horizontal = NativeMotionWindow {
            from_x: 10.0,
            from_y: 10.0,
            to_x: 11.0,
            to_y: 10.0,
            sort_x: 10,
            sort_y: 10,
            started_ms: 1_000,
            expires_ms: 1_600,
            phase_count: 6,
            animation_sequence: 1,
            action: AnimationAction::Walking,
            direction: Direction::Right,
            locally_predicted: false,
            locally_settled: false,
        };
        assert_eq!(native_motion_offset(&horizontal, 1_000), (-40.0, 0.0));
        assert_eq!(native_motion_offset(&horizontal, 1_099), (-40.0, 0.0));
        assert_eq!(native_motion_offset(&horizontal, 1_100), (-32.0, 0.0));
        assert_eq!(native_motion_offset(&horizontal, 1_499), (-8.0, 0.0));
        assert_eq!(native_motion_offset(&horizontal, 1_500), (0.0, 0.0));
        assert_eq!(native_motion_offset(&horizontal, 1_600), (0.0, 0.0));

        let vertical = NativeMotionWindow {
            from_x: 10.0,
            from_y: 10.0,
            to_x: 10.0,
            to_y: 9.0,
            sort_x: 10,
            sort_y: 10,
            started_ms: 2_000,
            expires_ms: 2_600,
            phase_count: 6,
            animation_sequence: 2,
            action: AnimationAction::Walking,
            direction: Direction::Up,
            locally_predicted: false,
            locally_settled: false,
        };
        assert_eq!(native_motion_offset(&vertical, 2_000), (0.0, 26.0));
        assert_eq!(native_motion_offset(&vertical, 2_100), (0.0, 22.0));
        assert_eq!(crystal_even_pixel(-21.9), -22.0);
        assert_eq!(crystal_even_pixel(21.9), 22.0);
    }

    #[test]
    fn authoritative_move_uses_wall_clock_and_keeps_self_screen_locked() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 1_700_000_000_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial authoritative payload");

        let mut moved = player_payload(2);
        moved["sceneView"]["center"]["x"] = json!(11);
        moved["entities"][0]["x"] = json!(11);
        presentation.replace_payload(moved);
        let rendered = presentation
            .render_state_if_changed_with_clocks(100, 1_700_000_000_100, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("moved authoritative payload");

        let entity = &rendered["entities"][0];
        assert_eq!(entity["motionFromX"], json!(10.0));
        assert_eq!(entity["motionToX"], json!(11.0));
        assert_eq!(entity["motionSortX"], json!(10));
        assert_eq!(entity["motionSortY"], json!(10));
        assert_eq!(entity["motionStartedMs"], json!(1_700_000_000_100_u64));
        assert_eq!(entity["motionDurationMs"], json!(600));
        assert_eq!(
            presentation.camera_screen_offset(1_700_000_000_100),
            (40.0, 0.0)
        );
        assert_eq!(
            presentation.entity_screen_offset("1", 1_700_000_000_100),
            (0.0, 0.0),
            "self motion and camera motion must cancel"
        );
        assert_eq!(
            presentation.entity_screen_offset("remote", 1_700_000_000_100),
            (40.0, 0.0),
            "static world actors follow the moving self camera"
        );
        assert_eq!(
            presentation.camera_screen_offset(1_700_000_000_700),
            (0.0, 0.0)
        );

        let mut teleported = player_payload(3);
        teleported["sceneView"]["center"]["x"] = json!(20);
        teleported["entities"][0]["x"] = json!(20);
        presentation.replace_payload(teleported);
        let rendered = presentation
            .render_state_if_changed_with_clocks(200, 1_700_000_000_200, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("teleport payload");
        assert!(rendered["entities"][0].get("motionFromX").is_none());
        assert!(!presentation.has_active_motion(1_700_000_000_200));
    }

    #[test]
    fn movement_sort_anchor_expires_without_waiting_for_another_snapshot() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 1_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial payload");

        let mut moved = player_payload(2);
        moved["sceneView"]["center"]["x"] = json!(11);
        moved["entities"][0]["x"] = json!(11);
        presentation.replace_payload(moved);
        let moving = presentation
            .render_state_if_changed_with_clocks(100, 1_100, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("moving payload");
        assert_eq!(moving["entities"][0]["motionSortX"], json!(10));

        let settled = presentation
            .render_state_if_changed_with_clocks(700, 1_700, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("locally settled payload");
        assert!(settled["entities"][0].get("motionSortX").is_none());
        assert!(settled["entities"][0].get("motionFromX").is_none());
        assert_eq!(settled["entities"][0]["x"], json!(11));
    }

    #[test]
    fn late_self_run_ack_never_replays_completed_prediction_or_blocks_correction() {
        let render = |p: &mut NativeEntityPresentation, time| {
            p.render_state_if_changed_with_clocks(time - 1000, time, true, |payload, _, _| {
                Some(payload.clone())
            });
        };
        let mut p = NativeEntityPresentation::default();
        let mut initial = player_payload(7);
        initial["entities"][0]["_nativeAnimationAction"] = json!("standing");
        p.replace_payload(initial.clone());
        render(&mut p, 1000);
        assert!(p.begin_local_self_motion("1", (10, 10), (12, 10), "right", true, 100, 1100));
        render(&mut p, 1700);
        assert_eq!(
            p.latest_payload.as_ref().unwrap()["entities"][0]["x"],
            json!(10),
            "unacknowledged render coordinates must remain coherent with the source map"
        );
        assert_eq!(
            p.latest_payload.as_ref().unwrap()["sceneView"]["center"]["x"],
            json!(10)
        );
        assert_eq!(
            p.last_positions["1"],
            (12, 10),
            "receipt remembers the already-played endpoint"
        );
        assert!(p.motion_windows["1"].locally_settled);
        let mut ack = player_payload(9);
        ack["entities"][0]["x"] = json!(12);
        ack["entities"][0]["direction"] = json!("right");
        ack["entities"][0]["_nativeAnimationAction"] = json!("running");
        ack["sceneView"]["center"]["x"] = json!(12);
        p.replace_payload(ack.clone());
        render(&mut p, 1850);
        assert!(
            !p.has_active_motion(1850),
            "late ACK cannot restart movement"
        );
        assert_eq!(
            p.world.active_state("1").unwrap().pose().action,
            AnimationAction::Standing
        );
        assert_eq!(p.last_positions["1"], (12, 10));
        assert!(p.begin_local_self_motion("1", (12, 10), (14, 10), "right", true, 900, 1900));
        for time in [2000, 2100, 2300] {
            p.replace_payload(ack.clone());
            render(&mut p, time);
            assert_eq!(
                p.motion_windows["1"].started_ms, 1900,
                "source echoes cannot restart second run"
            );
            assert_eq!(
                p.latest_payload.as_ref().unwrap()["sceneView"]["center"]["x"],
                json!(12)
            );
            assert_eq!(
                p.latest_payload.as_ref().unwrap()["entities"][0]["x"],
                json!(12)
            );
        }
        render(&mut p, 2500);
        p.replace_payload(ack.clone());
        render(&mut p, 2600);
        assert_eq!(
            p.latest_payload.as_ref().unwrap()["entities"][0]["x"],
            json!(12),
            "render center stays source until ACK"
        );
        assert_eq!(
            p.latest_payload.as_ref().unwrap()["sceneView"]["center"]["x"],
            json!(12)
        );
        assert_eq!(p.last_positions["1"], (14, 10));
        assert!(p.motion_windows["1"].locally_predicted);
        p.cancel_local_self_prediction("1", (12, 10), "left");
        assert!(!p.motion_windows.contains_key("1"));
        assert_eq!(
            p.latest_payload.as_ref().unwrap()["entities"][0]["x"],
            json!(12)
        );
        assert_eq!(
            p.latest_payload.as_ref().unwrap()["sceneView"]["center"]["x"],
            json!(12)
        );
        assert_eq!(p.last_positions["1"], (12, 10));
    }

    #[test]
    fn local_self_command_starts_pixels_immediately_and_ack_keeps_its_window() {
        let mut presentation = NativeEntityPresentation::default();
        let mut initial = player_payload(7);
        initial["entities"][0]["_nativeAnimationAction"] = json!("standing");
        presentation.replace_payload(initial);
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 1_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial standing self");

        assert!(presentation.begin_local_self_motion(
            "1",
            (10, 10),
            (11, 10),
            "right",
            false,
            100,
            1_100,
        ));
        assert!(presentation.has_active_motion(1_100));
        assert!(
            !presentation.has_active_non_self_motion(1_100),
            "local self motion must move the retained camera root instead of rebuilding labels"
        );
        let predicted = presentation
            .render_state_if_changed_with_clocks(100, 1_100, true, |payload, frames, _| {
                assert_eq!(
                    frames.get("1").map(|(_, action)| *action),
                    Some(AnimationAction::Walking)
                );
                Some(payload.clone())
            })
            .expect("command-time walking pixels");
        assert_eq!(predicted["entities"][0]["x"], json!(10));
        assert_eq!(predicted["entities"][0]["direction"], json!("right"));
        let predicted_window = presentation.motion_windows["1"];
        assert!(predicted_window.locally_predicted);
        assert_eq!(predicted_window.started_ms, 1_100);
        assert_eq!(predicted_window.expires_ms, 1_700);
        assert_eq!(predicted_window.animation_sequence, 8);

        let mut acknowledged = player_payload(9);
        acknowledged["sceneView"]["center"]["x"] = json!(11);
        acknowledged["entities"][0]["x"] = json!(11);
        acknowledged["entities"][0]["direction"] = json!("right");
        presentation.replace_payload(acknowledged);
        let rendered = presentation
            .render_state_if_changed_with_clocks(200, 1_200, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("authoritative confirmation");

        let confirmed = presentation.motion_windows["1"];
        assert!(!confirmed.locally_predicted);
        assert_eq!(confirmed.started_ms, 1_100, "ACK restarted the visual path");
        assert_eq!(confirmed.expires_ms, 1_700);
        assert_eq!(confirmed.animation_sequence, 9);
        assert_eq!(rendered["entities"][0]["motionFromX"], json!(10.0));
        assert_eq!(rendered["entities"][0]["motionToX"], json!(11.0));
        assert_eq!(rendered["entities"][0]["motionSortX"], json!(10));
        assert_eq!(rendered["entities"][0]["motionSortY"], json!(10));
        assert_eq!(rendered["entities"][0]["motionStartedMs"], json!(1_100));
        assert_eq!(presentation.last_applied_sequence.get("1"), Some(&9));
    }

    fn prediction_with_next_source_sequence_collision() -> NativeEntityPresentation {
        let mut presentation = NativeEntityPresentation::default();
        let mut initial = player_payload(7);
        initial["entities"][0]["_nativeAnimationAction"] = json!("standing");
        presentation.replace_payload(initial);
        presentation.sync_pending_payload(0, 1_000);
        assert!(presentation.begin_local_self_motion(
            "1",
            (10, 10),
            (11, 10),
            "right",
            false,
            100,
            1_100,
        ));
        assert_eq!(presentation.motion_windows["1"].animation_sequence, 8);
        presentation
    }

    #[test]
    fn synthetic_prediction_sequence_collision_cannot_drop_next_real_death() {
        let mut presentation = prediction_with_next_source_sequence_collision();
        // The adapter's clock was not advanced by local pixels. Its very next
        // real event therefore has the number used by the prediction above.
        let mut death = player_payload(8);
        death["entities"][0]["_nativeAnimationAction"] = json!("die");
        death["entities"][0]["dead"] = json!(true);
        presentation.replace_payload(death.clone());
        presentation.sync_pending_payload(200, 1_200);
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(
            state
                .queued_actions()
                .map(|event| event.action)
                .collect::<Vec<_>>(),
            vec![AnimationAction::Die],
            "a source Death must retain its life barrier"
        );
        assert_eq!(
            presentation.overlay_payload().unwrap()["entities"][0]["x"],
            json!(10)
        );
        presentation.replace_payload(death);
        presentation.sync_pending_payload(250, 1_250);
        assert_eq!(
            presentation.world.active_state("1").unwrap().queue_depth(),
            1,
            "repeated Death projections cannot queue a second life barrier"
        );
        presentation.world.tick(700).unwrap();
        assert_eq!(
            presentation.world.active_state("1").unwrap().pose().action,
            AnimationAction::Die
        );
    }

    #[test]
    fn synthetic_prediction_sequence_collision_cannot_drop_next_real_spell() {
        let mut presentation = prediction_with_next_source_sequence_collision();
        let mut spell = player_payload(8);
        spell["entities"][0]["_nativeAnimationAction"] = json!("spell");
        presentation.replace_payload(spell.clone());
        presentation.sync_pending_payload(200, 1_200);
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(
            state
                .queued_actions()
                .map(|event| event.action)
                .collect::<Vec<_>>(),
            vec![AnimationAction::Spell],
            "a source cast must retain its FIFO barrier"
        );
        presentation.replace_payload(spell);
        presentation.sync_pending_payload(250, 1_250);
        assert_eq!(
            presentation.world.active_state("1").unwrap().queue_depth(),
            1,
            "repeated cast projections cannot replay the spell"
        );
        presentation.world.tick(700).unwrap();
        assert_eq!(
            presentation.world.active_state("1").unwrap().pose().action,
            AnimationAction::Spell
        );
    }

    #[test]
    fn synthetic_prediction_sequence_collision_ack_keeps_original_motion_window() {
        let mut presentation = prediction_with_next_source_sequence_collision();
        let prediction = presentation.motion_windows["1"];
        let mut ack = player_payload(8);
        ack["entities"][0]["direction"] = json!("right");
        ack["entities"][0]["x"] = json!(11);
        ack["sceneView"]["center"]["x"] = json!(11);
        presentation.replace_payload(ack.clone());
        presentation.sync_pending_payload(200, 1_200);
        let confirmed = presentation.motion_windows["1"];
        assert!(!confirmed.locally_predicted);
        assert_eq!(confirmed.started_ms, prediction.started_ms);
        assert_eq!(confirmed.expires_ms, prediction.expires_ms);
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(state.pose().action, AnimationAction::Walking);
        assert_eq!(state.queue_depth(), 0);
        assert_eq!(
            state.last_started_event_sequence(),
            Some(confirmed.animation_sequence),
            "the motion window and active animation must use one presentation sequence"
        );
        let last_enqueued = state.last_enqueued_event_sequence();
        presentation.replace_payload(ack.clone());
        presentation.sync_pending_payload(250, 1_250);
        assert_eq!(
            presentation.motion_windows["1"].started_ms,
            prediction.started_ms
        );
        assert_eq!(
            presentation
                .world
                .active_state("1")
                .unwrap()
                .last_enqueued_event_sequence(),
            last_enqueued
        );
        presentation.render_state_if_changed_with_clocks(700, 1_700, true, |payload, _, _| {
            Some(payload.clone())
        });
        presentation.replace_payload(ack);
        presentation.sync_pending_payload(800, 1_800);
        assert!(
            !presentation.has_active_motion(1_800),
            "a completed movement cannot replay on its repeated ACK"
        );
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(state.pose().action, AnimationAction::Standing);
        assert_eq!(state.queue_depth(), 0);
    }

    #[test]
    fn synthetic_prediction_sequence_collision_stale_echo_cannot_retire_future_death() {
        let mut presentation = prediction_with_next_source_sequence_collision();
        let mut first_ack = player_payload(8);
        first_ack["entities"][0]["direction"] = json!("right");
        first_ack["entities"][0]["x"] = json!(11);
        first_ack["sceneView"]["center"]["x"] = json!(11);
        presentation.replace_payload(first_ack.clone());
        presentation.sync_pending_payload(200, 1_200);
        assert!(presentation.begin_local_self_motion(
            "1",
            (11, 10),
            (12, 10),
            "right",
            false,
            700,
            1_700,
        ));
        let prediction = presentation.motion_windows["1"];
        // Reconciliation rewrites this old source echo with the second
        // prediction's higher animation number. That is not its packet number.
        presentation.replace_payload(first_ack);
        presentation.sync_pending_payload(750, 1_750);
        assert_eq!(
            presentation.motion_windows["1"].started_ms,
            prediction.started_ms
        );
        assert_eq!(
            presentation.world.active_state("1").unwrap().queue_depth(),
            0
        );
        let mut death = player_payload(9);
        death["entities"][0]["x"] = json!(11);
        death["sceneView"]["center"]["x"] = json!(11);
        death["entities"][0]["_nativeAnimationAction"] = json!("die");
        death["entities"][0]["dead"] = json!(true);
        presentation.replace_payload(death);
        presentation.sync_pending_payload(800, 1_800);
        assert_eq!(
            presentation
                .world
                .active_state("1")
                .unwrap()
                .queued_actions()
                .map(|event| event.action)
                .collect::<Vec<_>>(),
            vec![AnimationAction::Die],
            "normalizing a stale receipt cannot consume the next real Death"
        );
    }

    #[test]
    fn attack_packet_waits_for_local_run_window_before_rendering_attack_pose() {
        let mut presentation = NativeEntityPresentation::default();
        let mut initial = player_payload(7);
        initial["entities"][0]["_nativeAnimationAction"] = json!("standing");
        presentation.replace_payload(initial);
        presentation
            .render_state_if_changed_with_clocks(0, 1_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial player");
        assert!(presentation.begin_local_self_motion(
            "1",
            (10, 10),
            (12, 10),
            "right",
            true,
            100,
            1_100,
        ));

        let mut attack = player_payload(9);
        attack["entities"][0]["x"] = json!(12);
        attack["sceneView"]["center"]["x"] = json!(12);
        attack["entities"][0]["direction"] = json!("right");
        attack["entities"][0]["_nativeAnimationAction"] = json!("attack1");
        presentation.replace_payload(attack);
        presentation
            .render_state_if_changed_with_clocks(200, 1_200, true, |payload, frames, _| {
                assert_eq!(frames["1"].1, AnimationAction::Running);
                assert!(payload["entities"][0].get("motionStartedMs").is_some());
                Some(payload.clone())
            })
            .expect("run still visible while early attack is queued");
        assert!(presentation.last_attack_motion_overlap.is_none());

        presentation
            .render_state_if_changed_with_clocks(700, 1_700, true, |payload, frames, _| {
                assert_eq!(frames["1"].1, AnimationAction::Attack1);
                assert!(payload["entities"][0].get("motionStartedMs").is_none());
                Some(payload.clone())
            })
            .expect("attack starts only after run pixels settle");
        assert!(presentation.last_attack_motion_overlap.is_none());
    }

    #[test]
    fn mismatched_animation_and_motion_clocks_detect_attack_motion_overlap_once() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(7));
        presentation
            .render_state_if_changed_with_clocks(0, 1_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial player");
        assert!(presentation.begin_local_self_motion(
            "1",
            (10, 10),
            (12, 10),
            "right",
            true,
            100,
            1_100,
        ));
        let mut attack = player_payload(9);
        attack["entities"][0]["x"] = json!(12);
        attack["sceneView"]["center"]["x"] = json!(12);
        attack["entities"][0]["_nativeAnimationAction"] = json!("attack1");
        presentation.replace_payload(attack);
        presentation
            .render_state_if_changed_with_clocks(200, 1_200, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("attack queued behind run");

        // Deliberately advance the animation clock ahead of the wall-clock
        // motion window: this is the exact visual anomaly the sparse trace
        // must distinguish from a harmless delayed network ACK.
        presentation
            .render_state_if_changed_with_clocks(700, 1_300, true, |payload, frames, _| {
                assert_eq!(frames["1"].1, AnimationAction::Attack1);
                assert!(payload["entities"][0].get("motionStartedMs").is_some());
                Some(payload.clone())
            })
            .expect("skewed attack pose overlaps active motion");
        let first = presentation
            .last_attack_motion_overlap
            .expect("overlap recorded");
        presentation.render_state_if_changed_with_clocks(750, 1_350, true, |payload, _, _| {
            Some(payload.clone())
        });
        assert_eq!(presentation.last_attack_motion_overlap, Some(first));
        presentation.render_state_if_changed_with_clocks(800, 1_700, true, |payload, _, _| {
            Some(payload.clone())
        });
        assert!(presentation.last_attack_motion_overlap.is_none());
    }

    #[test]
    fn unchanged_correction_removes_only_the_local_prediction() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 1_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial self");
        assert!(presentation.begin_local_self_motion(
            "1",
            (10, 10),
            (11, 10),
            "right",
            false,
            100,
            1_100,
        ));

        presentation.cancel_local_self_prediction("1", (10, 10), "left");

        assert!(!presentation.motion_windows.contains_key("1"));
        assert!(presentation.payload_dirty);
        assert_eq!(
            presentation.latest_payload.as_ref().unwrap()["entities"][0]["x"],
            json!(10)
        );
        assert_eq!(
            presentation.latest_payload.as_ref().unwrap()["entities"][0]["direction"],
            json!("left")
        );
        assert_eq!(
            presentation.latest_payload.as_ref().unwrap()["sceneView"]["center"]["x"],
            json!(10)
        );
    }

    #[test]
    fn mounted_walk_uses_eight_phases_and_packet_carried_wall_clock() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(mounted_player_payload(20, "walking"));
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 10_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial mounted player payload");

        let mut moved = mounted_player_payload(21, "walking");
        moved["sceneView"]["center"]["x"] = json!(11);
        moved["entities"][0]["x"] = json!(11);
        moved["entities"][0]["direction"] = json!("right");
        moved["entities"][0]["movementStartedAt"] = json!(10_100.0);
        moved["entities"][0]["movementUntil"] = json!(10_900.0);
        presentation.replace_payload(moved);
        let rendered = presentation
            .render_state_if_changed_with_clocks(100, 10_350, true, |payload, frames, _| {
                let mut payload = payload.clone();
                payload["_testDrawFrame"] = json!(frames["1"].0);
                Some(payload)
            })
            .expect("packet-timed mounted walk");

        let entity = &rendered["entities"][0];
        assert_eq!(entity["motionFromX"], json!(10.0));
        assert_eq!(entity["motionToX"], json!(11.0));
        assert_eq!(entity["motionStartedMs"], json!(10_100_u64));
        assert_eq!(entity["motionDurationMs"], json!(800_u64));
        assert_eq!(rendered["_testDrawFrame"], json!(466));
        assert_eq!(presentation.camera_screen_offset(10_350), (30.0, 0.0));
        assert_eq!(
            presentation.entity_screen_offset("1", 10_350),
            (0.0, 0.0),
            "mounted self and camera remain locked at the packet-carried phase"
        );
        assert!(presentation.has_active_motion(10_899));
        assert!(!presentation.has_active_motion(10_900));
    }

    #[test]
    fn mounted_run_remains_six_phases() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(mounted_player_payload(30, "running"));
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 20_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial mounted runner");

        let mut moved = mounted_player_payload(31, "running");
        moved["sceneView"]["center"]["x"] = json!(13);
        moved["entities"][0]["x"] = json!(13);
        moved["entities"][0]["direction"] = json!("right");
        presentation.replace_payload(moved);
        let first = presentation
            .render_state_if_changed_with_clocks(100, 20_100, true, |payload, frames, _| {
                let mut payload = payload.clone();
                payload["_testDrawFrame"] = json!(frames["1"].0);
                Some(payload)
            })
            .expect("mounted run frame zero");
        assert_eq!(first["entities"][0]["motionDurationMs"], json!(600_u64));
        assert_eq!(first["_testDrawFrame"], json!(524));

        let last = presentation
            .render_state_if_changed_with_clocks(600, 20_600, true, |payload, frames, _| {
                let mut payload = payload.clone();
                payload["_testDrawFrame"] = json!(frames["1"].0);
                Some(payload)
            })
            .expect("mounted run final phase");
        assert_eq!(last["_testDrawFrame"], json!(529));
        assert!(presentation.has_active_motion(20_699));
        assert!(!presentation.has_active_motion(20_700));
    }

    #[test]
    fn movement_phase_and_packet_time_metadata_are_bounded() {
        let mut mounted = mounted_player_payload(40, "walking");
        assert_eq!(
            native_motion_phase_count(&mounted["entities"][0], AnimationAction::Walking),
            8
        );

        mounted["entities"][0]["movementFrameCount"] = json!(7);
        assert_eq!(
            native_motion_phase_count(&mounted["entities"][0], AnimationAction::Walking),
            7
        );
        mounted["entities"][0]["movementFrameCount"] = json!(9);
        assert_eq!(
            native_motion_phase_count(&mounted["entities"][0], AnimationAction::Walking),
            8
        );
        mounted["entities"][0]["movementFrameCount"] = json!(0);
        assert_eq!(
            native_motion_phase_count(&mounted["entities"][0], AnimationAction::Walking),
            8
        );

        let active = json!({"movementStartedAt": 100.0, "movementUntil": 900.0});
        assert_eq!(native_packet_motion_window(&active, 350), Some((100, 900)));
        assert_eq!(native_packet_motion_window(&active, 99), None);
        assert_eq!(native_packet_motion_window(&active, 900), None);

        let transformed = json!({"movementStartedMs": 100, "movementDurationMs": 800});
        assert_eq!(
            native_packet_motion_window(&transformed, 350),
            Some((100, 900))
        );
        let overflow = json!({
            "movementStartedMs": u64::MAX - 1,
            "movementDurationMs": 10
        });
        assert_eq!(native_packet_motion_window(&overflow, u64::MAX), None);
    }

    #[test]
    fn overlapping_player_moves_continue_fractional_motion_and_restart_visible_phase() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 1_000, true, |payload, frames, _| {
                crate::atlas::build_entity_render_state_with_poses(payload, frames)
            })
            .expect("initial player payload");

        let mut first_move = player_payload(2);
        first_move["sceneView"]["center"]["x"] = json!(11);
        first_move["entities"][0]["x"] = json!(11);
        presentation.replace_payload(first_move);
        let first = presentation
            .render_state_if_changed_with_clocks(100, 1_100, true, |payload, frames, _| {
                crate::atlas::build_entity_render_state_with_poses(payload, frames)
            })
            .expect("first player move");
        assert!(
            rendered_path(&first).ends_with("/56.png"),
            "a new tile starts from Crystal movement frame zero"
        );
        assert_eq!(
            presentation
                .world
                .active_state("1")
                .expect("player animation state")
                .queue_depth(),
            0,
            "a newer player movement must not enqueue stale locomotion"
        );

        let mut second_move = player_payload(3);
        second_move["sceneView"]["center"]["x"] = json!(12);
        second_move["entities"][0]["x"] = json!(12);
        second_move["entities"][0]["_nativeAnimationAction"] = json!("running");
        presentation.replace_payload(second_move);
        let second = presentation
            .render_state_if_changed_with_clocks(350, 1_350, true, |payload, frames, _| {
                crate::atlas::build_entity_render_state_with_poses(payload, frames)
            })
            .expect("overlapping player move");

        let entity = &second["entities"][0];
        assert_eq!(
            entity["motionFromX"],
            json!(10.5),
            "the second segment continues from the first segment's current fractional position"
        );
        assert_eq!(entity["motionToX"], json!(12.0));
        assert_eq!(entity["motionStartedMs"], json!(1_350_u64));
        assert!(
            rendered_path(&second).ends_with("/104.png"),
            "walk-to-run restarts the running sprite with the same motion window"
        );
        let state = presentation
            .world
            .active_state("1")
            .expect("player animation state");
        assert_eq!(state.current_action, AnimationAction::Running);
        assert_eq!(state.last_started_event_sequence(), Some(3));
        assert_eq!(state.queue_depth(), 0);
        assert_eq!(presentation.last_applied_sequence.get("1"), Some(&3));
        assert_eq!(
            presentation.entity_screen_offset("1", 1_350),
            (0.0, 0.0),
            "self sprite and camera must remain locked across a rebased segment"
        );

        let mut third_move = player_payload(4);
        third_move["sceneView"]["center"]["x"] = json!(13);
        third_move["entities"][0]["x"] = json!(13);
        presentation.replace_payload(third_move);
        let third = presentation
            .render_state_if_changed_with_clocks(500, 1_500, true, |payload, frames, _| {
                crate::atlas::build_entity_render_state_with_poses(payload, frames)
            })
            .expect("run-to-walk player move");
        assert_eq!(third["entities"][0]["motionFromX"], json!(11.0));
        assert!(
            rendered_path(&third).ends_with("/56.png"),
            "run-to-walk restarts the walking sprite at frame zero"
        );
        let state = presentation
            .world
            .active_state("1")
            .expect("player animation state");
        assert_eq!(state.current_action, AnimationAction::Walking);
        assert_eq!(state.last_started_event_sequence(), Some(4));
        assert_eq!(state.queue_depth(), 0);
    }

    #[test]
    fn stale_self_source_echo_keeps_the_active_target_and_motion_window() {
        let mut presentation = NativeEntityPresentation::default();
        let mut initial = player_payload(10);
        initial["entities"][0]["direction"] = json!("right");
        presentation.replace_payload(initial);
        let _ = presentation
            .render_state_if_changed_with_clocks(0, 1_000, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("initial self payload");

        let mut moved = player_payload(11);
        moved["sceneView"]["center"]["x"] = json!(11);
        moved["entities"][0]["x"] = json!(11);
        moved["entities"][0]["direction"] = json!("right");
        presentation.replace_payload(moved);
        let _ = presentation
            .render_state_if_changed_with_clocks(100, 1_100, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("authoritative self move");

        let mut stale_echo = player_payload(12);
        // Sustained running can receive a target-centred scene snapshot whose
        // self entity is still the previous source tile. The renderer already
        // owns the active 10 -> 11 window, so overlays must consume its
        // reconciled payload instead of exposing the two-cell visual split.
        stale_echo["sceneView"]["center"]["x"] = json!(11);
        stale_echo["entities"][0]["direction"] = json!("right");
        presentation.replace_payload(stale_echo);
        let rendered = presentation
            .render_state_if_changed_with_clocks(200, 1_200, true, |payload, _, _| {
                Some(payload.clone())
            })
            .expect("stale self source echo");

        assert_eq!(rendered["sceneView"]["center"]["x"], json!(11));
        assert_eq!(rendered["entities"][0]["x"], json!(11));
        assert_eq!(rendered["entities"][0]["motionFromX"], json!(10.0));
        assert_eq!(rendered["entities"][0]["motionToX"], json!(11.0));
        assert_eq!(rendered["entities"][0]["motionStartedMs"], json!(1_100_u64));
        let overlay_payload = presentation
            .overlay_payload()
            .expect("overlay consumes the reconciled presentation payload");
        assert_eq!(overlay_payload["sceneView"]["center"]["x"], json!(11));
        assert_eq!(overlay_payload["entities"][0]["x"], json!(11));
        assert_eq!(presentation.last_positions.get("1"), Some(&(11, 10)));
        assert_eq!(presentation.last_applied_sequence.get("1"), Some(&11));
        let state = presentation
            .world
            .active_state("1")
            .expect("player animation state");
        assert_eq!(state.last_started_event_sequence(), Some(11));
        assert_eq!(state.queue_depth(), 0);

        let mut struck = player_payload(13);
        struck["entities"][0]["direction"] = json!("right");
        struck["entities"][0]["_nativeAnimationAction"] = json!("struck");
        presentation.replace_payload(struck);
        presentation.sync_pending_payload(300, 1_300);
        let state = presentation.world.active_state("1").unwrap();
        assert_eq!(state.last_enqueued_event_sequence(), Some(13));
        assert!(std::iter::once(state.pose().action)
            .chain(state.queued_actions().map(|event| event.action))
            .any(|action| action == AnimationAction::Struck));
    }

    #[test]
    fn hover_cursor_and_highlight_setting_republish_without_authoritative_packet() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        let initial = presentation
            .render_state_if_changed_with(0, true, |payload, _, _| Some(payload.clone()))
            .expect("initial local presentation payload");
        assert_eq!(initial["_nativeHighlightTarget"], json!(true));
        assert!(initial.get("_nativeHoverCursor").is_none());

        presentation.set_hover_presentation(Some((482.25, 353.5)), true);
        let hovered = presentation
            .render_state_if_changed_with(0, true, |payload, _, _| Some(payload.clone()))
            .expect("cursor-only redraw");
        assert_eq!(hovered["_nativeHoverCursor"]["x"], json!(482.25));
        assert_eq!(hovered["_nativeHoverCursor"]["y"], json!(353.5));
        assert!(presentation
            .render_state_if_changed_with(0, true, |payload, _, _| Some(payload.clone()))
            .is_none());

        presentation.set_hover_presentation(None, true);
        let cleared = presentation
            .render_state_if_changed_with(0, true, |payload, _, _| Some(payload.clone()))
            .expect("cursor-leave redraw");
        assert!(cleared.get("_nativeHoverCursor").is_none());

        presentation.set_hover_presentation(None, false);
        let disabled = presentation
            .render_state_if_changed_with(0, true, |payload, _, _| Some(payload.clone()))
            .expect("setting-only redraw");
        assert_eq!(disabled["_nativeHighlightTarget"], json!(false));
    }

    #[test]
    fn native_attack_selection_is_projected_into_the_render_only_payload() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        presentation.set_local_selected_object_id(Some("2001".to_owned()));

        let selected = presentation
            .render_state_if_changed_with(0, true, |payload, _, _| Some(payload.clone()))
            .expect("local combat selection redraw");
        assert_eq!(selected["selectedObjectId"], json!("2001"));

        presentation.set_local_selected_object_id(None);
        let cleared = presentation
            .render_state_if_changed_with(0, true, |payload, _, _| Some(payload.clone()))
            .expect("selection clear redraw");
        assert!(cleared["selectedObjectId"].is_null());
    }

    #[test]
    fn native_hover_cursor_is_independent_of_highlight_and_uses_runtime_gates() {
        use bevy::prelude::Vec2;
        use mir2_client_bevy::native_shell::{NativeShellModel, NativeShellScreen};

        let mut window = Window::default();
        window.resolution.set(1280.0, 720.0);
        window.focused = true;
        window.set_cursor_position(Some(Vec2::new(100.0, 360.0)));
        let mut shell = NativeShellModel::default();
        shell.screen = NativeShellScreen::InGame;
        assert_eq!(
            native_hover_cursor(Some(&window), Some(&shell), None, None),
            None
        );

        window.set_cursor_position(Some(Vec2::new(640.0, 360.0)));
        assert_eq!(
            native_hover_cursor(Some(&window), Some(&shell), None, None),
            Some((512.0, 384.0))
        );
        shell.screen = NativeShellScreen::Login;
        assert_eq!(
            native_hover_cursor(Some(&window), Some(&shell), None, None),
            None
        );
        shell.screen = NativeShellScreen::InGame;
        window.focused = false;
        assert_eq!(
            native_hover_cursor(Some(&window), Some(&shell), None, None),
            None
        );
    }

    #[test]
    fn rendered_hover_identity_is_published_and_cleared_fail_closed() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(player_payload(1));
        let _ = presentation.render_state_if_changed_with(0, true, |_, _, _| {
            Some(json!({"hoveredObjectId": "2001", "selfHovered": true}))
        });
        assert_eq!(presentation.hovered_object_id(), Some("2001"));
        assert!(presentation.self_hovered());

        presentation.set_hover_presentation(Some((512.0, 384.0)), false);
        assert!(presentation
            .render_state_if_changed_with(0, true, |_, _, _| None)
            .is_none());
        assert_eq!(presentation.hovered_object_id(), None);
        assert!(!presentation.self_hovered());

        presentation.reset_session();
        assert_eq!(presentation.hovered_object_id(), None);
        assert!(!presentation.self_hovered());
    }

    #[test]
    fn monster_run_normalizes_to_supported_walk_cycle() {
        assert_eq!(
            normalize_action(EntityKind::Monster, AnimationAction::Running),
            Some(AnimationAction::Walking)
        );
        assert_eq!(
            normalize_action(EntityKind::Npc, AnimationAction::Attack1),
            None
        );
        assert_eq!(
            parse_action("dashAttack"),
            Some(AnimationAction::DashAttack)
        );
    }

    #[test]
    fn projectile_completion_gate_uses_dead_action_not_dead_flag() {
        let mut presentation = NativeEntityPresentation::default();
        presentation.replace_payload(json!({
            "sceneView": {"center": {"x": 10, "y": 10}},
            "entities": [{
                "objectId": 2005,
                "kind": "monster",
                "x": 10,
                "y": 10,
                "direction": "down",
                "dead": true,
                "_nativeAnimationAction": "die",
                "_nativeAnimationSequence": 1,
                "sprite": {
                    "bodyLibrary": "Monster/005",
                    "directionStride": 10,
                    "frameBaseOffset": 0
                }
            }]
        }));
        presentation.sync_pending_payload_with(0, |_, _, _| AnimationCatalog::crystal_monster());
        assert!(
            presentation.dead_action_object_ids().is_empty(),
            "dead=true during Die must not suppress a Crystal projectile impact"
        );
        presentation.world.tick(999).expect("advance Die action");
        assert!(presentation.dead_action_object_ids().is_empty());
        presentation
            .world
            .tick(1_000)
            .expect("complete Die into terminal Dead action");
        assert_eq!(
            presentation.dead_action_object_ids(),
            HashSet::from([2005]),
            "the shared action clock closes the impact callback only at Dead"
        );
    }

    #[test]
    fn effect_option_removes_and_restores_scarecrow_post_world_layer_without_new_packet() {
        let mut presentation = NativeEntityPresentation::default();
        let manifest = crate::atlas::scarecrow_routing_atlas_manifest_fixture();
        presentation.replace_payload(json!({
            "sceneView": {"center": {"x": 10, "y": 10}, "width": 19, "height": 15},
            "entities": [{
                "objectId": 2005,
                "kind": "monster",
                "x": 10,
                "y": 10,
                "direction": "down",
                "_nativeAnimationAction": "die",
                "_nativeAnimationSequence": 1,
                "sprite": {
                    "bodyLibrary": "Monster/005",
                    "directionStride": 10,
                    "frameBaseOffset": 0
                }
            }]
        }));
        // Keep this unit test independent from a packaged frame-set manifest.
        // Monster/005 uses the compiled Crystal monster descriptor, whose
        // source ranges are separately locked against the generated catalog.
        presentation.sync_pending_payload_with(0, |_, _, _| AnimationCatalog::crystal_monster());

        let visible = presentation
            .render_state_if_changed_with(0, true, |payload, poses, effect_visible| {
                crate::atlas::build_entity_render_state_with_manifest_for_test(
                    payload,
                    poses,
                    effect_visible,
                    &manifest,
                )
            })
            .expect("effect enabled state");
        assert!(has_additive_layer(&visible));

        let hidden = presentation
            .render_state_if_changed_with(0, false, |payload, poses, effect_visible| {
                crate::atlas::build_entity_render_state_with_manifest_for_test(
                    payload,
                    poses,
                    effect_visible,
                    &manifest,
                )
            })
            .expect("option transition rebuilds the same authoritative pose");
        assert!(!has_additive_layer(&hidden));
        assert!(presentation
            .render_state_if_changed_with(0, false, |payload, poses, effect_visible| {
                crate::atlas::build_entity_render_state_with_manifest_for_test(
                    payload,
                    poses,
                    effect_visible,
                    &manifest,
                )
            })
            .is_none());

        let restored = presentation
            .render_state_if_changed_with(0, true, |payload, poses, effect_visible| {
                crate::atlas::build_entity_render_state_with_manifest_for_test(
                    payload,
                    poses,
                    effect_visible,
                    &manifest,
                )
            })
            .expect("re-enabling effects rebuilds without another gateway packet");
        assert!(has_additive_layer(&restored));
    }

    #[test]
    fn cannibal_plant_hide_finishes_before_visual_suppression_and_show_restores_it() {
        let mut presentation = NativeEntityPresentation::default();
        let payload = |sequence: u64, action: &str| {
            json!({
                "sceneView": {"center": {"x": 10, "y": 10}},
                "entities": [{
                    "objectId": 10,
                    "kind": "monster",
                    "x": 10,
                    "y": 10,
                    "direction": "down",
                    "_nativeAnimationAction": action,
                    "_nativeAnimationSequence": sequence,
                    "sprite": {
                        "bodyLibrary": "Monster/010",
                        "directionStride": 0,
                        "frameBaseOffset": 0
                    }
                }]
            })
        };

        presentation.replace_payload(payload(1, "hide"));
        let hide_start = presentation
            .render_state_if_changed(0, true)
            .expect("hide starts before suppression");
        assert!(rendered_path(&hide_start).ends_with("/Monster/010/12.png"));

        let hidden = presentation
            .render_state_if_changed(1_600, true)
            .expect("hide completion changes visible set");
        assert!(hidden["entities"]
            .as_array()
            .expect("rendered entities")
            .is_empty());

        presentation.replace_payload(payload(2, "show"));
        let show_start = presentation
            .render_state_if_changed(1_600, true)
            .expect("ObjectShow restores the entity before animation");
        assert!(rendered_path(&show_start).ends_with("/Monster/010/4.png"));
    }

    #[test]
    fn removed_hidden_object_does_not_suppress_a_reused_object_id() {
        let mut presentation = NativeEntityPresentation::default();
        let payload = |sequence: u64, action: &str, body_library: &str| {
            json!({
                "sceneView": {"center": {"x": 10, "y": 10}},
                "entities": [{
                    "objectId": 10,
                    "kind": "monster",
                    "x": 10,
                    "y": 10,
                    "direction": "down",
                    "_nativeAnimationAction": action,
                    "_nativeAnimationSequence": sequence,
                    "sprite": {
                        "bodyLibrary": body_library,
                        "directionStride": 0,
                        "frameBaseOffset": 0
                    }
                }]
            })
        };

        presentation.replace_payload(payload(1, "hide", "Monster/010"));
        presentation
            .render_state_if_changed(0, true)
            .expect("hide starts before suppression");
        presentation
            .render_state_if_changed(1_600, true)
            .expect("hide completion suppresses the plant");

        presentation.replace_payload(json!({
            "sceneView": {"center": {"x": 10, "y": 10}},
            "entities": []
        }));
        presentation
            .render_state_if_changed(1_601, true)
            .expect("ObjectRemove changes the rendered entity set");

        presentation.replace_payload(payload(1, "standing", "Monster/003"));
        let reused = presentation
            .render_state_if_changed(1_602, true)
            .expect("a later actor may reuse the removed object id");
        assert!(rendered_path(&reused).contains("/Monster/003/"));
    }

    fn vis01_catalog(kind: EntityKind, library: &str, _: bool) -> AnimationCatalog {
        let normalized = library
            .trim()
            .trim_matches('/')
            .strip_prefix("original-ui/")
            .unwrap_or_else(|| library.trim().trim_matches('/'));
        if normalized == "Monster/010" {
            let mut catalog = AnimationCatalog::new();
            for (action, descriptor) in [
                (
                    AnimationAction::Standing,
                    FrameDescriptor::from_crystal(0, 4, -4, 500, false),
                ),
                (
                    AnimationAction::Show,
                    FrameDescriptor::from_crystal(4, 8, -8, 200, false),
                ),
                (
                    AnimationAction::Hide,
                    FrameDescriptor::from_crystal(12, 8, -8, 200, true),
                ),
            ] {
                catalog
                    .insert(action, descriptor)
                    .expect("VIS-01 CannibalPlant source descriptor");
            }
            return catalog;
        }

        let mut catalog = AnimationCatalog::crystal_default(kind);
        if normalized == "Monster/004" {
            catalog
                .insert(
                    AnimationAction::Skeleton,
                    FrameDescriptor::from_crystal(224, 1, 0, 1_000, false),
                )
                .expect("VIS-01 Deer skeleton source descriptor");
        }
        catalog
    }

    fn checkpoint_frame_paths(fixture: &Value) -> Vec<String> {
        let mut paths = fixture["timeline"]
            .as_array()
            .into_iter()
            .flatten()
            .filter_map(|step| step.get("checkpoint"))
            .filter_map(|checkpoint| checkpoint.get("layers"))
            .flat_map(|layers| layers.as_array().into_iter().flatten())
            .filter_map(|layer| layer.get("path").and_then(Value::as_str))
            .map(str::to_owned)
            .collect::<Vec<_>>();
        paths.sort_unstable();
        paths.dedup();
        paths
    }

    fn rendered_layers<'a>(state: &'a Value, object_id: &str) -> &'a [Value] {
        state["entities"]
            .as_array()
            .into_iter()
            .flatten()
            .find(|entity| entity["objectId"].as_str() == Some(object_id))
            .and_then(|entity| entity["layers"].as_array())
            .map(Vec::as_slice)
            .unwrap_or_else(|| panic!("rendered layers for object {object_id}"))
    }

    fn rendered_layer<'a>(layers: &'a [Value], key: &str) -> &'a Value {
        layers
            .iter()
            .find(|layer| layer["key"].as_str() == Some(key))
            .unwrap_or_else(|| panic!("rendered layer {key}"))
    }

    fn highlight_layer_count(state: &Value) -> usize {
        state["entities"]
            .as_array()
            .into_iter()
            .flatten()
            .flat_map(|entity| entity["layers"].as_array().into_iter().flatten())
            .filter(|layer| {
                layer["key"]
                    .as_str()
                    .is_some_and(|key| key.contains(":target-highlight:"))
            })
            .count()
    }

    #[test]
    fn crystal_selected_remote_player_redraws_exact_composite_at_thirty_percent() {
        let manifest = crate::atlas::routing_atlas_manifest_fixture(&[
            "/original-ui/CArmour/00/980.png",
            "/original-ui/CHair/00/980.png",
            "/original-ui/CWeapon/00/588.png",
        ]);
        let mut payload = json!({
            "sceneView": {"center": {"x": 288, "y": 616}, "width": 19, "height": 15},
            "selectedObjectId": "1001",
            "entities": [{
                "objectId": 1001,
                "kind": "player",
                "classKey": "warrior",
                "genderKey": "female",
                "x": 289,
                "y": 616,
                "direction": "Left",
                "hidden": false,
                "sprite": {
                    "bodyLibrary": "CArmour/00",
                    "hairLibrary": "CHair/00",
                    "weaponLibrary": "CWeapon/00",
                    "frameBaseOffset": 808,
                    "weaponFrameOffset": 416,
                    "directionStride": 4
                }
            }]
        });
        let poses = HashMap::from([("1001".to_owned(), (172, AnimationAction::Attack1))]);
        let state = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload, &poses, true, &manifest,
        )
        .expect("selected remote player render state");
        let layers = rendered_layers(&state, "1001");
        assert_eq!(layers.len(), 6, "three source layers plus three redraws");

        for (role, expected_path) in [
            ("weapon-primary", "/original-ui/CWeapon/00/588.png"),
            ("body", "/original-ui/CArmour/00/980.png"),
            ("hair", "/original-ui/CHair/00/980.png"),
        ] {
            let normal = rendered_layer(layers, &format!("1001:{role}"));
            let highlight = rendered_layer(layers, &format!("1001:target-highlight:{role}"));
            assert_eq!(normal["path"], json!(expected_path));
            for field in [
                "path",
                "left",
                "top",
                "width",
                "height",
                "atlasKey",
                "atlasRectKey",
            ] {
                assert_eq!(highlight[field], normal[field], "redraw {role} {field}");
            }
            assert_eq!(highlight["opacity"], json!(0.3));
            assert_eq!(highlight["additive"], json!(true));
            assert!(highlight["z"].as_f64() > normal["z"].as_f64());
        }
        assert!(
            rendered_layer(layers, "1001:target-highlight:weapon-primary")["z"].as_f64()
                < rendered_layer(layers, "1001:target-highlight:body")["z"].as_f64()
        );
        assert!(
            rendered_layer(layers, "1001:target-highlight:body")["z"].as_f64()
                < rendered_layer(layers, "1001:target-highlight:hair")["z"].as_f64()
        );

        payload["entities"][0]["hidden"] = json!(true);
        let hidden = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload, &poses, true, &manifest,
        )
        .expect("hidden selected remote player render state");
        let hidden_layers = rendered_layers(&hidden, "1001");
        assert_eq!(
            rendered_layer(hidden_layers, "1001:body")["opacity"],
            json!(0.5)
        );
        assert_eq!(
            rendered_layer(hidden_layers, "1001:target-highlight:body")["opacity"],
            json!(0.3),
            "Crystal DrawBlend is independent of the hidden draw opacity"
        );

        let partial_manifest = crate::atlas::routing_atlas_manifest_fixture(&[
            "/original-ui/CHair/00/980.png",
            "/original-ui/CWeapon/00/588.png",
        ]);
        let partial = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload,
            &poses,
            true,
            &partial_manifest,
        )
        .expect("partially resolved player render state");
        assert_eq!(
            highlight_layer_count(&partial),
            3,
            "a verified standalone body keeps the complete selected composite"
        );
        let partial_layers = rendered_layers(&partial, "1001");
        assert!(rendered_layer(partial_layers, "1001:body")
            .get("atlasRectKey")
            .is_none());
        assert!(rendered_layer(partial_layers, "1001:target-highlight:body")
            .get("atlasRectKey")
            .is_none());

        payload["entities"][0]["kind"] = json!("selfPlayer");
        let self_selected = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload, &poses, true, &manifest,
        )
        .expect("self player render state");
        assert_eq!(highlight_layer_count(&self_selected), 0);

        payload["entities"][0]["kind"] = json!("npc");
        let npc_selected = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload, &poses, true, &manifest,
        )
        .expect("NPC render state");
        assert_eq!(highlight_layer_count(&npc_selected), 0);

        payload["entities"][0]
            .as_object_mut()
            .expect("player object")
            .remove("kind");
        let missing_kind = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload, &poses, true, &manifest,
        )
        .expect("missing-kind render state");
        assert_eq!(highlight_layer_count(&missing_kind), 0);
    }

    #[test]
    fn crystal_selected_redraw_precedes_same_and_cross_actor_flaming_sword_effects() {
        let manifest = crate::atlas::routing_atlas_manifest_fixture(&[
            "/original-ui/CArmour/00/980.png",
            "/original-ui/CHair/00/980.png",
            "/original-ui/CWeapon/00/588.png",
        ]);
        let payload = json!({
            "sceneView": {"center": {"x": 288, "y": 616}, "width": 19, "height": 15},
            "selectedObjectId": 1001,
            "entities": [
                {
                    "objectId": 1000,
                    "kind": "selfPlayer",
                    "classKey": "warrior",
                    "genderKey": "male",
                    "x": 285,
                    "y": 614,
                    "direction": "Up",
                    "sprite": {"bodyLibrary": "CArmour/00", "frameBaseOffset": 0}
                },
                {
                    "objectId": 1001,
                    "kind": "player",
                    "classKey": "warrior",
                    "genderKey": "female",
                    "x": 292,
                    "y": 618,
                    "direction": "Left",
                    "sprite": {
                        "bodyLibrary": "CArmour/00",
                        "hairLibrary": "CHair/00",
                        "weaponLibrary": "CWeapon/00",
                        "frameBaseOffset": 808,
                        "weaponFrameOffset": 416
                    }
                }
            ]
        });
        let selected = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload,
            &HashMap::from([("1001".to_owned(), (172, AnimationAction::Attack1))]),
            true,
            &manifest,
        )
        .expect("selected player state");
        let selected_layers = rendered_layers(&selected, "1001");
        let max_highlight_z = selected_layers
            .iter()
            .filter(|layer| {
                layer["key"]
                    .as_str()
                    .is_some_and(|key| key.contains(":target-highlight:"))
            })
            .filter_map(|layer| layer["z"].as_f64())
            .reduce(f64::max)
            .expect("selected composite z");

        let effect_z_for = |object_id: u32, x: i32, y: i32| {
            let mut effects = crate::effects::NativeEffects::default();
            effects.observe_render_payload(&payload);
            effects.observe(
                0,
                288,
                616,
                &[crate::gameplay_bridge::NativeEffectEvent {
                    sequence: 1,
                    generation: 1,
                    packet: "ObjectAttack".to_owned(),
                    payload: json!({
                        "objectId": object_id,
                        "location": {"x": x, "y": y},
                        "direction": "Up",
                        "spell": 8,
                        "level": 3,
                        "attackType": 0
                    }),
                }],
                &HashMap::from([(object_id, (x, y))]),
            );
            let state: Value = serde_json::from_str(
                &effects
                    .tick_with_visibility(0, true)
                    .expect("FlamingSword render state"),
            )
            .expect("FlamingSword JSON");
            state["effects"][0]["z"].as_f64().expect("FlamingSword z")
        };

        assert!(
            max_highlight_z < effect_z_for(1001, 292, 618),
            "same-actor DrawEffects must follow selected DrawBlend"
        );
        assert!(
            max_highlight_z < effect_z_for(1000, 285, 614),
            "even a shallower actor effect must follow the deeper selected redraw"
        );
    }

    #[test]
    fn crystal_selected_monster_redraw_stays_between_real_front_tiles_and_effects() {
        let manifest = crate::atlas::routing_atlas_manifest_fixture(&[
            "/original-ui/Monster/005/136.png",
            "/original-ui/Monster/005/164.png",
            "/original-ui/Monster/005/173.png",
            "/original-ui/Monster/005/224.png",
            "/original-ui/Monster/005/233.png",
        ]);
        let mut payload = json!({
            "sceneView": {"center": {"x": 288, "y": 616}, "width": 19, "height": 15},
            "selectedObjectId": 2005,
            "entities": [{
                "objectId": 2005,
                "kind": "monster",
                "x": 285,
                "y": 614,
                "direction": "Right",
                "hidden": false,
                "sprite": {
                    "bodyLibrary": "Monster/005",
                    "frameBaseOffset": 0,
                    "directionStride": 10
                }
            }]
        });

        let compressed = include_bytes!("../../../web/lib/generated/crystal-map-pack/0.map.gz");
        let mut decoder = flate2::read::GzDecoder::new(&compressed[..]);
        let mut bytes = Vec::new();
        decoder
            .read_to_end(&mut bytes)
            .expect("decode real 0.map.gz");
        let map = crate::map_parser::parse_type100_map(&bytes).expect("parse real 0.map");
        let front = crate::map_parser::resolve_map_tile_draws(&map)
            .into_iter()
            .find(|draw| {
                draw.x == 285 && draw.y == 614 && draw.layer == crate::map_parser::TileLayer::Front
            })
            .expect("VIS-01 source coordinate is a real 0.map front tile");
        let front_z = f64::from(crate::atlas::map_tile_draw_z_for_test(
            front.x, front.y, front.z,
        ));

        for (frame, action, expected_body, expected_effect) in [
            (
                136,
                AnimationAction::Struck,
                "/original-ui/Monster/005/136.png",
                None,
            ),
            (
                164,
                AnimationAction::Die,
                "/original-ui/Monster/005/164.png",
                Some("/original-ui/Monster/005/224.png"),
            ),
            (
                173,
                AnimationAction::Die,
                "/original-ui/Monster/005/173.png",
                Some("/original-ui/Monster/005/233.png"),
            ),
            (
                173,
                AnimationAction::Dead,
                "/original-ui/Monster/005/173.png",
                None,
            ),
        ] {
            let poses = HashMap::from([("2005".to_owned(), (frame, action))]);
            let state = crate::atlas::build_entity_render_state_with_manifest_for_test(
                &payload, &poses, true, &manifest,
            )
            .expect("selected Scarecrow phase render state");
            let layers = rendered_layers(&state, "2005");
            let normal = rendered_layer(layers, "2005:body");
            let highlight = rendered_layer(layers, "2005:target-highlight:body");
            assert_eq!(normal["path"], json!(expected_body));
            assert_eq!(highlight["path"], normal["path"]);
            assert_eq!(highlight["opacity"], json!(0.3));
            assert_eq!(highlight["additive"], json!(true));
            assert!(normal["z"].as_f64().unwrap() < front_z);
            assert!(front_z < highlight["z"].as_f64().unwrap());

            let effects = layers
                .iter()
                .filter(|layer| {
                    layer["additive"].as_bool() == Some(true)
                        && layer["key"] != json!("2005:target-highlight:body")
                })
                .collect::<Vec<_>>();
            assert_eq!(effects.len(), usize::from(expected_effect.is_some()));
            if let Some(expected_effect) = expected_effect {
                let effect = effects[0];
                assert_eq!(effect["path"], json!(expected_effect));
                assert!(highlight["z"].as_f64() < effect["z"].as_f64());
                assert!(!layers.iter().any(|layer| {
                    layer["key"]
                        .as_str()
                        .is_some_and(|key| key.contains("target-highlight:scarecrow-die-effect"))
                }));
            }
        }

        payload["entities"]
            .as_array_mut()
            .expect("entities")
            .push(json!({
                "objectId": "2006",
                "kind": "monster",
                "x": 286,
                "y": 614,
                "direction": "Right",
                "sprite": {"bodyLibrary": "Monster/005", "frameBaseOffset": 0, "directionStride": 10}
            }));
        payload["selectedObjectId"] = json!("2006");
        let switched = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload,
            &HashMap::from([
                ("2005".to_owned(), (136, AnimationAction::Struck)),
                ("2006".to_owned(), (136, AnimationAction::Struck)),
            ]),
            true,
            &manifest,
        )
        .expect("selection switch render state");
        assert!(!rendered_layers(&switched, "2005").iter().any(|layer| {
            layer["key"]
                .as_str()
                .is_some_and(|key| key.contains(":target-highlight:"))
        }));
        assert_eq!(
            rendered_layers(&switched, "2006")
                .iter()
                .filter(|layer| {
                    layer["key"]
                        .as_str()
                        .is_some_and(|key| key.contains(":target-highlight:"))
                })
                .count(),
            1
        );

        for selected in [Value::Null, json!(2999)] {
            payload["selectedObjectId"] = selected;
            let unselected = crate::atlas::build_entity_render_state_with_manifest_for_test(
                &payload,
                &HashMap::from([
                    ("2005".to_owned(), (136, AnimationAction::Struck)),
                    ("2006".to_owned(), (136, AnimationAction::Struck)),
                ]),
                true,
                &manifest,
            )
            .expect("unselected render state");
            assert_eq!(highlight_layer_count(&unselected), 0);
        }

        payload["selectedObjectId"] = json!(2005);
        payload["entities"]
            .as_array_mut()
            .expect("entities")
            .truncate(1);
        let individual_png = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload,
            &HashMap::from([("2005".to_owned(), (136, AnimationAction::Struck))]),
            true,
            &crate::atlas::routing_atlas_manifest_fixture(&[]),
        )
        .expect("individual source PNG render state");
        assert_eq!(highlight_layer_count(&individual_png), 1);
        let layers = rendered_layers(&individual_png, "2005");
        assert!(!layers.is_empty());
        for layer in layers {
            assert_eq!(layer["path"], "/original-ui/Monster/005/136.png");
            assert_eq!(
                (layer["width"].as_f64(), layer["height"].as_f64()),
                (Some(96.0), Some(76.0)),
                "fallback retains real source geometry"
            );
        }

        // A missing atlas rect alone is no longer missing source geometry:
        // complete packs can supply individual monster PNGs. This frame is
        // outside the source library, so neither valid source can resolve it.
        assert!(
            crate::assets::asset_path("original-ui/Monster/005/2147483647.png")
                .is_none_or(|path| !path.is_file())
        );
        let missing_rect = crate::atlas::build_entity_render_state_with_manifest_for_test(
            &payload,
            &HashMap::from([(
                "2005".to_owned(),
                (i64::from(i32::MAX), AnimationAction::Struck),
            )]),
            true,
            &crate::atlas::routing_atlas_manifest_fixture(&[]),
        )
        .expect("missing target frame state");
        assert_eq!(highlight_layer_count(&missing_rect), 0);
        assert!(
            rendered_layers(&missing_rect, "2005").is_empty(),
            "a body without atlas or individual PNG geometry fails closed instead of inventing 48x64"
        );
    }

    fn assert_vis01_checkpoint(
        presentation: &NativeEntityPresentation,
        payload: &Value,
        state: &Value,
        checkpoint: &Value,
    ) {
        let object_id = checkpoint["objectId"]
            .as_u64()
            .expect("checkpoint objectId")
            .to_string();
        let rendered = state["entities"]
            .as_array()
            .into_iter()
            .flatten()
            .find(|entity| entity["objectId"].as_str() == Some(object_id.as_str()));
        let visible = checkpoint["visible"].as_bool().unwrap_or(true);
        assert_eq!(rendered.is_some(), visible, "object {object_id} visibility");

        let payload_entity = payload["entities"]
            .as_array()
            .into_iter()
            .flatten()
            .find(|entity| {
                entity["objectId"]
                    .as_u64()
                    .is_some_and(|id| id.to_string() == object_id)
            })
            .expect("checkpoint payload entity");
        if let Some(sequence) = checkpoint.get("sequence").and_then(Value::as_u64) {
            assert_eq!(
                payload_entity["_nativeAnimationSequence"].as_u64(),
                Some(sequence),
                "object {object_id} derived packet sequence"
            );
        }
        if let Some(dead) = checkpoint.get("dead").and_then(Value::as_bool) {
            assert_eq!(payload_entity["dead"].as_bool(), Some(dead));
        }
        for field in ["x", "y", "deathKind"] {
            if let Some(expected) = checkpoint.get(field).and_then(Value::as_i64) {
                assert_eq!(
                    payload_entity[field].as_i64(),
                    Some(expected),
                    "object {object_id} authoritative {field}"
                );
            }
        }
        for field in ["direction", "disposition"] {
            if let Some(expected) = checkpoint.get(field).and_then(Value::as_str) {
                assert_eq!(
                    payload_entity[field].as_str(),
                    Some(expected),
                    "object {object_id} authoritative {field}"
                );
            }
        }
        if let Some(expected) = checkpoint.get("bodyLibrary").and_then(Value::as_str) {
            assert_eq!(
                payload_entity["sprite"]["bodyLibrary"].as_str(),
                Some(expected),
                "object {object_id} authoritative body library"
            );
        }
        if let Some(action) = checkpoint.get("action").and_then(Value::as_str) {
            let actual = presentation
                .world
                .active_state(&object_id)
                .map(|state| format!("{:?}", state.pose().action).to_ascii_lowercase())
                .expect("checkpoint animation state");
            assert_eq!(actual, action, "object {object_id} presentation action");
        }

        let Some(rendered) = rendered else {
            return;
        };
        let layers = rendered["layers"].as_array().expect("rendered layers");
        let expected_layers = checkpoint["layers"].as_array().expect("checkpoint layers");
        let redraws = layers
            .iter()
            .filter(|layer| layer["key"].as_str().unwrap().contains(":self-occlusion:"))
            .collect::<Vec<_>>();
        let expected_redraw_roles = if rendered["isSelf"] == true {
            expected_layers
                .iter()
                .filter_map(|layer| {
                    let key = layer["key"].as_str()?;
                    let role = key.rsplit(':').next()?;
                    matches!(role, "body" | "hair" | "wings").then_some(role)
                })
                .collect::<Vec<_>>()
        } else {
            Vec::new()
        };
        assert_eq!(redraws.len(), expected_redraw_roles.len());
        for role in expected_redraw_roles {
            let source = layers
                .iter()
                .find(|v| v["key"] == format!("{object_id}:{role}"))
                .unwrap();
            let redraw = redraws
                .iter()
                .find(|v| v["key"] == format!("{object_id}:self-occlusion:{role}"))
                .unwrap();
            for field in ["path", "atlasRectKey", "left", "top", "width", "height"] {
                assert_eq!(
                    source[field], redraw[field],
                    "redraw preserves {role} {field}"
                );
            }
            assert_eq!(redraw["opacity"], json!(0.4));
            assert_eq!(redraw["additive"], json!(role == "wings"));
            assert!(redraw["z"].as_f64().unwrap() > source["z"].as_f64().unwrap());
        }
        assert_eq!(
            layers.len() - redraws.len(),
            expected_layers.len(),
            "object {object_id} must have no extra or missing original actor layers"
        );
        let unique_keys = layers
            .iter()
            .filter_map(|layer| layer["key"].as_str())
            .collect::<std::collections::HashSet<_>>();
        assert_eq!(
            unique_keys.len(),
            layers.len(),
            "object {object_id} layer keys must be unique"
        );
        for expected in expected_layers {
            let key = expected["key"].as_str().expect("layer key");
            let layer = layers
                .iter()
                .find(|layer| layer["key"].as_str() == Some(key))
                .unwrap_or_else(|| panic!("missing layer {key} for object {object_id}"));
            assert_eq!(layer["path"], expected["path"], "layer {key} path");
            assert!(
                layer["atlasRectKey"].as_str().is_some(),
                "layer {key} must route through the selected atlas manifest"
            );
            if let Some(additive) = expected.get("additive").and_then(Value::as_bool) {
                assert_eq!(layer["additive"].as_bool(), Some(additive));
            }
        }

        if let (Some(x), Some(y)) = (
            checkpoint.get("x").and_then(Value::as_i64),
            checkpoint.get("y").and_then(Value::as_i64),
        ) {
            assert_eq!(rendered["gridX"].as_i64(), Some(x));
            assert_eq!(rendered["gridY"].as_i64(), Some(y));
        }
        let layer_z = |suffix: &str| {
            layers
                .iter()
                .find(|layer| {
                    layer["key"]
                        .as_str()
                        .is_some_and(|key| key.ends_with(suffix))
                })
                .and_then(|layer| layer["z"].as_f64())
        };
        if object_id == "1001" {
            assert!(layer_z(":weapon-primary") < layer_z(":body"));
            assert!(layer_z(":body") < layer_z(":hair"));
        } else if object_id == "1000" {
            assert!(layer_z(":body") < layer_z(":hair"));
            assert!(layer_z(":hair") < layer_z(":weapon-primary"));
        } else if object_id == "2005" && expected_layers.len() == 2 {
            assert!(layer_z(":body") < layer_z(":scarecrow-die-effect"));
        }
    }

    #[test]
    fn vis01_bichon_actor_transcript_drives_packets_clocks_layers_and_real_front_occlusion() {
        let fixture: Value = serde_json::from_str(include_str!(
            "../tests/fixtures/vis01-bichon-actors-v1.json"
        ))
        .expect("VIS-01 fixture JSON");
        assert_eq!(fixture["schemaVersion"], json!(1));
        assert_eq!(
            fixture["source"]["crystalRevision"],
            json!("484983404e3d6afa584e93801f8006ae3429bea9")
        );
        let fixture_text = serde_json::to_string(&fixture).expect("fixture serializes");
        assert!(
            !fixture_text.contains("_nativeAnimation"),
            "the fixture must contain server/Gateway output, never client-derived animation fields"
        );

        let frame_paths = checkpoint_frame_paths(&fixture);
        let frame_path_refs = frame_paths.iter().map(String::as_str).collect::<Vec<_>>();
        let manifest = crate::atlas::routing_atlas_manifest_fixture(&frame_path_refs);
        let mut adapter = NativeGameplayAdapter::default();
        let mut payload = fixture["worldSnapshot"].clone();
        adapter.observe_world_snapshot(&payload);
        let mut presentation = NativeEntityPresentation::default();
        let mut checked_real_occlusion = false;

        for step in fixture["timeline"].as_array().expect("VIS-01 timeline") {
            let at_ms = step["atMs"].as_u64().expect("timeline atMs");
            let event_applied = if let Some(event) = step.get("event") {
                let packet = event["packet"].as_str().expect("packet name").to_owned();
                let packet_event = PacketEvent::Other {
                    packet,
                    payload: event["payload"].clone(),
                };
                assert!(adapter.observe_packet(&packet_event));
                adapter.apply_authoritative_overlay(&mut payload);
                true
            } else {
                false
            };

            if let Some(expected) = step.get("damageCheckpoint") {
                let snapshot = adapter.snapshot(&payload);
                let damage = snapshot.damage_events.last().expect("damage event");
                assert_eq!(damage.sequence, expected["sequence"].as_u64().unwrap());
                assert_eq!(
                    u64::from(damage.object_id),
                    expected["objectId"].as_u64().unwrap()
                );
                assert_eq!(
                    i64::from(damage.damage),
                    expected["damage"].as_i64().unwrap()
                );
                assert_eq!(
                    i64::from(damage.damage_type),
                    expected["damageType"].as_i64().unwrap()
                );
            }

            let Some(checkpoint) = step.get("checkpoint") else {
                continue;
            };
            if event_applied {
                presentation.replace_payload(payload.clone());
                presentation.sync_pending_payload_with(at_ms, vis01_catalog);
            }
            let state = presentation
                .render_state_if_changed_with(at_ms, true, |payload, poses, effect_visible| {
                    crate::atlas::build_entity_render_state_with_manifest_for_test(
                        payload,
                        poses,
                        effect_visible,
                        &manifest,
                    )
                })
                .expect("VIS-01 checkpoint must produce a render-state change");
            assert_vis01_checkpoint(&presentation, &payload, &state, checkpoint);

            if !checked_real_occlusion && checkpoint["objectId"] == json!(2010) {
                let compressed =
                    include_bytes!("../../../web/lib/generated/crystal-map-pack/0.map.gz");
                let mut decoder = flate2::read::GzDecoder::new(&compressed[..]);
                let mut bytes = Vec::new();
                decoder
                    .read_to_end(&mut bytes)
                    .expect("decode real 0.map.gz");
                let map = crate::map_parser::parse_type100_map(&bytes).expect("parse real 0.map");
                let front = crate::map_parser::resolve_map_tile_draws(&map)
                    .into_iter()
                    .find(|draw| {
                        draw.x
                            == fixture["source"]["frontOcclusionCell"]["x"]
                                .as_i64()
                                .unwrap() as i32
                            && draw.y
                                == fixture["source"]["frontOcclusionCell"]["y"]
                                    .as_i64()
                                    .unwrap() as i32
                            && draw.layer == crate::map_parser::TileLayer::Front
                    })
                    .expect("fixture coordinate is an actual 0.map front cell");
                let front_z = crate::atlas::map_tile_draw_z_for_test(front.x, front.y, front.z);
                let body_z = state["entities"]
                    .as_array()
                    .into_iter()
                    .flatten()
                    .find(|entity| entity["objectId"] == json!("2010"))
                    .and_then(|entity| entity["layers"].as_array())
                    .into_iter()
                    .flatten()
                    .find(|layer| layer["key"] == json!("2010:body"))
                    .and_then(|layer| layer["z"].as_f64())
                    .expect("CannibalPlant body z") as f32;
                assert!(
                    front_z > body_z,
                    "real front cell must occlude same-cell body"
                );
                checked_real_occlusion = true;
            }
        }

        assert!(checked_real_occlusion);
    }

    #[test]
    fn vis01_bichon_actor_transcript_routes_through_candidate_manifests_and_map_state() {
        let fixture: Value = serde_json::from_str(include_str!(
            "../tests/fixtures/vis01-bichon-actors-v1.json"
        ))
        .expect("VIS-01 fixture JSON");
        crate::assets::require_asset_root().expect("complete Candidate asset root");
        assert!(
            crate::atlas::validate_starter_entity_atlas_pages_for_test(),
            "every Candidate entity-atlas page must exist, decode, and match manifest dimensions/hash"
        );
        let frame_set_path = crate::assets::asset_path("original-ui/frame-sets.generated.json")
            .expect("Candidate frame-set path");
        let frame_sets: Value = serde_json::from_str(
            &std::fs::read_to_string(frame_set_path).expect("read Candidate frame-set catalog"),
        )
        .expect("parse Candidate frame-set catalog");
        assert_eq!(
            frame_sets["sourceContentHash"], fixture["source"]["frameSetSourceContentHash"],
            "fixture clocks must be locked to the packaged generated frame-set source hash"
        );

        let mut adapter = NativeGameplayAdapter::default();
        let mut payload = fixture["worldSnapshot"].clone();
        adapter.observe_world_snapshot(&payload);
        let mut presentation = NativeEntityPresentation::default();
        let mut cannibal_body_bounds = None;

        for step in fixture["timeline"].as_array().expect("VIS-01 timeline") {
            let at_ms = step["atMs"].as_u64().expect("timeline atMs");
            let event_applied = if let Some(event) = step.get("event") {
                let packet = event["packet"].as_str().expect("packet name").to_owned();
                assert!(adapter.observe_packet(&PacketEvent::Other {
                    packet,
                    payload: event["payload"].clone(),
                }));
                adapter.apply_authoritative_overlay(&mut payload);
                true
            } else {
                false
            };

            let Some(checkpoint) = step.get("checkpoint") else {
                continue;
            };
            if event_applied {
                presentation.replace_payload(payload.clone());
                presentation.sync_pending_payload(at_ms, at_ms);
            }
            let state = presentation
                .render_state_if_changed(at_ms, true)
                .expect("Candidate manifest checkpoint must produce render state");
            assert_vis01_checkpoint(&presentation, &payload, &state, checkpoint);

            if cannibal_body_bounds.is_none()
                && checkpoint["objectId"] == json!(2010)
                && checkpoint["visible"] == json!(true)
            {
                let body = state["entities"]
                    .as_array()
                    .into_iter()
                    .flatten()
                    .find(|entity| entity["objectId"] == json!("2010"))
                    .and_then(|entity| entity["layers"].as_array())
                    .into_iter()
                    .flatten()
                    .find(|layer| layer["key"] == json!("2010:body"))
                    .expect("Candidate CannibalPlant body layer");
                cannibal_body_bounds = Some((
                    body["left"].as_f64().expect("body left"),
                    body["top"].as_f64().expect("body top"),
                    body["width"].as_f64().expect("body width"),
                    body["height"].as_f64().expect("body height"),
                ));
            }
        }

        let compressed = include_bytes!("../../../web/lib/generated/crystal-map-pack/0.map.gz");
        let mut decoder = flate2::read::GzDecoder::new(&compressed[..]);
        let mut bytes = Vec::new();
        decoder
            .read_to_end(&mut bytes)
            .expect("decode real 0.map.gz");
        let map = crate::map_parser::parse_type100_map(&bytes).expect("parse real 0.map");
        let front_draw = crate::map_parser::resolve_map_tile_draws(&map)
            .into_iter()
            .find(|draw| {
                draw.x
                    == fixture["source"]["frontOcclusionCell"]["x"]
                        .as_i64()
                        .unwrap() as i32
                    && draw.y
                        == fixture["source"]["frontOcclusionCell"]["y"]
                            .as_i64()
                            .unwrap() as i32
                    && draw.layer == crate::map_parser::TileLayer::Front
            })
            .expect("real front draw");
        let map_state = crate::map_parser::build_map_render_state(
            &map,
            crate::map_parser::MapViewport::from_gateway_payload(&fixture["worldSnapshot"]),
        )
        .expect("Candidate map render state");
        let key = format!(
            "front:{}:{}",
            fixture["source"]["frontOcclusionCell"]["x"]
                .as_i64()
                .expect("front x"),
            fixture["source"]["frontOcclusionCell"]["y"]
                .as_i64()
                .expect("front y")
        );
        let atlas_tile = map_state["tiles"]
            .as_array()
            .into_iter()
            .flatten()
            .find(|tile| tile["key"].as_str() == Some(key.as_str()));
        let standalone_tile = map_state["standaloneTiles"]
            .as_array()
            .into_iter()
            .flatten()
            .find(|tile| {
                tile["key"].as_str().is_some_and(|tile_key| {
                    tile_key
                        == format!(
                            "standalone:{}:{}:{}:{}",
                            if front_draw.additive {
                                "additive"
                            } else {
                                "normal"
                            },
                            front_draw.x,
                            front_draw.y,
                            crate::map_parser::atlas_rect_key(
                                &front_draw.library,
                                front_draw.frame_index,
                            )
                        )
                })
            });
        let front = atlas_tile
            .or(standalone_tile)
            .expect("real front cell must survive production map binding");
        if atlas_tile.is_some() {
            let atlas_key = front["atlasKey"].as_str().expect("front atlas key");
            let rect_key = front["rectKey"].as_str().expect("front rect key");
            let atlas = map_state["atlases"]
                .as_array()
                .into_iter()
                .flatten()
                .find(|atlas| atlas["key"].as_str() == Some(atlas_key))
                .expect("front atlas page retained");
            assert!(atlas["rects"]
                .as_array()
                .into_iter()
                .flatten()
                .any(|rect| rect["key"].as_str() == Some(rect_key)));
        } else {
            let image_url = front["imageUrl"].as_str().expect("front standalone image");
            assert!(crate::assets::asset_path(image_url).is_some_and(|path| path.is_file()));
        }

        let front_bounds = (
            front["left"].as_f64().expect("front left"),
            front["top"].as_f64().expect("front top"),
            front["width"].as_f64().expect("front width"),
            front["height"].as_f64().expect("front height"),
        );
        let body_bounds = cannibal_body_bounds.expect("CannibalPlant body geometry");
        assert!(
            front_bounds.0 < body_bounds.0 + body_bounds.2
                && front_bounds.0 + front_bounds.2 > body_bounds.0
                && front_bounds.1 < body_bounds.1 + body_bounds.3
                && front_bounds.1 + front_bounds.3 > body_bounds.1,
            "real front tile and actor body geometry must overlap"
        );
    }
}
