$ErrorActionPreference='Stop'
$taskSource=[IO.Path]::GetFullPath('C:/mir2-build/p1-native-20261007')
$taskDestination=[IO.Path]::GetFullPath('C:/mir2-build/p1-native-escape-20261010-target')
$taskEvidence='C:/mir2-build/p1-client-escape-20261010-evidence'
if($taskDestination -ne [IO.Path]::GetFullPath('C:/mir2-build/p1-native-escape-20261010-target')){throw 'Unexpected target'}
if(Test-Path -LiteralPath $taskDestination){throw 'Owned target must be fresh'}
if(-not(Test-Path -LiteralPath "$taskSource/debug/.fingerprint")){throw 'Missing cache source'}
$taskExcluded=@('incremental')
foreach($taskPart in @('debug/.fingerprint','debug/build')){
 $taskExcluded+=@(Get-ChildItem -LiteralPath "$taskSource/$taskPart" -Directory | Where-Object {$_.Name -like 'mir2*'} | ForEach-Object {$_.FullName})
}
$taskArgs=@($taskSource,$taskDestination,'/E','/COPY:DAT','/DCOPY:T','/R:0','/W:0','/NFL','/NDL','/NJH','/NJS','/NP','/XF','*mir2*','.cargo-lock','/XD')+$taskExcluded
$taskStart=[DateTime]::UtcNow
& robocopy @taskArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/registry-cache-copy-01.log" -Encoding utf8
$taskExit=$LASTEXITCODE
if($taskExit -ge 8){throw "Cache copy failed, robocopy status $taskExit"}
$taskUnexpected=@(Get-ChildItem -LiteralPath $taskDestination -Recurse -File | Where-Object {$_.Name -like '*mir2*'})
$taskUnexpectedDirs=@(Get-ChildItem -LiteralPath "$taskDestination/debug/.fingerprint" -Directory | Where-Object {$_.Name -like 'mir2*'})
if($taskUnexpected.Count -or $taskUnexpectedDirs.Count){throw 'Workspace products unexpectedly present in copied cache'}
[ordered]@{utcStarted=$taskStart.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');
 source=$taskSource;destination=$taskDestination;command=@('robocopy')+$taskArgs;
 robocopyExitCode=$taskExit;copiedWorkspaceProducts=0;hardlinks=false;
 qualification='Copied registry artifacts are only a cache; all Mir2 source crates must rebuild in the owned target.'} |
 ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$taskEvidence/registry-cache-copy-01.json" -Encoding utf8
Write-Output 'Owned target seeded without Mir2 products or incremental state.'
