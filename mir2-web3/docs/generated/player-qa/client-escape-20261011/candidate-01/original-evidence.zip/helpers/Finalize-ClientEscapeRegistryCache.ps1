$ErrorActionPreference='Stop'
$taskSource='C:/mir2-build/p1-native-20261007'
$taskTarget='C:/mir2-build/p1-native-escape-20261010-target'
$taskEvidence='C:/mir2-build/p1-client-escape-20261010-evidence'
if(-not(Test-Path -LiteralPath "$taskTarget/debug/.fingerprint")){throw 'Copy target missing'}
$taskFiles=@(Get-ChildItem -LiteralPath $taskTarget -Recurse -File)
$taskUnexpected=@($taskFiles | Where-Object {$_.Name -like '*mir2*'})
$taskUnexpectedDirs=@(Get-ChildItem -LiteralPath "$taskTarget/debug/.fingerprint" -Directory | Where-Object {$_.Name -like 'mir2*'})
if($taskUnexpected.Count -or $taskUnexpectedDirs.Count){throw 'Workspace products found'}
if(Test-Path -LiteralPath "$taskTarget/debug/incremental"){throw 'Incremental source state found'}
[ordered]@{
 utc=[DateTime]::UtcNow.ToString('o');source=$taskSource;target=$taskTarget;
 cacheCopyRepeated=$false;files=$taskFiles.Count;workspaceProducts=0;hardlinks=$false;
 originalFailure='Copy completed and absence checks passed; recording then failed because bare false was parsed as a PowerShell command. Exact robocopy return is unavailable and is not reconstructed.';
 recovery='Read-only validation of existing target, no recopy or shared-target edits.';
 qualification='Registry cache only; all Mir2 source crates must rebuild in owned target.'
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath "$taskEvidence/registry-cache-finalized-01.json" -Encoding utf8
Write-Output "Validated $($taskFiles.Count) copied registry-cache files; no Mir2 or incremental products."
