from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re

out=Path('C:/mir2-build/p1-client-escape-20261010-evidence')
stem='check-02-owned-target-focused-escape'
assert not (out/(stem+'-after.json')).exists() and not (out/(stem+'-result.json')).exists()
data=(out/(stem+'.log')).read_bytes();raw=data.decode('utf-8-sig')
assert 'running 11 tests' in raw and 'test result:' not in raw
passed=re.findall(r'^test (.+) \.\.\. ok$',raw,re.MULTILINE)
record={'utc':datetime.now(timezone.utc).isoformat(),'run':stem,'complete':False,
        'exitCode':None,'finalAfterHashReceiptAbsent':True,'finalResultAbsent':True,
        'partialPassedTestNames':passed,'partialCount':len(passed),
        'observedSystemBootUtc':'2026-10-10T16:53:05Z',
        'priorObservedTestProcessId':277668,'priorObservedWorkingSetBytes':43030851584,
        'causeOfSystemRebootProven':False,'runIsQualified':False,
        'logSha256':hashlib.sha256(data).hexdigest(),'logBytes':len(data),
        'diagnosis':'New test initialized this actor AnimationWorld at zero; the real sender later supplied Unix milliseconds, causing large idle-frame replay. Normal production packet/render/sender paths consistently use Unix.',
        'originalSharedCacheCompilerFailureRetained':True,
        'copyReceiptFailure':'The registry-cache copy completed; final record then failed on a bare PowerShell false token. Copy was not repeated; separate read-only validation retained.'}
with (out/'INTERRUPTED-FOCUSED-RUN-02.json').open('x',encoding='utf-8') as file:json.dump(record,file,indent=2)
print(json.dumps({'complete':False,'partialCount':len(passed),'runIsQualified':False,'originalLogRetained':True}))
