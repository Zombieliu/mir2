from pathlib import Path
from datetime import datetime, timezone
import argparse, ctypes, json, subprocess, sys, time
from ctypes import wintypes as w

parser=argparse.ArgumentParser()
parser.add_argument('--stem',required=True)
parser.add_argument('--filters',nargs='+',required=True)
parser.add_argument('--test-timeout',type=int,default=60)
args=parser.parse_args()
out=Path('C:/mir2-build/p1-client-escape-20261010-evidence')
for suffix in ['-supervisor.json','-supervisor.stdout.log','-supervisor.stderr.log']:
    assert not (out/(args.stem+suffix)).exists()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
psapi=ctypes.WinDLL('psapi',use_last_error=True)
class Entry(ctypes.Structure):
    _fields_=[('size',w.DWORD),('usage',w.DWORD),('pid',w.DWORD),('heap',ctypes.c_size_t),
              ('module',w.DWORD),('threads',w.DWORD),('parent',w.DWORD),('priority',w.LONG),
              ('flags',w.DWORD),('exe',w.WCHAR*260)]
class Memory(ctypes.Structure):
    _fields_=[('cb',w.DWORD),('faults',w.DWORD),('peakWorkingSet',ctypes.c_size_t),
              ('workingSet',ctypes.c_size_t),('peakPagedPool',ctypes.c_size_t),
              ('pagedPool',ctypes.c_size_t),('peakNonpagedPool',ctypes.c_size_t),
              ('nonpagedPool',ctypes.c_size_t),('pagefile',ctypes.c_size_t),
              ('peakPagefile',ctypes.c_size_t),('private',ctypes.c_size_t)]
kernel.CreateToolhelp32Snapshot.argtypes=[w.DWORD,w.DWORD];kernel.CreateToolhelp32Snapshot.restype=w.HANDLE
kernel.Process32FirstW.argtypes=[w.HANDLE,ctypes.POINTER(Entry)];kernel.Process32FirstW.restype=w.BOOL
kernel.Process32NextW.argtypes=[w.HANDLE,ctypes.POINTER(Entry)];kernel.Process32NextW.restype=w.BOOL
kernel.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];kernel.OpenProcess.restype=w.HANDLE
kernel.CloseHandle.argtypes=[w.HANDLE];kernel.CloseHandle.restype=w.BOOL
kernel.TerminateProcess.argtypes=[w.HANDLE,w.UINT];kernel.TerminateProcess.restype=w.BOOL
psapi.GetProcessMemoryInfo.argtypes=[w.HANDLE,ctypes.POINTER(Memory),w.DWORD];psapi.GetProcessMemoryInfo.restype=w.BOOL
def descendants(root):
    handle=kernel.CreateToolhelp32Snapshot(2,0)
    if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
    entries=[];entry=Entry();entry.size=ctypes.sizeof(entry)
    try:
        valid=kernel.Process32FirstW(handle,ctypes.byref(entry))
        while valid:
            entries.append((entry.pid,entry.parent,entry.exe));valid=kernel.Process32NextW(handle,ctypes.byref(entry))
    finally:kernel.CloseHandle(handle)
    owned={root}
    while True:
        added={pid for pid,parent,_ in entries if parent in owned}
        if added<=owned:break
        owned|=added
    return [(pid,name) for pid,_,name in entries if pid in owned]
def memory(pid):
    handle=kernel.OpenProcess(0x410,False,pid)
    if not handle:return None
    try:
        result=Memory();result.cb=ctypes.sizeof(result)
        if not psapi.GetProcessMemoryInfo(handle,ctypes.byref(result),result.cb):return None
        return int(result.private),int(result.workingSet)
    finally:kernel.CloseHandle(handle)
def terminate_owned(pid,root):
    assert pid in {item[0] for item in descendants(root)},'Never stop an unrelated process'
    handle=kernel.OpenProcess(1,False,pid)
    if not handle:raise ctypes.WinError(ctypes.get_last_error())
    try:assert kernel.TerminateProcess(handle,3),'Could not stop the owned test'
    finally:kernel.CloseHandle(handle)
quoted=','.join("'"+value.replace("'","''")+"'" for value in args.filters)
script=f"& 'E:/mir2-player-journey/tmp/Run-ClientEscapeQualification.ps1' -LogStem '{args.stem}' -Filters @({quoted})"
started=datetime.now(timezone.utc).isoformat();clock=time.monotonic()
observed={};peak=0;failure=None
with (out/(args.stem+'-supervisor.stdout.log')).open('xb') as stdout, (out/(args.stem+'-supervisor.stderr.log')).open('xb') as stderr:
    process=subprocess.Popen(['pwsh','-NoProfile','-Command',script],stdout=stdout,stderr=stderr)
    while process.poll() is None:
        for pid,name in descendants(process.pid):
            if not name.lower().startswith('mir2_platform_windows-'):continue
            info=memory(pid)
            observed.setdefault(pid,{'name':name,'startedMonotonic':time.monotonic(),'peakPrivateBytes':0,'peakWorkingSetBytes':0})
            if info:
                observed[pid]['peakPrivateBytes']=max(observed[pid]['peakPrivateBytes'],info[0])
                observed[pid]['peakWorkingSetBytes']=max(observed[pid]['peakWorkingSetBytes'],info[1]);peak=max(peak,info[0])
            if (info and info[0]>2*1024**3) or time.monotonic()-observed[pid]['startedMonotonic']>args.test_timeout:
                failure={'pid':pid,'reason':'test memory or time bound exceeded','privateBytes':info[0] if info else None}
                terminate_owned(pid,process.pid)
        if time.monotonic()-clock>1500:
            failure={'pid':process.pid,'reason':'compile/wrapper total bound exceeded'}
            for pid,_ in reversed(descendants(process.pid)):
                if pid!=process.pid:terminate_owned(pid,process.pid)
            process.terminate()
        time.sleep(.25)
    exit_code=process.wait()
record={'utcStarted':started,'utcFinished':datetime.now(timezone.utc).isoformat(),
        'wrapperExitCode':exit_code,'rootOwnedProcessId':process.pid,'observedOwnedTestProcesses':observed,
        'peakTestPrivateBytes':peak,'testMemoryBoundBytes':2*1024**3,'testTimeBoundSeconds':args.test_timeout,
        'boundFailure':failure,'unrelatedProcessesStopped':False,'thisIsComponentVerification':True,
        'nativeHumanAcceptance':False}
with (out/(args.stem+'-supervisor.json')).open('x',encoding='utf-8') as file:json.dump(record,file,indent=2)
print(json.dumps(record),flush=True)
sys.stdout.buffer.write((out/(args.stem+'-supervisor.stdout.log')).read_bytes()[-5000:])
sys.stdout.flush()
sys.exit(exit_code or (1 if failure else 0))
