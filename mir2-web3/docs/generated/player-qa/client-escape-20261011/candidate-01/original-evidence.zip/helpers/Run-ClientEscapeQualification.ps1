param([Parameter(Mandatory=$true)][string]$LogStem,[Parameter(Mandatory=$true)][string[]]$Filters)
$ErrorActionPreference='Stop'
$taskProject='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p1-client-escape-20261010-evidence'
$taskTarget='C:/mir2-build/p1-native-escape-20261010-target'
$taskDrive=[IO.DriveInfo]::new([IO.Path]::GetPathRoot($taskTarget))
if($taskDrive.AvailableFreeSpace -lt 50GB){throw 'Insufficient existing build-volume reserve'}
$env:CARGO_TARGET_DIR=$taskTarget
Set-Location -LiteralPath $taskProject
foreach($taskSuffix in @('.log','-before.json','-after.json','-result.json')){
 if(Test-Path -LiteralPath "$taskEvidence/$LogStem$taskSuffix"){throw 'Original evidence already exists'}
}
$taskPaths=@('apps/game-client/platform-windows/Cargo.toml','apps/game-client/platform-windows/Cargo.lock',
 'apps/game-client/platform-windows/src/main.rs','apps/game-client/platform-windows/src/input.rs',
 'apps/game-client/platform-windows/src/entity_presentation.rs','apps/game-client/platform-windows/src/gateway.rs',
 'apps/game-client/platform-windows/src/gameplay_bridge.rs',
 'apps/game-client/platform-windows/src/gateway_target_lifecycle_network_tests.rs',
 'apps/game-client/runtime/Cargo.toml','apps/game-client/runtime/src/lib.rs',
 'apps/game-client/client-bevy/Cargo.toml','apps/game-client/client-bevy/src/lib.rs',
 'packages/protocol/Cargo.toml','packages/protocol/src/types.rs','packages/game-data/Cargo.toml')
$taskArgs=@('+1.95.0','test','--locked','--offline','--jobs','2','--config',
 'profile.test.package.mir2-platform-windows.debug="line-tables-only"','--config',
 'profile.test.package.mir2-platform-windows.codegen-units=218',
 '--manifest-path','apps/game-client/platform-windows/Cargo.toml','--bin','mir2-platform-windows','--','--test-threads=1','--nocapture')+$Filters
function Write-TaskSourceHashes([string]$phase){
 $taskHashes=@($taskPaths | ForEach-Object {Get-FileHash -LiteralPath $_ -Algorithm SHA256} | Select-Object Path,Hash)
 [ordered]@{utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=@('cargo')+$taskArgs;
 root=$taskProject;scope="$($taskPaths.Count) selected paths, not whole-workspace input closure";
 source=$taskHashes} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding utf8
}
Write-TaskSourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& cargo @taskArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding utf8
$taskExit=$LASTEXITCODE
Write-TaskSourceHashes 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');
 exitCode=$taskExit;log="$taskEvidence/$LogStem.log";freeBytesAfter=$taskDrive.AvailableFreeSpace} |
 ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding utf8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 40
exit $taskExit
