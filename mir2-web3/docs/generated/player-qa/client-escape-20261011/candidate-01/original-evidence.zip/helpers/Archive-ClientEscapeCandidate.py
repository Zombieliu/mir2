from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, zipfile

repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
out=Path('C:/mir2-build/p1-client-escape-20261010-evidence')
parent='1e343def08670e0e3fecee7e00088ff23c5c5153'
sha=lambda data:hashlib.sha256(data).hexdigest()
canon=lambda data:data.replace(b'\r\n',b'\n')
git=['git','-c','gc.auto=0','-c','maintenance.auto=false','-c','safe.directory='+repo.as_posix(),'-C',str(repo)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip()==parent
paths=['mir2-web3/apps/game-client/platform-windows/src/input.rs','mir2-web3/apps/game-client/platform-windows/src/entity_presentation.rs']
source={name:sha((repo/name).read_bytes()) for name in paths}
worker_input=canon((out/'worker-original-input.rs').read_bytes())
current_input=canon((repo/paths[0]).read_bytes())
marker=b'#[cfg(test)]\nmod tests {'
assert worker_input.count(marker)==current_input.count(marker)==1
assert worker_input.split(marker)[0]==current_input.split(marker)[0],'Fixture repair cannot change product code'
assert sha((out/'worker-original-entity_presentation.rs').read_bytes())==source[paths[1]]
checks=[];passed=set();ignored=[]
for stem in ['check-03-absolute-fixture-focused-escape','check-04-adjacent-native-input-presentation-sender','check-05-native-stage-gate-all-tests']:
    result=json.loads((out/(stem+'-result.json')).read_text(encoding='utf-8-sig'))
    before=json.loads((out/(stem+'-before.json')).read_text(encoding='utf-8-sig'))
    after=json.loads((out/(stem+'-after.json')).read_text(encoding='utf-8-sig'))
    supervisor=json.loads((out/(stem+'-supervisor.json')).read_bytes())
    assert result['exitCode']==supervisor['wrapperExitCode']==0 and supervisor['boundFailure'] is None
    assert before['source']==after['source'] and before['command']==after['command']
    for name,digest in source.items():
        absolute=str((repo/name).resolve()).casefold()
        assert next(row['Hash'].casefold() for row in before['source'] if row['Path'].casefold()==absolute)==digest
    raw=(out/(stem+'.log')).read_text(encoding='utf-8-sig')
    names=[match.group(1) for line in raw.splitlines() if (match:=re.fullmatch(r'test (.+) \.\.\. ok',line))]
    summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',raw)
    assert len(summaries)==1 and len(names)==int(summaries[0][0]) and summaries[0][1]=='0'
    passed.update(names)
    if stem=='check-05-native-stage-gate-all-tests':
        ignored=[line.removeprefix('test ') for line in raw.splitlines() if ' ... ignored,' in line]
        assert len(names)==911 and len(ignored)==int(summaries[0][2])==7
    checks.append({'stem':stem,'command':before['command'],'passed':len(names),'ignored':int(summaries[0][2]),
                   'testNames':names,'beforeAfterSelectedHashesEqual':True,
                   'peakTestPrivateBytes':supervisor['peakTestPrivateBytes'],
                   'utcStarted':result['utcStarted'],'utcFinished':result['utcFinished']})
assert len(passed)==911
assert json.loads((out/'INTERRUPTED-FOCUSED-RUN-02.json').read_bytes())['complete'] is False
assert json.loads((out/'check-01-client-escape-focused-result.json').read_text(encoding='utf-8-sig'))['exitCode']!=0
folder=repo/'mir2-web3/docs/generated/player-qa/client-escape-20261011/candidate-01'
folder.mkdir(parents=True,exist_ok=False)
entries=[]
with zipfile.ZipFile(folder/'original-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in sorted(p for p in out.rglob('*') if p.is_file()):
        data=path.read_bytes();name=path.relative_to(out).as_posix()
        assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{40,}|ghp_[A-Za-z0-9]{30,}',data)
        archive.writestr(name,data);entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
    for name in ['Run-ClientEscapeQualification.ps1','Run-ClientEscapeBounded.py',
                 'Copy-ClientEscapeRegistryCache.ps1','Finalize-ClientEscapeRegistryCache.ps1',
                 'Record-ClientEscapeInterruptedRun.py','Archive-ClientEscapeCandidate.py']:
        data=(Path(__file__).parent/name).read_bytes();archive.writestr('helpers/'+name,data)
        entries.append({'path':'helpers/'+name,'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(folder/'original-evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.infolist())==len(entries)
    for row in entries:assert sha(archive.read(row['path']))==row['sha256']
data=(folder/'original-evidence.zip').read_bytes();assert len(data)<=3*1024*1024
proof={'utc':datetime.now(timezone.utc).isoformat(),'parent':parent,'sourceSha256':source,
       'passedNativeComponentTestsDistinct':len(passed),'newTests':11,'checks':checks,'ignoredNativeOrExternalChecks':ignored,
       'finalComponentStageGatePasses':True,'fixtureRepairChangesProductCode':False,
       'senderSuccessVerifiesActualMotionWindow':True,'originalIgnoredChecksNotClaimedPassed':True,
       'originalForeignCacheCompilationFailureRetained':True,'originalUnfinishedLargeClockReplayRetained':True,
       'originalPreparationAndMetadataFailuresRetained':True,'fullPacketBeforeAckLifecycleClosed':False,
       'ownWindowsReleaseQualified':False,'newSourcePushed':False,'newClientPublished':False,
       'nativeHumanAcceptance':False,'fullP1P7Claimed':False,
       'archive':{'bytes':len(data),'sha256':sha(data),'entries':len(entries)},'entries':entries}
with (folder/'EVIDENCE.json').open('x',encoding='utf-8') as file:json.dump(proof,file,indent=2);file.write('\n')
print(json.dumps({key:proof[key] for key in ['parent','passedNativeComponentTestsDistinct','newTests','archive','finalComponentStageGatePasses']}))
