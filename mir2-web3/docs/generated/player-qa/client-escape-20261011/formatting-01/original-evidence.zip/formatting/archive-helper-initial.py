from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,zipfile
repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
ev=Path('C:/mir2-build/p1-client-escape-20261010-evidence')
out=repo/'mir2-web3/docs/generated/player-qa/client-escape-20261011/formatting-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
base='f2082841d4e79b29ffc6933ace349b572d1b3c21'
head=subprocess.check_output(['git','-c','safe.directory='+repo.as_posix(),'-C',str(repo),'rev-parse','HEAD']).decode().strip()
assert head==base and not out.exists()
candidate=json.loads((repo/'mir2-web3/docs/generated/player-qa/client-escape-20261011/candidate-01/EVIDENCE.json').read_bytes())
formatting=json.loads((ev/'formatting-01/FORMATTING-ONLY.json').read_bytes())
assert formatting['parent']==base and formatting['before']==candidate['sourceSha256']
assert formatting['fullNativeFormattingCheck']['exitCode']==0 and all(r['exitCode']==0 for r in formatting['commands'])
for name,digest in formatting['after'].items():assert sha((repo/name).read_bytes())==digest
stem='check-08-formatted-native-stage-gate'
before=json.loads((ev/(stem+'-before.json')).read_bytes());after=json.loads((ev/(stem+'-after.json')).read_bytes())
assert before['source']==after['source']
result=json.loads((ev/(stem+'-result.json')).read_bytes());supervisor=json.loads((ev/(stem+'-supervisor.json')).read_bytes())
assert result['exitCode']==supervisor['wrapperExitCode']==0 and supervisor['boundFailure'] is None
log=(ev/(stem+'.log')).read_text(encoding='utf-8-sig')
assert re.search(r'test result: ok\. 911 passed; 0 failed; 7 ignored; 0 measured; 0 filtered out;',log)
names=sorted(re.findall(r'^test ([^\r\n]+?) \.\.\. ok\s*$',log,re.M))
expected=next(c['testNames'] for c in candidate['checks'] if c['stem']=='check-05-native-component-stage-gate')
assert len(names)==len(set(names))==911 and names==expected
ignored=sorted(re.findall(r'^test ([^\r\n]+?) \.\.\. ignored[^\r\n]*',log,re.M))
assert len(ignored)==7
files={}
for p in (ev/'formatting-01').iterdir():
    assert p.is_file();files['formatting/'+p.name]=p.read_bytes()
for pattern in ['check-06-committed-rustfmt.*','check-07-formatted-native-stage-gate*',stem+'*']:
    for p in ev.glob(pattern):
        assert p.is_file();files['checks/'+p.name]=p.read_bytes()
assert 'checks/check-07-formatted-native-stage-gate-supervisor.stderr.log' in files
out.mkdir(parents=True)
archive=out/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,data in sorted(files.items()):z.writestr(path,data)
proof={'utc':datetime.now(timezone.utc).isoformat(),'parent':base,'sourceSha256':formatting['after'],
 'beforeSourceSha256':formatting['before'],'onlyStandardRustfmtApplied':True,
 'fullNativeFormattingCheckPassed':True,'formattedNativeStageGatePassed':True,
 'nativeComponentTestsDistinct':911,'sameExactTestNamesAsPriorStageGate':True,'ignoredOriginalChecks':ignored,
 'selectedBeforeAfterSourceHashesEqual':True,'testCommand':before['command'],
 'peakTestPrivateBytes':supervisor['peakTestPrivateBytes'],'testProcessesStopped':False,
 'firstFormattingGateFailureRetained':True,'emptyFilterInvocationFailureRetained':True,
 'noReexecutionOfAnActualFailedTest':True,'newPackagePublished':False,'nativeHumanAcceptance':False,
 'archive':{'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':len(files)},
 'entries':[{'path':path,'bytes':len(data),'sha256':sha(data)} for path,data in sorted(files.items())]}
with (out/'EVIDENCE.json').open('x') as f:json.dump(proof,f,indent=2);f.write('\n')
doc=repo/'mir2-web3/docs/CLASSIC-CLIENT-ESCAPE-ACTION-CLOCK-20261011.md'
with doc.open('a',encoding='utf-8') as f:f.write('''

## Release formatting preparation, 2026-10-11

The original behavior Candidate is committed and pushed as
`f2082841d4e79b29ffc6933ace349b572d1b3c21`. Its raw evidence above remains
immutable. The subsequent full native `cargo +1.95.0 fmt -- --check` failed
only `input.rs` and `entity_presentation.rs`; standard Rustfmt 1.95, edition2021,
with `skip_children=true` formatted exactly those two owned files. The full
native formatting check now passes. No separate implementation, permission,
clock, assertion or failure-policy change was made in this formatting round.

The first stage-gate wrapper invocation rejected an empty mandatory filter
before launching Cargo; its original stderr/supervisor receipt remains. The
correct all-module `::` filter then ran all918 native component cases, with
the same exact911 passing names,0failed and the same7 original ignored cases.
Peak observed private memory was240,447,488bytes; no process was stopped. This
does not add911 new tests or qualify ignored native/network/human acceptance.

[Formatting source, original gate failure and actual final check](generated/player-qa/client-escape-20261011/formatting-01/EVIDENCE.json)
bind this formatted source separately. A clean attested Windows Release,
qualified package, signed update publication and actual dense-combat/native
acceptance are still required. Server1e own Linux qualification is separate.
''')
print(json.dumps({k:proof[k] for k in ['parent','sourceSha256','nativeComponentTestsDistinct','archive']}))
