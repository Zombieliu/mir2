import ast, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path('E:/mir2-player-journey/tmp')
SOURCE = ROOT/'Download-SourceTerrainLinuxCI.py'
TARGET = ROOT/'Download-SourceTerrainLinuxCIRetry02.py'
OUT = Path('C:/mir2-build/p7-source-map-terrain-20261010-ci/server-ci-01')
original = SOURCE.read_bytes()
changed = original.replace(b"OUT=ROOT/'server-ci-01/artifact-01'", b"OUT=ROOT/'server-ci-01/artifact-02'")
assert changed != original and original.count(b"OUT=ROOT/'server-ci-01/artifact-01'") == 1
functions = lambda data: [ast.dump(node) for node in ast.parse(data).body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
assert functions(changed) == functions(original)
with TARGET.open('xb') as stream:
    stream.write(changed)
partial = OUT/'artifact-01/github-artifact-original.zip'
receipt = {'utcRecorded': datetime.now(timezone.utc).isoformat(),
    'originalFailedInvocation': 'python tmp/Download-SourceTerrainLinuxCI.py',
    'actualError': 'AssertionError: unexpected EOF at line62 after gh artifact ZIP request',
    'originalPartialZip': {'path': str(partial), 'bytes': partial.stat().st_size, 'sha256': hashlib.sha256(partial.read_bytes()).hexdigest()},
    'originalRetained': True, 'retrySeparateFreshDirectory': 'artifact-02',
    'originalVerifierSha256': hashlib.sha256(original).hexdigest(), 'retryVerifierSha256': hashlib.sha256(changed).hexdigest(),
    'onlyChangedAssignment': 'OUT artifact-01 to artifact-02', 'allOriginalValidationFunctionAstsRetained': True,
    'retryExecuted': False}
with (OUT/'ARTIFACT-RETRY02-PREPARED.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt))
