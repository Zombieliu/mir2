"""Derive the unchanged drained operator and owned public harnesses; do not deploy."""
import ast, hashlib, json, subprocess
from pathlib import Path

PRIOR = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-rollout-01')
ROOT = Path('C:/mir2-build/p7-source-map-terrain-20261010-ci')
OUT = ROOT/'server-rollout-01'
CI = ROOT/'server-ci-01/artifact-02'
REVISION = '64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
OLD_CANDIDATE = 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9'
PREVIOUS = 'c70436f34eabb432d769e0082c0afa23303294b0'
def sha(data): return hashlib.sha256(data).hexdigest()
def new(path, data):
    with path.open('xb') as stream: stream.write(data)
def functions(data):
    return {node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(data).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
def replace_exact(body, pairs):
    for left, right in pairs:
        assert body.count(left) >= 1, left
        body = body.replace(left, right)
    return body

proof = json.loads((CI/'CI-VERIFIED.json').read_bytes())
assert proof['revision'] == REVISION and proof['runConclusion'] == 'success'
assert proof['serverSwitched'] is False and proof['publicR2Upload'] is False
before_raw = Path('C:/mir2-build/p7-unavailable-collision-20261010-evidence/public-preflight-read-01.log').read_bytes()
before = json.loads(next(line for line in before_raw.decode().splitlines() if line.startswith('{')))
assert before['ok'] is True and before['test']['revision'] == PREVIOUS and before['remoteZoneConfigured'] is False
assert before['binarySha256'] == '952fe0c77ab9b3b13b9c96dab0b1d5503baa77fc90006e15e009d11d2c85c243'
assert all(before['test']['capacity'][key] == 0 for key in ('currentWsConnections', 'currentActiveSessions', 'currentReconnectLeases', 'currentLoginInFlight', 'currentNewCharacterInFlight', 'currentStartGameInFlight'))
assert before['tcp7200'] == 0 and before['test']['spectator']['activeViewers'] == 0
assert before['files']['/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf']['sha256'] == '0935469c2c7a9ab3421726a0ca2835687f6a8cc8260e6bbbee30a85b544d3c71'
OUT.mkdir(exist_ok=False)
new(OUT/'preflight-read-01.log', before_raw)
old = (PRIOR/'upgrade-npc-buff-gateway-01.py').read_bytes()
assert sha(old) == json.loads((PRIOR/'operator-prepared-01.json').read_bytes())['preparedOperatorSha256']
operator = replace_exact(old.decode(), [(OLD_CANDIDATE, REVISION),
    ('Only the attested purification-to-NPC-buff-fix pair at the established capacity is allowed', 'Only the attested purification-to-source-terrain-fix pair at the established capacity is allowed')]).encode()
old_f, new_f = functions(old), functions(operator)
assert old_f.keys() == new_f.keys()
assert all(old_f[name] == new_f[name] for name in old_f if name != 'validate_request')
assert OLD_CANDIDATE not in operator.decode()
new(OUT/'upgrade-source-terrain-gateway-01.py', operator)
op_proof = {'sourceOperatorSha256': sha(old), 'preparedOperatorSha256': sha(operator), 'candidate': REVISION, 'previous': PREVIOUS,
    'freshBeforeSha256': sha(before_raw), 'functionsIdentical': len(old_f)-1,
    'onlyRequestIdentityChanged': True, 'strictZeroPlayersViewersTcpRetained': True, 'executedOnServer': False}
new(OUT/'operator-prepared-01.json', (json.dumps(op_proof, indent=2)+'\n').encode())

driver_old = (PRIOR/'deploy-npc-buff-gateway-01.py').read_bytes()
driver = replace_exact(driver_old.decode(), [(PRIOR.as_posix(), OUT.as_posix()),
    ('C:/mir2-build/p7-npc-buff-20261010-ci/server-ci-01/artifact-01', CI.as_posix()),
    (OLD_CANDIDATE, REVISION), ('upgrade-npc-buff-gateway-', 'upgrade-source-terrain-gateway-')]).encode()
assert functions(driver_old) == functions(driver)
new(OUT/'deploy-source-terrain-gateway-01.py', driver)
harnesses = []
for folder, script in [('ordinary-public-01', 'public-smoke.mjs'), ('native-resume-public-01', 'native-resume-smoke.mjs')]:
    source = PRIOR/folder
    target = OUT/folder
    old_h = (source/script).read_bytes()
    assert sha(old_h) == json.loads((source/'PREPARATION.json').read_bytes())['preparedHarnessSha256']
    h = replace_exact(old_h.decode(), [("const root='"+source.as_posix()+"';", "const root='"+target.as_posix()+"';"),
        ("const revision='"+OLD_CANDIDATE+"';", "const revision='"+REVISION+"';")]).encode()
    target.mkdir(exist_ok=False)
    new(target/script, h)
    check = subprocess.run(['node', '--check', str(target/script)], capture_output=True, timeout=30)
    assert check.returncode == 0, check.stderr.decode(errors='replace')
    hp = {'schema': 'mir2.source-terrain.postdeploy-harness-derivation.v1', 'sourceHarnessSha256': sha(old_h),
        'preparedHarnessSha256': sha(h), 'candidate': REVISION, 'comparisonAssertionsChanged': False, 'credentialsCopied': False,
        'onlyRootAndRevisionChanged': True, 'executedAgainstServer': False}
    new(target/'PREPARATION.json', (json.dumps(hp, indent=2)+'\n').encode())
    harnesses.append(hp)
receipt = {'candidate': REVISION, 'previous': PREVIOUS, 'qualifiedArtifactReceiptSha256': sha((CI/'CI-VERIFIED.json').read_bytes()),
    'operator': op_proof, 'driverSourceSha256': sha(driver_old), 'driverSha256': sha(driver),
    'driverFunctionsIdentical': len(functions(driver)), 'allOriginalArtifactAndDrainGatesRetained': True,
    'harnesses': harnesses, 'executed': False}
new(OUT/'PREPARATION.json', (json.dumps(receipt, indent=2)+'\n').encode())
print(json.dumps(receipt))
