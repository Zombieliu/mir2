$ErrorActionPreference='Stop'
$taskRoot='C:/Users/Administrator/.codex/worktrees/i9/mir2-player-journey'
$taskEvidence='C:/mir2-build/p7-unavailable-collision-20261010-evidence'
$taskStem='05-original-parent-checkpoint-baseline'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
Set-Location -LiteralPath $taskRoot
$taskHead=& git -c gc.auto=0 -c maintenance.auto=false -c "safe.directory=$taskRoot" rev-parse HEAD
if ($taskHead -ne '9fe7c45ff6a9b198d87322b9ecca4a2abcac6547') {throw 'Not exact parent'}
if (& git -c gc.auto=0 -c maintenance.auto=false -c "safe.directory=$taskRoot" status --porcelain=v1) {throw 'Frozen parent dirty'}
Set-Location -LiteralPath "$taskRoot/mir2-web3"
$taskPaths=@('Cargo.lock','Cargo.toml','apps/simulation/Cargo.toml','apps/simulation/src/lib.rs','apps/simulation/src/runtime/mod.rs','apps/simulation/src/runtime/map.rs','apps/simulation/src/runtime/source_map_loading.rs','apps/simulation/src/runtime/source_map_io.rs','apps/simulation/src/runtime/zone/collision.rs','apps/simulation/src/runtime/zone/movement.rs','apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/runtime/checkpoint.rs')
$taskArgs=@('+1.95.0','test','--locked','-p','mir2-simulation','--lib','zone::runtime::checkpoint::tests::','--','--test-threads=1')
function Record-Inputs([string]$phase) {
 $taskRecord=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');head=$taskHead;phase=$phase;command=@('cargo')+$taskArgs;scope='12 selected files, not whole input closure';files=@($taskPaths | ForEach-Object {Get-FileHash -LiteralPath $_ -Algorithm SHA256} | Select-Object Path,Hash)}
 if (Test-Path -LiteralPath "$taskEvidence/$taskStem-$phase.json") {throw 'Evidence already exists'}
 $taskRecord | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$taskStem-$phase.json" -Encoding UTF8
}
if (Test-Path -LiteralPath "$taskEvidence/$taskStem.log") {throw 'Evidence already exists'}
Record-Inputs 'before'
$taskStarted=[DateTime]::UtcNow
& cargo @taskArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$taskStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Record-Inputs 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$taskStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$taskStem.log" -Tail 27
exit $taskExit
