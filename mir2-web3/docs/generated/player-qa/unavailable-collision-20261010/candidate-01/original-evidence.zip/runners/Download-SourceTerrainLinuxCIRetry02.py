import hashlib,json,re,stat,subprocess,tarfile,zipfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath

RUN='38001876065'
REPO='Zombieliu/mir2'
REVISION='64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
TAG='2026-10-10-source-terrain-64b6b10c05'
ROOT=Path('C:/mir2-build/p7-source-map-terrain-20261010-ci')
OUT=ROOT/'server-ci-01/artifact-02'

def digest(data):
    return hashlib.sha256(data).hexdigest()
def gh(*args):
    result=subprocess.run(['gh',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    if result.returncode:
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
    return result.stdout
def new(path,data):
    with path.open('xb') as stream:
        stream.write(data)

raw_ci=gh('run','view',RUN,'--repo',REPO,'--json','status,conclusion,headSha,jobs,url')
ci=json.loads(raw_ci)
assert ci['headSha']==REVISION
if ci['status']!='completed':
    print(json.dumps({'ready':False,'status':ci['status'],'run':RUN}))
    raise SystemExit(75)
assert ci['conclusion']=='success',ci['conclusion']
assert len(ci['jobs'])==2 and all(j['conclusion']=='success' for j in ci['jobs'])
build=next(j for j in ci['jobs'] if j['name']=='build-linux-x64')
steps={s['name']:s['conclusion'] for s in build['steps']}
for name in ('Verify shared player appearance and equipment ingress',
             'Verify disconnect cancellation and trusted journal recovery',
             'Verify Linux release and save-recovery boundary',
             'Verify classic shared gameplay and durable source receipts',
             'Verify rejected combat targets acknowledge and retire old movement',
             'Verify SnakeTotem immediate master and corpse permissions',
             'Verify original Purification completion and status cleanup',
             'Verify complete NPC Source acknowledgement and ordered pet interpretation',
             'Verify bounded Source terrain and ordinary map collision',
             'Package Gateway','Upload Gateway package'):
    assert steps.get(name)=='success',name
assert steps.get('Publish Gateway package to R2')=='skipped'
assert not OUT.exists(),'Refusing to overwrite original CI artifacts'
raw_artifacts=gh('api',f'repos/{REPO}/actions/runs/{RUN}/artifacts?per_page=100')
artifacts=json.loads(raw_artifacts)
assert artifacts['total_count']==1
artifact=artifacts['artifacts'][0]
assert artifact['name']=='mir2-gateway-linux-x64' and artifact['expired'] is False
assert artifact['workflow_run']['head_sha']==REVISION
assert re.fullmatch(r'sha256:[0-9a-f]{64}',artifact['digest'])
assert 0<artifact['size_in_bytes']<300*1024**2
OUT.mkdir()
new(OUT/'ci-status-original.json',raw_ci)
new(OUT/'ci-artifacts-original.json',raw_artifacts)
bundle=OUT/'github-artifact-original.zip'
with bundle.open('xb') as stream:
    result=subprocess.run(['gh','api',f'repos/{REPO}/actions/artifacts/{artifact["id"]}/zip'],
                          stdout=stream,stderr=subprocess.PIPE,timeout=900)
assert result.returncode==0,result.stderr.decode(errors='replace')
assert bundle.stat().st_size==artifact['size_in_bytes']
assert digest(bundle.read_bytes())==artifact['digest'].split(':',1)[1]
archive_name='mir2-gateway-linux-x64-'+TAG+'.tar.gz'
expected={archive_name,archive_name+'.sha256','latest-mir2-gateway-release.json'}
with zipfile.ZipFile(bundle) as zipped:
    entries=zipped.infolist()
    assert len(entries)==3 and sum(i.file_size for i in entries)<300*1024**2
    leaves=set()
    for item in entries:
        path=PurePosixPath(item.filename)
        assert not path.is_absolute() and '..' not in path.parts
        assert not item.is_dir() and not stat.S_ISLNK(item.external_attr>>16)
        assert path.name in expected and path.name not in leaves
        leaves.add(path.name)
        new(OUT/path.name,zipped.read(item))
    assert leaves==expected
metadata=json.loads((OUT/'latest-mir2-gateway-release.json').read_text())
assert metadata['name']=='mir2-gateway' and metadata['gitRevision']==REVISION and metadata['gitDirty'] is False
assert metadata['tag']==TAG and metadata['target']=='linux-x64' and metadata['archive']==archive_name
archive=OUT/archive_name
archive_sha=digest(archive.read_bytes())
assert archive_sha==metadata['archiveSha256']
checksum=(OUT/(archive_name+'.sha256')).read_text().split()
assert checksum==[archive_sha,archive_name]
files={}
with tarfile.open(archive,'r:gz') as packed:
    for item in packed.getmembers():
        path=PurePosixPath(item.name)
        assert not path.is_absolute() and '..' not in path.parts and item.isfile()
        assert len(path.parts)==1 and item.name in {'mir2-gateway','zone_host','RELEASE.json','README.txt'}
        assert item.name not in files and 0<item.size<=268435456
        files[item.name]=packed.extractfile(item).read()
assert set(files)=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
release=json.loads(files['RELEASE.json'])
assert release=={key:value for key,value in metadata.items() if key not in ('archive','archiveSha256')}
for name,prefix in [('mir2-gateway','binary'),('zone_host','zoneHostBinary')]:
    assert files[name][:4]==b'\x7fELF'
    assert len(files[name])==metadata[prefix+'SizeBytes'] and digest(files[name])==metadata[prefix+'Sha256']
    new(OUT/name,files[name])
new(OUT/'RELEASE.json',files['RELEASE.json'])
new(OUT/'README.txt',files['README.txt'])
manifest={'revision':REVISION,'files':[{'path':name,'size':len(files[name]),'sha256':digest(files[name]),
    'mode':0o755 if name=='mir2-gateway' else 0o644} for name in ('mir2-gateway','RELEASE.json')]}
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode()
new(OUT/'VERIFIED-FILES.json',manifest_bytes)
raw_log=gh('run','view',RUN,'--repo',REPO,'--log')
new(OUT/'ci-log-original.txt',raw_log)
for command in (b'--lib npc_population::', b'--lib zone::manager::', b'--lib online_epoch_exhaustion', b'--lib npc_population_binding::tests'):
    assert command in raw_log,command.decode()
for command in (b'--lib npc_buff_action_tests', b'--lib npc_catalog_lookup_tests', b'--lib buff_duration::tests'):
    assert command in raw_log,command.decode()
for command in (b'--lib source_map_loading::tests',
                b'map::map_collision_source_tests:: deadmine_entrance_collision_parses_from_pack crystal_map_v0_'):
    assert command in raw_log,command.decode()
receipt={'schema':'mir2.gateway.source-terrain-linux-ci.v1','createdUtc':datetime.now(timezone.utc).isoformat(),
    'runId':RUN,'url':ci['url'],'revision':REVISION,'runConclusion':'success',
    'jobs':[{key:j[key] for key in ('name','conclusion','databaseId')} for j in ci['jobs']],
    'githubArtifactDigest':artifact['digest'],'githubArtifactBytes':bundle.stat().st_size,
    'archiveSha256':archive_sha,'archiveBytes':archive.stat().st_size,
    'binarySha256':metadata['binarySha256'],'binaryBytes':metadata['binarySizeBytes'],
    'zoneHostBinarySha256':metadata['zoneHostBinarySha256'],
    'manifestSha256':digest(manifest_bytes),'logSha256':digest(raw_log),
    'publicR2Upload':False,'serverSwitched':False}
new(OUT/'CI-VERIFIED.json',(json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps(receipt))
