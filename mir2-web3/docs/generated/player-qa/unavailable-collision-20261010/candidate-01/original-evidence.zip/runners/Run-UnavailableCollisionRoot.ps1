param([Parameter(Mandatory=$true)][string]$LogStem,[Parameter(Mandatory=$true)][string[]]$ToolArgs)
$ErrorActionPreference='Stop'
$taskRoot='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p7-unavailable-collision-20261010-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
Set-Location -LiteralPath $taskRoot
$taskPaths=@('Cargo.lock','Cargo.toml','apps/simulation/Cargo.toml','apps/simulation/src/lib.rs','apps/simulation/src/runtime/mod.rs','apps/simulation/src/runtime/map.rs','apps/simulation/src/runtime/source_map_loading.rs','apps/simulation/src/runtime/source_map_io.rs','packages/game-data/Cargo.toml','packages/game-data/src/lib.rs','packages/protocol/Cargo.toml','packages/protocol/src/lib.rs','packages/game-data/data/generated/crystal_respawn_manifest.json','../.github/workflows/gateway-release.yml','apps/simulation/src/runtime/zone/collision.rs','apps/simulation/src/runtime/zone/movement.rs','apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/runtime/checkpoint.rs','apps/simulation/tests/shared_missing_map_collision.rs')
foreach ($taskSuffix in @('.log','-before.json','-after.json','-result.json')) {
 if (Test-Path -LiteralPath "$taskEvidence/$LogStem$taskSuffix") { throw 'Original evidence stem already exists' }
}
$taskCommand=@('cargo')+$ToolArgs
function Write-SourceHashes([string]$phase) {
 $taskHashes=@($taskPaths | ForEach-Object { Get-FileHash -LiteralPath $_ -Algorithm SHA256 } | Select-Object Path,Hash)
 [ordered]@{declaredBaseSource='9fe7c45ff6a9b198d87322b9ecca4a2abcac6547';utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=$taskCommand;scope="$($taskPaths.Count) selected paths, not whole-workspace input closure";source=$taskHashes} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding UTF8
}
Write-SourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& cargo @ToolArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Write-SourceHashes 'after'
[ordered]@{utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;log="$taskEvidence/$LogStem.log"} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 42
exit $taskExit
