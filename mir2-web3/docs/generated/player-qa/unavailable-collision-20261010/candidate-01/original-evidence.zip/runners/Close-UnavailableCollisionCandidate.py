"""Close only actual local tests and separately verified predecessor publication."""
import hashlib, json, re, subprocess, zipfile
from datetime import datetime, timezone
from pathlib import Path

REPO = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
EV = Path('C:/mir2-build/p7-unavailable-collision-20261010-evidence')
HELPERS = Path('E:/mir2-player-journey/tmp')
TERRAIN = Path('C:/mir2-build/p7-source-map-terrain-20261010-ci')
ROLLOUT = TERRAIN/'server-rollout-01'
BASE = '9fe7c45ff6a9b198d87322b9ecca4a2abcac6547'
LIVE = '64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
DEST = REPO/'mir2-web3/docs/generated/player-qa/unavailable-collision-20261010/candidate-01'
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def new_json(path, data):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')

git = ['git','-c','gc.auto=0','-c','maintenance.auto=false','-c',f'safe.directory={REPO.as_posix()}','-C',str(REPO)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip() == BASE
names = set()
final = {}
for stem, counts in [
    ('06-final-collision-door-and-checkpoint',[25]),
    ('07-final-normal-missing-and-explicit-cold',[5]),
    ('08-final-original-movement',[14]),
    ('09-final-original-mining-and-security',[5,20]),
    ('10-final-original-optimized-gateway-map-flow',[4]),
]:
    before, after = read(EV/(stem+'-before.json')), read(EV/(stem+'-after.json'))
    assert before['source'] == after['source'] and len(after['source']) == 19
    for row in after['source']:
        assert sha(Path(row['Path']).read_bytes()).upper() == row['Hash']
    log_bytes = (EV/(stem+'.log')).read_bytes()
    log = log_bytes.decode('utf-8-sig').replace('\r\n', '\n')
    totals = [tuple(map(int, group)) for group in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)]
    assert totals == [(count,0,0) for count in counts]
    passed = re.findall(r'^test (\S+) \.\.\. ok$', log, re.M)
    assert len(passed) == len(set(passed)) == sum(counts) and not names.intersection(passed)
    names.update(passed)
    assert read(EV/(stem+'-result.json'))['exitCode'] == 0
    final[stem] = {'passed':sum(counts),'failed':0,'ignored':0,'selectedPaths':19,
        'beforeAfterStableAndCurrent':True,'logSha256':sha(log_bytes)}
assert len(names) == 73
assert read(EV/'01-before-product-fix-normal-entry-result.json')['exitCode'] != 0
assert '1 passed; 3 failed;' in (EV/'01-before-product-fix-normal-entry.log').read_text(encoding='utf-8-sig')
assert read(EV/'04-after-fix-original-cold-and-mining-schema-result.json')['exitCode'] != 0
assert read(EV/'05-original-parent-checkpoint-baseline-result.json')['exitCode'] == 0

reviewed = {
    'mir2-web3/apps/simulation/src/runtime/zone/collision.rs':'d22bff2672d611a3a57d57f41e10532d51c3b35b38136aab433eabd26bf6df4d',
    'mir2-web3/apps/simulation/src/runtime/zone/runtime/checkpoint.rs':'401b0a97ed6034a02e9c871586622555e76841de17c37042a526a1830b4ddcc6',
    'mir2-web3/apps/simulation/tests/shared_missing_map_collision.rs':'a0f54032d36e60f55b6976a66b646131c45e4a0f2d6f30d0d8cf7127a5b2e4ea',
    '.github/workflows/gateway-release.yml':'ad136d67bac53c478fde983dc8d4cdb144399ce888d610033454cee56c36f9ca',
}
assert all(sha((REPO/path).read_bytes()) == digest for path,digest in reviewed.items())
review = {'utcRecorded':datetime.now(timezone.utc).isoformat(),'source':'Actual read-only mentor_integration_audit messages received by Root',
    'noBlockingFindings':True,'editedFiles':False,'ranTests':False,'finalHashes':reviewed,
    'originalColdAssertionsAndWorkflowCommandsRetained':True,
    'limits':['Explicit-open missing-map strict cold restore now correctly rejects a different collision identity',
        'Missing ordinary Join/trusted transforms and Gateway current-foot transfer remain open',
        'No successful Source Map.Load/population or whole P1-P7/human proof']}
new_json(EV/'FINAL-READ-ONLY-REVIEW.json',review)
linux = read(TERRAIN/'server-ci-01/artifact-02/CI-VERIFIED.json')
published = read(ROLLOUT/'PUBLIC-VERIFIED-01.json')
applied = read(ROLLOUT/'DEPLOYED-01.json')
assert linux['revision'] == published['revision'] == applied['revision'] == LIVE
assert linux['runConclusion']=='success' and published['normalPublicChecks']==62
assert published['originalRealmUnchanged'] is True and published['nativeUiAccepted'] is False and published['fullGoalComplete'] is False
assert published['binarySha256'] == linux['binarySha256'] == applied['binarySha256']
assert applied['candidateShutdownPanic'] is False and applied['envBeforeSha256']==applied['envAfterSha256']
assert all(published['after']['test']['capacity'][key]==0 for key in ('currentWsConnections','currentActiveSessions','currentReconnectLeases','currentLoginInFlight','currentNewCharacterInFlight','currentStartGameInFlight'))
io_git = read(Path('C:/mir2-build/p7-source-map-io-20261010-git-publication-01/exact-api/PUBLISHED-VERIFIED.json'))
assert io_git['head']==BASE and io_git['candidateSourcePublishedToGit'] is True
io_ci_root=Path('C:/mir2-build/p7-source-map-io-20261010-ci/server-ci-01')
io_snapshots=sorted(io_ci_root.glob('snapshot-??.json'))
io_latest=read(io_snapshots[-1])
assert io_latest['source']==BASE and io_latest['runId']==38006259110
receipt={'schema':'mir2.unavailable-collision-candidate.v1','createdUtc':datetime.now(timezone.utc).isoformat(),
    'baseSource':BASE,'uniqueFinalLocalTestsPassed':73,'newTests':9,'retainedRegressionTests':64,
    'originalFailuresRetained':True,'newFixtureTimeRepairOnly':'550ms to unchanged600ms deadline',
    'oldColdFixtureRepairOnly':'Use ordinary missing-map collision identity; keep every original cold/payload/tamper assertion',
    'finalTests':final,'review':review,
    'scope':'19 selected pre/post paths; no entire workspace/toolchain input closure',
    'newCandidateActuallyPushedAtCheckpoint':False,'newCandidateLinuxQualified':False,'newCandidatePublished':False,
    'predecessorIoActuallyPushed':io_git,'predecessorIoLinuxLastActualSnapshot':io_latest,
    'publishedTerrain':{'source':LIVE,'linuxRun':linux['runId'],'binarySha256':linux['binarySha256'],
        'publicNormalProtocolChecks':62,'originalRealmUnchanged':True,'clientReinstallRequired':False,
        'sourceIo9feIncluded':False,'newUnavailableCollisionIncluded':False},
    'noHumanOrCompleteP1P7Acceptance':True,'expiredHeartbeatRestarted':False,'blockedGoalCompleted':False}
new_json(EV/'FINAL-PROVENANCE.json',receipt)
entries={}
def add(name,path):
    assert name not in entries and path.is_file() and not path.is_symlink()
    data=path.read_bytes()
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',data),name
    entries[name]=data
for path in sorted(EV.iterdir()):
    if path.is_file(): add('local/'+path.name,path)
for name in reviewed: add('final-source/'+name,REPO/name)
for name in ['Prepare-UnavailableCollisionEvidence.py','Run-UnavailableCollisionRoot.ps1','Run-UnavailableCollisionParent.ps1',
             'Prepare-SourceTerrainArtifactRetry02.py','Download-SourceTerrainLinuxCIRetry02.py',
             'Prepare-SourceTerrainGatewayRollout.py','Close-UnavailableCollisionCandidate.py',
             'Close-UnavailableCollisionCandidate.original-before-crlf-parser-repair.py',
             'Commit-SourceMapIOCandidate.original-before-status-repair.py']:
    add('runners/'+name,HELPERS/name)
io_pub=Path('C:/mir2-build/p7-source-map-io-20261010-git-publication-01/exact-api')
for name in ['PUBLISHED-VERIFIED.json','REF-MCP-RESULT.json','REF-MCP-FRESH-READBACK.json','COMMIT-MCP-FRESH-READBACK.json']:
    add('predecessor-io-git/'+name,io_pub/name)
for path in sorted(io_ci_root.iterdir()):
    if path.is_file(): add('predecessor-io-ci/'+path.name,path)
for path in sorted((TERRAIN/'server-ci-01').glob('snapshot-*')):
    if path.is_file(): add('terrain-linux-snapshots/'+path.name,path)
add('terrain-linux/ARTIFACT-RETRY02-PREPARED.json',TERRAIN/'server-ci-01/ARTIFACT-RETRY02-PREPARED.json')
for folder in ['artifact-01','artifact-02']:
    for path in sorted((TERRAIN/'server-ci-01'/folder).iterdir()):
        if path.name in {'ci-status-original.json','ci-artifacts-original.json','ci-log-original.txt','CI-VERIFIED.json','RELEASE.json','latest-mir2-gateway-release.json','VERIFIED-FILES.json'}:
            add('terrain-linux/'+folder+'/'+path.name,path)
for path in sorted(ROLLOUT.rglob('*')):
    if path.is_file() and 'private' not in path.relative_to(ROLLOUT).parts:
        add('terrain-publication/'+path.relative_to(ROLLOUT).as_posix(),path)
DEST.mkdir(parents=True,exist_ok=False)
archive=DEST/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
    for name,data in entries.items(): zipped.writestr(name,data)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None and set(zipped.namelist())==set(entries)
    for name,data in entries.items(): assert zipped.read(name)==data
assert archive.stat().st_size<=3*1024**2
receipt['archive']={'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':len(entries)}
receipt['entries']={name:{'bytes':len(data),'sha256':sha(data)} for name,data in entries.items()}
new_json(DEST/'EVIDENCE.json',receipt)

header='''> Continued collision round, 2026-10-10: unavailable ordinary terrain now
> rejects walking/running before door/transfer-cell exceptions and cannot mint
> mineable walls. Final73 distinct local checks pass, including strict cold
> recovery, original movement/security/mining and optimized Gateway500ms flow.
> Original red baselines and fixture-only repairs are retained. Root is the
> sole writer; read-only review reports no blocker. New exact Git/Linux/publication
> are separate. [Scope and original evidence](CLASSIC-UNAVAILABLE-MAP-COLLISION-20261010.md).
> Earlier terrain64b6 is now truly Linux-qualified and published from drained
> c704 with private backups, normal/cold stops and62 public protocol checks.
> This publishes neither source-I/O9fe7 nor the new unavailable-collision fix.
> Io9fe7 is actually pushed; its Linux38006259110 is still separately tracked.
> Source Map.Load/population, current-foot transfer/Join rejection, Source-CAS
> world outbox and fullP1-P7/Mentor/native/human remain open. Expired heartbeat
> stays paused and the blocked Goal is not marked complete. Older entries are history.

'''
for name in ['AGENT-ORCHESTRATION','AGENT-TASK-QUEUE','CRYSTAL-1TO1-ROADMAP','BACKEND-1TO1-PROGRESS','CRYSTAL-SERVER-PARITY','CLASSIC-12H-DELIVERY-20261007']:
    path=REPO/'mir2-web3/docs'/(name+'.md')
    old=path.read_text(encoding='utf-8-sig')
    first,rest=old.split('\n',1)
    path.write_text(first+'\n\n'+header+rest.lstrip('\n'),encoding='utf-8')
doc='''# Unavailable ordinary map collision

Map collision read/parse failure previously became `ZoneCollision::unbounded()`.
The normal Zone Join → Walk/Run → tick path therefore allowed movement on missing
terrain; ordinary strict checkpoint restore reproduced it. This round makes that
absence a private closed collision identity. Known terrain and trusted explicit
open arenas retain their original live movement/serialization bytes because
`unavailable=false` is omitted. Doors, builder changes and transaction clones do
not clear unavailable; transfer-cell bypass runs only after this guard. Mining
also rejects unknown terrain as a wall.

The corrected real before-fix run is1 pass/3 failures. The earlier0/4 contains one
new550ms positive-fixture timing error, retained separately. Product cadence stays
600ms. The old cold fixture used explicit unbounded with a missing key; the exact
frozen9fe7 parent passes19, while the new round initially passes18/fails1 at strict
root verification. Only its constructor now uses the ordinary map collision
identity. Every original cold payload, online revocation and tamper assertion is
retained. A new test explicitly refuses strict restore of an open missing-map
checkpoint; no ignore-root, fallback arena or weakened restoration is added.

Final73 distinct selected checks pass: collision/door/checkpoint25, normal missing
and explicit-open cold5, original movement14, mining5/security20, original release
Gateway4. Nine are new;64 are retained regressions. Pre/post/current hashes cover
19 selected paths, not a whole toolchain/input closure. Independent read-only
review covers the final four files. The original failed runs remain in the archive.

This does not reject Join or trusted transforms. Missing-map prior open roots can
be rejected by strict cold restore. Existing verified-world reanchor policy is not
changed. Gateway failed Walk/Run/Turn still has a current-foot transfer path; this
round is not complete transfer safety or successful Source Map.Load/population.
Map0 can also use its known embedded starter fragment. Full P1-P7/Mentor and native
human acceptance remain unfinished, with the expired heartbeat still paused.

Separately, source9fe7 is actually pushed with exact guarded Git readbacks; its
original63 local checks and actual463 raw/1620 gzip byte probes are recorded in
[the preceding I/O round](CLASSIC-SOURCE-MAP-IO-20261010.md). New I/O Linux
38006259110 remains distinct. Predecessor terrain64b6 passed Linux38001876065;
its first partial artifact download hit unexpected EOF and remains retained.
The fresh artifact02 passed the original ZIP/TAR/ELF/full gate verifier.

Terrain64b6 was then published after fresh six-zero/TCP/viewer checks, private
DB/state/recovery/config backup, normal c704 stop and candidate normal stop/cold
restart. Only isolated Gateway ExecStart changed; original realm, resources,
environment, authentication and R23/feed18 delivery were not modified. Original
44 ordinary public WSS and18 protocol/native-resume checks pass. These are normal
public packet stories, not GUI/human acceptance; this release does not include
9fe7 I/O or the new unavailable guard. Existing operator has two snapshot-to-stop
windows without an admission fence; no claim is made that future arrivals are
atomically excluded. Apply success is separate from complete public verification;
candidate-started failures do not trigger a blind schema/DB rollback.

[Original local, Git, Linux and public evidence](generated/player-qa/unavailable-collision-20261010/candidate-01/EVIDENCE.json).
'''
(REPO/'mir2-web3/docs/CLASSIC-UNAVAILABLE-MAP-COLLISION-20261010.md').write_text(doc,encoding='utf-8')
for name, note in [
    ('CLASSIC-SOURCE-MAP-IO-20261010','''> Actual follow-up: source9fe7 is pushed with exact Git ref/commit/tree readbacks.
> Linux38006259110 is tracked separately from local63/byte comparisons. Terrain64b6
> is now published; it does not include this I/O round or later collision guard.
> [Actual follow-up evidence](CLASSIC-UNAVAILABLE-MAP-COLLISION-20261010.md).

'''),
    ('CLASSIC-SOURCE-MAP-TERRAIN-20261010','''> Actual follow-up: exact64b6 Linux38001876065 succeeds; genuine artifact02 is
> verified after the retained partial EOF download. Drained c704→64b6 publication,
> private backup, normal/cold stops and62 original public protocol checks succeed.
> No Windows reinstall or complete Source Map.Load/P1-P7/human acceptance is claimed.
> [Actual original follow-up evidence](CLASSIC-UNAVAILABLE-MAP-COLLISION-20261010.md).

''')]:
    path=REPO/'mir2-web3/docs'/(name+'.md')
    old=path.read_text(encoding='utf-8-sig')
    first,rest=old.split('\n',1)
    path.write_text(first+'\n\n'+note+rest.lstrip('\n'),encoding='utf-8')
print(json.dumps({'uniqueLocalTestsPassed':73,'archive':receipt['archive'],'publishedTerrain':receipt['publishedTerrain'],
    'newCollisionPublished':False,'completeGoal':False}))
