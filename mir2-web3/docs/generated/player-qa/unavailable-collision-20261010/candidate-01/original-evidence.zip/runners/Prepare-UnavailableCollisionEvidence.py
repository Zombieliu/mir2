import hashlib, json, subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
OUT = Path('C:/mir2-build/p7-unavailable-collision-20261010-evidence')
BASE = '9fe7c45ff6a9b198d87322b9ecca4a2abcac6547'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', f'safe.directory={ROOT.as_posix()}', '-C', str(ROOT), *args])
assert git('rev-parse', 'HEAD').decode().strip() == BASE
status = git('status', '--porcelain=v1').decode()
assert status.strip() == '?? mir2-web3/apps/simulation/tests/shared_missing_map_collision.rs', status
OUT.mkdir(exist_ok=False)
files = {
    '00-first-attempt-test.rs': ROOT/'mir2-web3/apps/simulation/tests/shared_missing_map_collision.rs',
    '00-first-attempt-original.log': Path('C:/mir2-build/p7-source-map-io-20261010-evidence/04-before-fix-missing-map-regression.log'),
    '00-original-collision.rs': ROOT/'mir2-web3/apps/simulation/src/runtime/zone/collision.rs',
    '00-original-movement.rs': ROOT/'mir2-web3/apps/simulation/src/runtime/zone/movement.rs',
}
entries = []
for name, path in files.items():
    data = path.read_bytes()
    with (OUT/name).open('xb') as stream:
        stream.write(data)
    entries.append({'name': name, 'originalPath': str(path), 'bytes': len(data), 'sha256': sha(data)})
receipt = {
    'utcRecorded': datetime.now(timezone.utc).isoformat(), 'baseSource': BASE,
    'scope': 'Post-run preservation of the first real attempt, not a pre-run hash receipt.',
    'originalExitCode': 101, 'originalTests': {'passed': 0, 'failed': 4},
    'defectFailures': ['normal_missing_map_walk_corrects_owner_without_broadcast_or_later_drift', 'normal_missing_map_run_corrects_owner_without_broadcast_or_later_drift', 'missing_map_stays_closed_after_ordinary_checkpoint_restore'],
    'fixtureFailure': 'New explicit-open positive used 550ms before the unchanged 600ms movement deadline; only this new fixture time will be corrected.',
    'productDiffBeforeFixtureRepair': git('diff', '--stat').decode(), 'files': entries,
}
with (OUT/'00-first-attempt-preserved.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt))
