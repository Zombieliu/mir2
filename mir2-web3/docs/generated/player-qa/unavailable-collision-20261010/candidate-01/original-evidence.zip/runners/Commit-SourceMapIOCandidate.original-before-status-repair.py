"""Commit only the returned leaf, Root integration, scoped docs and receipts."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
from datetime import datetime, timezone

repo = Path(__file__).resolve().parent / 'gateway-lifecycle-20261008-01'
out = Path('C:/mir2-build/p7-source-map-io-20261010-git-publication-01')
base = '64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-c', 'gc.auto=0',
       '-c', 'maintenance.auto=false', '-C', str(repo)]

def run(*args):
    return subprocess.check_output(git + list(args)).decode().strip()

assert run('rev-parse', 'HEAD') == base
assert run('branch', '--show-current') == 'codex/gateway-disconnect-lifecycle-20261008'
assert not run('diff', '--cached', '--name-only') and not out.exists()
paths = ['.github/workflows/gateway-release.yml']
paths += ['mir2-web3/apps/simulation/src/runtime/' + name + '.rs'
          for name in ['map', 'mod', 'source_map_loading', 'source_map_io']]
paths += ['mir2-web3/docs/' + name + '.md' for name in [
    'AGENT-ORCHESTRATION', 'AGENT-TASK-QUEUE', 'BACKEND-1TO1-PROGRESS',
    'CLASSIC-12H-DELIVERY-20261007', 'CRYSTAL-1TO1-ROADMAP', 'CRYSTAL-SERVER-PARITY',
    'CLASSIC-NPC-OWNER-EXECUTION-20261010', 'CLASSIC-SOURCE-MAP-TERRAIN-20261010',
    'CLASSIC-SOURCE-MAP-IO-20261010']]
assert len(paths) == 14
directories = [
    'mir2-web3/docs/generated/player-qa/source-map-terrain-20261010/git-linux-followup-01/',
    'mir2-web3/docs/generated/player-qa/source-map-io-20261010/candidate-01/']
archives = [directory + name for directory in directories for name in ['EVIDENCE.json', 'original-evidence.zip']]
status = run('status', '--porcelain=v1', '--untracked-files=all')
assert {line[3:] for line in status.splitlines()} == set(paths), 'Unexpected user/worker changes'
for name in paths + archives:
    path = repo / name
    assert path.is_file() and not path.is_symlink() and 0 < path.stat().st_size <= 3 * 1024**2
receipts = []
for directory in directories:
    receipt = json.loads((repo / directory / 'EVIDENCE.json').read_bytes())
    archive = repo / directory / 'original-evidence.zip'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt['archive']['sha256']
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None and set(zipped.namelist()) == set(receipt['entries'])
        for name, expected in receipt['entries'].items():
            data = zipped.read(name)
            assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    receipts.append(receipt)
followup, io = receipts
assert followup['source'] == base and followup['sourceActuallyPushed'] is True
assert followup['predecessorLinux']['runConclusion'] == 'success'
assert io['baseSource'] == base and io['uniqueTestsPassed'] == 63 and io['ioUnitTestsPassed'] == 27
assert io['localTestsPassed'] is True and io['originalBenchmarkIgnored'] == 1
assert io['byteProbe']['exitCode'] == 0 and io['byteProbe']['beforeAfterStable'] is True
assert io['byteProbe']['rawFilesMatched'] == 463 and io['byteProbe']['packGzipFilesMatched'] == 1620
provenance = json.loads(Path('C:/mir2-build/p7-source-map-io-20261010-evidence/FINAL-PROVENANCE.json').read_bytes())
assert len(provenance['finalSelectedInputs']) == 14
for item in provenance['finalSelectedInputs']:
    assert hashlib.sha256(Path(item['Path']).read_bytes()).hexdigest().upper() == item['Hash']
for item in provenance['byteProbeInputs']:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
subprocess.run(git + ['add', '--'] + paths, check=True)
subprocess.run(git + ['add', '-f', '--'] + archives, check=True)
assert set(run('diff', '--cached', '--name-only').splitlines()) == set(paths + archives)
subprocess.run(git + ['diff', '--cached', '--check'], check=True)
subprocess.run(git + ['commit', '-m', 'fix(map): bound raw and gzip byte providers without losing source checks'], check=True)
head = run('rev-parse', 'HEAD')
assert run('rev-parse', 'HEAD^') == base and not run('status', '--porcelain=v1', '--untracked-files=all')
out.mkdir()
record = {'createdUtc': datetime.now(timezone.utc).isoformat(), 'repository': 'Zombieliu/mir2',
          'branch': 'codex/gateway-disconnect-lifecycle-20261008', 'head': head, 'parent': base,
          'tree': run('rev-parse', 'HEAD^{tree}'), 'paths': paths + archives, 'workingTreeClean': True,
          'remoteVerified': False, 'selectedLocalChecksPassed': 63, 'originalBenchmarkIgnored': 1,
          'actualRawBytesMatched': 463, 'actualPackBytesMatched': 1620,
          'exactLinuxPassed': False, 'successfulSourceLoadProducerImplemented': False,
          'gatewayPublished': False, 'realSavesModified': False}
with (out / 'LOCAL-COMMIT.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
