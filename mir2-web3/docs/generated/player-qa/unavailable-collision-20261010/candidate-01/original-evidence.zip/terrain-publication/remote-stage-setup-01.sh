/usr/bin/python3 - <<'PY'
import os,pathlib,stat,json
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-64b6b10c05732048da9c6bf5ccb0a491d2d053d3')
assert p.parent.resolve(strict=True)==p.parent and p.parent.stat().st_uid in (0,os.geteuid())
assert not p.exists() and not p.is_symlink(), 'Existing staging requires inspection; refusing a blind rerun'
p.mkdir(mode=0o700)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
print(json.dumps({'stageCreated':True}))
PY
