/usr/bin/python3 - <<'PY'
STAGE='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
REVISION='64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
PINS={'gateway-package.tar.gz': {'size': 34280956, 'sha256': '4306a04e0e0cda8b65a76492c2a9180cf14b0650fa4a7a8b1291c74e4195663c'}, 'VERIFIED-FILES.json': {'size': 412, 'sha256': '561171b44ee3c8c08c7442aba7f3f7f88c1e71878aa6207e4b6f2c5f2e0fc275'}, 'upgrade-source-terrain-gateway-01.py': {'size': 31560, 'sha256': 'a4cf2640cc820065bcd55d40be7f498fca814dfd0e5a39c3df03fb1d25769b3c'}}
import hashlib,json,os,pathlib,stat,tarfile
p=pathlib.Path(STAGE)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
assert set(x.name for x in p.iterdir())==set(PINS)
for name,pin in PINS.items():
 f=p/name;info=f.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.geteuid()
 assert info.st_size==pin['size'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
manifest=json.loads((p/'VERIFIED-FILES.json').read_text())
assert manifest['revision']==REVISION
expected={row['path']:row for row in manifest['files']}
assert set(expected)=={'mir2-gateway','RELEASE.json'}
seen=set()
with tarfile.open(p/'gateway-package.tar.gz','r:gz') as packed:
 for item in packed.getmembers():
  assert item.isfile() and item.name in {'mir2-gateway','zone_host','RELEASE.json','README.txt'}
  assert item.name not in seen and 0<item.size<=268435456
  seen.add(item.name)
  if item.name not in expected: continue
  data=packed.extractfile(item).read();entry=expected[item.name]
  assert len(data)==entry['size'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  fd=os.open(p/item.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,entry['mode'])
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.chmod(p/item.name,entry['mode'])
assert seen=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
print(json.dumps({'artifactStageVerified':True,'revision':REVISION,'publicServiceChanged':False}))
PY
