"""Archive actual serial results and failures, never a synthetic qualification."""
from datetime import datetime, timezone
import hashlib, json, re, zipfile
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
out = Path('C:/mir2-build/p1-outcome-respawn-performance-20261010-evidence')
frozen = json.loads((out/'SOURCE-FROZEN-02.json').read_bytes())
final = sorted(p for p in out.glob('check-*-result.json') if 2 <= int(p.name.split('-')[1]) <= 6 or int(p.name.split('-')[1]) == 8)
assert len(final) == 6
passed = set()
checks = []
for path in final:
    result = json.loads(path.read_text(encoding='utf-8-sig'))
    assert result['exitCode'] == 0
    stem = path.name.removesuffix('-result.json')
    before = json.loads((out/(stem+'-before.json')).read_text(encoding='utf-8-sig'))
    after = json.loads((out/(stem+'-after.json')).read_text(encoding='utf-8-sig'))
    assert before['command'] == after['command'] and before['source'] == after['source']
    for row in frozen['changedPaths']:
        absolute = str((repo/row['path']).resolve()).casefold()
        observed = next(r['Hash'] for r in before['source'] if r['Path'].casefold() == absolute)
        assert observed.casefold() == row['candidateSha256']
    target = 'lib'
    names = []
    for line in (out/(stem+'.log')).read_text(encoding='utf-8-sig').splitlines():
        match = re.search(r'Running tests[\\/](\w+)\.rs', line)
        if match: target = match.group(1)
        match = re.fullmatch(r'test (.+) \.\.\. ok', line)
        if match: names.append(target + ':' + match.group(1))
    package = before['command'][before['command'].index('-p')+1]
    actual = {package+':'+name for name in names}
    summaries = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', (out/(stem+'.log')).read_text(encoding='utf-8-sig'))
    assert len(names) == sum(int(r[0]) for r in summaries) and all(r[1:] == ('0','0') for r in summaries)
    passed |= actual
    checks.append({'stem':stem, 'command':before['command'], 'passed':len(names), 'testNames':sorted(actual), 'exitCode':0, 'selectedBeforeAfterInputsEqual':True})
for row in frozen['changedPaths']:
    assert hashlib.sha256((repo/row['path']).read_bytes()).hexdigest() == row['candidateSha256']
runner = Path('E:/mir2-player-journey/tmp/Run-OutcomeRespawnPerformanceQualification.ps1')
assert hashlib.sha256(runner.read_bytes()).hexdigest() == frozen['runnerSha256']
failed = json.loads((out/'check-01-focused-simulation-clock-geometry-result.json').read_text(encoding='utf-8-sig'))
assert failed['exitCode'] == 101
invocation_failure = json.loads((out/'check-07-original-crowded-pet-purification-integrations-result.json').read_text(encoding='utf-8-sig'))
assert invocation_failure['exitCode'] == 101
invocation_log = (out/'check-07-original-crowded-pet-purification-integrations.log').read_text(encoding='utf-8-sig')
assert 'could not compile' in invocation_log and 'test result:' not in invocation_log
folder = repo/'mir2-web3/docs/generated/player-qa/outcome-respawn-performance-20261010/candidate-01'
folder.mkdir(parents=True, exist_ok=False)
entries = []
with zipfile.ZipFile(folder/'original-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in sorted(out.rglob('*')):
        if not path.is_file(): continue
        data = path.read_bytes()
        # Check actual credential material, not harmless names of auth fields.
        assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{40,}|ghp_[A-Za-z0-9]{30,}', data)
        name = path.relative_to(out).as_posix()
        archive.writestr(name,data)
        entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    for name in ['Run-OutcomeRespawnPerformanceQualification.ps1','Prepare-OutcomeRespawnPerformanceQualification.py','Run-OutcomeRespawnPerformanceGates.py','Archive-OutcomeRespawnPerformanceCandidate.py']:
        data = (Path(__file__).parent/name).read_bytes()
        archive.writestr('helpers/'+name,data)
        entries.append({'path':'helpers/'+name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
archive_path = folder/'original-evidence.zip'
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None and len(archive.infolist()) == len(entries)
    for row in entries: assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
data = archive_path.read_bytes()
assert len(data) <= 3*1024*1024
proof = {'utc':datetime.now(timezone.utc).isoformat(), 'parent':frozen['parent'],
    'sourceSha256':{r['path']:r['candidateSha256'] for r in frozen['changedPaths']},
    'checks':checks, 'passedRustDistinct':len(passed), 'testNames':sorted(passed),
    'newTests':15, 'allSelectedFinalChecksPass':True,
    'originalInitialFixtureFailureRetained':True, 'originalParentLinuxStrict500msFailureRetained':True,
    'originalMissingTestSupportInvocationFailureRetained':True,
    'originalStrictScrollSourceOrClocksOrAssertionsChanged':False,
    'workflowOriginalCommandsAndGatesPreserved':True,
    'newSourcePushed':False, 'newSourceLinuxQualified':False, 'newGatewayPublished':False,
    'realSaveModified':False, 'nativeHumanAcceptanceClaimed':False, 'fullP1P7Claimed':False,
    'archive':{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'entries':len(entries)},'entries':entries}
with (folder/'EVIDENCE.json').open('x',encoding='utf-8') as stream:
    json.dump(proof,stream,indent=2); stream.write('\n')
print(json.dumps({k:proof[k] for k in ['parent','passedRustDistinct','newTests','archive','allSelectedFinalChecksPass']}))
