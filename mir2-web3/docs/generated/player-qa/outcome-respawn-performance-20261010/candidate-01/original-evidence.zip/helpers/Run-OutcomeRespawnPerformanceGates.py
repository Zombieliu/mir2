"""Serial qualification on frozen source; never repeat until green."""
from datetime import datetime, timezone
import hashlib, json, subprocess
from pathlib import Path

directory = Path(__file__).resolve().parent
repo = directory / 'gateway-lifecycle-20261008-01'
out = Path('C:/mir2-build/p1-outcome-respawn-performance-20261010-evidence')
runner = directory / 'Run-OutcomeRespawnPerformanceQualification.ps1'
frozen = json.loads((out / 'SOURCE-FROZEN-02.json').read_bytes())
assert json.loads((out / 'check-02-focused-simulation-final-clock-geometry-result.json').read_text(encoding='utf-8-sig'))['exitCode'] == 0
assert hashlib.sha256(runner.read_bytes()).hexdigest() == frozen['runnerSha256']
previous = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence/check-15-final-gateway-purification-release-before.json')
strict = json.loads(previous.read_text(encoding='utf-8-sig'))['command'][1:]
checks = [
 ('check-03-gateway-clock-typed-outcome-hot-path', ['+1.89.0','test','--locked','-j','1','-p','mir2-gateway','--lib','--','--test-threads=1','outcome_tick_tests::','shared_session_hot_path_tests::','typed_game_shop_outcome']),
 ('check-04-original-optimized-gateway-strict-scroll', strict),
 ('check-05-adjacent-original-simulation-spawn-movement', ['+1.89.0','test','--locked','-j','1','-p','mir2-simulation','--lib','--','--test-threads=1','start_game_visible_respawns','crystal_current_map_transfer_spawns_visible','crystal_world_respawn_spawns','movement_deadline_tests::','map_transfer_availability_tests::','unavailable_collision_tests::']),
 ('check-06-original-gateway-optimized-map-availability', ['+1.89.0','test','--locked','--release','-j','1','-p','mir2-gateway','--lib','map_transfer_availability_tests::','--','--test-threads=1']),
 ('check-07-original-crowded-pet-purification-integrations', ['+1.89.0','test','--locked','--no-fail-fast','-j','1','-p','mir2-simulation','--test','shared_crowded_escape','--test','shared_pet_pvp','--test','shared_purification_map_transfer','--test','shared_snake_master_lifecycle','--','--test-threads=1']),
]
for stem, args in checks:
    for row in frozen['changedPaths']:
        assert hashlib.sha256((repo / row['path']).read_bytes()).hexdigest() == row['candidateSha256']
    assert not (out / (stem + '-result.json')).exists()
    quote = lambda value: "'" + value.replace("'", "''") + "'"
    command = '& ' + quote(runner.as_posix()) + ' -LogStem ' + quote(stem) + ' -ToolArgs @(' + ','.join(map(quote, args)) + ')'
    print(json.dumps({'starting': stem, 'cargoArgs': args}), flush=True)
    started = datetime.now(timezone.utc).isoformat()
    process = subprocess.run(['pwsh','-NoLogo','-NoProfile','-Command',command], capture_output=True, timeout=3600)
    (out / (stem + '-wrapper.stdout.log')).open('xb').write(process.stdout)
    (out / (stem + '-wrapper.stderr.log')).open('xb').write(process.stderr)
    proof = {'utcStarted': started, 'utcFinished': datetime.now(timezone.utc).isoformat(), 'actualWrapperExitCode': process.returncode, 'cargoArgs': args}
    (out / (stem + '-wrapper.json')).open('x', encoding='utf-8').write(json.dumps(proof, indent=2)+'\n')
    result = json.loads((out / (stem + '-result.json')).read_text(encoding='utf-8-sig'))
    print(json.dumps({'completed': stem, 'wrapperExitCode': process.returncode, 'cargoExitCode': result['exitCode']}), flush=True)
    assert process.returncode == result['exitCode'] == 0, 'Original failure retained; stop dependent gates'
