"""Freeze this bounded product round; preserve the original timing failure."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

directory = Path(__file__).resolve().parent
repo = directory / 'gateway-lifecycle-20261008-01'
parent = '6153cb2b802fa700f6a182ce704f76e7568bdd08'
out = Path('C:/mir2-build/p1-outcome-respawn-performance-20261010-evidence')
out.mkdir(exist_ok=True)
assert not (out / 'SOURCE-FROZEN-01.json').exists()
git = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
       '-c', 'safe.directory=' + repo.as_posix(), '-C', str(repo)]
assert subprocess.check_output(git + ['rev-parse', 'HEAD']).decode().strip() == parent
assert not subprocess.check_output(git + ['diff', '--cached', '--name-only']).strip()
changed = [
    '.github/workflows/gateway-release.yml',
    'mir2-web3/apps/gateway/src/routing.rs',
    'mir2-web3/apps/simulation/src/runtime/monsters.rs',
    'mir2-web3/apps/simulation/src/runtime/session.rs',
    'mir2-web3/apps/simulation/src/world_runtime.rs',
]
added = [
    'mir2-web3/apps/gateway/src/routing/tests/outcome_tick_tests.rs',
    'mir2-web3/apps/simulation/src/runtime/monsters/respawn_geometry_cache_tests.rs',
    'mir2-web3/apps/simulation/src/world_runtime_tick_tests.rs',
]
assert set(subprocess.check_output(git + ['diff', '--name-only']).decode().splitlines()) == set(changed)
assert set(subprocess.check_output(git + ['ls-files', '--others', '--exclude-standard']).decode().splitlines()) == set(added)
canon = lambda data: data.replace(b'\r\n', b'\n')
strict = 'mir2-web3/apps/gateway/tests/shared_purification_map_transfer.rs'
assert canon((repo / strict).read_bytes()) == canon(subprocess.check_output(git + ['show', parent + ':' + strict]))
workflow_old = canon(subprocess.check_output(git + ['show', parent + ':' + changed[0]]))
workflow_new = canon((repo / changed[0]).read_bytes())
new_step = workflow_new[workflow_new.index(b'      - name: Verify lightweight outcome clock'):workflow_new.index(b'      - name: Verify original Purification')]
assert workflow_new.replace(new_step, b'') == workflow_old
subprocess.run(git + ['diff', '--check'], check=True)

old_runner = (directory / 'Run-ClassicFixtureQualificationFinal.ps1').read_text()
runner = old_runner.replace('p7-snake-recovery-fixture-20261010-evidence', out.name)
runner = runner.replace('348caa5e4b3b8bb3d63e3d2af80803e958adafee', parent)
additional = [path.removeprefix('mir2-web3/') for path in changed[1:] + added
              if path.removeprefix('mir2-web3/') not in old_runner]
additional += ['apps/gateway/tests/shared_purification_map_transfer.rs',
               'apps/gateway/src/routing/tests/shared_session_hot_path_tests.rs',
               'apps/simulation/src/runtime/packets.rs',
               'apps/simulation/src/runtime/resources.rs']
anchor = " 'apps/web/lib/generated/crystal-map-pack/d024.map.gz'\n)\n"
assert runner.count(anchor) == 1
runner = runner.replace(anchor, anchor[:-3] + ',\n' + ',\n'.join(" '" + path + "'" for path in additional) + '\n)\n', 1)
runner_path = directory / 'Run-OutcomeRespawnPerformanceQualification.ps1'
with runner_path.open('x', encoding='utf-8') as stream: stream.write(runner)

rows = []
for path in changed + added:
    data = (repo / path).read_bytes()
    row = {'path': path, 'candidateSha256': hashlib.sha256(data).hexdigest(), 'added': path in added}
    target = out / 'candidate-sources-01' / 'candidate' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    if path in changed:
        original = subprocess.check_output(git + ['show', parent + ':' + path])
        row['parentCanonicalSha256'] = hashlib.sha256(canon(original)).hexdigest()
        target = out / 'candidate-sources-01' / 'original' / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(original)
    rows.append(row)
with (out / 'selected-product-source-01.patch').open('xb') as stream:
    stream.write(subprocess.check_output(git + ['diff', '--'] + changed))
ci = Path('C:/mir2-build/p7-terrain-fixture-recovery-20261010-ci/server-ci-01')
red = ['snapshot-03.json', 'FAILED-JOB-LOG01-ATTEMPT-1.json', 'failed-job-log01-attempt-1.txt']
red_rows = []
for name in red:
    data = (ci / name).read_bytes()
    (out / ('parent-ci-' + name)).open('xb').write(data)
    red_rows.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
paths = re.search(r'\$taskPaths=@\((.*?)\n\)', runner, re.S).group(1)
selected = re.findall(r"'([^']+)'", paths)
assert len(selected) == len(set(selected))
record = {'utc': datetime.now(timezone.utc).isoformat(), 'parent': parent,
    'changedPaths': rows, 'runnerSha256': hashlib.sha256(runner_path.read_bytes()).hexdigest(),
    'selectedInputPathCount': len(selected), 'wholeWorkspaceClosureClaimed': False,
    'unchangedOriginalStrictScrollSha256': hashlib.sha256((repo / strict).read_bytes()).hexdigest(),
    'originalWorkflowCommandsAndRequirementsPreserved': True,
    'originalParentCIFailure': red_rows, 'newSourceTestResultsPending': True,
    'linuxQualified': False, 'gatewayPublished': False, 'realSaveChanged': False}
with (out / 'SOURCE-FROZEN-01.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps({'evidence': str(out), 'changedPaths': len(rows), 'selectedInputs': len(selected),
                  'runnerSha256': record['runnerSha256']}))
