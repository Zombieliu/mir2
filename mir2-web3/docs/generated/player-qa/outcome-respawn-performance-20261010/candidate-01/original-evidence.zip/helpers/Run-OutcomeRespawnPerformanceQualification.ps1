param(
 [Parameter(Mandatory=$true)][string]$LogStem,
 [Parameter(Mandatory=$true)][string[]]$ToolArgs,
 [string]$TaskRoot='E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3'
)
$ErrorActionPreference='Stop'
$taskEvidence='C:/mir2-build/p1-outcome-respawn-performance-20261010-evidence'
$env:CARGO_TARGET_DIR='C:/mir2-build/p4-purification-map-20261009-target'
Set-Location -LiteralPath $TaskRoot
$taskPaths=@(
 'Cargo.lock','Cargo.toml','apps/simulation/Cargo.toml',
 'apps/simulation/src/lib.rs','apps/simulation/src/runtime/mod.rs',
 'apps/simulation/src/runtime/map.rs','apps/simulation/src/runtime/source_map_loading.rs',
 'apps/simulation/src/runtime/source_map_io.rs',
 'apps/simulation/src/runtime/zone/collision.rs','apps/simulation/src/runtime/zone/movement.rs',
 'apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/runtime/checkpoint.rs',
 'apps/simulation/src/runtime/zone/runtime/snake_totem_ai.rs',
 'apps/simulation/src/runtime/zone/runtime/owned_pet_combat.rs',
 'apps/simulation/tests/shared_snake_master_lifecycle.rs',
 'apps/simulation/tests/shared_missing_map_collision.rs',
 'apps/simulation/tests/shared_purification_map_transfer.rs',
 'apps/simulation/src/runtime/map_transfer_availability_tests.rs',
 'packages/game-data/Cargo.toml','packages/game-data/src/lib.rs',
 'packages/protocol/Cargo.toml','packages/protocol/src/lib.rs',
 'packages/game-data/data/generated/crystal_respawn_manifest.json',
 'apps/web/lib/generated/crystal-map-pack/0.map.gz',
 '../.github/workflows/gateway-release.yml',
 'apps/gateway/Cargo.toml','apps/gateway/src/routing.rs',
 'apps/gateway/src/routing/tests/map_transfer_availability_tests.rs',
 'apps/gateway/src/routing/tests/owner_location_order_tests.rs',
 'apps/simulation/src/runtime/zone/runtime/owned_pet_combat_tests.rs',
 'apps/simulation/src/runtime/zone/runtime/owned_pet_immediate_master_tests.rs',
 'apps/simulation/src/runtime/zone/runtime/purification_tests.rs',
 'apps/simulation/tests/shared_crowded_escape.rs',
 'apps/simulation/tests/shared_monster_hell_ai.rs',
 'apps/simulation/tests/shared_pet_pvp.rs',
 'packages/game-data/data/generated/crystal_starter_map_collision.json',
 'apps/web/lib/generated/crystal-map-pack/d022.map.gz',
 'apps/web/lib/generated/crystal-map-pack/d023.map.gz',
 'apps/web/lib/generated/crystal-map-pack/d024.map.gz',
 'apps/simulation/src/runtime/monsters.rs',
 'apps/simulation/src/runtime/session.rs',
 'apps/simulation/src/world_runtime.rs',
 'apps/gateway/src/routing/tests/outcome_tick_tests.rs',
 'apps/simulation/src/runtime/monsters/respawn_geometry_cache_tests.rs',
 'apps/simulation/src/world_runtime_tick_tests.rs',
 'apps/gateway/tests/shared_purification_map_transfer.rs',
 'apps/gateway/src/routing/tests/shared_session_hot_path_tests.rs',
 'apps/simulation/src/runtime/packets.rs',
 'apps/simulation/src/runtime/resources.rs'
)
New-Item -ItemType Directory -Path $taskEvidence -Force | Out-Null
foreach($taskSuffix in @('.log','-before.json','-after.json','-result.json')) {
 if(Test-Path -LiteralPath "$taskEvidence/$LogStem$taskSuffix") {throw 'Original evidence stem already exists'}
}
$taskCommand=@('cargo')+$ToolArgs
function Write-TaskSourceHashes([string]$phase) {
 $taskHashes=@($taskPaths | ForEach-Object {Get-FileHash -LiteralPath $_ -Algorithm SHA256} | Select-Object Path,Hash)
 [ordered]@{
  declaredBaseSource='6153cb2b802fa700f6a182ce704f76e7568bdd08'
  utc=[DateTime]::UtcNow.ToString('o');phase=$phase;command=$taskCommand
  root=$TaskRoot;scope="$($taskPaths.Count) selected paths, not whole-workspace input closure"
  source=$taskHashes
 } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskEvidence/$LogStem-$phase.json" -Encoding UTF8
}
Write-TaskSourceHashes 'before'
$taskStarted=[DateTime]::UtcNow
& cargo @ToolArgs 2>&1 | Out-File -LiteralPath "$taskEvidence/$LogStem.log" -Encoding UTF8
$taskExit=$LASTEXITCODE
Write-TaskSourceHashes 'after'
[ordered]@{
 utcStarted=$taskStarted.ToString('o');utcFinished=[DateTime]::UtcNow.ToString('o')
 exitCode=$taskExit;log="$taskEvidence/$LogStem.log"
} | ConvertTo-Json | Set-Content -LiteralPath "$taskEvidence/$LogStem-result.json" -Encoding UTF8
Get-Content -LiteralPath "$taskEvidence/$LogStem.log" -Tail 42
exit $taskExit
