sudo -n /usr/bin/python3 - <<'PY'
import hashlib,json,pathlib,re,stat,subprocess,urllib.request
sha=lambda data:hashlib.sha256(data).hexdigest()
def run(args):return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15).stdout.decode()
def health(port):
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 with opener.open('http://127.0.0.1:%d/health'%port,timeout=5) as response:return json.load(response)
test=health(7210)
unit=dict(line.split('=',1) for line in run(['systemctl','show','mir2-playtest.service','-p','MainPID','-p','Result','-p','ExecMainStatus','-p','NRestarts','-p','DropInPaths']).splitlines())
pid=unit['MainPID'];assert pid.isdecimal() and pid!='0'
process_env=dict(entry.split(b'=',1) for entry in pathlib.Path('/proc/'+pid+'/environ').read_bytes().split(b'\0') if b'=' in entry)
names=('/etc/mir2-playtest/gateway.env','/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf','/etc/systemd/system/mir2-playtest.service.d/90-spectator-watch.conf','/etc/systemd/system/mir2-playtest.service','/etc/caddy/Caddyfile','/srv/mir2-client-updates/feed-current/latest.json','/srv/mir2-client-updates/feed-current/latest.p7s')
files={}
for name in names:
 p=pathlib.Path(name);s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_size<=131072
 data=p.read_bytes();files[name]=dict(bytes=len(data),sha256=sha(data),uid=s.st_uid,mode=oct(stat.S_IMODE(s.st_mode)),nlink=s.st_nlink)
def env(data):
 return dict((line.partition(b'=')[0],line.partition(b'=')[2].strip().strip(b'"')) for line in data.splitlines() if line and not line.startswith(b'#') and b'=' in line)
current=pathlib.Path(names[0]).read_bytes();current_vars=env(current)
old=pathlib.Path('/var/backups/mir2-playtest-stripe-test-20261011-01/gateway.env.before');old_vars=env(old.read_bytes())
billing={b'MIR2_STRIPE_ENABLED',b'MIR2_STRIPE_SECRET_KEY',b'MIR2_STRIPE_WEBHOOK_SECRET',b'MIR2_BILLING_PUBLIC_BASE_URL',b'MIR2_STRIPE_ALLOW_LOOPBACK_TEST_RETURN',b'MIR2_STRIPE_RECHARGE_OFFERS'}
nonbilling_changed=[key.decode() for key in sorted(set(old_vars)|set(current_vars)) if key not in billing and old_vars.get(key)!=current_vars.get(key)]
changed_from_process=[key.decode() for key in sorted(current_vars) if current_vars[key]!=process_env.get(key)]
backup=pathlib.Path('/var/backups/mir2-playtest-before-8fee37c1afd154b18ceffe53b1fc4dd02b6f38a2')
backup_files=[dict(name=p.name,bytes=p.lstat().st_size,regular=p.is_file(),symlink=p.is_symlink()) for p in sorted(backup.iterdir())]
snapshot_envs={}
for name in ('gateway.env','gateway.env.before','env.before','gateway.env.backup'):
 p=backup/name
 if p.is_file() and not p.is_symlink() and p.stat().st_size<=65536:
  data=p.read_bytes();values=env(data)
  snapshot_envs[name]=dict(sha256=sha(data),bytes=len(data),changedKeys=[key.decode() for key in sorted(set(values)|set(current_vars)) if values.get(key)!=current_vars.get(key)])
binary=pathlib.Path('/proc/'+pid+'/exe');binary_sha=sha(binary.read_bytes())
post_snapshot=(backup/'gateway.env').read_bytes()
assert sha(post_snapshot)=='41d0939baa6f164a5db0605ef441647c4c8214a6b4ac1dd7c69ab1da65c647c0'
assert current.startswith(post_snapshot)
phase_suffix=current[len(post_snapshot):]
phase_values=env(phase_suffix)
assert set(phase_values)=={b'MIR2_ACTIVITY_PHASE',b'MIR2_ACTIVITY_PHASE_START_MS'}
assert phase_values[b'MIR2_ACTIVITY_PHASE']==b'closed'
assert phase_values[b'MIR2_ACTIVITY_PHASE_START_MS'].isdigit()
assert all(process_env.get(key)==value for key,value in phase_values.items())
phase_proof=dict(originalPrivateEnvPrefixPreserved=True,appendedBytes=len(phase_suffix),
 appendedSha256=sha(phase_suffix),phase='closed',sourceSchema9Required=True,
 exactlyTwoCampaignKeys=True,processPhaseMatchesFile=True)
secret=process_env.get(b'MIR2_STRIPE_SECRET_KEY',b'')
original=health(7110)
print(json.dumps(dict(readOnly=True,privateValuesReturned=False,test=test,unit=unit,files=files,binarySha256=binary_sha,binaryPath=str(binary.resolve()),
 tcp7200=len([line for line in run(['ss','-Htn','state','established','sport = :7200']).splitlines() if line.strip()]),
 original=dict(ok=original.get('ok'),revision=original.get('revision'),pids=re.findall(r'pid=(\d+)',run(['ss','-ltnpH','sport = :7110']))),
 processStripeTestKey=secret.startswith((b'sk_test_',b'rk_test_')),processStripeLiveKey=secret.startswith((b'sk_live_',b'rk_live_')),
 processStripeEnabled=process_env.get(b'MIR2_STRIPE_ENABLED')==b'1',processMonthlyPriceIs1000=process_env.get(b'MIR2_MONTHLY_CARD_CREDIT_PRICE')==b'1000',
 processAccountStorePostgres=process_env.get(b'MIR2_ACCOUNT_STORE_BACKEND')==b'postgres',phaseProof=phase_proof,changedCurrentFileKeysComparedToProcess=changed_from_process,
 nonbillingChangedComparedToOriginalSnapshot=nonbilling_changed,backupFiles=backup_files,originalEnvSnapshots=snapshot_envs),sort_keys=True))
PY
