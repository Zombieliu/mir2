sudo -n /usr/bin/python3 - <<'PY'
import hashlib,json,pathlib,re,subprocess,urllib.request
def run(args):
    return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15).stdout.decode()
def health(port):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open('http://127.0.0.1:%d/health'%port,timeout=5) as r:
        return json.load(r)
test=health(7210)
original=health(7110)
unit=run(['systemctl','show','mir2-playtest.service','-p','MainPID','-p','Result','-p','ExecMainStatus','-p','NRestarts','-p','DropInPaths'])
count=len([x for x in run(['ss','-Htn','state','established','sport = :7200']).splitlines() if x.strip()])
files={}
for name in ('/etc/mir2-playtest/gateway.env','/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf','/etc/systemd/system/mir2-playtest.service.d/90-spectator-watch.conf','/etc/systemd/system/mir2-playtest.service'):
    p=pathlib.Path(name)
    assert p.is_file() and not p.is_symlink()
    data=p.read_bytes()
    files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
release=pathlib.Path('/opt/mir2-playtest/releases')/test['revision']
meta=json.loads((release/'RELEASE.json').read_text())
binary=release/'mir2-gateway'
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest==meta['binarySha256'] and binary.stat().st_size==meta['binarySizeBytes']
pid=re.search(r'^MainPID=(\d+)$',unit,re.M).group(1)
held=pathlib.Path('/proc/'+pid+'/exe')
assert held.resolve()==binary and hashlib.sha256(held.read_bytes()).hexdigest()==digest
process_env=dict(entry.split(b'=',1) for entry in pathlib.Path('/proc/'+pid+'/environ').read_bytes().split(b'\0') if b'=' in entry)
rpc_keys=(b'MIR2_ZONE_HOST_ADDR',b'MIR2_ZONE_HOST_ADDRS',b'MIR2_ZONE_HOST_ACTIVE_ADDRS',b'MIR2_ZONE_HOST_STANDBY_ADDRS')
remote_zone_configured=any(bool(process_env.get(key)) for key in rpc_keys)
original_pids=re.findall(r'pid=(\d+)',run(['ss','-ltnpH','sport = :7110']))
import stat
def protected_file(name, expected, limit, private=False):
    p=pathlib.Path(name);info=p.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_uid==0 and info.st_nlink==1 and info.st_size<=limit and not info.st_mode & 0o022
    assert not private or not info.st_mode & 0o077
    contents=p.read_bytes();assert hashlib.sha256(contents).hexdigest()==expected
    return contents
new_env=protected_file('/etc/mir2-playtest/gateway.env','cbc3a385c14e016c76bb6e55512582bf89324cece4d4a3b4bcdeb94b0c540378',65536,True)
old_env=protected_file('/var/backups/mir2-playtest-stripe-test-20261011-01/gateway.env.before','77f12d974ca32103673181669803c89283c68cf34a952c0a177b721c1d013729',65536,True)
billing_keys={b'MIR2_STRIPE_ENABLED',b'MIR2_STRIPE_SECRET_KEY',b'MIR2_STRIPE_WEBHOOK_SECRET',b'MIR2_BILLING_PUBLIC_BASE_URL',b'MIR2_STRIPE_ALLOW_LOOPBACK_TEST_RETURN',b'MIR2_STRIPE_RECHARGE_OFFERS'}
def nonbilling(data):
    return b''.join(line for line in data.splitlines(keepends=True) if line.partition(b'=')[0] not in billing_keys)
post_snapshot=protected_file('/var/backups/mir2-playtest-before-8fee37c1afd154b18ceffe53b1fc4dd02b6f38a2/gateway.env','41d0939baa6f164a5db0605ef441647c4c8214a6b4ac1dd7c69ab1da65c647c0',65536,True)
assert new_env.startswith(post_snapshot)
phase_suffix=new_env[len(post_snapshot):]
assert len(phase_suffix)==125 and hashlib.sha256(phase_suffix).hexdigest()=='d5d2f5109e0f15018ee5e93606a43cdd1a1529c33b41cf4995d276108840e2eb'
phase_fields=dict(line.split(b'=',1) for line in phase_suffix.splitlines() if line and not line.startswith(b'#') and b'=' in line)
assert set(phase_fields)=={b'MIR2_ACTIVITY_PHASE',b'MIR2_ACTIVITY_PHASE_START_MS'}
assert phase_fields[b'MIR2_ACTIVITY_PHASE']==b'closed' and phase_fields[b'MIR2_ACTIVITY_PHASE_START_MS'].isdigit()
assert all(process_env.get(key)==value for key,value in phase_fields.items())
assert nonbilling(post_snapshot)==nonbilling(old_env)
assert process_env.get(b'MIR2_DEPLOY_REVISION')==b'bad3737f265b0547d838382c2bb3592caa5dcb31'
assert pid=='3457815' and process_env.get(b'MIR2_STRIPE_ENABLED')==b'1'
assert process_env.get(b'MIR2_STRIPE_SECRET_KEY',b'').startswith((b'sk_test_',b'rk_test_'))
assert process_env.get(b'MIR2_ACCOUNT_STORE_BACKEND')==b'postgres'
assert process_env.get(b'MIR2_MONTHLY_CARD_CREDIT_PRICE')==b'1000'
assert process_env.get(b'MIR2_MONTHLY_CARD_REQUIRED',b'0') in (b'0',b'false')
protected_file('/etc/caddy/Caddyfile','b19f0c1911042fafe37fd0adc6e396a45c8b98f2f195d81b6969644cd061ad8a',131072)
protected_file('/srv/mir2-client-updates/feed-current/latest.json','a08a45735bffc7d6f1eaff9eb4edf4c210e1a27b278d7cb411f4afc20f141a9d',32768)
protected_file('/srv/mir2-client-updates/feed-current/latest.p7s','0f88d31feb50b69970e43108a65245ef899eb7b72133d4ced04c342408acd9d3',32768)
assert test['revision']=='bad3737f265b0547d838382c2bb3592caa5dcb31'
assert digest=='445e74acc5c6b202250331849eac2e08a93faf1b1c5554f52b1ef128b39d4f98'
assert test['ok'] is True
assert all(isinstance(test['capacity'][key],int) and test['capacity'][key]>=0 for key in ('currentActiveSessions','currentWsConnections','currentReconnectLeases','currentLoginInFlight','currentNewCharacterInFlight','currentStartGameInFlight'))
assert not remote_zone_configured and original_pids==['3855184']
print(json.dumps({'ok':True,'test':test,'unit':dict(line.split('=',1) for line in unit.splitlines()),'tcp7200':count,'files':files,'remoteZoneConfigured':remote_zone_configured,'binarySha256':digest,'binaryBytes':binary.stat().st_size,'original':{'ok':original.get('ok'),'revision':original.get('revision'),'pids':original_pids,'release':str(pathlib.Path('/opt/mir2/gateway/current').resolve())}},sort_keys=True))
PY
