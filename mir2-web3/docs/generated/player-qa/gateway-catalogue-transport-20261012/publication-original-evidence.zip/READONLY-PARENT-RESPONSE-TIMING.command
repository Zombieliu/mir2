sudo -n /usr/bin/python3 - <<'PY'
import json,re,subprocess
raw=subprocess.run(['journalctl','-u','mir2-playtest.service','--since','2026-10-11 23:23:30 UTC','--until','2026-10-11 23:25:30 UTC','-o','cat','--no-pager'],check=True,capture_output=True,timeout=15).stdout.decode(errors='replace')
measurements=[]
for line in raw.splitlines():
 m=re.search(r'\[gateway-slow-stage\] stage=([a-z._]+) duration_ms=(\d+)',line)
 if m: measurements.append(dict(stage=m[1],durationMs=int(m[2])))
print(json.dumps(dict(journalWindowStart='2026-10-11T23:23:30Z',journalWindowEnd='2026-10-11T23:25:30Z',measurements=measurements,serverChanged=False,packetBodiesRecorded=False)))
PY
