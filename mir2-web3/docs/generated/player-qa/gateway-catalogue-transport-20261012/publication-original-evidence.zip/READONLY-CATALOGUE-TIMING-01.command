sudo -n /usr/bin/python3 - <<'PY'
import json,subprocess,urllib.request
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
with opener.open('http://127.0.0.1:7210/health',timeout=5) as response: health=json.load(response)
assert health['revision']=='28f117dc736f84712b35f217223ac9e316cba906'
raw=subprocess.run(['journalctl','_PID=3435214','--since','2026-10-12 02:20:00 UTC','--until','2026-10-12 02:30:00 UTC','--no-pager','-o','cat'],check=True,capture_output=True,timeout=20).stdout.decode()
for line in raw.splitlines():
    if line.startswith('[gateway-response-write]'):
        print(line)
    elif line.startswith('[gateway-slow]') and any(stage in line for stage in ('session_action.flush','shared_session.inner_execute','shared_session.owner.execute','session_action.execute','snapshot.build_and_send')):
        print(line)
PY
