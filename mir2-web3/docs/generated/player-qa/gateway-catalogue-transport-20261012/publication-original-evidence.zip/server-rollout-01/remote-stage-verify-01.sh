/usr/bin/python3 - <<'PY'
STAGE='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-28f117dc736f84712b35f217223ac9e316cba906'
REVISION='28f117dc736f84712b35f217223ac9e316cba906'
PINS={'gateway-package.tar.gz': {'size': 35032643, 'sha256': 'a5659f8840bf4e7cdb7b138773e8abad813819eb8c4cc471e13f3b67b2ca808b'}, 'VERIFIED-FILES.json': {'size': 412, 'sha256': '5e9a19b1c3b6be1bc39a9bb96a8f0b93e01929508e2943ceb33922798b036fa5'}, 'upgrade-catalogue-01.py': {'size': 31710, 'sha256': '3f16582db9b3e08983bc22497a23dab15802d95b3f5694b4badc2c6bfee2f482'}}
import hashlib,json,os,pathlib,stat,tarfile
p=pathlib.Path(STAGE)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
assert set(x.name for x in p.iterdir())==set(PINS)
for name,pin in PINS.items():
 f=p/name;info=f.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.geteuid()
 assert info.st_size==pin['size'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
manifest=json.loads((p/'VERIFIED-FILES.json').read_text())
assert manifest['revision']==REVISION
expected={row['path']:row for row in manifest['files']}
assert set(expected)=={'mir2-gateway','RELEASE.json'}
seen=set()
with tarfile.open(p/'gateway-package.tar.gz','r:gz') as packed:
 for item in packed.getmembers():
  assert item.isfile() and item.name in {'mir2-gateway','zone_host','RELEASE.json','README.txt'}
  assert item.name not in seen and 0<item.size<=268435456
  seen.add(item.name)
  if item.name not in expected: continue
  data=packed.extractfile(item).read();entry=expected[item.name]
  assert len(data)==entry['size'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  fd=os.open(p/item.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,entry['mode'])
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.chmod(p/item.name,entry['mode'])
assert seen=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
print(json.dumps({'artifactStageVerified':True,'revision':REVISION,'publicServiceChanged':False}))
PY
