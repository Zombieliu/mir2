param([Parameter(Mandatory=$true)][ValidatePattern('^[0-9]{2}$')][string]$Run,
    [Parameter(Mandatory=$true)][ValidateSet('native-full','gateway-adjacent')][string]$Suite,
    [Parameter(Mandatory=$true)][ValidatePattern('^[0-9]{2}$')][string]$BuildRun,
    [string]$NativeAudioRoot)
$ErrorActionPreference='Stop'
$taskProject=Join-Path $PSScriptRoot 'gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p1-target-lifecycle-20261009-01'
$taskBuildSuite=if ($Suite -eq 'native-full') { 'native-focused' } else { 'gateway-bridge-build' }
$taskReceipt=Get-Content -LiteralPath (Join-Path $taskEvidence "$BuildRun-$taskBuildSuite.log.json") -Raw | ConvertFrom-Json
if ($taskReceipt.exitCode -ne 0) { throw 'Compiled source did not pass its gate' }
$taskPattern=if ($Suite -eq 'native-full') { 'Running unittests[^\r\n]*\(([^\r\n]+mir2_platform_windows-[a-f0-9]+\.exe)\)' } else { 'Executable unittests[^\r\n]*\(([^\r\n]+mir2_gateway-[a-f0-9]+\.exe)\)' }
$taskMatch=[regex]::Match((Get-Content -LiteralPath $taskReceipt.log -Raw), $taskPattern)
if (!$taskMatch.Success) { throw 'Exact built test artifact missing' }
$taskExe=[IO.Path]::GetFullPath($taskMatch.Groups[1].Value)
if (!$taskExe.StartsWith([IO.Path]::GetFullPath($taskReceipt.target), [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected test executable' }
Set-Location -LiteralPath $taskProject
foreach ($taskSource in $taskReceipt.sourceSha256.PSObject.Properties) {
    if ($Suite -eq 'native-full' -or !$taskSource.Name.StartsWith('apps/game-client/')) {
        if ((Get-FileHash -LiteralPath $taskSource.Name -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskSource.Value) { throw "Changed source: $($taskSource.Name)" }
    }
}
$taskLog=Join-Path $taskEvidence "$Run-$Suite-artifact.log"
if (Test-Path -LiteralPath $taskLog) { throw 'Prior evidence exists' }
$taskArgs=@('--test-threads=1')
if ($Suite -eq 'gateway-adjacent') { $taskArgs += @('unavailable_combat_target','owner_location_order','owner_attack_animation','movement_deadline','crowded_escape_tests') }
$taskAudioReceipt=$null
if ($NativeAudioRoot) {
    if ($Suite -ne 'native-full') { throw 'Audio fixture is only supported for the native artifact suite' }
    $taskAudioRoot=(Resolve-Path -LiteralPath $NativeAudioRoot).Path
    $taskAudioFile=Join-Path $taskAudioRoot '91.wav'
    $taskAudioHash=(Get-FileHash -LiteralPath $taskAudioFile -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskAudioHash -ne 'ebcb5e32521cdf7256c334be1951064edd21e080264823b327bc6803acdd38f1') { throw 'Original SoundList 10091 hash mismatch' }
    $env:MIR2_NATIVE_AUDIO_ROOT=$taskAudioRoot
    $taskAudioReceipt=[ordered]@{environmentVariable='MIR2_NATIVE_AUDIO_ROOT';root=$taskAudioRoot;file=$taskAudioFile;bytes=(Get-Item -LiteralPath $taskAudioFile).Length;sha256=$taskAudioHash}
}
$taskStarted=[DateTime]::UtcNow.ToString('o')
& $taskExe @taskArgs *> $taskLog
$taskExit=$LASTEXITCODE
[ordered]@{suite=$Suite;run=$Run;startedUtc=$taskStarted;completedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;
    sourceSha256=$taskReceipt.sourceSha256;buildReceipt="$BuildRun-$taskBuildSuite.log.json";
    executable=$taskExe;executableSha256=(Get-FileHash -LiteralPath $taskExe -Algorithm SHA256).Hash.ToLowerInvariant();arguments=$taskArgs;
    audioFixture=$taskAudioReceipt;log=$taskLog;logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskLog.json" -Encoding utf8
Get-Content -LiteralPath $taskLog -Tail 12
exit $taskExit
