param([Parameter(Mandatory=$true)][ValidatePattern('^[0-9]{2}$')][string]$Run,
    [ValidatePattern('^[0-9]{2}$')][string]$NativeRun='19',
    [ValidatePattern('^[0-9]{2}$')][string]$GatewayRun='15',
    [ValidateSet('native-adjacent','native-focused')][string]$NativeSuite='native-adjacent')
$ErrorActionPreference='Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'PowerShell 7 required' }
$taskProject=Join-Path $PSScriptRoot 'gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p1-target-lifecycle-20261009-01'
function Read-VerifiedTestExe($receipt, $pattern) {
    if ($receipt.exitCode -ne 0) { throw 'Build or adjacent checks failed' }
    $taskMatch=[regex]::Match([IO.File]::ReadAllText($receipt.log), $pattern)
    if (!$taskMatch.Success) { throw 'No exact compiled executable in build log' }
    $taskPath=[IO.Path]::GetFullPath($taskMatch.Groups[1].Value)
    if (!$taskPath.StartsWith([IO.Path]::GetFullPath($receipt.target), [StringComparison]::OrdinalIgnoreCase)) { throw 'Unexpected test executable' }
    return $taskPath
}
$taskNativeReceipt=Get-Content -LiteralPath (Join-Path $taskEvidence "$NativeRun-$NativeSuite.log.json") -Raw | ConvertFrom-Json
$taskGatewayReceipt=Get-Content -LiteralPath (Join-Path $taskEvidence "$GatewayRun-gateway-bridge-build.log.json") -Raw | ConvertFrom-Json
$taskNative=Read-VerifiedTestExe $taskNativeReceipt 'Running unittests[^\r\n]*\(([^\r\n]+mir2_platform_windows-[a-f0-9]+\.exe)\)'
$taskGateway=Read-VerifiedTestExe $taskGatewayReceipt 'Executable unittests[^\r\n]*\(([^\r\n]+mir2_gateway-[a-f0-9]+\.exe)\)'
$taskOutput="C:/mir2-playtest-releases/20261009-p1-target-lifecycle-network-$Run"
$taskLog=Join-Path $taskEvidence "$Run-native-gateway-network.log"
if ((Test-Path -LiteralPath $taskOutput) -or (Test-Path -LiteralPath $taskLog)) { throw 'Refusing to overwrite previous evidence' }
Set-Location -LiteralPath $taskProject
$taskSources=$taskNativeReceipt.sourceSha256
foreach ($taskSource in $taskSources.PSObject.Properties) {
    if ((Get-FileHash -LiteralPath $taskSource.Name -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskSource.Value) { throw "Source changed: $($taskSource.Name)" }
}
foreach ($taskSource in $taskGatewayReceipt.sourceSha256.PSObject.Properties) {
    if ($taskSource.Name.StartsWith('apps/gateway/') -or $taskSource.Name.StartsWith('apps/simulation/')) {
        if ((Get-FileHash -LiteralPath $taskSource.Name -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskSource.Value) { throw "Gateway source changed: $($taskSource.Name)" }
    }
}
$env:MIR2_TARGET_NATIVE_TEST_EXE=$taskNative
$env:MIR2_TARGET_OWNED_OUTPUT=$taskOutput
$taskArgs=@('--exact','routing::tests::native_target_lifecycle_transport_tests::native_target_lifecycle_real_gateway_three_class_cohort','--ignored','--nocapture','--test-threads=1')
$taskStarted=[DateTime]::UtcNow.ToString('o')
$taskNativeHash=(Get-FileHash -LiteralPath $taskNative -Algorithm SHA256).Hash.ToLowerInvariant()
$taskGatewayHash=(Get-FileHash -LiteralPath $taskGateway -Algorithm SHA256).Hash.ToLowerInvariant()
& $taskGateway @taskArgs *> $taskLog
$taskExit=$LASTEXITCODE
[ordered]@{run=$Run;startedUtc=$taskStarted;completedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;
    sourceSha256=$taskSources;nativeTestExe=$taskNative;nativeExeSha256=$taskNativeHash;gatewayTestExe=$taskGateway;
    gatewayExeSha256=$taskGatewayHash;arguments=$taskArgs;ownedOutput=$taskOutput;
    log=$taskLog;logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant();
    rendererStarted=$false;humanAcceptance=$false} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskLog.json" -Encoding utf8
Get-Content -LiteralPath $taskLog -Tail 18
exit $taskExit
