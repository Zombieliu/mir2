param([Parameter(Mandatory=$true)][ValidatePattern('^[0-9]{2}$')][string]$Run)
$ErrorActionPreference='Stop'
$taskProject=Join-Path $PSScriptRoot 'gateway-lifecycle-baseline-20261008-01/mir2-web3'
$taskEvidence='C:/mir2-build/p1-target-lifecycle-20261009-01'
$taskLog=Join-Path $taskEvidence "$Run-zone-baseline.log"
if (Test-Path -LiteralPath $taskLog) { throw 'Prior evidence exists' }
$env:CARGO_TARGET_DIR='C:/mir2-build/p1-gateway-lifecycle-target-20261009-01'
Set-Location -LiteralPath $taskProject
$taskSources=@('apps/simulation/tests/shared_zone.rs','apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/movement_deadline_tests.rs','Cargo.lock')
$taskHashes=@{}
foreach ($taskFile in $taskSources) { $taskHashes[$taskFile]=(Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant() }
$taskArgs=@('+1.95.0','test','--locked','--offline','--jobs','2','--config','profile.test.package.mir2-simulation.codegen-units=147','-p','mir2-simulation','--test','shared_zone','--','--test-threads=1')
$taskStarted=[DateTime]::UtcNow.ToString('o')
& cargo @taskArgs *> $taskLog
$taskExit=$LASTEXITCODE
[ordered]@{suite='zone-baseline';run=$Run;startedUtc=$taskStarted;completedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;
    sourceSha256=$taskHashes;project=$taskProject;arguments=$taskArgs;log=$taskLog;
    logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()} |
    ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskLog.json" -Encoding utf8
Get-Content -LiteralPath $taskLog -Tail 16
exit $taskExit
