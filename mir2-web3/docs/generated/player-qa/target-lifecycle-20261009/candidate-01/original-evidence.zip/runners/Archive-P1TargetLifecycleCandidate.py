import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

task = Path(__file__).resolve().parent
lane = task / 'gateway-lifecycle-20261008-01'
project = lane / 'mir2-web3'
raw_root = Path('C:/mir2-build/p1-target-lifecycle-20261009-01')
out = project / 'docs/generated/player-qa/target-lifecycle-20261009/candidate-01'
base = '88a36e7a2f79b54163fc3849fb48d00d498d4cda'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.run(['git', '-c', f'safe.directory={lane.as_posix()}',
        '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', *args], cwd=lane,
        capture_output=True, check=True).stdout

def new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)

assert git('rev-parse', 'HEAD').decode().strip() == base
assert not out.exists(), 'Original evidence is immutable'
changed = git('diff', '--name-only', '--', '.github', 'mir2-web3/apps').decode().splitlines()
new_sources = git('ls-files', '--others', '--exclude-standard', '--', 'mir2-web3/apps').decode().splitlines()
asset = 'mir2-web3/apps/web/public/original-ui/Sound/91.wav'
source_files = sorted(set(changed + new_sources + [asset]))
assert len(source_files) == 12, source_files
records = {}
for name in ['31-native-full-artifact.log.json', '29-gateway-adjacent-artifact.log.json',
             '27-native-focused.log.json', '07-native-gateway-network.log.json',
             '32-shell-and-native-format.log.json']:
    record = json.loads((raw_root / name).read_text(encoding='utf-8-sig'))
    assert record.get('exitCode', record.get('nodeExit')) == 0
    assert record.get('formatExit', 0) == 0
    data = Path(record['log']).read_bytes()
    assert digest(data) == record['logSha256']
    for path, sha in record.get('sourceSha256', {}).items():
        if name.startswith('29-') and path.startswith('apps/game-client/'):
            continue
        assert digest((project / path).read_bytes()) == sha, (name, path)
    records[name] = record

assert b'test result: ok. 900 passed; 0 failed; 7 ignored;' in Path(records['31-native-full-artifact.log.json']['log']).read_bytes()
assert b'test result: ok. 21 passed; 0 failed;' in Path(records['29-gateway-adjacent-artifact.log.json']['log']).read_bytes()
assert b'test result: ok. 5 passed; 0 failed;' in Path(records['27-native-focused.log.json']['log']).read_bytes()
assert digest((lane / asset).read_bytes()) == 'ebcb5e32521cdf7256c334be1951064edd21e080264823b327bc6803acdd38f1'

entries = {}
for path in sorted(raw_root.iterdir()):
    if path.is_file():
        entries['raw/' + path.name] = path.read_bytes()
allowed = {'cohort.json', 'attack-ack.json', 'gateway-checks.json', 'native-report.json',
           'native-stderr.log', 'native-stdout.log', 'wire-trace.json'}
for run in [1, 2, 3, 4, 5, 7]:
    network = Path(f'C:/mir2-playtest-releases/20261009-p1-target-lifecycle-network-{run:02d}')
    assert network.is_dir()
    for path in sorted(network.rglob('*')):
        if path.is_file() and path.name in allowed and not any('private' in part for part in path.relative_to(network).parts):
            entries[f'network-{run:02d}/' + path.relative_to(network).as_posix()] = path.read_bytes()
for class_name in ['Warrior', 'Wizard', 'Taoist']:
    root = Path('C:/mir2-playtest-releases/20261009-p1-target-lifecycle-network-07') / class_name
    report = json.loads((root / 'native-report.json').read_text())
    checks = json.loads((root / 'gateway-checks.json').read_text())
    assert report['status'] == 'passed' and report['normalLogoutAcknowledged']
    assert report['realGatewayAndNativeClient'] and not report['rendererStarted'] and not report['humanAcceptance']
    assert report['rejectedAckMs'] <= 5000 and report['quiet5Seconds']
    assert report['guard399MsPreserved'] and report['welcomeNoticeDismissedThroughOkModel']
    for name in ['causalAttackCorrection', 'nativeLogoutAck', 'nativePassed',
                 'normalLogoutWireAck', 'oldMovementNeverWritten', 'sharedZoneDrained']:
        assert checks[name] is True, (name, checks)
    assert checks['rendererStarted'] is False and checks['humanAcceptance'] is False
entries['network-06/PREFLIGHT-NO-EXECUTION.txt'] = (
    'Attempt06 was invoked before required build receipt25 existed. Its preflight refused; '
    'no output directory, network test, or gameplay acceptance was produced. It is excluded.\n').encode()
for name in ['Run-P1TargetLifecycleChecks.ps1', 'Run-P1ZoneBaseline.ps1',
             'Run-P1NativeGatewayBridge.ps1', 'Run-P1CompiledArtifactChecks.ps1']:
    entries['runners/' + name] = (task / name).read_bytes()
entries['runners/Archive-P1TargetLifecycleCandidate.py'] = Path(__file__).read_bytes()
entries['source/tracked.patch'] = git('diff', '--binary', '--', '.github', 'mir2-web3/apps')
for name in source_files:
    entries['source/current/' + name] = (lane / name).read_bytes()
entries['assets/91-wav-provenance.json'] = (json.dumps({
    'source': 'Crystal/Build/Client/Debug/Sound/91.wav', 'soundList': 10091,
    'bytes': 164642, 'sha256': digest((lane / asset).read_bytes()),
    'r22PackagedFileMatchesOriginal': True, 'newFileIsOriginalBytes': True,
    'generatedReplacement': False}, indent=2) + '\n').encode()
out.mkdir(parents=True)
archive = out / 'original-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(entries.items()):
        bundle.writestr(name, data)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name, data in entries.items():
        assert bundle.read(name) == data
proof = {
    'schema': 'mir2.classic.target-lifecycle-candidate.v1',
    'createdUtc': datetime.now(timezone.utc).isoformat(), 'sourceBase': base,
    'sourceFiles': [{'file': name, 'bytes': len((lane / name).read_bytes()),
                     'sha256': digest((lane / name).read_bytes())} for name in source_files],
    'currentLocalGates': records,
    'native': {'passed': 900, 'failed': 0, 'ignored': 7, 'rendererStarted': False, 'humanAcceptance': False},
    'realNativeGatewayCohort': {'classes': ['Warrior', 'Wizard', 'Taoist'], 'rejectedAckMs': [68, 68, 71],
        'normalLogouts': 3, 'realSocketPackets': True, 'pendingMoveWasProducedNormally': True,
        'noSyntheticAck': True, 'noticeClosedThroughOrdinaryOkModel': True, 'guiClickClaimed': False},
    'zoneBroadGate': {'currentPassed': 198, 'currentFailed': 11, 'clean7feaPassed': 198,
        'clean7feaFailed': 11, 'baselineFullyGreen': False, 'audit': 'CLASSIC-ZONE-BASELINE-AUDIT-20261009.md'},
    'publishedByThisSlice': False, 'humanAccepted': False, 'fullGoalComplete': False,
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()),
        'entries': [{'file': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(entries.items())]},
    'limits': ['Headless loopback real native/Gateway lifecycle, not GPU/native-human or public production acceptance.',
        'Unknown-target network story plus bounded dead/removed Direct/Live/LiveFull server matrix; not full seven-monster pressure.',
        'Source clocks, cooldowns, damage and collision guards are unchanged.',
        'Failed runs, fixture clock OOM and missing source clip attempt are retained and excluded from passing results.',
        'Public last verified pair remains R22/feed17/Gateway536 until separate exact-source CI and paired rollout.',
        'P4 Totem owner chain, P7 ordered shared-world outbox and natural P2/P3/P5/P6/Mentor acceptance remain open.']}
new(out / 'CANDIDATE.json', (json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode())
new(out / 'README.md', b'''# Target lifecycle Candidate evidence\n\nCurrent local qualification: native900/0/7ignored, Gateway21, focused native5. Actual separately compiled native/Gateway loopback tests pass for Warrior/Wizard/Taoist with real owner corrections in68/68/71ms, ordinary pending movement, original399+1ms correction guard, fresh movement,5s quiet, three normal logouts and drained owners. No synthetic correction or rendered/human acceptance.\n\nCANDIDATE.json binds current file hashes, full original logs, all failed/intermediate attempts, package clip provenance, executable hashes and runner commands. The source and R22 packaged SoundList10091 clip both match164642 bytes and SHA256ebcb5e32521cdf7256c334be1951064edd21e080264823b327bc6803acdd38f1. Final31 uses the newly tracked original clip and no developer audio root.\n\nRun16 broad Zone is198pass/11fail, exactly reproduced on clean7fea in17; existing failures stay open. Runs18/22 are failed cache/format gates later fixed. Run25 passed but its new fixture used a zero epoch with the Unix-clock presentation path and took190s;26 aborts on64GiB allocation. Production bridge already uses native Unix motion clock. Only the new test fixture clock is corrected in27; no production timing/cooldown/damage change. Run28 is899pass/1fail because clean source omitted original91.wav;30 verifies genuine R22 clip through an explicit root;31 passes900 with the original clip now tracked and packaged.\n\nNetwork01 refuses weak fixture MAC,02 times out cold bootstrap setup,03/04 fail to prove ordinary pending movement,05 proves the real welcome notice blocks input. Final07 closes the notice through its normal OK model, uses20s cold-bootstrap setup while retaining5s action limits and all original399+1ms/quiet assertions. Network06 ran no test because its build receipt preflight failed. Original accounts/recovery stores and credential payloads are excluded; whitelist traces retain complete sanitized events.\n\nThis is not a Linux/Windows release CI, production cutover, dense seven-monster/native-human or completeP1-P7/Mentor receipt.\n''')
print(json.dumps({'out': str(out), 'sourceFiles': len(source_files), 'archiveBytes': archive.stat().st_size,
                  'archiveSha256': proof['archive']['sha256'], 'entries': len(entries)}))
