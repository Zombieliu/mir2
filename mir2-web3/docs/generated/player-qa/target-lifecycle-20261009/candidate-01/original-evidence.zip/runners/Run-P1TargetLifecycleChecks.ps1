param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('gateway-focused','native-focused','gateway-adjacent','native-adjacent','zone-focused','zone-adjacent','gateway-build','gateway-bridge-build')]
    [string]$Suite,
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^[0-9]{2}$')]
    [string]$Run
)
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSVersion.Major -lt 7) { throw 'Use PowerShell 7 to preserve native command output' }
$taskProject = Join-Path $PSScriptRoot 'gateway-lifecycle-20261008-01/mir2-web3'
$taskEvidence = 'C:/mir2-build/p1-target-lifecycle-20261009-01'
$taskTarget = if ($Suite.StartsWith('native-')) { 'C:/mir2-build/p1-native-20261007' } else { 'C:/mir2-build/p1-gateway-lifecycle-target-20261009-01' }
[IO.Directory]::CreateDirectory($taskEvidence) | Out-Null
$taskLog = Join-Path $taskEvidence "$Run-$Suite.log"
if (Test-Path -LiteralPath $taskLog) { throw 'Refusing to overwrite prior evidence' }
$taskDrive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($taskTarget))
if ($taskDrive.AvailableFreeSpace -lt 50GB) { throw 'Insufficient build-volume reserve' }
$taskFreeBefore = $taskDrive.AvailableFreeSpace
$env:CARGO_TARGET_DIR = $taskTarget
Set-Location -LiteralPath $taskProject
$taskArgs = @('+1.95.0','test','--locked','--offline','--jobs','2')
if ($Suite.StartsWith('native-')) {
    $taskArgs += @('--config', 'profile.test.package.mir2-platform-windows.debug="line-tables-only"')
    $taskArgs += @('--config', "profile.test.package.mir2-platform-windows.codegen-units=$(150 + [int]$Run)")
}
if (!$Suite.StartsWith('native-') -and $Suite -ne 'zone-focused' -and $Suite -ne 'zone-adjacent' -and $Suite -ne 'gateway-build') {
    # Give this owned test round a distinct artifact without touching the
    # locked executable, another application, gameplay rules, or the source.
    $taskArgs += @('--config', 'profile.test.package.mir2-gateway.debug="line-tables-only"')
    $taskArgs += @('--config', "profile.test.package.mir2-gateway.codegen-units=$(150 + [int]$Run)")
}
switch ($Suite) {
    'gateway-focused' { $taskArgs += @('-p','mir2-gateway','--lib','unavailable_combat_target','--','--test-threads=1') }
    'native-focused' { $taskArgs += @('--manifest-path','apps/game-client/platform-windows/Cargo.toml','--bin','mir2-platform-windows','selected_monster_','--','--test-threads=1','--nocapture') }
    'gateway-adjacent' { $taskArgs += @('-p','mir2-gateway','--lib','--','--test-threads=1','unavailable_combat_target','owner_location_order','owner_attack_animation','movement_deadline','crowded_escape_tests','mining_','reincarnation') }
    'native-adjacent' { $taskArgs += @('--manifest-path','apps/game-client/platform-windows/Cargo.toml','--bin','mir2-platform-windows','--','--test-threads=1','input::tests::','gateway::movement_barrier_tests::','entity_presentation::tests::') }
    'zone-focused' { $taskArgs += @('-p','mir2-simulation','--lib','movement_deadline_tests','--','--test-threads=1') }
    'zone-adjacent' { $taskArgs += @('-p','mir2-simulation','--test','shared_zone','--','--test-threads=1') }
    'gateway-build' { $taskArgs = @('+1.95.0','build','--locked','--offline','--jobs','2','-p','mir2-gateway','--bin','mir2-gateway') }
    'gateway-bridge-build' { $taskArgs += @('-p','mir2-gateway','--lib','--no-run') }
}
$taskSources = @('apps/game-client/platform-windows/src/input.rs','apps/game-client/platform-windows/src/entity_presentation.rs','apps/game-client/platform-windows/src/gateway.rs','apps/game-client/platform-windows/src/gateway_target_lifecycle_network_tests.rs','apps/gateway/src/routing.rs','apps/gateway/src/routing/tests/unavailable_combat_target_tests.rs','apps/gateway/src/routing/tests/native_target_lifecycle_transport_tests.rs','apps/simulation/src/runtime/zone/runtime.rs','apps/simulation/src/runtime/zone/movement_deadline_tests.rs')
$taskSourceHashes = @{}
foreach ($taskFile in $taskSources) { $taskSourceHashes[$taskFile] = (Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant() }
$taskStarted = [DateTime]::UtcNow.ToString('o')
& cargo @taskArgs *> $taskLog
$taskExit = $LASTEXITCODE
$taskRecord = [ordered]@{
    suite=$Suite; run=$Run; startedUtc=$taskStarted; completedUtc=[DateTime]::UtcNow.ToString('o'); exitCode=$taskExit;
    executable='cargo'; arguments=$taskArgs; project=$taskProject; target=$taskTarget;
    sourceSha256=$taskSourceHashes; freeBytesBefore=$taskFreeBefore; freeBytesAfter=$taskDrive.AvailableFreeSpace;
    log=$taskLog; logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
}
$taskRecord | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskLog.json" -Encoding utf8
Get-Content -LiteralPath $taskLog -Tail 20 | Where-Object { $_ -notmatch '^  = note: "' }
exit $taskExit
