import hashlib
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parent / 'gateway-lifecycle-release-01'
source = root / 'native-resume-public-01/native-resume-smoke.mjs'
out = root / 'native-resume-public-02'
original = source.read_bytes()
assert hashlib.sha256(original).hexdigest() == '4aa96984e4f62fcecba0fed1e8344e7ce8be9fe3b84ae9da4917ddff5c291e3b'
assert json.loads((source.parent / 'RESULT.json').read_text())['passed'] is False
assert not out.exists(), 'Preserve the original unsuccessful public attempt'
text = original.decode('utf-8')
old_root = "const root='" + source.parent.as_posix() + "';"
assert text.count(old_root) == 1
text = text.replace(old_root, "const root='" + out.as_posix() + "';")
old_error = "this.ws.addEventListener('error',()=>{this.error=Error('Verified public WSS failed');});"
new_error = """this.ws.addEventListener('error',event=>{
   const rawCode=event.error?.code;
   const code=typeof rawCode==='string'&&/^[A-Z0-9_]{1,64}$/.test(rawCode)?rawCode:null;
   const status=/Unexpected server response: (\\d{3})/.exec(event.message??'');
   const httpStatus=status?Number(status[1]):null;
   this.record('local',{type:'transportError',code,httpStatus});
   this.error=Error('Verified public WSS failed'+(code?' ['+code+']':httpStatus?' [HTTP '+httpStatus+']':''));
  });"""
assert text.count(old_error) == 1
text = text.replace(old_error, new_error)
assert text.replace(new_error, old_error).replace("const root='" + out.as_posix() + "';", old_root) == original.decode('utf-8')
out.mkdir()
script = out / source.name
with script.open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(text)
subprocess.run(['node', '--check', str(script)], check=True)
proof = {
    'schema': 'mir2.disconnect.public-resume-retry-preparation.v1',
    'sourceHarnessSha256': hashlib.sha256(original).hexdigest(),
    'preparedHarnessSha256': hashlib.sha256(script.read_bytes()).hexdigest(),
    'changes': ['New immutable output directory', 'Log only transport error code and HTTP status'],
    'unchangedAssertions': True,
    'cycles': 3,
    'checks': 18,
    'historicalFailurePreserved': True,
    'noFallbackLoginForResume': True,
}
with (out / 'PREPARATION.json').open('x') as stream:
    json.dump(proof, stream, indent=2)
    stream.write('\n')
print(json.dumps(proof))
