import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

task = Path(__file__).resolve().parent
root = task / 'gateway-lifecycle-release-01'
revision = '536b4a59f3a8af43f6d4484238e2847573dfb106'
ci = json.loads((root / 'linux-ci-01/CI-VERIFIED.json').read_text())
applied = json.loads((root / 'DEPLOYED-01.json').read_text())
ordinary = json.loads((root / 'ordinary-public-01/RESULT.json').read_text())
resume = json.loads((root / 'native-resume-public-02/RESULT.json').read_text())
historical = json.loads((root / 'native-resume-public-01/RESULT.json').read_text())
assert ci['revision'] == applied['revision'] == ordinary['sourceRevision'] == resume['sourceRevision'] == revision
assert ci['runConclusion'] == 'success' and applied['applied'] is True
assert ci['binarySha256'] == applied['binarySha256']
assert ordinary['passed'] and ordinary['tlsVerified'] and len(ordinary['rows']) == 44
assert len(ordinary['normalLogouts']) == 8 and all(row['confirmed'] for row in ordinary['normalLogouts'])
assert resume['passed'] and resume['tlsVerified'] and len(resume['checks']) == 18
assert all(row['status'] == 'passed' for row in resume['checks'])
assert sum(row['evidence'].get('normalLogouts', 0) for row in resume['checks']) == 6
assert historical['passed'] is False and len(historical['checks']) == 15
assert ordinary['adminCommands'] is False and resume['adminCommands'] is False
assert ordinary['qaStatePreparation'] is False and resume['qaStatePreparation'] is False
assert ordinary['newAccountRegistrations'] == resume['newAccountRegistrations'] == 0
assert ordinary['newCharacterCreations'] == resume['newCharacterCreations'] == 0
assert not (root / 'PUBLIC-VERIFIED-01.json').exists()

after_log = root / 'deploy-after-01.log'
with after_log.open('xb') as stream:
    command = ['python', 'C:/mir2-ui-repair-20260921/playtest-release-20260928/remote.py',
               '--user', 'ubuntu', '--command-file', str(task / 'gateway-lifecycle-read-public-01.sh'), '--timeout', '40']
    result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=100)
assert result.returncode == 0, 'Retained post-rollout read failed'
after = json.loads(next(line for line in after_log.read_text().splitlines() if line.startswith('{')))
before = json.loads(next(line for line in (root / 'deploy-before-03.log').read_text().splitlines() if line.startswith('{')))
assert after['ok'] and after['test']['ok'] and after['test']['revision'] == revision
assert after['binarySha256'] == ci['binarySha256']
assert after['original'] == before['original']
assert after['remoteZoneConfigured'] is False and after['tcp7200'] == 0
keys = ['currentWsConnections', 'currentActiveSessions', 'currentReconnectLeases',
        'currentLoginInFlight', 'currentNewCharacterInFlight', 'currentStartGameInFlight']
assert all(before['test']['capacity'][key] == 0 and after['test']['capacity'][key] == 0 for key in keys)
assert before['test']['spectator']['activeViewers'] == after['test']['spectator']['activeViewers'] == 0
for name, pin in before['files'].items():
    if name != applied['modifiedDropInPath']:
        assert after['files'][name] == pin, name
assert applied['candidateShutdownPanic'] is False
assert after['unit']['Result'] == 'success' and after['unit']['ExecMainStatus'] == '0'
assert after['unit']['NRestarts'] == '0' and after['unit']['MainPID'] == applied['pid']
proof = {
    'schema': 'mir2.gateway.disconnect-public-verification.v1',
    'createdUtc': datetime.now(timezone.utc).isoformat(),
    'revision': revision,
    'runId': ci['runId'],
    'ciUrl': ci['url'],
    'binarySha256': ci['binarySha256'],
    'ordinaryChecks': 44,
    'nativeResumeChecks': 18,
    'normalPublicChecks': 62,
    'normalLogoutAcknowledgements': 14,
    'resumeAcceptedAttempt': 'native-resume-public-02',
    'historicalResumeAttempt': {'directory': 'native-resume-public-01', 'passed': False,
        'completedChecks': 15, 'failure': historical['failure'], 'includedInPassCount': False},
    'retryChanges': ['Immutable output directory', 'Transport code/HTTP-status diagnostics only'],
    'originalRealmUnchanged': True,
    'clientReinstallRequired': False,
    'nativeUiAccepted': False,
    'fullQueuePressureTestedPublicly': False,
    'fullGoalComplete': False,
    'after': after,
}
with (root / 'PUBLIC-VERIFIED-01.json').open('x') as stream:
    json.dump(proof, stream, indent=2)
    stream.write('\n')
print(json.dumps({'passed': True, 'revision': revision, 'publicChecks': 62,
                  'normalLogoutAcknowledgements': 14, 'originalRealmUnchanged': True,
                  'clientReinstallRequired': False, 'fullGoalComplete': False}))
