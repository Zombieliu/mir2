from pathlib import Path
import hashlib,json

root=Path(__file__).resolve().parent
source=root/'gateway-lifecycle-release-01/ordinary-public-01/public-smoke.mjs'
body=root/'gateway-lifecycle-resume-body.mjs'
out=root/'gateway-lifecycle-release-01/native-resume-public-01'
assert not out.exists()
text=source.read_text(encoding='utf-8').split('const clients=[],rows=[],variants=new Set();',1)[0]
def change(old,new):
    global text
    assert text.count(old)==1,old
    text=text.replace(old,new)
change("const root='"+source.parent.as_posix()+"';","const root='"+out.as_posix()+"';")
change("'keepAlive','walk','logOut'", "'keepAlive','walk','turn','logOut','clientCapabilities','resumeSession'")
change('password|secret|token|authorization|cookie|pepper|private.?key',
       'password|secret|token|credential|authorization|cookie|pepper|private.?key')
change("this.record('received',value);if(value.packet==='UserInformation')", 
       "this.record('received',value);if(value.type==='resumeCredential')this.ticket=value;if(value.packet==='UserInformation')")
change("this.ws.addEventListener('error',", "this.ws.addEventListener('close',()=>{this.closed=true;});\n  this.ws.addEventListener('error',")
text+=body.read_text(encoding='utf-8')
out.mkdir()
script=out/'native-resume-smoke.mjs'
with script.open('x',encoding='utf-8',newline='\n') as stream:stream.write(text)
proof={'sourceHarnessSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
       'bodySha256':hashlib.sha256(body.read_bytes()).hexdigest(),
       'preparedHarnessSha256':hashlib.sha256(script.read_bytes()).hexdigest(),
       'cycles':3,'checks':18,'ordinaryOwnedActorOnly':True,'credentialsCopied':False,
       'actualSocketTermination':True,'newLoginCannotSubstituteForResume':True,
       'executedAgainstServer':False}
with (out/'PREPARATION.json').open('x') as stream:
    json.dump(proof,stream,indent=2);stream.write('\n')
print(json.dumps(proof))
