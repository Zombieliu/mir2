import hashlib,json,py_compile
from pathlib import Path

root=Path(__file__).resolve().parent/'gateway-lifecycle-release-01'
before=json.loads(next(line for line in (root/'deploy-before-01.log').read_text().splitlines() if line.startswith('{')))
watch=before['files']['/etc/systemd/system/mir2-playtest.service.d/90-spectator-watch.conf']
assert watch=={'bytes':594,'sha256':'d136270aad3a230fd882443afc26c17e49134ba2449e5beab67b7acc45ecd1a4'}
assert before['test']['revision']=='a41dfe72d7e5858f11169adf88673dc44ed24200'
old=root/'upgrade-disconnect-gateway-01.py'
data=old.read_text()
prior='ecc0e1d28b54b774284051e91baa066b5ec74800e87eb1e11ad93e9a7d4ec5f5'
assert data.count(prior)==1
data=data.replace(prior,watch['sha256'])
out=root/'upgrade-disconnect-gateway-02.py'
with out.open('x',encoding='utf-8',newline='\n') as stream:stream.write(data)
py_compile.compile(str(out),doraise=True)
proof={'sourceOperatorSha256':hashlib.sha256(old.read_bytes()).hexdigest(),
 'preparedOperatorSha256':hashlib.sha256(out.read_bytes()).hexdigest(),
 'currentWatchUnitSha256':watch['sha256'],'currentWatchUnitBytes':watch['bytes'],
 'onlyChange':'Pin separately updated existing watch configuration; preserve its bytes',
 'previousAttemptApplied':False,'strictZeroPlayersAndViewersAndTcp':True}
with (root/'operator-prepared-02.json').open('x') as stream:
 json.dump(proof,stream,indent=2);stream.write('\n')
print(json.dumps(proof))
