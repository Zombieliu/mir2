from pathlib import Path
import hashlib,json,py_compile

source=Path('C:/mir2-playtest-releases/20261008-classic-r22/operators-01/upgrade-classic-gateway-02.py')
out=Path(__file__).resolve().parent/'gateway-lifecycle-release-01/upgrade-disconnect-gateway-01.py'
text=source.read_text(encoding='utf-8')
def change(old,new):
    global text
    assert text.count(old)==1, old
    text=text.replace(old,new)
change('OLD_DROPIN_SHA256 = "6267365ef2c5c610535d1de865e10d84cdcbec37a89b98326e498f64a78e6814"',
       'OLD_DROPIN_SHA256 = "2a0386cc0ff8108a96c86547a92d2e8be96ad80cc38964aa0c22fbffc6ef2432"\nWATCH_UNITFILE = pathlib.Path("/etc/systemd/system/mir2-playtest.service.d/90-spectator-watch.conf")\nWATCH_UNIT_SHA256 = "ecc0e1d28b54b774284051e91baa066b5ec74800e87eb1e11ad93e9a7d4ec5f5"')
change('revision == "a41dfe72d7e5858f11169adf88673dc44ed24200" and\n            previous == "c6c32381a646dae1067dafdeec57691f606b1779" and active == 51',
       'revision == "536b4a59f3a8af43f6d4484238e2847573dfb106" and\n            previous == "a41dfe72d7e5858f11169adf88673dc44ed24200" and active == 51')
change('Only the attested appearance-to-classic pair at the established capacity is allowed',
       'Only the attested classic-to-disconnect-fix pair at the established capacity is allowed')
change('require(spectator.get("recordingEnabled") is False and spectator.get("bufferedFrames") == 0\n            and spectator.get("enabled") is not True, "Spectator state changed")',
       '# The separately installed watch configuration is pinned and preserved.\n    # Historical buffered frames are not active users; no viewer may be cut off.\n    require(spectator.get("recordingEnabled") is False and spectator.get("activeViewers") == 0,\n            "Spectator recording differs or a viewer has not drained")')
change('require(show(("DropInPaths",)).get("DropInPaths") == str(UNITFILE), "Effective drop-in set changed")',
       'require(show(("DropInPaths",)).get("DropInPaths") == str(UNITFILE) + " " + str(WATCH_UNITFILE),\n            "Effective drop-in set changed")')
change('env, unit = checked(ENV, 65536, private=True), checked(UNITFILE, 32768, OLD_DROPIN_SHA256)',
       'env, unit = checked(ENV, 65536, private=True), checked(UNITFILE, 32768, OLD_DROPIN_SHA256)\n    watch = checked(WATCH_UNITFILE, 65536, WATCH_UNIT_SHA256)')
change('"manifest": manifest_bytes, "content": content, "fingerprint": fingerprint, "oldFingerprint": old_fingerprint,',
       '"watch": watch, "manifest": manifest_bytes, "content": content, "fingerprint": fingerprint, "oldFingerprint": old_fingerprint,')
change('"Unit differs from its sole ExecStart rewrite")',
       '"Unit differs from its sole ExecStart rewrite")\n    require(checked(WATCH_UNITFILE, 65536, WATCH_UNIT_SHA256) == context["watch"],\n            "Existing spectator watch configuration changed")')
change('newfile(backup / UNITFILE.name, context["unit"])',
       'newfile(backup / UNITFILE.name, context["unit"])\n    newfile(backup / WATCH_UNITFILE.name, context["watch"])')
change('"configurationRetainedForV7": True', '"configurationRetainedForCandidate": True')
receipt_tail='"modifiedDropInPath": str(UNITFILE), "baseUnitSha256Unchanged": BASE_UNIT_SHA256}'
assert text.count(receipt_tail)==2
text=text.replace(receipt_tail, '"modifiedDropInPath": str(UNITFILE), "baseUnitSha256Unchanged": BASE_UNIT_SHA256,\n                  "watchUnitSha256Unchanged": WATCH_UNIT_SHA256}')
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(text)
py_compile.compile(str(out),doraise=True)
proof={'sourceOperatorSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
       'preparedOperatorSha256':hashlib.sha256(out.read_bytes()).hexdigest(),
       'previous':'a41dfe72d7e5858f11169adf88673dc44ed24200',
       'candidate':'536b4a59f3a8af43f6d4484238e2847573dfb106',
       'retainsExistingSpectatorWatch':True,'strictZeroPlayersAndViewersAndTcp':True,
       'executedOnServer':False}
with (out.parent/'operator-prepared-01.json').open('x') as stream:
    json.dump(proof,stream,indent=2)
    stream.write('\n')
print(json.dumps(proof))
