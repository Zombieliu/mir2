sudo -n /usr/bin/python3 - <<'PY'
import hashlib,json,pathlib,re,subprocess,urllib.request
def run(args):
    return subprocess.run(args,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15).stdout.decode()
def health(port):
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open('http://127.0.0.1:%d/health'%port,timeout=5) as r:
        return json.load(r)
test=health(7210)
original=health(7110)
unit=run(['systemctl','show','mir2-playtest.service','-p','MainPID','-p','Result','-p','ExecMainStatus','-p','NRestarts','-p','DropInPaths'])
count=len([x for x in run(['ss','-Htn','state','established','sport = :7200']).splitlines() if x.strip()])
files={}
for name in ('/etc/mir2-playtest/gateway.env','/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf','/etc/systemd/system/mir2-playtest.service.d/90-spectator-watch.conf','/etc/systemd/system/mir2-playtest.service'):
    p=pathlib.Path(name)
    assert p.is_file() and not p.is_symlink()
    data=p.read_bytes()
    files[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
release=pathlib.Path('/opt/mir2-playtest/releases')/test['revision']
meta=json.loads((release/'RELEASE.json').read_text())
binary=release/'mir2-gateway'
digest=hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest==meta['binarySha256'] and binary.stat().st_size==meta['binarySizeBytes']
pid=re.search(r'^MainPID=(\d+)$',unit,re.M).group(1)
held=pathlib.Path('/proc/'+pid+'/exe')
assert held.resolve()==binary and hashlib.sha256(held.read_bytes()).hexdigest()==digest
process_env=dict(entry.split(b'=',1) for entry in pathlib.Path('/proc/'+pid+'/environ').read_bytes().split(b'\0') if b'=' in entry)
rpc_keys=(b'MIR2_ZONE_HOST_ADDR',b'MIR2_ZONE_HOST_ADDRS',b'MIR2_ZONE_HOST_ACTIVE_ADDRS',b'MIR2_ZONE_HOST_STANDBY_ADDRS')
remote_zone_configured=any(bool(process_env.get(key)) for key in rpc_keys)
original_pids=re.findall(r'pid=(\d+)',run(['ss','-ltnpH','sport = :7110']))
print(json.dumps({'ok':True,'test':test,'unit':dict(line.split('=',1) for line in unit.splitlines()),'tcp7200':count,'files':files,'remoteZoneConfigured':remote_zone_configured,'binarySha256':digest,'binaryBytes':binary.stat().st_size,'original':{'ok':original.get('ok'),'revision':original.get('revision'),'pids':original_pids,'release':str(pathlib.Path('/opt/mir2/gateway/current').resolve())}},sort_keys=True))
PY
