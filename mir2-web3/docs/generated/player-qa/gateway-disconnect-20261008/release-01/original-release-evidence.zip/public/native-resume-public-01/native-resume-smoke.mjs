import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';

const base='C:/mir2-playtest-releases/20261007-remote-player-r21';
const root='E:/mir2-player-journey/tmp/gateway-lifecycle-release-01/native-resume-public-01';
const revision='536b4a59f3a8af43f6d4484238e2847573dfb106';
const endpoint='wss://165.154.65.136.sslip.io/playtest/ws';
function need(value,message){if(!value)throw Error(message);}
need(process.env.NODE_TLS_REJECT_UNAUTHORIZED!=='0','Normal TLS verification is required');
need(crypto.createHash('sha256').update(await fs.readFile(base+'/ws-transport-02.cjs')).digest('hex')==='7b9865c26b0b6c148b4ed0d00dfc5409aff21e6a65851a2c5352b689f7351574','Pinned WebSocket transport differs');
const WebSocketTransport=createRequire(import.meta.url)(base+'/ws-transport-02.cjs');
need(crypto.createHash('sha256').update(await fs.readFile(base+'/protocol-observation.mjs')).digest('hex')==='b69ba03e9f6ee05286d401341c6dbbe6dac4a6e5014fa6a67e9c6167c072d097','Frozen source observation differs');
const {applyProtocolObservation}=await import(pathToFileURL(base+'/protocol-observation.mjs'));
const health=await fetch('https://165.154.65.136.sslip.io/playtest/health',{redirect:'error',signal:AbortSignal.timeout(15000)}).then(r=>{need(r.ok,'Public health HTTP status');return r.json();});
need(health.ok===true&&health.revision===revision,'Public playtest must run the pinned disconnect candidate');
need(health.capacity.currentActiveSessions<=44,'Five owned clients require available normal capacity');
await fs.access(base+'/public-wss-03/private');
const priorReport=JSON.parse(await fs.readFile(base+'/public-wss-03/RESULT.json','utf8'));
need(priorReport.passed===true&&priorReport.sourceRevision==='c6c32381a646dae1067dafdeec57691f606b1779','Owned ordinary cohort provenance');
const owned=JSON.parse(await fs.readFile(base+'/public-wss-03/private/accounts.json','utf8'));
const {cohort,female}=owned;
need(cohort.length===5&&female.class==='Taoist'&&female.gender==='Female','Six existing owned class/gender variants');
for(const account of [...cohort,female])need(Number.isSafeInteger(account.characterIndex),'Reuse exact ordinary-created character index');
const secrets=cohort.map(a=>a.password);
const ordinary=new Set(['clientVersion','login','newCharacter','startGame','keepAlive','walk','turn','logOut','clientCapabilities','resumeSession']);
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function safe(value){
 if(Array.isArray(value))return value.map(safe);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,/password|secret|token|credential|authorization|cookie|pepper|private.?key/i.test(k)?'[redacted]':safe(v)]));
 return typeof value==='string'?secrets.reduce((s,p)=>s.split(p).join('[redacted]'),value):value;
}
class Client {
 constructor(account,phase){this.account=account;this.phase=phase;this.events=[];this.sequence=0;this.queue=Promise.resolve();}
 record(direction,value){const event={sequence:++this.sequence,utc:new Date().toISOString(),direction,...safe(value)};this.events.push(event);this.queue=this.queue.then(()=>fs.appendFile(path.join(root,`${this.phase}-${this.account.name}.jsonl`),JSON.stringify(event)+'\n'));}
 async wait(predicate,label,ms=20000){const end=Date.now()+ms;while(Date.now()<end){if(this.error)throw this.error;const value=predicate();if(value)return value;await delay(25);}throw Error('Timed out: '+label);}
 send(value){need(ordinary.has(value.type),'Only ordinary public commands are admitted');this.record('sent',value);this.ws.send(JSON.stringify(value));}
 async request(value,packet){const prior=this.sequence;this.send(value);return this.wait(()=>this.events.find(e=>e.sequence>prior&&e.direction==='received'&&e.packet===packet),packet);}
 async open(){
  this.ws=new WebSocketTransport(endpoint,{origin:'https://165.154.65.136.sslip.io',handshakeTimeout:10000});
  this.ws.addEventListener('message',event=>{try{const value=JSON.parse(String(event.data));this.record('received',value);if(value.type==='resumeCredential')this.ticket=value;if(value.packet==='UserInformation')this.info=value.payload;this.snapshot=applyProtocolObservation(this.snapshot,value);if(value.type==='error')this.error=Error('Public gateway rejected an ordinary command: '+value.message);}catch(error){this.error=error;}});
  this.ws.addEventListener('close',()=>{this.closed=true;});
  this.ws.addEventListener('error',()=>{this.error=Error('Verified public WSS failed');});
  await this.wait(()=>this.ws.readyState===1,'TLS WebSocket open',15000);
  this.send({type:'clientVersion'});
  this.timer=setInterval(()=>{if(this.ws.readyState===1)this.send({type:'keepAlive',time:Date.now()});},2000);
 }
 async login(createCharacter=false){
  const a=this.account;
  await this.request({type:'login',accountId:a.accountId,password:a.password},'LoginSuccess');
  if(createCharacter){const reply=await this.request({type:'newCharacter',name:a.name,class:a.class,gender:a.gender},'NewCharacterSuccess');a.characterIndex=reply.payload.character.index;need(Number.isSafeInteger(a.characterIndex),'Actual newly created character index');}
 }
 async start(){
  const prior=this.sequence;
  const reply=await this.request({type:'startGame',characterIndex:this.account.characterIndex},'StartGame');
  need(reply.payload.result===4,'Authenticated StartGame result4');
  await this.wait(()=>this.events.find(e=>e.sequence>prior&&e.packet==='UserInformation'),'owner UserInformation');
  await this.wait(()=>this.snapshot?.entities?.find(e=>e.objectId===this.snapshot.playerObjectId&&e.name===this.account.name),'normal shared owner snapshot');
  need(this.info.level===1&&this.info.hp>0,'Normal level1 actor without trusted preparation');
 }
 owner(){return this.snapshot.entities.find(e=>e.objectId===this.snapshot.playerObjectId);}
 async seen(account,after=0){return this.wait(()=>this.events.filter(e=>e.sequence>after&&e.packet==='ObjectPlayer'&&e.payload.name===account.name).at(-1),'remote ObjectPlayer '+account.name);}
 async close(){
  clearInterval(this.timer);
  if(this.ws?.readyState===1){const previousError=this.error;this.error=null;try{await this.request({type:'logOut'},'LogOutSuccess');this.normalLogout=true;}catch{}finally{this.error=previousError;this.ws.close(1000);}}
  await this.queue;
 }
}
function verifyAppearance(event,owner){
 const info=event.payload;
 need(info.transformType===-1,'Ordinary remote actor must not use Transform/00');
 need(info.class===owner.account.class&&info.gender===owner.account.gender,'Remote class and gender are authoritative');
 need(info.sprite?.bodyLibrary?.startsWith('CArmour/'),'Released ordinary armour body is selected');
 need(JSON.stringify(info.sprite)===JSON.stringify(owner.owner().sprite),'Complete remote sprite equals ordinary owner snapshot');
 return {observerBody:info.sprite.bodyLibrary,weapon:info.sprite.weaponLibrary,gender:info.gender,class:info.class,transformType:info.transformType,objectId:info.objectId};
}
const clients=[],checks=[];
const check=(name,evidence)=>checks.push({name,status:'passed',evidence});
function state(client){
 const s=client.snapshot,p=client.owner();
 need(p?.name===cohort[0].name,'Expected ordinary owned actor');
 need(s.entities.filter(e=>e.name===cohort[0].name).length===1,'Exactly one actor copy');
 need(Array.isArray(s.inventoryItems)&&Array.isArray(s.equipmentItems)&&Number.isFinite(s.gold),'Complete inventory/equipment/gold snapshot is required');
 const items=key=>structuredClone(s[key]).sort((a,b)=>String(a.uniqueId).localeCompare(String(b.uniqueId)));
 return {name:p.name,objectId:p.objectId,mapFileName:s.mapFileName,x:p.x,y:p.y,direction:p.direction,
         gold:s.gold,inventory:items('inventoryItems'),equipment:items('equipmentItems')};
}
async function fresh(phase,login=true){
 const client=new Client(cohort[0],phase);clients.push(client);
 await client.open();
 client.send({type:'clientCapabilities',capabilities:['nativeResumeV1']});
 if(login){await client.login(false);await client.start();}
 return client;
}
async function step(client){
 const from={...client.owner()};
 for(const [direction,dx,dy]of [['Down',0,1],['Right',1,0],['Left',-1,0],['Up',0,-1]]){
  await delay(650);const prior=client.sequence;
  client.send({type:'walk',direction});
  try{return await client.wait(()=>client.events.find(e=>e.sequence>prior&&e.packet==='UserLocation'&&e.payload.x===from.x+dx&&e.payload.y===from.y+dy),'ordinary acknowledged step',2000);}catch(error){if(client.error)throw error;}
 }
 throw Error('No ordinary acknowledged step completed');
}
let failure=null;
try{
 for(let cycle=1;cycle<=3;cycle++){
  const first=await fresh(`cycle-${cycle}-original`);
  const moved=await step(first);const before=state(first);
  check(`cycle${cycle}.ordinaryLoginAndStep`,{characterIndex:first.account.characterIndex,receipt:moved.sequence,position:{x:before.x,y:before.y}});
  const ticket=await first.wait(()=>first.ticket?.expiresAtMs>Date.now()+5000&&first.ticket,'live native resume credential');
  need(ticket.protocol==='nativeResumeV1'&&Number.isInteger(ticket.generation)&&/^[A-Za-z0-9_-]{43}$/.test(ticket.credential),'Bound native resume credential shape');
  clearInterval(first.timer);first.record('local',{type:'transportTerminated',logoutSent:false});first.ws.terminate();
  const deadline=Date.now()+5000;while(!first.closed&&Date.now()<deadline)await delay(25);
  need(first.closed===true&&!first.events.some(e=>e.direction==='sent'&&e.type==='logOut'),'Actual socket loss without application logout');await first.queue;
  check(`cycle${cycle}.uncleanTransportLoss`,{closed:true,logoutSent:false});
  await delay(1000);
  const resumed=await fresh(`cycle-${cycle}-resumed`,false),after=resumed.sequence;
  resumed.send({type:'resumeSession',credential:ticket.credential});
  const ack=await resumed.wait(()=>{
   const fresh=resumed.events.filter(e=>e.sequence>after);
   need(!fresh.some(e=>e.type==='resumeRejected'),'Native resume must not be rejected');
   return fresh.find(e=>e.type==='sessionResumed');
  },'sessionResumed');
  need(ack.protocol==='nativeResumeV1'&&ack.characterIndex===first.account.characterIndex&&ack.generation===ticket.generation+1,'Resume binds the same character and next generation');
  const snapshot=await resumed.wait(()=>resumed.events.find(e=>e.sequence>ack.sequence&&e.type==='worldSnapshot'),'ordered authoritative resume snapshot');
  const rotated=await resumed.wait(()=>resumed.ticket,'rotated resume credential');
  need(rotated.credential!==ticket.credential&&rotated.generation===ticket.generation+1,'Exactly one ticket rotation');
  need(!resumed.events.some(e=>e.direction==='sent'&&['login','startGame','newAccount','newCharacter'].includes(e.type)),'Fresh login or StartGame cannot substitute for resume');
  need(JSON.stringify(state(resumed))===JSON.stringify(before),'Resume preserves exact acknowledged state and item fields');
  check(`cycle${cycle}.nativeResumeAndState`,{receipt:ack.sequence,snapshotReceipt:snapshot.sequence,generation:ack.generation,exactState:true});
  const replay=await fresh(`cycle-${cycle}-replay`,false),replayAfter=replay.sequence;
  replay.send({type:'resumeSession',credential:ticket.credential});
  const rejected=await replay.wait(()=>replay.events.find(e=>e.sequence>replayAfter&&['resumeRejected','sessionResumed'].includes(e.type)),'used-ticket replay rejection');
  need(rejected.type==='resumeRejected'&&rejected.code==='unavailable','Used ticket must be rejected');
  await delay(500);
  need(!replay.events.some(e=>e.sequence>replayAfter&&(e.type==='sessionResumed'||e.packet==='UserInformation'||(e.type==='worldSnapshot'&&e.payload?.playerObjectId))),'Rejected replay exposes no authenticated actor');
  clearInterval(replay.timer);replay.ws.close(1000);await replay.queue;
  check(`cycle${cycle}.replayRejected`,{code:rejected.code,receipt:rejected.sequence});
  const direction=before.direction==='Up'?'Right':'Up';
  const turned=await resumed.request({type:'turn',direction},'UserLocation');
  const saved=state(resumed);need(saved.x===before.x&&saved.y===before.y&&saved.direction===direction,'Resumed actor retains live authority');
  check(`cycle${cycle}.resumedOwnerLive`,{receipt:turned.sequence,direction});
  await resumed.close();need(resumed.normalLogout===true,'Resumed actor normal logout must acknowledge');
  const returning=await fresh(`cycle-${cycle}-cold-login`);
  need(JSON.stringify(state(returning))===JSON.stringify(saved),'Normal logout releases the route and fresh login preserves acknowledged state');
  await returning.close();need(returning.normalLogout===true,'Returning actor normal logout must acknowledge');
  check(`cycle${cycle}.logoutAndFreshLogin`,{normalLogouts:2,exactState:true});
 }
}catch(error){failure=error.message;}
finally{
 for(const client of clients){
  clearInterval(client.timer);
  if(client.ws?.readyState===1){
   if(client.snapshot?.playerObjectId){await client.close();if(!client.normalLogout)failure??='Cleanup normal logout did not acknowledge';}
   else client.ws.close(1000);
  }
  await client.queue;
 }
}
const report={schema:'mir2.disconnect.native-resume-public.v1',passed:failure===null&&checks.length===18,
 sourceRevision:revision,endpoint,tlsVerified:true,checks,failure,cycles:3,
 newAccountRegistrations:0,newCharacterCreations:0,privateCredentialCopiesCreated:false,
 adminCommands:false,qaStatePreparation:false,nativeRenderAcceptance:false,fullQueuePressureTested:false};
await fs.writeFile(root+'/RESULT.json',JSON.stringify(safe(report),null,2),{flag:'wx'});
console.log(JSON.stringify(safe(report)));if(!report.passed)process.exitCode=1;
