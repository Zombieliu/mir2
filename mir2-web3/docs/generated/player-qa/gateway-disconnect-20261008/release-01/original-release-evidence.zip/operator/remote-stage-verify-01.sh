/usr/bin/python3 - <<'PY'
STAGE='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-536b4a59f3a8af43f6d4484238e2847573dfb106'
REVISION='536b4a59f3a8af43f6d4484238e2847573dfb106'
PINS={'gateway-package.tar.gz': {'size': 34194659, 'sha256': '02a70ed8487327a418b6ad3b3cf0d9227c6fa7a7812df73c199a8f40a4aee41b'}, 'VERIFIED-FILES.json': {'size': 412, 'sha256': 'fa489066f81e38befa27fbdc639fc21cc4287596f4f754230f3f4adf73bd10ab'}, 'upgrade-disconnect-gateway-01.py': {'size': 31551, 'sha256': 'f54c85cf93dd3d696da527e409a458a6dcefb0725eb9aef48c6542c51cc97b59'}}
import hashlib,json,os,pathlib,stat,tarfile
p=pathlib.Path(STAGE)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
assert set(x.name for x in p.iterdir())==set(PINS)
for name,pin in PINS.items():
 f=p/name;info=f.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.geteuid()
 assert info.st_size==pin['size'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
manifest=json.loads((p/'VERIFIED-FILES.json').read_text())
assert manifest['revision']==REVISION
expected={row['path']:row for row in manifest['files']}
assert set(expected)=={'mir2-gateway','RELEASE.json'}
seen=set()
with tarfile.open(p/'gateway-package.tar.gz','r:gz') as packed:
 for item in packed.getmembers():
  assert item.isfile() and item.name in {'mir2-gateway','zone_host','RELEASE.json','README.txt'}
  assert item.name not in seen and 0<item.size<=268435456
  seen.add(item.name)
  if item.name not in expected: continue
  data=packed.extractfile(item).read();entry=expected[item.name]
  assert len(data)==entry['size'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  fd=os.open(p/item.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,entry['mode'])
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.chmod(p/item.name,entry['mode'])
assert seen=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
print(json.dumps({'artifactStageVerified':True,'revision':REVISION,'publicServiceChanged':False}))
PY
