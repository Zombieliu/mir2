import hashlib,json,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
RELEASE=ROOT/'gateway-lifecycle-release-01'
CI=RELEASE/'linux-ci-01'
REMOTE_HELPER='C:/mir2-ui-repair-20260921/playtest-release-20260928/remote.py'
REVISION='536b4a59f3a8af43f6d4484238e2847573dfb106'
PREVIOUS='a41dfe72d7e5858f11169adf88673dc44ed24200'
STAGE='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-'+REVISION

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def new(path,data):
    with path.open('xb') as stream:stream.write(data)
def invoke(args,log,timeout=300):
    with (RELEASE/log).open('xb') as stream:
        result=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
    data=(RELEASE/log).read_text(encoding='utf-8',errors='replace')
    if result.returncode:
        print(data)
        raise SystemExit(result.returncode)
    return data
def remote(file,log,timeout=60):
    return invoke(['python',REMOTE_HELPER,'--user','ubuntu','--command-file',str(file),
                   '--timeout',str(timeout)],log,timeout+90)

assert sys.argv[1:]==['--apply'],'Explicit --apply is required'
proof=json.loads((CI/'CI-VERIFIED.json').read_text())
assert proof['revision']==REVISION and proof['runConclusion']=='success'
assert proof['serverSwitched'] is False and proof['publicR2Upload'] is False
metadata=json.loads((CI/'latest-mir2-gateway-release.json').read_text())
assert sha(CI/metadata['archive'])==proof['archiveSha256']
assert sha(CI/'mir2-gateway')==proof['binarySha256']
assert sha(CI/'VERIFIED-FILES.json')==proof['manifestSha256']
operator=RELEASE/'upgrade-disconnect-gateway-01.py'
operator_proof=json.loads((RELEASE/'operator-prepared-01.json').read_text())
assert sha(operator)==operator_proof['preparedOperatorSha256']
before_name=next('deploy-before-%02d.log'%attempt for attempt in range(1,100)
    if not (RELEASE/('deploy-before-%02d.log'%attempt)).exists())
before_raw=remote(ROOT/'gateway-lifecycle-read-public-01.sh',before_name,40)
before=json.loads(next(line for line in before_raw.splitlines() if line.startswith('{')))
assert before['ok'] is True and before['test']['revision']==PREVIOUS
assert before['remoteZoneConfigured'] is False,'This slice deploys the in-process Gateway only'
capacity=before['test']['capacity']
count_keys=['currentWsConnections','currentActiveSessions','currentReconnectLeases',
            'currentLoginInFlight','currentNewCharacterInFlight','currentStartGameInFlight']
if any(capacity[key]!=0 for key in count_keys) or before['tcp7200']!=0 or before['test']['spectator']['activeViewers']!=0:
    print(json.dumps({'ready':False,'serverSwitched':False,'reason':'Connections have not drained',
                     'capacity':capacity,'tcp7200':before['tcp7200'],
                     'spectatorViewers':before['test']['spectator']['activeViewers']}))
    raise SystemExit(75)
archive=CI/metadata['archive']
uploads=[(archive,'gateway-package.tar.gz'),(CI/'VERIFIED-FILES.json','VERIFIED-FILES.json'),
         (operator,'upgrade-disconnect-gateway-01.py')]
pins={name:{'size':file.stat().st_size,'sha256':sha(file)} for file,name in uploads}
setup=RELEASE/'remote-stage-setup-01.sh'
new(setup,("/usr/bin/python3 - <<'PY'\nimport os,pathlib,stat,json\np=pathlib.Path("+repr(STAGE)+")\n"
    "assert p.parent.resolve(strict=True)==p.parent and p.parent.stat().st_uid in (0,os.geteuid())\n"
    "assert not p.exists() and not p.is_symlink(), 'Existing staging requires inspection; refusing a blind rerun'\n"
    "p.mkdir(mode=0o700)\nassert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()\n"
    "print(json.dumps({'stageCreated':True}))\nPY\n").encode())
remote(setup,'deploy-stage-created-01.log')
upload_file=RELEASE/'upload-batch-01.json'
new(upload_file,(json.dumps([[str(file),STAGE+'/'+name] for file,name in uploads],indent=2)+'\n').encode())
invoke(['python',REMOTE_HELPER,'--user','ubuntu','--upload-batch',str(upload_file),'--timeout','180'],
       'deploy-upload-01.log',600)
extract=RELEASE/'remote-stage-verify-01.sh'
extract_code='''import hashlib,json,os,pathlib,stat,tarfile
p=pathlib.Path(STAGE)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
assert set(x.name for x in p.iterdir())==set(PINS)
for name,pin in PINS.items():
 f=p/name;info=f.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.geteuid()
 assert info.st_size==pin['size'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
manifest=json.loads((p/'VERIFIED-FILES.json').read_text())
assert manifest['revision']==REVISION
expected={row['path']:row for row in manifest['files']}
assert set(expected)=={'mir2-gateway','RELEASE.json'}
seen=set()
with tarfile.open(p/'gateway-package.tar.gz','r:gz') as packed:
 for item in packed.getmembers():
  assert item.isfile() and item.name in {'mir2-gateway','zone_host','RELEASE.json','README.txt'}
  assert item.name not in seen and 0<item.size<=268435456
  seen.add(item.name)
  if item.name not in expected: continue
  data=packed.extractfile(item).read();entry=expected[item.name]
  assert len(data)==entry['size'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  fd=os.open(p/item.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,entry['mode'])
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.chmod(p/item.name,entry['mode'])
assert seen=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
print(json.dumps({'artifactStageVerified':True,'revision':REVISION,'publicServiceChanged':False}))
'''
new(extract,("/usr/bin/python3 - <<'PY'\nSTAGE="+repr(STAGE)+"\nREVISION="+repr(REVISION)+
    "\nPINS="+repr(pins)+"\n"+extract_code+"PY\n").encode())
remote(extract,'deploy-stage-verified-01.log',90)
base_command=('sudo -n /usr/bin/python3 '+STAGE+'/upgrade-disconnect-gateway-01.py --revision '+REVISION+
    ' --expected-current '+PREVIOUS+' --manifest-sha256 '+proof['manifestSha256']+' --expected-active 51')
preflight=RELEASE/'remote-preflight-01.sh';new(preflight,(base_command+'\n').encode())
preflight_raw=remote(preflight,'deploy-preflight-01.log',120)
preflight_json=json.loads(next(line for line in preflight_raw.splitlines() if line.startswith('{')))
assert preflight_json['ok'] is True and preflight_json['applied'] is False
assert preflight_json['binarySha256']==proof['binarySha256']
apply=RELEASE/'remote-apply-01.sh';new(apply,(base_command+' --apply\n').encode())
apply_raw=remote(apply,'deploy-apply-01.log',240)
applied=json.loads(next(line for line in apply_raw.splitlines() if line.startswith('{')))
assert applied['ok'] is True and applied['applied'] is True and applied['revision']==REVISION
assert applied['binarySha256']==proof['binarySha256'] and applied['candidateShutdownPanic'] is False
assert applied['originalPid']==before['original']['pids'][0]
new(RELEASE/'DEPLOYED-01.json',(json.dumps(applied,indent=2)+'\n').encode())
print(json.dumps({'serverSwitched':True,'revision':REVISION,'pid':applied['pid'],
                 'originalUnchanged':True,'backup':applied['backup']}),flush=True)
for folder,script,proof_name,log in (
    ('ordinary-public-01','public-smoke.mjs','preparedHarnessSha256','public-ordinary-01.log'),
    ('native-resume-public-01','native-resume-smoke.mjs','preparedHarnessSha256','public-native-resume-01.log')):
    root=RELEASE/folder;spec=json.loads((root/'PREPARATION.json').read_text())
    assert sha(root/script)==spec[proof_name]
    invoke(['node',str(root/script)],log,300)
    report=json.loads((root/'RESULT.json').read_text())
    assert report['passed'] is True and report['sourceRevision']==REVISION
    print(json.dumps({'verified':folder,'passed':True}),flush=True)
after_raw=remote(ROOT/'gateway-lifecycle-read-public-01.sh','deploy-after-01.log',40)
after=json.loads(next(line for line in after_raw.splitlines() if line.startswith('{')))
assert after['test']['revision']==REVISION and after['test']['ok'] is True
assert after['original']==before['original'] and after['files']==before['files'] | {
    '/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf':after['files']['/etc/systemd/system/mir2-playtest.service.d/50-periodic-b71.conf']}
assert all(after['test']['capacity'][key]==0 for key in count_keys) and after['tcp7200']==0
final={'schema':'mir2.gateway.disconnect-public-verification.v1','revision':REVISION,
    'runId':proof['runId'],'binarySha256':proof['binarySha256'],'ordinaryChecks':44,'nativeResumeChecks':18,
    'normalPublicChecks':62,'originalRealmUnchanged':True,'clientReinstallRequired':False,
    'nativeUiAccepted':False,'fullGoalComplete':False,'after':after}
new(RELEASE/'PUBLIC-VERIFIED-01.json',(json.dumps(final,indent=2)+'\n').encode())
print(json.dumps({'passed':True,'publicChecks':62,'revision':REVISION}))
