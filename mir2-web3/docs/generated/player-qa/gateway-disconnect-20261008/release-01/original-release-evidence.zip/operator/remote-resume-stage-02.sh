/usr/bin/python3 - <<'PY'
STAGE='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-536b4a59f3a8af43f6d4484238e2847573dfb106'
PINS={'gateway-package.tar.gz': {'size': 34194659, 'sha256': '02a70ed8487327a418b6ad3b3cf0d9227c6fa7a7812df73c199a8f40a4aee41b'}, 'VERIFIED-FILES.json': {'size': 412, 'sha256': 'fa489066f81e38befa27fbdc639fc21cc4287596f4f754230f3f4adf73bd10ab'}, 'upgrade-disconnect-gateway-01.py': {'size': 31551, 'sha256': 'f54c85cf93dd3d696da527e409a458a6dcefb0725eb9aef48c6542c51cc97b59'}, 'mir2-gateway': {'size': 83430592, 'sha256': '755b02a845869551c79017ecb6392a1faee8007ebc117001443a294feb050dba'}, 'RELEASE.json': {'size': 1551, 'sha256': '7375393040127a3e8eeeb5a884aa9a17195ab19d29846de8ea60322138440f2e'}}
OPERATOR='upgrade-disconnect-gateway-02.py'
NEWPIN={'size': 31551, 'sha256': '049cdec755e03728e58cdee3962c7309ae30cfa52c78c688eaede94a30a5472b'}
import hashlib,json,os,pathlib,stat
p=pathlib.Path(STAGE)
assert p.resolve(strict=True)==p and p.stat().st_uid==os.geteuid()
names=set(x.name for x in p.iterdir())
assert names in (set(PINS),set(PINS)|{OPERATOR})
for name,pin in PINS.items():
 f=p/name;info=f.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.geteuid()
 assert info.st_size==pin['size'] and hashlib.sha256(f.read_bytes()).hexdigest()==pin['sha256']
if OPERATOR in names:
 f=p/OPERATOR;info=f.lstat()
 assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size==NEWPIN['size']
 assert hashlib.sha256(f.read_bytes()).hexdigest()==NEWPIN['sha256']
print(json.dumps({'verifiedExistingStage':True,'operatorAlreadyPresent':OPERATOR in names}))
PY
