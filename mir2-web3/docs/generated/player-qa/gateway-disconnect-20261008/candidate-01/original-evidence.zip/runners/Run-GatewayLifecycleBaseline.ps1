param(
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^[0-9]{2}$')]
    [string]$Run
)
$ErrorActionPreference = 'Stop'
$taskProject = Join-Path $PSScriptRoot 'gateway-lifecycle-baseline-20261008-01/mir2-web3'
$taskTarget = Join-Path $PSScriptRoot 'gateway-lifecycle-baseline-target-01'
$taskEvidence = Join-Path $PSScriptRoot 'gateway-lifecycle-evidence-01'
$taskLog = Join-Path $taskEvidence "$Run-baseline.log"
if (Test-Path -LiteralPath $taskLog) { throw 'Refusing to overwrite prior evidence' }
$env:CARGO_TARGET_DIR = $taskTarget
Set-Location -LiteralPath $taskProject
$taskArgs = @('+1.95.0','test','--locked','--offline','-p','mir2-gateway','--lib','--','--test-threads=1',
    'abrupt_tcp_and_web_teardown_drain_authoritative_state_and_economy_once',
    'db_failure_journals_the_exact_frozen_checkpoint_and_revokes_resume_eligibility',
    'realm_info_exposes_platinum_176_release_identity',
    'explicit_leave_failed_save_preserves_identity_lease_and_refresh',
    'authenticated_login_replays_once_and_returns_fresh_roster_on_all_three_paths',
    'dev_and_production_web_leave_paths_propagate_stale_save_and_keep_identity',
    'journaled_teardown_revokes_resume_then_replay_fences_stale_writer')
$taskStarted = [DateTime]::UtcNow.ToString('o')
& cargo @taskArgs *> $taskLog
$taskExit = $LASTEXITCODE
[ordered]@{
    suite='baseline-seven'; run=$Run; sourceCommit='7fea5cdba8cd160d4f2c5536f14fb7ce98c6bfbc';
    startedUtc=$taskStarted; completedUtc=[DateTime]::UtcNow.ToString('o'); exitCode=$taskExit;
    executable='cargo'; arguments=$taskArgs; project=$taskProject; target=$taskTarget;
    log=$taskLog; logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskLog.json" -Encoding utf8
Get-Content -LiteralPath $taskLog -Tail 130
exit $taskExit
