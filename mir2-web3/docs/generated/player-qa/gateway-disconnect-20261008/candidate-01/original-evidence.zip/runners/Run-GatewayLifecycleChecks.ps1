param(
    [Parameter(Mandatory=$true)]
    [ValidateSet('focused','adjacent','qualification','recovery-load','web','build')]
    [string]$Suite,
    [Parameter(Mandatory=$true)]
    [ValidatePattern('^[0-9]{2}$')]
    [string]$Run
)
$ErrorActionPreference = 'Stop'
$taskProject = Join-Path $PSScriptRoot 'gateway-lifecycle-20261008-01/mir2-web3'
$taskTarget = Join-Path $PSScriptRoot 'gateway-lifecycle-target-05'
$taskEvidence = Join-Path $PSScriptRoot 'gateway-lifecycle-evidence-01'
if (-not (Test-Path -LiteralPath (Join-Path $taskProject 'Cargo.toml'))) {
    throw 'Missing isolated project'
}
[IO.Directory]::CreateDirectory($taskEvidence) | Out-Null
$taskLog = Join-Path $taskEvidence "$Run-$Suite.log"
if (Test-Path -LiteralPath $taskLog) { throw 'Refusing to overwrite prior evidence' }
$env:CARGO_TARGET_DIR = $taskTarget
Set-Location -LiteralPath $taskProject
$taskArgs = @('+1.95.0','test','--locked','--offline','-p','mir2-gateway','--lib')
switch ($Suite) {
    'focused' { $taskArgs += @('transport_','--','--test-threads=1') }
    'adjacent' { $taskArgs += @('--','--test-threads=1','web::','abnormal_teardown_','rpc_zone_owner_command_client') }
    'qualification' { $taskArgs += @('--','--test-threads=1','web::','abnormal_teardown_','rpc_zone_owner_command_client','save_recovery::tests') }
    'recovery-load' { $taskArgs = @('+1.95.0','test','--locked','--offline','-p','mir2-simulation','--lib','runtime::recovery::','--','--test-threads=1') }
    'web' { $taskArgs += @('web::','--','--test-threads=1') }
    'build' { $taskArgs = @('+1.95.0','build','--locked','--offline','-p','mir2-gateway','--bin','mir2-gateway') }
}
$taskStarted = [DateTime]::UtcNow.ToString('o')
& cargo @taskArgs *> $taskLog
$taskExit = $LASTEXITCODE
$taskRecord = [ordered]@{
    suite=$Suite; run=$Run; startedUtc=$taskStarted;
    completedUtc=[DateTime]::UtcNow.ToString('o'); exitCode=$taskExit;
    executable='cargo'; arguments=$taskArgs; project=$taskProject; target=$taskTarget;
    log=$taskLog; logSha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
}
$taskRecord | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath "$taskLog.json" -Encoding utf8
Get-Content -LiteralPath $taskLog -Tail 45
exit $taskExit
