import hashlib,json,re,stat,subprocess,tarfile,zipfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath

SOURCE=Path('E:/mir2-player-journey/tmp/Download-P4PurificationLinuxCI02.py')
source=SOURCE.read_bytes()
assert hashlib.sha256(source).hexdigest()=='020599c5efe685e71c507a9b3f7017a1dd6e37d543ebc334f45b85e98b1047ed'
BASE=Path('C:/mir2-build/p4-purification-20261009-ci/server-ci-01')
OLD=BASE/'artifact-01'
OUT=BASE/'artifact-resume-02/verified'
RUN='37901046490';REPO='Zombieliu/mir2'
REVISION='5860815944e8077537cc12a7f32885b21c6d0a80'
TAG='2026-10-09-purification-5860815944'
bundle=BASE/'artifact-resume-02/github-original-complete.zip'

def digest(data):return hashlib.sha256(data).hexdigest()
def new(path,data):
    with path.open('xb') as stream:stream.write(data)
def gh(*args):
    result=subprocess.run(['gh',*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
    assert result.returncode==0,result.stderr.decode(errors='replace')
    return result.stdout

raw_ci=(OLD/'ci-status-original.json').read_bytes();ci=json.loads(raw_ci)
raw_artifacts=(OLD/'ci-artifacts-original.json').read_bytes();artifact=json.loads(raw_artifacts)['artifacts'][0]
assert ci['headSha']==REVISION and ci['status']=='completed' and ci['conclusion']=='success'
assert len(ci['jobs'])==2 and all(job['conclusion']=='success' for job in ci['jobs'])
steps={item['name']:item['conclusion'] for job in ci['jobs'] if job['name']=='build-linux-x64' for item in job['steps']}
for name in ['Verify shared player appearance and equipment ingress','Verify disconnect cancellation and trusted journal recovery',
    'Verify Linux release and save-recovery boundary','Verify classic shared gameplay and durable source receipts',
    'Verify rejected combat targets acknowledge and retire old movement','Verify SnakeTotem immediate master and corpse permissions',
    'Verify original Purification completion and status cleanup','Package Gateway','Upload Gateway package']:
    assert steps[name]=='success',name
assert steps['Publish Gateway package to R2']=='skipped'
assert artifact['workflow_run']['head_sha']==REVISION and artifact['expired'] is False
assert bundle.stat().st_size==artifact['size_in_bytes'] and digest(bundle.read_bytes())==artifact['digest'].split(':',1)[1]
assert not OUT.exists();OUT.mkdir()
new(OUT/'ci-status-original.json',raw_ci);new(OUT/'ci-artifacts-original.json',raw_artifacts)
marker="archive_name='mir2-gateway-linux-x64-'+TAG+'.tar.gz'"
assert source.decode().count(marker)==1
tail=marker+source.decode().split(marker,1)[1]
# This is exact reviewed local source, not code from the downloaded artifact.
# Preserve original safe ZIP/tar, ELF/size/SHA, clean Source metadata and raw log
# verification after replacing only the acquisition with verified206 recovery.
new(OUT/'ORIGINAL-VERIFIER-DERIVATION.json',(json.dumps({'sourceSha256':digest(source),
    'originalVerifierTailSha256':digest(tail.encode()),'tailByteUnchanged':True,
    'rangeRecoveryReceiptSha256':digest((BASE/'artifact-resume-02/RECOVERY-VERIFIED.json').read_bytes())},indent=2)+'\n').encode())
exec(compile(tail,str(SOURCE)+'#verified-archive-tail','exec'),globals())
