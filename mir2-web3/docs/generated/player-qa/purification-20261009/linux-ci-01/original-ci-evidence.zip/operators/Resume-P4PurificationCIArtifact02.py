import hashlib,json,re,subprocess
from pathlib import Path
BASE=Path('C:/mir2-build/p4-purification-20261009-ci/server-ci-01')
OLD=BASE/'artifact-01'
OUT=BASE/'artifact-resume-02'
partial=OLD/'github-artifact-original.zip'
metadata=json.loads((OLD/'ci-artifacts-original.json').read_bytes())['artifacts'][0]
assert metadata['id']==11604393896 and metadata['size_in_bytes']==33763818
assert metadata['digest']=='sha256:7c3032c7327990aa6fe17e34bf9c6524b739795a6308804ec51cb851050a63c0'
assert metadata['workflow_run']['head_sha']=='5860815944e8077537cc12a7f32885b21c6d0a80'
prefix=partial.read_bytes();assert len(prefix)==31834112
assert not OUT.exists();OUT.mkdir()
command=['gh','api','--include','repos/Zombieliu/mir2/actions/artifacts/11604393896/zip',
    '--header','Accept-Encoding: identity','--header',f'Range: bytes={len(prefix)}-']
with (OUT/'remaining-range-response.private-http').open('xb') as stream:
    result=subprocess.run(command,stdout=stream,stderr=subprocess.PIPE,timeout=90)
with (OUT/'command-stderr.log').open('xb') as stream:stream.write(result.stderr)
assert result.returncode==0,result.stderr.decode(errors='replace')
raw=(OUT/'remaining-range-response.private-http').read_bytes()
header,tail=raw.split(b'\r\n\r\n',1)
assert re.match(rb'HTTP/[^ ]+ 206 ',header)
fields={}
for line in header.split(b'\r\n')[1:]:
    key,value=line.split(b':',1);key=key.decode().lower()
    assert key not in fields or key in ('server-timing',)
    fields[key]=value.strip().decode()
assert fields.get('content-range')==f'bytes {len(prefix)}-{metadata["size_in_bytes"]-1}/{metadata["size_in_bytes"]}'
assert fields.get('content-encoding') in (None,'identity')
assert len(tail)==metadata['size_in_bytes']-len(prefix)
assert int(fields['content-length'])==len(tail)
whole=prefix+tail
assert hashlib.sha256(whole).hexdigest()==metadata['digest'].split(':',1)[1]
with (OUT/'github-original-complete.zip').open('xb') as stream:stream.write(whole)
record={'schema':'mir2.purification.ci-artifact-range-recovery.v1','passed':True,
    'originalPartialPreserved':True,'originalPartialSha256':hashlib.sha256(prefix).hexdigest(),
    'originalPartialBytes':len(prefix),'remainingBytes':len(tail),'status':206,'contentRange':fields['content-range'],
    'completeBytes':len(whole),'completeSha256':hashlib.sha256(whole).hexdigest(),
    'githubArtifactDigestVerified':True,'source':'5860815944e8077537cc12a7f32885b21c6d0a80',
    'privateResponseHeadersCopiedIntoPublicEvidence':False}
with (OUT/'RECOVERY-VERIFIED.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
