use anyhow::{ensure, Context, Result};
use mir2_windows_updater::{model::hash, platform, update::{HttpsSource, Source}, CDN_FEED_URL, SIGNING_KEY};
use serde_json::json;
use std::{fs, io::Read, path::PathBuf, time::Duration};

fn get(agent: &ureq::Agent, path: &str, size: usize, pin: &str, dir: &PathBuf) -> Result<Vec<u8>> {
    let url = format!("https://assets.mir2.obelisk.build/client-updates/{path}");
    let r = agent.get(&url).set("Accept-Encoding", "identity").call()?;
    ensure!(r.status() == 200, "status");
    ensure!(r.header("Content-Encoding").is_none(), "encoding");
    if path.starts_with("latest.") { ensure!(r.header("X-Mir2-Sequence") == Some("14"), "actual CDN sequence"); }
    let headers = json!({"status":r.status(),"sequence":r.header("X-Mir2-Sequence"),"cache":r.header("X-Mir2-Native-Cache"),"cfRay":r.header("CF-Ray"),"etag":r.header("ETag"),"contentLength":r.header("Content-Length"),"cacheControl":r.header("Cache-Control")});
    let mut bytes = Vec::new();
    r.into_reader().take(size as u64 + 1).read_to_end(&mut bytes)?;
    ensure!(bytes.len() == size && hash(&bytes).eq_ignore_ascii_case(pin), "size/SHA");
    let name = path.rsplit('/').next().context("filename")?;
    fs::write(dir.join(name), &bytes)?;
    fs::write(dir.join(format!("{name}.headers.json")), serde_json::to_vec_pretty(&headers)?)?;
    Ok(bytes)
}
fn main() -> Result<()> {
    let dir = PathBuf::from(std::env::args_os().nth(1).context("owned output path")?);
    ensure!(!dir.exists(), "output already exists");
    fs::create_dir(&dir)?;
    let agent = ureq::AgentBuilder::new().redirects(0).timeout_connect(Duration::from_secs(8)).timeout_read(Duration::from_secs(30)).timeout_write(Duration::from_secs(30)).build();
    let feed = get(&agent, "latest.json", 1159, "b5b29a4992c6cf6f276d35e2fba28a2a6b5aa640a0156e3474b81bb14a04f454", &dir)?;
    let signature = get(&agent, "latest.p7s", 1614, "8e4c9e0800ea4724d05f600552df4cb62275097e88fba833ba1e09cfd9fe288b", &dir)?;
    platform::verify_cms(&feed, &signature, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let source = HttpsSource::new()?;
    let mut received = 0;
    let pair = source.discovery_pair(&mut |n| { received += n; Ok(()) })?;
    ensure!(pair.0 == feed && pair.1 == signature, "production HTTPS discovery pair");
    platform::verify_cms(&pair.0, &pair.1, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let engine = get(&agent, "releases/updater-8CDDDC11E89E3328-s14/ENGINE.json", 421, "da47b670b127af8f62c6771f624ef75ded9d76fb365e49b0eccd0858467baa78", &dir)?;
    let engine_sig = get(&agent, "releases/updater-8CDDDC11E89E3328-s14/ENGINE.p7s", 1614, "7f15daf54c7c5b5a87e774c6050645b7fcf88f43afaf1d96abfb7bd440926d65", &dir)?;
    platform::verify_cms(&engine, &engine_sig, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let _binary = get(&agent, "releases/updater-8CDDDC11E89E3328-s14/Mir2Updater.exe", 1952256, "8cdddc11e89e3328276dd9ea7b7c8666ac4004d47566bd187e7b7302d614bb2e", &dir)?;
    let r = agent.get("https://assets.mir2.obelisk.build/client-updates/installers/0b77fc6ce3e22cc0b81ede90b2802a16babddd460fb4e3f434052fcd629425bd/Mir2Setup.exe").set("Accept-Encoding", "identity").set("Range", "bytes=0-1023").call()?;
    ensure!(r.status() == 206 && r.header("Content-Range") == Some("bytes 0-1023/27525634"), "actual TLS range");
    let mut prefix = Vec::new();
    r.into_reader().take(1025).read_to_end(&mut prefix)?;
    let mut original = Vec::new();
    fs::File::open("C:/mir2-playtest-releases/20261006-local-install-perf-01/bootstrap14/artifacts/Numeron-Legend-of-Rebirth-20261006-r17-Bootstrap.exe")?.take(1024).read_to_end(&mut original)?;
    ensure!(prefix == original && prefix.len() == 1024, "range original bytes");
    fs::write(dir.join("bootstrap-prefix.bin"), &prefix)?;
    let receipt = json!({"schema":"mir2.actual-native-ureq-https-cms-readonly.v1","passed":true,"ureq":"2.12.1","defaultUserAgent":"ureq/2.12.1","tlsVerified":true,"directCdnSequence":14,"compiledCdnUrl":CDN_FEED_URL,"actualProductionDiscoveryPair":true,"discoveryReportedBytes":received,"feedCmsVerified":true,"engineCmsVerified":true,"engineFullShaVerified":true,"actualRange206OriginalBytes":true,"requestBytesStored":true,"gameLaunched":false,"gameInstallationTouched":false,"fullInstallerExecuted":false,"affectedLaptopTested":false});
    fs::write(dir.join("RESULT.json"), serde_json::to_vec_pretty(&receipt)?)?;
    println!("{receipt}");
    Ok(())
}
