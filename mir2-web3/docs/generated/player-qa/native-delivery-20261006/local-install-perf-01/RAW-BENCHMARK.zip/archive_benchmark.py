import hashlib, json, pathlib, zipfile

BASE = pathlib.Path(__file__).resolve().parent
PROJECT = pathlib.Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3')
OUT = PROJECT / 'docs/generated/player-qa/native-delivery-20261006/local-install-perf-01'
OUT.mkdir(parents=True, exist_ok=False)
selected = {}
for path in (BASE / 'commands').glob('*.log'):
    selected[path.relative_to(BASE).as_posix()] = path
for name in ['probe-baseline-01', 'probe-candidate-01']:
    selected[f'{name}/RESULT.json'] = pathlib.Path('D:/Mir2InstallPerf-20261006-01') / name / 'RESULT.json'
for name in ['bundle-baseline-01', 'bundle-candidate-01', 'bundle-candidate-02', 'bundle-baseline-02']:
    selected[f'{name}/RESULT.json'] = BASE / name / 'RESULT.json'
for path in (BASE / 'source-baseline').rglob('*'):
    if path.is_file(): selected[path.relative_to(BASE).as_posix()] = path
for path in (BASE / 'harness').rglob('*'):
    if path.is_file(): selected[path.relative_to(BASE).as_posix()] = path
for name in ['user-install-original-13-completed.jsonl', 'archive_benchmark.py']:
    selected[name] = BASE / name
for name in ['baseline-probe.exe', 'baseline-pipeline.exe', 'candidate-pipeline.exe']:
    path = BASE / name
    selected[f'{name}.identity.json'] = None
    record = {'path': str(path), 'size': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    (OUT / f'{name}.identity.json').write_text(json.dumps(record, indent=2), encoding='utf-8')

records = []
archive = OUT / 'RAW-BENCHMARK.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for key, path in sorted(selected.items()):
        data = path.read_bytes() if path else (OUT / key).read_bytes()
        z.writestr(key, data)
        records.append({'path': key, 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
inputs = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((PROJECT / 'apps/game-client/windows-updater/src').rglob('*.rs'))}
bundles = [json.loads((BASE / n / 'RESULT.json').read_text()) for n in ['bundle-baseline-01','bundle-candidate-01','bundle-candidate-02','bundle-baseline-02']]
summary = {'schema': 'mir2.local-install.benchmark-proof.v1', 'baselineRevision':'ae0eec42959f4267ebc42f2a3f3a9ca14129bd8c', 'candidateInputs': inputs, 'order': ['baseline-01','candidate-01','candidate-02','baseline-02'], 'actualRealSignedArchiveRuns': bundles, 'archive': {'path': archive.name, 'size':archive.stat().st_size, 'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}, 'rawFiles':records, 'fullCandidateFirstInstall':False,'publicCandidatePublished':False,'networkSpeedMeasured':False,'affectedLaptopMeasured':False,'originalFailuresRetained':True}
(OUT / 'BENCHMARK.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps({'archive':summary['archive'],'files':len(records),'output':str(OUT)}))
