use anyhow::{ensure, Result};
use mir2_windows_updater::{fs_safe as safe, model::{self, FileEntry, META, MAX_META}, platform, transaction, update::{self, delivery}};
use serde_json::json;
use std::{fs, path::PathBuf, time::Instant};

fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    ensure!(args.len() == 3 && ["probe", "bundle"].contains(&args[1].as_str()), "probe|bundle <fresh-owned-root>");
    let root = PathBuf::from(&args[2]);
    ensure!(root.starts_with("D:/Mir2InstallPerf-20261006-01") || root.starts_with("C:/mir2-playtest-releases/20261006-local-install-perf-01"), "owned root only");
    ensure!(!root.exists(), "fresh fixture required");
    safe::ancestors(&root)?;
    fs::create_dir_all(&root)?;
    if args[1] == "bundle" { return bundle(&root); }
    let data = vec![42u8; 2048];
    let source = root.join("source.bin");
    safe::write_new(&source, &data)?;
    let entry = FileEntry {path: "mir2-assets/probe.png".into(), size: data.len() as u64, sha256: model::hash(&data)};
    safe::write_new(&root.join("game/mir2-platform-windows.exe"), b"fixture, never executed")?;
    let started = Instant::now();
    for _ in 0..1000 {ensure!(!platform::game_is_running(&root.join("game/mir2-platform-windows.exe"))?, "fixture unexpectedly running");}
    let guard_ms = started.elapsed().as_millis();
    let started = Instant::now();
    for _ in 0..1000 {ensure!(safe::matches(&source, &entry)?, "fixture hash");}
    let matches_ms = started.elapsed().as_millis();
    let started = Instant::now();
    let mut changes = Vec::new();
    for index in 0..256 {
        changes.push(transaction::stage_bytes(&root, &format!("game/mir2-assets/probe/{index}.png"), &data)?);
    }
    let stage_ms = started.elapsed().as_millis();
    let started = Instant::now();
    transaction::prepare_and_apply(&root, &changes)?;
    let transaction_ms = started.elapsed().as_millis();
    let started = Instant::now();
    transaction::rollback(&root)?;
    let rollback_ms = started.elapsed().as_millis();
    let result = json!({"schema":"mir2.local-install.probe.v1","root":root,"guardIterations":1000,"guardMs":guard_ms,"matchesIterations":1000,"matchesMs":matches_ms,"transactionCount":256,"stageMs":stage_ms,"transactionMs":transaction_ms,"rollbackMs":rollback_ms,"userInstallMutated":false});
    safe::write_new(&root.join("RESULT.json"), &serde_json::to_vec_pretty(&result)?)?;
    println!("{}", result);
    Ok(())
}

fn bundle(root: &std::path::Path) -> Result<()> {
    let inputs: serde_json::Value = serde_json::from_slice(&safe::read_bounded(&PathBuf::from("C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/PROFILE-INPUTS.json"), 32768)?)?;
    let package = PathBuf::from(inputs["package"].as_str().unwrap());
    let meta = META.into_iter().map(|name| Ok((name.to_string(),safe::read_bounded(&package.join(name), MAX_META)?))).collect::<Result<std::collections::BTreeMap<_,_>>>()?;
    platform::verify_cms(&meta["RELEASE-STATEMENT.json"], &meta["RELEASE-STATEMENT.p7s"], mir2_windows_updater::SIGNING_KEY).map_err(anyhow::Error::msg)?;
    ensure!(model::hash(&meta["PACKAGE-MANIFEST.json"]) == inputs["manifestSha256"], "frozen signed manifest");
    let manifest = model::bind_game(&meta)?;
    let directory = PathBuf::from(inputs["delivery"].as_str().unwrap());
    let bytes = safe::read_bounded(&directory.join("DELIVERY.json"), MAX_META)?;
    let descriptor = delivery::Delivery::parse(&bytes, "WN-CANDIDATE-20261004-invited-17", &meta["PACKAGE-MANIFEST.json"], &meta["VERSION.json"], &manifest, update::now())?;
    platform::verify_cms_at(&bytes, &safe::read_bounded(&directory.join("DELIVERY.p7s"), 32768)?, mir2_windows_updater::SIGNING_KEY, descriptor.built_unix).map_err(anyhow::Error::msg)?;
    let bundle = &descriptor.bundles[5];
    ensure!(bundle.files.len() == 33996, "fixed benchmark projection");
    let map = manifest.map();
    let expected: Vec<_> = bundle.files.iter().map(|path| map[path.as_str()]).collect();
    let archive = root.join("archive.m2b.gz");
    fs::copy(directory.join(&bundle.archive.path), &archive)?;
    ensure!(safe::matches(&archive, &bundle.archive)?, "artifact copy matches CMS descriptor");
    let start = Instant::now();
    delivery::extract_bundle(root, &archive, &bundle.archive, &expected, &mut || Ok(()))?;
    let extract_ms = start.elapsed().as_millis();
    let start = Instant::now();
    for entry in &expected { ensure!(safe::matches(&root.join(".update/downloads").join(&entry.sha256), entry)?, "independent full output hash"); }
    let verify_ms = start.elapsed().as_millis();
    let result = json!({"schema":"mir2.local-install.real-bundle.v1","root":root,"manifestSha256":inputs["manifestSha256"],"archive":bundle.archive,"fileCount":expected.len(),"expandedBytes":expected.iter().map(|e|e.size).sum::<u64>(),"extractMs":extract_ms,"independentVerifyMs":verify_ms,"cmsVerified":true,"allOutputHashesVerified":true,"transport":"local signed archive; network time excluded","userInstallMutated":false});
    safe::write_new(&root.join("RESULT.json"), &serde_json::to_vec_pretty(&result)?)?;
    println!("{result}");
    Ok(())
}
