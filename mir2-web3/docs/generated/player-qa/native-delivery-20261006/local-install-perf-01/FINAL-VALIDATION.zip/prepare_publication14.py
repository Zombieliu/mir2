import hashlib, json, pathlib, subprocess

OUT = pathlib.Path(__file__).resolve().parent
PROJECT = pathlib.Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3')
RECIPES = pathlib.Path('C:/Users/Administrator/.codex/worktrees/r2-client-delivery/mir2-player-journey/mir2-web3/apps/game-client/windows-updater/scripts')
REV = 'b4390ee4c987bbf000ba1d95761151e39fc0d54f'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def canonical(v): return (json.dumps(v, sort_keys=True, separators=(',', ':'), ensure_ascii=False) + '\n').encode()
def write(path, raw):
    with path.open('xb') as f: f.write(raw)

assert json.loads((OUT/'bootstrap14/BUILD-BOOTSTRAP.json').read_bytes())['passed'] is True
assert subprocess.check_output(['git','-c','gc.auto=0','rev-parse','HEAD'],cwd=PROJECT).decode().strip()==REV
assert not subprocess.check_output(['git','-c','gc.auto=0','status','--porcelain=v1','--untracked-files=all'],cwd=PROJECT).strip()
original=(RECIPES/'prepare-signed-native-publication.ps1').read_bytes()
git_original=subprocess.check_output(['git','-c','gc.auto=0','show','4c60c323aed11829abae6ee5ce6e13c675a3c1c3:mir2-web3/apps/game-client/windows-updater/scripts/prepare-signed-native-publication.ps1'],cwd=PROJECT)
assert original==git_original
text=original.decode('utf-8-sig')
old="$project=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../..'))"
assert text.count(old)==1
text=text.replace(old,"$project='"+PROJECT.as_posix()+"'")
old="(Join-Path $PSScriptRoot 'prepare-native-publication.py')"
assert text.count(old)==1
text=text.replace(old,"'"+(RECIPES/'prepare-native-publication.py').as_posix()+"'")
wrapped=text.encode('utf-8')
wrapper=OUT/'prepare-signed-publication14.ps1'
write(wrapper,wrapped)
write(OUT/'PREPARE-VERIFIER-SOURCE.json',json.dumps({'recipeSource':'4c60c323aed11829abae6ee5ce6e13c675a3c1c3','originalSha256':sha(original),'wrapperSha256':sha(wrapped),'changes':['repository anchor fixed to clean engine source','dependency script fixed to unchanged reviewed recipe'],'cmsFunctionsChanged':False,'engineSource':REV},indent=2).encode())
args=['pwsh','-NoProfile','-File',str(wrapper),'-CandidateRoot','C:/Users/Administrator/.codex/worktrees/r17/mir2-player-journey/mir2-web3/dist/r17','-DeliveryRoot','C:/mir2-playtest-releases/20261004-native-r18/r17-download-acceleration-02','-EngineRoot',str(OUT/'release14/engine-release'),'-FeedRoot',str(OUT/'release14/feed'),'-OutputRoot',str(OUT/'publication14'),'-SourceRevision',REV,'-BootstrapExe',str(OUT/'bootstrap14/artifacts/Numeron-Legend-of-Rebirth-20261006-r17-Bootstrap.exe'),'-PythonPath','C:/Python313/python.exe','-IncludeRootFiles']
r=subprocess.run(args,cwd=PROJECT,capture_output=True,timeout=240)
write(OUT/'commands/prepare-publication14.stdout',r.stdout)
write(OUT/'commands/prepare-publication14.stderr',r.stderr)
assert r.returncode==0,r.stderr.decode(errors='replace')
print(json.dumps({'passed':True,'source':REV,'recipeSha256':sha(original),'rootReceipt':str(OUT/'publication14/ROOT-VERIFICATION.json')}))
