import base64, copy, hashlib, json, pathlib, re

OUT=pathlib.Path(__file__).resolve().parent
PROJECT=pathlib.Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3')
REV='b4390ee4c987bbf000ba1d95761151e39fc0d54f'
SRC=PROJECT/'infra/cloudflare/mir2-r2-bulk-upload/src'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canon(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n').encode()
def put(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(data)

old=json.loads((SRC/'native-r17-publication-plan.json').read_bytes())
planraw=(OUT/'publication14/PUBLICATION-PLAN.json').read_bytes()
proofraw=(OUT/'publication14/ROOT-VERIFICATION.json').read_bytes()
publication=json.loads(planraw);proof=json.loads(proofraw)
assert proof['passed'] and proof['cmsVerified'] and proof['candidateVerified'] and proof['sequence']==14 and proof['sourceRevision']==REV
assert publication['expectedCurrent'] is None
definition=copy.deepcopy(old)
definition['sourceRevision']=REV
definition['sourcePlanSha256']=sha(planraw)
definition['sourcePlanBase64']=base64.b64encode(planraw).decode()
definition['rootVerificationSha256']=sha(proofraw)
definition['rootVerificationBase64']=base64.b64encode(proofraw).decode()
definition['candidate']=publication['candidate']
definition['objectsSha256']=proof['objectsSha256']
definition['knownPrevious']=old['candidate']
definition['predecessorProof']={k:old[k] for k in ('sourcePlanSha256','sourcePlanBase64','rootVerificationSha256','rootVerificationBase64')}
definition['preparation']['verifierExecutedThisPhase']=True
definition['preparation']['verifierReceiptSource']='fixtures/actual-cms14/ROOT-VERIFICATION.json'
definition['preparation']['requiredVerifier']='Actual pinned Windows CMS; clean engine b4390ee4; unchanged complete R17 verification'
definition['objects']=[]
for index,o in enumerate(sorted(publication['objects'],key=lambda o:o['path'])):
    obj={k:o[k] for k in ('path','size','sha256')}
    obj.update(index=index,r2Key=definition['r2Prefix']+o['path'],originRelativePath=o['path'],contentType='application/json' if o['path'].endswith('.json') else 'application/pkcs7-signature' if o['path'].endswith('.p7s') else 'application/octet-stream',cacheControl='public, max-age=31536000, immutable')
    if o['path'].startswith('releases/game-'):
        prior=next(p for p in old['objects'] if p['path']==o['path'])
        assert all(prior[k]==obj[k] for k in ('path','size','sha256','index','r2Key','originRelativePath'))
        obj=copy.deepcopy(prior)
    definition['objects'].append(obj)
assert len(definition['objects'])==36
assert sha(canon([{k:o[k] for k in ('path','size','sha256')} for o in definition['objects']]))==definition['objectsSha256']
assert [o for o in definition['objects'] if o['path'].startswith('releases/game-')]==[o for o in old['objects'] if o['path'].startswith('releases/game-')]
installer=definition['objects'][2]
definition['installerOriginEvidence'].update(expectedSha256=installer['sha256'],expectedSize=installer['size'],requestedOriginRelativePath=installer['path'],sourceFixture=str(OUT/'bootstrap14/artifacts/Numeron-Legend-of-Rebirth-20261006-r17-Bootstrap.exe'),actualPublicBuildReceipt='bootstrap14/BUILD-BOOTSTRAP.json')
literal=(json.dumps(definition,indent=2)+'\n').encode()
if len(literal)>65536:literal=canon(definition)
put(SRC/'native-r17-s14-publication-plan.json',literal)
native=sha(canon(definition))
module=(SRC/'native-r17-publication.mjs').read_text()
module=module.replace('./native-r17-publication-plan.json','./native-r17-s14-publication-plan.json').replace(old['candidate']['sourceRevision'],REV).replace("candidate.candidate.sequence === 13","candidate.candidate.sequence === 14").replace("candidate.knownPrevious.sequence === 12","candidate.knownPrevious.sequence === 13").replace("'/upload/native-r17'","'/upload/native-r17-s14'").replace('nativeR17Fetch','nativeR17S14Fetch').replace('createNativeR17Handler','createNativeR17S14Handler')
module=re.sub(r"export const NATIVE_PLAN_SHA256 = '[0-9a-f]{64}';",f"export const NATIVE_PLAN_SHA256 = '{native}';",module)
put(SRC/'native-r17-s14-publication.mjs',module.encode())
script=(PROJECT/'scripts/native_r17_r2_delivery.py').read_text()
for name,value in {'SOURCE_PLAN_SHA':sha(planraw),'ROOT_SHA':sha(proofraw),'NATIVE_SHA':native,'LITERAL_SHA':sha(literal),'OBJECTS_SHA':definition['objectsSha256']}.items():script=re.sub(r"^"+name+r" = '[0-9a-f]{64}'$",name+" = '"+value+"'",script,flags=re.M)
script=script.replace("PRIVATE_PREFIX = '/upload/native-r17'","PRIVATE_PREFIX = '/upload/native-r17-s14'").replace("/ 'infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json'","/ 'infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-s14-publication-plan.json'").replace('len(raw) == 64106',f'len(raw) == {len(literal)}').replace("plan['candidate']['sequence'] == 13","plan['candidate']['sequence'] == 14").replace("plan['knownPrevious']['sequence'] == 12","plan['knownPrevious']['sequence'] == 13").replace(old['candidate']['sourceRevision'],REV)
put(PROJECT/'scripts/native_r17_s14_r2_delivery.py',script.encode())
fixture=PROJECT/'scripts/fixtures/native-r17-s14'
for name,raw in [('preview/artifacts/feed/latest.json',(OUT/'release14/feed/latest.json').read_bytes()),('preview/artifacts/feed/latest.p7s',(OUT/'release14/feed/latest.p7s').read_bytes()),('predecessor13/latest.json',(PROJECT/'scripts/fixtures/native-r17-13/preview/artifacts/feed/latest.json').read_bytes()),('actual-cms14/ROOT-VERIFICATION.json',proofraw),('actual-cms14/PUBLICATION-PLAN.json',planraw)]:put(fixture/name,raw)
test=(PROJECT/'infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-publication.test.mjs').read_text()
test=test.replace("../src/native-r17-publication", "../src/native-r17-s14-publication").replace('createNativeR17Handler','createNativeR17S14Handler').replace('createNativeR17S14Handler as createPreparedSnapshotHandler','createNativeR17Handler as createPreparedSnapshotHandler').replace("native-r17-13/preview/","native-r17-s14/preview/").replace("native-r17-13/predecessor12/","native-r17-s14/predecessor13/").replace('/upload/native-r17','/upload/native-r17-s14').replace('definition.candidate.sequence, 13','definition.candidate.sequence, 14').replace('e.candidate.sequence = 12','e.candidate.sequence = 13')
put(PROJECT/'infra/cloudflare/mir2-r2-bulk-upload/test/native-r17-s14-publication.test.mjs',test.encode())
test=(PROJECT/'scripts/test_native_r17_r2_delivery.py').read_text().replace("BASE / 'scripts/native_r17_r2_delivery.py'","BASE / 'scripts/native_r17_s14_r2_delivery.py'").replace("FIXTURE_ROOT = BASE / 'scripts/fixtures/native-r17-13'","FIXTURE_ROOT = BASE / 'scripts/fixtures/native-r17-s14'").replace("PREPARED_ROOT = FIXTURE_ROOT / 'prepared-snapshot-01'","PREPARED_ROOT = BASE / 'scripts/fixtures/native-r17-13/prepared-snapshot-01'").replace("PLAN['candidate']['sequence'], 13","PLAN['candidate']['sequence'], 14").replace("headers['x-mir2-sequence'] = '12'","headers['x-mir2-sequence'] = '13'").replace("b'\"sequence\": 13', b'\"sequence\": 14'","b'\"sequence\": 14', b'\"sequence\": 15'")
test=test.replace("FIXTURE_ROOT / 'predecessor12'","FIXTURE_ROOT / 'predecessor13'")
put(PROJECT/'scripts/test_native_r17_s14_r2_delivery.py',test.encode())
test=(PROJECT/'scripts/test_native_r17_interrupt.py').read_text().replace("scripts/native_r17_r2_delivery.py","scripts/native_r17_s14_r2_delivery.py")
put(PROJECT/'scripts/test_native_r17_s14_interrupt.py',test.encode())
record={'schema':'mir2.r17.s14.literal-admission.v1','candidate':definition['candidate'],'nativeSha256':native,'literalSha256':sha(literal),'literalBytes':len(literal),'sourcePlanSha256':sha(planraw),'rootVerificationSha256':sha(proofraw),'closedObjects':36,'unchangedGameObjects':30,'old13FilesModified':False}
put(OUT/'R2-14-ADMISSION.json',json.dumps(record,indent=2).encode())
print(json.dumps(record))
