"""Public local source/metadata audit only. Never executes SSH or decrypts a credential."""
from pathlib import Path
import ast
import hashlib
import json
import os
import stat
import time

OUT = Path(r"C:/mir2-playtest-releases/20261004-native-r18/cf-authorized-origin-prep-20261005-01")
BASE = OUT.parent
PUB = BASE/"current-signed-release-qa-01/publication-proof-01/verified"
NATIVE = BASE/"native-updater-preview-publication-01/prepared/infra/cloudflare/mir2-r2-bulk-upload/src/native-r17-publication-plan.json"
SSH = Path(r"C:/mir2-ui-repair-20260921/playtest-release-20260928/remote.py")
OLD = BASE/"origin-acceleration-implementation-01"
OLD_WRITER = BASE/"origin-acceleration-publisher-worker-01/origin-r17-append.py"
GAME = "6032ef8b3e27dd97bad0b20c8676ef9f185db64b"
ENGINE = "48454bba7623694ca7432613af52bee28e83970e"
SOURCE_SHA = "335e80d1692c105e9423fb53a54d000fe3bffc6bc24ef71bfeedbdbe9a6f8a16"
ROOT_SHA = "00984e502e2bcbe3fd32d6f6cf14818f8f46b57a1ba6294f6c8c06621b1f8fff"
NATIVE_SHA = "9fd816a5fdf26a937d3d94a5b031c9e992fbb104f49832ba31a703587a0385f8"
REMOTE_ROOT = "/srv/mir2-client-updates"
USER_STAGE = "/tmp/mir2-origin-preview13-20261005-01"
ROOT_STAGE = "/srv/.mir2-origin-preview13-20261005-01"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def ordinary(path):
    for parent in [*reversed(path.parents),path]:
        info=parent.lstat()
        assert not stat.S_ISLNK(info.st_mode) and not getattr(info,"st_file_attributes",0)&0x400,str(parent)
    info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink==1,str(path)
    return info

def public_hash(path,expected=None):
    before=ordinary(path)
    fd=os.open(path,os.O_RDONLY|getattr(os,"O_NOFOLLOW",0))
    hasher=hashlib.sha256(); size=0
    with os.fdopen(fd,"rb") as stream:
        opened=os.fstat(stream.fileno())
        assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(opened.st_dev,opened.st_ino,opened.st_size,opened.st_mtime_ns)
        while data:=stream.read(65536):
            hasher.update(data);size+=len(data)
        after=os.fstat(stream.fileno())
    current=ordinary(path)
    assert (opened.st_dev,opened.st_ino,opened.st_size,opened.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)==(current.st_dev,current.st_ino,current.st_size,current.st_mtime_ns)
    result={"source":str(path),"size":size,"sha256":hasher.hexdigest()}
    if expected:assert size==expected["size"] and result["sha256"]==expected["sha256"],str(path)
    return result

def output(name,data):
    encoded=(json.dumps(data,ensure_ascii=False,indent=2)+"\n").encode()
    path=OUT/name
    with path.open("xb") as stream:stream.write(encoded)
    return {"path":str(path),"size":len(encoded),"sha256":sha(encoded)}

source_raw=(PUB/"PUBLICATION-PLAN.json").read_bytes()
root_raw=(PUB/"ROOT-VERIFICATION.json").read_bytes()
native_raw=NATIVE.read_bytes()
assert sha(source_raw)==SOURCE_SHA and sha(root_raw)==ROOT_SHA and sha(native_raw)==NATIVE_SHA
source=json.loads(source_raw);root=json.loads(root_raw);native=json.loads(native_raw)
assert root["sequence"]==13 and root["sourceRevision"]==ENGINE
assert root["passed"] is True and root["cmsVerified"] is True and root["candidateVerified"] is True
assert source["candidate"]==native["candidate"] and native["knownPrevious"]["sequence"]==12
actual=[]
start=time.monotonic()
for row in source["objects"]:
    record=public_hash(Path(row["source"]),row)
    assert not row["path"].startswith("/") and ".." not in Path(row["path"]).parts
    actual.append({**row,"localByteVerified":True,"remoteTarget":REMOTE_ROOT+"/"+row["path"]})
assert len(actual)==36 and sum(x["size"] for x in actual)==817719767
local_elapsed=time.monotonic()-start

by_path={x["path"]:x for x in actual}
old_source=json.loads((BASE/"native-updater-preview-publication-01/baseline/source-publication-plan-12.json").read_bytes())
old_rows={x["path"]:(x["size"],x["sha256"]) for x in old_source["objects"]}
old30=[x for x in actual if old_rows.get(x["path"])==(x["size"],x["sha256"])]
new6=[x for x in actual if x not in old30]
assert len(old30)==30 and len(new6)==6
for item in new6:
    item["routeFamily"]="feeds" if item["path"].startswith("feeds/") else "installers" if item["path"].startswith("installers/") else "releases"
    item["sourceUrl"]="https://165.154.65.136.sslip.io/client-updates/"+item["path"]
    item["index"]=next(x["index"] for x in native["objects"] if x["path"]==item["path"])
    item["remoteUpload"]=USER_STAGE+"/"+str(item["index"]).zfill(2)+"-"+Path(item["path"]).name
assert sorted(x["index"] for x in new6)==[0,1,2,33,34,35]
new6.sort(key=lambda x:x["index"])
statement=json.loads(Path(by_path["releases/game-WN-CANDIDATE-20261004-invited-17/RELEASE-STATEMENT.json"]["source"]).read_bytes())
attestation=json.loads(Path(by_path["releases/game-WN-CANDIDATE-20261004-invited-17/BUILD-ATTESTATION.json"]["source"]).read_bytes())
version=json.loads(Path(by_path["releases/game-WN-CANDIDATE-20261004-invited-17/VERSION.json"]["source"]).read_bytes())
engine=json.loads(Path(by_path["releases/updater-50F99917916F10E8-s13/ENGINE.json"]["source"]).read_bytes())
assert statement["gitRevision"]==attestation["gitRevision"]==version["gitRevision"]==GAME
assert statement["worktreeDirty"] is False and attestation["worktreeDirty"] is False
assert engine["sourceRevision"]==ENGINE and engine["exeSha256"].lower()==by_path["releases/updater-50F99917916F10E8-s13/Mir2Updater.exe"]["sha256"]
assert by_path["releases/game-WN-CANDIDATE-20261004-invited-17/mir2-platform-windows.exe"]["size"]==111013376

ssh_source=SSH.read_bytes()
tree=ast.parse(ssh_source.decode())
known_hosts=Path.home()/".ssh"/"known_hosts"
known_public=public_hash(known_hosts)
# Only metadata for the protected DPAPI file. It is never opened/read/hashed.
credential=Path(r"C:/mir2-ui-repair-20260921/playtest-release-20260928/private/server-password.dpapi")
ci=credential.lstat()
assert stat.S_ISREG(ci.st_mode) and not stat.S_ISLNK(ci.st_mode) and not getattr(ci,"st_file_attributes",0)&0x400
known_call=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and ast.unparse(n.func).endswith("load_host_keys"))
reject=any(isinstance(n,ast.Call) and ast.unparse(n.func)=="paramiko.RejectPolicy" for n in ast.walk(tree))
connect=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and ast.unparse(n.func).endswith(".connect"))
assert reject and ast.unparse(connect.args[0])=="'165.154.65.136'"
auth={"helper":public_hash(SSH),"host":"165.154.65.136","username":"ubuntu",
 "mode":"existing DPAPI-protected password file through helper; never supplied on CLI",
 "credentialPathMetadataOnly":str(credential),"credentialFileExists":True,
 "credentialFileOpened":False,"credentialFileDecrypted":False,"credentialFileHashed":False,
 "privateKeysRead":False,"credentialValuesPrinted":False,
 "knownHosts":known_public,"knownHostExpression":ast.unparse(known_call.args[0]),
 "missingHostKeyPolicy":"RejectPolicy","freshAuthenticationAttempted":False,
 "safeReadonlyCall":["C:/Python313/python.exe","-B",str(SSH),"--user","ubuntu","--command-file","<root-owned-readonly-preflight.command>","--timeout","240"],
 "safeUploadCallNotExecuted":["C:/Python313/python.exe","-B",str(SSH),"--user","ubuntu","--upload-batch",str(OUT/"UPLOAD-BATCH.public.json"),"--timeout","240"],
 "historicalSuccess":"Same helper was invoked by verify-origin-closure.py to obtain the saved passed36/817657896B loopback TLS record; this phase does not re-authenticate."}

historical_paths=["HTTPS-36-SOURCE-VERIFICATION-01.json","publisher-preflight-01.json","publisher-apply-01.json","post-publication-02.json","verify-origin-closure.py","verify-origin-closure-01.command"]
history=[public_hash(OLD/n) for n in historical_paths]
https=json.loads((OLD/"HTTPS-36-SOURCE-VERIFICATION-01.json").read_bytes())
apply=json.loads((OLD/"publisher-apply-01.json").read_bytes())
assert https["passed"] is True and https["objects"]==36 and https["verifiedBytes"]==817657896
assert apply["status"]=="passed" and apply["mode"]=="apply" and apply["feedOrCandidateChangedByTool"] is False
assert len(apply["createdObjects"])==14
tools={
 "append12":public_hash(OLD_WRITER),
 "prepareInputs12":public_hash(OLD/"prepare-inputs.py"),
 "prepareInputs12RootCopy":"root-copy-01.command: guarded user->root private copy; hashes/owner/mode/NOFOLLOW; existing paths must not be blindly reused",
 "fullPublisherNotForThisAppend":public_hash(BASE/"origin-download-compatibility-plan-01/source/apps/game-client/windows-updater/scripts/deploy-server-release.py"),
 "priorTlsVerifier":public_hash(OLD/"remote-verify-serving.py"),
 "append12Scope":"Frozen4c60/toolsource6032 baseline, ROOT proof sequence12, and only fourteen DELIVERY objects. Do not override its production pins or run it to append six13 objects.",
 "requiredNewWriter":"Parent-reviewed fixed six-file append-only wrapper, retaining Guard/lock/O_NOFOLLOW/renameat2(RENAME_NOREPLACE)/fsync primitives. No generic destination, no replacement/delete/retire/latest operation.",
 "codeEvidenceLines":{
  "oldFixedRootSourceAndLock":"origin-r17-append.py:29-37",
  "oldFreshProofSequence12":"origin-r17-append.py:465-478",
  "existingPublisherLock":"origin-r17-append.py:328-354",
  "sameFilesystemNoReplace":"origin-r17-append.py:363-384",
  "currentFeedPhysicalDirectory":"origin-r17-append.py:569-590",
  "allConflictsBeforeWriteAndResumedExact":"origin-r17-append.py:784-827",
  "fullPublisherAlwaysExchangesFeed":"deploy-server-release.py:421-440"}}
issued_caddy={
 "config":"/etc/caddy/Caddyfile","staticRoot":REMOTE_ROOT,
 "discoveryPhysical":REMOTE_ROOT+"/feed-current",
 "issuedSourceMatcher":"/client-updates/releases/*",
 "issuedDefaultOtherPayload":"404",
 "sourceEvidence":"origin-download-compatibility-plan-01/source/apps/game-client/windows-updater/scripts/deploy-server-release.py:45-62",
 "actualCurrentConfigReadThisPhase":False,
 "requiredFreshRootCheck":"Read actual Caddyfile through root-owned sanitized readonly preflight; hash config and report only static route shape.",
 "potentialMissingFamilies":["/client-updates/feeds/s13-5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16/*",
 "/client-updates/installers/6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5/*"],
 "noBlindDeploymentClaim":"Existing issued config is evidence of a route gap, not a new observation of current production config. Parent owns any separately reviewed static-route addition/reload."}

input_plan={
 "schema":"mir2.native-origin-preview13.preparation.v1","operation":"PREPARATION_ONLY",
 "sourcePlan":{"path":str(PUB/"PUBLICATION-PLAN.json"),"sha256":SOURCE_SHA},
 "rootIssuedProof":{"path":str(PUB/"ROOT-VERIFICATION.json"),"sha256":ROOT_SHA,"issuer":"actual parent detached CMS+closed36 verifier; unchanged bytes","cmsReverifiedHere":False},
 "nativeLiteral":{"path":str(NATIVE),"sha256":NATIVE_SHA},
 "candidate":native["candidate"],"gameSource":GAME,"engineSource":ENGINE,
 "publicRoot":REMOTE_ROOT,"caddy":issued_caddy,
 "existingPublisherLock":"/var/backups/mir2-client-updates/.publisher.lock",
 "privateStageProposal":{"user":USER_STAGE,"root":ROOT_STAGE,"freshPathsRequired":True,"created":False},
 "protectedFeed12":{"physicalDirectory":REMOTE_ROOT+"/feed-current","urlDirectory":"/client-updates",
  "latest.json":{"size":1159,"sha256":native["knownPrevious"]["feedSha256"]},
  "latest.p7s":{"size":1614,"sha256":native["knownPrevious"]["signatureSha256"]},
  "sequence":12,"neverReplaceOrRebase":True},
 "objects":new6,"remoteStatus":"NOT_CHECKED_THIS_PHASE",
 "localObjectBytesVerified":sum(x["size"] for x in new6),
 "remoteMutationsExecuted":False,"sourceLatestSwitchExecuted":False,
 "prerequisites":[
  "Root fresh SSH-only readonly preflight: knownhost authentication, original30 and source6032, latest12 pair, allsix target states, disk/device/private-stage/lock and sanitized Caddy route shape.",
  "Actual trusted proof/raw source/native hashes exact; no manually minted CMS admission.",
  "All six targets absent or byte-exact ordinary root-owned existing files; any conflict/link/path escape rejects before first public mutation.",
  "Owned root700 private stage on same filesystem; input files created exclusively and rehashed with descriptor identity fences before promotion.",
  "Route gap resolved by parent separate static configuration review if current config matches issued source; latest12 discovery path preserved."],
 "appendOrder":[35,34,33,2,1,0],
 "appendInvariants":[
  "Acquire existing publisher lock without create/truncate; keep it through preflight/append/final verification.",
  "No symlink/hardlink/user-writable ancestors; fixed literals only, root ownership and expected file identity/size/SHA.",
  "Prepare/flush/fsync immutable source then renameat2 RENAME_NOREPLACE; exact-existing race may resume, conflict rejects; never overwrite or delete.",
  "Fchmod0444 final payloads and fsync source/target directory; revalidate bytes and latest12 before/after each change.",
  "Keep original30 game objects, source6032 metadata, old engine/Bootstrap and mutable feed-current byte/fingerprint unchanged.",
  "New immutable feed signature/json only inside exact feeds/s13...; never copy them to feed-current or root latest.*.",
  "Record each created/exact-existing result in new private exclusive receipt. Partial result permits exact-source reconcile, not rollback/delete or inferred completeness."],
 "verificationAfterRootAppend":[
  "Root static/TLS verifier reads all36 full objects at frozen originRelativePath mapping; exact status200, verifiedTLS, identity encoding, length, SHA, appropriate immutable cache; no external throughput claim.",
  "Read mutable latest12 pair before/after and retain exact byte/hash/fingerprint proof; no API or game-service changes.",
  "Stage13 may read immutable13 pair; promote deliberately refuses until parent separately authorizes and verifies current origin13 feed pair."],
 "authorizationBoundary":"This document authorizes nothing new; parent owns all actual source append/config/service/R2 operations."}
plan_record=output("APPEND-INPUTS.prepared.json",input_plan)
uploads=[[x["source"],x["remoteUpload"]] for x in new6]
uploads.extend([[str(PUB/"ROOT-VERIFICATION.json"),USER_STAGE+"/ROOT-VERIFICATION.json"],
 [str(PUB/"PUBLICATION-PLAN.json"),USER_STAGE+"/PUBLICATION-PLAN.json"],
 [str(OUT/"APPEND-INPUTS.prepared.json"),USER_STAGE+"/APPEND-INPUTS.prepared.json"]])
upload_record=output("UPLOAD-BATCH.public.json",uploads)
audit={
 "schema":"mir2.native-origin-preview13-local-review.v1","createdUnix":int(time.time()),
 "localFull36ByteCheck":{"objects":36,"bytes":817719767,"shaMatched":True,"elapsedSeconds":local_elapsed,
   "throughputClaim":False,"original30IdentityUnchanged":True,"original30Source":GAME},
 "localPublicObjects":actual,"sixNewObjects":new6,
 "sourceBindings":{"sourcePlan":public_hash(PUB/"PUBLICATION-PLAN.json"),
   "rootProof":public_hash(PUB/"ROOT-VERIFICATION.json"),"nativeLiteral":public_hash(NATIVE),
   "releaseStatementSource":statement["gitRevision"],"gameExeSha256":statement["exeSha256"].lower(),
   "gameManifestSha256":statement["packageManifestSha256"].lower()},
 "tools":tools,"sshMetadataOnly":auth,"historicalSSHProofs":history,
 "sourceRouteGate":issued_caddy,"plans":[plan_record,upload_record],
 "remoteNetworkCalls":0,"credentialsReadOrDecrypted":False,"remoteFilesWritten":False,
 "sourcesOrFrozenFiveChanged":False,"freshOriginOrSSHAccepted":False,
 "minorInspectionFailuresPreservedInNarrative":"Two known_hosts metadata lookups used assumed sibling paths and failed; exact helper AST establishes Path.home()/.ssh/known_hosts, then the actual public file was hashed successfully. No authentication guesses or attempts occurred."}
audit_record=output("READONLY-REVIEW-01.json",audit)
table=["index\tfamily\tsize\tsha256\tlocalSource\tremoteTarget"]
for x in new6:table.append("\t".join(str(x[k]) for k in ("index","routeFamily","size","sha256","source","remoteTarget")))
with (OUT/"SIX-OBJECTS.tsv").open("x",encoding="utf-8",newline="\n") as stream:stream.write("\n".join(table)+"\n")
print(json.dumps({"review":audit_record,"plan":plan_record,"uploads":upload_record,"sixBytes":sum(x["size"] for x in new6),
 "all36Bytes":817719767,"localHashSeconds":local_elapsed,"sshExecuted":False,"sourceLatestChanged":False},ensure_ascii=False))

