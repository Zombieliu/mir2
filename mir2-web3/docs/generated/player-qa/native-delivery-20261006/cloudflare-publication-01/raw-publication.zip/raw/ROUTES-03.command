sudo -n python3 -B - <<'PY'
import hashlib,importlib.util,json,os,pathlib,subprocess,sys,time
stage=pathlib.Path('/srv/.mir2-origin-preview13-20261005-01')
path=stage/'origin_preview13.py'
raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='bcf62dfa1542fefd9d861dfa09f3026d9a3e6615b0b708b14286aa31b3a139de'
spec=importlib.util.spec_from_file_location('verified_preview13_writer',path)
w=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=w
exec(compile(raw,str(path),'exec'),w.__dict__)
g,ops=w.boot()
with ops.lock(g,w.LOCK):
    feed=w.stable_feed(g)
    current=g.read(w.CONFIG,128*1024)
    assert w.digest(current)=='5be6b1666cfe380f5b90e08f7c36e4441f20e5c0a80bd5892c54bb20b3df6e16'
    old=b'\tencode zstd gzip'
    new=b'\t@mir2_non_download_compression not path /client-updates /client-updates/*\n\tencode @mir2_non_download_compression zstd gzip'
    assert current.count(old)==2 and b'@mir2_non_download_compression' not in current
    # Exactly the first/public site's encode directive changes; the second site is untouched.
    candidate=current.replace(old,new,1)
    w.write_new(g,ops,stage/'CADDY-ROUTES02-BEFORE.private',current)
    candidate_path=w.CONFIG.parent/'Caddyfile.mir2-native-uncompressed-20261006-01'
    w.write_new(g,ops,candidate_path,candidate,0o644)
    before=w.snapshot_services()
    pid=before['caddy.service']['MainPID']
    assert pid.isdigit() and int(pid)>1 and before['caddy.service']['ActiveState']=='active'
    environment={}
    for field in pathlib.Path('/proc',pid,'environ').read_bytes().split(b'\0'):
        if b'=' in field:
            name,value=field.split(b'=',1)
            environment[os.fsdecode(name)]=os.fsdecode(value)
    environment.setdefault('PATH',os.environ.get('PATH','/usr/bin:/bin'))
    result=subprocess.run(['caddy','validate','--config',str(candidate_path),'--adapter','caddyfile'],env=environment,capture_output=True,timeout=30)
    w.write_new(g,ops,stage/'CADDY-VALIDATE-03.private.stdout',result.stdout)
    w.write_new(g,ops,stage/'CADDY-VALIDATE-03.private.stderr',result.stderr)
    assert result.returncode==0,'caddy-native-identity-validation-failed'
    immediate=w.snapshot_services()
    w.same_pids(before,immediate)
    assert all(state['incoming']==0 for state in immediate.values()),'active-connections-reload-deferred'
    assert w.stable_feed(g)==feed and g.read(w.CONFIG,128*1024)==current and g.read(candidate_path,128*1024)==candidate
    with g.dir_fd(w.CONFIG.parent) as fd:
        os.rename(candidate_path.name,w.CONFIG.name,src_dir_fd=fd,dst_dir_fd=fd)
        os.fsync(fd)
    result=subprocess.run(['caddy','reload','--config',str(w.CONFIG),'--adapter','caddyfile'],env=environment,capture_output=True,timeout=30)
    w.write_new(g,ops,stage/'CADDY-RELOAD-03.private.stdout',result.stdout)
    w.write_new(g,ops,stage/'CADDY-RELOAD-03.private.stderr',result.stderr)
    assert result.returncode==0,'caddy-reload-failed-retained-backup'
    assert g.read(w.CONFIG,128*1024)==candidate and w.stable_feed(g)==feed
    w.same_pids(before,w.snapshot_services())
    receipt={'schema':'mir2.origin-native-identity-encoding.v1','passed':True,'createdUnix':int(time.time()),'oldConfigSha256':w.digest(current),'newConfigSha256':w.digest(candidate),'validationExit':0,'reloadExit':0,'scope':'public first-site encode excludes client-updates; second-site unchanged','environmentValuesExported':False,'incomingImmediatelyBeforeReload':{n:s['incoming'] for n,s in immediate.items()},'allServicePidsPreserved':True,'feed12FingerprintPreserved':True,'gatewayRestarted':False}
    w.write_new(g,ops,stage/'ROUTES-03.json',(json.dumps(receipt,indent=2)+'\n').encode())
    print(json.dumps(receipt))
PY
