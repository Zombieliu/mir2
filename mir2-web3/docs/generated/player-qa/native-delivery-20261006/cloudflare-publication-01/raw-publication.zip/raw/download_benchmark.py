"""Same immutable installer, same curl/options, full byte verification."""
import hashlib,json,subprocess,sys,time
from pathlib import Path

out=Path(__file__).resolve().parent/'HTTP-BENCHMARK-01'
out.mkdir(exist_ok=True)
mode=sys.argv[1]
assert mode in ('origin','cdn-cold','cdn-warm')
path='installers/6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5/Mir2Setup.exe'
base='https://165.154.65.136.sslip.io/client-updates/' if mode=='origin' else 'https://assets.mir2.obelisk.build/client-updates/'
body=out/(mode+'.body')
headers=out/(mode+'.headers')
assert not body.exists() and not headers.exists()
args=['curl.exe','--silent','--show-error','--fail','--proto','=https','--retry','0','--connect-timeout','15',
      '--max-time','900','--speed-limit','256','--speed-time','90','-H','Accept-Encoding: identity',
      '--dump-header',str(headers),'--output',str(body),'--write-out','%{json}',base+path]
start=time.monotonic()
r=subprocess.run(args,capture_output=True,timeout=930,check=False)
(out/(mode+'.curl.raw.json')).write_bytes(r.stdout)
(out/(mode+'.raw.stderr')).write_bytes(r.stderr)
value={'schema':'mir2.same-installer.actual-https-timing.v1','mode':mode,'exitCode':r.returncode,'elapsedSeconds':time.monotonic()-start,'url':base+path,'samePayload':True,'size':27496643}
if r.returncode==0:
    metadata=json.loads(r.stdout)
    data=body.read_bytes()
    sha=hashlib.sha256(data).hexdigest()
    value['sha256']=sha
    h={}
    for line in headers.read_text(encoding='iso-8859-1').splitlines():
        if ':' in line:
            key,v=line.split(':',1);h[key.lower()]=v.strip()
    value.update(httpStatus=metadata['http_code'],tlsVerified=metadata['ssl_verify_result']==0,
        totalSeconds=metadata['time_total'],ttfbSeconds=metadata['time_starttransfer'],bytesPerSecond=metadata['speed_download'],
        cacheState=h.get('x-mir2-native-cache'),cfRay=h.get('cf-ray'),encoding=h.get('content-encoding'),cacheControl=h.get('cache-control'))
    value['passed']=len(data)==27496643 and sha=='6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5' and metadata['http_code']==200 and value['tlsVerified'] and not value['encoding']
else:value['passed']=False
with (out/(mode+'.receipt.json')).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps(value),flush=True)
assert value['passed'],'actual benchmark failed; original bytes/metadata retained'
