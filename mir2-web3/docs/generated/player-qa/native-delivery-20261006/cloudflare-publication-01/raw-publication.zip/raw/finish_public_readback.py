import hashlib,json,urllib.request,urllib.error,runpy
from pathlib import Path

root=Path(__file__).resolve().parent
source=(root/'verify_public_latest.py').read_text()
source=source.replace("/'LATEST-PUBLIC-01'", "/'LATEST-PUBLIC-03'")
source=source.replace("headers={'Accept-Encoding':'identity'}", "headers={'Accept-Encoding':'identity','User-Agent':'ureq/2.12.1'}")
target=root/'verify_public_latest03.py'
with target.open('x') as f:f.write(source)
runpy.run_path(str(target),run_name='__main__')
out=root/'BIC-HTTP-01'
out.mkdir(exist_ok=False)
checks=[]
for path,method,status in [('latest.json','GET',200),('latest.p7s','GET',200),('latest.json','HEAD',200),('channels/invited.json','GET',403),('latest.json','POST',403)]:
    request=urllib.request.Request('https://assets.mir2.obelisk.build/client-updates/'+path,method=method,headers={'Accept-Encoding':'identity'})
    try:r=urllib.request.urlopen(request,timeout=30)
    except urllib.error.HTTPError as e:r=e
    with r:
        data=r.read(32769)
        headers={k.lower():v for k,v in r.headers.items()}
        assert r.code==status,(path,method,r.code)
        if method=='GET' and status==200:
            pin={'latest.json':'5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16','latest.p7s':'1227f6b40f103cbd4d29cdf989ddb1cb70f4d972b79c681ba7d0a2746493b003'}[path]
            assert hashlib.sha256(data).hexdigest()==pin
        if status==403:assert data==b'error code: 1010\n' or b'error code: 1010' in data
        name=str(len(checks)+1)
        (out/(name+'.headers.json')).write_text(json.dumps(headers,indent=2)+'\n')
        (out/(name+'.body')).write_bytes(data)
        checks.append({'path':path,'method':method,'status':r.code,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'tlsVerified':True,'userAgent':'Python-urllib/3.13'})
receipt={'schema':'mir2.actual-scoped-bic-http-acceptance.v1','passed':True,'checks':checks,'zoneBrowserIntegrityCheckStillOn':True,'postAndPrivatePathNotExempt':True,'actualNativeUpdaterExecuted':False}
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
