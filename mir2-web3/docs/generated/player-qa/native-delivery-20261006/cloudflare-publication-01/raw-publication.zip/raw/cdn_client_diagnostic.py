import hashlib,json,urllib.request,urllib.error,subprocess
from pathlib import Path

root=Path(__file__).resolve().parent
out=root/'CDN-CLIENT-01'
out.mkdir(exist_ok=False)
url='https://assets.mir2.obelisk.build/client-updates/latest.json'
checks=[]
for agent in ('Python-urllib/3.13','ureq/2.12.1','mir2-native-r17-ci/2'):
    name=agent.split('/')[0]
    body=out/(name+'.body')
    headers=out/(name+'.headers')
    r=subprocess.run(['curl.exe','--silent','--show-error','--max-time','25','--proto','=https','-A',agent,'-H','Accept-Encoding: identity','--dump-header',str(headers),'--output',str(body),'--write-out','%{http_code}',url],capture_output=True,timeout=35,check=False)
    assert r.returncode==0
    data=body.read_bytes()
    checks.append({'agent':agent,'status':int(r.stdout),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'serverHeadersRetained':True})
request=urllib.request.Request(url,headers={'Accept-Encoding':'identity'})
try:response=urllib.request.build_opener().open(request,timeout=30)
except urllib.error.HTTPError as e:response=e
with response:
    data=response.read(32769)
    (out/'urllib-default.private.body').write_bytes(data)
    headers={k.lower():v for k,v in response.headers.items()}
    (out/'urllib-default.headers.json').write_text(json.dumps(headers,indent=2)+'\n')
    checks.append({'agent':'actual-Python-urllib','status':response.code,'bytes':len(data),'server':headers.get('server'),'contentType':headers.get('content-type'),'cfMitigated':headers.get('cf-mitigated'),'sha256':hashlib.sha256(data).hexdigest()})
correct={'schema':'mir2.public-readback.failure-correction.v1','originalFailureReceiptPreserved':True,'actualCompletedChecksBefore403':2,'completedPair':'origin latest.json + latest.p7s','actualFailedEndpoint':'CDN latest.json','originalZeroCompletedOriginAttributionWasIncorrect':True,'networkSettingsChanged':False}
(root/'LATEST-PUBLIC-01/FAILURE-CORRECTION.json').write_text(json.dumps(correct,indent=2)+'\n')
receipt={'schema':'mir2.actual-cdn-client-header-diagnostic.v1','networkSettingsChanged':False,'checks':checks}
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
