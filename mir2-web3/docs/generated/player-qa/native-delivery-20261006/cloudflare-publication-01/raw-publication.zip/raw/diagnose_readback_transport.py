import hashlib,json,urllib.request,urllib.error,urllib.parse,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent/'READBACK-TRANSPORT-01'
out.mkdir(exist_ok=False)
url='https://165.154.65.136.sslip.io/client-updates/latest.json'
results=[]
for label,opener in [('default',urllib.request.build_opener()),('direct',urllib.request.build_opener(urllib.request.ProxyHandler({})))]:
    request=urllib.request.Request(url,headers={'Accept-Encoding':'identity'})
    try:response=opener.open(request,timeout=30)
    except urllib.error.HTTPError as error:response=error
    with response:
        data=response.read(32769)
        headers={k.lower():v for k,v in response.headers.items()}
        (out/(label+'.private.body')).write_bytes(data)
        results.append({'client':label,'status':response.code,'server':headers.get('server'),'contentType':headers.get('content-type'),'via':headers.get('via'),'blockedReason':headers.get('x-mitmproxy-blocked-reason'),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'tlsVerificationDisabled':False})
headers=out/'curl-python-ua.headers'
body=out/'curl-python-ua.body'
r=subprocess.run(['curl.exe','--silent','--show-error','--max-time','30','--proto','=https','-A','Python-urllib/3.13','-H','Accept-Encoding: identity','--dump-header',str(headers),'--output',str(body),'--write-out','%{http_code}',url],capture_output=True,timeout=40,check=False)
assert r.returncode==0
results.append({'client':'curl-same-python-user-agent','status':int(r.stdout),'sha256':hashlib.sha256(body.read_bytes()).hexdigest()})
receipt={'schema':'mir2.actual-readback-transport-diagnostic.v1','networkSettingsChanged':False,'proxyValuesExported':False,'configuredProxyKinds':sorted(urllib.request.getproxies()),'checks':results}
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
