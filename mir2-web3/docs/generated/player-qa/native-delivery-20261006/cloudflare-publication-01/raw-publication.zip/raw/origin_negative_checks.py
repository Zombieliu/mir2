"""Actual Linux checks inside one fresh root-owned fixture; never production writes."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

stage=Path('/srv/.mir2-origin-preview13-20261005-01')
spec=importlib.util.spec_from_file_location('preview13_writer',stage/'origin_preview13.py')
w=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=w
spec.loader.exec_module(w)
g,ops=w.boot()
objects=w.fixed_envelope(g)
checks=[{'name':'genuine-sealed-proof-closed36','passed':len(objects)==36}]
fixture=stage/'negative-fixtures'
assert not fixture.exists()
fixture.mkdir(mode=0o700)
public=fixture/'public'
inputs=fixture/'inputs'
public.mkdir(mode=0o755)
inputs.mkdir(mode=0o700)
original_public,original_stage,original_pins=w.PUBLIC,w.STAGE,w.PINS
pins=copy.deepcopy(original_pins)
w.PUBLIC,w.STAGE,w.PINS=public,inputs,pins

def pin(path,raw,index=None):
    value={'path':path,'size':len(raw),'sha256':w.digest(raw)}
    if index is not None:value['index']=index
    return value

def put(path,raw):
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o755)
    w.write_new(g,ops,path,raw)

def refuses(name,action):
    try:action()
    except (RuntimeError,w.sys.modules['origin_exact_guards'].Refusal):
        checks.append({'name':name,'passed':True})
    else:raise AssertionError('must-refuse:'+name)

feed_raw=(json.dumps({'sequence':12,'game':{'directory':'releases/game-WN-CANDIDATE-20261004-invited-17'},'expiresUnix':int(time.time())+3600})+'\n').encode()
put(public/'feed-current/latest.json',feed_raw)
put(public/'feed-current/latest.p7s',b'fixture-signature')
pins['feed12']={name:pin(name,raw) for name,raw in [('latest.json',feed_raw),('latest.p7s',b'fixture-signature')]}
feed_before=w.stable_feed(g)
refuses('path-escape',lambda:w.check_target(g,pin('../escape',b'a')))
refuses('absolute-path',lambda:w.check_target(g,pin('/etc/passwd',b'a')))
put(public/'conflict',b'actual')
refuses('conflicting-bytes',lambda:w.check_target(g,pin('conflict',b'expected')))
os.symlink(public/'conflict',public/'link')
refuses('symlink-leaf',lambda:w.check_target(g,pin('link',b'actual')))
os.link(public/'conflict',public/'hardlink')
refuses('hardlink-leaf',lambda:w.check_target(g,pin('hardlink',b'actual')))
bad_parent=public/'unsafe'
bad_parent.mkdir(mode=0o777)
os.chmod(bad_parent,0o777)
refuses('writable-parent',lambda:w.check_target(g,pin('unsafe/missing',b'a')))
names={0:'00-latest.json',1:'01-latest.p7s',2:'02-Mir2Setup.exe',33:'33-ENGINE.json',34:'34-ENGINE.p7s',35:'35-Mir2Updater.exe'}
new=[]
for index,name in names.items():
    raw=('source-'+str(index)).encode()
    put(inputs/name,raw)
    new.append(pin('new/'+name,raw,index))
pins['new']=new
old=[]
for i in range(30):
    raw=('old-'+str(i)).encode()
    name='original/file-'+str(i)
    put(public/name,raw)
    old.append(pin(name,raw))
put(public/new[-1]['path'],b'late-conflict')
before={p.relative_to(public).as_posix():p.read_bytes() for p in public.rglob('*') if p.is_file() and not p.is_symlink()}
refuses('all-six-conflicts-before-first-public-write',lambda:w.append(g,ops,old+new,feed_before))
after={p.relative_to(public).as_posix():p.read_bytes() for p in public.rglob('*') if p.is_file() and not p.is_symlink()}
assert before==after and not (public/new[0]['path']).exists()
checks.append({'name':'late-conflict-preserves-original30-and-feed','passed':True})
put(inputs/'rename-source',b'new-value')
put(public/'rename-target',b'old-value')
try:ops.rename_new(g,inputs/'rename-source',public/'rename-target')
except FileExistsError:pass
else:raise AssertionError('renameat2-must-not-overwrite')
assert (public/'rename-target').read_bytes()==b'old-value'
checks.append({'name':'actual-linux-renameat2-noreplace','passed':True})
put(inputs/'tampered',b'tampered')
refuses('full-hash-tamper-rejected',lambda:g.read(inputs/'tampered',128,pin('tampered',b'expected')))
assert all(c['passed'] for c in checks)
w.PUBLIC,w.STAGE,w.PINS=original_public,original_stage,original_pins
print(json.dumps({'schema':'mir2.origin-fixed6-linux-negative-checks.v1','passed':True,'checks':checks,'productionPublicMutations':False,'actualLinux':True}))
