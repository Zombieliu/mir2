import hashlib,json,urllib.request,urllib.error
from pathlib import Path

out=Path(__file__).resolve().parent/'LATEST-PUBLIC-03'
out.mkdir(exist_ok=False)
expected={'latest.json':{'size':1159,'sha256':'5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16'},'latest.p7s':{'size':1614,'sha256':'1227f6b40f103cbd4d29cdf989ddb1cb70f4d972b79c681ba7d0a2746493b003'}}
checks=[]
for label,base in [('origin','https://165.154.65.136.sslip.io/client-updates/'),('cdn','https://assets.mir2.obelisk.build/client-updates/')]:
    for name,pin in expected.items():
        request=urllib.request.Request(base+name,headers={'Accept-Encoding':'identity','User-Agent':'ureq/2.12.1'})
        with urllib.request.urlopen(request,timeout=30) as r:
            data=r.read(32769)
            headers={k.lower():v for k,v in r.headers.items()}
            assert r.status==200 and len(data)==pin['size'] and hashlib.sha256(data).hexdigest()==pin['sha256']
            assert headers.get('cache-control')=='no-store' and not headers.get('content-encoding')
            if label=='cdn':
                assert headers['x-mir2-sequence']=='13' and headers['x-mir2-feed-sha256']==expected['latest.json']['sha256'] and headers['x-mir2-native-cache']=='BYPASS'
            (out/(label+'-'+name)).write_bytes(data)
            (out/(label+'-'+name+'.headers.json')).write_text(json.dumps(headers,indent=2)+'\n')
            checks.append({'source':label,'path':name,'status':200,'bytes':len(data),'sha256':pin['sha256'],'tlsVerified':True,'cacheControl':'no-store','cdnPointer13Verified':label=='cdn'})
for method,path,status in [('GET','channels/invited.json',404),('GET','',404),('POST','latest.json',405)]:
    request=urllib.request.Request('https://assets.mir2.obelisk.build/client-updates/'+path,method=method,headers={'Accept-Encoding':'identity','User-Agent':'ureq/2.12.1'})
    try:urllib.request.urlopen(request,timeout=30)
    except urllib.error.HTTPError as r:
        assert r.code==status
        r.close()
    else:raise AssertionError('private-or-method-route-exposed')
    checks.append({'source':'cdn','method':method,'path':path,'status':status,'tlsVerified':True})
receipt={'schema':'mir2.native.actual-public13-readback.v1','passed':True,'sequence':13,'gameSource':'6032ef8b3e27dd97bad0b20c8676ef9f185db64b','engineSource':'48454bba7623694ca7432613af52bee28e83970e','checks':checks,'cmsPairMatchesRootIssuedActualProof':True,'newCmsReverificationHere':False,'affectedLaptopTested':False,'fullNativeInstallerExecuted':False}
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'passed':True,'sourceAndCdnCurrentSequence':13,'coherentPair':True,'noStoreAliases':True,'privatePointerBlocked':True,'writeMethodsBlocked':True}))
