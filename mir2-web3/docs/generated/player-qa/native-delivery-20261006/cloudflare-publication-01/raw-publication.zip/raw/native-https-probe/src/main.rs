use anyhow::{ensure, Context, Result};
use mir2_windows_updater::{model::hash, platform, update::{HttpsSource, Source}, CDN_FEED_URL, SIGNING_KEY};
use serde_json::json;
use std::{fs, io::Read, path::PathBuf, time::Duration};

fn get(agent: &ureq::Agent, path: &str, size: usize, pin: &str, dir: &PathBuf) -> Result<Vec<u8>> {
    let url = format!("https://assets.mir2.obelisk.build/client-updates/{path}");
    let r = agent.get(&url).set("Accept-Encoding", "identity").call()?;
    ensure!(r.status() == 200, "status");
    ensure!(r.header("Content-Encoding").is_none(), "encoding");
    if path.starts_with("latest.") { ensure!(r.header("X-Mir2-Sequence") == Some("13"), "actual CDN sequence"); }
    let headers = json!({"status":r.status(),"sequence":r.header("X-Mir2-Sequence"),"cache":r.header("X-Mir2-Native-Cache"),"cfRay":r.header("CF-Ray"),"etag":r.header("ETag"),"contentLength":r.header("Content-Length"),"cacheControl":r.header("Cache-Control")});
    let mut bytes = Vec::new();
    r.into_reader().take(size as u64 + 1).read_to_end(&mut bytes)?;
    ensure!(bytes.len() == size && hash(&bytes).eq_ignore_ascii_case(pin), "size/SHA");
    let name = path.rsplit('/').next().context("filename")?;
    fs::write(dir.join(name), &bytes)?;
    fs::write(dir.join(format!("{name}.headers.json")), serde_json::to_vec_pretty(&headers)?)?;
    Ok(bytes)
}
fn main() -> Result<()> {
    let dir = PathBuf::from(std::env::args_os().nth(1).context("owned output path")?);
    ensure!(!dir.exists(), "output already exists");
    fs::create_dir(&dir)?;
    let agent = ureq::AgentBuilder::new().redirects(0).timeout_connect(Duration::from_secs(8)).timeout_read(Duration::from_secs(30)).timeout_write(Duration::from_secs(30)).build();
    let feed = get(&agent, "latest.json", 1159, "5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16", &dir)?;
    let signature = get(&agent, "latest.p7s", 1614, "1227f6b40f103cbd4d29cdf989ddb1cb70f4d972b79c681ba7d0a2746493b003", &dir)?;
    platform::verify_cms(&feed, &signature, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let source = HttpsSource::new()?;
    let mut received = 0;
    let pair = source.discovery_pair(&mut |n| { received += n; Ok(()) })?;
    ensure!(pair.0 == feed && pair.1 == signature, "production HTTPS discovery pair");
    platform::verify_cms(&pair.0, &pair.1, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let engine = get(&agent, "releases/updater-50F99917916F10E8-s13/ENGINE.json", 421, "74ceb55740d0cf6fa83d1d044092c967602b631fee68f88e0a5718b2b65af38e", &dir)?;
    let engine_sig = get(&agent, "releases/updater-50F99917916F10E8-s13/ENGINE.p7s", 1614, "5f40d755fe824ddd0f530e93626289636ec44813589f5f9ea5436911c18ded24", &dir)?;
    platform::verify_cms(&engine, &engine_sig, SIGNING_KEY).map_err(anyhow::Error::msg)?;
    let _binary = get(&agent, "releases/updater-50F99917916F10E8-s13/Mir2Updater.exe", 1859072, "50f99917916f10e8e8f7e906de1d6e1fa7edb9a735f0ce95873bf5d196d426cf", &dir)?;
    let r = agent.get("https://assets.mir2.obelisk.build/client-updates/installers/6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5/Mir2Setup.exe").set("Accept-Encoding", "identity").set("Range", "bytes=0-1023").call()?;
    ensure!(r.status() == 206 && r.header("Content-Range") == Some("bytes 0-1023/27496643"), "actual TLS range");
    let mut prefix = Vec::new();
    r.into_reader().take(1025).read_to_end(&mut prefix)?;
    let mut original = Vec::new();
    fs::File::open("C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/bootstrap/artifacts/Numeron-Legend-of-Rebirth-20261005-r17-Bootstrap.exe")?.take(1024).read_to_end(&mut original)?;
    ensure!(prefix == original && prefix.len() == 1024, "range original bytes");
    fs::write(dir.join("bootstrap-prefix.bin"), &prefix)?;
    let receipt = json!({"schema":"mir2.actual-native-ureq-https-cms-readonly.v1","passed":true,"ureq":"2.12.1","defaultUserAgent":"ureq/2.12.1","tlsVerified":true,"directCdnSequence":13,"compiledCdnUrl":CDN_FEED_URL,"actualProductionDiscoveryPair":true,"discoveryReportedBytes":received,"feedCmsVerified":true,"engineCmsVerified":true,"engineFullShaVerified":true,"actualRange206OriginalBytes":true,"requestBytesStored":true,"gameLaunched":false,"gameInstallationTouched":false,"fullInstallerExecuted":false,"affectedLaptopTested":false});
    fs::write(dir.join("RESULT.json"), serde_json::to_vec_pretty(&receipt)?)?;
    println!("{receipt}");
    Ok(())
}
