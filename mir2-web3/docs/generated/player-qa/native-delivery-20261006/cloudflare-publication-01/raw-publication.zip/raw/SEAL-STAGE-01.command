sudo -n python3 -B - <<'PY'
import hashlib, json, os, pathlib, stat
def ident(i): return (i.st_dev,i.st_ino,i.st_mode,i.st_uid,i.st_nlink,i.st_size,i.st_mtime_ns,i.st_ctime_ns)
user=pathlib.Path('/tmp/mir2-origin-preview13-20261005-01')
root=pathlib.Path('/srv/.mir2-origin-preview13-20261005-01')
files=[{'name': '00-latest.json', 'size': 1159, 'sha256': '5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16'}, {'name': '01-latest.p7s', 'size': 1614, 'sha256': '1227f6b40f103cbd4d29cdf989ddb1cb70f4d972b79c681ba7d0a2746493b003'}, {'name': '02-Mir2Setup.exe', 'size': 27496643, 'sha256': '6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5'}, {'name': '33-ENGINE.json', 'size': 421, 'sha256': '74ceb55740d0cf6fa83d1d044092c967602b631fee68f88e0a5718b2b65af38e'}, {'name': '34-ENGINE.p7s', 'size': 1614, 'sha256': '5f40d755fe824ddd0f530e93626289636ec44813589f5f9ea5436911c18ded24'}, {'name': '35-Mir2Updater.exe', 'size': 1859072, 'sha256': '50f99917916f10e8e8f7e906de1d6e1fa7edb9a735f0ce95873bf5d196d426cf'}, {'name': 'ROOT-VERIFICATION.json', 'size': 424, 'sha256': '00984e502e2bcbe3fd32d6f6cf14818f8f46b57a1ba6294f6c8c06621b1f8fff'}, {'name': 'PUBLICATION-PLAN.json', 'size': 14098, 'sha256': '335e80d1692c105e9423fb53a54d000fe3bffc6bc24ef71bfeedbdbe9a6f8a16'}, {'name': 'APPEND-INPUTS.prepared.json', 'size': 10593, 'sha256': '80bcd2031d95d452fd687a564e5efb411c8bd35fc207257dfebc3221139e6d7d'}, {'name': 'guards.py', 'size': 47951, 'sha256': '10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811'}, {'name': 'origin_preview13.py', 'size': 15622, 'sha256': 'bcf62dfa1542fefd9d861dfa09f3026d9a3e6615b0b708b14286aa31b3a139de'}, {'name': 'ORIGIN-PINS.json', 'size': 2089, 'sha256': 'e4179958b3b2affa7be8aebba979d903404323ea622b2264acea5ba6fedb263f'}, {'name': 'origin_negative_checks.py', 'size': 4184, 'sha256': '4a36897237711077ec45d9d40b0d2198cbe119da9a34a6b9c4186f2a63b569e7'}]
assert os.geteuid()==0
info=user.lstat()
assert stat.S_ISDIR(info.st_mode) and info.st_uid==1000 and info.st_mode & 0o777 == 0o700, 'private-upload-stage-required'
assert not root.exists() and not root.is_symlink(), 'fresh-root-stage-required'
for p in [*reversed(root.parent.parents),root.parent]:
    i=p.lstat()
    assert stat.S_ISDIR(i.st_mode) and i.st_uid==0 and not i.st_mode & 0o022, 'root-parent-unsafe'
root.mkdir(mode=0o700)
rootfd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
userfd=os.open(user,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
assert ident(os.fstat(userfd))==ident(info), 'user-dir-open-race'
try:
    for pin in files:
        name=pin['name']
        assert pathlib.Path(name).name==name and name not in ('.','..')
        i=os.stat(name,dir_fd=userfd,follow_symlinks=False)
        assert stat.S_ISREG(i.st_mode) and i.st_uid==1000 and i.st_nlink==1 and not i.st_mode & 0o022
        source=os.open(name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=userfd)
        with os.fdopen(source,'rb') as stream:
            assert ident(os.fstat(stream.fileno()))==ident(i) and i.st_size==pin['size']
            data=stream.read(pin['size']+1)
            assert len(data)==pin['size'] and hashlib.sha256(data).hexdigest()==pin['sha256'], 'input-pin:'+name
            assert ident(os.fstat(stream.fileno()))==ident(i) and ident(os.stat(name,dir_fd=userfd,follow_symlinks=False))==ident(i)
        dest=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=rootfd)
        with os.fdopen(dest,'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        assert os.stat(name,dir_fd=rootfd,follow_symlinks=False).st_uid==0
    assert ident(user.lstat())==ident(info) and ident(os.fstat(userfd))==ident(info), 'user-stage-changed'
    os.fsync(rootfd)
    parentfd=os.open(root.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try: os.fsync(parentfd)
    finally: os.close(parentfd)
finally:
    os.close(rootfd)
    os.close(userfd)
print(json.dumps({'schema':'mir2.origin.fixed6-sealed-inputs.v1','passed':True,'files':files,'publicMutations':False}))
PY
