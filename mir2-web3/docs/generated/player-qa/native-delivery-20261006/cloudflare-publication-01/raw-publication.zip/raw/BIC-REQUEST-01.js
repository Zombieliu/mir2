async () => {
 const zone='99ce48eea9b3d1ae966cd998df110fd7';
 const prior=await cloudflare.request({method:'GET',path:'/zones/'+zone+'/rulesets'});
 if(!prior.success || prior.result.some(r=>r.phase==='http_config_settings' && r.kind==='zone')) throw new Error('Configuration entrypoint appeared; reconcile before writing');
 const body={
  "name": "Mir2 native download compatibility",
  "kind": "zone",
  "phase": "http_config_settings",
  "rules": [
    {
      "action": "set_config",
      "action_parameters": {
        "bic": false
      },
      "description": "Mir2 public native downloads: desktop HTTP clients",
      "enabled": true,
      "expression": "(http.host eq \"assets.mir2.obelisk.build\" and http.request.method in {\"GET\" \"HEAD\"} and (http.request.uri.path in {\"/client-updates/latest.json\" \"/client-updates/latest.p7s\"} or starts_with(http.request.uri.path, \"/client-updates/releases/\") or starts_with(http.request.uri.path, \"/client-updates/feeds/\") or starts_with(http.request.uri.path, \"/client-updates/installers/\")))",
      "ref": "mir2_public_native_downloads_bic"
    }
  ]
};
 const r=await cloudflare.request({method:'POST',path:'/zones/'+zone+'/rulesets',body});
 return {schema:'mir2.native.actual-scoped-browser-check-create.v1',success:r.success,status:r.status,result:r.result,errors:r.errors,messages:r.messages};
}
