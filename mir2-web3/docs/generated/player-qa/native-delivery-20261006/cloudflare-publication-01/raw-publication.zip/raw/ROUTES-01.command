sudo -n python3 -B /srv/.mir2-origin-preview13-20261005-01/origin_preview13.py routes
