import hashlib,json,subprocess,time
from pathlib import Path

root=Path(__file__).resolve().parent
out=root/'HTTP-RANGE-01'
out.mkdir(exist_ok=False)
url='https://assets.mir2.obelisk.build/client-updates/installers/6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5/Mir2Setup.exe'
baseline=(root/'HTTP-BENCHMARK-01/origin.body').read_bytes()
assert len(baseline)==27496643 and hashlib.sha256(baseline).hexdigest()=='6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5'
checks=[]

def get(name,body,extra):
    header=out/(name+'.headers')
    args=['curl.exe','--silent','--show-error','--proto','=https','--retry','0','--connect-timeout','15','--max-time','180',
          '-H','Accept-Encoding: identity','--dump-header',str(header),'--output',str(body),'--write-out','%{json}',*extra,url]
    start=time.monotonic()
    r=subprocess.run(args,capture_output=True,timeout=200,check=False)
    (out/(name+'.curl.raw.json')).write_bytes(r.stdout)
    (out/(name+'.raw.stderr')).write_bytes(r.stderr)
    assert r.returncode==0,name+':curl-failed'
    meta=json.loads(r.stdout)
    assert meta['ssl_verify_result']==0
    h={}
    for line in header.read_text(encoding='iso-8859-1').splitlines():
        if ':' in line:
            key,value=line.split(':',1);h[key.lower()]=value.strip()
    assert not h.get('content-encoding')
    checks.append({'name':name,'status':meta['http_code'],'tlsVerified':True,'elapsedSeconds':time.monotonic()-start,'wireBytes':meta['size_download'],'contentRange':h.get('content-range'),'contentLength':h.get('content-length'),'cacheState':h.get('x-mir2-native-cache'),'etag':h.get('etag'),'passed':False})
    return meta,h,checks[-1]

partial=out/'interrupted.part'
meta,headers,check=get('prefix',partial,['--range','0-1048575'])
assert meta['http_code']==206 and headers['content-range']=='bytes 0-1048575/27496643' and partial.read_bytes()==baseline[:1048576]
etag=headers['etag'];assert etag.startswith('"') and not etag.startswith('W/')
check['passed']=True
prefix_identity={'bytes':partial.stat().st_size,'sha256':hashlib.sha256(partial.read_bytes()).hexdigest()}
meta,headers,check=get('actual-resume',partial,['--continue-at','-','-H','If-Range: '+etag])
assert meta['http_code']==206 and headers['content-range']=='bytes 1048576-27496642/27496643' and headers['etag']==etag
assert meta['size_download']==27496643-1048576 and partial.read_bytes()==baseline
check['passed']=True
meta,headers,check=get('suffix',out/'suffix.body',['--range','-1024'])
assert meta['http_code']==206 and (out/'suffix.body').read_bytes()==baseline[-1024:] and headers['content-range']=='bytes 27495619-27496642/27496643'
check['passed']=True
meta,headers,check=get('past-end',out/'past-end.body',['--range','27496643-'])
assert meta['http_code']==416 and headers['content-range']=='bytes */27496643'
check['passed']=True
meta,headers,check=get('stale-if-range-full',out/'fallback.body',['--range','0-1023','-H','If-Range: "deliberately-stale-fixed-fixture"'])
assert meta['http_code']==200 and 'content-range' not in headers and (out/'fallback.body').read_bytes()==baseline and check['cacheState']=='BYPASS'
check['passed']=True
receipt={'schema':'mir2.native.actual-https-range-acceptance.v1','passed':all(c['passed'] for c in checks),'checks':checks,'prefixBeforeResume':prefix_identity,'resumedBytes':27496643-1048576,'reconstructedSha256':hashlib.sha256(partial.read_bytes()).hexdigest(),'immutableSignedArtifactVerified':True,'nativeInstallerExecuted':False,'affectedLaptopTested':False,'noGameOrSaveMutation':True}
(out/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
