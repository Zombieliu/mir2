sudo -n python3 -B - <<'PY'
import json, pathlib, stat
result={}
for label in ('/tmp/mir2-origin-preview13-20261005-01','/srv/.mir2-origin-preview13-20261005-01'):
    path=pathlib.Path(label)
    values=[]
    for p in sorted(path.iterdir()):
        i=p.lstat()
        values.append({'name':p.name,'mode':oct(stat.S_IMODE(i.st_mode)),'uid':i.st_uid,'nlink':i.st_nlink,'size':i.st_size,'regular':stat.S_ISREG(i.st_mode)})
    result[label]=values
print(json.dumps(result))
PY
