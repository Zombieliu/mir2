"""Root's fixed six-file append; no general deployment or credentials."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

PINS = {'prepared': '80bcd2031d95d452fd687a564e5efb411c8bd35fc207257dfebc3221139e6d7d', 'guards': '10693760a24973f896caa3f5ac6b1f59e02a32f6e9977cea0dbaa65adbaa0811', 'proof': '00984e502e2bcbe3fd32d6f6cf14818f8f46b57a1ba6294f6c8c06621b1f8fff', 'publication': '335e80d1692c105e9423fb53a54d000fe3bffc6bc24ef71bfeedbdbe9a6f8a16', 'config': 'c9eb1149dd23bed11b94b921e812ff111822410e487c4ef61b3c9bb351c649bd', 'feed12': {'latest.json': {'size': 1159, 'sha256': '7efdddf34fbf58ffa0bf8c4f7fcb1a9ad2bac869cb3f003cea0a0c9c53356c88'}, 'latest.p7s': {'size': 1614, 'sha256': '7dd131dddcef9107ea0c80363cc9ca44746603c586a1e23e00ff6aa178006916'}}, 'new': [{'index': 0, 'path': 'feeds/s13-5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16/latest.json', 'size': 1159, 'sha256': '5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16'}, {'index': 1, 'path': 'feeds/s13-5b2a6d21874fabe9d405388f6793e2f6673f9ce7e0c9ce967b0e327a28058c16/latest.p7s', 'size': 1614, 'sha256': '1227f6b40f103cbd4d29cdf989ddb1cb70f4d972b79c681ba7d0a2746493b003'}, {'index': 2, 'path': 'installers/6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5/Mir2Setup.exe', 'size': 27496643, 'sha256': '6175bd72f273c2f00d96117183fc1bf4d1f987c15455a1064e4f0e975ca70af5'}, {'index': 33, 'path': 'releases/updater-50F99917916F10E8-s13/ENGINE.json', 'size': 421, 'sha256': '74ceb55740d0cf6fa83d1d044092c967602b631fee68f88e0a5718b2b65af38e'}, {'index': 34, 'path': 'releases/updater-50F99917916F10E8-s13/ENGINE.p7s', 'size': 1614, 'sha256': '5f40d755fe824ddd0f530e93626289636ec44813589f5f9ea5436911c18ded24'}, {'index': 35, 'path': 'releases/updater-50F99917916F10E8-s13/Mir2Updater.exe', 'size': 1859072, 'sha256': '50f99917916f10e8e8f7e906de1d6e1fa7edb9a735f0ce95873bf5d196d426cf'}]}
STAGE = Path('/srv/.mir2-origin-preview13-20261005-01')
PUBLIC = Path('/srv/mir2-client-updates')
LOCK = Path('/var/backups/mir2-client-updates/.publisher.lock')
CONFIG = Path('/etc/caddy/Caddyfile')
GAME = '6032ef8b3e27dd97bad0b20c8676ef9f185db64b'
ENGINE = '48454bba7623694ca7432613af52bee28e83970e'
OLD_MATCH = b'@mir2_native_payload path /client-updates/releases/*'
NEW_MATCH = OLD_MATCH + b' /client-updates/feeds/* /client-updates/installers/*'

def require(value, label):
    if not value:
        raise RuntimeError(label)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def fingerprint(info):
    return (info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)

def boot():
    require(sys.platform.startswith('linux') and os.geteuid()==0, 'linux-root-required')
    require(Path(__file__).resolve().parent == STAGE, 'fixed-root-stage-required')
    for parent in [*reversed(STAGE.parents),STAGE]:
        info=parent.lstat()
        require(stat.S_ISDIR(info.st_mode) and info.st_uid==0 and not info.st_mode & 0o022, 'unsafe-root-stage-parent')
    require(not STAGE.stat().st_mode & 0o077, 'root-stage-not-private')
    path=STAGE/'guards.py'
    before=path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_uid==0 and before.st_nlink==1 and not before.st_mode & 0o077, 'unsafe-guard-file')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
    with os.fdopen(fd,'rb') as stream:
        require(fingerprint(os.fstat(stream.fileno()))==fingerprint(before), 'guard-open-race')
        raw=stream.read(131073)
        require(len(raw)<=131072 and digest(raw)==PINS['guards'], 'guard-source-mismatch')
        require(fingerprint(os.fstat(stream.fileno()))==fingerprint(before) and fingerprint(path.lstat())==fingerprint(before), 'guard-read-race')
    spec=importlib.util.spec_from_file_location('origin_exact_guards',path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    # Execute exactly the bytes just verified, with no second pathname read.
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module.Guard(),module.Operations()

def write_new(g,ops,path,data,mode=0o600):
    g.parents(path)
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
        os.fchmod(stream.fileno(),mode)
        os.fsync(stream.fileno())
    g.file_info(path)
    ops.sync_dir(g,path.parent)

def snapshot_services():
    names=['caddy.service','mir2-gateway.service','mir2-playtest.service','mir2-periodic-qa.service',
           'mir2-commonware-gateway.service','mir2-admin-api.service','mir2-zone-ucloud.service']
    listeners=subprocess.run(['ss','-Hlntp'],capture_output=True,text=True,check=True).stdout.splitlines()
    connections=subprocess.run(['ss','-Hntp','state','established'],capture_output=True,text=True,check=True).stdout.splitlines()
    states={}
    for name in names:
        result=subprocess.run(['systemctl','show',name,'--property=MainPID,ActiveState'],capture_output=True,text=True,check=True)
        state=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
        pid=state['MainPID']
        ports={line.split()[3].rsplit(':',1)[-1] for line in listeners if 'pid='+pid+',' in line}
        state['incoming']=sum(1 for line in connections if 'pid='+pid+',' in line and line.split()[2].rsplit(':',1)[-1] in ports)
        states[name]=state
    return states

def same_pids(before,after):
    require(all(before[n]['MainPID']==after[n]['MainPID'] and before[n]['ActiveState']==after[n]['ActiveState'] for n in before),'service-pid-or-state-changed')

def stable_feed(g):
    identities={}
    for name,pin in PINS['feed12'].items():
        path=PUBLIC/'feed-current'/name
        raw=g.read(path,32768,pin)
        identities[name]=g.identity(g.file_info(path))
        if name=='latest.json':
            value=json.loads(raw)
            require(value['sequence']==12 and value['game']['directory']=='releases/game-WN-CANDIDATE-20261004-invited-17','feed12-game-binding')
            require(value['expiresUnix']>=int(time.time()),'feed12-expired')
    return identities

def fixed_envelope(g):
    names={'ROOT-VERIFICATION.json':'proof','PUBLICATION-PLAN.json':'publication','APPEND-INPUTS.prepared.json':'prepared'}
    values={}
    for name,key in names.items():
        raw=g.read(STAGE/name,32*1024*1024)
        require(digest(raw)==PINS[key],'envelope-hash:'+name)
        values[name]=json.loads(raw)
    proof=values['ROOT-VERIFICATION.json']
    require(proof['passed'] is True and proof['cmsVerified'] is True and proof['candidateVerified'] is True and proof['sequence']==13 and proof['sourceRevision']==ENGINE,'genuine-root-proof-binding')
    publication=values['PUBLICATION-PLAN.json']
    objects=publication['objects']
    require(len(objects)==36 and len({o['path'] for o in objects})==36,'closed36-required')
    closure=sorted([{k:o[k] for k in ('path','size','sha256')} for o in objects],key=lambda o:o['path'])
    canonical=(json.dumps(closure,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
    require(digest(canonical)==proof['objectsSha256'],'closed36-proof-digest')
    selected={o['path']:o for o in objects}
    for obj in PINS['new']:
        bound=selected[obj['path']]
        require(all(bound[k]==obj[k] for k in ('size','sha256')),'fixed6-proof-mismatch')
    require(values['APPEND-INPUTS.prepared.json']['gameSource']==GAME,'game-source-preserved')
    feed=g.read(STAGE/'00-latest.json',32768,PINS['new'][0])
    value=json.loads(feed)
    require(value['sequence']==13 and value['expiresUnix']>=int(time.time()),'feed13-expired-or-mismatch')
    return objects

def ensure_parent(g,ops,path):
    require(path.is_relative_to(PUBLIC) and '..' not in path.parts,'target-escape')
    relative=path.relative_to(PUBLIC)
    current=PUBLIC
    for part in relative.parts:
        require(re.fullmatch(r'[A-Za-z0-9_.-]+',part) and part not in ('.','..'),'target-component')
        current=current/part
        if not current.exists() and not current.is_symlink():
            g.directory(current.parent)
            try:
                os.mkdir(current,0o755)
                ops.sync_dir(g,current.parent)
            except FileExistsError:
                pass
        g.directory(current)

def check_target(g,obj):
    target=PUBLIC/obj['path']
    require(target.is_relative_to(PUBLIC) and '..' not in Path(obj['path']).parts and not Path(obj['path']).is_absolute(),'target-escape')
    # Every existing ancestor is checked even for an absent leaf.
    current=PUBLIC
    g.directory(current)
    for part in Path(obj['path']).parts[:-1]:
        current=current/part
        if current.exists() or current.is_symlink():
            g.directory(current)
        else:
            break
    if target.exists() or target.is_symlink():
        g.match(target,obj)
        require(stat.S_IMODE(g.file_info(target).st_mode)==0o444,'new-target-not-public-immutable')
        return 'exact-existing'
    return 'absent'

def append(g,ops,objects,feed_before):
    new_names={o['path'] for o in PINS['new']}
    baseline={o['path']:g.match(PUBLIC/o['path'],o) for o in objects if o['path'] not in new_names}
    require(len(baseline)==30,'original30-required')
    for obj in PINS['new']:
        source=STAGE/({0:'00-latest.json',1:'01-latest.p7s',2:'02-Mir2Setup.exe',33:'33-ENGINE.json',34:'34-ENGINE.p7s',35:'35-Mir2Updater.exe'}[obj['index']])
        g.match(source,obj)
        check_target(g,obj)
    require(stable_feed(g)==feed_before,'feed-changed-before-append')
    events=[]
    by_index={o['index']:o for o in PINS['new']}
    for index in (35,34,33,2,1,0):
        obj=by_index[index]
        status=check_target(g,obj)
        if status=='absent':
            ensure_parent(g,ops,(PUBLIC/obj['path']).parent)
            original=STAGE/({0:'00-latest.json',1:'01-latest.p7s',2:'02-Mir2Setup.exe',33:'33-ENGINE.json',34:'34-ENGINE.p7s',35:'35-Mir2Updater.exe'}[index])
            staged=STAGE/f'append-{index:02}'
            if staged.exists() or staged.is_symlink():
                g.match(staged,obj)
                require(stat.S_IMODE(g.file_info(staged).st_mode)==0o444,'staged-mode-conflict')
            else:
                data=g.read(original,128*1024*1024,obj)
                write_new(g,ops,staged,data,0o444)
            g.match(staged,obj)
            require(stable_feed(g)==feed_before,'feed-changed-during-append')
            try:
                ops.rename_new(g,staged,PUBLIC/obj['path'])
                status='created'
            except FileExistsError:
                check_target(g,obj)
                status='raced-exact-existing'
        check_target(g,obj)
        require(stable_feed(g)==feed_before,'feed-changed-after-append')
        event={'index':index,'path':obj['path'],'status':status,'size':obj['size'],'sha256':obj['sha256']}
        audit=STAGE/f'APPEND-EVENT-{index:02}.json'
        if audit.exists() or audit.is_symlink():
            previous=json.loads(g.read(audit,32768))
            require(all(previous[k]==event[k] for k in ('index','path','size','sha256')) and previous['status'] in ('created','exact-existing','raced-exact-existing'),'append-audit-conflict')
        else:
            write_new(g,ops,audit,(json.dumps(event,sort_keys=True)+'\n').encode())
        events.append(event)
    for obj in objects:
        identity=g.match(PUBLIC/obj['path'],obj)
        if obj['path'] in baseline:
            require(identity==baseline[obj['path']],'original30-fingerprint-changed')
    return events

def routes(g,ops,feed_before):
    current=g.read(CONFIG,128*1024)
    require(digest(current)==PINS['config'],'caddy-old-config-conflict')
    require(current.count(OLD_MATCH)==1 and NEW_MATCH not in current,'caddy-matcher-ambiguous')
    candidate=current.replace(OLD_MATCH,NEW_MATCH)
    backup=STAGE/'CADDY-BEFORE.private'
    write_new(g,ops,backup,current)
    path=CONFIG.parent/'Caddyfile.mir2-preview13-20261005-01'
    write_new(g,ops,path,candidate,0o644)
    result=subprocess.run(['caddy','validate','--config',str(path),'--adapter','caddyfile'],capture_output=True,timeout=30)
    write_new(g,ops,STAGE/'CADDY-VALIDATE.private.stdout',result.stdout)
    write_new(g,ops,STAGE/'CADDY-VALIDATE.private.stderr',result.stderr)
    require(result.returncode==0,'caddy-candidate-validation-failed')
    states=snapshot_services()
    require(all(s['incoming']==0 for s in states.values()),'active-incoming-connections-reload-deferred')
    require(stable_feed(g)==feed_before and digest(g.read(CONFIG,128*1024))==PINS['config'],'caddy-pre-reload-conflict')
    # Only the validated, exact one-line static route edit replaces the config.
    with g.dir_fd(CONFIG.parent) as fd:
        os.rename(path.name,CONFIG.name,src_dir_fd=fd,dst_dir_fd=fd)
        os.fsync(fd)
    result=subprocess.run(['caddy','reload','--config',str(CONFIG),'--adapter','caddyfile'],capture_output=True,timeout=30)
    write_new(g,ops,STAGE/'CADDY-RELOAD.private.stdout',result.stdout)
    write_new(g,ops,STAGE/'CADDY-RELOAD.private.stderr',result.stderr)
    require(result.returncode==0,'caddy-reload-failed-retained-config-backup')
    require(g.read(CONFIG,128*1024)==candidate,'caddy-readback-conflict')
    same_pids(states,snapshot_services())
    require(stable_feed(g)==feed_before,'feed-changed-after-route-reload')
    return {'oldSha256':digest(current),'newSha256':digest(candidate),'validationExit':0,'reloadExit':0,'incomingAtReload':{n:s['incoming'] for n,s in states.items()},'allPidsUnchanged':True}

def main():
    require(len(sys.argv)==2 and sys.argv[1] in ('preflight','append','routes'),'fixed-operation-required')
    mode=sys.argv[1]
    g,ops=boot()
    g.directory(PUBLIC)
    g.directory(STAGE,private=True)
    require(STAGE.stat().st_dev==PUBLIC.stat().st_dev,'stage-filesystem-mismatch')
    states=snapshot_services()
    with ops.lock(g,LOCK):
        feed_before=stable_feed(g)
        objects=fixed_envelope(g)
        result={'schema':'mir2.origin-preview13.fixed6.v1','operation':mode,'gameSource':GAME,'engineSource':ENGINE,'rootProofSha256':PINS['proof'],'createdUnix':int(time.time()),'changedCurrentFeed':False,'gameServiceRestart':False}
        if mode=='append':
            result['events']=append(g,ops,objects,feed_before)
        elif mode=='routes':
            result['caddy']=routes(g,ops,feed_before)
        else:
            selected={o['path'] for o in PINS['new']}
            result['objects']=[{'path':o['path'],'status':check_target(g,o) if o['path'] in selected else 'original-exact','identity':None if o['path'] in selected else g.match(PUBLIC/o['path'],o)} for o in objects]
            for obj in PINS['new']:
                name={0:'00-latest.json',1:'01-latest.p7s',2:'02-Mir2Setup.exe',33:'33-ENGINE.json',34:'34-ENGINE.p7s',35:'35-Mir2Updater.exe'}[obj['index']]
                g.match(STAGE/name,obj)
            require(digest(g.read(CONFIG,128*1024))==PINS['config'],'caddy-preflight-conflict')
        require(stable_feed(g)==feed_before,'feed-final-conflict')
        same_pids(states,snapshot_services())
        result.update(passed=True,feed12FingerprintPreserved=True,allServicePidsPreserved=True)
        raw=(json.dumps(result,indent=2)+'\n').encode()
        write_new(g,ops,STAGE/f'{mode.upper()}-01.json',raw)
        print(raw.decode(),end='')

if __name__=='__main__':
    main()
