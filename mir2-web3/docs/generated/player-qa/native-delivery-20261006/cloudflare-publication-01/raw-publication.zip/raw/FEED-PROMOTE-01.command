sudo -n python3 -B - <<'PY'
import ctypes,hashlib,http.client,importlib.util,json,os,pathlib,socket,ssl,sys,time
stage=pathlib.Path('/srv/.mir2-origin-preview13-20261005-01')
path=stage/'origin_preview13.py'
raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='bcf62dfa1542fefd9d861dfa09f3026d9a3e6615b0b708b14286aa31b3a139de'
spec=importlib.util.spec_from_file_location('verified_preview13_writer',path)
w=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=w
exec(compile(raw,str(path),'exec'),w.__dict__)
g,ops=w.boot()
class LocalTLS(http.client.HTTPSConnection):
    def connect(self):
        self.sock=self._context.wrap_socket(socket.create_connection(('127.0.0.1',self.port),self.timeout),server_hostname=self.host)
with ops.lock(g,w.LOCK):
    before=w.snapshot_services()
    old_identity=w.stable_feed(g)
    assert w.digest(g.read(w.CONFIG,128*1024))=='4f54f9ca961771de96efff9b24d983815cfbbf5c69369bed9da5e9c61dec4632'
    objects=w.fixed_envelope(g)
    # Admission remains the genuine signed13 proof; every one of its36 source objects is rechecked.
    for obj in objects:g.match(w.PUBLIC/obj['path'],obj)
    by_index={o['index']:o for o in w.PINS['new']}
    expected={name:g.read(stage/source,32768,by_index[index]) for index,name,source in [(0,'latest.json','00-latest.json'),(1,'latest.p7s','01-latest.p7s')]}
    prepared=stage/'feed13-ready'
    assert not prepared.exists() and not prepared.is_symlink(),'fresh-feed-stage-required'
    prepared.mkdir(mode=0o700)
    for name,data in expected.items():w.write_new(g,ops,prepared/name,data,0o444)
    os.chmod(prepared,0o755)
    ops.sync_dir(g,prepared)
    ops.sync_dir(g,stage)
    current=w.PUBLIC/'feed-current'
    g.directory(current)
    assert prepared.stat().st_dev==current.stat().st_dev and w.stable_feed(g)==old_identity
    rename=ctypes.CDLL(None,use_errno=True).renameat2
    rename.argtypes=(ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint)
    rename.restype=ctypes.c_int
    with g.dir_fd(stage) as source_fd,g.dir_fd(w.PUBLIC) as target_fd:
        assert rename(source_fd,b'feed13-ready',target_fd,b'feed-current',2)==0,'atomic-feed-exchange-failed'
        os.fsync(source_fd);os.fsync(target_fd)
    checks=[]
    for name,data in expected.items():
        assert g.read(current/name,32768)==data
        assert g.identity(g.file_info(prepared/name))==old_identity[name]
        assert g.read(prepared/name,32768,w.PINS['feed12'][name])
        connection=LocalTLS('165.154.65.136.sslip.io',timeout=30,context=ssl.create_default_context())
        try:
            connection.request('GET','/client-updates/'+name,headers={'Host':'165.154.65.136.sslip.io','Accept-Encoding':'identity'})
            response=connection.getresponse()
            received=response.read(32769)
            assert response.status==200 and received==data and 'no-store' in response.getheader('Cache-Control','') and response.getheader('Content-Length')==str(len(data))
            checks.append({'name':name,'status':200,'bytes':len(data),'sha256':w.digest(data),'tlsVerified':True,'cacheControl':'no-store'})
        finally:connection.close()
    w.same_pids(before,w.snapshot_services())
    receipt={'schema':'mir2.native.current-origin-feed13.v1','passed':True,'createdUnix':int(time.time()),'sequence':13,'gameSource':w.GAME,'engineSource':w.ENGINE,'rootProofSha256':w.PINS['proof'],'complete36SourceHashesChecked':True,'oldFeed12BytesAndFingerprintsPreserved':True,'oldFeedPrivateBackup':str(prepared),'allServicePidsPreserved':True,'caddyReloaded':False,'gatewayRestarted':False,'checks':checks}
    w.write_new(g,ops,stage/'FEED-PROMOTE-01.json',(json.dumps(receipt,indent=2)+'\n').encode())
    print(json.dumps(receipt))
PY
