sudo -n python3 -B - <<'PY'
import hashlib,importlib.util,json,pathlib,sys
path=pathlib.Path('/srv/.mir2-origin-preview13-20261005-01/origin_preview13.py')
raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='bcf62dfa1542fefd9d861dfa09f3026d9a3e6615b0b708b14286aa31b3a139de'
spec=importlib.util.spec_from_file_location('verified_preview13_writer',path)
w=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=w
exec(compile(raw,str(path),'exec'),w.__dict__)
g,ops=w.boot()
print(json.dumps({'readOnly':True,'services':w.snapshot_services(),'configSha256':w.digest(g.read(w.CONFIG,128*1024))}))
PY
