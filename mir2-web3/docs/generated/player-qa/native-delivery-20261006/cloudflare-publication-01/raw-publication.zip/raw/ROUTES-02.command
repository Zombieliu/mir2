sudo -n python3 -B - <<'PY'
import hashlib,importlib.util,json,os,pathlib,subprocess,sys,time
stage=pathlib.Path('/srv/.mir2-origin-preview13-20261005-01')
path=stage/'origin_preview13.py'
raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='bcf62dfa1542fefd9d861dfa09f3026d9a3e6615b0b708b14286aa31b3a139de'
spec=importlib.util.spec_from_file_location('verified_preview13_writer',path)
w=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=w
exec(compile(raw,str(path),'exec'),w.__dict__)
g,ops=w.boot()
with ops.lock(g,w.LOCK):
    feed=w.stable_feed(g)
    w.fixed_envelope(g)
    current=g.read(w.CONFIG,128*1024)
    assert w.digest(current)==w.PINS['config'] and current.count(w.OLD_MATCH)==1 and w.NEW_MATCH not in current
    candidate=current.replace(w.OLD_MATCH,w.NEW_MATCH)
    candidate_path=w.CONFIG.parent/'Caddyfile.mir2-preview13-20261005-01'
    assert g.read(candidate_path,128*1024)==candidate
    assert g.read(stage/'CADDY-BEFORE.private',128*1024)==current
    before=w.snapshot_services()
    pid=before['caddy.service']['MainPID']
    assert pid.isdigit() and int(pid)>1 and before['caddy.service']['ActiveState']=='active'
    # Use the same private environment as the live Caddy service. No value leaves this process.
    environment={}
    for field in pathlib.Path('/proc',pid,'environ').read_bytes().split(b'\0'):
        if b'=' in field:
            name,value=field.split(b'=',1)
            environment[os.fsdecode(name)]=os.fsdecode(value)
    environment.setdefault('PATH',os.environ.get('PATH','/usr/bin:/bin'))
    result=subprocess.run(['caddy','validate','--config',str(candidate_path),'--adapter','caddyfile'],env=environment,capture_output=True,timeout=30)
    w.write_new(g,ops,stage/'CADDY-VALIDATE-02.private.stdout',result.stdout)
    w.write_new(g,ops,stage/'CADDY-VALIDATE-02.private.stderr',result.stderr)
    assert result.returncode==0,'caddy-live-environment-validation-failed'
    immediate=w.snapshot_services()
    w.same_pids(before,immediate)
    assert all(state['incoming']==0 for state in immediate.values()),'active-connections-reload-deferred'
    assert w.stable_feed(g)==feed and g.read(w.CONFIG,128*1024)==current and g.read(candidate_path,128*1024)==candidate
    with g.dir_fd(w.CONFIG.parent) as fd:
        os.rename(candidate_path.name,w.CONFIG.name,src_dir_fd=fd,dst_dir_fd=fd)
        os.fsync(fd)
    result=subprocess.run(['caddy','reload','--config',str(w.CONFIG),'--adapter','caddyfile'],env=environment,capture_output=True,timeout=30)
    w.write_new(g,ops,stage/'CADDY-RELOAD-02.private.stdout',result.stdout)
    w.write_new(g,ops,stage/'CADDY-RELOAD-02.private.stderr',result.stderr)
    assert result.returncode==0,'caddy-reload-failed-retained-backup'
    assert g.read(w.CONFIG,128*1024)==candidate and w.stable_feed(g)==feed
    w.same_pids(before,w.snapshot_services())
    receipt={'schema':'mir2.origin-preview13.static-routes.v1','passed':True,'createdUnix':int(time.time()),'oldConfigSha256':w.digest(current),'newConfigSha256':w.digest(candidate),'validationExit':0,'reloadExit':0,'environmentSource':'existing live Caddy process; values neither exported nor printed','incomingImmediatelyBeforeReload':{n:s['incoming'] for n,s in immediate.items()},'allServicePidsPreserved':True,'feed12FingerprintPreserved':True,'gatewayRestarted':False}
    w.write_new(g,ops,stage/'ROUTES-02.json',(json.dumps(receipt,indent=2)+'\n').encode())
    print(json.dumps(receipt))
PY
