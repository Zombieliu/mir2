import hashlib,json,subprocess,time
from pathlib import Path

root=Path(__file__).resolve().parent
project=Path('C:/Users/Administrator/.codex/worktrees/crowded-combat-control/mir2-player-journey/mir2-web3')
source_revision='48454bba7623694ca7432613af52bee28e83970e'
pins=json.loads(Path('C:/mir2-playtest-releases/20261004-native-r18/updater-resume-release-root-01/commands/build-profile-01.command.json').read_text())['sourceBefore']
def source_check():
    actual={}
    for key,expected in pins.items():
        path=project.parent/key
        data=path.read_bytes()
        value={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        assert value==expected,(key,'source drift')
        actual[key]=value
    return actual
before=source_check()
check=subprocess.run(['git','-c','gc.auto=0','diff','--exit-code',source_revision,'--','apps/game-client/windows-updater'],cwd=project,capture_output=True,check=True)
commands=[]
def run(name,argv,timeout):
    started=time.monotonic()
    r=subprocess.run(argv,cwd=project,capture_output=True,timeout=timeout,check=False)
    (root/(name+'.stdout')).write_bytes(r.stdout)
    (root/(name+'.stderr')).write_bytes(r.stderr)
    commands.append({'name':name,'argv':argv,'exitCode':r.returncode,'seconds':time.monotonic()-started})
    (root/'NATIVE-HTTPS-COMMANDS-01.json').write_text(json.dumps({'sourceRevision':source_revision,'sourceBefore':before,'commands':commands},indent=2)+'\n')
    assert r.returncode==0,(name,r.returncode)
manifest=str(root/'native-https-probe/Cargo.toml')
run('native-https-lock-01',['cargo','+1.95.0','generate-lockfile','--offline','--manifest-path',manifest],60)
run('native-https-build-01',['cargo','+1.95.0','build','--offline','--locked','--release','--jobs','2','--manifest-path',manifest,'--target','x86_64-pc-windows-msvc','--target-dir','C:/mir2-build/updater-resume-release-20261005'],180)
run('native-https-run-01',['C:/mir2-build/updater-resume-release-20261005/x86_64-pc-windows-msvc/release/mir2-native-cdn-readonly-proof.exe',str(root/'NATIVE-HTTPS-01')],150)
after=source_check()
(root/'NATIVE-HTTPS-COMMANDS-01.json').write_text(json.dumps({'sourceRevision':source_revision,'sourceBefore':before,'sourceAfter':after,'commands':commands,'nativeReadOnlyNetworkProof':True,'fullInstallerExecuted':False},indent=2)+'\n')
print(json.dumps({'passed':True,'sourceRevision':source_revision,'actualNativeUreqAndProductionDiscovery':True,'cmsVerified':True,'sourceUnchanged':True}))
