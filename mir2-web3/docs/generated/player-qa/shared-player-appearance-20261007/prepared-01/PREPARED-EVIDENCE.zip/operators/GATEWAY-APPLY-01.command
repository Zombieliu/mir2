sudo -n python3 -B - <<'PY'
import hashlib,os,pathlib,stat,sys
p=pathlib.Path('/srv/.mir2-appearance-gateway-20261007-01/upgrade-appearance-gateway-01.py')
assert os.geteuid()==0 and p.parent.resolve(strict=True)==p.parent
assert p.parent.stat().st_uid==0 and stat.S_IMODE(p.parent.stat().st_mode)==0o700
s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_uid==0 and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==0o600
fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as f:b=f.read(131073)
assert len(b)==30748 and hashlib.sha256(b).hexdigest()=='2e6259a3bd9649d47464019143ebe14ef45096612a92023d5d6d53a8240186e3'
sys.argv=[str(p)]+['--revision', 'c6c32381a646dae1067dafdeec57691f606b1779', '--expected-current', '2b04e82c4f42b22f895f5f95b5bd79a8147eacdf', '--manifest-sha256', 'cd1be39e45b7d368bd7733e69732b11f161597ed98c50bd18ee10526345c6c9e', '--expected-active', '51', '--apply']
exec(compile(b,str(p),'exec'),{'__name__':'__main__','__file__':str(p)})
PY
