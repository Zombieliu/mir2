python3 -B - <<'PY'
import os,pathlib,stat
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-c6c32381a646dae1067dafdeec57691f606b1779')
assert os.geteuid()==1000 and p.parent.resolve(strict=True)==p.parent
s=p.parent.lstat()
assert stat.S_ISDIR(s.st_mode) and s.st_uid==1000 and not s.st_mode & 0o022
assert not p.exists() and not p.is_symlink()
p.mkdir(mode=0o700)
print('Private appearance artifact stage created; no service change')
PY
