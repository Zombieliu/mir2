sudo -n python3 -B - <<'PY'
import hashlib,os,pathlib,stat
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-c6c32381a646dae1067dafdeec57691f606b1779');target=pathlib.Path('/srv/.mir2-appearance-gateway-20261007-01')
assert os.geteuid()==0 and p.resolve(strict=True)==p
assert p.stat().st_uid==1000 and stat.S_IMODE(p.stat().st_mode)==0o700
op=p/'upgrade-appearance-gateway-01.py';s=op.lstat()
assert stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==0o600
fd=os.open(op,os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as f:
 b=f.read(131073);assert len(b)==30748 and hashlib.sha256(b).hexdigest()=='2e6259a3bd9649d47464019143ebe14ef45096612a92023d5d6d53a8240186e3'
assert target.parent.resolve(strict=True)==target.parent and target.parent.stat().st_uid==0 and not target.parent.stat().st_mode & 0o022
assert not target.exists() and not target.is_symlink();target.mkdir(mode=0o700)
fd=os.open(target/'upgrade-appearance-gateway-01.py',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
print('Exact reviewed operator sealed; no service change')
PY
