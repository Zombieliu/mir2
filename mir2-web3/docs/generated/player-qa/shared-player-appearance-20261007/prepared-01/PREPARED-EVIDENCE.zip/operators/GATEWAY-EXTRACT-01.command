python3 -B - <<'PY'
import hashlib,io,json,os,pathlib,stat,tarfile
p=pathlib.Path('/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-c6c32381a646dae1067dafdeec57691f606b1779')
incoming=[{'name': 'mir2-gateway-linux-x64-20261007-remote-player-r21.tar.gz', 'size': 32300623, 'sha256': '33f1fa442231b21b0e2b0c0c57810071a94cb28af83b06f24bcede426aac5fcc'}, {'name': 'VERIFIED-FILES.json', 'size': 412, 'sha256': 'cd1be39e45b7d368bd7733e69732b11f161597ed98c50bd18ee10526345c6c9e'}, {'name': 'upgrade-appearance-gateway-01.py', 'size': 30748, 'sha256': '2e6259a3bd9649d47464019143ebe14ef45096612a92023d5d6d53a8240186e3'}]
assert os.geteuid()==1000 and p.resolve(strict=True)==p
s=p.lstat()
assert stat.S_ISDIR(s.st_mode) and s.st_uid==1000 and stat.S_IMODE(s.st_mode)==0o700
assert set(x.name for x in p.iterdir())=={row['name'] for row in incoming}
data={}
for row in incoming:
 f=p/row['name'];s=f.lstat()
 assert stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_nlink==1 and s.st_size==row['size']
 b=f.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];f.chmod(0o600);data[row['name']]=b
manifest=json.loads(data['VERIFIED-FILES.json'])
assert manifest['revision']=='c6c32381a646dae1067dafdeec57691f606b1779'
with tarfile.open(fileobj=io.BytesIO(data['mir2-gateway-linux-x64-20261007-remote-player-r21.tar.gz']),mode='r:gz') as tar:
 members=tar.getmembers()
 assert len(members)==4 and all(m.isfile() for m in members)
 assert {m.name for m in members}=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
 for row in manifest['files']:
  m=tar.getmember(row['path']);assert m.size==row['size']<=268435456
  b=tar.extractfile(m).read(m.size+1)
  assert len(b)==m.size and hashlib.sha256(b).hexdigest()==row['sha256']
  fd=os.open(p/row['path'],os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
print(json.dumps({'passed':True,'sourceRevision':manifest['revision'],'verifiedFiles':manifest['files'],'publicMutations':False}))
PY
