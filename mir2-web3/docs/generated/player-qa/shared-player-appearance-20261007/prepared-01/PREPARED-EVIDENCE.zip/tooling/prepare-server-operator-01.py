import hashlib,json,pathlib

base=pathlib.Path('C:/mir2-playtest-releases/20261007-remote-player-r21')
ci=base/'server-ci-01'
ops=base/'operators-01'
revision='c6c32381a646dae1067dafdeec57691f606b1779'
receipt=json.loads((ci/'operator-verification.json').read_text())
assert receipt['sourceRevision']==revision and receipt['releaseWorkflowAccepted'] is True
remote='/home/ubuntu/mir2-playtest-preflight-20260929/capacity-verified-'+revision
sealed='/srv/.mir2-appearance-gateway-20261007-01'
package='mir2-gateway-linux-x64-20261007-remote-player-r21.tar.gz'
rows=[]
for name,mode in [('mir2-gateway',0o755),('RELEASE.json',0o644)]:
    data=(ci/name).read_bytes()
    rows.append({'path':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':mode})
manifest=(json.dumps({'revision':revision,'files':rows},indent=2)+'\n').encode()
(ops/'VERIFIED-FILES.json').write_bytes(manifest)
manifest_hash=hashlib.sha256(manifest).hexdigest()
operator='upgrade-appearance-gateway-01.py'
operator_bytes=(ops/operator).read_bytes()
operator_hash=hashlib.sha256(operator_bytes).hexdigest()
incoming=[{'name':package,'size':(ci/package).stat().st_size,'sha256':receipt['archiveSha256']},
          {'name':'VERIFIED-FILES.json','size':len(manifest),'sha256':manifest_hash},
          {'name':operator,'size':len(operator_bytes),'sha256':operator_hash}]
def write(name,text):
    path=ops/name
    assert not path.exists()
    path.write_text(text,encoding='utf-8',newline='\n')

write('GATEWAY-CREATE-01.command',f'''python3 -B - <<'PY'
import os,pathlib,stat
p=pathlib.Path({remote!r})
assert os.geteuid()==1000 and p.parent.resolve(strict=True)==p.parent
s=p.parent.lstat()
assert stat.S_ISDIR(s.st_mode) and s.st_uid==1000 and not s.st_mode & 0o022
assert not p.exists() and not p.is_symlink()
p.mkdir(mode=0o700)
print('Private appearance artifact stage created; no service change')
PY
''')
write('GATEWAY-EXTRACT-01.command',f'''python3 -B - <<'PY'
import hashlib,io,json,os,pathlib,stat,tarfile
p=pathlib.Path({remote!r})
incoming={incoming!r}
assert os.geteuid()==1000 and p.resolve(strict=True)==p
s=p.lstat()
assert stat.S_ISDIR(s.st_mode) and s.st_uid==1000 and stat.S_IMODE(s.st_mode)==0o700
assert set(x.name for x in p.iterdir())=={{row['name'] for row in incoming}}
data={{}}
for row in incoming:
 f=p/row['name'];s=f.lstat()
 assert stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_nlink==1 and s.st_size==row['size']
 b=f.read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256'];f.chmod(0o600);data[row['name']]=b
manifest=json.loads(data['VERIFIED-FILES.json'])
assert manifest['revision']=={revision!r}
with tarfile.open(fileobj=io.BytesIO(data[{package!r}]),mode='r:gz') as tar:
 members=tar.getmembers()
 assert len(members)==4 and all(m.isfile() for m in members)
 assert {{m.name for m in members}}=={{'mir2-gateway','zone_host','RELEASE.json','README.txt'}}
 for row in manifest['files']:
  m=tar.getmember(row['path']);assert m.size==row['size']<=268435456
  b=tar.extractfile(m).read(m.size+1)
  assert len(b)==m.size and hashlib.sha256(b).hexdigest()==row['sha256']
  fd=os.open(p/row['path'],os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
print(json.dumps({{'passed':True,'sourceRevision':manifest['revision'],'verifiedFiles':manifest['files'],'publicMutations':False}}))
PY
''')
write('GATEWAY-SEAL-01.command',f'''sudo -n python3 -B - <<'PY'
import hashlib,os,pathlib,stat
p=pathlib.Path({remote!r});target=pathlib.Path({sealed!r})
assert os.geteuid()==0 and p.resolve(strict=True)==p
assert p.stat().st_uid==1000 and stat.S_IMODE(p.stat().st_mode)==0o700
op=p/{operator!r};s=op.lstat()
assert stat.S_ISREG(s.st_mode) and s.st_uid==1000 and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==0o600
fd=os.open(op,os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as f:
 b=f.read(131073);assert len(b)=={len(operator_bytes)} and hashlib.sha256(b).hexdigest()=={operator_hash!r}
assert target.parent.resolve(strict=True)==target.parent and target.parent.stat().st_uid==0 and not target.parent.stat().st_mode & 0o022
assert not target.exists() and not target.is_symlink();target.mkdir(mode=0o700)
fd=os.open(target/{operator!r},os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
print('Exact reviewed operator sealed; no service change')
PY
''')
args=['--revision',revision,'--expected-current','2b04e82c4f42b22f895f5f95b5bd79a8147eacdf','--manifest-sha256',manifest_hash,'--expected-active','51']
for name,extra in [('GATEWAY-PREFLIGHT-01.command',[]),('GATEWAY-APPLY-01.command',['--apply'])]:
    write(name,f'''sudo -n python3 -B - <<'PY'
import hashlib,os,pathlib,stat,sys
p=pathlib.Path({(sealed+'/'+operator)!r})
assert os.geteuid()==0 and p.parent.resolve(strict=True)==p.parent
assert p.parent.stat().st_uid==0 and stat.S_IMODE(p.parent.stat().st_mode)==0o700
s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_uid==0 and s.st_nlink==1 and stat.S_IMODE(s.st_mode)==0o600
fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
with os.fdopen(fd,'rb') as f:b=f.read(131073)
assert len(b)=={len(operator_bytes)} and hashlib.sha256(b).hexdigest()=={operator_hash!r}
sys.argv=[str(p)]+{(args+extra)!r}
exec(compile(b,str(p),'exec'),{{'__name__':'__main__','__file__':str(p)}})
PY
''')
uploads=[[str(ci/package),remote+'/'+package],[str(ops/'VERIFIED-FILES.json'),remote+'/VERIFIED-FILES.json'],[str(ops/operator),remote+'/'+operator]]
write('GATEWAY-UPLOAD-BATCH-01.json',json.dumps(uploads,indent=2)+'\n')
write('OPERATOR-RECIPES.json',json.dumps({'sourceRevision':revision,'previousRevision':'2b04e82c4f42b22f895f5f95b5bd79a8147eacdf','manifestSha256':manifest_hash,'operatorSha256':operator_hash,'binarySha256':receipt['binarySha256'],'source':remote,'sealedOperator':sealed+'/'+operator,'actualRollout':False},indent=2)+'\n')
print(json.dumps({'passed':True,'sourceRevision':revision,'manifestSha256':manifest_hash,'operatorSha256':operator_hash,'archiveSizeBytes':incoming[0]['size'],'publicMutations':False}))
