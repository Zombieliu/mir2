"""Fetch an exact authenticated CI artifact; never print a token or signed URL."""
import hashlib,json,pathlib,subprocess,tarfile,urllib.error,urllib.parse,urllib.request,zipfile

root=pathlib.Path('C:/mir2-playtest-releases/20261007-remote-player-r21/server-ci-01')
revision='c6c32381a646dae1067dafdeec57691f606b1779'
run_id=37617054260
run=json.loads((root/'authenticated-run.json').read_text(encoding='utf-8-sig'))
jobs=json.loads((root/'authenticated-jobs.json').read_text(encoding='utf-8-sig'))['jobs']
artifacts=json.loads((root/'authenticated-artifacts.json').read_text(encoding='utf-8-sig'))['artifacts']
assert run['id']==run_id and run['head_sha']==revision and run['status']=='completed' and run['conclusion']=='success'
assert len(jobs)==2 and all(j['conclusion']=='success' for j in jobs)
assert {j['name'] for j in jobs}=={'build-linux-x64','siege-acceptance / siege-linux'}
assert len(artifacts)==1
artifact=artifacts[0]
assert artifact['id']==11480868639 and artifact['name']=='mir2-gateway-linux-x64' and artifact['expired'] is False
assert artifact['workflow_run']['head_sha']==revision
expected='40297bba9a318697f9ada8a4b51ddde88d2769458f623d8c46e2035c9bc9b9d7'
assert artifact['digest']=='sha256:'+expected and artifact['size_in_bytes']==31885191

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,request,response,code,message,headers,new_url):return None

archive=root/'artifact.zip'
if not archive.exists():
    opener=urllib.request.build_opener(NoRedirect())
    token=subprocess.run(['gh','auth','token'],check=True,capture_output=True,text=True).stdout.strip()
    assert token and '\n' not in token
    request=urllib.request.Request(f'https://api.github.com/repos/Zombieliu/mir2/actions/artifacts/{artifact["id"]}/zip',headers={'Authorization':'Bearer '+token,'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'})
    try:
        response=opener.open(request,timeout=45)
    except urllib.error.HTTPError as error:
        assert error.code==302
        location=error.headers['Location']
        parsed=urllib.parse.urlsplit(location)
        assert parsed.scheme=='https' and not parsed.username and not parsed.password and parsed.port in (None,443)
        assert parsed.hostname.endswith(('.blob.core.windows.net','.actions.githubusercontent.com','.githubusercontent.com'))
        # No Authorization header is forwarded to the signed artifact location.
        response=opener.open(urllib.request.Request(location),timeout=45)
    del token,request
    with response,archive.open('xb') as output:
        count=0
        while True:
            data=response.read(1024*1024)
            if not data:break
            count+=len(data)
            assert count<=artifact['size_in_bytes']
            output.write(data)
assert archive.stat().st_size==artifact['size_in_bytes'] and hashlib.sha256(archive.read_bytes()).hexdigest()==expected
with zipfile.ZipFile(archive) as zipped:
    names=zipped.namelist()
    package='mir2-gateway-linux-x64-20261007-remote-player-r21.tar.gz'
    assert set(names)=={package,package+'.sha256','latest-mir2-gateway-release.json'}
    for name in names:
        info=zipped.getinfo(name)
        assert not info.is_dir() and info.file_size<=64*1024*1024
        (root/name).write_bytes(zipped.read(info))
manifest=json.loads((root/'latest-mir2-gateway-release.json').read_text())
assert manifest['gitRevision']==revision and manifest['gitDirty'] is False and manifest['tag']=='20261007-remote-player-r21'
assert manifest['archive']==package and manifest['target']=='linux-x64'
assert hashlib.sha256((root/package).read_bytes()).hexdigest()==manifest['archiveSha256']
assert (root/(package+'.sha256')).read_text().split()[0]==manifest['archiveSha256']
with tarfile.open(root/package,'r:gz') as tar:
    entries=tar.getmembers()
    regular=[entry for entry in entries if entry.isfile()]
    assert all(entry.isdir() or entry.isfile() for entry in entries)
    assert {entry.name for entry in regular}=={'mir2-gateway','zone_host','RELEASE.json','README.txt'}
    for entry in regular:
        assert entry.size<=256*1024*1024 and not pathlib.PurePosixPath(entry.name).is_absolute() and '..' not in pathlib.PurePosixPath(entry.name).parts
        name=pathlib.PurePosixPath(entry.name).name
        if name not in ('mir2-gateway','RELEASE.json'):continue
        data=tar.extractfile(entry).read(entry.size+1)
        assert len(data)==entry.size
        (root/name).write_bytes(data)
metadata=json.loads((root/'RELEASE.json').read_text())
binary=(root/'mir2-gateway').read_bytes()
assert metadata['gitRevision']==revision and metadata['gitDirty'] is False and binary[:4]==b'\x7fELF'
assert len(binary)==metadata['binarySizeBytes']==manifest['binarySizeBytes']
assert hashlib.sha256(binary).hexdigest()==metadata['binarySha256']==manifest['binarySha256']
receipt={'sourceRevision':revision,'runId':run_id,'artifactId':artifact['id'],'artifactZipSha256':expected,'archiveSha256':manifest['archiveSha256'],'binarySha256':manifest['binarySha256'],'binarySizeBytes':len(binary),'buildAndSecurityJobPassed':True,'releaseWorkflowAccepted':True,'deployedToLiveRealm':False}
(root/'operator-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
