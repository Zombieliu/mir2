import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {pathToFileURL} from 'node:url';

const revision='c6c32381a646dae1067dafdeec57691f606b1779';
const root='C:/mir2-playtest-releases/20261007-remote-player-r21/public-wss-01';
const endpoint='wss://165.154.65.136.sslip.io/playtest/ws';
need(typeof WebSocket==='function'&&process.env.NODE_TLS_REJECT_UNAUTHORIZED!=='0','Node native WebSocket with normal TLS verification is required');
const observationSource=await fs.readFile('C:/mir2-playtest-releases/20261007-remote-player-r21/protocol-observation.mjs');
need(crypto.createHash('sha256').update(observationSource).digest('hex')==='b69ba03e9f6ee05286d401341c6dbbe6dac4a6e5014fa6a67e9c6167c072d097','Frozen source observation differs');
const {applyProtocolObservation}=await import(pathToFileURL('C:/mir2-playtest-releases/20261007-remote-player-r21/protocol-observation.mjs'));
const health=await fetch('https://165.154.65.136.sslip.io/playtest/health',{redirect:'error',signal:AbortSignal.timeout(15000)}).then(r=>{need(r.ok,'public health HTTP status');return r.json();});
need(health.ok===true && health.revision===revision,'Public playtest must run the pinned appearance candidate');
need(health.capacity.currentActiveSessions<=43,'Six owned clients require available normal capacity');
await fs.access(root+'/private');
const suffix=crypto.randomBytes(3).toString('hex');
const cohort=['Warrior','Wizard','Taoist'].flatMap((className,index)=>['Male','Female'].map((gender,g)=>({accountId:`Look${index}${g}${suffix}`,name:`R21${index}${g}${suffix}`,class:className,gender,password:crypto.randomBytes(12).toString('hex')})));
await fs.writeFile(root+'/private/accounts.json',JSON.stringify(cohort),{flag:'wx',mode:0o600});
const secrets=cohort.map(a=>a.password);
const ordinary=new Set(['clientVersion','newAccount','login','newCharacter','startGame','keepAlive','turn','walk','logOut']);
const delay=ms=>new Promise(r=>setTimeout(r,ms));
function need(value,message){if(!value)throw Error(message);}
function safe(value){
 if(Array.isArray(value))return value.map(safe);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,/password|secret|token|authorization|cookie|pepper|private.?key/i.test(k)?'[redacted]':safe(v)]));
 return typeof value==='string'?secrets.reduce((s,p)=>s.split(p).join('[redacted]'),value):value;
}
class Client {
 constructor(account,phase){this.account=account;this.phase=phase;this.events=[];this.sequence=0;this.queue=Promise.resolve();}
 record(direction,value){const event={sequence:++this.sequence,utc:new Date().toISOString(),direction,...safe(value)};this.events.push(event);this.queue=this.queue.then(()=>fs.appendFile(path.join(root,`${this.phase}-${this.account.name}.jsonl`),JSON.stringify(event)+'\n'));}
 async wait(predicate,label,ms=20000){const end=Date.now()+ms;while(Date.now()<end){if(this.error)throw this.error;const value=predicate();if(value)return value;await delay(25);}throw Error('Timed out: '+label);}
 send(value){need(ordinary.has(value.type),'Only ordinary public commands are admitted');this.record('sent',value);this.ws.send(JSON.stringify(value));}
 async request(value,packet){const prior=this.sequence;this.send(value);return this.wait(()=>this.events.find(e=>e.sequence>prior&&e.direction==='received'&&e.packet===packet),packet);}
 async open(){
  this.ws=new WebSocket(endpoint);
  this.ws.addEventListener('message',event=>{try{const value=JSON.parse(String(event.data));this.record('received',value);if(value.packet==='UserInformation')this.info=value.payload;this.snapshot=applyProtocolObservation(this.snapshot,value);if(value.type==='error')this.error=Error('Public gateway rejected an ordinary command');}catch(error){this.error=error;}});
  this.ws.addEventListener('error',()=>{this.error=Error('Verified public WSS failed');});
  await this.wait(()=>this.ws.readyState===1,'TLS WebSocket open',15000);
  this.send({type:'clientVersion'});
  this.timer=setInterval(()=>{if(this.ws.readyState===1)this.send({type:'keepAlive',time:Date.now()});},2000);
 }
 async login(create){
  const a=this.account;
  if(create){const reply=await this.request({type:'newAccount',accountId:a.accountId,password:a.password,birthDateBinary:0,userName:'Appearance QA',secretQuestion:'q',secretAnswer:'a',emailAddress:''},'NewAccount');need(reply.payload.result===8,'Ordinary account creation result');}
  await this.request({type:'login',accountId:a.accountId,password:a.password},'LoginSuccess');
  if(create){const reply=await this.request({type:'newCharacter',name:a.name,class:a.class,gender:a.gender},'NewCharacterSuccess');a.characterIndex=reply.payload.character.index;need(Number.isSafeInteger(a.characterIndex),'Actual created character index');}
 }
 async start(){
  const prior=this.sequence;
  const reply=await this.request({type:'startGame',characterIndex:this.account.characterIndex},'StartGame');
  need(reply.payload.result===4,'Authenticated StartGame result4');
  await this.wait(()=>this.events.find(e=>e.sequence>prior&&e.packet==='UserInformation'),'owner UserInformation');
  await this.wait(()=>this.snapshot?.entities?.find(e=>e.objectId===this.snapshot.playerObjectId&&e.name===this.account.name),'normal shared owner snapshot');
  need(this.info.level===1&&this.info.hp>0,'Normal level1 actor without trusted preparation');
 }
 owner(){return this.snapshot.entities.find(e=>e.objectId===this.snapshot.playerObjectId);}
 async seen(account,after=0){return this.wait(()=>this.events.filter(e=>e.sequence>after&&e.packet==='ObjectPlayer'&&e.payload.name===account.name).at(-1),'remote ObjectPlayer '+account.name);}
 async close(){
  clearInterval(this.timer);
  if(this.ws?.readyState===1){const previous=this.error;this.error=null;try{await this.request({type:'logOut'},'LogOutSuccess');this.normalLogout=true;}catch{}finally{this.error=previous;this.ws.close(1000);}}
  await this.queue;
 }
}
function verifyAppearance(event,owner){
 const info=event.payload;
 need(info.transformType===-1,'Ordinary remote actor must not use Transform/00');
 need(info.class===owner.account.class&&info.gender===owner.account.gender,'Remote class and gender are authoritative');
 need(info.sprite?.bodyLibrary?.startsWith('CArmour/'),'Released ordinary armour body is selected');
 need(JSON.stringify(info.sprite)===JSON.stringify(owner.owner().sprite),'Complete remote sprite equals ordinary owner snapshot');
 return {observerBody:info.sprite.bodyLibrary,weapon:info.sprite.weaponLibrary,gender:info.gender,class:info.class,transformType:info.transformType,objectId:info.objectId};
}
const clients=[],rows=[];
let failure=null;
try{
 for(const account of cohort){const client=new Client(account,'initial');clients.push(client);await client.open();await client.login(true);await client.start();}
 await fs.writeFile(root+'/private/accounts.json',JSON.stringify(cohort));
 for(const observer of clients)for(const owner of clients)if(observer!==owner){
  const event=await observer.seen(owner.account);rows.push({phase:'initial',observer:observer.account.name,subject:owner.account.name,...verifyAppearance(event,owner)});
 }
 const actor=clients[0],start={...actor.owner()},before=clients.map(c=>c.sequence);
 let moved=null;
 for(const [direction,dx,dy]of [['Down',0,1],['Right',1,0],['Left',-1,0],['Up',0,-1],['DownRight',1,1],['DownLeft',-1,1],['UpRight',1,-1],['UpLeft',-1,-1]]){
  const prior=actor.sequence;actor.send({type:'walk',direction});
  try{moved=await actor.wait(()=>actor.events.find(e=>e.sequence>prior&&e.packet==='UserLocation'&&e.payload.x===start.x+dx&&e.payload.y===start.y+dy),'one ordinary tile move',2000);break;}catch{}
 }
 need(moved,'At least one ordinary acknowledged move is required');
 const oldId=(await clients[1].seen(actor.account)).payload.objectId;
 for(let i=1;i<clients.length;i++){const seen=await clients[i].wait(()=>clients[i].events.find(e=>e.sequence>before[i]&&e.packet==='ObjectWalk'&&e.payload.objectId===oldId&&e.payload.x===moved.payload.x&&e.payload.y===moved.payload.y),'AOI ObjectWalk');rows.push({phase:'walk',observer:clients[i].account.name,objectId:oldId,location:{x:seen.payload.x,y:seen.payload.y}});}
 const beforeLogout=clients.map(c=>c.sequence);
 await actor.close();need(actor.normalLogout===true,'Ordinary actor logout must save normally');
 for(let i=1;i<clients.length;i++)await clients[i].wait(()=>clients[i].events.find(e=>e.sequence>beforeLogout[i]&&e.packet==='ObjectRemove'&&e.payload.objectId===oldId),'AOI leave remove');
 const beforeRejoin=clients.map(c=>c.sequence),returning=new Client(actor.account,'relogin');clients.push(returning);
 await returning.open();await returning.login(false);await returning.start();
 need(returning.owner().x===moved.payload.x&&returning.owner().y===moved.payload.y,'Normal logout/relogin preserves actual acknowledged transform');
 for(let i=1;i<6;i++){const event=await clients[i].seen(returning.account,beforeRejoin[i]);rows.push({phase:'relogin',observer:clients[i].account.name,subject:returning.account.name,...verifyAppearance(event,returning)});}
}catch(error){failure=error.message;}
finally{for(const client of clients)await client.close();}
const report={schema:'mir2.shared-player-appearance.public.v1',passed:failure===null&&rows.length===40&&clients.every(c=>c.normalLogout===true),sourceRevision:revision,endpoint,tlsVerified:true,ordinaryAccounts:6,classes:3,genders:2,initialRelations:30,movementRelations:5,reloginRelations:5,ordinaryCommandsOnly:true,adminCommands:false,qaStatePreparation:false,nativeRenderAcceptance:false,failure,normalLogouts:clients.map(c=>({name:c.account.name,phase:c.phase,confirmed:c.normalLogout===true})),rows};
await fs.writeFile(root+'/RESULT.json',JSON.stringify(safe(report),null,2),{flag:'wx'});
console.log(JSON.stringify(safe(report)));
if(!report.passed)process.exitCode=1;
