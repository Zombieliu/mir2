import hashlib, json, re, subprocess, zipfile
from datetime import datetime, timezone
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
root = repo / 'mir2-web3'
evidence = Path('C:/mir2-build/p7-npc-population-20261010-evidence')
out = root / 'docs/generated/player-qa/npc-population-20261010/candidate-01'
assert not out.exists()
final = {'09-final-source-selection-and-census':28,
         '10-final-adjacent-manager':11, '11-final-owner-epoch-exhaustion':1}
records, unique = {}, set()
for stem, expected in final.items():
    before = json.loads((evidence/(stem+'-before.json')).read_text(encoding='utf-8-sig'))
    after = json.loads((evidence/(stem+'-after.json')).read_text(encoding='utf-8-sig'))
    assert before['source'] == after['source'], stem
    for row in after['source']:
        assert hashlib.sha256(Path(row['Path']).read_bytes()).hexdigest().upper() == row['Hash'], (stem,row['Path'])
    result = json.loads((evidence/(stem+'-result.json')).read_text(encoding='utf-8-sig'))
    log = (evidence/(stem+'.log')).read_text(encoding='utf-8-sig')
    match = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    assert result['exitCode'] == 0 and match and tuple(map(int,match.groups())) == (expected,0,0), stem
    names = re.findall(r'^test (\S+) \.\.\. ok$',log,re.M)
    assert len(names) == expected and len(set(names)) == expected
    unique.update(names)
    records[stem] = {'passed':expected,'failed':0,'ignored':0,'exitCode':0,
                     'selectedPaths':len(after['source']),'beforeAfterStableAndCurrent':True}
assert len(unique) == 32
failed = (evidence/'01-source-selection-and-owner-nodes.log').read_text(encoding='utf-8-sig')
assert 'test result: FAILED. 22 passed; 1 failed; 0 ignored;' in failed
zero = (evidence/'07-final-adjacent-manager.log').read_text(encoding='utf-8-sig')
assert 'test result: ok. 0 passed; 0 failed; 0 ignored;' in zero
git = ['git','-c','safe.directory='+repo.as_posix(),'-c','gc.auto=0',
       '-c','maintenance.auto=false','-C',str(repo)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip() == 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9'
subprocess.run(git+['diff','--check'],check=True)
entries = {}
def add(name,path):
    assert name not in entries
    data = Path(path).read_bytes()
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',data)
    entries[name] = data
for path in sorted(evidence.iterdir()):
    if path.is_file(): add('local/'+path.name,path)
for path in sorted((evidence/'archive-preparation-01').iterdir()):
    if path.is_file(): add('initial-archive-preparation/'+path.name,path)
owned = ['.github/workflows/gateway-release.yml'] + [
    'mir2-web3/apps/simulation/src/runtime/'+name+'.rs' for name in
    ['mod','npc_population','zone/mod','zone/manager','zone/npc_population','zone/runtime','zone/online_identity']]
for name in owned: add('final-source/'+name,repo/name)
for name in ['Run-NpcPopulationRoot.ps1','Archive-NpcPopulationFoundation.py']:
    add('runners/'+name,repo.parent/name)
source = Path('E:/mir2/Crystal')
for name in ['Server/MirObjects/NPC/NPCSegment.cs','Server/MirEnvir/Envir.cs',
             'Server/MirDatabase/MapInfo.cs','Server/MirEnvir/Map.cs']:
    add('original-crystal/'+name,source/name)
maps = json.loads((root/'packages/game-data/data/generated/crystal_respawn_manifest.json').read_bytes())['maps']
file_names = [row['map_file_name'] for row in maps]
assert len(file_names) == 464 and all(name.isascii() for name in file_names)
out.mkdir(parents=True)
archive = out/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in entries.items(): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(entries)
    assert all(z.read(name) == data for name,data in entries.items())
record = {'createdUtc':datetime.now(timezone.utc).isoformat(),
    'baseSource':'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9',
    'foundationImplemented':True,'localTestsPassed':True,'uniqueTestsPassed':len(unique),
    'rawFinalExecutions':sum(item['passed'] for item in records.values()),'finalTests':records,
    'initialFixtureFailure':{'passed':22,'failed':1,'cause':'AOI test used generic-object visibility helper instead of ordinary ObjectPlayer outbounds','retained':True},
    'zeroSelection':{'stem':'07-final-adjacent-manager','passed':0,'excluded':True,
        'cause':'Manager adjacent tests are in parallel_tick_tests, not a tests module','correctedFilter':'zone::manager::'},
    'initialArchivePreparationFailuresRetained':True,
    'sourceFileNames':{'count':len(file_names),'allAscii':True,'emptyNames':sum(name == '' for name in file_names),
        'metadataIsNotLoadedMapAuthority':True},
    'publicGateway':'c70436f34eabb432d769e0082c0afa23303294b0',
    'publicClient':'R23/sourcefaef/signedfeed18',
    'gatewaySourceConsumerImplemented':False,'successfulSourceMapProducerImplemented':False,
    'newSourcePushed':False,'exactLinuxPassed':False,'gatewayPublished':False,'humanAccepted':False,
    'limits':['selected hashes, not whole Cargo/toolchain input closure',
        'pure synthetic loaded records do not prove successful Source loading or ownership',
        'count includes dead and out-of-AOI Player Nodes until actual Leave, not pets/Hero',
        'actor predicate is not freshness; retained A-to-B-to-A can match an old binding',
        'per-map unavailable/zero is not a full global Book census or Source map-load proof',
        'ordinary NPC CHECKHUM still uses its prior fixed-one adapter; no production parity claim',
        'full lease, sequence, presence epoch, actual NPC/page body, DefaultNPC phases and deterministic replay remain open',
        'same-Source-CAS reservation/world outbox/application/recovery remains open'],
    'archive':{'file':archive.name,'entries':len(entries),'bytes':archive.stat().st_size,
        'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'everyEntryByteVerified':True},
    'entries':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in entries.items()}}
(out/'EVIDENCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in record.items() if key not in ['entries','finalTests']},indent=2))
