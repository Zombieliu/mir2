import hashlib, json, re, subprocess, zipfile
from datetime import datetime, timezone
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
root = repo / 'mir2-web3'
evidence = Path('C:/mir2-build/p7-npc-buff-20261010-evidence')
out = root / 'docs/generated/player-qa/npc-buff-catalog-20261010/candidate-01'
assert not out.exists()
final = {'20-compatible-buff-records-and-cold-login':15,
    'final-10-buff-duration-saved-shape':3, 'final-11-catalog-final-equivalence':3,
    'final-12-parser-omission-final':5, 'final-13-source-guard-final':8,
    'final-14-default-hooks-final':25, 'final-15-ordered-world-plan-final':32,
    'final-16-quest-endpoint-identity-final':2,
    '21-final-original-optimized-gateway-map-transfer':4}
records = {}
for stem, expected in final.items():
    before = json.loads((evidence/(stem+'-before.json')).read_text(encoding='utf-8-sig'))
    after = json.loads((evidence/(stem+'-after.json')).read_text(encoding='utf-8-sig'))
    assert before['source'] == after['source'], stem
    for row in after['source']:
        assert hashlib.sha256(Path(row['Path']).read_bytes()).hexdigest().upper() == row['Hash'], (stem,row['Path'])
    result = json.loads((evidence/(stem+'-result.json')).read_text(encoding='utf-8-sig'))
    log = (evidence/(stem+'.log')).read_text(encoding='utf-8-sig')
    match = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
    assert result['exitCode'] == 0 and match and tuple(map(int,match.groups())) == (expected,0,0), stem
    records[stem] = {'passed':expected,'failed':0,'ignored':0,'exitCode':0,
        'declaredPaths':len(after['source']),'beforeAfterStableAndCurrent':True}
node = (evidence/'final-17-node-default-source-generator.log').read_text(encoding='utf-8-sig')
assert '# pass 6' in node and '# fail 0' in node and '# skipped 0' in node
node_result = json.loads((evidence/'final-17-node-default-source-generator-result.json').read_text(encoding='utf-8-sig'))
assert node_result['exitCode'] == 0
adjacent = (evidence/'22-final-adjacent-original-npc.log').read_text(encoding='utf-8-sig')
assert 'test result: FAILED. 54 passed; 2 failed; 0 ignored;' in adjacent
failures = re.findall(r'^test (\S+) \.\.\. FAILED$',adjacent,re.M)
old = Path('C:/mir2-build/p7-npc-parser-20261009-evidence/10-frozen-4baa-adjacent-baseline.log').read_text(encoding='utf-8-sig')
assert failures == re.findall(r'^test (\S+) \.\.\. FAILED$',old,re.M) and len(failures)==2
timing = re.findall(r'normal purification scroll chain completed: targetFirst=(true|false), deadline=(\d+), before=(\d+), between=(\d+), after=(\d+)',
    (evidence/'21-final-original-optimized-gateway-map-transfer.log').read_text(encoding='utf-8-sig'))
assert len(timing)==2 and {row[0] for row in timing}=={'true','false'}
timing = [{'targetFirst':row[0]=='true','deadline':int(row[1]),'before':int(row[2]),'between':int(row[3]),'after':int(row[4]),'headroomMs':int(row[1])-int(row[4])} for row in timing]
assert all(row['headroomMs']>0 for row in timing)
git=['git','-c','safe.directory='+repo.as_posix(),'-c','gc.auto=0','-c','maintenance.auto=false','-C',str(repo)]
unchanged = ['mir2-web3/apps/gateway/tests/shared_purification_map_transfer.rs',
    'mir2-web3/tools/generate-crystal-default-npc-scripts.mjs',
    'mir2-web3/tools/generate-crystal-default-npc-scripts.test.mjs',
    'mir2-web3/packages/game-data/data/generated/crystal_default_npc_scripts.json',
    'mir2-web3/packages/game-data/data/generated/crystal_npc_manifest.json',
    'mir2-web3/packages/game-data/data/generated/crystal_buff_manifest.json']
for name in unchanged:
    assert subprocess.check_output(git+['show','20cee44303012dc83260181b53fd0d2dcd21900a:'+name]) == (repo/name).read_bytes(), name
source_enum = Path('E:/mir2/Crystal/Shared/Enums.cs').read_text(encoding='utf-8-sig')
enum_body=re.search(r'public enum BuffType : byte\s*\{(.*?)\n\}',source_enum,re.S).group(1)
source_names=set(re.findall(r'^\s*([A-Za-z]\w*)\s*(?:=\s*\d+)?\s*,',enum_body,re.M))
buffs=json.loads((root/'packages/game-data/data/generated/crystal_buff_manifest.json').read_bytes())['buffs']
assert {row['buffType'] for row in buffs} == source_names-{'None'} and len(buffs)==59
entries={}
def add(name,path):
    assert name not in entries
    entries[name]=Path(path).read_bytes()
for path in sorted(evidence.iterdir()):
    if path.is_file(): add('local/'+path.name,path)
ci=Path('C:/mir2-build/p7-npc-parser-20261009-ci/server-ci-01')
for path in sorted((ci/'failure-01').iterdir()):
    if path.is_file(): add('failed-20cee-ci/'+path.name,path)
for name in ['DISPATCH-REQUEST.json','DISPATCH-RESULT.json','RUN-IDENTIFIED.json','snapshot-02-runs.json','snapshot-02-jobs.json','snapshot-02.json']:
    add('failed-20cee-ci/'+name,ci/name)
published=Path('C:/mir2-build/p7-npc-parser-20261009-git-publication-01/exact-api')
for name in ['REF-REQUEST.json','REF-RESULT.json','PUBLISHED-VERIFIED.json']:
    add('previous-exact-git/'+name,published/name)
owned=['.github/workflows/gateway-release.yml']+['mir2-web3/apps/simulation/src/runtime/'+name+'.rs' for name in
    ['npc','npc_script','buffs','buff_duration','session','mod','npc_buff_action_tests','npc_catalog_lookup_tests']]
for name in owned+unchanged: add('final-source/'+name,repo/name)
for name in ['Run-NpcBuffRoot.ps1','Run-NpcBuffFinal.ps1','Run-NpcBuffGatewayRelease.ps1','Archive-NpcBuffRound.py']:
    add('runners/'+name,repo.parent/name)
add('baseline/frozen-4baa-adjacent-original.log','C:/mir2-build/p7-npc-parser-20261009-evidence/10-frozen-4baa-adjacent-baseline.log')
out.mkdir(parents=True)
archive=out/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in entries.items(): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    assert all(z.read(name)==data for name,data in entries.items())
record={'utc':datetime.now(timezone.utc).isoformat(),'baseSource':'20cee44303012dc83260181b53fd0d2dcd21900a',
    'implemented':True,'locallyTested':True,'newSourcePublishedToGit':False,'gatewayPublished':False,'humanAccepted':False,
    'publicGateway':'c70436f34eabb432d769e0082c0afa23303294b0','publicClient':'R23/sourcefaef/signedfeed18',
    'finalLocalTests':records,'node':{'passed':6,'failed':0,'skipped':0},
    'adjacent':{'passed':54,'failed':2,'samePriorFailures':failures,'narrowerThanPrior104Filter':True},
    'originalGatewayTestsAndSourceInputsUnchanged':unchanged,'originalBuffEnumRosterVerified':len(source_names),
    'localOriginalClockTiming':timing,'failedOriginalLinuxRun':37955396469,
    'archive':{'file':archive.name,'entries':len(entries),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'everyEntryByteVerified':True},
    'limits':['selected inputs, not complete Cargo/toolchain closure','prior clock-layout schema test, not old binary execution',
        'prepared Source item/NPC fixtures and trusted projection, not native/public travel','new exact Linux/publication required',
        'full Buff side effects/numeric semantics and shared world population/outbox remain open'],
    'entries':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in entries.items()}}
(out/'EVIDENCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in record.items() if key not in ['entries','finalLocalTests']},indent=2))
