param([string]$Round='')
$ErrorActionPreference='Stop'
$taskRunner='E:/mir2-player-journey/tmp/Run-NpcBuffRoot.ps1'
$taskGroups=@(
    @('10-buff-duration-saved-shape','buff_duration::tests'),
    @('11-catalog-final-equivalence','npc_catalog_lookup_tests'),
    @('12-parser-omission-final','npc_parser_omission_tests'),
    @('13-source-guard-final','npc_source_guard_tests'),
    @('14-default-hooks-final','default_npc_events_tests'),
    @('15-ordered-world-plan-final','npc_world_plan::tests'),
    @('16-quest-endpoint-identity-final','quest_endpoint_identity_tests')
)
foreach($taskGroup in $taskGroups){
    & $taskRunner -LogStem ($Round+$taskGroup[0]) -ToolArgs @('+1.95.0','test','--locked','--offline','-p','mir2-simulation','--features','test-support','--lib',$taskGroup[1],'--','--nocapture','--test-threads=1')
    if($LASTEXITCODE -ne 0){ exit $LASTEXITCODE }
}
& $taskRunner -LogStem ($Round+'17-node-default-source-generator') -Tool node -ToolArgs @('--test','tools/generate-crystal-default-npc-scripts.test.mjs')
exit $LASTEXITCODE
