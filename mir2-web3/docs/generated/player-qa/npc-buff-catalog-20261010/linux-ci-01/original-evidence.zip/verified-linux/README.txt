Mir2 Gateway release package.

The Gateway and authoritative Zone Host are built from the same revision and
must be deployed together when account or simulation behavior changes.

Threat boundary:
  The release URL and archive are untrusted transport. Authenticity comes only
  from /etc/mir2/gateway-release.pin, provisioned root:root mode 0600 through a
  separately authenticated configuration-management channel. Caller
  environment URL/SHA/tag values, the adjacent .sha256 file, RELEASE.json, and
  files fetched from the release URL are never an authenticity root.
  Configuration management must derive the exact pin digest from an
  independently authenticated artifact-registry API/channel, never by copying
  the publisher .sha256 sidecar. The root installer hashes the downloaded
  archive again from its already-open FD and compares that digest to the pin;
  it never reads the sidecar.

  Packaging must run as a dedicated non-root publisher and requires
  MIR2_RELEASE_PUBLISHER_UID to exactly equal that effective UID. That UID,
  every process able to act as it, and its source/build tree are the publisher
  trust boundary. Do not package from a shared or attacker-writable checkout.

  This archive contains exactly four non-link ustar members: mir2-gateway,
  zone_host, RELEASE.json, and README.txt. It intentionally contains no
  installer/helper, systemd unit, environment template, recovery key, or
  recovery sidecar. Archive bytes are never executed as installer code. The
  fixed trusted installer generates the exact systemd unit itself.

  Packaging uses a publisher-private mode-0700 stage and a mode-0700 output
  directory whose complete ancestry, owner, mode, nlink, and held directory FD
  are verified. Source members stay open while ustar bytes are produced; the
  archive digest is calculated from that same archive FD. The sidecar is
  published no-replace first and is tentative until the archive is published
  no-replace as the transaction commit record. A boot/process-bound marker and
  bounded next-run sweep remove a verified orphan sidecar or finish cleanup
  after SIGKILL; unknown, linked, over-age live, or over-limit residue fails
  closed. Thus a crash exposes either no committed archive or an archive plus
  its exact matching sidecar, never a different archive blessed by that hash.

Mandatory out-of-band bootstrap:
  Provision these independently of the archive and release URL:
    /usr/local/libexec/mir2/install-gateway-release.sh
      root:root mode 0755, nlink=1
    /usr/local/share/mir2/gateway/mir2-gateway.env.example
      root:root mode 0644, nlink=1
    /etc/mir2/gateway-release.pin
      root:root mode 0600, nlink=1

  Every ancestor must be a real root-owned directory that is not writable by
  group/other. Invoke the fixed installer through its #!/bin/bash -p shebang
  from a sanitized root execution context. If this bootstrap cannot be proved,
  installation fails closed; there is no workspace-script or archive-helper
  fallback.

Install layout:
  root-owned:    /opt/mir2/gateway/releases/<tag>/{mir2-gateway,zone_host}
  root-owned:    /opt/mir2/gateway/current -> releases/<tag>
  service-owned: /var/lib/mir2/gateway-data
  root-owned:    /var/lib/mir2/save-recovery and its v1 namespace
  service-owned: /var/lib/mir2/save-recovery/v1/gateway (mode 0700)
  service-owned: /var/log/mir2
  root-owned:    /etc/mir2/gateway.env (mode 0600)

Installer runtime assumptions:
  Linux/systemd, /bin/bash with privileged mode, /usr/bin/python3 with dir_fd,
  O_NOFOLLOW/fchown/fchmod/fsync, RLIMIT_FSIZE, renameat2(RENAME_NOREPLACE),
  prctl(PR_SET_PDEATHSIG), a mounted readable procfs boot_id and process stat,
  /usr/bin/curl, GNU getent/id/user-management tools, local passwd/group/shadow/
  gshadow databases, files-only passwd/group/shadow/gshadow NSS configured in
  root-owned /etc/nsswitch.conf, and login.defs with all SYS_UID/GID bounds.
  The systemd manager must support ProtectProc/ProcSubset,
  namespace/device/kernel
  protections, RestrictAddressFamilies, and @system-service syscall groups.
  Filesystems containing /tmp, /var/tmp, /opt, /etc, and the artifact OUT_DIR
  must provide O_NOFOLLOW dirfd operations, directory fsync, and same-filesystem
  atomic renameat2. Curl runs with -q, never follows
  redirects, accepts a pinned HTTPS URL without query/fragment/credentials, and
  writes its body to an already-open root-private FD under a kernel-enforced
  file-size limit. The installer bounds compressed bytes, expanded bytes,
  member count, header/name forms, and individual member sizes before copying
  from the same authenticated archive FD into O_EXCL destinations. A completed
  release is published from an unreferenced temporary directory with atomic
  no-replace rename; failed temporary releases are safely removed and retryable.
  Download and release/config transactions carry root-owned markers tied to the
  initiating process start time and Linux boot ID. Every startup performs a
  count/age/byte-bounded dirfd sweep; dead-owner residues are removed through
  the already-open parent and unknown entries are never traversed or deleted.
  First creation of gateway.env and the fixed unit uses a fully written,
  validated, fsynced private payload followed by no-replace publication and a
  parent-directory fsync. Existing or truncated files are never overwritten or
  silently accepted.
  --activate additionally requires independently strong authenticated
  Postgres and Redis URLs; template/public/default credentials and
  unauthenticated Redis are rejected without logging credential material.

Ownership migration:
  Existing service-owned /opt/mir2/gateway or /var/lib/mir2 roots are refused.
  Migrate legacy ownership manually: release/data/recovery namespaces remain
  root-owned and non-writable by group/other; only gateway-data, the final
  recovery instance leaf, and the log directory belong to the service account.
  An existing mir2 identity is accepted only when root-owned local passwd,
  group, shadow, and gshadow records exactly agree with full NSS/getent output;
  all four identity NSS databases must be configured as exactly files-only so
  enumeration proves numeric uniqueness (non-enumerating remote backends are
  unsupported and fail closed); login.defs supplies the supported system
  UID/GID ranges; password and group
  markers are explicit and both shadow databases are locked; UID/GID values are
  unique; the mir2 group has no members/admins; the home and nologin/false shell
  are fixed; and id(1) reports only the mir2 primary group. Remote, duplicate,
  interactive, shared-ID, or reused identities fail closed before directory
  ownership is created.

Save-recovery backup and restore:
  MIR2_SAVE_RECOVERY_MAC_KEY is generated once during the first install and is
  not included in this package. Recovery sidecars under MIR2_SAVE_RECOVERY_DIR
  are also not included. Back up the original key and all sidecars as one
  protected recovery set, and restore both together before Gateway startup.
  Rotating or losing the key makes retained sidecars unusable; restoring only
  the key or only the sidecars is insufficient.

Linux security gate:
  CI must run scripts/selftest-gateway-save-recovery.sh on a non-root Linux
  worker with MIR2_REQUIRE_LINUX_SECURITY_GATE=1. MINGW results do not validate
  Linux RLIMIT_FSIZE streaming, atomic publication, dirfd, owner/mode/nlink,
  symlink-race, or same-FD copy behavior.
