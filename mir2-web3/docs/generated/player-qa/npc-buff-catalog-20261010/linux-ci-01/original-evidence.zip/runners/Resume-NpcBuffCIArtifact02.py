"""Recover only the missing authenticated range; keep the timed-out ZIP."""
import hashlib
import json
import re
import subprocess
from pathlib import Path

base = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-ci-01')
old = base / 'artifact-01'
out = base / 'artifact-resume-02'
metadata = json.loads((old / 'ci-artifacts-original.json').read_bytes())['artifacts'][0]
assert metadata['id'] == 11638344918 and metadata['size_in_bytes'] == 33854431
assert metadata['digest'] == 'sha256:525516fe3d4fc465265ecff178ffcc574dbf73ca846ac1e1aa431c0c6e36358b'
assert metadata['workflow_run']['head_sha'] == 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9'
prefix = (old / 'github-artifact-original.zip').read_bytes()
assert len(prefix) == 29655040
out.mkdir(exist_ok=False)
attempt = {'schema': 'mir2.npc-buff.ci-artifact-incomplete-attempt.v1',
    'originalDownloadTimedOutSeconds': 300, 'originalPartialPreserved': True,
    'originalPartialBytes': len(prefix), 'originalPartialSha256': hashlib.sha256(prefix).hexdigest(),
    'qualified': False, 'serverSwitched': False}
with (out / 'INCOMPLETE-ORIGINAL.json').open('x') as stream:
    json.dump(attempt, stream, indent=2)
    stream.write('\n')
command = ['gh', 'api', '--include', 'repos/Zombieliu/mir2/actions/artifacts/11638344918/zip',
    '--header', 'Accept-Encoding: identity', '--header', f'Range: bytes={len(prefix)}-']
with (out / 'remaining-range-response.private-http').open('xb') as stream:
    result = subprocess.run(command, stdout=stream, stderr=subprocess.PIPE, timeout=180)
with (out / 'command-stderr.log').open('xb') as stream:
    stream.write(result.stderr)
assert result.returncode == 0, 'Original range download failure retained'
raw = (out / 'remaining-range-response.private-http').read_bytes()
header, tail = raw.split(b'\r\n\r\n', 1)
assert re.match(rb'HTTP/[^ ]+ 206 ', header)
fields = {}
for line in header.split(b'\r\n')[1:]:
    key, value = line.split(b':', 1)
    key = key.decode().lower()
    assert key not in fields or key in ('server-timing',)
    fields[key] = value.strip().decode()
assert fields.get('content-range') == f'bytes {len(prefix)}-{metadata["size_in_bytes"] - 1}/{metadata["size_in_bytes"]}'
assert fields.get('content-encoding') in (None, 'identity')
assert len(tail) == metadata['size_in_bytes'] - len(prefix)
assert int(fields['content-length']) == len(tail)
whole = prefix + tail
assert hashlib.sha256(whole).hexdigest() == metadata['digest'].split(':', 1)[1]
with (out / 'github-original-complete.zip').open('xb') as stream:
    stream.write(whole)
record = {'schema': 'mir2.npc-buff.ci-artifact-range-recovery.v1', 'passed': True,
    'originalPartialPreserved': True, 'originalPartialSha256': hashlib.sha256(prefix).hexdigest(),
    'originalPartialBytes': len(prefix), 'remainingBytes': len(tail), 'status': 206,
    'contentRange': fields['content-range'], 'completeBytes': len(whole),
    'completeSha256': hashlib.sha256(whole).hexdigest(), 'githubArtifactDigestVerified': True,
    'source': 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9',
    'privateResponseHeadersCopiedIntoPublicEvidence': False, 'serverSwitched': False}
with (out / 'RECOVERY-VERIFIED.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
