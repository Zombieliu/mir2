"""Change only acquisition; preserve every original qualification gate."""
import ast
import hashlib
import json
from pathlib import Path

source = Path('E:/mir2-player-journey/tmp/Download-NpcBuffLinuxCI.py')
target = Path('E:/mir2-player-journey/tmp/Verify-Recovered-NpcBuffCI02.py')
old = source.read_bytes()
body = old.decode()
left = "OUT=ROOT/'server-ci-01/artifact-01'"
right = "OUT=ROOT/'server-ci-01/artifact-resume-02/verified'"
assert body.count(left) == 1
body = body.replace(left, right)
acquisition = '''bundle=OUT/'github-artifact-original.zip'
with bundle.open('xb') as stream:
    result=subprocess.run(['gh','api',f'repos/{REPO}/actions/artifacts/{artifact["id"]}/zip'],
                          stdout=stream,stderr=subprocess.PIPE,timeout=300)
assert result.returncode==0,result.stderr.decode(errors='replace')'''
replacement = '''recovery_root=ROOT/'server-ci-01/artifact-resume-02'
recovery_raw=(recovery_root/'RECOVERY-VERIFIED.json').read_bytes()
recovery=json.loads(recovery_raw)
assert recovery['passed'] is True and recovery['source']==REVISION
assert recovery['status']==206 and recovery['githubArtifactDigestVerified'] is True
partial=ROOT/'server-ci-01/artifact-01/github-artifact-original.zip'
assert partial.stat().st_size==recovery['originalPartialBytes']
assert digest(partial.read_bytes())==recovery['originalPartialSha256']
bundle=recovery_root/'github-original-complete.zip'
assert digest(bundle.read_bytes())==recovery['completeSha256']
new(OUT/'ORIGINAL-ACQUISITION-RECOVERY.json',recovery_raw)'''
if '\r\n' in body:
    acquisition = acquisition.replace('\n', '\r\n')
    replacement = replacement.replace('\n', '\r\n')
assert body.count(acquisition) == 1
body = body.replace(acquisition, replacement)
marker = "archive_name='mir2-gateway-linux-x64-'+TAG+'.tar.gz'"
assert body.count(marker) == old.decode().count(marker) == 1
assert body.split(marker, 1)[1] == old.decode().split(marker, 1)[1]
def functions(data):
    return {node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(data).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
assert functions(old) == functions(body)
with target.open('x', encoding='utf-8') as stream:
    stream.write(body)
record = {'schema': 'mir2.npc-buff.ci-verifier-recovery-derivation.v1',
    'originalVerifierSha256': hashlib.sha256(old).hexdigest(),
    'recoveredVerifierSha256': hashlib.sha256(body.encode()).hexdigest(),
    'completeZipAndAllFollowingGatesByteUnchanged': True,
    'originalVerificationFunctionsIdentical': True, 'source': 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9',
    'executed': False, 'serverSwitched': False}
out = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-ci-01')
with (out / 'RECOVERED-VERIFIER-PREPARATION.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
