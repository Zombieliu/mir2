"""Point the original drained driver at the genuinely recovered artifact."""
import ast
import hashlib
import json
from pathlib import Path

root = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-rollout-01')
source = root / 'deploy-npc-buff-gateway-01.py'
target = root / 'deploy-npc-buff-gateway-02.py'
old = source.read_bytes()
proof = json.loads((root / 'PREPARATION.json').read_bytes())
assert hashlib.sha256(old).hexdigest() == proof['driverSha256']
body = old.decode()
left = "CI=Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-ci-01/artifact-01')"
right = "CI=Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-ci-01/artifact-resume-02/verified')"
assert body.count(left) == 1
body = body.replace(left, right)
def functions(data):
    return {node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(data).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
assert functions(old) == functions(body)
with target.open('xb') as stream:
    stream.write(body.encode())
record = {'schema': 'mir2.npc-buff.recovered-deploy-driver.v1',
    'sourceDriverSha256': hashlib.sha256(old).hexdigest(),
    'actualPreparedDriverSha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    'onlyArtifactPathChanged': True, 'allDriverFunctionsAstIdentical': True,
    'allDrainBackupShutdownAndPublicGatesRetained': True,
    'candidate': proof['candidate'], 'previous': proof['previous'], 'executed': False}
with (root / 'RECOVERED-DRIVER-PREPARATION.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
