"""Retain and correct the preparation's Windows newline/hash accounting."""
import ast
import hashlib
import json
from pathlib import Path

root = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-ci-01')
old = Path('E:/mir2-player-journey/tmp/Download-NpcBuffLinuxCI.py').read_bytes()
actual = Path('E:/mir2-player-journey/tmp/Verify-Recovered-NpcBuffCI02.py').read_bytes()
original_proof = (root / 'RECOVERED-VERIFIER-PREPARATION.json').read_bytes()
def functions(data):
    return {node.name: ast.dump(node, include_attributes=False)
        for node in ast.parse(data).body if isinstance(node, (ast.FunctionDef, ast.ClassDef))}
assert functions(old) == functions(actual)
marker = "archive_name='mir2-gateway-linux-x64-'+TAG+'.tar.gz'"
old_tail = old.decode().split(marker, 1)[1]
actual_tail = actual.decode().split(marker, 1)[1]
canonical = lambda text: text.replace('\r\r\n', '\n').replace('\r\n', '\n')
assert canonical(old_tail) == canonical(actual_tail)
assert ast.dump(ast.parse(old_tail), include_attributes=False) == ast.dump(ast.parse(actual_tail), include_attributes=False)
record = {'schema': 'mir2.npc-buff.ci-verifier-actual-byte-accounting.v1',
    'originalPreparationRetainedSha256': hashlib.sha256(original_proof).hexdigest(),
    'originalVerifierSha256': hashlib.sha256(old).hexdigest(),
    'actualExecutedVerifierSha256': hashlib.sha256(actual).hexdigest(),
    'preparedStringSha256': json.loads(original_proof)['recoveredVerifierSha256'],
    'windowsTextWriteTranslatedExistingCrLf': True,
    'previousWholeByteAndTailByteClaimsSuperseded': True,
    'allVerificationFunctionsAstIdentical': True,
    'allOriginalZipAndFollowingGatesAstIdentical': True,
    'tailEquivalentAfterOnlyNewlineNormalization': True,
    'zipOrGateAssertionsRelaxed': False, 'serverSwitched': False}
with (root / 'RECOVERED-VERIFIER-ACTUAL-BYTES.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
