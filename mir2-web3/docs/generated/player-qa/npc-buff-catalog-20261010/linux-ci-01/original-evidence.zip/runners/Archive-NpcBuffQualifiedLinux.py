import hashlib, json, re, zipfile
from datetime import datetime, timezone
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
root = repo / 'mir2-web3'
ci = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-ci-01')
recovery = ci/'artifact-resume-02'
verified = recovery/'verified'
rollout = Path('C:/mir2-build/p7-npc-buff-20261010-ci/server-rollout-01')
publication = Path('C:/mir2-build/p7-npc-buff-20261010-git-publication-01/exact-api')
out = root/'docs/generated/player-qa/npc-buff-catalog-20261010/linux-ci-01'
assert not out.exists()
receipt = json.loads((verified/'CI-VERIFIED.json').read_bytes())
assert receipt['revision'] == 'ecd81f6a1528e0a1a85bfd920356f607bc37a2a9'
assert receipt['runId'] == '37970933774' and receipt['runConclusion'] == 'success'
assert all(row['conclusion'] == 'success' for row in receipt['jobs']) and len(receipt['jobs']) == 2
assert receipt['publicR2Upload'] is False and receipt['serverSwitched'] is False
for filename, sha_key in [('mir2-gateway','binarySha256'),('zone_host','zoneHostBinarySha256'),
    ('mir2-gateway-linux-x64-2026-10-10-npc-buff-ecd81f6a15.tar.gz','archiveSha256'),
    ('VERIFIED-FILES.json','manifestSha256'),('ci-log-original.txt','logSha256')]:
    assert hashlib.sha256((verified/filename).read_bytes()).hexdigest() == receipt[sha_key]
recovered = json.loads((recovery/'RECOVERY-VERIFIED.json').read_bytes())
assert hashlib.sha256((recovery/'github-original-complete.zip').read_bytes()).hexdigest() == receipt['githubArtifactDigest'].split(':')[1]
assert (recovery/'github-original-complete.zip').stat().st_size == receipt['githubArtifactBytes']
preflight = json.loads((rollout/'deploy-before-01.log').read_bytes())
counters = preflight['test']['capacity']
keys = ['currentWsConnections','currentActiveSessions','currentReconnectLeases',
        'currentLoginInFlight','currentNewCharacterInFlight','currentStartGameInFlight']
assert counters['currentWsConnections'] == 1 and all(counters[key] == 0 for key in keys[1:])
assert preflight['test']['revision'] == 'c70436f34eabb432d769e0082c0afa23303294b0'
actual = json.loads((ci/'RECOVERED-VERIFIER-ACTUAL-BYTES.json').read_bytes())
entries = {}
def add(name,path):
    assert name not in entries and not name.endswith('private-http')
    data = Path(path).read_bytes()
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',data)
    entries[name] = data
for name in ['DISPATCH-REQUEST.json','DISPATCH-RESULT.json','RUN-IDENTIFIED.json']:
    add('original-ci/'+name,ci/name)
for path in sorted(ci.glob('snapshot-*')):
    if path.is_file(): add('original-ci/'+path.name,path)
for name in ['ci-status-original.json','ci-artifacts-original.json','ci-log-original.txt','CI-VERIFIED.json',
             'RELEASE.json','VERIFIED-FILES.json','latest-mir2-gateway-release.json',
             'mir2-gateway-linux-x64-2026-10-10-npc-buff-ecd81f6a15.tar.gz.sha256',
             'ORIGINAL-ACQUISITION-RECOVERY.json','README.txt']:
    add('verified-linux/'+name,verified/name)
for name in ['INCOMPLETE-ORIGINAL.json','RECOVERY-VERIFIED.json']:
    add('range-recovery/'+name,recovery/name)
for name in ['RECOVERED-VERIFIER-PREPARATION.json','RECOVERED-VERIFIER-ACTUAL-BYTES.json']:
    add('range-recovery/'+name,ci/name)
for path in sorted(Path('C:/mir2-build/p7-npc-population-20261010-evidence/archive-preparation-01').iterdir()):
    if path.is_file(): add('initial-archive-preparation/'+path.name,path)
for name in ['PUBLISHED-VERIFIED.json','REF-REQUEST.json','REF-RESULT.json']:
    add('exact-git/'+name,publication/name)
for name in ['PREPARATION.json','RECOVERED-DRIVER-PREPARATION.json','deploy-before-01.log']:
    add('held-rollout/'+name,rollout/name)
for name in ['Download-NpcBuffLinuxCI.py','Resume-NpcBuffCIArtifact02.py',
             'Prepare-Recovered-NpcBuffCIVerifier.py','Verify-Recovered-NpcBuffCI02.py',
             'Verify-NpcBuffVerifierBytes.py','Prepare-NpcBuffRecoveredDeployDriver.py',
             'Archive-NpcBuffQualifiedLinux.py']:
    add('runners/'+name,repo.parent/name)
out.mkdir(parents=True)
archive = out/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in entries.items(): z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(entries)
    assert all(z.read(name) == data for name,data in entries.items())
record = {'createdUtc':datetime.now(timezone.utc).isoformat(),
    'revision':receipt['revision'],'sourceCommittedAndRemoteVerified':True,
    'exactLinuxPassed':True,'runId':receipt['runId'],'url':receipt['url'],
    'artifactVerified':True,'linuxReceipt':receipt,
    'recovery':{'originalTimeoutSeconds':300,'originalPartialPreserved':True,
        'rangeResponse':206,'remainingBytes':4199391,
        'completeBytes':receipt['githubArtifactBytes'],'completeSha256':receipt['githubArtifactDigest'],
        'allFinalArchiveAndGateChecksRetained':True,
        'initialVerifierPreparationReceiptRetainedButByteClaimsSuperseded':True,
        'actualVerifierByteAccounting':actual},
    'rollout':{'applyDriverInvoked':True,'stoppedBeforeRemoteStageOrServiceMutation':True,
        'ready':False,'reason':'one WebSocket connection has not drained','capacityCounters':{key:counters[key] for key in keys},
        'tcp7200':preflight['tcp7200'],'spectatorViewers':preflight['test']['spectator']['activeViewers'],
        'childSystemExit':75,'powershellToolExit':1,'gatewayPublished':False},
    'publicGateway':preflight['test']['revision'],'publicClient':'R23/sourcefaef/signedfeed18',
    'nativeAccepted':False,'humanAccepted':False,'fullGoalComplete':False,
    'privateResponseHeadersAndBinaryZipExcluded':True,
    'initialArchivePreparationFailuresRetained':True,
    'archive':{'file':archive.name,'entries':len(entries),'bytes':archive.stat().st_size,
        'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'everyEntryByteVerified':True},
    'entries':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in entries.items()}}
(out/'EVIDENCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:value for key,value in record.items() if key not in ['entries','recovery','linuxReceipt']},indent=2))
