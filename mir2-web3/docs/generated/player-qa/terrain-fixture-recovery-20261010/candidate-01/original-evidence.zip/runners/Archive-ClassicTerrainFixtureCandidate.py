"""Freeze original failures and completed final checks; never overwrite evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

REPO = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
BASE = '348caa5e4b3b8bb3d63e3d2af80803e958adafee'
EV = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence')
OUT = REPO / 'mir2-web3/docs/generated/player-qa/terrain-fixture-recovery-20261010/candidate-01'
GIT = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
       '-c', 'safe.directory=' + REPO.as_posix(), '-C', str(REPO)]
FINAL = [
    'check-07-final-integration-workflow-gates',
    'check-08-final-simulation-workflow-gates',
    'check-09-final-classic-source-workflow-gates',
    'check-12-final-gateway-classic-workflow-jobs1',
    'check-13-final-gateway-owner-source-lib',
    'check-14-final-gateway-transfer-release-lib',
    'check-16-final-ordinary-snake-missing-map',
    'check-22-original-shared-zone-after-space-recovery',
    'check-18-final-gateway-movement-population-lib',
]
TIMING = [
    ('check-15-final-gateway-purification-release', 101, 'original-timing-gate-failed'),
    ('check-19-diagnostic-original-scroll-repeat', 0, 'single-diagnostic-repeat-passed'),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def new_json(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

assert subprocess.check_output(GIT + ['rev-parse', 'HEAD']).decode().strip() == BASE
assert not OUT.exists()
frozen = json.loads((EV / 'SOURCE-FROZEN-01.json').read_bytes())
changed = subprocess.check_output(GIT + ['diff', '--name-only']).decode().splitlines()
assert set(changed) == {entry['path'] for entry in frozen['changedTests']}
assert len(changed) == 8
source = {}
fixture_tests = {}
for entry in frozen['changedTests']:
    name = entry['path']
    candidate = (REPO / name).read_bytes()
    original = subprocess.check_output(GIT + ['show', BASE + ':' + name])
    assert sha(candidate) == entry['candidateSha256']
    assert sha(original) == entry['originalSha256']
    assert original == (EV / 'candidate-sources-01/original' / name).read_bytes()
    assert candidate == (EV / 'candidate-sources-01/candidate' / name).read_bytes()
    old_names = re.findall(rb'#\[test\]\s*fn\s+([A-Za-z0-9_]+)\(', original)
    new_names = re.findall(rb'#\[test\]\s*fn\s+([A-Za-z0-9_]+)\(', candidate)
    assert old_names == new_names and old_names
    assert original.count(b'#[ignore') == candidate.count(b'#[ignore')
    source[name] = sha(candidate)
    fixture_tests[name] = {'testNamesUnchanged': True, 'testCount': len(old_names),
                           'ignoredTestsAddedOrRemoved': False}

# Scope is canonical tracked content, with the recorded raw map.rs EOL difference.
product_paths = subprocess.check_output(GIT + ['ls-files', 'mir2-web3/apps/simulation',
                                              'mir2-web3/apps/gateway']).decode().splitlines()
product_paths = [p for p in product_paths if p.endswith('.rs') and p not in changed]
for name in product_paths + ['.github/workflows/gateway-release.yml']:
    canonical = subprocess.check_output(GIT + ['show', BASE + ':' + name])
    assert (REPO / name).read_bytes().replace(b'\r\n', b'\n') == canonical.replace(b'\r\n', b'\n'), name
correction = json.loads((EV / 'SOURCE-EOL-CORRECTION-01.json').read_bytes())
assert correction['allProductRawWorkingBytesClaimedIdentical'] is False
assert correction['lfNormalizedProductContentIdentical'] is True

passes = set()
stable_passes = set()
failed = set()
ignored = set()
receipts = []
for stem, expected_exit, kind in [(stem, 0, 'selected-gate-passed') for stem in FINAL] + TIMING:
    result_raw = (EV / (stem + '-result.json')).read_bytes()
    result = json.loads(result_raw)
    assert result['exitCode'] == expected_exit, stem
    before = json.loads((EV / (stem + '-before.json')).read_bytes())
    after = json.loads((EV / (stem + '-after.json')).read_bytes())
    assert before['command'] == after['command']
    hashes_before = {p['Path']: p['Hash'].lower() for p in before['source']}
    hashes_after = {p['Path']: p['Hash'].lower() for p in after['source']}
    assert hashes_before == hashes_after and len(hashes_before) == 39, stem
    for path, digest in hashes_after.items():
        assert sha(Path(path).read_bytes()) == digest, (stem, path)
    args = before['command']
    package = args[args.index('-p') + 1]
    raw = (EV / (stem + '.log')).read_bytes()
    log = raw.decode('utf-8-sig')
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    expected_failures = 1 if expected_exit == 101 else 0
    assert summaries and sum(int(f) for _, f, _ in summaries) == expected_failures, stem
    active = None
    observed = []
    for line in log.splitlines():
        start = re.match(r'\s*Running (unittests src[\\/]lib\.rs|tests[\\/][\w]+\.rs) \(', line)
        if start:
            active = package + ':' + start[1].replace('\\', '/')
        match = re.match(r'test (.+) \.\.\. (ok|ignored|FAILED)(?:,.*)?$', line)
        if match:
            assert active is not None
            identity = active + ':' + match[1]
            observed.append((identity, match[2]))
            (passes if match[2] == 'ok' else ignored if match[2] == 'ignored' else failed).add(identity)
            if match[2] == 'ok' and kind == 'selected-gate-passed':
                stable_passes.add(identity)
    assert sum(int(p) for p, _, _ in summaries) == sum(s == 'ok' for _, s in observed), stem
    assert sum(int(i) for _, _, i in summaries) == sum(s == 'ignored' for _, s in observed), stem
    assert sum(int(f) for _, f, _ in summaries) == sum(s == 'FAILED' for _, s in observed), stem
    receipts.append({'stem': stem, 'resultSha256': sha(result_raw), 'logSha256': sha(raw),
                     'passedExecutions': sum(int(p) for p, _, _ in summaries),
                     'failedExecutions': sum(int(f) for _, f, _ in summaries),
                     'ignoredExecutions': sum(int(i) for _, _, i in summaries),
                     'exitCode': result['exitCode'], 'classification': kind,
                     'command': args, 'selectedPathCount': len(hashes_after),
                     'selectedBeforeAfterHashesEqual': True})

assert len(failed) == 1 and next(iter(failed)).endswith(
    ':normal_gateway_purification_survives_real_town_scroll_map_changes_in_both_actor_orders')
timing_commands = [json.loads((EV / (stem + '-before.json')).read_bytes())['command']
                   for stem, _, _ in TIMING]
assert timing_commands[0] == timing_commands[1]
assert b'deadline=1791619773549' in (EV / (TIMING[0][0] + '.log')).read_bytes()
assert b'after=1791619773580' in (EV / (TIMING[0][0] + '.log')).read_bytes()

node_stem = 'check-11-final-default-npc-generator'
node_result = json.loads((EV / (node_stem + '-result.json')).read_bytes())
node_log = (EV / (node_stem + '.log')).read_bytes()
assert node_result['exitCode'] == 0
assert b'# pass 6' in node_log and b'# fail 0' in node_log and b'# skipped 0' in node_log
assert len(ignored) == 1 and 'immutable_collision_real_map_clone_benchmark' in next(iter(ignored))

old_ci = Path('C:/mir2-build/p7-map-transfer-availability-20261010-ci/server-ci-01')
ci_log = old_ci / 'failed-job-log01-attempt-1.txt'
assert sha(ci_log.read_bytes()) == '9efe61073845156457faebc07b1dc859074b071d841f19d8404a848203348fac'
observation = json.loads((EV / 'CHECK10-MEMORY-FAILURE-OBSERVATION.json').read_bytes())
assert observation['testExecutionObserved'] is observation['actualWrapperExitCodeAvailable'] is False
assert not (EV / 'check-10-final-gateway-classic-workflow-gates-result.json').exists()

entries = []
OUT.mkdir(parents=True)
with zipfile.ZipFile(OUT / 'original-evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED,
                     compresslevel=9) as archive:
    def add(name, data):
        assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|Bearer [A-Za-z0-9_\-]{20,}|\bgh[ps]_[A-Za-z0-9]{20,}|X-Amz-Signature=[A-Fa-f0-9]{64}', data), name
        assert name not in {e['path'] for e in entries}
        archive.writestr(name, data)
        entries.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    for path in sorted(EV.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            add('raw/' + path.relative_to(EV).as_posix(), path.read_bytes())
    for name in ['Run-ClassicFixtureQualificationFinal.ps1', 'Run-SnakeRecoveryQualification.ps1',
                 'Repair-PurificationAndCrowdedFixtures.py', 'Record-FixtureEolScopeCorrection.py',
                 'Record-ClassicFixtureBuildFailure.py', 'Prepare-FinalFixtureQualificationRunner.py',
                 'Run-RemainingClassicFixtureGates.py',
                 'Resume-ClassicFixtureGatesAfterDiagnostic.py', 'Run-RetainedClassicFixtureGates.py',
                 'Run-ClassicOriginalPurificationLowDebug.py',
                 'Archive-ClassicTerrainFixtureCandidate.py']:
        add('runners/' + name, (Path(__file__).parent / name).read_bytes())
    add('failed-linux348/' + ci_log.name, ci_log.read_bytes())
    add('failed-linux348/FAILED-JOB-LOG01-ATTEMPT-1.json',
        (old_ci / 'FAILED-JOB-LOG01-ATTEMPT-1.json').read_bytes())
    for stem in FINAL:
        after = json.loads((EV / (stem + '-after.json')).read_bytes())
        if stem == FINAL[0]:
            for row in after['source']:
                path = Path(row['Path'])
                add('selected-final-source/' + path.relative_to(REPO).as_posix(), path.read_bytes())
    add('source/final-fixture-only.patch', subprocess.check_output(GIT + ['diff', '--binary', '--'] + changed))
    for name in product_paths:
        if name.endswith('/runtime/zone/runtime/checkpoint.rs'):
            add('source/retained-strict-checkpoint.rs', (REPO / name).read_bytes())
    add('source/retained-npc-generator.mjs', (REPO / 'mir2-web3/tools/generate-crystal-default-npc-scripts.mjs').read_bytes())
    add('source/retained-npc-generator.test.mjs', (REPO / 'mir2-web3/tools/generate-crystal-default-npc-scripts.test.mjs').read_bytes())

archive = OUT / 'original-evidence.zip'
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None and len(zipped.infolist()) == len(entries)
    assert len(set(zipped.namelist())) == len(entries)
    for entry in entries:
        assert sha(zipped.read(entry['path'])) == entry['sha256']
assert archive.stat().st_size <= 3 * 1024**2
record = {
    'schema': 'mir2.classic-terrain-fixture-recovery.candidate.v1',
    'utc': datetime.now(timezone.utc).isoformat(), 'parent': BASE,
    'sourceSha256': source, 'unchangedTestNames': fixture_tests,
    'canonicalOtherRustFilesCompared': len(product_paths),
    'productionRecoveryCollisionPermissionOrWorkflowContentChanged': False,
    'rawWorkingEolScopeCorrection': correction,
    'localRustPassedDistinct': len(passes), 'localNodePassedDistinct': 6,
    'localPassedDistinct': len(passes) + 6,
    'localSelectedNonDiagnosticRustPassedDistinct': len(stable_passes),
    'allRequiredLocalChecksPass': False,
    'localStrictPurificationTimingGate': {
        'status': 'original-failed-once-single-diagnostic-repeat-passed',
        'failedTestIdentities': sorted(failed),
        'originalDeadlineMs': 500, 'observedBoundaryMissMs': 31,
        'sameCommandsAndSelectedSourceHashes': True,
        'timingDefectClaimedFixed': False,
        'additionalPassesUntilGreenPerformed': False,
    },
    'retainedIgnoredBenchmark': list(ignored), 'finalChecks': receipts,
    'passedRustTestIdentities': sorted(passes),
    'selectedHashScope': '39 selected paths; not a full toolchain/input closure',
    'failedParentLinuxRun': '38019332713', 'failedParentJob': '114116595817',
    'failedOriginalLogsRetained': True, 'compilerFailureObservation': observation,
    'sharedZoneCompileFailuresBeforeExecution': [
        {'stem': 'check-17-final-original-shared-zone-purification', 'exitCode': 101,
         'reported': 'memory allocation of 294928 bytes failed', 'testsExecuted': False},
        {'stem': 'check-20-original-shared-zone-low-debug-build', 'exitCode': 101,
         'reported': 'LNK1180 insufficient disk space', 'testsExecuted': False},
    ],
    'generatedCacheArchiveReceipt': json.loads((EV / 'GENERATED-INCREMENTAL-CACHE-ARCHIVE-01.json').read_bytes()),
    'allOriginalAssertionsDeadlinesAndPermissionsRetained': True,
    'strictColdRecoveryAndOrdinaryMissingMapGuardWeakened': False,
    'trustedFarPurificationTransformIsNormalReachableMapProof': False,
    'sourceMapLoadPopulationOrNativeHumanAcceptanceClaimed': False,
    'liveGatewaySourceLastConfirmed': '64b6b10c05732048da9c6bf5ccb0a491d2d053d3',
    'newSourcePushed': False, 'newSourceLinuxQualified': False, 'newGatewayPublished': False,
    'fullClassicP1P7MentorComplete': False,
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                'sha256': sha(archive.read_bytes()), 'entries': len(entries)},
    'entries': entries,
}
new_json(OUT / 'EVIDENCE.json', record)
print(json.dumps({key: record[key] for key in ('parent', 'localRustPassedDistinct',
                 'localNodePassedDistinct', 'localPassedDistinct', 'archive', 'newSourcePushed')}))
