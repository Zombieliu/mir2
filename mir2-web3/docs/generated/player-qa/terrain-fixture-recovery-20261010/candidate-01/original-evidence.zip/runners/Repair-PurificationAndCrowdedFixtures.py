import hashlib
import json
from pathlib import Path
import subprocess

root = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
out = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence/root-fixture-repair-01')
base = '348caa5e4b3b8bb3d63e3d2af80803e958adafee'
git = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false',
       '-c', 'safe.directory='+root.as_posix(), '-C', str(root)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip() == base
out.mkdir()
records = []

def repair(name, substitutions):
    path = root / name
    before = path.read_bytes()
    assert before == subprocess.check_output(git+['show',base+':'+name]), name
    text = before.decode('utf-8')
    applied = []
    for old, new in substitutions:
        count = text.count(old)
        assert count > 0 and new not in text, (name,old)
        text = text.replace(old,new)
        applied.append((old,new,count))
    inverse = text
    for old,new,count in reversed(applied):
        assert inverse.count(new) == count, (name,new)
        inverse = inverse.replace(new,old)
    assert inverse.encode('utf-8') == before
    target = out / Path(name).name
    target.with_suffix(target.suffix+'.before').write_bytes(before)
    path.write_bytes(text.encode('utf-8'))
    records.append({'path':name,'originalSha256':hashlib.sha256(before).hexdigest(),
                    'finalSha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'inverseConstructorAndUniformGeometryMatchesOriginalBytes':True,
                    'substitutions':[{'old':old,'new':new,'count':count} for old,new,count in applied]})

repair('mir2-web3/apps/simulation/src/runtime/zone/runtime/purification_tests.rs',[
 ('fn sid(name: &str) -> SessionId {',
  'const MAP: &str = "D024";\n\n// Preserve the original geometry on real open terrain: translate (+20,+42).\nfn fixture_point(x: i32, y: i32) -> Point {\n    Point { x: x + 20, y: y + 42 }\n}\n\nfn sid(name: &str) -> SessionId {'),
 ('"purification-source".into()','MAP.into()'),
 ('Point { x, y: 10 }','fixture_point(x, 10)'),
 ('Point { x: 12, y: 10 }','fixture_point(12, 10)'),
 ('Point { x: 80, y: 80 }','fixture_point(80, 80)'),
 ('Point { x: 10, y: 10 }','fixture_point(10, 10)'),
 ('point.x = 80;','point.x = 80 + 20;'),
 ('    let mut zone = ZoneRuntime::new_with_collision(\n        ZoneKey::for_map("purification-source"),\n        ZoneCollision::unbounded(),\n    );',
  '    // Strict recovery must reload the same ordinary map collision.\n    let mut zone = ZoneRuntime::new(ZoneKey::for_map(MAP));\n    assert!(zone.has_available_collision(), "real fixture terrain must load");'),
])
repair('mir2-web3/apps/simulation/tests/shared_crowded_escape.rs',[
 ('SessionId, WorldEntityDisposition, ZoneCollision, ZoneCommand, ZoneJoin, ZoneKey,',
  'SessionId, WorldEntityDisposition, ZoneCommand, ZoneJoin, ZoneKey,'),
 ('const OWNER: &str = "crowded-escape-owner";',
  'const MAP: &str = "D024";\nconst OWNER: &str = "crowded-escape-owner";'),
 ('    Point { x, y }',
  '    // Translate every actor, ring, corridor and expected location together.\n    Point { x: x + 20, y: y + 42 }'),
 ('    let mut zone = ZoneRuntime::new_with_collision(\n        ZoneKey::for_map("crowded-escape-fixture"),\n        ZoneCollision::unbounded(),\n    );',
  '    // Ordinary terrain has the same signed identity after strict cold reload.\n    let mut zone = ZoneRuntime::new(ZoneKey::for_map(MAP));\n    assert!(zone.has_available_collision(), "real fixture terrain must load");'),
 ('"crowded-escape-fixture".into()','MAP.into()'),
])
with (out/'REPAIRS.json').open('x',encoding='utf-8') as stream:
    json.dump({'base':base,'records':records,'productRecoveryOrPermissionCodeChanged':False},stream,indent=2)
    stream.write('\n')
print(json.dumps({'files':[{k:r[k] for k in ('path','finalSha256','inverseConstructorAndUniformGeometryMatchesOriginalBytes')} for r in records]}))
