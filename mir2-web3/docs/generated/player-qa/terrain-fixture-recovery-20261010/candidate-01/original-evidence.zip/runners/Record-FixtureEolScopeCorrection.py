import hashlib
import json
from pathlib import Path
import subprocess
from datetime import datetime, timezone

root=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
frozen=Path('C:/Users/Administrator/.codex/worktrees/mta/mir2-player-journey')
out=Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence')
name='mir2-web3/apps/simulation/src/runtime/map.rs'
base='348caa5e4b3b8bb3d63e3d2af80803e958adafee'
git=['git','-c','gc.auto=0','-c','maintenance.auto=false','-c','safe.directory='+root.as_posix(),'-C',str(root)]
disk=(root/name).read_bytes()
other=(frozen/name).read_bytes()
canonical=subprocess.check_output(git+['show',base+':'+name])
assert disk!=other and disk.replace(b'\r\n',b'\n')==other==canonical
receipt=(out/'SOURCE-FROZEN-01.json').read_bytes()
assert json.loads(receipt)['originalProductRecoveryPermissionWorkflowBytesUnchanged'] is True
record={'utc':datetime.now(timezone.utc).isoformat(),'parent':base,
        'correctsReceiptSha256':hashlib.sha256(receipt).hexdigest(),
        'scopeCorrection':'The earlier boolean describes canonical tracked Git content, not every raw working-file byte. Mixed EOL in existing map.rs is separately retained; no product file was reformatted.',
        'allProductRawWorkingBytesClaimedIdentical':False,'mapPath':name,
        'workingSha256':hashlib.sha256(disk).hexdigest(),
        'frozenAndGitCanonicalSha256':hashlib.sha256(canonical).hexdigest(),
        'workingCrlfCount':disk.count(b'\r\n'),
        'workingStandaloneLfCount':disk.count(b'\n')-disk.count(b'\r\n'),
        'lfNormalizedProductContentIdentical':True,'productFileChangedByThisCorrection':False}
with (out/'SOURCE-EOL-CORRECTION-01.json').open('x',encoding='utf-8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
