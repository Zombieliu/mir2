"""Record an observed compiler failure without inventing a lost process result."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

root = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence')
stem = 'check-10-final-gateway-classic-workflow-gates'
log = root / (stem + '.log')
before = root / (stem + '-before.json')
raw = log.read_bytes()
text = raw.decode('utf-8-sig')
assert 'memory allocation' in text and '0xc0000409' in text
assert not re.search(r'^running \d+ tests?\s*$', text, re.M)
assert not (root / (stem + '-result.json')).exists()
assert not (root / (stem + '-after.json')).exists()
record = {
    'utcObserved': datetime.now(timezone.utc).isoformat(),
    'declaredBaseSource': '348caa5e4b3b8bb3d63e3d2af80803e958adafee',
    'log': log.name, 'logBytes': len(raw), 'logSha256': hashlib.sha256(raw).hexdigest(),
    'beforeReceiptSha256': hashlib.sha256(before.read_bytes()).hexdigest(),
    'memoryAllocationFailureMessages': len(re.findall(r'memory allocation .* failed', text)),
    'compilerErrorStatus': '0xc0000409: STATUS_STACK_BUFFER_OVERRUN',
    'testExecutionObserved': False, 'testFailureOrSuccessClaimed': False,
    'actualWrapperExitCodeAvailable': False, 'actualWrapperExitCode': None,
    'afterSourceHashesAvailable': False, 'originalLogRetained': True,
    'buildDirectoryLockWaitAlsoObserved': 'Blocking waiting for file lock on build directory' in text,
    'retry': 'check-12-final-gateway-classic-workflow-jobs1',
    'retryChanges': ['Cargo build concurrency -j 1 only'],
    'assertionsDeadlinesAndPermissionsChangedForRetry': False,
}
with (root / 'CHECK10-MEMORY-FAILURE-OBSERVATION.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
