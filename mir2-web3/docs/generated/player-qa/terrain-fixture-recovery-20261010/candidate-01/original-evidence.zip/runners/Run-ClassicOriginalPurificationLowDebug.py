"""One bounded compile with reduced debug information; run the untouched test."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

directory = Path(__file__).resolve().parent
root = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence')
repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
build_stem = 'check-20-original-shared-zone-low-debug-build'
test_stem = 'check-21-original-shared-zone-low-debug-execution'
runner = directory / 'Run-ClassicFixtureQualificationFinal.ps1'
previous = json.loads((root / 'check-17-final-original-shared-zone-purification-result.json').read_bytes())
assert previous['exitCode'] == 101
old_log = (root / 'check-17-final-original-shared-zone-purification.log').read_bytes()
assert b'memory allocation of 294928 bytes failed' in old_log
assert b'Running tests' not in old_log
assert not (root / (build_stem + '-result.json')).exists()
assert not (root / (test_stem + '-result.json')).exists()
args = ['+1.89.0', 'rustc', '--locked', '-j', '1', '--message-format=json',
        '-p', 'mir2-simulation', '--test', 'shared_zone', '--', '-C', 'debuginfo=0']
quote = lambda value: "'" + value.replace("'", "''") + "'"
command = '& ' + quote(runner.as_posix()) + ' -LogStem ' + quote(build_stem) + ' -ToolArgs @(' + ','.join(map(quote, args)) + ')'
started = datetime.now(timezone.utc).isoformat()
print(json.dumps({'stage': 'bounded-low-debug-build', 'args': args}), flush=True)
build = subprocess.run(['pwsh', '-NoLogo', '-NoProfile', '-Command', command],
                       capture_output=True, timeout=3600)
for name, data in [('stdout', build.stdout), ('stderr', build.stderr)]:
    with (root / (build_stem + '-wrapper.' + name + '.log')).open('xb') as stream:
        stream.write(data)
with (root / (build_stem + '-wrapper.json')).open('x', encoding='utf-8') as stream:
    json.dump({'utcStarted': started, 'utcFinished': datetime.now(timezone.utc).isoformat(),
               'actualWrapperExitCode': build.returncode, 'args': args}, stream, indent=2)
assert build.returncode == json.loads((root / (build_stem + '-result.json')).read_bytes())['exitCode'] == 0
artifacts = []
for line in (root / (build_stem + '.log')).read_text(encoding='utf-8-sig').splitlines():
    if not line.startswith('{'):
        continue
    item = json.loads(line)
    if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'shared_zone':
        artifacts.append(item)
assert len(artifacts) == 1
artifact = artifacts[0]
assert artifact['target']['kind'] == ['test'] and artifact['profile']['test'] is True
assert artifact['fresh'] is False
assert Path(artifact['target']['src_path']).resolve() == (repo / 'mir2-web3/apps/simulation/tests/shared_zone.rs').resolve()
executable = Path(artifact['executable']).resolve()
assert executable.parent == Path('C:/mir2-build/p4-purification-map-20261009-target/debug/deps').resolve()
assert executable.is_file() and not executable.is_symlink()
sha = lambda data: hashlib.sha256(data).hexdigest()
source_before = json.loads((root / (build_stem + '-before.json')).read_bytes())
source_after = json.loads((root / (build_stem + '-after.json')).read_bytes())
assert source_before['source'] == source_after['source']
shared_source = repo / 'mir2-web3/apps/simulation/tests/shared_zone.rs'
source = source_before['source'] + [{'Path': str(shared_source), 'Hash': sha(shared_source.read_bytes()).upper()}]
command = [str(executable), '--exact', 'level50_taoist_purification_clears_shared_poison_and_curse_state', '--test-threads=1']
def snapshot(phase):
    for row in source:
        assert sha(Path(row['Path']).read_bytes()) == row['Hash'].lower()
    value = {'utc': datetime.now(timezone.utc).isoformat(), 'phase': phase, 'command': command,
             'package': 'mir2-simulation', 'binary': 'tests/shared_zone.rs', 'source': source,
             'scope': '40 selected source paths; not whole toolchain/input closure',
             'executableSha256': sha(executable.read_bytes()), 'buildStem': build_stem,
             'originalSourceAssertionsAndClocksUnchanged': True, 'debugInformationReducedOnly': True,
             'replacesOriginalLinuxWorkflowCommand': False}
    with (root / (test_stem + '-' + phase + '.json')).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
snapshot('before')
started = datetime.now(timezone.utc).isoformat()
print(json.dumps({'stage': 'execute-untouched-original-test', 'command': command}), flush=True)
execution = subprocess.run(command, cwd=repo / 'mir2-web3', capture_output=True, timeout=300)
with (root / (test_stem + '.log')).open('xb') as stream:
    stream.write(execution.stdout + execution.stderr)
snapshot('after')
with (root / (test_stem + '-result.json')).open('x', encoding='utf-8') as stream:
    json.dump({'utcStarted': started, 'utcFinished': datetime.now(timezone.utc).isoformat(),
               'exitCode': execution.returncode, 'log': str(root / (test_stem + '.log'))}, stream, indent=2)
print(execution.stdout.decode('utf-8'), flush=True)
assert execution.returncode == 0, 'Original failed execution retained; no repeated attempts'
