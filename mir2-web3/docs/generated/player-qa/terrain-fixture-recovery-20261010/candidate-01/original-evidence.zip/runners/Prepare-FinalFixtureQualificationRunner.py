import hashlib
import json
from pathlib import Path
import subprocess

directory = Path(__file__).resolve().parent
root = directory/'gateway-lifecycle-20261008-01'
base = '348caa5e4b3b8bb3d63e3d2af80803e958adafee'
out = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence')
git = ['git','-c','gc.auto=0','-c','maintenance.auto=false','-c','safe.directory='+root.as_posix(),'-C',str(root)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip() == base
changed = subprocess.check_output(git+['diff','--name-only']).decode().splitlines()
assert len(changed)==8 and all(name.endswith('_tests.rs') or '/tests/' in name for name in changed)
assert not subprocess.check_output(git+['diff','--cached','--name-only']).strip()
before = (directory/'Run-SnakeRecoveryQualification.ps1').read_bytes()
(out/'initial-runner-original.ps1').open('xb').write(before)
additional = [name.removeprefix('mir2-web3/') for name in changed
              if name.removeprefix('mir2-web3/') not in before.decode()]
additional += ['packages/game-data/data/generated/crystal_starter_map_collision.json',
               'apps/web/lib/generated/crystal-map-pack/d022.map.gz',
               'apps/web/lib/generated/crystal-map-pack/d023.map.gz',
               'apps/web/lib/generated/crystal-map-pack/d024.map.gz']
anchor = " 'apps/gateway/src/routing/tests/owner_location_order_tests.rs'\n)"
assert before.decode().count(anchor)==1
after = before.decode().replace(anchor,anchor[:-2]+',\n'+',\n'.join(" '"+name+"'" for name in additional)+'\n)')
target = directory/'Run-ClassicFixtureQualificationFinal.ps1'
target.open('x',encoding='utf-8').write(after)
snapshot = out/'candidate-sources-01'
snapshot.mkdir()
records=[]
for name in changed:
    data=(root/name).read_bytes()
    old=subprocess.check_output(git+['show',base+':'+name])
    relative=Path(name)
    for phase,content in [('original',old),('candidate',data)]:
        path=snapshot/phase/relative
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(content)
    records.append({'path':name,'originalSha256':hashlib.sha256(old).hexdigest(),
                    'candidateSha256':hashlib.sha256(data).hexdigest()})
(out/'selected-final-source-01.patch').open('xb').write(subprocess.check_output(git+['diff','--']+changed))
subprocess.run(git+['diff','--check'],check=True)
record={'parent':base,'changedTests':records,'finalRunnerSha256':hashlib.sha256(target.read_bytes()).hexdigest(),
        'originalProductRecoveryPermissionWorkflowBytesUnchanged':True,'candidateTestResultsPending':True}
(out/'SOURCE-FROZEN-01.json').open('x',encoding='utf-8').write(json.dumps(record,indent=2)+'\n')
print(json.dumps({'changedTests':len(changed),'runner':str(target),'additionalSelectedInputs':len(additional)}))
