"""Resume untouched remaining checks, retaining the original timing failure."""
import ast
import hashlib
import json
from pathlib import Path

directory = Path(__file__).resolve().parent
root = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence')
assert json.loads((root / 'check-15-final-gateway-purification-release-result.json').read_bytes())['exitCode'] == 101
assert json.loads((root / 'check-19-diagnostic-original-scroll-repeat-result.json').read_bytes())['exitCode'] == 0
template = directory / 'Run-RemainingClassicFixtureGates.py'
before = template.read_text()
tree = ast.parse(before)
assignment = next(node for node in tree.body if isinstance(node, ast.Assign)
                  and any(isinstance(target, ast.Name) and target.id == 'checks' for target in node.targets))
checks = assignment.value
values = ast.literal_eval(checks)
assert len(values) == 6
remaining = values[3:]
assert [stem for stem, _ in remaining] == ['check-16-final-ordinary-snake-missing-map',
                                         'check-17-final-original-shared-zone-purification',
                                         'check-18-final-gateway-movement-population-lib']
lines = before.splitlines(keepends=True)
old_assignment = ''.join(lines[assignment.lineno - 1:assignment.end_lineno])
assert before.count(old_assignment) == 1
new_assignment = 'checks = ' + repr(remaining) + '\n'
after = before.replace(old_assignment, new_assignment, 1)
replacements = {
    'check-12-final-gateway-classic-workflow-jobs1-result.json': 'check-19-diagnostic-original-scroll-repeat-result.json',
    'REMAINING-GATES-STARTED.json': 'RETAINED-GATES-RESUMED-01.json',
    'REMAINING-GATES-COMPLETED.json': 'RETAINED-GATES-COMPLETED-01.json',
}
for old, new in replacements.items():
    assert old in after
    after = after.replace(old, new)
candidate = ast.parse(after)
candidate_checks = next(node.value for node in candidate.body if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'checks' for target in node.targets))
assert ast.literal_eval(candidate_checks) == remaining
target = directory / 'Run-RetainedClassicFixtureGates.py'
with target.open('x', encoding='utf-8') as stream: stream.write(after)
proof = {'originalRunnerSha256': hashlib.sha256(template.read_bytes()).hexdigest(),
         'resumedRunnerSha256': hashlib.sha256(target.read_bytes()).hexdigest(),
         'remainingCommandsUnchanged': True, 'originalScrollTimingFailureRetained': True,
         'scrollTimingDefectClaimedFixed': False, 'diagnosticRepeatExitCode': 0}
with (root / 'RETAINED-GATES-RESUME-PREPARATION.json').open('x', encoding='utf-8') as stream:
    json.dump(proof, stream, indent=2)
print(json.dumps(proof))
