"""Run remaining original checks serially after the current Cargo finishes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path('C:/mir2-build/p7-snake-recovery-fixture-20261010-evidence')
repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
runner = Path(__file__).parent / 'Run-ClassicFixtureQualificationFinal.ps1'
frozen = json.loads((root / 'SOURCE-FROZEN-01.json').read_bytes())
assert hashlib.sha256(runner.read_bytes()).hexdigest() == frozen['finalRunnerSha256']
current = root / 'check-19-diagnostic-original-scroll-repeat-result.json'
assert not (root / 'RETAINED-GATES-RESUMED-01.json').exists()
started = datetime.now(timezone.utc).isoformat()
with (root / 'RETAINED-GATES-RESUMED-01.json').open('x', encoding='utf-8') as stream:
    json.dump({'utc': started, 'waitForResult': current.name, 'serial': True,
               'runnerSha256': hashlib.sha256(runner.read_bytes()).hexdigest()}, stream, indent=2)
print(json.dumps({'waitingFor': current.name, 'sourceMutations': False}), flush=True)
wait_deadline = time.monotonic() + 3600
while not current.exists():
    assert time.monotonic() < wait_deadline, 'Original current check did not finish within the bounded wait'
    time.sleep(5)
assert json.loads(current.read_bytes())['exitCode'] == 0
checks = [('check-16-final-ordinary-snake-missing-map', ['+1.89.0', 'test', '--locked', '--no-fail-fast', '-j', '1', '-p', 'mir2-simulation', '--test', 'shared_snake_master_lifecycle', '--test', 'shared_missing_map_collision', '--', '--test-threads=1']), ('check-17-final-original-shared-zone-purification', ['+1.89.0', 'test', '--locked', '-j', '1', '-p', 'mir2-simulation', '--test', 'shared_zone', 'level50_taoist_purification_clears_shared_poison_and_curse_state', '--', '--test-threads=1']), ('check-18-final-gateway-movement-population-lib', ['+1.89.0', 'test', '--locked', '-j', '1', '-p', 'mir2-gateway', '--lib', '--', '--test-threads=1', 'unavailable_combat_target', 'owner_location_order', 'owner_attack_animation', 'movement_deadline', 'crowded_escape_tests', 'npc_population_binding::tests'])]
for stem, args in checks:
    for row in frozen['changedTests']:
        assert hashlib.sha256((repo / row['path']).read_bytes()).hexdigest() == row['candidateSha256']
    assert not (root / (stem + '-result.json')).exists()
    quote = lambda value: "'" + value.replace("'", "''") + "'"
    command = '& ' + quote(runner.as_posix()) + ' -LogStem ' + quote(stem) + ' -ToolArgs @(' + ','.join(map(quote, args)) + ')'
    print(json.dumps({'starting': stem, 'cargoArgs': args}), flush=True)
    attempt_started = datetime.now(timezone.utc).isoformat()
    process = subprocess.run(['pwsh', '-NoLogo', '-NoProfile', '-Command', command],
                             capture_output=True, timeout=3600)
    with (root / (stem + '-wrapper.stdout.log')).open('xb') as stream: stream.write(process.stdout)
    with (root / (stem + '-wrapper.stderr.log')).open('xb') as stream: stream.write(process.stderr)
    wrapper = {'utcStarted': attempt_started, 'utcFinished': datetime.now(timezone.utc).isoformat(),
               'actualWrapperExitCode': process.returncode, 'cargoArgs': args}
    with (root / (stem + '-wrapper.json')).open('x', encoding='utf-8') as stream:
        json.dump(wrapper, stream, indent=2)
    result = json.loads((root / (stem + '-result.json')).read_bytes())
    print(json.dumps({'completed': stem, 'wrapperExitCode': process.returncode,
                      'cargoExitCode': result['exitCode']}), flush=True)
    assert process.returncode == result['exitCode'] == 0, 'Original failed check retained; dependent checks stopped'
with (root / 'RETAINED-GATES-COMPLETED-01.json').open('x', encoding='utf-8') as stream:
    json.dump({'utcStarted': started, 'utcFinished': datetime.now(timezone.utc).isoformat(),
               'stems': [stem for stem, _ in checks], 'allExitCodesZero': True}, stream, indent=2)
