"""Retain every bounded job-log fetch attempt; diagnosis is not qualification."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

out = Path('C:/mir2-build/p7-unavailable-collision-20261010-ci/server-ci-01')
for attempt in range(1, 4):
    raw_path = out / f'failed-job-log02-attempt-{attempt}.txt'
    assert not raw_path.exists()
    with raw_path.open('xb') as stream:
        try:
            result = subprocess.run(['gh', 'api', '-H', 'Cache-Control: no-cache',
                'repos/Zombieliu/mir2/actions/jobs/114098017989/logs'],
                stdout=stream, stderr=subprocess.PIPE, timeout=55)
            error, code = result.stderr, result.returncode
        except subprocess.TimeoutExpired as failure:
            error, code = failure.stderr or b'', 124
    with (out / f'failed-job-log02-attempt-{attempt}.stderr.log').open('xb') as stream:
        stream.write(error)
    proof = {'utc': datetime.now(timezone.utc).isoformat(), 'runId': 38013314930,
             'jobId': 114098017989, 'exitCode': code, 'bytes': raw_path.stat().st_size,
             'sha256': hashlib.sha256(raw_path.read_bytes()).hexdigest(),
             'originalFetchFailureRetained': True, 'qualificationClaimed': False,
             'serverSwitched': False}
    with (out / f'FAILED-JOB-LOG02-ATTEMPT-{attempt}.json').open('x', encoding='utf-8') as stream:
        json.dump(proof, stream, indent=2)
    print(json.dumps(proof), flush=True)
    if code:
        continue
    lines = raw_path.read_text(errors='replace').splitlines()
    for index, line in enumerate(lines):
        if ('FAILED' in line or 'error:' in line or 'test result: FAILED' in line
                or 'failures:' in line or 'panicked at' in line):
            print('\n'.join(item[:1100] for item in lines[max(0, index-1):min(len(lines), index+6)]))
    break
else:
    raise SystemExit('Three actual job log read failures; do not invent the test result')
