"""Seal actual selected checks and immutable evidence; do not claim rollout or Map.Load."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
evidence = Path('C:/mir2-build/p7-map-transfer-availability-20261010-evidence')
parent = '431520196068b710c6588bf53c75a599c2f726bd'
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-c', 'gc.auto=0',
       '-c', 'maintenance.auto=false', '-C', str(repo)]
assert subprocess.check_output(git + ['rev-parse', 'HEAD']).decode().strip() == parent

def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(data):
    return hashlib.sha256(data).hexdigest()

checks = [
    ('06-final-gateway-transfer-and-original-movement', 36, 0),
    ('07-final-simulation-terrain-transfer-and-cold', 87, 1),
    ('08-final-normal-missing-collision', 5, 0),
    ('09-final-original-shared-movement', 14, 0),
    ('10-final-original-optimized-gateway-map-flow', 4, 0),
]
passed = set()
results = []
declared = None
for stem, expected, ignored in checks:
    result = read_json(evidence / (stem + '-result.json'))
    assert result['exitCode'] == 0
    raw = (evidence / (stem + '.log')).read_bytes()
    text = raw.decode('utf-8-sig').replace('\r\n', '\n')
    names = re.findall(r'^test (\S+) \.\.\. ok$', text, re.M)
    assert len(names) == len(set(names)) == expected, (stem, len(names))
    assert f'test result: ok. {expected} passed; 0 failed; {ignored} ignored;' in text
    before = read_json(evidence / (stem + '-before.json'))
    after = read_json(evidence / (stem + '-after.json'))
    assert before['command'] == after['command'] and before['source'] == after['source']
    assert len(before['source']) == 24
    assert declared is None or declared == before['source']
    declared = before['source']
    assert not passed.intersection(names), 'Do not count repeated checks as distinct'
    passed.update(names)
    results.append({'stem': stem, 'passed': expected, 'ignored': ignored,
                    'originalLogSha256': sha(raw), 'command': before['command'],
                    'exitCode': result['exitCode']})
assert len(passed) == 146
for entry in declared:
    assert sha(Path(entry['Path']).read_bytes()).upper() == entry['Hash']

baselines = []
for stem, good, bad in [('01-before-product-fix-destination', 2, 2),
                        ('02-before-product-fix-gateway', 1, 6),
                        ('05-original-owner-fixture-unavailable-baseline', 3, 5)]:
    result = read_json(evidence / (stem + '-result.json'))
    text = (evidence / (stem + '.log')).read_text(encoding='utf-8-sig')
    assert result['exitCode'] != 0
    assert f'test result: FAILED. {good} passed; {bad} failed; 0 ignored;' in text
    baselines.append({'stem': stem, 'passed': good, 'failed': bad,
                      'originalLogSha256': sha((evidence / (stem + '.log')).read_bytes())})

fixture_path = 'mir2-web3/apps/gateway/src/routing/tests/owner_location_order_tests.rs'
old_fixture = (evidence / 'original-owner-location-fixture-before-explicit-arena.rs').read_bytes()
assert sha(old_fixture) == 'b454a96ea0b03d4991f72be710bc42cd6247532d875462b6fbbc8b4875d5c9ea'
assert old_fixture == subprocess.check_output(git + ['show', parent + ':' + fixture_path])
insert = b'''        // This packet-order fixture intentionally has no terrain files. Make
        // its open arena explicit; ordinary missing maps remain unavailable.
        assert!(state.zone_manager.install_empty_zone(
            mir2_simulation::ZoneRuntime::new_with_collision(
                ZoneKey::for_map(&map), mir2_simulation::ZoneCollision::unbounded(),
            ),
        ));
'''
current_fixture = (repo / fixture_path).read_bytes()
assert current_fixture.count(insert) == 1 and current_fixture.replace(insert, b'', 1) == old_fixture

workflow_path = '.github/workflows/gateway-release.yml'
old_workflow = subprocess.check_output(git + ['show', parent + ':' + workflow_path])
new_gate = b'''      - name: Verify terrain-backed map transfer observation
        working-directory: mir2-web3
        run: |
          set -euo pipefail
          cargo +1.89.0 test --locked -p mir2-simulation --lib map_transfer_availability_tests:: -- --test-threads=1
          cargo +1.89.0 test --locked --release -p mir2-gateway --lib map_transfer_availability_tests:: -- --test-threads=1

'''
anchor = b'      - name: Package Gateway\n'
assert old_workflow.count(anchor) == 1
assert (repo / workflow_path).read_bytes() == old_workflow.replace(anchor, new_gate + anchor)

reviewed = {
    'mir2-web3/apps/simulation/src/runtime/map.rs': 'd0265590220e6edb91cd5ea0b191179699fe8954a62246bde92e052a39f3cb2f',
    'mir2-web3/apps/simulation/src/runtime/zone/collision.rs': '4fa3dc74d105c51008f553ae3c4f06049a8a3747fed65bd514d3436deccf7b08',
    'mir2-web3/apps/simulation/src/runtime/zone/runtime.rs': '0d5a8e3d791a16888505c64543d6d9542ed868c85230475c7dd464e5b9c8b025',
    'mir2-web3/apps/gateway/src/routing.rs': 'c19831b76f580b9c175a61093fe1241c28de5808c74bb49e2ad228a05a186a0b',
    fixture_path: '2b7a055b1b14e638263c3eeb14c860682731fa8243ad8d0feda66051edc1030e',
    'mir2-web3/apps/simulation/src/runtime/map_transfer_availability_tests.rs': '3e69fac2efbac695bce7651f9bbcf0f296f26c4ccb41e8065fd043d2abaa5c8c',
    'mir2-web3/apps/gateway/src/routing/tests/map_transfer_availability_tests.rs': '89311342d25d2cf139a180266099e1686eb473ba656013c4bd9793dd584160d7',
    workflow_path: '23ca1b25011f70f4dc6ed7b1c0b6e9a1c821fc29ab2854b1b1e956da1aa83ffc',
}
for name, expected in reviewed.items():
    assert sha((repo / name).read_bytes()) == expected, name

qualified_parent = Path('C:/mir2-build/p7-source-map-io-20261010-ci/server-ci-01/artifact-01')
qualification = read_json(qualified_parent / 'CI-VERIFIED.json')
assert qualification['revision'] == '9fe7c45ff6a9b198d87322b9ecca4a2abcac6547'
assert qualification['runConclusion'] == 'success' and qualification['runId'] == '38006259110'
assert sha((qualified_parent / 'ci-log-original.txt').read_bytes()) == qualification['logSha256']
assert sha((qualified_parent / 'mir2-gateway').read_bytes()) == qualification['binarySha256']

archive_dir = repo / 'mir2-web3/docs/generated/player-qa/map-transfer-availability-20261010/candidate-01'
archive_dir.mkdir(parents=True, exist_ok=False)
entries = {f'local/{path.name}': path.read_bytes() for path in sorted(evidence.iterdir()) if path.is_file()}
for name in reviewed:
    entries['final-source/' + name] = (repo / name).read_bytes()
for name in ['Run-MapTransferAvailabilityRoot.ps1', 'Run-MapTransferAvailabilityOwnerFixture.ps1',
             'Close-MapTransferAvailabilityCandidate.py', 'Retain-UnavailableCollisionFailedCILog.py',
             'Read-UnavailableCollisionFailedJobLog02.py']:
    entries['helpers/' + name] = (Path(__file__).parent / name).read_bytes()
failed_ci = Path('C:/mir2-build/p7-unavailable-collision-20261010-ci/server-ci-01')
redactions = []
for path in sorted(failed_ci.iterdir()):
    if not path.is_file():
        continue
    data = path.read_bytes()
    # Keep the exact transport error locally, but never publish temporary log
    # download credentials. The public copy records its original fingerprint.
    redacted = re.sub(rb'([?&](?:signature|sig|token|access_token)=)[^&\s"<>]+',
                      rb'\1<redacted>', data)
    suffix = '.redacted' if redacted != data else ''
    entries['failed-linux/' + path.name + suffix] = redacted
    if redacted != data:
        redactions.append({'path': path.name, 'originalSha256': sha(data),
                           'archivedSha256': sha(redacted), 'originalRetainedLocally': True,
                           'redaction': 'temporary signed log-download query credential'})
for name in ['CI-VERIFIED.json', 'ci-status-original.json', 'ci-artifacts-original.json',
             'ci-log-original.txt', 'VERIFIED-FILES.json', 'RELEASE.json']:
    entries['qualified-predecessor9fe7/' + name] = (qualified_parent / name).read_bytes()
published = Path('C:/mir2-build/p7-unavailable-collision-20261010-git-publication-01/exact-api')
for name in ['PUBLISHED-VERIFIED.json', 'REF-MCP-FRESH-READBACK.json', 'COMMIT-MCP-FRESH-READBACK.json']:
    entries['published-predecessor431520/' + name] = (published / name).read_bytes()

archive = archive_dir / 'original-evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for name, data in sorted(entries.items()):
        zipped.writestr(name, data)
assert archive.stat().st_size < 3 * 1024**2
with zipfile.ZipFile(archive) as zipped:
    assert set(zipped.namelist()) == set(entries)
    for name, data in entries.items():
        assert zipped.read(name) == data
record = {'schema': 'mir2.classic.map-transfer-availability.candidate.v1',
          'utc': datetime.now(timezone.utc).isoformat(), 'parent': parent,
          'localPassedDistinct': len(passed), 'newTests': 11,
          'retainedRegressionTests': 135, 'existingIgnoredBenchmark': 1,
          'inputScope': '24 selected paths before/after/current, not a whole-workspace or toolchain closure',
          'finalRuns': results, 'redBaselines': baselines,
          'fixtureRepair': 'only seven explicit-open constructor lines; all original assertions and clocks unchanged',
          'originalWorkflowPlusOneAdditiveGate': True, 'reviewedSha256': reviewed,
          'qualifiedPredecessorSource': qualification['revision'],
          'qualifiedPredecessorRun': qualification['runId'],
          'failedPredecessorSource': parent, 'failedPredecessorRun': '38013314930',
          'failedPredecessorGate': {'passed': 16, 'failed': 5, 'siegeJob': 'success'},
          'archive': {'path': archive.name, 'entries': len(entries), 'bytes': archive.stat().st_size,
                      'sha256': sha(archive.read_bytes()), 'everyEntryByteVerified': True},
          'signedDownloadCredentialRedactions': redactions,
          'sourcePublished': False, 'exactLinuxPassed': False, 'gatewayPublished': False,
          'publicPacketStoriesPassed': False, 'nativeHumanAcceptance': False,
          'acceptedActionReceiptComplete': False, 'joinAdmissionComplete': False,
          'sourceMapLoadPopulationComplete': False, 'fullClassicGoalComplete': False,
          'liveGatewaySource': '64b6b10c05732048da9c6bf5ccb0a491d2d053d3',
          'realSavesModified': False, 'clientInstallerOrR2FeedModified': False}
with (archive_dir / 'EVIDENCE.json').open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: record[key] for key in ['parent', 'localPassedDistinct', 'newTests',
    'retainedRegressionTests', 'archive', 'sourcePublished', 'exactLinuxPassed', 'gatewayPublished']}))
