import hashlib
import json
from pathlib import Path
import subprocess

out = Path('C:/mir2-build/p7-unavailable-collision-20261010-ci/server-ci-01')
raw_path = out / 'failed-ci-log-original.txt'
assert not raw_path.exists()
with raw_path.open('xb') as stream:
    result = subprocess.run(['gh', 'run', 'view', '38013314930', '--repo', 'Zombieliu/mir2', '--log'],
                            stdout=stream, stderr=subprocess.PIPE, timeout=120)
with (out / 'failed-ci-log-original.stderr.log').open('xb') as stream:
    stream.write(result.stderr)
proof = {'runId': 38013314930, 'exitCode': result.returncode,
         'bytes': raw_path.stat().st_size, 'sha256': hashlib.sha256(raw_path.read_bytes()).hexdigest(),
         'successNotClaimed': True, 'serverSwitched': False}
with (out / 'FAILED-CI-LOG-RETAINED.json').open('x', encoding='utf-8') as stream:
    json.dump(proof, stream, indent=2)
print(json.dumps(proof))
if result.returncode:
    raise SystemExit(result.returncode)
lines = raw_path.read_text(errors='replace').splitlines()
for index, line in enumerate(lines):
    if ('FAILED' in line or 'error:' in line or 'test result: FAILED' in line
            or 'failures:' in line or 'panicked at' in line):
        print('\n'.join(lines[max(0, index-1):min(len(lines), index+5)]))
