@"C:\Python313\python.exe" "C:\mir2-build\classic-live01a8-integration-20261011\native-ci-fix-01\workflow-exit-guards-02\native-command-stub.py" cargo %*
@exit /b %errorlevel%
