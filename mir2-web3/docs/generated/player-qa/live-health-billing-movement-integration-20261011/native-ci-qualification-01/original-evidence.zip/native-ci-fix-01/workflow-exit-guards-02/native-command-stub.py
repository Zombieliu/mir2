import json, os, sys
from pathlib import Path
kind, args = sys.argv[1], sys.argv[2:]
stage = ('self-test' if '-SelfTest' in args else 'build') if kind == 'powershell' else ('format' if 'fmt' in args else 'test')
with Path(os.environ['TASK_GUARD_TRACE']).open('a') as stream:
    stream.write(json.dumps({'stage':stage,'args':args})+'\n')
sys.exit(55 if stage == os.environ.get('TASK_GUARD_FAIL_STAGE') else 0)
