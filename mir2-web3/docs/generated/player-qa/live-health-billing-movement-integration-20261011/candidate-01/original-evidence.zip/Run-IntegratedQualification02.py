import argparse
import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--suite', choices=['focused', 'adjacent', 'optimized', 'native', 'fmt'], required=True)
args = parser.parse_args()
ROOT = pathlib.Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
PROJECT = ROOT / 'mir2-web3'
OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011/qualification-02')
GIT = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', f'safe.directory={ROOT.as_posix()}']
OURS = '9c71a90396a2615177c7b2f8c2366f9c6e6598f1'
INCOMING = '01a8c48a425aecfad6adf49ff721b0aa14ce4d44'

def git(*arguments):
    return subprocess.check_output(GIT + list(arguments), cwd=ROOT).decode().strip()

assert git('rev-parse', 'HEAD') == OURS
assert git('rev-parse', 'MERGE_HEAD') == INCOMING
assert git('diff', '--name-only', '--diff-filter=U') == ''
OUT.mkdir(exist_ok=True)
selected = sorted(set(git('diff', '--name-only', INCOMING).splitlines() + git('diff', '--name-only', OURS).splitlines()))
selected = [p for p in selected if not p.startswith('mir2-web3/docs/')]
selected += ['mir2-web3/Cargo.toml', 'mir2-web3/Cargo.lock',
             'mir2-web3/apps/game-client/platform-windows/Cargo.toml',
             'mir2-web3/apps/game-client/platform-windows/Cargo.lock',
             '.github/workflows/cross-platform-client.yml']
selected = sorted(set(selected))

def snapshot():
    return [{'path': p, 'bytes': (ROOT / p).stat().st_size,
             'sha256': hashlib.sha256((ROOT / p).read_bytes()).hexdigest()} for p in selected]

sim = ['cargo', '+1.89.0', 'test', '--locked', '-j', '1', '-p', 'mir2-simulation']
gateway = ['cargo', '+1.89.0', 'test', '--locked', '-j', '1', '-p', 'mir2-gateway']
serial = ['--', '--test-threads=1']
suites = {
    'focused': [
        ('check-01-merged-source-movement-health', sim + ['--lib'] + serial + [
            'source_can_move_tests::', 'session_zone_buff_clock_tests::', 'health_zero_authority_tests::',
            'health_display_source_tests::', 'owner_health_tests::', 'outcome_tick_tests::']),
        ('check-02-merged-gateway-owner-shop-clock', gateway + ['--lib'] + serial + [
            'owner_location_order_tests::', 'movement_deadline_tests::', 'shared_session_hot_path_tests::',
            'outcome_tick_tests::', 'typed_game_shop_outcome', 'owner_attack_animation_tests::',
            'map_transfer_availability_tests::', 'health_zero_authority_tests::', 'owner_health_sync_tests::',
            'web_game_shop_gift_tests::', 'zone_rpc_game_shop_gift_tests::',
            'web_billing_tests::', 'stripe_billing_tests::', 'zone_rpc_billing_tests::']),
    ],
    'adjacent': [
        ('check-03-merged-source-integration', sim + ['--features', 'test-support',
            '--test', 'shared_monster_health_lifecycle', '--test', 'game_shop_gift',
            '--test', 'billing_monthly_card', '--test', 'billing_recharge',
            '--test', 'shared_crowded_escape', '--test', 'shared_monster_hell_ai',
            '--test', 'shared_pet_pvp', '--test', 'shared_missing_map_collision',
            '--test', 'shared_purification_map_transfer', '--test', 'shared_snake_master_lifecycle'] + serial),
        ('check-04-merged-gateway-mentor-monthly', gateway + ['--test', 'billing_monthly_card',
            '--test', 'mentor_shared_lifecycle'] + serial),
    ],
    'optimized': [
        ('check-05-merged-original-real500ms-scroll', gateway + ['--release', '--test',
            'shared_purification_map_transfer'] + serial),
    ],
    'native': [
        ('check-06-merged-native-stage', ['cargo', '+1.95.0', 'test', '--locked', '--offline', '--jobs', '2',
            '--config', 'profile.test.package.mir2-platform-windows.debug="line-tables-only"',
            '--config', 'profile.test.package.mir2-platform-windows.codegen-units=218',
            '--manifest-path', 'apps/game-client/platform-windows/Cargo.toml',
            '--bin', 'mir2-platform-windows'] + serial + ['--nocapture']),
    ],
    'fmt': [
        ('check-07-merged-native-fmt', ['cargo', '+1.95.0', 'fmt', '--manifest-path',
            'apps/game-client/platform-windows/Cargo.toml', '--check']),
    ],
}
env = os.environ.copy()
env['CARGO_TARGET_DIR'] = 'C:/mir2-build/p1-native-escape-20261010-target' if args.suite in ['native', 'fmt'] else 'C:/mir2-build/p4-purification-map-20261009-target'
for stem, command in suites[args.suite]:
    before_path = OUT / (stem + '-before.json')
    assert not before_path.exists(), 'Never overwrite or repeat original test evidence'
    before = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'mergeParents': [OURS, INCOMING], 'workingDirectory': str(PROJECT),
              'command': command, 'cargoTarget': env['CARGO_TARGET_DIR'],
              'scope': 'Changed source paths and manifests; not the entire external/native input closure',
              'source': snapshot()}
    before_path.write_text(json.dumps(before, indent=2) + '\n', encoding='utf-8')
    with (OUT / (stem + '.log')).open('xb') as log:
        result = subprocess.run(command, cwd=PROJECT, env=env, stdout=log, stderr=subprocess.STDOUT)
    after = snapshot()
    text = (OUT / (stem + '.log')).read_text(encoding='utf-8', errors='replace')
    successful = re.findall(r'^test (\S+) \.\.\. ok$', text, re.M)
    failed = re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.M)
    ignored = re.findall(r'^test (\S+) \.\.\. ignored[^\n]*$', text, re.M)
    record = {'utcStarted': before['utc'], 'utcFinished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'exitCode': result.returncode, 'sourceUnchanged': before['source'] == after,
              'passedTestNames': successful, 'failedTestNames': failed, 'ignoredTestNames': ignored,
              'sourceAfter': after, 'testIsNotNativeHumanAcceptance': True,
              'productionStagingOrSwitchExecuted': False}
    (OUT / (stem + '-result.json')).write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'stem': stem, 'exitCode': result.returncode, 'sourceUnchanged': record['sourceUnchanged'],
                      'passed': len(successful), 'failed': failed, 'ignored': len(ignored)}), flush=True)
    print(text[-4500:], flush=True)
    if result.returncode or not record['sourceUnchanged']:
        sys.exit(result.returncode or 1)
