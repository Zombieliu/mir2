import hashlib
import json
import pathlib

ROOT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011')
source = pathlib.Path('E:/mir2-player-journey/tmp/Prepare-ExactGitPublicationFixtures.py')
destination = ROOT / 'Prepare-ExactMergePublicationFixtures.py'
assert not destination.exists()
body = source.read_text(encoding='utf-8')
changes = [
    ("parser.add_argument('--parent',required=True)",
     "parser.add_argument('--parent',required=True)\n    parser.add_argument('--merge-parent',required=True)"),
    ("assert git('rev-parse','HEAD^').decode().strip()==args.parent",
     "assert git('show','-s','--format=%P','HEAD').decode().strip().split()==[args.parent,args.merge_parent]"),
    ("fields['parent']==[args.parent]", "fields['parent']==[args.parent,args.merge_parent]"),
    ("files=git('diff','--name-only',args.parent,target).decode().splitlines()",
     "files=git('diff','--name-only',args.merge_parent,target).decode().splitlines()"),
    ("git('rev-parse',args.parent+'^{tree}')", "git('rev-parse',args.merge_parent+'^{tree}')"),
    ("'tree':fields['tree'][0],'files':files,'branchUpdated':False}",
     "'tree':fields['tree'][0],'files':files,'branchUpdated':False,'parents':[args.parent,args.merge_parent],'baseTreeCommit':args.merge_parent}"),
    ("'parents':[args.parent]", "'parents':[args.parent,args.merge_parent]"),
]
fixed = body
for old, new in changes:
    assert fixed.count(old) == 1, old
    fixed = fixed.replace(old, new)
assert 'assert 0<len(files)<=150' in fixed and '3*1024*1024' in fixed
assert "'expected_sha':args.parent" in fixed and "'force':False" in fixed
destination.write_text(fixed, encoding='utf-8')
record = {'originalHelperSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'derivedHelperSha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
          'changes': [{'before': a, 'after': b} for a, b in changes],
          'why': 'Preserve exact two-parent merge identity and reuse the existing remote incoming tree; upload only the bounded new delta instead of 527 already-published incoming files',
          'unchangedGuards': ['Clean exact branch', 'First parent exact expected remote ref', '150-file and 3MiB per-blob bounds', 'Original author and committer identity', 'Non-force ref update remains separate'],
          'executedApiMutation': False}
(ROOT / 'merge-01/GIT-MERGE-PUBLICATION-HELPER-PREPARED.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'helperPrepared': str(destination), 'executedApiMutation': False}))
