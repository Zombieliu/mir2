import datetime
import json
import pathlib
import subprocess

ROOT = pathlib.Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011/merge-01')
OURS = '9c71a90396a2615177c7b2f8c2366f9c6e6598f1'
THEIRS = '01a8c48a425aecfad6adf49ff721b0aa14ce4d44'
GIT = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', f'safe.directory={ROOT.as_posix()}']

def read(*args):
    return subprocess.check_output(GIT + list(args), cwd=ROOT).decode('utf-8').strip()

assert not OUT.exists(), 'Evidence destination already exists'
assert read('rev-parse', 'HEAD') == OURS
assert read('branch', '--show-current') == 'codex/gateway-disconnect-lifecycle-20261008'
assert read('status', '--porcelain') == '', 'Owned lane is not clean'
assert read('rev-parse', f'{THEIRS}^{{commit}}') == THEIRS
OUT.mkdir(parents=True)
result = subprocess.run(GIT + ['merge', '--no-ff', '--no-commit', THEIRS], cwd=ROOT, capture_output=True)
(OUT / 'merge.stdout.log').write_bytes(result.stdout)
(OUT / 'merge.stderr.log').write_bytes(result.stderr)
conflicts = read('diff', '--name-only', '--diff-filter=U').splitlines()
assert result.returncode == 1, result.returncode
assert sorted(conflicts) == sorted([
    'mir2-web3/apps/gateway/src/routing.rs',
    'mir2-web3/apps/simulation/src/runtime/zone/runtime.rs',
]), conflicts
assert read('rev-parse', 'HEAD') == OURS
assert read('rev-parse', 'MERGE_HEAD') == THEIRS
(OUT / 'MERGE-STARTED.json').write_text(json.dumps({
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'root': str(ROOT), 'ours': OURS, 'theirs': THEIRS,
    'incomingTree': read('rev-parse', f'{THEIRS}^{{tree}}'),
    'mergeExitCode': result.returncode, 'conflicts': conflicts,
    'branchStillAtOriginalHead': True, 'serverStagingOrSwitchExecuted': False,
}, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'mergeStarted': True, 'conflicts': conflicts, 'evidence': str(OUT)}))
