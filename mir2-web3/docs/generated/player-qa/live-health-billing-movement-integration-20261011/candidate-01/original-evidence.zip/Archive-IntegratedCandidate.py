from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,re,subprocess,zipfile,collections
REPO=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
OUT=Path('C:/mir2-build/classic-live01a8-integration-20261011')
OURS='9c71a90396a2615177c7b2f8c2366f9c6e6598f1'; LIVE='01a8c48a425aecfad6adf49ff721b0aa14ce4d44'
GIT=['git','-c','gc.auto=0','-c','maintenance.auto=false','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
def git(*args):return subprocess.check_output(GIT+list(args)).decode().strip()
def digest(data):return hashlib.sha256(data).hexdigest()
def write_json(path,obj):
    with path.open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2,ensure_ascii=False);f.write('\n')
assert git('rev-parse','HEAD')==OURS and git('rev-parse','MERGE_HEAD')==LIVE
assert not git('diff','--name-only','--diff-filter=U')
specs=[('qualification-02','check-01-merged-source-movement-health',39,0),('qualification-05','check-02-merged-gateway-owner-shop-clock',69,0),('qualification-04','check-03-merged-source-integration',146,1),('qualification-04','check-04-merged-gateway-mentor-monthly',10,0),('qualification-06','check-05-merged-original-real500ms-scroll',5,0),('qualification-02','check-06-merged-native-stage',941,7),('qualification-03','check-07-merged-native-fmt',0,0),('qualification-06','check-08-merged-actual-gift-billing-modules',48,0)]
checks=[]; server=set(); native=set()
workflow='.github/workflows/gateway-release.yml'; gw_fixture='mir2-web3/apps/gateway/src/routing/tests/health_zero_authority_tests.rs'
for folder,stem,expected,ignore in specs:
    base=OUT/folder
    before=json.loads((base/(stem+'-before.json')).read_bytes()); after=json.loads((base/(stem+'-result.json')).read_bytes())
    assert after['exitCode']==0 and after['sourceUnchanged'] and before['source']==after['sourceAfter']
    differences=[r['path'] for r in after['sourceAfter'] if digest((REPO/r['path']).read_bytes())!=r['sha256']]
    assert set(differences)<= {workflow,gw_fixture}
    if 'gateway-owner-shop' in stem:assert set(differences)<= {workflow}
    if folder=='qualification-06':assert not differences
    raw=(base/(stem+'.log')).read_text(encoding='utf-8',errors='replace')
    headers=list(re.finditer(r'^test (\S+) \.\.\. ',raw,re.M)); names=[]; ignored=[]
    package='mir2-platform-windows' if 'native-stage' in stem else (before['command'][before['command'].index('-p')+1] if '-p' in before['command'] else 'fmt')
    for i,h in enumerate(headers):
        end=headers[i+1].start() if i+1<len(headers) else len(raw)
        statuses=re.findall(r'(?m)^(ok|FAILED|ignored[^\n]*)\r?$',raw[h.end():end]); assert statuses,(stem,h.group(1))
        status=statuses[-1].strip()
        prior=re.findall(r'Running tests[\\/](\w+)\.rs',raw[:h.start()]); target=prior[-1] if prior else ('bin' if package=='mir2-platform-windows' else 'lib')
        name=package+':'+target+':'+h.group(1)
        if status=='ok':names.append(name)
        elif status.startswith('ignored'):ignored.append(name)
        else:raise AssertionError('Unexpected failed test '+name)
    summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',raw)
    assert len(names)==expected and len(set(names))==expected and len(ignored)==ignore
    assert (sum(int(r[0]) for r in summaries),sum(int(r[1]) for r in summaries),sum(int(r[2]) for r in summaries))==(expected,0,ignore)
    if package=='mir2-platform-windows':native.update(names)
    else:server.update(names)
    checks.append({'evidence':folder+'/'+stem,'command':before['command'],'utcStarted':after['utcStarted'],'utcFinished':after['utcFinished'],'passed':expected,'ignored':ignore,'testNames':names,'ignoredNames':ignored,'beforeAfterSelectedSnapshotEqual':True,'currentSelectedDifferences':differences,'differenceExplanation':'Workflow is outside local compilation; gateway fixture is cfg(test), outside Simulation/Native and integration-test gateway library. Final gateway library check uses the final fixture. These are selected hashes, not a full external closure.'})
assert len(server)==317 and len(native)==941
selected=json.loads((OUT/'qualification-06/check-05-merged-original-real500ms-scroll-result.json').read_bytes())['sourceAfter']
assert all(digest((REPO/r['path']).read_bytes())==r['sha256'] for r in selected)
added='''      - name: Verify merged owner health and native shop capabilities
        working-directory: mir2-web3
        run: |
          set -euo pipefail
          cargo +1.89.0 test --locked -p mir2-simulation --lib -- --test-threads=1 health_zero_authority_tests:: health_display_source_tests:: owner_health_tests::
          cargo +1.89.0 test --locked -p mir2-simulation --features test-support --test shared_monster_health_lifecycle --test game_shop_gift --test billing_monthly_card --test billing_recharge -- --test-threads=1
          cargo +1.89.0 test --locked -p mir2-gateway --lib -- --test-threads=1 health_zero_authority_tests:: owner_health_sync_tests:: game_shop_gift billing
          cargo +1.89.0 test --locked -p mir2-gateway --test billing_monthly_card --test mentor_shared_lifecycle -- --test-threads=1

'''
wf=(REPO/workflow).read_text(encoding='utf-8'); prior=subprocess.check_output(GIT+['show',OURS+':'+workflow]).decode()
assert wf.count(added)==1 and wf.replace(added,'',1)==prior
prefix='mir2-web3/docs/generated/player-qa/live-health-billing-movement-integration-20261011/candidate-01'
folder=REPO/prefix; folder.mkdir(parents=True,exist_ok=False)
write_json(folder/'NATIVE-TEST-PARSER-CORRECTION.json',{'originalResultRetained':True,'originalSameLinePassedNames':912,'actualLibtestPassed':941,'actualBlockParsedPassedNames':941,'actualIgnored':7,'testRunRepeated':False,'reason':'--nocapture prints 29 successful test statuses on later lines; the original same-line name collector undercounted. The actual libtest summary and 948 complete blocks agree.','sourceLogSha256':digest((OUT/'qualification-02/check-06-merged-native-stage.log').read_bytes())})
entries=[]
with zipfile.ZipFile(folder/'original-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    files=sorted(p for p in OUT.rglob('*') if p.is_file() and ('qualification-' in p.relative_to(OUT).parts[0] or p.relative_to(OUT).parts[0] in ['preflight-01','merge-01','diagnostic-01'] or p.parent==OUT))
    for p in files:
        data=p.read_bytes(); name=p.relative_to(OUT).as_posix()
        assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{40,}|ghp_[A-Za-z0-9]{30,}',data)
        archive.writestr(name,data); entries.append({'path':name,'bytes':len(data),'sha256':digest(data)})
with zipfile.ZipFile(folder/'original-evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.infolist())==len(entries)
    for r in entries:assert digest(archive.read(r['path']))==r['sha256']
archive=(folder/'original-evidence.zip').read_bytes(); assert len(archive)<3*1024*1024
proof={'utc':datetime.now(timezone.utc).isoformat(),'mergeParents':[OURS,LIVE],'selectedFinalSource':selected,'selectedSourceScope':'Changed paths, Cargo manifests/locks and workflows only; not a whole external input closure.','checks':checks,'passedRustServerDistinct':317,'passedRustNativeDistinct':941,'serverPostgresIgnored':1,'nativeExternalIgnored':7,'allOriginalFailuresRetained':True,'fixtureRepairsOnly':{'coldRoot':'Use ordinary collision-available Zone constructors so cold checkpoints preserve the actual root policy.','ownerHealthFifo':'Inspect the real pending_zone_owner_health FIFO outside the poisoned mutex; preserve original action ordering, exact wire values and exactly-once retry.','import':'Import the private test presentation enum explicitly.','terrain':'Ordinary TCP/WS test uses existing open D024 tiles with an equivalent coordinate translation.','zeroHealth':'Rounded zero-percent ObjectHealth cannot settle death; ObjectDied positive control retained.'},'originalWorkflowGatesPreserved':True,'nativeSameLineParserUndercountCorrectedWithoutRerun':True,'newSourcePushed':False,'newPairedLinuxWindowsBuildQualified':False,'productionStagingOrSwitchExecuted':False,'humanNativeAcceptance':False,'fullP1P7Complete':False,'archive':{'bytes':len(archive),'sha256':digest(archive),'entries':len(entries)},'entries':entries}
write_json(folder/'EVIDENCE.json',proof)
doc='''# Live health, billing and movement integration — 2026-10-11

The actual public Gateway source `01a8c48a425aecfad6adf49ff721b0aa14ce4d44` is merged into the owned movement/escape source `9c71a90396a2615177c7b2f8c2366f9c6e6598f1`. Both histories remain parents; no reset, force push, authentication bypass or production collision weakening is used. Source CanMove/Fishing, real Zone buff duration, admitted-animation escape and the current live owner-health FIFO, rounded-zero health, monthly card, billing, gifting and mail behavior are preserved together.

| Actual local gate | Passed | Existing ignored |
| --- | ---: | ---: |
| Simulation Source movement, buff clock and health | 39 | 0 |
| Gateway owner ordering, movement and health | 69 | 0 |
| Simulation crowd, pets, collision, poison/transfer and commerce | 146 | 1 PostgreSQL external |
| Gateway monthly card and mentor lifecycle | 10 | 0 |
| Original optimized Gateway real 500ms poison/scroll/transfer | 5 | 0 |
| Actual Gateway gift and billing modules | 48 | 0 |
| Native Windows component stage | 941 | 7 native external |

There are 317 distinct qualified server test names and 941 distinct Native names; these are component checks, not player acceptance. Native full formatting also passes. Original libtest reports 941; its old same-line collector recorded 912 because 29 `--nocapture` statuses appear on later lines. A read-only block parser confirms all 948 records, without repeating the test or replacing the original result.

The initial cold-checkpoint fixture failures, Gateway abnormal `0xc0000409` exit, missing enum import, unavailable synthetic-map movement and old rounded-zero death assertion are retained. The original Gateway binary diagnostic revealed an obsolete legacy FIFO lookup and a double panic during cleanup; this is not labeled a stack overflow. Tests now inspect the actual owner-health FIFO outside the mutex. Cold fixtures use ordinary roots; TCP/WS uses independently verified open D024 tiles with equivalent positions. HP1/max419, movement authority, retry ordering, timeouts and real death positive controls remain. The zero-display assertion intentionally follows the independent Source rule that rounded display 0 is alive. No original strict 500ms behavior is ignored or relaxed.

Checks use selected before/after source hashes. Subsequent changes are only the added CI step and a `cfg(test)` Gateway fixture, outside earlier Simulation/Native and integration-library inputs; the final Gateway library gate uses the repaired fixture. This is not a whole external/native build closure. Original workflow commands remain byte-for-byte when the added merged health/commerce step is removed. The new step explicitly selects the actual `game_shop_gift` and `billing` module names. Real PostgreSQL acceptance remains a separate CI gate.

[Immutable original logs, preparation, diagnostic and current source pins](generated/player-qa/live-health-billing-movement-integration-20261011/candidate-01/EVIDENCE.json) retain every attempted check. New exact two-parent Git publication, clean matching Linux/Windows builds, drained paired production rollout, native dense-combat play and human acceptance remain pending at this archival point. The earlier 9c full Windows workflow passed all eight builds with publishing skipped; it is a different source and is not reused as this merge's EXE. Earlier 1e Linux is likewise not deployed over live billing.

The current tracked runtime resources and packager inputs do not differ from the commercial R24 resource source. Reuse requires fresh byte/provenance checks and a distinct new delivery identity; old R24/escape-R24 EXEs, signatures and recipes are not relabeled. Existing users and real saves remain protected. P1–P7 and mentor overall delivery remain open, and the expired heartbeat remains paused.
'''
doc_path=REPO/'mir2-web3/docs/CLASSIC-LIVE-HEALTH-BILLING-MOVEMENT-INTEGRATION-20261011.md'
with doc_path.open('x',encoding='utf-8') as f:f.write(doc)
notice='''> Integrated live health/billing with Source movement and Windows escape, 2026-10-11:
> the public01a8 and owned9c histories are both retained. Actual local checks:
> 317 distinct server names and941 Native names pass; one PostgreSQL external
> and seven Native external checks remain ignored. Original failures and the
> read-only correction of the Native name collector912→941 are retained.
> [Scope, original evidence and limits](CLASSIC-LIVE-HEALTH-BILLING-MOVEMENT-INTEGRATION-20261011.md).
> New two-parent Git publication, matching Linux/Windows builds, safe paired
> publication, dense native combat and human acceptance remain pending here.
> Old1e/9c artifacts are separate; existing workflow gates and live commerce
> are preserved. Root is the sole writer. FullP1–P7/Mentor is open; expired
> heartbeat remains paused. Older progress below is historical.

'''
common=['AGENT-ORCHESTRATION.md','AGENT-TASK-QUEUE.md','CRYSTAL-1TO1-ROADMAP.md','BACKEND-1TO1-PROGRESS.md','CRYSTAL-SERVER-PARITY.md','CLASSIC-12H-DELIVERY-20261007.md','NATIVE-WINDOWS-PLAYER-QA.md','FRONTEND-1TO1-GAPS.md']
for name in common:
    p=REPO/'mir2-web3/docs'/name; original=p.read_text(encoding='utf-8'); first,rest=original.split('\n',1)
    assert 'Integrated live health/billing with Source movement' not in original
    p.write_text(first+'\n\n'+notice+rest.lstrip('\n'),encoding='utf-8')
stage=[workflow,gw_fixture,'mir2-web3/apps/gateway/src/routing/tests/shared_session_hot_path_tests.rs','mir2-web3/apps/simulation/src/runtime/zone/runtime/health_zero_authority_tests.rs','mir2-web3/apps/simulation/src/runtime/zone/runtime/owner_health_tests.rs','mir2-web3/docs/'+doc_path.name]+['mir2-web3/docs/'+n for n in common]+[prefix+'/'+n for n in ['EVIDENCE.json','NATIVE-TEST-PARSER-CORRECTION.json','original-evidence.zip']]
subprocess.run(GIT+['diff','--check'],check=True); subprocess.run(GIT+['add','--']+stage,check=True); subprocess.run(GIT+['diff','--cached','--check'],check=True)
write_json(OUT/'ARCHIVAL-COMPLETED-01.json',{'utc':datetime.now(timezone.utc).isoformat(),'serverPassedDistinct':317,'nativePassedDistinct':941,'archive':proof['archive'],'stagePaths':stage,'unstagedPaths':git('diff','--name-only').splitlines(),'fullGoalComplete':False,'productionSwitch':False})
print(json.dumps({'serverPassedDistinct':317,'nativePassedDistinct':941,'archive':proof['archive'],'stagedOwnPaths':len(stage),'unstagedPaths':git('diff','--name-only').splitlines()},ensure_ascii=False))
