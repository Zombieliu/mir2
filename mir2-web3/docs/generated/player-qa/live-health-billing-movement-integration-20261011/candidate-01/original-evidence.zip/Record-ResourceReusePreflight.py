import datetime
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011/merge-01/RESOURCE-REUSE-PREFLIGHT.json')
GIT = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', f'safe.directory={ROOT.as_posix()}']
R24 = '87fd85a0d5a819e5b38c90d192421f9239f65678'
paths = ['mir2-web3/apps/web/public', 'mir2-web3/apps/web/lib/generated',
         'mir2-web3/packages/game-data', 'mir2-web3/config',
         'mir2-web3/apps/game-client/platform-windows/scripts', 'mir2-web3/apps/web/scripts']
changed = subprocess.check_output(GIT + ['diff', '--name-only', R24, '--'] + paths, cwd=ROOT).decode().splitlines()
assert changed == []
native = ['mir2-web3/apps/game-client/platform-windows/src/input.rs',
          'mir2-web3/apps/game-client/platform-windows/src/entity_presentation.rs']
evidence = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'r24Source': R24, 'integratingParents': ['9c71a90396a2615177c7b2f8c2366f9c6e6598f1', '01a8c48a425aecfad6adf49ff721b0aa14ce4d44'],
    'checkedTrackedResourceAndPackagerRoots': paths, 'resourceChanges': changed,
    'resourceReuseEligibleAfterRehashAndSourceProvenanceChecks': True,
    'r24ExecutableMayBeReused': False,
    'clientSourceSha256': {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in native},
    'newReleaseNameMustNotCollideWithCommercialR24': True,
    'newFullCleanIntegratedWindowsCIRequired': True, 'clientPackagedOrFeedPublished': False,
    'priorEscapeR24RecipeWillNotBeExecuted': True,
}
assert not OUT.exists()
OUT.write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
print(json.dumps(evidence))
