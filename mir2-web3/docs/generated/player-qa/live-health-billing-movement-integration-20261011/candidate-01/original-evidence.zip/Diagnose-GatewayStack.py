import datetime
import json
import os
import pathlib
import subprocess

OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011/diagnostic-01')
ROOT = pathlib.Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3')
assert not OUT.exists()
OUT.mkdir()
command = ['C:/mir2-build/p4-purification-map-20261009-target/debug/deps/mir2_gateway-b035aa43022289bb.exe',
           '--exact', 'routing::tests::health_zero_authority_tests::health_zero_registered_owner_full_channel_keeps_global_attack_until_one_wire_rebase',
           '--test-threads=1', '--nocapture']
env = os.environ.copy()
assert 'RUST_MIN_STACK' not in env
env['RUST_BACKTRACE'] = '1'
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=90)
(OUT / 'original-binary-diagnostic.stdout.log').write_bytes(result.stdout)
(OUT / 'original-binary-diagnostic.stderr.log').write_bytes(result.stderr)
record = {'utcStarted': start, 'utcFinished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'command': command, 'exitCode': result.returncode, 'purpose': 'Retained diagnostic of the original abnormal exit; not a green qualification rerun',
          'sourceOrAssertionChanged': False, 'testStackSizeChanged': False, 'sourceDeclaresNoPass': True}
(OUT / 'DIAGNOSTIC.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
print(result.stdout.decode('utf-8', errors='replace')[-4500:])
print(result.stderr.decode('utf-8', errors='replace')[-4500:])
