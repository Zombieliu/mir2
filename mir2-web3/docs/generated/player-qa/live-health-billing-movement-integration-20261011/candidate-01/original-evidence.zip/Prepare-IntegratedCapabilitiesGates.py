import datetime
import hashlib
import json
import pathlib

ROOT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011')
source = ROOT / 'Run-IntegratedQualification05.py'
dest = ROOT / 'Run-IntegratedQualification06.py'
assert not dest.exists()
body = source.read_text(encoding='utf-8')
fixed = body.replace("['focused', 'gateway', 'adjacent', 'optimized', 'native', 'fmt']",
                     "['focused', 'gateway', 'capabilities', 'adjacent', 'optimized', 'native', 'fmt']")
fixed = fixed.replace('20261011/qualification-05', '20261011/qualification-06')
marker = "env = os.environ.copy()"
assert fixed.count(marker) == 1
fixed = fixed.replace(marker, "suites['capabilities'] = [('check-08-merged-actual-gift-billing-modules', gateway + ['--lib'] + serial + ['game_shop_gift', 'billing'])]\n\n" + marker)
dest.write_text(fixed, encoding='utf-8')
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'helperOnlyChanges': ['New evidence directory', 'One additional capability suite'],
          'why': 'Module aliases are web::game_shop_gift_tests and zone_rpc::billing_tests; file-based filter names matched zero capability cases. The passed 69 gateway checks are owner/movement coverage only.',
          'prior69GatewayChecksPassed': True, 'billingCapabilityChecksPassed': False,
          'allPriorTestSelectorsAssertionsAndDeadlinesRetained': True,
          'originalHelperSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'derivedHelperSha256': hashlib.sha256(dest.read_bytes()).hexdigest(),
          'originalTimedSourceMapFailuresRetained': True, 'publicSwitchExecuted': False}
(ROOT / 'merge-01/CAPABILITY-SELECTORS-PREPARED.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
