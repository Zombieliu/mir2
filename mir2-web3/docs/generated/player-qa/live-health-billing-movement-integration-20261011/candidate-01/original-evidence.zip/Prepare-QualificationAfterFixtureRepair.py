import datetime
import hashlib
import json
import pathlib
import subprocess

OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011')
ROOT = pathlib.Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
GIT = ['git', '-c', 'gc.auto=0', '-c', 'maintenance.auto=false', '-c', f'safe.directory={ROOT.as_posix()}']
source = OUT / 'Run-IntegratedQualification.py'
derived = OUT / 'Run-IntegratedQualification02.py'
assert not derived.exists()
text = source.read_text(encoding='utf-8')
old = "OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011/qualification-01')"
new = old.replace('qualification-01', 'qualification-02')
assert text.count(old) == 1
fixed = text.replace(old, new)
derived.write_text(fixed, encoding='utf-8')
test_paths = [
    'mir2-web3/apps/simulation/src/runtime/zone/runtime/health_zero_authority_tests.rs',
    'mir2-web3/apps/simulation/src/runtime/zone/runtime/owner_health_tests.rs',
]
before = json.loads((OUT / 'qualification-01/check-01-merged-source-movement-health-result.json').read_bytes())
assert before['exitCode'] != 0 and len(before['failedTestNames']) == 2 and before['sourceUnchanged']
entries = []
for p in test_paths:
    original = subprocess.check_output(GIT + ['show', '01a8c48a425aecfad6adf49ff721b0aa14ce4d44:' + p], cwd=ROOT)
    current = (ROOT / p).read_bytes()
    old_asserts = [line.strip() for line in original.decode().splitlines() if line.strip().startswith('assert')]
    new_asserts = [line.strip() for line in current.decode().splitlines() if line.strip().startswith('assert')]
    assert old_asserts == new_asserts
    entries.append({'path': p, 'incomingSha256': hashlib.sha256(original).hexdigest(),
                    'repairedSha256': hashlib.sha256(current).hexdigest(), 'assertionsUnchanged': True})
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'originalFailureRetained': True, 'originalFailedTestNames': before['failedTestNames'],
          'fixtureOnlyChangedPaths': entries, 'productionCheckpointOrCollisionChangeInThisRepair': False,
          'derivedHelperOnlyChange': 'qualification-01 evidence path to qualification-02',
          'originalRunnerSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'derivedRunnerSha256': hashlib.sha256(derived.read_bytes()).hexdigest(),
          'newChecksPassed': False, 'publicRolloutExecuted': False}
(OUT / 'merge-01/FIXTURE-REPAIR-PREPARED.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
