import datetime
import hashlib
import json
import pathlib

OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011')
source = OUT / 'Run-IntegratedQualification02.py'
dest = OUT / 'Run-IntegratedQualification03.py'
assert not dest.exists()
body = source.read_text(encoding='utf-8')
fixed = body.replace("['focused', 'adjacent', 'optimized', 'native', 'fmt']",
                     "['focused', 'gateway', 'adjacent', 'optimized', 'native', 'fmt']")
fixed = fixed.replace('20261011/qualification-02', '20261011/qualification-03')
marker = "env = os.environ.copy()"
assert fixed.count(marker) == 1
fixed = fixed.replace(marker, "suites['gateway'] = [suites['focused'][1]]\n\n" + marker)
dest.write_text(fixed, encoding='utf-8')
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'priorAbnormalQualificationRetained': 'qualification-02/check-02-merged-gateway-owner-shop-clock-result.json',
          'exactOriginalBinaryDiagnosticRetained': 'diagnostic-01/DIAGNOSTIC.json',
          'diagnosticRootCause': 'Test indexes old legacy backlog; owner action now retained in pending_zone_owner_health FIFO; assertion poisons the Zone mutex and cleanup double-panics',
          'testStackOrPacketQueueImplementationChanged': False,
          'testOnlyRepair': 'Inspect exact original global attack in current FIFO and require both queues empty after retry; retain full-channel, one wire rebase and exactly-once assertions',
          'originalHelperSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'derivedHelperSha256': hashlib.sha256(dest.read_bytes()).hexdigest(),
          'helperChanges': ['New immutable evidence directory', 'Gateway-only selector retains all original gateway filters without repeating already-passed Simulation cases'],
          'newQualificationPassed': False, 'publicSwitchExecuted': False}
(OUT / 'merge-01/QUEUE-FIXTURE-REPAIR-PREPARED.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
