import datetime
import hashlib
import json
import pathlib

OUT = pathlib.Path('C:/mir2-build/classic-live01a8-integration-20261011')
original = pathlib.Path('E:/mir2-player-journey/tmp/Run-ClientEscapeBounded.py')
dest = OUT / 'Run-IntegratedNativeBounded.py'
assert not dest.exists()
body = original.read_text(encoding='utf-8')
fixed = body.replace("out=Path('C:/mir2-build/p1-client-escape-20261010-evidence')",
                     "out=Path('C:/mir2-build/classic-live01a8-integration-20261011/qualification-02')")
old = "process=subprocess.Popen(['pwsh','-NoProfile','-Command',script],stdout=stdout,stderr=stderr)"
new = "process=subprocess.Popen([sys.executable,'C:/mir2-build/classic-live01a8-integration-20261011/Run-IntegratedQualification02.py','--suite','native'],stdout=stdout,stderr=stderr)"
assert fixed.count(old) == 1
fixed = fixed.replace(old, new)
assert fixed != body
assert '2*1024**3' in fixed and 'Never stop an unrelated process' in fixed
dest.write_text(fixed, encoding='utf-8')
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'originalSupervisorSha256': hashlib.sha256(original.read_bytes()).hexdigest(),
          'derivedSupervisorSha256': hashlib.sha256(dest.read_bytes()).hexdigest(),
          'onlyChanges': ['Evidence destination', 'Owned child command to integrated native runner'],
          'existingMemoryAndDescendantGuardsRetained': True, 'nativeAcceptance': False}
(OUT / 'merge-01/NATIVE-SUPERVISOR-PREPARED.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record))
