from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01'); out=Path('C:/mir2-build/classic-live01a8-integration-20261011/ci-fix-01')
source='4006d988b3922d0106278720abfa9b3d384c8d5e'; path=repo/'mir2-web3/apps/game-client/client-bevy/src/mail.rs'
git=['git','-c','gc.auto=0','-c','maintenance.auto=false','-c','safe.directory='+repo.as_posix(),'-C',str(repo)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip()==source and not subprocess.check_output(git+['status','--porcelain=v1','--untracked-files=all'])
before=path.read_bytes(); newline='\r\n' if b'\r\n' in before else '\n'; text=before.decode().replace('\r\n','\n'); changes=[]
def change(a,b):
    global text
    assert text.count(a)==1,a
    text=text.replace(a,b,1);changes.append({'before':a,'after':b})
change('use crate::inventory::{CrystalItemInfoModel, CrystalItemTooltipSourceModel, CrystalUserItemModel};','use crate::inventory::CrystalItemTooltipSourceModel;\n#[cfg(feature = "native-ui")]\nuse crate::inventory::{CrystalItemInfoModel, CrystalUserItemModel};')
change('    pub fn is_monthly_card(&self) -> bool {','    #[cfg(feature = "native-ui")]\n    pub fn is_monthly_card(&self) -> bool {')
change('    pub fn image_index(&self) -> Option<u16> {','    #[cfg(not(feature = "native-ui"))]\n    pub fn image_index(&self) -> Option<u16> {\n        self.tooltip_source\n            .as_ref()\n            .map(|source| source.user_item_image(u32::from(self.count)))\n            .or_else(|| self.image.and_then(|image| u16::try_from(image).ok()))\n    }\n\n    #[cfg(feature = "native-ui")]\n    pub fn image_index(&self) -> Option<u16> {')
change('    pub fn display_tooltip_source(&self) -> Option<CrystalItemTooltipSourceModel> {','    #[cfg(not(feature = "native-ui"))]\n    pub fn display_tooltip_source(&self) -> Option<CrystalItemTooltipSourceModel> {\n        self.tooltip_source.clone()\n    }\n\n    #[cfg(feature = "native-ui")]\n    pub fn display_tooltip_source(&self) -> Option<CrystalItemTooltipSourceModel> {')
change('    pub fn label(&self) -> String {\n        if self.is_monthly_card() {','    pub fn label(&self) -> String {\n        #[cfg(feature = "native-ui")]\n        if self.is_monthly_card() {')
change('    pub fn display_body(&self) -> String {','    #[cfg(not(feature = "native-ui"))]\n    pub fn display_body(&self) -> String {\n        self.body.replace("\\\\r\\\\n", "\\r\\n")\n    }\n\n    #[cfg(feature = "native-ui")]\n    pub fn display_body(&self) -> String {')
change('    fn display_body_for_locale(&self, language: crate::native_i18n::Locale) -> String {','    #[cfg(feature = "native-ui")]\n    fn display_body_for_locale(&self, language: crate::native_i18n::Locale) -> String {')
change('pub fn mail_date_display_label(binary: i64) -> String {','#[cfg(not(feature = "native-ui"))]\npub fn mail_date_display_label(binary: i64) -> String {\n    let label = mail_date_label(binary);\n    if label.is_empty() {\n        "Not recorded".to_owned()\n    } else {\n        label\n    }\n}\n\n#[cfg(feature = "native-ui")]\npub fn mail_date_display_label(binary: i64) -> String {')
for name in ['monthly_card_mail_display_uses_exact_identity_and_does_not_rewrite_letters','monthly_card_mail_localizes_actual_source_purchase_and_gift_templates_in_all_languages','monthly_card_mail_keeps_wrong_quantity_and_opaque_shop_text_unchanged','missing_mail_date_has_a_visible_placeholder_without_inventing_a_timestamp']:
    change('    #[test]\n    fn '+name+'() {','    #[cfg(feature = "native-ui")]\n    #[test]\n    fn '+name+'() {')
newtests='''    #[cfg(not(feature = "native-ui"))]
    #[test]
    fn renderer_neutral_mail_keeps_shop_metadata_and_opaque_text() {
        let mail: MailMessage = serde_json::from_value(serde_json::json!({
            "sender": "Gameshop",
            "body": "Game shop purchase\\\\r\\\\nMonthlyCard30Days x 1 was sent from the game shop.",
            "items": [{
                "itemIndex": 1000001,
                "uniqueId": 71,
                "count": 1,
                "name": "MonthlyCard30Days",
                "image": 1813,
                "tooltipSource": {"info": {"item_index": 1000001, "name": "MonthlyCard30Days"}}
            }]
        }))
        .unwrap();
        let original = mail.clone();
        assert_eq!(
            mail.display_body(),
            "Game shop purchase\\r\\nMonthlyCard30Days x 1 was sent from the game shop."
        );
        assert_eq!(mail.items[0].label(), "MonthlyCard30Days");
        assert_eq!(mail.items[0].unique_id, Some(71));
        assert_eq!(
            mail.items[0].display_tooltip_source(),
            mail.items[0].tooltip_source
        );
        let supplied_icon = MailAttachment {
            image: Some(1813),
            ..Default::default()
        };
        assert_eq!(supplied_icon.image_index(), Some(1813));
        assert_eq!(mail, original, "display cannot mutate authoritative mail");
    }

    #[cfg(not(feature = "native-ui"))]
    #[test]
    fn renderer_neutral_unknown_mail_date_has_placeholder_without_timestamp() {
        assert_eq!(mail_date_label(0), "");
        assert_eq!(mail_date_display_label(0), "Not recorded");
        let timestamp = 621_355_968_000_000_000;
        assert_eq!(mail_date_display_label(timestamp), mail_date_label(timestamp));
        assert_eq!(mail_date_display_label(-1), "Not recorded");
    }

'''
change('mod tests {\n    use super::*;\n\n','mod tests {\n    use super::*;\n\n'+newtests)
reverse=text
for row in reversed(changes):
    assert reverse.count(row['after'])==1
    reverse=reverse.replace(row['after'],row['before'],1)
assert reverse==before.decode().replace('\r\n','\n'),'Original product and assertions must reconstruct exactly'
with (out/'mail.original.rs').open('xb') as f:f.write(before)
path.write_bytes(text.replace('\n',newline).encode())
record={'utc':datetime.now(timezone.utc).isoformat(),'parent':source,'path':path.relative_to(repo).as_posix(),'beforeSha256':hashlib.sha256(before).hexdigest(),'afterSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'changes':changes,'originalNativeBehaviorAndAssertionsExactlyReconstructable':True,'nativeSpecificTestsRunUnderNativeFeatureNotIgnored':True,'newNonNativeTests':2,'optionalGameDataAndNativeUiDependenciesRemainOptional':True,'authenticationOrAuthoritativeMailMutationChanged':False,'checksExecuted':False,'publicRelease':False}
with (out/'FIX-PREPARED.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'parent':source,'file':record['path'],'beforeSha256':record['beforeSha256'],'afterSha256':record['afterSha256'],'originalNativeBehaviorAndAssertionsExactlyReconstructable':True,'newNonNativeTests':2}))
