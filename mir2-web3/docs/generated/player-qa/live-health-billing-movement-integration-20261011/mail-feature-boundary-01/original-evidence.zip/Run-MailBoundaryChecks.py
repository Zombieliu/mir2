from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01'); project=repo/'mir2-web3'; out=Path('C:/mir2-build/classic-live01a8-integration-20261011/ci-fix-01')
fix=json.loads((out/'FIX-PREPARED.json').read_bytes()); path=repo/fix['path']
assert hashlib.sha256(path.read_bytes()).hexdigest()==fix['afterSha256']
env=os.environ.copy(); env['CARGO_TARGET_DIR']='C:/mir2-build/p1-native-escape-20261010-target'
manifest='apps/game-client/client-bevy/Cargo.toml'; base=['cargo','+1.95.0']
commands=[('mail-format',base+['fmt','--manifest-path',manifest,'--check']),('mail-default',base+['test','--locked','--offline','--jobs','2','--manifest-path',manifest,'--lib','--','--test-threads=1','mail::tests::']),('mail-native',base+['test','--locked','--offline','--jobs','2','--manifest-path',manifest,'--features','native-ui','--lib','--','--test-threads=1','mail::tests::']),('renderer-neutral-runtime',base+['check','--locked','--offline','--jobs','2','--manifest-path','apps/game-client/runtime/Cargo.toml'])]
for stem,command in commands:
    before={'utc':datetime.now(timezone.utc).isoformat(),'parent':fix['parent'],'command':command,'cwd':str(project),'scope':'Changed mail.rs plus unchanged tracked source at parent; no full external input closure claim','mailSha256':fix['afterSha256']}
    with (out/(stem+'-before.json')).open('x',encoding='utf-8') as f:json.dump(before,f,indent=2);f.write('\n')
    with (out/(stem+'.log')).open('xb') as log:p=subprocess.run(command,cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
    raw=(out/(stem+'.log')).read_text(encoding='utf-8',errors='replace'); after=hashlib.sha256(path.read_bytes()).hexdigest()
    result={'utc':datetime.now(timezone.utc).isoformat(),'exitCode':p.returncode,'mailSourceUnchanged':after==before['mailSha256'],'passedNames':re.findall(r'^test (\S+) \.\.\. ok$',raw,re.M),'ignoredNames':re.findall(r'^test (\S+) \.\.\. ignored[^\n]*$',raw,re.M),'summaries':re.findall(r'test result:[^\n]+',raw),'actualNativePlayOrPublication':False}
    with (out/(stem+'-result.json')).open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps({'check':stem,**result}),flush=True)
    if p.returncode or not result['mailSourceUnchanged']:
        print(raw[-5500:],flush=True);sys.exit(p.returncode or 1)
