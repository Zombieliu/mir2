import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
out=Path('C:/mir2-build/p1-source-can-move-20261010-evidence')
path=repo/'mir2-web3/apps/gateway/tests/shared_purification_map_transfer.rs'
old=path.read_bytes()
assert hashlib.sha256(old).hexdigest()=='7a2a513d43f9874fb0a4530e7b36269b3bad1cf677b9531d97e966a849f2f4f7'
diagnostic='''        assert!(now_ms() >= completion_deadline,
            "actual state disappeared before native completion: targetFirst={target_first}, deadline={completion_deadline}, afterScrolls={after_scrolls}, originalCurse={:?}, packets={completion_packets:?}", original["buffs"]["12"]);'''
anchor=b'        assert!(now_ms() >= completion_deadline);'
assert old.count(anchor)==1
new=old.replace(anchor,diagnostic.encode(),1)
test='''

#[test]
fn normal_gateway_private_ticks_cannot_expire_authoritative_curse() {
    let config = fixture();
    let factory = Arc::new(SharedInProcessZoneRuntimeFactory::with_tick_cadences(
        Duration::from_millis(25), BTreeMap::new(),
    ));
    let registry = ZoneRegistry::new(ZoneId::primary(), factory.clone());
    let (mut friend, _) = login(&config, &registry, "friend", 2);
    let (mut enemy, enemy_id) = login(&config, &registry, "enemy", 3);
    enemy.try_handle_packet(ClientPacket::ChangeAMode { mode: 5 }).unwrap();
    let mut cursed = false;
    for _ in 0..12 {
        std::thread::sleep(Duration::from_millis(1_850));
        assert!(admitted(&magic(&mut enemy, enemy_id, Spell::Curse, 0), Spell::Curse));
        std::thread::sleep(Duration::from_millis(550));
        friend.tick();
        if zone_player(&factory, "friend").1["buffs"].get("12").is_some() {
            cursed = true;
            break;
        }
    }
    assert!(cursed, "ordinary native Curse did not land in bounded source attempts");
    let original = zone_player(&factory, "friend").1;
    let expires = original["buffs"]["12"]["expires_at_ms"].as_u64().unwrap();
    let started = now_ms();
    let mut packets = Vec::new();
    for _ in 0..40 {
        packets.extend(friend.tick());
    }
    let completed = now_ms();
    let current = zone_player(&factory, "friend").1;
    eprintln!("ordinary private tick clock: calls=40 elapsedMs={} actualCurseExpiry={expires} ended={completed}",
        completed.saturating_sub(started));
    assert!(completed < expires, "the actual pre-expiry interval must be observed");
    assert_eq!(current["buffs"]["12"], original["buffs"]["12"],
        "private ticks must neither clear nor renew actual Zone Curse");
    assert!(!packets.iter().any(|packet| matches!(packet,
        ServerPacket::RemoveBuff { buff_type: 12, .. })),
        "personal tick expiry cannot echo an early native removal: {packets:?}");
    for session in [&mut friend, &mut enemy] {
        assert!(session.try_handle_packet(ClientPacket::LogOut).unwrap().iter()
            .any(|packet| matches!(packet, ServerPacket::LogOutSuccess { .. })));
    }
}
'''
assert b'fn normal_gateway_private_ticks_cannot_expire_authoritative_curse' not in new
new+=test.encode()
path.write_bytes(new)
workflow=repo/'.github/workflows/gateway-release.yml'
before=workflow.read_bytes()
line=b'          cargo +1.89.0 test --locked -p mir2-simulation --lib source_can_move_tests:: -- --test-threads=1\n'
extra=b'          cargo +1.89.0 test --locked -p mir2-simulation --lib session_zone_buff_clock_tests:: -- --test-threads=1\n'
assert before.count(line)==1 and extra not in before
after=before.replace(line,line+extra,1)
assert after.replace(extra,b'')==before
workflow.write_bytes(after)
record={'utc':datetime.now(timezone.utc).isoformat(),'originalTestSha256':hashlib.sha256(old).hexdigest(),
 'candidateTestSha256':hashlib.sha256(new).hexdigest(),'addedOrdinaryGatewayRegressions':1,
 'original500msAndExactlyOnceAssertionsPreserved':True,'originalClockOrSpellTimeChanged':False,
 'newDiagnosticOnlyOnOriginalAssertionFailure':True,'allOriginalWorkflowGatesPreserved':True,
 'candidateWorkflowSha256':hashlib.sha256(after).hexdigest(),'productionSwitched':False}
with (out/'NORMAL-GATEWAY-BUFF-CLOCK-PREPARED.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
