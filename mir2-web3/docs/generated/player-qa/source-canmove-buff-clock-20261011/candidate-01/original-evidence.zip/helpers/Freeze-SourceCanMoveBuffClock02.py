import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
evidence=Path('C:/mir2-build/p1-source-can-move-20261010-evidence')
paths=['.github/workflows/gateway-release.yml','mir2-web3/apps/simulation/src/runtime/zone/runtime.rs',
 'mir2-web3/apps/simulation/src/runtime/zone/runtime/source_can_move_tests.rs',
 'mir2-web3/apps/simulation/src/runtime/session.rs','mir2-web3/apps/simulation/src/runtime/session_zone_buff_clock_tests.rs',
 'mir2-web3/apps/gateway/tests/shared_purification_map_transfer.rs']
parent='9d0839306641831a2a7982c9b1ae04a72626ed63'
git=['git','-c','gc.auto=0','-c','maintenance.auto=false','-c','safe.directory='+repo.as_posix(),'-C',str(repo)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip()==parent
old=json.loads((evidence/'SOURCE-FROZEN-01.json').read_bytes())
assert hashlib.sha256((repo/paths[1]).read_bytes()).hexdigest()==old['changedPaths'][0]['candidateSha256']
assert hashlib.sha256((repo/paths[2]).read_bytes()).hexdigest()==old['changedPaths'][1]['candidateSha256']
work=(repo/paths[0]).read_bytes()
start=work.index(b'      - name: Verify consumption-time Source CanMove and Turn delay\n')
end=work.index(b'      - name: Verify lightweight outcome clock and exact respawn geometry\n',start)
assert work[:start]+work[end:]==(evidence/'parent-workflow.yml').read_bytes()
rows=[]
for name in paths:
    data=(repo/name).read_bytes()
    target=evidence/'candidate-source-02'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(data)
    rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
receipt={'utc':datetime.now(timezone.utc).isoformat(),'parent':parent,'changedPaths':rows,
 'allOriginalWorkflowCommandsAndConditionsByteIdenticalAfterRemovingNewStep':True,
 'sourceCanMoveRuntimeAndNineTestsIdenticalToInitialPassingScope':True,
 'zoneDeadlineAndActionTimeUnchangedByBuffFix':True,'strictReal500msConditionsAndExactlyOnceAssertionsRetained':True,
 'retainedFirstStrictResult':{'passed':3,'failed':1,'assertion':'now_ms() >= completion_deadline'},
 'retainedClockReproduction':{'calls':40,'elapsedMs':19,'earlyRemovals':1},
 'currentClockLifecycleChecks':{'passed':5,'failed':0},'candidateQualified':False,
 'nativeClientIndependentScopePending':True,'serverSwitched':False,'nativeHumanAcceptance':False}
with (evidence/'SOURCE-FROZEN-02.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
