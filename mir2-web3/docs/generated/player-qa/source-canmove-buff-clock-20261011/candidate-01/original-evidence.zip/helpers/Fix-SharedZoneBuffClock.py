import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
root=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
evidence=Path('C:/mir2-build/p1-source-can-move-20261010-evidence')
path=root/'mir2-web3/apps/simulation/src/runtime/session.rs'
old=path.read_bytes()
assert hashlib.sha256(old).hexdigest()=='8352ee9dce6e9e954328ed7353b6bd78ca15edcea221ef47f542ea74cf449184'
baseline=json.loads((evidence/'check-07-shared-zone-buff-clock-baseline-result.json').read_text(encoding='utf-8-sig'))
assert baseline['exitCode']==101
log=(evidence/'check-07-shared-zone-buff-clock-baseline.log').read_bytes()
assert b'personalTicks=40 elapsedMs=19 curseRemovals=1' in log
for source,name in [(path,'session-before-zone-buff-clock.rs'),
    (root/'mir2-web3/apps/simulation/src/runtime/session_zone_buff_clock_tests.rs','zone-buff-clock-baseline-test.rs')]:
    target=evidence/name
    if target.exists():
        assert target.read_bytes()==source.read_bytes()
    else:
        with target.open('xb') as f:f.write(source.read_bytes())
old_block='''                real_time_duration: buff.infinite.then(|| super::buffs::RealTimeBuffDuration::new_infinite(
                    u64::try_from(buff.expire_time.max(0)).unwrap_or_default(),
                )),'''
new_block='''                // This is a projection of the shared Zone's actual duration.
                // Private RuntimeClock ticks can be called more often than a
                // second and must never expire it ahead of the authoritative
                // wall deadline, then echo a premature RemoveBuff to the Zone.
                real_time_duration: Some({
                    let duration_ms = u64::try_from(buff.expire_time.max(0)).unwrap_or_default();
                    let mut duration = if buff.infinite {
                        super::buffs::RealTimeBuffDuration::new_infinite(duration_ms)
                    } else {
                        super::buffs::RealTimeBuffDuration::new(duration_ms.max(1))
                    };
                    duration.set_paused(buff.paused);
                    duration
                }),'''
pause_match='''            ServerPacket::PauseBuff { object_id, buff_type, paused }
                if local_player_object_id.is_some_and(|local_object_id| {
                    *object_id == local_object_id || *object_id == zone_object_id
                }) =>
            {
                if let Some(key) = super::buffs::crystal_buff_key_for_type(*buff_type) {
                    if let Some(duration) = self.app.world_mut().resource_mut::<BuffResource>()
                        .buffs.iter_mut().find(|buff| buff.key == key)
                        .and_then(|buff| buff.real_time_duration.as_mut())
                    {
                        duration.set_paused(*paused);
                    }
                }
            }
'''
anchor='''            ServerPacket::SpellToggle {
                object_id,
                spell: Spell::CounterAttack,'''
def replace_preserving_local_eol(body,before,after):
    versions=[(before.encode(),after.encode()),
        (before.replace('\n','\r\n').encode(),after.replace('\n','\r\n').encode())]
    matches=[(left,right) for left,right in versions if body.count(left)==1]
    assert len(matches)==1 and sum(body.count(left) for left,_ in versions)==1
    left,right=matches[0]
    return body.replace(left,right,1)
new=replace_preserving_local_eol(old,old_block,new_block)
new=replace_preserving_local_eol(new,anchor,pause_match+anchor)
path.write_bytes(new)
record={'utc':datetime.now(timezone.utc).isoformat(),'oldSourceSha256':hashlib.sha256(old).hexdigest(),
 'newSourceSha256':hashlib.sha256(new).hexdigest(),'baselineCargoExitCode':101,
 'baselineActualPersonalTicks':40,'baselineActualElapsedMs':19,'baselineActualEarlyRemoveBuff':1,
 'existingMonotonicDurationReused':True,'newSaveSchemaFields':False,'legacyTickFieldPreserved':True,
 'nativeZoneDeadlineAndMagicAdmissionChanged':False,'originalStrictAssertionsChanged':False,
 'fakeClockOrDelayedRemovalAdded':False,'serverSwitched':False}
with (evidence/'ZONE-BUFF-CLOCK-FIX-PREPARED.json').open('x') as f:json.dump(record,f,indent=2)
print(json.dumps(record))
