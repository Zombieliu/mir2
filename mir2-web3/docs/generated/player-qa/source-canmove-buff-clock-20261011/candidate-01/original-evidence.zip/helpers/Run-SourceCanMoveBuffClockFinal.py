import json, pathlib, subprocess, sys

out = pathlib.Path('C:/mir2-build/p1-source-can-move-20261010-evidence')
runner = 'E:/mir2-player-journey/tmp/Run-SharedZoneBuffClockQualification.ps1'
commands = [
    ('check-12-final-simulation-action-buff-collision', [
        '+1.89.0','test','--locked','-j','1','-p','mir2-simulation','--lib','--','--test-threads=1',
        'source_can_move_tests::','session_zone_buff_clock_tests::','buff_duration::tests::',
        'player_action_cadence_tests::','player_magic_cooldown_tests::','movement_deadline_tests::',
        'map_transfer_availability_tests::','unavailable_collision_tests::','zone::collision::tests']),
    ('check-13-final-crowded-pet-status-integrations', json.loads((out / 'check-03-original-crowded-pet-status-integrations-before.json').read_text(encoding='utf-8-sig'))['command'][1:]),
    ('check-14-final-gateway-owner-order-action-clocks', json.loads((out / 'check-04-original-gateway-owner-order-action-clocks-before.json').read_text(encoding='utf-8-sig'))['command'][1:]),
]
for stem, args in commands:
    quoted = ','.join("'" + a.replace("'", "''") + "'" for a in args)
    script = f"& '{runner}' -LogStem '{stem}' -ToolArgs @({quoted})"
    result = subprocess.run(['pwsh','-NoProfile','-Command',script], capture_output=True)
    (out / f'{stem}-wrapper.stdout.log').write_bytes(result.stdout)
    (out / f'{stem}-wrapper.stderr.log').write_bytes(result.stderr)
    print(stem, 'exit', result.returncode, flush=True)
    sys.stdout.buffer.write(result.stdout[-4000:]); sys.stdout.flush()
    if result.returncode:
        sys.stdout.buffer.write(result.stderr[-4000:]); sys.stdout.flush()
        sys.exit(result.returncode)
