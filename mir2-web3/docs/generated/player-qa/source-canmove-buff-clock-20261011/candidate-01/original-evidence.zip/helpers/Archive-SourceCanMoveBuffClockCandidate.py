from datetime import datetime, timezone
from pathlib import Path
import hashlib, json, re, zipfile

repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
out=Path('C:/mir2-build/p1-source-can-move-20261010-evidence')
frozen=json.loads((out/'SOURCE-FROZEN-02.json').read_bytes())
stems=['check-11-original-optimized-gateway-with-real-clock-fix',
       'check-12-final-simulation-action-buff-collision',
       'check-13-final-crowded-pet-status-integrations',
       'check-14-final-gateway-owner-order-action-clocks']
sha=lambda data:hashlib.sha256(data).hexdigest()
checks=[]; passed=set()
for stem in stems:
    result=json.loads((out/(stem+'-result.json')).read_text(encoding='utf-8-sig'))
    before=json.loads((out/(stem+'-before.json')).read_text(encoding='utf-8-sig'))
    after=json.loads((out/(stem+'-after.json')).read_text(encoding='utf-8-sig'))
    assert result['exitCode']==0 and before['source']==after['source'] and before['command']==after['command']
    for row in frozen['changedPaths']:
        absolute=str((repo/row['path']).resolve()).casefold()
        actual=next(item['Hash'] for item in before['source'] if item['Path'].casefold()==absolute)
        assert actual.casefold()==row['sha256'] and sha((repo/row['path']).read_bytes())==row['sha256']
    raw=(out/(stem+'.log')).read_text(encoding='utf-8-sig')
    package=before['command'][before['command'].index('-p')+1]
    target='lib'; names=[]
    for line in raw.splitlines():
        match=re.search(r'Running tests[\\/](\w+)\.rs',line)
        if match:target=match.group(1)
        match=re.fullmatch(r'test (.+) \.\.\. ok',line)
        if match:names.append(package+':'+target+':'+match.group(1))
    summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',raw)
    assert summaries and len(names)==sum(int(r[0]) for r in summaries)
    assert all(r[1:]==('0','0') for r in summaries)
    passed.update(names)
    checks.append({'stem':stem,'command':before['command'],'passed':len(names),'testNames':names,
                   'selectedBeforeAfterHashesEqual':True,'utcStarted':result['utcStarted'],'utcFinished':result['utcFinished']})
assert len(passed)==158
baseline=json.loads((out/'check-07-shared-zone-buff-clock-baseline-result.json').read_text(encoding='utf-8-sig'))
assert baseline['exitCode']==101
assert 'curseRemovals=1' in (out/'check-07-shared-zone-buff-clock-baseline.log').read_text(encoding='utf-8-sig')
strict=json.loads((out/'check-05-original-optimized-gateway-strict-scroll-result.json').read_text(encoding='utf-8-sig'))
assert strict['exitCode']==101
folder=repo/'mir2-web3/docs/generated/player-qa/source-canmove-buff-clock-20261011/candidate-01'
folder.mkdir(parents=True,exist_ok=False)
entries=[]
with zipfile.ZipFile(folder/'original-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    paths=sorted(p for p in out.rglob('*') if p.is_file())
    for path in paths:
        data=path.read_bytes(); name=path.relative_to(out).as_posix()
        assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----|github_pat_[A-Za-z0-9_]{40,}|ghp_[A-Za-z0-9]{30,}',data)
        archive.writestr(name,data)
        entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
    for name in ['Run-SharedZoneBuffClockQualification.ps1','Run-SourceCanMoveBuffClockFinal.py',
                 'Fix-SharedZoneBuffClock.py','Add-NormalGatewayBuffClockRegression.py',
                 'Freeze-SourceCanMoveBuffClock02.py','Archive-SourceCanMoveBuffClockCandidate.py']:
        data=(Path(__file__).parent/name).read_bytes()
        archive.writestr('helpers/'+name,data)
        entries.append({'path':'helpers/'+name,'bytes':len(data),'sha256':sha(data)})
with zipfile.ZipFile(folder/'original-evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.infolist())==len(entries)
    for row in entries:assert sha(archive.read(row['path']))==row['sha256']
data=(folder/'original-evidence.zip').read_bytes()
assert len(data)<=3*1024*1024
proof={'utc':datetime.now(timezone.utc).isoformat(),'parent':frozen['parent'],
       'sourceSha256':{r['path']:r['sha256'] for r in frozen['changedPaths']},'checks':checks,
       'passedRustDistinct':len(passed),'testNames':sorted(passed),'newTests':15,
       'allSelectedFinalChecksPass':True,'originalStrict500msFailureRetained':True,
       'actualBaselinePrivateTicks':40,'actualBaselineElapsedMs':19,'actualBaselineEarlyRemovals':1,
       'originalCompileAndPreparationFailuresRetained':True,'originalWorkflowGatesPreserved':True,
       'newSourcePushed':False,'newSourceLinuxQualified':False,'newGatewayPublished':False,
       'nativeClientQualified':False,'nativeHumanAcceptance':False,'fullP1P7Claimed':False,
       'archive':{'bytes':len(data),'sha256':sha(data),'entries':len(entries)},'entries':entries}
with (folder/'EVIDENCE.json').open('x',encoding='utf-8') as file:json.dump(proof,file,indent=2);file.write('\n')
print(json.dumps({k:proof[k] for k in ['parent','passedRustDistinct','newTests','archive','allSelectedFinalChecksPass']}))
