import hashlib, json, re, subprocess, zipfile
from datetime import datetime, timezone
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
root = repo / 'mir2-web3'
ev = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence')
ci = Path('C:/mir2-build/p7-npc-owner-binding-20261010-ci/server-ci-01')
publication = Path('C:/mir2-build/p7-npc-owner-binding-20261010-git-publication-01/exact-api')
base = '01e3d08791c2639b3375c39d46fbf4f00ca53f75'
out = root / 'docs/generated/player-qa/source-map-terrain-20261010/candidate-01'
assert not out.exists()

def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def digest(data): return hashlib.sha256(data).hexdigest()
def new_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

git = ['git', '-c', 'safe.directory='+repo.as_posix(), '-c', 'gc.auto=0',
       '-c', 'maintenance.auto=false', '-C', str(repo)]
assert subprocess.check_output(git+['rev-parse', 'HEAD']).decode().strip() == base
assert read(publication/'PUBLISHED-VERIFIED.json')['head'] == base
final, names = {}, set()
for stem, expected, ignored in [('06-final-source-reads-and-preparation', 32, 1),
                                ('07-final-optimized-gateway-source-read-flow', 4, 0)]:
    before, after = read(ev/(stem+'-before.json')), read(ev/(stem+'-after.json'))
    assert before['source'] == after['source']
    assert before['declaredBaseSource'] == after['declaredBaseSource'] == base
    assert len(after['source']) == 13
    for item in after['source']:
        assert digest(Path(item['Path']).read_bytes()).upper() == item['Hash']
    result = read(ev/(stem+'-result.json'))
    log = (ev/(stem+'.log')).read_text(encoding='utf-8-sig')
    match = re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    passed = re.findall(r'^test (\S+) \.\.\. ok$', log, re.M)
    assert result['exitCode'] == 0 and match and tuple(map(int,match.groups())) == (expected,0,ignored)
    assert len(passed) == len(set(passed)) == expected and not names.intersection(passed)
    names.update(passed)
    final[stem] = {'passed':expected,'failed':0,'ignored':ignored,'exitCode':0,
        'selectedPaths':len(after['source']),'beforeAfterStableAndCurrent':True,
        'logSha256':digest((ev/(stem+'.log')).read_bytes())}
assert len(names) == 36
module = root/'apps/simulation/src/runtime/source_map_loading.rs'
assert digest(module.read_bytes()) == '8cd178aa505e0d50cdee14f575d062b4d13f3e6bf30ea478589e0a1fcab7db38'
oracle = ev/'oracle-01'
pack = ev/'pack-oracle-01'
assert digest((oracle/'OriginalMap.cs').read_bytes()) == '4df569012db86428b82b3c4994a1b0e982b1da7b5ed0b58dcf1930020ed4d5d1'
assert read(oracle/'rust-06-result.json')['sourceExitCode'] == read(oracle/'rust-06-result.json')['packExitCode'] == 0
assert read(oracle/'rust-06-before.json') == read(oracle/'rust-06-after.json')
source_rows = [json.loads(x) for x in (oracle/'rust-06-comparison.jsonl').read_text().splitlines()]
pack_rows = [json.loads(x) for x in (pack/'rust-02-comparison.jsonl').read_text().splitlines()]
assert len(source_rows) == 464 and sum(x['status']=='raw-terrain-matched' for x in source_rows) == 463
assert sum(x['status']=='empty-name-not-decoded' for x in source_rows) == 1
assert len(pack_rows) == 1620
assert sum(x['status']=='raw-terrain-matched' for x in pack_rows) == 1601
unknown = [x for x in pack_rows if x['status']!='raw-terrain-matched']
assert len(unknown) == 19
assert 'ordinary-collision-matched' in json.dumps(unknown), 'Expected explicit wider collision-domain record'
assert read(pack/'RESULT.json')['exitCode'] == 101
assert 'UnsupportedTrailingBytes' in (pack/'rust-original.log').read_text()

review = {'recordedUtc':datetime.now(timezone.utc).isoformat(),'role':'independent read-only reviewer',
    'moduleSha256':digest(module.read_bytes()),'modifiedFiles':False,'ranTests':False,
    'reportedBlockingFindings':False,
    'verifiedReadBoundariesByFormat':{'0':12,'1':14,'2':12,'3':19,'4':7,'5':14,'6':1,'7':13,'100':26},
    'notes':['FindType uses original full length and C# precedence before cell decoding',
             'Ordinary collision accepts Source unread tails but cannot construct Prepared identity',
             'Strict preparation remains separate and exact; no Map.Load/population authority claim',
             'Observed original final Gateway log with four passing tests']}
new_json(ev/'FINAL-READ-ONLY-REVIEW.json', review)
provenance = {'utc':datetime.now(timezone.utc).isoformat(),'baseSource':base,
    'finalSelectedInputs':read(ev/'06-final-source-reads-and-preparation-after.json')['source'],
    'finalModuleSha256':digest(module.read_bytes()),'finalTests':final,
    'retainedEarlierIntegrationMetadata':'COLLISION-INTEGRATION.json',
    'earlierIntegrationMetadataIsNotCurrentSourceHash':True}
new_json(ev/'FINAL-PROVENANCE.json', provenance)

doc = root/'docs/CLASSIC-SOURCE-MAP-TERRAIN-20261010.md'
text = doc.read_text(encoding='utf-8')
old = '''checks. The original optimized Gateway4 passed before the final read-domain
correction; its final-source rerun is recorded separately before qualification.
Original500ms TownTeleport and authentication/skill assertions are unchanged.'''
new = '''checks. The final optimized Gateway rerun on the corrected source passes all
4 original tests: 36 distinct final checks pass, with the one original benchmark
excluded. Original 500ms TownTeleport and authentication/skill assertions are
unchanged. Earlier repeated runs are retained and not added to the distinct count.'''
assert old in text
text = text.replace(old,new)
old = '''Predecessor01e3's Linux run37993166469 reached packaging after its main gates;
its separate siege job failed before tests while pulling postgres:16 (Docker
Hub timeout/rate limit). No whole-pipeline success is inferred from that progress.'''
new = '''Predecessor 01e3 is actually pushed with guarded GitHub readbacks. Its Linux
run 37993166469 completed the main build and genuine package upload successfully;
the first separate siege job failed before tests pulling postgres:16 (Docker Hub
timeout/rate limit), so attempt 1 failed overall. One actual failed-job-only
rerun was accepted. Snapshot 13 at 2026-10-09 22:34:16 UTC shows the main build
success retained and the siege job running its live protocol checks. No pipeline
or artifact qualification is inferred while that job is incomplete.'''
assert old in text
text = text.replace(old,new)
text = text.replace('Input/output hashes and exact runners are archived; selected local hashes do\nnot claim whole Cargo/toolchain/workspace input closure.',
'''Input/output hashes, exact runners, final read-only review and every retained
failure are in the [original archive](generated/player-qa/source-map-terrain-20261010/candidate-01/original-evidence.zip)
and [byte-verified receipt](generated/player-qa/source-map-terrain-20261010/candidate-01/EVIDENCE.json).
Selected local hashes do not claim whole Cargo/toolchain/workspace input closure.
Earlier integration metadata is preserved; FINAL-PROVENANCE.json supplies the
actual final hashes. The evidence flags are the pre-commit checkpoint.''')
doc.write_text(text,encoding='utf-8')

old = '''> Final optimized Gateway/source-specific Linux/publication are recorded
> separately; publicc704/R23/feed18 remains current with1 undrained WS. Full'''
new = '''> Final optimized Gateway 4/4 passes; 36 distinct final checks pass, with
> the original benchmark excluded. New-source Linux/publication remain separate;
> public c704/R23/feed18 remains current with 1 undrained WS. Full'''
for name in ['AGENT-ORCHESTRATION','AGENT-TASK-QUEUE','CRYSTAL-1TO1-ROADMAP',
             'BACKEND-1TO1-PROGRESS','CRYSTAL-SERVER-PARITY','CLASSIC-12H-DELIVERY-20261007']:
    path = root/'docs'/f'{name}.md'
    text = path.read_text(encoding='utf-8-sig')
    assert text.count(old)==1
    path.write_text(text.replace(old,new),encoding='utf-8')
owner_doc = root/'docs/CLASSIC-NPC-OWNER-EXECUTION-20261010.md'
with owner_doc.open('a',encoding='utf-8') as stream:
    stream.write('''
## Actual Git and Linux follow-up — 2026-10-10

Source 01e3d08791c2639b3375c39d46fbf4f00ca53f75 is actually pushed after
non-forced expected-parent update and fresh exact commit/tree/parent readbacks.
Run 37993166469 completed build-linux-x64 and package upload successfully.
Its first siege job failed pulling postgres:16 before tests (Docker Hub
timeout/rate limit); the whole first attempt failed and is retained. One
failed-job-only rerun was accepted. Snapshot 13 at 2026-10-09 22:34:16 UTC shows
the siege job running the original live protocol checks with main build success
retained. The original gates are unchanged. Overall Linux success, genuine
artifact verification and rollout are still separate pending checks. The newer
Source terrain changes require their own exact-source CI; this run cannot qualify
them. Public c704/R23/feed18 and all real saves remain untouched.
''')
subprocess.run(git+['diff','--check'],check=True)

entries = {}
def add(name,path):
    assert name not in entries
    data = Path(path).read_bytes()
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)',data), name
    entries[name]=data
for path in sorted(ev.iterdir()):
    if path.is_file(): add('local/'+path.name,path)
for directory in [oracle,pack]:
    for path in sorted(directory.iterdir()):
        if path.is_file(): add(directory.name+'/'+path.name,path)
for directory, allowed in [('csharp',['Oracle.csproj','Program.cs']),
                           ('rust',['Cargo.toml','Cargo.lock','src/main.rs'])]:
    for name in allowed: add('oracle-01/'+directory+'/'+name,oracle/directory/name)
for name in ['Prepare-SourceTerrainOracle.py','Prepare-SourceTerrainRustProbe.py',
             'Repair-SourceTerrainRustProbe.py','Extend-SourceTerrainRustProbe.py',
             'Prepare-SourceTerrainPackOracle.py','Repair-SourceTerrainPackComparison.py',
             'Integrate-SourceTerrainCollision.py','Write-SourceTerrainProgress.py',
             'Run-SourceMapTerrainRoot.ps1','Close-SourceTerrainCandidate.py']:
    add('runners/'+name,repo.parent/name)
for name in ['.github/workflows/gateway-release.yml',
             'mir2-web3/apps/simulation/src/runtime/source_map_loading.rs',
             'mir2-web3/apps/simulation/src/runtime/map.rs',
             'mir2-web3/apps/simulation/src/runtime/mod.rs',
             'mir2-web3/apps/gateway/tests/shared_purification_map_transfer.rs']:
    add('final-source/'+name,repo/name)
for name in ['PUBLISHED-VERIFIED.json','REF-MCP-FRESH-READBACK.json','COMMIT-MCP-FRESH-READBACK.json']:
    add('predecessor-git/'+name,publication/name)
for name in ['snapshot-12.json','snapshot-12-runs.json','snapshot-12-jobs.json',
             'snapshot-13.json','snapshot-13-runs.json','snapshot-13-jobs.json',
             'siege-job-02-api-original.log','siege-job-02-api-result.json',
             'FAILED-JOB-RERUN-TOOL-RESULT.json']:
    add('predecessor-ci/'+name,ci/name)
snapshot=next(json.loads(line) for line in (ev/'public-preflight-read-01.log').read_text().splitlines() if line.startswith('{'))
assert snapshot['test']['revision']=='c70436f34eabb432d769e0082c0afa23303294b0'
assert snapshot['test']['capacity']['currentWsConnections']==1
out.mkdir(parents=True)
archive=out/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zipped:
    for name,data in entries.items(): zipped.writestr(name,data)
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None and set(zipped.namelist())==set(entries)
    assert all(zipped.read(name)==data for name,data in entries.items())
assert archive.stat().st_size <= 3*1024*1024
record={'createdUtc':datetime.now(timezone.utc).isoformat(),'baseSource':base,
    'normalCollisionIntegrated':True,'rawPreparationImplemented':True,
    'localTestsPassed':True,'uniqueTestsPassed':36,'originalBenchmarkIgnored':1,'finalTests':final,
    'sourceCorpus':{'records':464,'matchedPreparationsAndCollisions':463,'literalEmptyNameNotDecoded':1,
                    'mismatches':0,'preparationUnavailable':0,'actualFormats':{'1':456,'5':5,'100':2}},
    'bundledCorpus':{'files':1620,'ordinaryCollisionsMatched':1620,'mismatches':0,
                     'rawPreparationUnavailable':19,'unavailableIsNotKnownEmpty':True,
                     'firstStrictNormalProbeFailedAndRetained':True,
                     'actualFormats':{'0':237,'1':1370,'3':1,'5':6,'100':6}},
    'overlappingCorporaNotDistinctMapSum':True,'syntheticOnlyFormats':[2,4,6,7],
    'originalSourceReadersUnmodified':True,'originalProductAssertionsUnmodified':True,
    'allOriginalCompileAndProbeFailuresRetained':True,'independentReviewReadOnly':True,
    'newSourcePushed':False,'exactLinuxPassed':False,'gatewayPublished':False,'humanAccepted':False,
    'successfulSourceLoadProducerImplemented':False,'populationReceiptMinted':False,
    'ordinaryCheckhumConsumerImplemented':False,'sourceCasWorldOutboxImplemented':False,
    'publicGateway':snapshot['test']['revision'],'publicClient':'R23/sourcefaef/signedfeed18',
    'productionSwitched':False,'heldWsConnections':1,
    'limits':['13 selected input hashes, not whole workspace/toolchain closure',
              'after-read decoder bounds do not bound earlier file/decompression IO',
              'no cold-load/RSS improvement claimed; ordinary path uses a temporary cell vector',
              'original Map.Load, DB boot, full NPC/world initialization and native rendering are unverified',
              'full P1-P7/Mentor/native/human and new exact-source Linux remain open'],
    'archive':{'file':archive.name,'entries':len(entries),'bytes':archive.stat().st_size,
               'sha256':digest(archive.read_bytes()),'everyEntryByteVerified':True},
    'entries':{name:{'bytes':len(data),'sha256':digest(data)} for name,data in entries.items()}}
new_json(out/'EVIDENCE.json',record)
print(json.dumps({k:v for k,v in record.items() if k not in ['entries','finalTests']},indent=2))
