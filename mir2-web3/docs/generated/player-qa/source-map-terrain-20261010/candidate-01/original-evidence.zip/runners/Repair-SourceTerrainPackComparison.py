import hashlib
import json
from pathlib import Path

root=Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/oracle-01')
p=root/'rust/src/main.rs'
old=p.read_text()
backup=root/'probe-pre-source-read-domain-main.rs'
assert not backup.exists()
backup.write_bytes(p.read_bytes())
needle='fn main() {'
helper=r'''fn collision_matches_source(collision: &mir2_game_data::StarterMapCollision, original: &serde_json::Value) -> bool {
    let blocked: HashMap<_,_> = collision.blocked_cells.iter().map(|c|((c.x,c.y),&c.attribute)).collect();
    let doors: HashMap<_,_> = collision.doors.iter().map(|d|((d.x,d.y),d.index)).collect();
    let fish: HashMap<_,_> = collision.fishing_cells.iter().map(|f|((f.x,f.y),f.attribute)).collect();
    let mut cells=Sha256::new(); let mut walk=Sha256::new(); let mut walk_count=0;
    for x in 0..i32::from(collision.map_width) { for y in 0..i32::from(collision.map_height) {
        let point=(x,y);
        let attribute=match blocked.get(&point) {
            Some(mir2_game_data::MapCellAttribute::LowWall)=>1,
            Some(mir2_game_data::MapCellAttribute::HighWall)=>2,
            None=>0,
        };
        cells.update([attribute,u8::from(doors.contains_key(&point)),*doors.get(&point).unwrap_or(&0),
            fish.get(&point).map(|f|(*f+1) as u8).unwrap_or(0)]);
        if attribute==0 { walk_count+=1; walk.update(x.to_le_bytes()); walk.update(y.to_le_bytes()); }
    } }
    original["width"].as_u64()==Some(u64::from(collision.map_width))
      && original["height"].as_u64()==Some(u64::from(collision.map_height))
      && original["cellHash"].as_str()==Some(hex(cells.finalize()).as_str())
      && original["walkHash"].as_str()==Some(hex(walk.finalize()).as_str())
      && original["walkCount"].as_u64()==Some(walk_count)
}
'''
assert old.count(needle)==1
fixed=old.replace(needle,helper+needle)
needle='        let prepared = match prepare_source_map_terrain('
assert fixed.count(needle)==1
fixed=fixed.replace(needle,'''        let normalized=filename.to_ascii_lowercase();
        let actual_collision=source_map_loading::decode_runtime_map_collision(&normalized,&bytes)
            .expect("original Source actual cell-read domain must decode ordinary collision");
        let prepared = match prepare_source_map_terrain(''')
old_error='''                unavailable += 1;
                writeln!(output,"{}",serde_json::json!({"input":input,"status":"preparation-unavailable","sourceStatus":original["status"],"error":format!("{error:?}")})).unwrap();
                continue;'''
new_error='''                unavailable += 1;
                let equal=matches!(error,source_map_loading::SourceMapTerrainUnavailable::UnsupportedTrailingBytes { .. })
                    && original["status"]=="raw-cells-decoded-not-Map.Load"
                    && collision_matches_source(&actual_collision,&original);
                if equal { matched+=1; } else { mismatched+=1; }
                writeln!(output,"{}",serde_json::json!({"input":input,"status":if equal {"ordinary-source-collision-matched-preparation-unavailable"} else {"ordinary-source-collision-mismatch"},
                    "sourceStatus":original["status"],"preparationError":format!("{error:?}"),"rawSha256":original["rawSha256"]})).unwrap();
                continue;'''
assert fixed.count(old_error)==1
fixed=fixed.replace(old_error,new_error)
fixed=fixed.replace('assert_eq!(unavailable,0,"Actual raw corpus has preparation gaps");',
    'let expected_preparation_unavailable: usize=args.get(4).map(|v|v.parse().unwrap()).unwrap_or(0);\n    assert_eq!(unavailable,expected_preparation_unavailable,"Strict preparation availability differs from its explicitly recorded domain");')
fixed=fixed.replace('"unavailable":unavailable', '"strictPreparationUnavailable":unavailable')
p.write_text(fixed)
(root/'PACK-DOMAIN-COMPARISON-REPAIR.json').write_text(json.dumps(dict(
    beforeProbeSha256=hashlib.sha256(backup.read_bytes()).hexdigest(),
    actualProbeSha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    originalFailureRetained=True,
    correction='Ordinary collision obeys actual unmodified Source reads; strict preparation remains unavailable for19 trailing-byte records',
    noFullMapLoadClaim=True
),indent=2)+'\n')
print('Separate Source collision/preparation domains are explicitly compared; original19-gap failure retained')
