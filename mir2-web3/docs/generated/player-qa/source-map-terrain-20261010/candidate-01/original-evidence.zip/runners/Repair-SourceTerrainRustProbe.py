import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

root = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/oracle-01')
p = root / 'rust/src/main.rs'
old = p.read_text()
backup = root / 'probe-original-main.rs'
assert not backup.exists()
backup.write_bytes(p.read_bytes())
fixed = old.replace('fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }',
    'fn hex(bytes: impl AsRef<[u8]>) -> String { bytes.as_ref().iter().map(|b|format!("{b:02x}")).collect() }\nfn digest(bytes: &[u8]) -> String { hex(Sha256::digest(bytes)) }')
fixed = fixed.replace('format!("{:x}",cells.finalize())','hex(cells.finalize())')
fixed = fixed.replace('format!("{:x}",walk.finalize())','hex(walk.finalize())')
assert fixed != old and 'format!("{:x}"' not in fixed
p.write_text(fixed)
(root / 'PROBE-HEX-REPAIR.json').write_text(json.dumps(dict(
    utc=datetime.now(timezone.utc).isoformat(), originalMainSha256=hashlib.sha256(old.encode()).hexdigest(),
    fixedMainSha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    firstAttempt='Rust probe compile failed: sha2 0.11 Array does not implement LowerHex',
    secondAttempt='Shell repair command rejected by PowerShell before execution; probe compile failed unchanged',
    scope='Temporary probe hex serializer only; production module and original Source methods unchanged'
), indent=2)+'\n')
print('Temporary probe hex serializer repaired; all original compile failures retained')
