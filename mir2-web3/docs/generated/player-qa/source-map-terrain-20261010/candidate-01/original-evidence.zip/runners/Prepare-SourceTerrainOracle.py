import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

checkout = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3')
root = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/oracle-01')
source = Path('E:/mir2/Crystal/Server/MirEnvir/Map.cs')
maps = Path('E:/mir2/Crystal/Build/Server/Debug/Maps')
manifest = checkout / 'packages/game-data/data/generated/crystal_respawn_manifest.json'
assert not root.exists(), 'Do not overwrite an original attempt'
root.mkdir(parents=True)
text = source.read_text(encoding='utf-8-sig')

def extract(signature):
    start = text.index(signature)
    brace = text.index('{', start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (text[end] == '{') - (text[end] == '}')
        end += 1
    return text[start:end]

signatures = ['public Door AddDoor(byte DoorIndex, Point location)',
              'private byte FindType(byte[] input)']
signatures += ['private void LoadMapCellsv%d(byte[] fileBytes)' % i for i in range(8)]
signatures += ['private void LoadMapCellsV100(byte[] Bytes)', 'public void GetWalkableCells()']
methods = '\n\n'.join(extract(s) for s in signatures)
(root / 'OriginalTerrainMethods.cs.txt').write_text(methods, encoding='utf-8')
(root / 'OriginalMap.cs').write_bytes(source.read_bytes())
records = [dict(ordinal=i, index=m['map_index'], fileName=m['map_file_name'])
           for i, m in enumerate(json.loads(manifest.read_bytes())['maps'])]
(root / 'inputs.json').write_text(json.dumps(records, indent=2), encoding='utf-8')
project = root / 'csharp'
project.mkdir()
(project / 'Oracle.csproj').write_text('''<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net9.0</TargetFramework>
  <ImplicitUsings>enable</ImplicitUsings><Nullable>disable</Nullable></PropertyGroup>
</Project>\n''', encoding='utf-8')
wrapper = r'''using System.Drawing;
using System.Security.Cryptography;
using System.Text.Json;
public enum CellAttribute : byte { Walk = 0, HighWall = 1, LowWall = 2 }
public class Cell {
    public static Cell LowWall { get { return new Cell { Attribute = CellAttribute.LowWall }; } }
    public static Cell HighWall { get { return new Cell { Attribute = CellAttribute.HighWall }; } }
    public CellAttribute Attribute;
    public sbyte FishingAttribute = -1;
}
public class Door { public byte index; public Point Location; }
public record Input(int ordinal, int index, string fileName);
public class Oracle {
    public int Width, Height;
    public Cell[,] Cells;
    public Door[,] DoorIndex;
    public List<Door> Doors = new();
    public List<Point> WalkableCells;
__METHODS__
    public byte Decode(byte[] b) {
        byte format = FindType(b);
        switch (format) {
            case 0: LoadMapCellsv0(b); break;
            case 1: LoadMapCellsv1(b); break;
            case 2: LoadMapCellsv2(b); break;
            case 3: LoadMapCellsv3(b); break;
            case 4: LoadMapCellsv4(b); break;
            case 5: LoadMapCellsv5(b); break;
            case 6: LoadMapCellsv6(b); break;
            case 7: LoadMapCellsv7(b); break;
            case 100: LoadMapCellsV100(b); break;
        }
        GetWalkableCells();
        return format;
    }
    public string CellHash() {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        byte[] cell = new byte[4];
        for(int x=0;x<Width;x++) for(int y=0;y<Height;y++) {
            cell[0] = Cells[x,y].Attribute switch {
                CellAttribute.Walk => 0, CellAttribute.LowWall => 1,
                CellAttribute.HighWall => 2, _ => throw new InvalidDataException() };
            var door = DoorIndex[x,y];
            cell[1]=(byte)(door==null ? 0 : 1);
            cell[2]=(byte)(door==null ? 0 : door.index);
            cell[3]=(byte)(Cells[x,y].FishingAttribute + 1);
            hash.AppendData(cell);
        }
        return Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();
    }
    public string WalkHash() {
        using var hash=IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        foreach(var p in WalkableCells) {
            hash.AppendData(BitConverter.GetBytes(p.X));
            hash.AppendData(BitConverter.GetBytes(p.Y));
        }
        return Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();
    }
    public static void Main(string[] args) {
        var inputs=JsonSerializer.Deserialize<List<Input>>(File.ReadAllText(args[0]));
        using var output=new StreamWriter(args[2], false, new System.Text.UTF8Encoding(false));
        foreach(var input in inputs) {
            if(input.fileName.Length==0) {
                output.WriteLine(JsonSerializer.Serialize(new { input, status="empty-name-not-decoded" }));
                continue;
            }
            var path=Path.Combine(args[1], input.fileName + ".map");
            byte[] bytes=File.ReadAllBytes(path);
            string rawSha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
            try {
                var oracle=new Oracle();
                byte format=oracle.Decode(bytes);
                output.WriteLine(JsonSerializer.Serialize(new {
                    input, status="raw-cells-decoded-not-Map.Load", rawSha256, rawByteLength=bytes.Length,
                    format, width=oracle.Width, height=oracle.Height,
                    walkCount=oracle.WalkableCells.Count, cellHash=oracle.CellHash(), walkHash=oracle.WalkHash(),
                    sourceUniqueDoorCount=oracle.Doors.Count
                }));
            } catch(Exception exception) {
                output.WriteLine(JsonSerializer.Serialize(new {
                    input, status="raw-oracle-unavailable-not-Map.Load-failure", rawSha256,
                    rawByteLength=bytes.Length, error=exception.GetType().Name
                }));
            }
        }
    }
}
'''
(project / 'Program.cs').write_text(wrapper.replace('__METHODS__', methods), encoding='utf-8')
receipt = dict(utc=datetime.now(timezone.utc).isoformat(), baseSource='01e3d08791c2639b3375c39d46fbf4f00ca53f75',
               sourceMapSha256=hashlib.sha256(source.read_bytes()).hexdigest(),
               inputManifestSha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
               methodSignatures=signatures, methodTextSha256=hashlib.sha256(methods.encode()).hexdigest(),
               inputCount=len(records), nonemptyInputCount=sum(bool(r['fileName']) for r in records),
               methodExtraction='Exact unmodified method text; minimal Cell and Door fields preserve used Source behavior',
               scope='Raw cell readers and GetWalkableCells only; no Source Map.Load, database boot, NPC, mining, receipt, population or real saves')
(root / 'PREPARED.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt))
