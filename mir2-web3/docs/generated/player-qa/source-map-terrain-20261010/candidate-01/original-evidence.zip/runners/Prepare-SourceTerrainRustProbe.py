import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

checkout = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3')
root = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/oracle-01')
project = root / 'rust'
assert not project.exists()
project.mkdir()
(project / 'src').mkdir()
manifest = '''[package]
name = "source-terrain-oracle-probe"
version = "0.1.0"
edition = "2021"
[workspace]
[dependencies]
mir2-game-data = { path = "%s/packages/game-data" }
sha2 = "0.11"
serde_json = "1"
''' % checkout.as_posix()
(project / 'Cargo.toml').write_text(manifest, encoding='utf-8')
(project / 'Cargo.lock').write_bytes((checkout / 'Cargo.lock').read_bytes())
module = (checkout / 'apps/simulation/src/runtime/source_map_loading.rs').as_posix()
probe = r'''#[path = "__MODULE__"]
mod source_map_loading;
use sha2::{Digest, Sha256};
use source_map_loading::{prepare_source_map_terrain, SourceTerrainCellAttribute};
use std::{collections::HashMap, fs, io::Write, path::Path};
fn digest(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let oracle = fs::read_to_string(&args[1]).unwrap();
    let mut output = fs::OpenOptions::new().write(true).create_new(true).open(&args[3]).unwrap();
    let mut matched = 0;
    let mut unavailable = 0;
    let mut mismatched = 0;
    for line in oracle.lines() {
        let original: serde_json::Value = serde_json::from_str(line).unwrap();
        let input = &original["input"];
        let filename = input["fileName"].as_str().unwrap();
        if filename.is_empty() {
            writeln!(output, "{}", serde_json::json!({"input":input,"status":"empty-name-not-decoded"})).unwrap();
            continue;
        }
        let bytes = fs::read(Path::new(&args[2]).join(format!("{filename}.map"))).unwrap();
        assert_eq!(digest(&bytes), original["rawSha256"].as_str().unwrap(), "Source input changed");
        assert_eq!(bytes.len() as u64, original["rawByteLength"].as_u64().unwrap());
        let prepared = match prepare_source_map_terrain(input["ordinal"].as_u64().unwrap() as usize,
                          input["index"].as_i64().unwrap() as i32, filename, &bytes) {
            Ok(prepared) => prepared,
            Err(error) => {
                unavailable += 1;
                writeln!(output,"{}",serde_json::json!({"input":input,"status":"preparation-unavailable","sourceStatus":original["status"],"error":format!("{error:?}")})).unwrap();
                continue;
            }
        };
        assert_eq!(prepared.source_ordinal(),input["ordinal"].as_u64().unwrap() as usize);
        assert_eq!(prepared.source_index(),input["index"].as_i64().unwrap() as i32);
        assert_eq!(prepared.raw_file_name(),filename);
        assert_eq!(prepared.raw_byte_len(),bytes.len());
        assert_eq!(prepared.raw_sha256().as_slice(),Sha256::digest(&bytes).as_slice());
        let doors: HashMap<_,_> = prepared.collision().doors.iter().map(|d|((d.x,d.y),d.index)).collect();
        let fish: HashMap<_,_> = prepared.collision().fishing_cells.iter().map(|f|((f.x,f.y),f.attribute)).collect();
        assert_eq!(doors.len(),prepared.collision().doors.len(),"Duplicate door coordinates");
        assert_eq!(fish.len(),prepared.collision().fishing_cells.len(),"Duplicate fishing coordinates");
        let mut cells = Sha256::new();
        for x in 0..prepared.width() { for y in 0..prepared.height() {
            let point = (i32::from(x),i32::from(y));
            let attribute = match prepared.cell_attribute_at(x,y).unwrap() {
                SourceTerrainCellAttribute::Walk => 0,
                SourceTerrainCellAttribute::LowWall => 1,
                SourceTerrainCellAttribute::HighWall => 2,
            };
            cells.update([attribute,u8::from(doors.contains_key(&point)),*doors.get(&point).unwrap_or(&0),
                          fish.get(&point).map(|f|(*f + 1) as u8).unwrap_or(0)]);
        } }
        let mut walk = Sha256::new();
        for &(x,y) in prepared.base_walkable_cells() { walk.update(x.to_le_bytes()); walk.update(y.to_le_bytes()); }
        let cell_hash = format!("{:x}",cells.finalize());
        let walk_hash = format!("{:x}",walk.finalize());
        let equal = original["status"] == "raw-cells-decoded-not-Map.Load"
           && original["format"].as_u64() == Some(u64::from(prepared.map_format()))
           && original["width"].as_u64() == Some(u64::from(prepared.width()))
           && original["height"].as_u64() == Some(u64::from(prepared.height()))
           && original["walkCount"].as_u64() == Some(prepared.base_walkable_cells().len() as u64)
           && original["cellHash"].as_str() == Some(cell_hash.as_str())
           && original["walkHash"].as_str() == Some(walk_hash.as_str());
        if equal { matched+=1; } else { mismatched+=1; }
        writeln!(output,"{}",serde_json::json!({"input":input,"status":if equal {"raw-terrain-matched"} else {"raw-terrain-mismatch"},
                "format":prepared.map_format(),"width":prepared.width(),"height":prepared.height(),"walkCount":prepared.base_walkable_cells().len(),
                "cellHash":cell_hash,"walkHash":walk_hash,"rawSha256":original["rawSha256"]})).unwrap();
    }
    let summary = serde_json::json!({"matched":matched,"unavailable":unavailable,"mismatched":mismatched,
        "scope":"Raw terrain only; no full Map.Load, global loaded directory, population authority or live installation"});
    println!("{summary}");
    assert_eq!(unavailable,0,"Actual raw corpus has preparation gaps");
    assert_eq!(mismatched,0,"Original Source cell/walk data differs");
}
'''
(project / 'src/main.rs').write_text(probe.replace('__MODULE__', module), encoding='utf-8')
(root / 'RUST-PROBE-PREPARED.json').write_text(json.dumps(dict(utc=datetime.now(timezone.utc).isoformat(),
    actualModulePath=module, actualModuleSha256=hashlib.sha256(Path(module).read_bytes()).hexdigest(),
    actualGameDataPath=(checkout/'packages/game-data').as_posix(),
    scope='Separate isolated Rust binary includes the actual module by path and uses actual game-data crate, not copied terrain logic/stubs; lockfile is independent'),indent=2)+'\n')
print('Actual-module Rust probe prepared; no comparison result yet')
