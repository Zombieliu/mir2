import hashlib
import json
from pathlib import Path

repo = Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01')
root = Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence')
p = repo / 'mir2-web3/apps/simulation/src/runtime/map.rs'
old = p.read_text(encoding='utf-8-sig')
start = old.index('pub(super) fn parse_runtime_map_collision(\n')
end = old.index('pub(super) fn runtime_full_map_collision_data(\n',start)
original = old[start:end]
assert 'detect_runtime_map_type' in original and original.count('pub(super) fn ') == 15
backup = root / 'legacy-parser-original.rs.txt'
assert not backup.exists()
backup.write_text(original,encoding='utf-8')
replacement = '''pub(super) fn parse_runtime_map_collision(
    map_file_name: &str,
    bytes: &[u8],
) -> Option<StarterMapCollision> {
    let normalized = normalize_map_file_name(map_file_name);
    // Collision availability is not a successful Source Map.Load receipt.
    // Share the bounded Source cell decoder; preserve the existing cache key.
    super::source_map_loading::decode_runtime_map_collision(&normalized, bytes).ok()
}

'''
p.write_text(old[:start]+replacement+old[end:],encoding='utf-8')
(root/'COLLISION-INTEGRATION.json').write_text(json.dumps(dict(
    originalMapModuleSha256=hashlib.sha256(old.encode()).hexdigest(),
    newMapModuleSha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    removedDuplicateParserLines=len(original.splitlines()),
    sourceDifferences=['FindType 0F branch precedence','v4 stride 12','v0/v2/v3 no-floor final HighWall assignment'],
    originalMapCacheKeysPreserved=True,sourceLoadReceiptIssued=False,
    existingFallbackChanged=False,originalTestsEdited=False
),indent=2)+'\n')
print('Normal collision entry uses bounded Source decoder; original duplicate parser retained in evidence')
