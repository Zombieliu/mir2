import hashlib
import json
from pathlib import Path

root=Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/oracle-01')
p=root/'rust/src/main.rs'
old=p.read_text()
backup=root/'probe-pre-collision-comparison-main.rs'
assert not backup.exists()
backup.write_bytes(p.read_bytes())
needle='        let doors: HashMap<_,_> = prepared.collision().doors.iter()'
assert old.count(needle)==1
prefix='''        let normalized = filename.to_ascii_lowercase();
        let runtime_collision = source_map_loading::decode_runtime_map_collision(&normalized,&bytes)
            .expect("actual ordinary collision decoder must accept every Source-backed raw map");
        let mut expected_collision = prepared.collision().clone();
        expected_collision.map_file_name = format!("{normalized}.map");
        assert_eq!(runtime_collision,expected_collision,"ordinary collision differs from Source preparation");
'''
fixed=old.replace(needle,prefix+needle).replace('Raw terrain only; no full Map.Load, global loaded directory, population authority or live installation',
    'Raw preparation and actual ordinary collision decoder only; no full Map.Load, global loaded directory, population authority or live installation')
p.write_text(fixed)
(root/'ORDINARY-COLLISION-PROBE.json').write_text(json.dumps(dict(
    originalProbeSha256=hashlib.sha256(backup.read_bytes()).hexdigest(),
    finalProbeSha256=hashlib.sha256(p.read_bytes()).hexdigest(),
    actualHelper='source_map_loading::decode_runtime_map_collision',
    normalizedKeyBridgeTestedBySeparateOrdinaryLibraryTests=True,
    fullSourceMapLoadClaim=False
),indent=2)+'\n')
print('Actual ordinary collision helper added to Source raw-corpus comparison')
