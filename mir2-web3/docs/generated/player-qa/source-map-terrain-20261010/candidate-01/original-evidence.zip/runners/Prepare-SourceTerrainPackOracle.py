import gzip
import hashlib
import json
from pathlib import Path

repo=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3')
pack=repo/'apps/web/lib/generated/crystal-map-pack'
root=Path('C:/mir2-build/p7-source-map-terrain-20261010-evidence/pack-oracle-01')
assert not root.exists()
root.mkdir()
(root/'maps').mkdir()
inputs=[]
hashes=[]
for ordinal,p in enumerate(sorted(pack.glob('*.map.gz'))):
    name=p.name[:-len('.map.gz')]
    compressed=p.read_bytes()
    raw=gzip.decompress(compressed)
    assert 0<len(raw)<=128*1024*1024
    (root/'maps'/f'{name}.map').write_bytes(raw)
    inputs.append(dict(ordinal=ordinal,index=-1,fileName=name))
    hashes.append(dict(file=p.name,compressedBytes=len(compressed),compressedSha256=hashlib.sha256(compressed).hexdigest(),
                       rawBytes=len(raw),rawSha256=hashlib.sha256(raw).hexdigest()))
assert inputs
(root/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
(root/'PACK-INPUTS.json').write_text(json.dumps(dict(
    count=len(inputs),inputs=hashes,actualPackPath=pack.as_posix(),
    identity='Audit fixture ordinals/index=-1 are not Source MapInfo or successful-loaded identities',
    scope='Exact actual bundled gzip corpus; no client preference directory or Source full Map.Load proof'
),indent=2)+'\n')
print(json.dumps({'actualBundledPackFiles':len(inputs),'rawBytes':sum(row['rawBytes'] for row in hashes),
                  'inputHashesRecorded':True,'sourceLoadClaim':False}))
