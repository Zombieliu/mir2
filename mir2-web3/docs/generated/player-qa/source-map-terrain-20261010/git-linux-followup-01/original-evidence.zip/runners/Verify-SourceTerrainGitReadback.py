import hashlib, json, subprocess
from datetime import datetime, timezone
from pathlib import Path

out=Path('C:/mir2-build/p7-source-map-terrain-20261010-git-publication-01/exact-api')
head='64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
parent='01e3d08791c2639b3375c39d46fbf4f00ca53f75'
tree='e3a106fe45425887795a14c308ed86f640dc2eda'
branch='codex/gateway-disconnect-lifecycle-20261008'
assert json.loads((out/'REF-MCP-RESULT.json').read_bytes())['structuredContent']['success'] is True
def read(endpoint,stem):
    for attempt in range(1,4):
        try:
            r=subprocess.run(['gh','api','-H','Cache-Control: no-cache','repos/Zombieliu/mir2/'+endpoint],capture_output=True,timeout=55)
            data,error,code=r.stdout,r.stderr,r.returncode
        except subprocess.TimeoutExpired as e: data,error,code=e.stdout or b'',e.stderr or b'',124
        (out/f'{stem}-attempt-{attempt}.json').write_bytes(data)
        (out/f'{stem}-attempt-{attempt}.stderr.log').write_bytes(error)
        if code==0:
            with (out/(stem+'.json')).open('xb') as f:f.write(data)
            return json.loads(data), hashlib.sha256(data).hexdigest()
        print(json.dumps({'readbackAttempt':attempt,'exitCode':code,'originalFailureRetained':True}),flush=True)
    raise RuntimeError('Fresh readback failed; publication not claimed')
ref,ref_hash=read('git/ref/heads/'+branch,'REF-MCP-FRESH-READBACK')
commit,commit_hash=read('git/commits/'+head,'COMMIT-MCP-FRESH-READBACK')
assert ref['object']['sha']==commit['sha']==head
assert commit['tree']['sha']==tree and [x['sha'] for x in commit['parents']]==[parent]
record={'createdUtc':datetime.now(timezone.utc).isoformat(),'repository':'Zombieliu/mir2',
    'branch':branch,'head':head,'tree':tree,'parent':parent,'expectedParent':parent,
    'force':False,'candidateSourcePublishedToGit':True,'freshRefReadbackSha256':ref_hash,
    'freshCommitReadbackSha256':commit_hash,'gatewayPublished':False,'exactLinuxPassed':False,
    'newCiRequired':True,'realSavesModified':False}
with (out/'PUBLISHED-VERIFIED.json').open('x',encoding='utf-8') as f:
    json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
