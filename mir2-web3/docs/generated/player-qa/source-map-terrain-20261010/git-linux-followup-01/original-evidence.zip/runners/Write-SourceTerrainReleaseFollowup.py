import hashlib, json, zipfile
from datetime import datetime, timezone
from pathlib import Path

root=Path('E:/mir2-player-journey/tmp/gateway-lifecycle-20261008-01/mir2-web3')
git=Path('C:/mir2-build/p7-source-map-terrain-20261010-git-publication-01')
ci=Path('C:/mir2-build/p7-source-map-terrain-20261010-ci')
owner=Path('C:/mir2-build/p7-npc-owner-binding-20261010-ci')
out=root/'docs/generated/player-qa/source-map-terrain-20261010/git-linux-followup-01'
assert not out.exists()
head='64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
publication=json.loads((git/'exact-api/PUBLISHED-VERIFIED.json').read_bytes())
assert publication['head']==head and publication['force'] is False and publication['candidateSourcePublishedToGit'] is True
linux=json.loads((owner/'server-ci-01/artifact-01/CI-VERIFIED.json').read_bytes())
assert linux['revision']=='01e3d08791c2639b3375c39d46fbf4f00ca53f75'
assert linux['runConclusion']=='success' and len(linux['jobs'])==2 and all(j['conclusion']=='success' for j in linux['jobs'])
live=next(json.loads(x) for x in (owner/'public-preflight-read-01.log').read_text().splitlines() if x.startswith('{'))
assert live['test']['revision']=='c70436f34eabb432d769e0082c0afa23303294b0'
assert live['test']['capacity']['currentWsConnections']==1
latest=json.loads((ci/'server-ci-01/snapshot-02.json').read_bytes())
assert latest['source']==head and latest['runId']==38001876065 and latest['status']=='in_progress'
entries={}
for name in ['exact-api/PUBLISHED-VERIFIED.json','exact-api/REF-MCP-FRESH-READBACK.json',
             'exact-api/COMMIT-MCP-FRESH-READBACK.json','exact-api/REF-MCP-RESULT.json',
             'exact-api/TREE-MCP-RESULT.json','LOCAL-COMMIT.json','FROZEN-WORKTREE-COMPLETED.json',
             'WORKTREE-LONG-PATH-FAILURE.json']:
    entries['git/'+name]=(git/name).read_bytes()
for name in ['HELPERS-PREPARED.json','VERIFIER-PREPARED.json',
             'server-ci-01/DISPATCH-REQUEST.json','server-ci-01/DISPATCH-RESULT.json',
             'server-ci-01/snapshot-01.json','server-ci-01/snapshot-02.json',
             'server-ci-01/snapshot-02-runs.json','server-ci-01/snapshot-02-jobs.json']:
    entries['terrain-ci/'+name]=(ci/name).read_bytes()
for name in ['server-ci-01/FAILED-JOB-RERUN-TOOL-RESULT.json','server-ci-01/snapshot-12.json',
             'server-ci-01/snapshot-15.json','server-ci-01/snapshot-15-runs.json',
             'server-ci-01/snapshot-15-jobs.json','server-ci-01/siege-job-02-api-original.log',
             'server-ci-01/artifact-01/CI-VERIFIED.json','server-ci-01/artifact-01/ci-status-original.json',
             'server-ci-01/artifact-01/ci-artifacts-original.json','server-ci-01/artifact-01/ci-log-original.txt',
             'server-ci-01/artifact-01/latest-mir2-gateway-release.json',
             'server-ci-01/artifact-01/VERIFIED-FILES.json','public-preflight-read-01.log']:
    entries['predecessor-ci/'+name]=(owner/name).read_bytes()
for name in ['Verify-SourceTerrainGitReadback.py','Prepare-SourceTerrainCIHelpers.py',
             'Dispatch-SourceTerrainGatewayCI.py','Record-SourceTerrainGatewayCI.py',
             'Prepare-SourceTerrainLinuxVerifier.py','Download-SourceTerrainLinuxCI.py',
             'Download-NpcOwnerLinuxCI.py','Write-SourceTerrainReleaseFollowup.py']:
    entries['runners/'+name]=(root.parent.parent/name).read_bytes()
out.mkdir(parents=True)
archive=out/'original-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in entries.items():z.writestr(name,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    assert all(z.read(name)==data for name,data in entries.items())
record={'createdUtc':datetime.now(timezone.utc).isoformat(),'source':head,
    'sourceActuallyPushed':True,'sourceFrozenClean':True,
    'terrainLinuxRun':latest['runId'],'terrainLinuxStatus':latest['status'],'terrainLinuxPassed':False,
    'predecessorLinux':linux,'predecessorInfraFailureRetained':True,'failedJobOnlyRerun':True,
    'publicGateway':live['test']['revision'],'publicClient':'R23/sourcefaef/signedfeed18',
    'rolloutHeldBeforeStaging':True,'heldWsConnections':1,'serverSwitched':False,
    'successfulMapLoadProducerImplemented':False,'fullClassicCompleted':False,
    'longPathWorktreeFailureRetained':True,'shortNameT64SucceededWithoutGlobalGitConfigChange':True,
    'archive':{'file':archive.name,'entries':len(entries),'bytes':archive.stat().st_size,
        'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'everyEntryByteVerified':True},
    'entries':{name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in entries.items()}}
(out/'EVIDENCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
with (root/'docs/CLASSIC-SOURCE-MAP-TERRAIN-20261010.md').open('a',encoding='utf-8') as f:
    f.write('''
## Actual Git and Linux follow-up — 2026-10-10

Terrain source 64b6b10c05732048da9c6bf5ccb0a491d2d053d3 is actually pushed
with non-forced expected-parent update and fresh exact GitHub ref/commit/tree
readbacks. The clean t64 worktree is frozen. Its exact-source Linux run
[38001876065](https://github.com/Zombieliu/mir2/actions/runs/38001876065)
was dispatched once with R2 publication disabled; snapshot 2 shows both jobs
running. This is not yet a successful Linux package or deployment.

Predecessor 01e3 run 37993166469 now actually passes both original jobs after
the single failed-job-only retry. Its original artifact ZIP, archive, ELF
Gateway/ZoneHost binaries, clean revision metadata, manifest and all original
CI gates/logs were independently verified. The first Docker infrastructure
failure remains retained. This predecessor cannot qualify the newer terrain
source. The fresh public preflight still reports one WS connection; rollout
remains held before staging, with c704/R23/feed18 current.

The [follow-up receipt](generated/player-qa/source-map-terrain-20261010/git-linux-followup-01/EVIDENCE.json)
and [original byte-verified archive](generated/player-qa/source-map-terrain-20261010/git-linux-followup-01/original-evidence.zip)
retain those actual readbacks, complete CI log, first failure, rerun and public
preflight. The initial long-name worktree creation failed on Windows path
length; the shorter t64 creation succeeded without changing global Git settings.
New bounded I/O work in the Root lane is a separate unqualified Candidate and
does not alter the frozen source or these results.
''')
with (root/'docs/CLASSIC-NPC-OWNER-EXECUTION-20261010.md').open('a',encoding='utf-8') as f:
    f.write('''
The subsequent final readback confirms run 37993166469 completed successfully
with both original jobs. Its genuine artifact ZIP, source/clean metadata,
archive/checksum, ELF binaries and every original CI gate/log were verified.
The first Docker infrastructure failure remains retained. The actual qualified
receipt is linked from the Source terrain Git/Linux follow-up above. Public
preflight still has 1 WS connection, so this is qualified, not deployed.
''')
print(json.dumps({k:v for k,v in record.items() if k!='entries'},indent=2))
