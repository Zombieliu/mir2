import hashlib, json, subprocess
from pathlib import Path

directory=Path('E:/mir2-player-journey/tmp')
source='64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
frozen=Path('C:/Users/Administrator/.codex/worktrees/t64/mir2-player-journey')
git=['git','-c','safe.directory='+frozen.as_posix(),'-c','gc.auto=0','-c','maintenance.auto=false','-C',str(frozen)]
assert subprocess.check_output(git+['rev-parse','HEAD']).decode().strip()==source
assert not subprocess.check_output(git+['status','--porcelain=v1','--untracked-files=all'])
publication=Path('C:/mir2-build/p7-source-map-terrain-20261010-git-publication-01/exact-api/PUBLISHED-VERIFIED.json')
assert json.loads(publication.read_bytes())['head']==source
replacements={
    '01e3d08791c2639b3375c39d46fbf4f00ca53f75':source,
    '2026-10-10-npc-owner-01e3d08791':'2026-10-10-source-terrain-64b6b10c05',
    'C:/Users/Administrator/.codex/worktrees/npc-owner-release-01e3d08791/mir2-player-journey':frozen.as_posix(),
    'p7-npc-owner-binding-20261010-git-publication-01':'p7-source-map-terrain-20261010-git-publication-01',
    'p7-npc-owner-binding-20261010-ci':'p7-source-map-terrain-20261010-ci'}
records={}
for original,target in [('Dispatch-NpcOwnerGatewayCI.py','Dispatch-SourceTerrainGatewayCI.py'),
                        ('Record-NpcOwnerGatewayCI.py','Record-SourceTerrainGatewayCI.py')]:
    before=(directory/original).read_text()
    after=before
    for old,new in replacements.items():after=after.replace(old,new)
    path=directory/target
    assert not path.exists()
    path.write_text(after,encoding='utf-8')
    records[target]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'templateSha256':hashlib.sha256((directory/original).read_bytes()).hexdigest()}
out=Path('C:/mir2-build/p7-source-map-terrain-20261010-ci')
out.mkdir(exist_ok=False)
(out/'HELPERS-PREPARED.json').write_text(json.dumps({'source':source,'frozenClean':True,'runners':records},indent=2)+'\n')
print(json.dumps({'source':source,'frozenClean':True,'workflowSha256':hashlib.sha256((frozen/'.github/workflows/gateway-release.yml').read_bytes()).hexdigest()}))
