import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

source = '64b6b10c05732048da9c6bf5ccb0a491d2d053d3'
branch = 'codex/gateway-disconnect-lifecycle-20261008'
tag = '2026-10-10-source-terrain-64b6b10c05'
repo = Path('C:/Users/Administrator/.codex/worktrees/t64/mir2-player-journey')
receipt = Path('C:/mir2-build/p7-source-map-terrain-20261010-git-publication-01/exact-api/PUBLISHED-VERIFIED.json')
assert json.loads(receipt.read_bytes())['head'] == source
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-c', 'gc.auto=0',
    '-c', 'maintenance.auto=false', '-C', str(repo)]
assert subprocess.check_output(git + ['rev-parse', 'HEAD']).decode().strip() == source
assert not subprocess.check_output(git + ['status', '--porcelain']).strip()
out = Path('C:/mir2-build/p7-source-map-terrain-20261010-ci/server-ci-01')
out.mkdir(parents=True, exist_ok=False)
record = {'utc': datetime.now(timezone.utc).isoformat(), 'source': source, 'branch': branch,
    'releaseTag': tag, 'publicR2Upload': False, 'guardedRemoteReadback': source,
    'dispatchAttempts': 1,
    'workflowSha256': hashlib.sha256((repo / '.github/workflows/gateway-release.yml').read_bytes()).hexdigest()}
(out / 'DISPATCH-REQUEST.json').write_text(json.dumps(record, indent=2) + '\n')
cmd = ['gh', 'workflow', 'run', 'gateway-release.yml', '--repo', 'Zombieliu/mir2',
    '--ref', branch, '-f', 'release_tag=' + tag, '-F', 'publish_r2=false']
try:
    result = subprocess.run(cmd, capture_output=True, timeout=55)
    stdout, stderr, code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as failure:
    stdout, stderr, code = failure.stdout or b'', failure.stderr or b'', 124
(out / 'dispatch.stdout.log').write_bytes(stdout)
(out / 'dispatch.stderr.log').write_bytes(stderr)
summary = {'exitCode': code, 'utc': datetime.now(timezone.utc).isoformat(),
    'command': cmd, 'source': source, 'pipelineSuccessNotYetClaimed': True}
(out / 'DISPATCH-RESULT.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary))
if code:
    raise RuntimeError('Actual dispatch outcome retained; identify the run before any repeat')
