import ast, hashlib, json
from pathlib import Path

directory=Path('E:/mir2-player-journey/tmp')
original=directory/'Download-NpcOwnerLinuxCI.py'
target=directory/'Download-SourceTerrainLinuxCI.py'
assert not target.exists()
before=original.read_text()
after=before.replace("RUN='37993166469'", "RUN='38001876065'")
after=after.replace('01e3d08791c2639b3375c39d46fbf4f00ca53f75','64b6b10c05732048da9c6bf5ccb0a491d2d053d3')
after=after.replace('2026-10-10-npc-owner-01e3d08791','2026-10-10-source-terrain-64b6b10c05')
after=after.replace('p7-npc-owner-binding-20261010-ci','p7-source-map-terrain-20261010-ci')
after=after.replace('mir2.gateway.npc-owner-linux-ci.v1','mir2.gateway.source-terrain-linux-ci.v1')
needle="             'Package Gateway','Upload Gateway package'):"
assert after.count(needle)==1
after=after.replace(needle,"             'Verify bounded Source terrain and ordinary map collision',\n"+needle)
needle="receipt={'schema':"
assert after.count(needle)==1
after=after.replace(needle,"""for command in (b'--lib source_map_loading::tests',
                b'map::map_collision_source_tests:: deadmine_entrance_collision_parses_from_pack crystal_map_v0_'):
    assert command in raw_log,command.decode()
receipt={'schema':""")
def functions(text):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body
            if isinstance(n,ast.FunctionDef)}
assert functions(before)==functions(after), 'Every original validation helper must remain unchanged'
target.write_text(after,encoding='utf-8')
record={'source':'64b6b10c05732048da9c6bf5ccb0a491d2d053d3','runId':38001876065,
    'scriptSha256':hashlib.sha256(target.read_bytes()).hexdigest(),
    'originalVerifierSha256':hashlib.sha256(original.read_bytes()).hexdigest(),
    'originalValidationFunctionAstsUnchanged':True,'allOriginalGatesRetained':True,
    'newSourceTerrainGateRequired':True,'executed':False,'linuxPassed':False,
    'serverSwitched':False}
out=Path('C:/mir2-build/p7-source-map-terrain-20261010-ci')/'VERIFIER-PREPARED.json'
with out.open('x',encoding='utf-8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
