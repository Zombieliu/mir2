import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

out = Path('C:/mir2-build/p7-source-map-terrain-20261010-ci/server-ci-01')
request = json.loads((out / 'DISPATCH-REQUEST.json').read_bytes())
attempt = next(i for i in range(1, 100) if not (out / ('snapshot-%02d-runs.json' % i)).exists())
endpoint = 'repos/Zombieliu/mir2/actions/workflows/gateway-release.yml/runs?event=workflow_dispatch&branch=codex%2Fgateway-disconnect-lifecycle-20261008&per_page=10'
read = subprocess.run(['gh', 'api', '-H', 'Cache-Control: no-cache', endpoint], capture_output=True, timeout=55)
raw_path = out / ('snapshot-%02d-runs.json' % attempt)
raw_path.write_bytes(read.stdout)
raw_path.with_suffix('.stderr.log').write_bytes(read.stderr)
assert read.returncode == 0, 'Original API failure retained; no completion claim'
runs = [r for r in json.loads(read.stdout)['workflow_runs'] if r['head_sha'] == request['source']
    and r['event'] == 'workflow_dispatch' and r['head_branch'] == request['branch']
    and datetime.fromisoformat(r['created_at'].replace('Z', '+00:00')) >= datetime.fromisoformat(request['utc'])]
assert len(runs) == 1, 'Require unique actual dispatched source run'
run = runs[0]
record = {'utc': datetime.now(timezone.utc).isoformat(), 'runId': run['id'], 'source': run['head_sha'],
    'branch': run['head_branch'], 'status': run['status'], 'conclusion': run['conclusion'],
    'url': run['html_url'], 'rawSha256': hashlib.sha256(read.stdout).hexdigest(), 'rawPath': raw_path.name}
if not (out / 'RUN-IDENTIFIED.json').exists():
    with (out / 'RUN-IDENTIFIED.json').open('x', encoding='utf-8') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
jobs = subprocess.run(['gh', 'api', '-H', 'Cache-Control: no-cache',
    'repos/Zombieliu/mir2/actions/runs/' + str(run['id']) + '/jobs?per_page=100'], capture_output=True, timeout=55)
(out / ('snapshot-%02d-jobs.json' % attempt)).write_bytes(jobs.stdout)
(out / ('snapshot-%02d-jobs.stderr.log' % attempt)).write_bytes(jobs.stderr)
assert jobs.returncode == 0
record['jobs'] = [{key: job[key] for key in ('id', 'name', 'status', 'conclusion')}
    | {'currentStep': next((s['name'] for s in job['steps'] if s['status'] == 'in_progress'), None)}
    for job in json.loads(jobs.stdout)['jobs']]
with (out / ('snapshot-%02d.json' % attempt)).open('x', encoding='utf-8') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
