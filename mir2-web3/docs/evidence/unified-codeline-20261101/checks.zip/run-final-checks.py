from pathlib import Path
import subprocess,os,json,time,re,hashlib
c=Path('E:/mir2-release/unified-codeline-20261101');logs=c/'final-checks';logs.mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith('MIR2_')};env.update({'CARGO_TARGET_DIR':'C:/m2u-target/backend','CARGO_BUILD_JOBS':'2','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'1'})
steps=[('shared-zone-security',['cargo','test','--locked','--offline','-p','mir2-simulation','--test','shared_zone','--test','security_lifecycle','--','--test-threads=1','--nocapture']),('workspace-all-targets',['cargo','check','--locked','--offline','--workspace','--all-targets'])]
r={'schema':'mir2.unified.final-checks.v1','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'steps':[]}
for name,args in steps:
 print('START '+name,flush=True);p=logs/(name+'.log');start=time.monotonic()
 with p.open('w',encoding='utf-8') as out:result=subprocess.run(args,cwd='C:/m2u1101/mir2-web3',env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 data=p.read_text(encoding='utf-8',errors='replace');matches=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',data)
 row={'name':name,'command':args,'exitCode':result.returncode,'seconds':round(time.monotonic()-start,3),'passedTests':sum(int(x[1]) for x in matches),'failedTests':sum(int(x[2]) for x in matches),'ignoredTests':sum(int(x[3]) for x in matches),'logSha256':hashlib.sha256(p.read_bytes()).hexdigest()};r['steps'].append(row);r['passed']=all(x['exitCode']==0 for x in r['steps']);(logs/'validation.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(row),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
