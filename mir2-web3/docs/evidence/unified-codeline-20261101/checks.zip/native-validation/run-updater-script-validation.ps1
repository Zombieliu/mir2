$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$validationRoot='E:/mir2-release/unified-codeline-20261101/native-validation'
Set-Location -LiteralPath C:/m2u1101/mir2-web3
$env:TEMP="$validationRoot/tmp"
$env:TMP=$env:TEMP
$env:PYTHONDONTWRITEBYTECODE='1'
$groups=@(
  @{label='updater-archive-python';path='apps/game-client/windows-updater/scripts/test-archive-update-release.py'},
  @{label='updater-bootstrap-python';path='apps/game-client/windows-updater/scripts/test-bootstrap-installer.py'}
)
function Get-ScriptWitness {
  $witness=[ordered]@{}
  $files=@(& rg --files apps/game-client/windows-updater/scripts apps/game-client/platform-windows/scripts -g '*.py' -g '*.ps1' -g '*.json' -g '*.iss')
  if($LASTEXITCODE -ne 0){throw 'Could not enumerate scripts'}
  foreach($file in $files|Sort-Object -Unique){$witness[$file]=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()}
  return $witness
}
$results=@()
foreach($group in $groups){
  $label=$group.label
  $before=Get-ScriptWitness
  $before|ConvertTo-Json -Depth 3|Set-Content -LiteralPath "$validationRoot/$label-source-before.json" -Encoding utf8
  $started=[DateTime]::UtcNow
  & python -B $group.path *> "$validationRoot/$label.log"
  $exitCode=$LASTEXITCODE
  $after=Get-ScriptWitness
  $after|ConvertTo-Json -Depth 3|Set-Content -LiteralPath "$validationRoot/$label-source-after.json" -Encoding utf8
  $changed=@($before.Keys|Where-Object { -not $after.Contains($_) -or $before[$_] -ne $after[$_] })
  $changed+=@($after.Keys|Where-Object { -not $before.Contains($_) })
  $summaries=@(Select-String -LiteralPath "$validationRoot/$label.log" -Pattern '^Ran |^OK|^FAILED'|ForEach-Object {$_.Line})
  $result=[ordered]@{label=$label;command=@('python','-B',$group.path);startedAtUtc=$started.ToString('o');finishedAtUtc=[DateTime]::UtcNow.ToString('o');exitCode=$exitCode;sourceUnchangedDuringRun=($changed.Count -eq 0);changedSources=$changed;testSummaries=$summaries;logSha256=(Get-FileHash -LiteralPath "$validationRoot/$label.log" -Algorithm SHA256).Hash.ToLowerInvariant()}
  $result|ConvertTo-Json -Depth 6|Set-Content -LiteralPath "$validationRoot/$label.json" -Encoding utf8
  $results+=$result
  $result|ConvertTo-Json -Depth 4 -Compress|Write-Output
}
$results|ConvertTo-Json -Depth 6|Set-Content -LiteralPath "$validationRoot/updater-scripts-summary.json" -Encoding utf8
if(@($results|Where-Object {$_.exitCode -ne 0 -or -not $_.sourceUnchangedDuringRun}).Count -gt 0){exit 1}
