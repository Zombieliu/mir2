$ErrorActionPreference='Stop'
$validationRoot='E:/mir2-release/unified-codeline-20261101/native-validation'
Set-Location -LiteralPath C:/m2u1101/mir2-web3
$cargoLabels=@('updater-lib','native-chat','native-npc','native-transport','native-pointer','native-billing','native-session','shared-gate','shared-shop','runtime-npc','runtime-economy')
$pythonLabels=@('updater-archive-python','updater-bootstrap-python')
$rows=@()
foreach($label in $cargoLabels+$pythonLabels){
  $record=Get-Content -Raw -LiteralPath "$validationRoot/$label.json"|ConvertFrom-Json
  $passed=0
  $failed=0
  $unexecuted=0
  foreach($line in $record.testSummaries){
    if($line -match '(\d+) passed; (\d+) failed; (\d+) ignored'){$passed+=[int]$Matches[1];$failed+=[int]$Matches[2];$unexecuted+=[int]$Matches[3]}
  }
  if($label -in $pythonLabels){
    $ran=0
    foreach($line in $record.testSummaries){if($line -match '^Ran (\d+) tests'){$ran=[int]$Matches[1]};if($line -match 'skipped=(\d+)'){$unexecuted=[int]$Matches[1]}}
    $passed=$ran-$unexecuted
  }
  $rows+=[ordered]@{label=$label;passed=$passed;failed=$failed;unexecuted=$unexecuted;exitCode=$record.exitCode;sourceUnchangedDuringRun=$record.sourceUnchangedDuringRun;logSha256=$record.logSha256}
}
$lastWitness=Get-Content -Raw -LiteralPath "$validationRoot/runtime-economy-source-after.json"|ConvertFrom-Json
$currentWitness=[ordered]@{}
$changed=@()
foreach($property in $lastWitness.PSObject.Properties){
  if(-not(Test-Path -LiteralPath $property.Name -PathType Leaf)){$changed+=$property.Name;continue}
  $currentWitness[$property.Name]=(Get-FileHash -LiteralPath $property.Name -Algorithm SHA256).Hash.ToLowerInvariant()
  if($property.Value -ne $currentWitness[$property.Name]){$changed+=$property.Name}
}
$sourceDirs=@('apps/game-client/client-core/src','apps/game-client/client-wire/src','apps/game-client/client-bevy/src','apps/game-client/runtime/src','apps/game-client/platform-windows/src','apps/game-client/windows-updater/src','apps/game-client/ui-core/src','apps/game-client/resource-pack/src','apps/game-client/crystal-gdi-text/src','packages/game-data/src','packages/protocol/src')
$found=@(& rg --files @sourceDirs -g '*.rs' -g '*.json' -g '*.toml')
if($LASTEXITCODE -ne 0){throw 'Could not enumerate focused source paths'}
$additional=@($found|Where-Object {-not $currentWitness.Contains($_)})
$currentWitness|ConvertTo-Json -Depth 3|Set-Content -LiteralPath "$validationRoot/current-source.json" -Encoding utf8
$baselineHash=(Get-FileHash -LiteralPath "$validationRoot/updater-lib-source-before.json" -Algorithm SHA256).Hash
$witnessesIdentical=$true
foreach($label in $cargoLabels){foreach($phase in @('before','after')){if((Get-FileHash -LiteralPath "$validationRoot/$label-source-$phase.json" -Algorithm SHA256).Hash -ne $baselineHash){$witnessesIdentical=$false}}}
$totalPassed=0
$totalFailed=0
$totalUnexecuted=0
foreach($row in $rows){$totalPassed+=$row.passed;$totalFailed+=$row.failed;$totalUnexecuted+=$row.unexecuted}
$summary=[ordered]@{
 schema='mir2.unified-codeline.native-focused-validation.v1'
 generatedAtUtc=[DateTime]::UtcNow.ToString('o')
 sourceRoot='C:/m2u1101/mir2-web3'
 compiler='Rust 1.95.0, --locked --offline'
 target='E:/mir2-release/windows-ui-shop-pointer-20261101/test-target'
 groups=$rows
 totalPassed=$totalPassed
 totalFailed=$totalFailed
 totalUnexecuted=$totalUnexecuted
 allGroupExitCodesZero=(@($rows|Where-Object {$_.exitCode -ne 0}).Count -eq 0)
 allSourcesStableDuringGroups=(@($rows|Where-Object {-not $_.sourceUnchangedDuringRun}).Count -eq 0)
 allCargoBoundarySourceWitnessesIdentical=$witnessesIdentical
 currentSourceMatchesFinalWitness=($changed.Count -eq 0 -and $additional.Count -eq 0)
 changedSinceFinalGroup=$changed
 additionalSourcePaths=$additional
 currentSourceSha256=(Get-FileHash -LiteralPath "$validationRoot/current-source.json" -Algorithm SHA256).Hash.ToLowerInvariant()
 limitations=@('No ignored GPU render fixture was run.','Real pinned-CMS and installed-package ignored fixtures were not run.','No real account, network transaction, complete installer build or public deployment was performed.','The initial Windows PowerShell 5 harness stopped on a normal cargo stderr line before tests; its log is retained, and the successful runs use PowerShell 7.')
}
$summary|ConvertTo-Json -Depth 6|Set-Content -LiteralPath "$validationRoot/summary.json" -Encoding utf8
$summary|ConvertTo-Json -Depth 4 -Compress|Write-Output
