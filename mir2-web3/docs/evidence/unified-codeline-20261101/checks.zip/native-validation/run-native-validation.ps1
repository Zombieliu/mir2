param([string]$Only='')
$ErrorActionPreference='Stop'
$PSNativeCommandUseErrorActionPreference=$false
$validationRoot='E:/mir2-release/unified-codeline-20261101/native-validation'
$projectRoot='C:/m2u1101/mir2-web3'
Set-Location -LiteralPath $projectRoot
$env:CARGO_TARGET_DIR='E:/mir2-release/windows-ui-shop-pointer-20261101/test-target'
$env:CARGO_BUILD_JOBS='4'
$env:CARGO_INCREMENTAL='0'
$env:CARGO_PROFILE_DEV_DEBUG='0'
$env:CARGO_PROFILE_TEST_DEBUG='0'
$env:TEMP="$validationRoot/tmp"
$env:TMP=$env:TEMP
$env:PYTHONDONTWRITEBYTECODE='1'
New-Item -ItemType Directory -Force -Path $env:TEMP | Out-Null
$nativeManifest='apps/game-client/platform-windows/Cargo.toml'
$sharedManifest='apps/game-client/client-bevy/Cargo.toml'
$updaterManifest='apps/game-client/windows-updater/Cargo.toml'
$groups=@(
  @{label='updater-lib';manifest=$updaterManifest;opts=@('--lib');filter=''},
  @{label='native-chat';manifest=$nativeManifest;opts=@('--bin','mir2-platform-windows');filter='native_chat_pointer'},
  @{label='native-npc';manifest=$nativeManifest;opts=@('--bin','mir2-platform-windows');filter='native_npc_buysell'},
  @{label='native-transport';manifest=$nativeManifest;opts=@('--bin','mir2-platform-windows');filter='npc_gold_buy_transport_tests'},
  @{label='native-pointer';manifest=$nativeManifest;opts=@('--bin','mir2-platform-windows');filter='input::tests::native_'},
  @{label='native-billing';manifest=$nativeManifest;opts=@('--bin','mir2-platform-windows');filter='billing_browser::tests'},
  @{label='native-session';manifest=$nativeManifest;opts=@('--bin','mir2-platform-windows');filter='session_config::tests'},
  @{label='shared-gate';manifest=$sharedManifest;opts=@('--features','native-ui','--lib');filter='npc_gold_buy_attempt::tests'},
  @{label='shared-shop';manifest=$sharedManifest;opts=@('--features','native-ui','--lib');filter='npc_shop'},
  @{label='runtime-npc';manifest=$nativeManifest;opts=@('--package','mir2-bevy-runtime','--lib');filter='native_npc_buysell'},
  @{label='runtime-economy';manifest=$nativeManifest;opts=@('--package','mir2-bevy-runtime','--lib');filter='npc_purchase_economy'}
)
function Get-SourceWitness {
  $witness=[ordered]@{}
  $sourceDirs=@('apps/game-client/client-core/src','apps/game-client/client-wire/src','apps/game-client/client-bevy/src','apps/game-client/runtime/src','apps/game-client/platform-windows/src','apps/game-client/windows-updater/src','apps/game-client/ui-core/src','apps/game-client/resource-pack/src','apps/game-client/crystal-gdi-text/src','packages/game-data/src','packages/protocol/src')
  $files=@(& rg --files @sourceDirs -g '*.rs' -g '*.json' -g '*.toml')
  if($LASTEXITCODE -ne 0){throw 'Could not enumerate focused source inputs'}
  foreach($dir in @('client-core','client-wire','client-bevy','runtime','platform-windows','windows-updater','ui-core','resource-pack','crystal-gdi-text')){
    foreach($name in @('Cargo.toml','Cargo.lock','build.rs')){
      $path="apps/game-client/$dir/$name"
      if(Test-Path -LiteralPath $path -PathType Leaf){$files+=$path}
    }
  }
  $files+=@('packages/game-data/Cargo.toml','packages/protocol/Cargo.toml')
  foreach($file in $files | Sort-Object -Unique){$witness[$file]=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()}
  return $witness
}
$results=@()
foreach($group in $groups){
  if($Only -and $Only -ne $group.label){continue}
  $label=$group.label
  $log="$validationRoot/$label.log"
  $before=Get-SourceWitness
  $before|ConvertTo-Json -Depth 3|Set-Content -LiteralPath "$validationRoot/$label-source-before.json" -Encoding utf8
  $argsList=@('+1.95.0','test','--locked','--offline','--manifest-path',$group.manifest)+$group.opts
  if($group.filter){$argsList+=$group.filter}
  $argsList+=@('--','--test-threads=1','--nocapture')
  $started=[DateTime]::UtcNow
  & cargo @argsList *> $log
  $exitCode=$LASTEXITCODE
  $after=Get-SourceWitness
  $after|ConvertTo-Json -Depth 3|Set-Content -LiteralPath "$validationRoot/$label-source-after.json" -Encoding utf8
  $changed=@($before.Keys | Where-Object { -not $after.Contains($_) -or $before[$_] -ne $after[$_] })
  $changed+=@($after.Keys | Where-Object { -not $before.Contains($_) })
  $testSummaries=@(Select-String -LiteralPath $log -Pattern '^test result:' | ForEach-Object {$_.Line})
  $result=[ordered]@{label=$label;command=@('cargo')+$argsList;startedAtUtc=$started.ToString('o');finishedAtUtc=[DateTime]::UtcNow.ToString('o');exitCode=$exitCode;sourceUnchangedDuringRun=($changed.Count -eq 0);changedSources=$changed;testSummaries=$testSummaries;logSha256=(Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash.ToLowerInvariant();target=$env:CARGO_TARGET_DIR}
  $result|ConvertTo-Json -Depth 6|Set-Content -LiteralPath "$validationRoot/$label.json" -Encoding utf8
  $results+=$result
  $result|ConvertTo-Json -Depth 4 -Compress|Write-Output
}
$results|ConvertTo-Json -Depth 6|Set-Content -LiteralPath "$validationRoot/run-summary.json" -Encoding utf8
if(@($results | Where-Object {$_.exitCode -ne 0 -or -not $_.sourceUnchangedDuringRun}).Count -gt 0){exit 1}
