from pathlib import Path
import subprocess,os,json,re,time,datetime,hashlib
root=Path('C:/m2u1101'); project=root/'mir2-web3'; control=Path('E:/mir2-release/unified-codeline-20261101'); logs=control/'postgres-validation'; logs.mkdir(exist_ok=True)
pg=json.loads((control/'isolated-pg.json').read_text()); assert pg['port']!=5432
from urllib.parse import urlsplit
for uri in pg['urls'].values():
 u=urlsplit(uri); assert u.hostname=='127.0.0.1' and u.port==pg['port'] and u.path.startswith('/mir2_') and not u.query
# Fence fixtures require an independently provisioned public lease relation.
with (logs/'provision-public-lease.log').open('w',encoding='utf-8') as out:
 subprocess.run([str(Path(pg['pgBin'])/'psql.exe'),pg['urls']['zone'],'-X','-v','ON_ERROR_STOP=1','-f',str(project/'infra/postgres/migrations/0003_zone_owner_leases.sql')],stdout=out,stderr=subprocess.STDOUT,check=True,creationflags=subprocess.CREATE_NO_WINDOW)
env={k:v for k,v in os.environ.items() if not k.startswith('MIR2_')}
env.update({'CARGO_TARGET_DIR':'C:/m2u-target/backend','CARGO_BUILD_JOBS':'2','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','RUST_TEST_THREADS':'1','MIR2_WALLET_TEST_ISOLATED':'1','MIR2_WALLET_TEST_DATABASE_URL':pg['urls']['wallet'],'MIR2_RUN_PROMOTION_PG_TESTS':'1','MIR2_PROMOTION_TEST_DATABASE_URL':pg['urls']['promotion'],'MIR2_TEST_ZONE_SAVE_FENCE_URL':pg['urls']['zone'],'MIR2_TEST_ZONE_SAVE_OPERATION_URL':pg['urls']['zone'],'MIR2_GUILD_TEST_DATABASE_URL':pg['urls']['guild'],'MIR2_PROMOTION_ENVIRONMENT':'test'})
cargo=['cargo','test','--locked','--offline']
groups=[
 ('billing-and-native-pg',cargo+['-p','mir2-simulation','--test','promotion_backend_compat','--test','sui_usdc_native_transfer_postgres','--test','promotion_full_monthly_policy','--test','billing_recharge','--test','sui_usdc_provenance','--','--test-threads=1','--nocapture']),
 ('wallet-native-pg',cargo+['-p','mir2-simulation','--test','wallet_postgres','--','--ignored','--test-threads=1','--nocapture']),
 ('simulation-zone-save-pg',cargo+['-p','mir2-simulation','--lib','zone_save_','--','--test-threads=1','--nocapture']),
 ('gateway-zone-save-pg',cargo+['-p','mir2-gateway','--lib','zone_save_','--','--test-threads=1','--nocapture']),
 ('mail-transfer-pg',cargo+['-p','mir2-gateway','--lib','mail_transfer_pg_tests','--','--ignored','--test-threads=1','--nocapture']),
 ('shared-uid-pg',cargo+['-p','mir2-gateway','--lib','shared_uid_pg_tests','--','--ignored','--test-threads=1','--nocapture']),
 ('prepared-kill-pg',cargo+['-p','mir2-gateway','--lib','prepared_kill_postgres','--','--ignored','--test-threads=1','--nocapture']),
 ('shared-zone-security',cargo+['-p','mir2-simulation','--test','shared_zone','--test','security_lifecycle','--','--test-threads=1','--nocapture']),
]
record={'schema':'mir2.unified.postgres-validation.v1','startedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRoot':str(root),'headAtStart':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'isolation':{'newDataDirectory':pg['data'],'loopback':'127.0.0.1','port':pg['port'],'databases':pg['databases'],'dockerUsed':False,'oldDatabaseUsed':False,'remoteDatabaseUsed':False},'groups':[]}
previous=logs/'validation.json'
if previous.exists():
 old=json.loads(previous.read_text()); record['groups']=old['groups']; record['attempts']=old.get('attempts',old['groups'].copy()); record['isolation']['databases']=pg['databases']
else: record['attempts']=[]
for name,args in groups:
 if any(row['name']==name and row['passedGate'] for row in record['groups']): continue
 attempt=1+sum(row['name']==name for row in record['attempts'])
 log=logs/(name+f'.attempt-{attempt:02}.log'); begin=time.monotonic(); print('START '+name,flush=True)
 with log.open('w',encoding='utf-8') as out:
  p=subprocess.run(args,cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 data=log.read_text(encoding='utf-8',errors='replace')
 rows=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',data)
 counts={key:sum(int(row[i]) for row in rows) for key,i in [('passed',1),('failed',2),('ignored',3)]}
 skipped=bool(re.search(r'\bSKIPPED[: ]',data))
 item={'name':name,'command':args,'exitCode':p.returncode,'seconds':round(time.monotonic()-begin,3),'log':str(log),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),**counts,'unexpectedSkipMessage':skipped,'passedGate':p.returncode==0 and counts['passed']>0 and counts['failed']==0 and not skipped}
 record['attempts'].append(item); record['groups']=[r for r in record['groups'] if r['name']!=name]+[item]; record['passed']=len(record['groups'])==len(groups) and all(r['passedGate'] for r in record['groups']); (logs/'validation.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(item),flush=True)
 if not item['passedGate']: raise SystemExit(1)
print('ALL GROUPS COMPLETE',flush=True)
