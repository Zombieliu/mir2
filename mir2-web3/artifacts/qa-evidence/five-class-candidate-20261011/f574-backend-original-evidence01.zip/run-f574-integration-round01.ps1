$ErrorActionPreference='Stop'
$review=Join-Path $PSScriptRoot 'f574-fiveclass-backend-review02.json'
foreach($target in @('periodic_quests','quest_icons','quest_agent_special_scripts')){
 $id='f574-integration-'+$target+'01'
 $log=Join-Path $PSScriptRoot ($id+'-runner.log')
 if(Test-Path -LiteralPath $log){throw 'Preserve historical actual run.'}
 & pwsh -NoProfile -File (Join-Path $PSScriptRoot 'run-guarded-integration-check.ps1') -CheckId $id -ReviewPath $review -Package mir2-simulation -Scope simulation -TestTarget $target *> $log
 $code=$LASTEXITCODE
 Write-Host ($id+': actual wrapper exit '+$code)
 if($code-ne0){throw ('Actual guarded integration failed: '+$id)}
 $result=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($id+'/result.json')) -Raw | ConvertFrom-Json
 if($result.exitCode-ne0 -or @($result.sourceDrift).Count-ne0){throw 'Actual integration result/source mismatch.'}
 $line=@(Select-String -LiteralPath (Join-Path $PSScriptRoot ($id+'/cargo.log')) -Pattern '^test result:')
 if($line.Count-ne1 -or $line[0].Line-match '^test result: ok\. 0 passed;'){throw 'Empty or ambiguous real integration.'}
 Write-Host $line[0].Line
}
