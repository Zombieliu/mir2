param(
    [Parameter(Mandatory=$true)][string]$CheckId,
    [Parameter(Mandatory=$true)][string]$ReviewPath,
    [Parameter(Mandatory=$true)][string]$Package,
    [ValidateSet('game-data','simulation','gateway','native')][string]$Scope='game-data',
    [string]$Filter='',
    [Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9_]{1,64}$')][string]$TestTarget,
    [ValidateSet('test','check','build')][string]$Action='test',
    [string]$TargetDirectory='C:/mir2-build/shared-classic-target',
    [switch]$Release,
    [switch]$Lib
)
$ErrorActionPreference='Stop'
$taskRepo=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../..')).Path
$taskProject=Join-Path $taskRepo 'mir2-web3'
$taskUtf8=[Text.UTF8Encoding]::new($false)
# Select exactly one ordinary integration source without compiling every target.
# Original CargoGuard, disk budget, PolicyB, snapshots and receipts stay intact.
$taskIntegrationPackages=@{'simulation'='mir2-simulation';'gateway'='mir2-gateway'}
if($Action -ne 'test' -or $Lib -or -not $taskIntegrationPackages.ContainsKey($Scope) -or $taskIntegrationPackages[$Scope] -ne $Package){throw 'Integration scope/package/action mismatch.'}
$taskIntegrationSource=Join-Path $taskProject ('apps/'+$Scope+'/tests/'+$TestTarget+'.rs')
if(-not (Test-Path -LiteralPath $taskIntegrationSource -PathType Leaf)){throw 'Ordinary integration test source is missing.'}
function Write-TaskJson([string]$Path,$Value){[IO.File]::WriteAllText($Path,($Value | ConvertTo-Json -Depth 16),$taskUtf8)}
function Hash-TaskFile([string]$Path){(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
$taskReview=Get-Content -LiteralPath $ReviewPath -Raw | ConvertFrom-Json
if($taskReview.acceptedForFocusedTests -ne $true){throw 'Independent source review has not accepted focused tests.'}
foreach($taskRow in $taskReview.scope){if((Hash-TaskFile (Join-Path $taskRepo $taskRow.path)) -ne $taskRow.sha256){throw "Reviewed source drift: $($taskRow.path)"}}
if(@(Get-Process cargo,rustc -ErrorAction SilentlyContinue).Count -gt 0){throw 'Another Cargo/rustc invocation is active; keep Cargo serial.'}
$taskCheck=Join-Path $PSScriptRoot $CheckId
if(Test-Path -LiteralPath $taskCheck){throw 'Check ID already exists; preserve historical runs.'}
$null=New-Item -ItemType Directory -Path $taskCheck
$taskReceiptRoot=Join-Path $taskCheck 'cargo-receipts'
$null=New-Item -ItemType Directory -Path $taskReceiptRoot
$taskSourcePaths=@('mir2-web3/Cargo.toml','mir2-web3/Cargo.lock','mir2-web3/rust-toolchain.toml')
$taskDirs=@('packages/game-data','packages/protocol')
if($Scope -in @('simulation','gateway')){$taskDirs+=@('apps/simulation','config/quest-guidance','packages/production')}
if($Scope -eq 'gateway'){$taskDirs+=@('apps/gateway','packages/accounts','packages/identity','packages/storage')}
if($Scope -eq 'native'){$taskDirs+=@('apps/game-client','packages/assets','packages/client','packages/audio')}
foreach($taskRelative in $taskDirs){
    $taskDir=Join-Path $taskProject $taskRelative
    if(Test-Path -LiteralPath $taskDir){$taskSourcePaths+=@(Get-ChildItem -LiteralPath $taskDir -Recurse -File | Where-Object {$_.Extension -in @('.rs','.json','.gz') -or $_.Name -in @('Cargo.toml','Cargo.lock')} | ForEach-Object {$_.FullName.Substring($taskRepo.Length+1).Replace('\','/')})}
}
foreach($taskConfig in @('.cargo/config.toml','mir2-web3/.cargo/config.toml')){if(Test-Path -LiteralPath (Join-Path $taskRepo $taskConfig)){$taskSourcePaths+=$taskConfig}}
$taskRows=@($taskSourcePaths | Sort-Object -Unique | ForEach-Object {[ordered]@{path=$_;sha256=(Hash-TaskFile (Join-Path $taskRepo $_));length=(Get-Item -LiteralPath (Join-Path $taskRepo $_)).Length}})
$taskSnapshotPath=Join-Path $taskCheck 'source-snapshot.json'
Write-TaskJson $taskSnapshotPath ([ordered]@{schema='mir2.five-class-source.v1';scope=$Scope;createdUtc=[DateTime]::UtcNow.ToString('o');files=$taskRows})
$taskSnapshotSha=Hash-TaskFile $taskSnapshotPath
$taskGuardRoot='C:/mir2-cross-platform-storage-20261002/repo-qa-shared-quest-heading-locale-01/cargo-per-call-guard-implementation01'
$taskTemplatePath='C:/mir2-cross-platform-storage-20261002/repo-qa-web-windows-catchup-20261006-01/w0-transport-source37-native-transport-test01.policy.json'
$taskPolicy=Get-Content -LiteralPath $taskTemplatePath -Raw | ConvertFrom-Json
foreach($taskPair in @(@($taskPolicy.guardSourcePath,$taskPolicy.guardSourceSha),@((Join-Path $taskGuardRoot 'CargoGuard.exe'),$taskPolicy.guardExeSha),@($taskPolicy.calleePath,$taskPolicy.calleeSha),@($taskPolicy.probePath,$taskPolicy.probeSha))){if((Hash-TaskFile $taskPair[0]) -ne $taskPair[1]){throw "Existing independently reviewed guard dependency changed: $($taskPair[0])"}}
$taskAuthorityPath=Join-Path $taskCheck 'root-authority.json'
Write-TaskJson $taskAuthorityPath ([ordered]@{owner='Root';allowRealCargo='true';guardExeSha=$taskPolicy.guardExeSha;guardSourceSha=$taskPolicy.guardSourceSha;sourceSnapshotSha=$taskSnapshotSha;calleeSha=$taskPolicy.calleeSha;probeSha=$taskPolicy.probeSha;independentShimReviewAccepted='true'})
$taskAcceptancePath=Join-Path $taskCheck 'source-acceptance.json'
Write-TaskJson $taskAcceptancePath ([ordered]@{sourceAccepted=$true;independentReviewAccepted=$true;sourceSnapshot=@{sha256=$taskSnapshotSha};independentSourceReview=@{path=$ReviewPath;sha256=(Hash-TaskFile $ReviewPath)};scope="Bounded five-class $Scope source reviewed for focused $Action. Test execution is not native or public acceptance."})
$taskPolicy.rootAuthorityPath=$taskAuthorityPath;$taskPolicy.rootAuthoritySha=Hash-TaskFile $taskAuthorityPath
$taskPolicy.sourceAcceptancePath=$taskAcceptancePath;$taskPolicy.sourceAcceptanceSha=Hash-TaskFile $taskAcceptancePath
$taskPolicy.sourceSnapshotPath=$taskSnapshotPath;$taskPolicy.sourceSnapshotSha=$taskSnapshotSha;$taskPolicy.receiptRoot=$taskReceiptRoot
$taskPolicyPath=Join-Path $taskCheck 'guard-policy.json'
Write-TaskJson $taskPolicyPath $taskPolicy
$taskEnvNames=@('QA_CARGO_GUARD_POLICY','QA_CARGO_GUARD_POLICY_SHA256','CARGO_TARGET_DIR','CARGO_INCREMENTAL','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_TERM_COLOR','RUST_MIN_STACK','RUST_TEST_THREADS')
$taskOldEnv=@{};foreach($taskName in $taskEnvNames){$taskOldEnv[$taskName]=[Environment]::GetEnvironmentVariable($taskName,'Process')}
$taskArgv=@('+1.95.0',$Action,'-p',$Package,'--locked','--offline','--jobs','1')
# Native crates have their own manifests outside the main Cargo workspace.
# Resolve only the four declared local packages; keep the original guard and
# its disk/freshness/PolicyB budgets unchanged.
if($Scope -eq 'native') {
    $taskNativeManifests=@{
        'mir2-bevy-runtime'='apps/game-client/runtime/Cargo.toml'
        'mir2-client-bevy'='apps/game-client/client-bevy/Cargo.toml'
        'mir2-platform-windows'='apps/game-client/platform-windows/Cargo.toml'
        'mir2-windows-updater'='apps/game-client/windows-updater/Cargo.toml'
    }
    if(-not $taskNativeManifests.ContainsKey($Package)){throw 'Native package has no declared manifest.'}
    $taskArgv+=@('--manifest-path',(Join-Path $taskProject $taskNativeManifests[$Package]))
    if($Package -eq 'mir2-client-bevy'){$taskArgv+=@('--features','native-ui')}
}
if($Lib){$taskArgv+='--lib'}
$taskArgv+=@('--test',$TestTarget)
if($Release){$taskArgv+='--release'}
if($Filter){$taskArgv+=$Filter}
if($Action -eq 'test'){$taskArgv+=@('--','--test-threads=1')}
$taskStart=[DateTime]::UtcNow;$taskExit=$null
try {
    $env:QA_CARGO_GUARD_POLICY=$taskPolicyPath;$env:QA_CARGO_GUARD_POLICY_SHA256=Hash-TaskFile $taskPolicyPath
    $env:CARGO_TARGET_DIR=$TargetDirectory;$env:CARGO_INCREMENTAL='0';$env:CARGO_BUILD_JOBS='1';$env:CARGO_NET_OFFLINE='true';$env:CARGO_TERM_COLOR='never';$env:RUST_MIN_STACK='67108864';$env:RUST_TEST_THREADS='1'
    Push-Location -LiteralPath $taskProject
    try {& (Join-Path $taskGuardRoot 'CargoGuard.exe') @taskArgv 2>&1 | Tee-Object -FilePath (Join-Path $taskCheck 'cargo.log');$taskExit=$LASTEXITCODE}finally{Pop-Location}
}finally{foreach($taskName in $taskEnvNames){[Environment]::SetEnvironmentVariable($taskName,$taskOldEnv[$taskName],'Process')}}
$taskDrift=@($taskRows | Where-Object {(Hash-TaskFile (Join-Path $taskRepo $_.path)) -ne $_.sha256})
$taskSummary=[ordered]@{schema='mir2.five-class-check.v1';scope=$Scope;startedUtc=$taskStart.ToString('o');finishedUtc=[DateTime]::UtcNow.ToString('o');exitCode=$taskExit;argv=$taskArgv;sourceSnapshotSha256=$taskSnapshotSha;declaredInputs=$taskRows.Count;sourceDrift=$taskDrift;cargoLogSha256=(Hash-TaskFile (Join-Path $taskCheck 'cargo.log'));gameStarted=$false;gatewayRestarted=$false}
Write-TaskJson (Join-Path $taskCheck 'result.json') $taskSummary
$taskSummary | ConvertTo-Json -Depth 8
if($taskExit -ne 0 -or $taskDrift.Count -gt 0){exit 1}
