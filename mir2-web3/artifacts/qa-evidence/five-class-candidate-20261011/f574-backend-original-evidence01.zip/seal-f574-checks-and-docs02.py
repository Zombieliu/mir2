from pathlib import Path
import json,hashlib,re,zipfile,subprocess
from datetime import datetime,timezone
work=Path(__file__).resolve().parent
root=work.parent.parent
project=root/'mir2-web3'
sha=lambda b:hashlib.sha256(b).hexdigest()
review_path=work/'f574-actual-snapshot-binding-review01.json'
original_review_path=work/'f574-fiveclass-backend-review02.json'
review=json.loads(review_path.read_text(encoding='utf-8-sig'))
assert review['acceptedForFocusedTests'] is True
assert review['acceptedAsActualCapturedRustRegressionEvidence'] is True
assert review['acceptedAsCompleteGatewayCompiledInputSnapshotClosure'] is False
assert review['actualCheckCount']==14
original_review=json.loads(original_review_path.read_text(encoding='utf-8-sig'))
assert review['scope']==original_review['sourceScope']
for row in review['scope']:
 data=(root/row['path']).read_bytes()
 assert sha(data)==row['sha256'] and len(data)==row['length'],row['path']
dirs=sorted(p for p in work.iterdir() if p.is_dir() and p.name.startswith('f574-') and p.name.endswith('01'))
assert len(dirs)==14
checks=[]
distinct=set()
passed_total=ignored_total=0
for directory in dirs:
 result_path=directory/'result.json'
 result=json.loads(result_path.read_text(encoding='utf-8-sig'))
 assert result['exitCode']==0 and result['sourceDrift']==[]
 log_path=directory/'cargo.log'
 data=log_path.read_bytes()
 assert sha(data)==result['cargoLogSha256']
 text=data.decode('utf-8-sig')
 matches=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
 assert len(matches)==1
 passed,failed,ignored=map(int,matches[0])
 assert passed>0 and failed==0
 names=re.findall(r'^test (\S+) \.\.\. ok\r?$',text,re.M)
 assert len(names)==passed,(directory.name,len(names),passed)
 args=result['argv']
 package=args[args.index('-p')+1]
 target=args[args.index('--test')+1] if '--test' in args else 'lib'
 for name in names:distinct.add(f'{package}:{target}:{name}')
 passed_total+=passed;ignored_total+=ignored
 checks.append({'id':directory.name,'package':package,'target':target,'passed':passed,'failed':0,'ignored':ignored,'actualExitCode':0,'argv':args,'sourceDrift':[],'resultSha256':sha(result_path.read_bytes()),'cargoLogSha256':sha(data),'testNames':names,'startedUtc':result['startedUtc'],'finishedUtc':result['finishedUtc']})
assert ignored_total==1
assert passed_total==review['actualPassedExecutionsWithOverlaps']==789
assert len(distinct)==review['actualDistinctPassingPackageTargetNames']==779
artifact=project/'artifacts/qa-evidence/five-class-candidate-20261011'
artifact.mkdir(parents=True,exist_ok=True)
archive_path=artifact/'f574-backend-original-evidence01.zip'
assert not archive_path.exists()
files=[]
for d in dirs:files+=list(p for p in d.rglob('*') if p.is_file())
files += [work/n for n in ['f574-fiveclass-backend-freeze01.json','f574-fiveclass-backend-freeze02.json','f574-fiveclass-backend-freeze03.json','f574-fiveclass-backend-review02.json','f574-actual-snapshot-binding-review01.json','seal-f574-checks-and-docs01.py','seal-f574-checks-and-docs02.py','live-gateway-merge-proof01.json','vis01-test-only-repair-proof01.json','vis01-test-only-repair-proof02.json','web-before-vis01-fix01.rs','web-before-vis01-fix02.rs','fix-vis01-gateway-test01.py','fix-vis01-gateway-test02.py','run-f574-check-round01.ps1','run-f574-check-round02.ps1','run-f574-integration-round01.ps1','run-guarded-check.ps1','run-guarded-integration-check.ps1']]
old_work=Path('C:/Users/Administrator/.codex/worktrees/five-class-completion/mir2-player-journey/work/fiveclass-20261010')
with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for path in sorted(set(files)):z.write(path,str(path.relative_to(work)).replace('\\','/'))
 z.write(old_work/'gateway-02457-linux-failed01.log','original-failed-ci/gateway-02457-linux-failed01.log')
summary={'schema':'mir2.five-class.f574-merged-checks.v1','createdUtc':datetime.now(timezone.utc).isoformat(),'clientEngineSource':'02457be9afbb6e836e4c89b2aae5fd55954e77a8','gatewayMergeParents':['02457be9afbb6e836e4c89b2aae5fd55954e77a8','f574d214a10c7efd62176ec94cea37821095b8fe'],'gatewayCommittedSourcePending':True,'sourceReviewSha256':sha(original_review_path.read_bytes()),'actualSnapshotBindingReviewSha256':sha(review_path.read_bytes()),'actualCapturedRustRegressionEvidenceAccepted':True,'completeGatewayCompiledInputSnapshotClosureAccepted':False,'originalQaScopeLoopExecutedRows':0,'fixtureCoverageGap':review['fixtureCoverageGap'],'reviewedPaths':len(review['scope']),'actualCheckCount':len(checks),'actualPassedExecutionsWithOverlaps':passed_total,'actualDistinctPassingNames':len(distinct),'actualFailedTests':0,'originalIgnoredChecks':ignored_total,'ignoredScope':'Only the original isolated PostgreSQL periodic quest fixture; unchanged Linux workflow remains required.','checks':checks,'originalEvidenceArchiveSha256':sha(archive_path.read_bytes()),'retainedFailedCi':{'runId':38185310159,'source':'02457be9afbb6e836e4c89b2aae5fd55954e77a8','passed':291,'failed':1,'pathInArchive':'original-failed-ci/gateway-02457-linux-failed01.log'},'retainedCoordinatorDiagnostic':'Initial QA coordinator wrongly matched trailing 0 passed in 300 passed after real NPC Cargo0; original script remains. Anchored-zero parser fixed only in resume02; no product test or assertion was changed or rerun to waive failure.','vis01TestOnlyChangedCharacters':2,'gatewayProductSerializerAndType1Type2Unchanged':True,'fullType1ParityAccepted':False,'actualNativeCiRun':38185307238,'actualNativeCiSource':'02457be9afbb6e836e4c89b2aae5fd55954e77a8','actualNativeTests':{'passed':987,'failed':0,'originalIgnored':7,'defaultParallel':True},'currentMergedLinuxCiPending':True,'signedR26PackagePending':True,'published':False,'humanAcceptance':False,'wholeCandidate100':False}
(artifact/'f574-backend-checks01.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
doc=project/'docs/FIVE-CLASS-LIVE-NPC-MERGE-20261012.md'
assert not doc.exists()
doc.write_text(f'''# Five-class and live NPC merge — 2026-10-12

The separate Gateway worktree merges the current live f574 ordinary NPC menu
and periodic Source CAS changes with the five-class client history02457.
The client/engine stay on their actual clean02457 source. Source identities
are deliberately separate; no binary or attestation is relabelled.

Fourteen actual guarded checks pass {len(distinct)} distinct names
({passed_total} executions with overlaps), with zero failures and one original
isolated PostgreSQL periodic fixture ignored locally. Gateway web249,
five-class simulation125/Gateway18, NPC300, native quest links2/diary5,
periodic rules10, CanMove9, buff clocks5, owner health16/32 and periodic
integration16 plus quest icons1/agent scripts1 all pass. Each actual caller
and its original source snapshot/guard/receipt remain in the evidence archive.
The old helper consumed review.scope while the independent report used
sourceScope, so that old loop checked zero rows. A new independent binding
review verifies every captured row and all original receipts without rewriting
history. Its explicitly reviewed Rust rows match all actual snapshots. The
VIS01 include_str native fixture was not captured by the old snapshot: complete
Gateway compiled-input snapshot closure is not claimed. The unchanged full
Linux workflow on the new clean commit must compile its tracked fixture.

The original02457 Linux CI38185310159 failed291/1 at a VIS01 typed death
comparison and remains failed. Only two characters in that one test change:
ordinary Scarecrow and Deer deaths use Source Type0, matching the existing
native transcript. All assertions, production serializer, special Type1/2
handling and native inputs are byte unchanged. Source default ordinary Die()
retains a corpse; the special types remove it. This is no full Type1 acceptance.
The original coordinator's false zero-match diagnostic after actual NPC300
is retained; only its anchored parser was repaired, without repeating green tests.

Original client CI38185307238 actually completes all eight build jobs,
including987 default-parallel Native passes and seven original external ignores;
its main-only protected publication job is skipped on the Candidate branch.
The genuine artifact remains internal Candidate, not Publisher Authenticode.

[Actual commands and original evidence](../artifacts/qa-evidence/five-class-candidate-20261011/f574-backend-checks01.json)
bind both independent91-path reviews, the actual capture limitation and exact
merge proofs. The failed first sealer (missing scope before any writes) remains
in the archive. Current clean
merged Linux qualification, complete signed R26 package and a fresh drained
paired publication remain open. Human/native/laptop gameplay acceptance and
the unrelated P1–P7 work remain open; no whole-project100% claim is made.
''',encoding='utf-8')
note=f'''\n> Five-class/live NPC Gateway merge, 2026-10-12: separate server worktree\n> retains all live f574 ordinary-menu/periodic CAS behavior and02457 five-class\n> history. Fourteen real guarded checks pass {len(distinct)} distinct names\n> ({passed_total} executions with overlap); one original isolated PostgreSQL fixture\n> remains ignored locally. The original02457 Linux291/1 red is retained; two\n> ordinary VIS01 death inputs now match Source Type0, with all assertions and\n> product Type1/2 bytes unchanged. No full Type1 acceptance. The old QA scope
> loop checked zero rows; the independent actual snapshot binding now verifies
> the captured Rust rows and receipts, but the VIS01 include_str fixture lacked
> a historical snapshot row. Complete Gateway compiled-input capture remains
> unproved and must not be inferred from current hashes. Actual client CI\n> passes all eight build jobs and Native987/0/7. Current merged Linux CI, signed\n> R26 package and fresh drained paired publication remain pending. Client and\n> engine stay on genuine02457; Gateway will retain its own actual commit identity.\n> [Original evidence and limits](FIVE-CLASS-LIVE-NPC-MERGE-20261012.md).\n> No human/native/laptop or whole-project100% acceptance.\n\n'''
for name in ['AGENT-ORCHESTRATION.md','AGENT-TASK-QUEUE.md','CRYSTAL-1TO1-ROADMAP.md','BACKEND-1TO1-PROGRESS.md','CRYSTAL-SERVER-PARITY.md']:
 path=project/'docs'/name
 data=path.read_bytes()
 i=data.index(b'\n')+1
 path.write_bytes(data[:i]+note.encode('utf-8')+data[i:])
exclude=Path(subprocess.run(['git','rev-parse','--git-path','info/exclude'],cwd=root,capture_output=True,check=True).stdout.decode().strip())
if not exclude.is_absolute():exclude=root/exclude
before=exclude.read_bytes()
entry=b'/work/fiveclass-live-gateway-20261012/'
if entry not in before.splitlines():
 exclude.write_bytes(before+(b'' if before.endswith(b'\n') else b'\n')+b'# Root-owned temporary QA path only\n'+entry+b'\n')
(work/'qa-ignore-own-path-proof01.json').write_text(json.dumps({'path':str(exclude),'beforeSha256':sha(before),'afterSha256':sha(exclude.read_bytes()),'onlyAddedPattern':entry.decode(),'productSourceNotIgnored':True},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':14,'passedExecutions':passed_total,'distinctPassed':len(distinct),'ignored':ignored_total,'evidenceArchiveSha256':sha(archive_path.read_bytes()),'summarySha256':sha((artifact/'f574-backend-checks01.json').read_bytes()),'docsUpdated':6}))
