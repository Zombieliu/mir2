from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

work = Path(__file__).resolve().parent
root = work.parent.parent
path = root / 'mir2-web3/apps/gateway/src/web.rs'
old = path.read_bytes()
start = old.index(b'    fn vis01_bichon_actor_fixture_is_exact_gateway_typed_packet_output() {')
end = old.index(b'\n    #[test]', start)
before = old[:start]
body = old[start:end]
after = old[end:]
target = b'object_id: 2005,\n                    location: Point { x: 292, y: 616 },\n                    direction: MirDirection::Right,\n                    kind: 2,'
replacement = target[:-2] + b'0,'
assert body.count(target) == 1
new_body = body.replace(target, replacement)
assert new_body.count(b'kind: 1,') == body.count(b'kind: 1,') == 1
new = before + new_body + after
assert len(old) == len(new) and sum(a != b for a,b in zip(old,new)) == 1
backup = work / 'web-before-vis01-fix01.rs'
assert not backup.exists()
backup.write_bytes(old)
path.write_bytes(new)
sha = lambda b: hashlib.sha256(b).hexdigest()
proof = {
 'schema': 'mir2.five-class.vis01-test-only-repair.v1',
 'createdUtc': datetime.now(timezone.utc).isoformat(),
 'path': str(path), 'beforeSha256': sha(old), 'afterSha256': sha(new),
 'backup': str(backup), 'changedBytes': 1,
 'testFunction': 'vis01_bichon_actor_fixture_is_exact_gateway_typed_packet_output',
 'outsideTestFunctionByteIdentical': before == new[:start] and after == new[end:],
 'ordinaryDeathKind': 0, 'type1Unchanged': True,
 'allAssertionsByteUnchanged': True,
 'sourceReason': 'Crystal ordinary ObjectDied default kind 0 retains corpse; kind 2 is special removal. Native fixture already matches kind 0.',
 'originalFailedCi': 38185310159,
 'fixture': 'mir2-web3/apps/game-client/platform-windows/tests/fixtures/vis01-bichon-actors-v1.json',
 'acceptedForRelease': False, 'actualTestsRun': False
}
(work / 'vis01-test-only-repair-proof01.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
freeze = json.loads((work/'f574-fiveclass-backend-freeze01.json').read_text(encoding='utf-8-sig'))
for row in freeze['scope']:
 data = (root/row['path']).read_bytes()
 if row['path'] != 'mir2-web3/apps/gateway/src/web.rs':
  assert sha(data) == row['sha256'] and len(data) == row['length'], row['path']
 row['sha256'], row['length'] = sha(data), len(data)
fixture = proof['fixture']
if not any(row['path'] == fixture for row in freeze['scope']):
 data = (root/fixture).read_bytes()
 freeze['scope'].append({'path': fixture, 'sha256': sha(data), 'length': len(data)})
freeze['createdUtc'] = datetime.now(timezone.utc).isoformat()
freeze['previousFreezeSha256'] = sha((work/'f574-fiveclass-backend-freeze01.json').read_bytes())
freeze['testOnlyRepairProof'] = {'path': 'vis01-test-only-repair-proof01.json', 'sha256': sha((work/'vis01-test-only-repair-proof01.json').read_bytes())}
freeze['nativeInputsExcluded'] = 'Product native inputs excluded; unchanged VIS01 include_str fixture pinned for exact Gateway comparison.'
(work/'f574-fiveclass-backend-freeze02.json').write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'changedBytes':1,'scopeCount':len(freeze['scope']),'webSha256':sha(new),'freezeSha256':sha((work/'f574-fiveclass-backend-freeze02.json').read_bytes()),'outsideTestIdentical':proof['outsideTestFunctionByteIdentical']}))
