$ErrorActionPreference='Stop'
$review=Join-Path $PSScriptRoot 'f574-fiveclass-backend-review02.json'
$checks=@(
 @{id='f574-gateway-web01';package='mir2-gateway';scope='gateway';filter='web::'},
 @{id='f574-simulation-five01';package='mir2-simulation';scope='simulation';filter='five_class'},
 @{id='f574-gateway-five01';package='mir2-gateway';scope='gateway';filter='five_class'},
 @{id='f574-simulation-npc01';package='mir2-simulation';scope='simulation';filter='npc_'},
 @{id='f574-simulation-quest-links01';package='mir2-simulation';scope='simulation';filter='quest_dialog_operation_link_tests'},
 @{id='f574-simulation-diary01';package='mir2-simulation';scope='simulation';filter='diary_quest_tests'},
 @{id='f574-simulation-periodic-rules01';package='mir2-simulation';scope='simulation';filter='periodic_quest_rules_tests'},
 @{id='f574-simulation-can-move01';package='mir2-simulation';scope='simulation';filter='source_can_move_tests'},
 @{id='f574-simulation-buff-clock01';package='mir2-simulation';scope='simulation';filter='session_zone_buff_clock_tests'},
 @{id='f574-simulation-owner-health01';package='mir2-simulation';scope='simulation';filter='owner_health_tests'},
 @{id='f574-gateway-owner-health01';package='mir2-gateway';scope='gateway';filter='owner_health_sync_tests'}
)
foreach($check in $checks){
 $log=Join-Path $PSScriptRoot ($check.id+'-runner.log')
 if(Test-Path -LiteralPath $log){throw 'Preserve existing actual check log.'}
 & pwsh -NoProfile -File (Join-Path $PSScriptRoot 'run-guarded-check.ps1') -CheckId $check.id -ReviewPath $review -Package $check.package -Scope $check.scope -Filter $check.filter -Lib *> $log
 $code=$LASTEXITCODE
 Write-Host ($check.id+': actual wrapper exit '+$code)
 if($code-ne0){throw ('Actual guarded check failed: '+$check.id)}
 $result=Get-Content -LiteralPath (Join-Path $PSScriptRoot ($check.id+'/result.json')) -Raw | ConvertFrom-Json
 if($result.exitCode-ne0 -or @($result.sourceDrift).Count-ne0){throw 'Actual result/source drift mismatch.'}
 $resultline=@(Select-String -LiteralPath (Join-Path $PSScriptRoot ($check.id+'/cargo.log')) -Pattern '^test result:')
 if($resultline.Count-ne1 -or $resultline[0].Line-match '0 passed;'){throw 'Exact focused filter matched no tests or ambiguous results.'}
 Write-Host $resultline[0].Line
}
