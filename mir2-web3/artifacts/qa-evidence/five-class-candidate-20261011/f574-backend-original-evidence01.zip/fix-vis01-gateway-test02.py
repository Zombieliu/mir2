from pathlib import Path
import hashlib, json
from datetime import datetime, timezone
work=Path(__file__).resolve().parent
root=work.parent.parent
web=root/'mir2-web3/apps/gateway/src/web.rs'
old=web.read_bytes()
start=old.index(b'    fn vis01_bichon_actor_fixture_is_exact_gateway_typed_packet_output() {')
end=old.index(b'\n    #[test]',start)
target=b'object_id: 2004,\n                    location: Point { x: 290, y: 618 },\n                    direction: MirDirection::Up,\n                    kind: 1,'
assert old[start:end].count(target)==1
new=old[:start]+old[start:end].replace(target,target[:-2]+b'0,')+old[end:]
assert len(old)==len(new) and sum(a!=b for a,b in zip(old,new))==1
initial=(work/'web-before-vis01-fix01.rs').read_bytes()
assert len(new)==len(initial) and sum(a!=b for a,b in zip(initial,new))==2
assert old[:start]==new[:start] and old[end:]==new[end:]
sha=lambda b:hashlib.sha256(b).hexdigest()
backup=work/'web-before-vis01-fix02.rs'
assert not backup.exists()
backup.write_bytes(old)
web.write_bytes(new)
references=[]
for source,start_line,end_line in [
 (Path('E:/mir2/Crystal/Server/MirObjects/MonsterObject.cs'),966,977),
 (Path('E:/mir2/Crystal/Client/MirScenes/GameScene.cs'),3790,3816),
 (Path('E:/mir2/Crystal/Shared/ServerPackets.cs'),0,0),
 (Path('E:/mir2/Crystal/Server/MirObjects/Monsters/Deer.cs'),0,0)
]:
 data=source.read_bytes()
 if start_line:
  excerpt=b'\n'.join(data.splitlines()[start_line-1:end_line])
 else:
  if source.name=='ServerPackets.cs':
   i=data.index(b'    public sealed class ObjectDied') if b'    public sealed class ObjectDied' in data else data.index(b'class ObjectDied')
   excerpt=data[i:i+680]
  else:excerpt=data
 references.append({'path':str(source),'length':len(data),'sha256':sha(data),'startLine':start_line,'endLine':end_line,'excerpt':excerpt.decode('utf-8-sig')})
proof={
 'schema':'mir2.five-class.vis01-test-only-repair.v2','createdUtc':datetime.now(timezone.utc).isoformat(),
 'path':str(web),'beforeSha256':sha(old),'initialBeforeSha256':sha(initial),'afterSha256':sha(new),
 'backup':str(backup),'initialBackup':str(work/'web-before-vis01-fix01.rs'),
 'changedBytesThisStep':1,'totalChangedBytesFromOriginal':2,
 'testFunction':'vis01_bichon_actor_fixture_is_exact_gateway_typed_packet_output',
 'outsideTestFunctionByteIdentical':True,'allAssertionsByteUnchanged':True,
 'ordinaryScarecrowDeathKind':0,'ordinaryDeerDeathKind':0,
 'productType1AndType2SemanticsUnchanged':True,'fullType1ParityAccepted':False,
 'reason':'Both ordinary Source deaths default Type0 and retain corpses; Type1/2 special removal is not ordinary death or ObjectHarvested.',
 'sourceReferences':references,'originalFailedCi':38185310159,
 'acceptedForRelease':False,'actualTestsRun':False
}
proof_path=work/'vis01-test-only-repair-proof02.json'
proof_path.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
previous=work/'f574-fiveclass-backend-freeze02.json'
freeze=json.loads(previous.read_text(encoding='utf-8'))
for row in freeze['scope']:
 data=(root/row['path']).read_bytes()
 if row['path']!='mir2-web3/apps/gateway/src/web.rs':assert sha(data)==row['sha256'] and len(data)==row['length'],row['path']
 row['sha256'],row['length']=sha(data),len(data)
freeze['createdUtc']=datetime.now(timezone.utc).isoformat()
freeze['previousFreezeSha256']=sha(previous.read_bytes())
freeze['testOnlyRepairProof']={'path':proof_path.name,'sha256':sha(proof_path.read_bytes())}
freeze_path=work/'f574-fiveclass-backend-freeze03.json'
freeze_path.write_text(json.dumps(freeze,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'webSha256':sha(new),'proofSha256':sha(proof_path.read_bytes()),'freezeSha256':sha(freeze_path.read_bytes()),'totalChangedBytes':2,'scopeCount':len(freeze['scope'])}))
